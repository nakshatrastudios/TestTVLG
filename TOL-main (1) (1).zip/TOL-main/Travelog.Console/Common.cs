﻿using System.Data;
using System.Security.Principal;
using System.Text;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Enums;

namespace Travelog.Console {
    public static class Common {
        public static string GetOdbcConnectionString(CustomerType customerType = CustomerType.TravelogStagingTest2) {
            return string.Format("ODBC;Driver={{SQL Server Native Client 11.0}};Server=localhost;Database={0};Trusted_Connection=Yes;Connection Pooling=False;MultipleActiveResultSets=True", customerType.ToString().ToLower());
        }

        public static string GetConnectionString(CustomerType customerType = CustomerType.TravelogStagingTest2) {
			return AppSettings.ConnectionStringLocal.Replace("{0}", customerType.ToString().ToLower());
		}

		public static int GetCustomerId(CustomerType customerType = CustomerType.TravelogStagingTest2) {
			return (int)customerType;
		}

		public static void InitCustomer(IPrincipal principal, int customerId = (int)CustomerType.TravelogStagingTest2) {
			using (var adminContext = new AppAdminContext(principal, AppSettings.ConnectionStringLocalAdmin)) {
				var customer = adminContext.Customer.Find(customerId);
				CustomerSettings.InitSettings(adminContext, customer);
			}
		}

		public static decimal GetTaxRate(IPrincipal principal, DateTime dateApplicable, int customerId = (int)CustomerType.TravelogStagingTest2) {
			using (var adminContext = new AppAdminContext(principal, AppSettings.ConnectionStringLocalAdmin)) {
				var customer = adminContext.Customer.Find(customerId);
				return adminContext.TaxRate.Where(t => t.CountryCode == customer.CountryCode).OrderByDescending(t => t.DateEffective).FirstOrDefault(t => t.DateEffective <= dateApplicable)?.Rate ?? 0;
			}
		}

		public static string GetErrorMessage(this Exception ex) {
			var sb = new StringBuilder();
			sb.AppendFormat("Exception: {0}", ex.Message).AppendLine();

			var innerException = ex.InnerException;

			while (innerException != null) {
				if (innerException.Message != ex.Message)
					sb.AppendFormat("Inner Exception: {0}", innerException.Message).AppendLine();

				innerException = innerException.InnerException;
			}

			return sb.ToString();
		}
    }
}