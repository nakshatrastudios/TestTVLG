﻿using System.Data;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using Microsoft.Data.SqlClient;
using Microsoft.Office.Interop.Access;
using Microsoft.Office.Interop.Access.Dao;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Common;

namespace Travelog.Console {
    public class ExportData {
        private const int dbLong = 4;
        private const int dbAppendOnly = 8;
        private const int dbSQLPassThrough = 64;
        private const int dbFailOnError = 128;
        private const int dbSeeChanges = 512;
        private const int dbAttachSavePwd = 131072;
        private const int dbAttachedOdbc = 536870912;

        private class RecordsetRow {
            public string SchemaName { get; set; }
            public string TableName { get; set; }
            public List<string> QueryList { get; set; }
            public List<string> PassThroughQueryList { get; set; }
            public bool IsLocal { get; set; }
            public bool IdentityInsert { get; set; }
            public bool ReseedIdentity { get; set; }
            public bool LineByLine { get; set; }
        }

        public void Export() {
            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Initialising application", DateTime.Now));
            var principal = Utils.GetGenericIdentity(null, "steve@travelog.com.au", "ConsoleApp");

            DateTime startTime = DateTime.Now;
            bool isError = false;
            string sql = null;

            List<RecordsetRow> tableList = null;

            Application app = null;
            Database db = null;

            Recordset rst1 = null;
            Recordset rst2 = null;

            string columnNames = null;
            string parameterNames = null;
            string table = null;
            string linkedTable = null;
            string idColumn = null;

            bool updateCountryCodes = false;
            bool updateSupplierCreditor = false;
            bool updateReceipt = false;
            bool updateBsp = false;
            bool updateInvoice = false;
            bool updateAdjustment = false;
            bool updateBspCreditor = false;
            bool updatePassenger = false;
            bool updateTripLineAirPassenger = false;

            try {
                Common.InitCustomer(principal);

                app = new Application();
                app.OpenCurrentDatabase(@"D:\Documents\Clients\Travelog\Projects\Desktop\DataMapping\DataMapping.accdb");

                if (app.DCount("*", "TableList", "IsSelected=true") == 0) {
                    System.Console.WriteLine("No rows selected");
                    isError = true;
                    return;
                }

                db = app.CurrentDb();
                db.QueryTimeout = 0;

                CleanCostingPayments(db);

                using (var con = new SqlConnection(Common.GetConnectionString())) {
                    con.Open();
                    System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Disabling check constraints", DateTime.Now));

                    using (var cmd = new SqlCommand()) {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;

                        cmd.CommandText = "exec sys.sp_MSforeachtable 'alter table ? nocheck constraint all'";
                        cmd.ExecuteNonQuery();

                        System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Disabling indexes", DateTime.Now));
                        var list = new List<string>();

                        cmd.CommandText = "SELECT 'ALTER INDEX ' + QUOTENAME(I.name) + ' ON ' +  QUOTENAME(SCHEMA_NAME(T.schema_id)) + '.' + QUOTENAME(T.name) + ' DISABLE' "
                            + "FROM sys.indexes I "
                            + "INNER JOIN sys.tables T ON I.object_id = T.object_id "
                            + "WHERE I.type_desc = 'NONCLUSTERED' "
                            + "AND I.name IS NOT NULL "
                            + "AND QUOTENAME(SCHEMA_NAME(T.schema_id)) <> '[dbo]' "
                            + "AND I.is_disabled = 0";

                        var reader = cmd.ExecuteReader();

                        while (reader.Read()) {
                            list.Add(reader.GetString(0));
                        }

                        reader.Close();

                        foreach (string query in list) {
                            cmd.CommandText = query;
                            cmd.ExecuteNonQuery();
                        }

                        System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Inserting Trip IDs", DateTime.Now));

                        sql = "delete TripIdLookup.* from TripIdLookup";
                        db.Execute(sql);

                        sql = "insert into TripIdLookup (TripId) select TripId from vw_TripIdLookup";
                        db.Execute(sql);

                        sql = "select SchemaName, TableName from TableList where (not IsLocal) and (IsSelected) group by SchemaName, TableName order by min(SeqNo)";
                        rst1 = db.OpenRecordset(sql, 4, dbSeeChanges);

                        while (!rst1.EOF) {
                            table = string.Format("[{0}].[{1}]", rst1.Fields[0].Value, rst1.Fields[1].Value);
                            System.Console.WriteLine("{0:dd-MMM-yyyy HH:mm}: Deleting data from {1}", DateTime.Now, table);

                            cmd.CommandText = string.Format("delete {0}", table);
                            cmd.ExecuteNonQuery();

                            rst1.MoveNext();
                        }

                        rst1.Close();

                        cmd.CommandText = "delete [ClientLedger].[TripItinerary]";
                        cmd.ExecuteNonQuery();

                        cmd.CommandText = "delete [Accounting].[TransactionDetailAllocation]";
                        cmd.ExecuteNonQuery();

                        cmd.CommandText = "delete [Accounting].[TransactionDetail]";
                        cmd.ExecuteNonQuery();

                        cmd.CommandText = "delete [Accounting].[Transaction]";
                        cmd.ExecuteNonQuery();
                    }
                }

                using (var con = new SqlConnection(Common.GetConnectionString())) {
                    con.Open();
                    sql = "select SchemaName, TableName, QueryList, PassThroughQueryList, IsLocal, IdentityInsert, ReseedIdentity, LineByLine from TableList where (QueryList <> '' and IsSelected) order by SeqNo";
                    rst1 = db.OpenRecordset(sql, 4, dbSeeChanges);

                    tableList = new List<RecordsetRow>();

                    while (!rst1.EOF) {
                        string queryList = rst1.Fields[2].Value.ToStringExt();
                        string passThroughQueryList = string.Empty;

                        if (rst1.Fields[3].Value is not DBNull)
                            passThroughQueryList = rst1.Fields[3].Value.ToStringExt();

                        tableList.Add(new RecordsetRow {
                            SchemaName = rst1.Fields[0].Value.ToStringExt(),
                            TableName = rst1.Fields[1].Value.ToStringExt(),
                            QueryList = queryList.Split(';').ToList(),
                            PassThroughQueryList = string.IsNullOrEmpty(passThroughQueryList) ? new List<string>() : passThroughQueryList.Split(';').ToList(),
                            IsLocal = rst1.Fields[4].Value.ToBool(),
                            IdentityInsert = rst1.Fields[5].Value.ToBool(),
                            ReseedIdentity = rst1.Fields[6].Value.ToBool(),
                            LineByLine = rst1.Fields[7].Value.ToBool()
                        });

                        rst1.MoveNext();
                    }

                    rst1.Close();

                    using (var cmd = new SqlCommand()) {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;

                        cmd.CommandText = "delete [Common].[IssuedDocument]";
                        cmd.ExecuteNonQuery();
                    }

                    InitInsert(con, "[Common].[IssuedDocument]", false, true);
                }

                foreach (var row in tableList) {
                    table = string.Format("[{0}].[{1}]", row.SchemaName, row.TableName);

                    using (var con = new SqlConnection(Common.GetConnectionString())) {
                        con.Open();
                        InitInsert(con, table, row.IdentityInsert, row.ReseedIdentity);
                    }

                    linkedTable = string.Empty;
                    columnNames = string.Empty;
                    parameterNames = string.Empty;
                    idColumn = string.Empty;

                    System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing table {1}", DateTime.Now, table));

                    foreach (string query in row.QueryList) {
                        bool dateUpdatesValidated = false;

                        try {
                            if (query.StartsWith("vw_Country") || query.StartsWith("vw_Voucher") || query.StartsWith("vw_ProfileAddress") || query.StartsWith("vw_TripAddress") || query.StartsWith("vw_TripLineLand") || query.StartsWith("vw_AgencyAddress") || query.StartsWith("vw_BankAccountAddress") || query.StartsWith("vw_CreditorAddress") || query.StartsWith("vw_SupplierAddress") || query.StartsWith("vw_DebtorAddress")) {
                                updateCountryCodes = true;
                            }
                            else if (query.StartsWith("vw_ReceiptDetail")) {
                                updateReceipt = true;
                            }
                            else if (query.StartsWith("vw_Bsp")) {
                                updateBsp = true;
                            }
                            else if (query.StartsWith("vw_InvoiceDetail")) {
                                updateInvoice = true;
                            }
                            else if (query.StartsWith("vw_Adjustment")) {
                                updateAdjustment = true;
                            }
                            else if (query.StartsWith("vw_Creditor")) {
                                updateBspCreditor = true;
                            }
                            else if (query.StartsWith("vw_SupplierCreditor")) {
                                updateSupplierCreditor = true;
                            }
                            else if (query.StartsWith("vw_Passenger")) {
                                updatePassenger = true;
                            }
                            else if (query.StartsWith("vw_TripLineAirPassenger")) {
                                updateTripLineAirPassenger = true;
                            }

                            if (row.LineByLine)
                                throw new NotImplementedException(string.Format("{0:dd-MMM-yyyy HH:mm}: Line-by-line insert of query {1}", DateTime.Now, query));

                            if (row.IsLocal) {
                                db.Execute(query, dbSeeChanges);
                                continue;
                            }

                            if (linkedTable != string.Format("{0}_{1}", row.SchemaName, row.TableName)) {
                                linkedTable = string.Format("{0}_{1}", row.SchemaName, row.TableName);

                                if (app.DCount("*", "MSysObjects", string.Format("Name='{0}'", linkedTable)) == 1)
                                    app.DoCmd.DeleteObject(AcObjectType.acTable, linkedTable);

                                app.DoCmd.TransferDatabase(AcDataTransferType.acLink, "ODBC", Common.GetOdbcConnectionString(), AcObjectType.acTable, string.Format("{0}.{1}", row.SchemaName, row.TableName), linkedTable);
                                db.TableDefs.Refresh();

                                var tdf = db.TableDefs[linkedTable];
                                tdf.Attributes = dbAttachSavePwd;
                                tdf.Connect = Common.GetOdbcConnectionString();
                                tdf.RefreshLink();

                                for (int i = 0; i < db.QueryDefs[query].Fields.Count; i++) {
                                    if (i == 0 && db.QueryDefs[query].Fields[i].Type == dbLong)
                                        idColumn = db.QueryDefs[query].Fields[i].Name;

                                    columnNames += string.Format("[{0}],", db.QueryDefs[query].Fields[i].Name);
                                }

                                columnNames = columnNames.Substring(0, columnNames.Length - 1);
                            }

                            UpdateMinDate(db, table, columnNames, linkedTable, row);
                            dateUpdatesValidated = true;

                            int idMin = -3;
                            int idMax = -3;
                            int processCount = 0;
                            int rowCount = app.DCount("*", query);

                            while (rowCount > processCount) {
                                if (rowCount > 20000) {
                                    sql = string.Format("select top 20000 {0} from {1} where ({2} > {3}) order by {2}", columnNames, query, idColumn, idMax);

                                    rst2 = db.OpenRecordset(sql, 4, dbSeeChanges);

                                    if (rst2.RecordCount > 0) {
                                        idMin = int.Parse(rst2.Fields[0].Value.ToString());
                                        rst2.MoveLast();
                                        idMax = int.Parse(rst2.Fields[0].Value.ToString());

                                        System.Console.WriteLine("{0:dd-MMM-yyyy HH:mm}: Processing query {1} rows {2} to {3} of {4}", DateTime.Now, query, processCount + 1, processCount + 20000 <= rowCount ? processCount + 20000 : rowCount, rowCount);
                                        processCount += rst2.RecordCount;
                                    }

                                    rst2.Close();
                                }
                                else {
                                    System.Console.WriteLine("{0:dd-MMM-yyyy HH:mm}: Processing query {1} rows 1 to {2} of {2}", DateTime.Now, query, rowCount);
                                    processCount = rowCount;
                                }

                                if (rowCount > 20000) {
                                    sql = string.Format("insert into {0} ({1}) select {1} from {2} where ({3} between {4} and {5}) order by {3}", linkedTable, columnNames, query, idColumn, idMin, idMax);
                                }
                                else {
                                    sql = string.Format("insert into {0} ({1}) select {1} from {2}", linkedTable, columnNames, query);
                                }

                                db.Execute(sql, dbFailOnError);
                            }
                        }
                        catch (Exception ex) {
                            if (ex is NotImplementedException) {
                                System.Console.Write(ex.GetErrorMessage());
                            }
                            else {
                                System.Console.WriteLine("{0:dd-MMM-yyyy HH:mm}: Table {1} ODBC Error: {2}", DateTime.Now, table, ex.GetErrorMessage());

                                foreach (var error in app.DBEngine.Errors) {
                                    System.Console.WriteLine("Stack Trace: {0}", error);
                                }
                            }

                            if (row.IsLocal)
                                continue;

                            using (var con = new SqlConnection(Common.GetConnectionString())) {
                                con.Open();
                                InitInsert(con, table, row.IdentityInsert, row.ReseedIdentity);

                                columnNames = string.Empty;
                                parameterNames = string.Empty;

                                sql = string.Format("select {0}.* from {0}", query);
                                rst2 = db.OpenRecordset(sql, 4, dbSeeChanges);

                                var columnValues = new List<object>();
                                var valueList = new List<string>();

                                if (!rst2.EOF)
                                    rst2.MoveLast();

                                int rowNo = 0;
                                int rowCount = rst2.RecordCount;

                                if (!rst2.BOF)
                                    rst2.MoveFirst();

                                if (!dateUpdatesValidated) {
                                    UpdateMinDate(rst2, table, row);
                                    dateUpdatesValidated = true;
                                }

                                while (!rst2.EOF) {
                                    rowNo++;
                                    System.Console.WriteLine("{0:dd-MMM-yyyy HH:mm}: Processing query {1} (row {2} of {3})", DateTime.Now, query, rowNo, rowCount);

                                    if (columnNames.Length == 0) {
                                        for (int i = 0; i < rst2.Fields.Count; i++) {
                                            columnNames += string.Format("{0},", rst2.Fields[i].Name);
                                            parameterNames += string.Format("@{0},", rst2.Fields[i].Name);
                                        }

                                        columnNames = columnNames.Substring(0, columnNames.Length - 1);
                                        parameterNames = parameterNames.Substring(0, parameterNames.Length - 1);
                                    }

                                    using (var cmd = new SqlCommand()) {
                                        cmd.Connection = con;
                                        cmd.CommandType = CommandType.Text;
                                        cmd.CommandTimeout = 0;
                                        cmd.CommandText = string.Format("insert into {0} ({1}) values ({2})", table, columnNames, parameterNames);

                                        for (int colNo = 0; colNo < rst2.Fields.Count; colNo++) {
                                            object value = rst2.Fields[colNo].Value;

                                            if ((table == "[Common].[Aircraft]" && rst2.Fields[colNo].Name == "Name")
                                                || (table == "[Common].[InsurancePlan]" && rst2.Fields[colNo].Name == "Name")
                                                || (table == "[CreditorLedger].[Creditor]" && rst2.Fields[colNo].Name == "Name")
                                                || (table == "[CreditorLedger].[Supplier]" && rst2.Fields[colNo].Name == "Name")
                                                || (table == "[DebtorLedger].[Debtor]" && rst2.Fields[colNo].Name == "Name")) {

                                                string columnValue = value.ToString().Trim();

                                                if (valueList.Any(t => t.Equals(columnValue, StringComparison.OrdinalIgnoreCase))) {
                                                    int valueCount = 2;

                                                    while (valueList.Any(t => t.Equals(columnValue, StringComparison.OrdinalIgnoreCase))) {
                                                        columnValue = string.Format("{0} {1}", rst2.Fields[colNo].Value, valueCount);
                                                        bool exists = valueList.Any(t => t.Equals(columnValue, StringComparison.OrdinalIgnoreCase));

                                                        valueList.Add(columnValue);

                                                        if (!exists)
                                                            break;

                                                        valueCount++;
                                                    }
                                                }
                                                else {
                                                    valueList.Add(columnValue);
                                                }

                                                value = columnValue;
                                            }

                                            cmd.Parameters.Add(new SqlParameter(rst2.Fields[colNo].Name, value));
                                        }

                                        cmd.ExecuteNonQuery();
                                    }

                                    rst2.MoveNext();
                                }

                                System.Console.WriteLine();
                                rst2.Close();
                            }
                        }
                    }

                    using (var con = new SqlConnection(Common.GetConnectionString())) {
                        con.Open();

                        if (updateCountryCodes)
                            UpdateCountryCodes(con);

                        if (updateSupplierCreditor)
                            UpdateSupplierCreditor(con);

                        if (updateTripLineAirPassenger)
                            UpdateTripLineAirPassenger(con);

                        if (updateBsp)
                            UpdateBsp(con);

                        if (updateBspCreditor)
                            UpdateBspCreditor(con);

                        if (updateReceipt)
                            UpdateReceipt(principal, con);

                        if (updateInvoice)
                            new Transactions().UpdateInvoiceMatching();

                        if (updateAdjustment)
                            UpdateAdjustment(principal, Common.GetConnectionString());

                        using (var cmd = new SqlCommand()) {
                            cmd.Connection = con;
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;

                            foreach (string query in row.PassThroughQueryList) {
                                cmd.CommandText = query;
                                cmd.ExecuteNonQuery();
                            }

                            if (row.IdentityInsert) {
                                cmd.CommandText = string.Format("set identity_insert {0} off", table);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }

                    UpdateLastDocumentNo(Common.GetConnectionString());
                }
            }
            catch (Exception ex) {
                isError = true;
                System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: {1}", DateTime.Now, ex.GetErrorMessage()));
                System.Console.WriteLine(string.Format("Stack Trace: {0}", ex.StackTrace));
            }
            finally {
                db?.Close();

                if (app != null) {
                    app.CloseCurrentDatabase();
                    app.Quit(AcQuitOption.acQuitSaveNone);
                    ReleaseObject(rst2);
                    ReleaseObject(rst1);
                    ReleaseObject(db);
                    ReleaseObject(app);
                }

                if (!isError) {
                    try {
                        if (updatePassenger) {
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Deleting duplicate passengers", DateTime.Now));

                            using (var con = new SqlConnection(Common.GetConnectionString())) {
                                con.Open();
                                DeleteDuplicatePassengers(con);
                            }
                        }

                        System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Restoring table indexes", DateTime.Now));
                        RestoreTableIndexes();
                    }
                    catch (Exception ex) {
                        isError = true;
                        System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: {1}", DateTime.Now, ex.GetErrorMessage()));
                        System.Console.ReadKey();
                    }
                }

                var endTime = DateTime.Now;
                System.Console.WriteLine(string.Format(@"{0:dd-MMM-yyyy HH:mm}: {1}. Processing time: {2:hh\:mm\:ss}", endTime, isError ? "Export failed" : "Export completed successfully", endTime.Subtract(startTime)));
            }
        }

        public void RestoreTableIndexes() {
            using (var con = new SqlConnection(Common.GetConnectionString())) {
                con.Open();
                var list = new List<string>();

                try {
                    using (var cmd = new SqlCommand()) {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;

                        cmd.CommandText = "SELECT 'ALTER INDEX ' + QUOTENAME(I.name) + ' ON ' +  QUOTENAME(SCHEMA_NAME(T.schema_id)) + '.' + QUOTENAME(T.name) + ' REBUILD' "
                        + "FROM sys.indexes I "
                        + "INNER JOIN sys.tables T ON I.object_id = T.object_id "
                        + "WHERE I.type_desc = 'NONCLUSTERED' "
                        + "AND I.name IS NOT NULL "
                        + "AND QUOTENAME(SCHEMA_NAME(T.schema_id)) <> '[dbo]' "
                        + "AND I.is_disabled = 1";

                        var reader = cmd.ExecuteReader();

                        while (reader.Read()) {
                            list.Add(reader.GetString(0));
                        }

                        reader.Close();

                        foreach (string query in list) {
                            cmd.CommandText = query;
                            cmd.ExecuteNonQuery();
                        }

                        cmd.CommandText = "exec sys.sp_MSforeachtable 'alter table ? with check check constraint all'";
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex) {
                    System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: {1}", DateTime.Now, ex.GetErrorMessage()));
                    System.Console.WriteLine(string.Format("Stack Trace: {0}", ex.StackTrace));
                    System.Console.ReadKey();
                }
            }
        }

        public void UpdateMinDates() {
            var app = new Application();
            app.OpenCurrentDatabase(@"D:\Documents\Clients\Travelog\Projects\Desktop\DataMapping\DataMapping.accdb");

            var db = app.CurrentDb();
            db.QueryTimeout = 0;

            Recordset rst1 = null;
            Recordset rst2 = null;

            try {
                using (var con = new SqlConnection(Common.GetConnectionString())) {
                    con.Open();

                    using (var cmd = new SqlCommand()) {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandTimeout = 0;

                        string sql = "select SchemaName, TableName from TableList order by SeqNo";
                        rst1 = db.OpenRecordset(sql, 4, dbSeeChanges);

                        while (!rst1.EOF) {
                            sql = string.Format("select top 1 * from {0}_{1}", rst1.Fields[0].Value, rst1.Fields[1].Value);
                            rst2 = db.OpenRecordset(sql, 4, dbSeeChanges);

                            foreach (Field field in rst2.Fields) {
                                if (field.Type == 8 && field.Name != "CreationTime" && field.Name != "LastWriteTime") {
                                    cmd.CommandText = string.Format("update {0}.{1} set {2}='01-Jan-0001' where ({2}='01-Jan-1753')", rst1.Fields[0].Value, rst1.Fields[1].Value, field.Name);
                                    cmd.ExecuteNonQuery();

                                    cmd.CommandText = string.Format("update {0}.{1} set {2}='01-Jan-0002' where ({2}='01-Jan-1754')", rst1.Fields[0].Value, rst1.Fields[1].Value, field.Name);
                                    cmd.ExecuteNonQuery();
                                }
                            }

                            rst2.Close();
                            rst1.MoveNext();
                        }

                        rst1.Close();
                    }
                }
            }
            catch (Exception ex) {
                System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: {1}", DateTime.Now, ex.GetErrorMessage()));
                System.Console.WriteLine(string.Format("Stack Trace: {0}", ex.StackTrace));
            }
            finally {
                db?.Close();

                if (app != null) {
                    app.CloseCurrentDatabase();
                    app.Quit(AcQuitOption.acQuitSaveNone);
                    ReleaseObject(rst2);
                    ReleaseObject(rst1);
                    ReleaseObject(db);
                    ReleaseObject(app);
                }
            }
        }

        private void InitInsert(SqlConnection con, string table, bool identityInsert, bool reseedIdentity) {
            using (var cmd = new SqlCommand()) {
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;

                if (identityInsert) {
                    cmd.CommandText = string.Format("set identity_insert {0} on", table);
                    cmd.ExecuteNonQuery();
                }
                else if (reseedIdentity) {
                    int id = 0;
                    cmd.CommandText = string.Format("select max(Id) as Id from {0}", table);

                    var reader = cmd.ExecuteReader();
                    reader.Read();

                    if (reader.HasRows && !(reader.GetValue(0) is DBNull))
                        id = reader.GetInt32(0);

                    reader.Close();

                    if (id < 0)
                        id = 0;

                    cmd.CommandText = string.Format("dbcc checkident ('{0}', reseed, {1})", table, id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void CleanCostingPayments(Database db) {
            string sql = "delete CT_Costing_Payments.* from CT_Costing_Payments where CT_dtDate_Time_Stamp < (select min(TK_Ticket.TK_dtDateTime_Stamp) from TK_Ticket) and (CT_dtDate_Time_Stamp is not null) and (CT_Costing_Payments.CT_bEntry_Type) = 2";
            db.Execute(sql, dbFailOnError);

            sql = "delete CT_Costing_Payments.* from CT_Costing_Payments where CT_dtDate_Time_Stamp < (select min(RT_Return.RT_dtDateTime_Stamp) from RT_Return) and (CT_dtDate_Time_Stamp is not null) and (CT_Costing_Payments.CT_bEntry_Type) = 3";
            db.Execute(sql, dbFailOnError);

            sql = "delete CT_Costing_Payments.* from CT_Costing_Payments where CT_dtDate_Time_Stamp < (select min(CQ_Cheque.CQ_dtDateTime_Stamp) from CQ_Cheque) and (CT_dtDate_Time_Stamp is not null) and (CT_Costing_Payments.CT_bEntry_Type) = 4";
            db.Execute(sql, dbFailOnError);

            sql = "delete CT_Costing_Payments.* from CT_Costing_Payments where CT_dtDate_Time_Stamp < (select min(CR_Cheque_Requisition.CR_dtDateTime_Stamp) from CR_Cheque_Requisition) and (CT_dtDate_Time_Stamp is not null) and (CT_Costing_Payments.CT_bEntry_Type) = 7";
            db.Execute(sql, dbFailOnError);

            sql = "delete CT_Costing_Payments.* from CT_Costing_Payments where CT_dtDate_Time_Stamp < (select min(CR_Charge.CR_dtDateTime_Stamp) from CR_Charge) and (CT_dtDate_Time_Stamp is not null) and (CT_Costing_Payments.CT_bEntry_Type) = 8";
            db.Execute(sql, dbFailOnError);

            sql = "delete CT_Costing_Payments.* from CT_Costing_Payments where CT_lPaid_Transaction_Link in (select CT_lPaid_Transaction_Link from CT_Costing_Payments inner join TK_Ticket on CT_Costing_Payments.CT_lDataEnty_Link = TK_Ticket.TK_lTicket_Counter where (((CT_Costing_Payments.CT_bEntry_Type) = 2) and ((CT_Costing_Payments.CT_dtDate_Time_Stamp) < (TK_Ticket.TK_dtDateTime_Stamp))))";
            db.Execute(sql, dbFailOnError);

            sql = "delete CT_Costing_Payments.* from CT_Costing_Payments where CT_lPaid_Transaction_Link in (select CT_lPaid_Transaction_Link from CT_Costing_Payments inner join RT_Return on CT_Costing_Payments.CT_lDataEnty_Link = RT_Return.RT_lReturn_Key where (((CT_Costing_Payments.CT_bEntry_Type) = 3) and ((CT_Costing_Payments.CT_dtDate_Time_Stamp) < (RT_Return.RT_dtDateTime_Stamp))))";
            db.Execute(sql, dbFailOnError);

            sql = "delete CT_Costing_Payments.* from CT_Costing_Payments where CT_lPaid_Transaction_Link in (select CT_lPaid_Transaction_Link from CT_Costing_Payments inner join CQ_Cheque on CT_Costing_Payments.CT_lDataEnty_Link = CQ_Cheque.CQ_lCheque_Code where (((CT_Costing_Payments.CT_bEntry_Type) = 4) and ((CT_Costing_Payments.CT_dtDate_Time_Stamp) < (CQ_Cheque.CQ_dtDateTime_Stamp))))";
            db.Execute(sql, dbFailOnError);

            sql = "delete CT_Costing_Payments.* from CT_Costing_Payments where CT_lPaid_Transaction_Link in (select CT_lPaid_Transaction_Link from CT_Costing_Payments inner join CR_Cheque_Requisition on CT_Costing_Payments.CT_lDataEnty_Link = CR_Cheque_Requisition.CR_lCheque_Code where (((CT_Costing_Payments.CT_bEntry_Type) = 7) and ((CT_Costing_Payments.CT_dtDate_Time_Stamp) < (CR_Cheque_Requisition.CR_dtDateTime_Stamp))))";
            db.Execute(sql, dbFailOnError);

            sql = "delete CT_Costing_Payments.* from CT_Costing_Payments where CT_lPaid_Transaction_Link in (select CT_lPaid_Transaction_Link from CT_Costing_Payments inner join CR_Charge on CT_Costing_Payments.CT_lDataEnty_Link = CR_Charge.CR_lCharge_Code and CT_Costing_Payments.CT_lBatch_No = CR_Charge.CR_lBatch_No where (((CT_Costing_Payments.CT_bEntry_Type) = 8) and ((CT_Costing_Payments.CT_dtDate_Time_Stamp) < (CR_Charge.CR_dtDateTime_Stamp))))";
            db.Execute(sql, dbFailOnError);
        }

        private void UpdateMinDate(Database db, string table, string columnNames, string linkedTable, RecordsetRow row) {
            string sql = string.Format("select top 1 {0} from {1}", columnNames, linkedTable);
            var rst = db.OpenRecordset(sql, 4, dbSeeChanges);
            UpdateMinDate(rst, table, row);
            rst.Close();
        }

        private void UpdateMinDate(Recordset rst, string table, RecordsetRow row) {
            foreach (Field field in rst.Fields) {
                if (field.Type == 8 && field.Name != "CreationTime" && field.Name != "LastWriteTime") {
                    row.PassThroughQueryList.Add(string.Format("update {0} set {1}='01-Jan-0001' where ({1}='01-Jan-1753')", table, field.Name));
                    row.PassThroughQueryList.Add(string.Format("update {0} set {1}='01-Jan-0002' where ({1}='01-Jan-1754')", table, field.Name));
                }
            }
        }

        private void DeleteDuplicatePassengers(SqlConnection con) {
            using (var sr = new StreamReader(@"D:\Documents\Clients\Travelog\Projects\SqlData\Scripts\DeleteDuplicatePassengers.sql")) {
                using (var cmd = new SqlCommand()) {
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    cmd.CommandText = sr.ReadToEnd();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void UpdateCountryCodes(SqlConnection con) {
            using (var cmd = new SqlCommand()) {
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;

                cmd.CommandText = "delete Common.City from Common.City left outer join Common.Country on Common.City.CountryId=Common.Country.Id where Common.Country.Id is null";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update CreditorLedger.Supplier set CityId=-1 from CreditorLedger.Supplier left outer join Common.City on CreditorLedger.Supplier.CityId=Common.City.Id where Common.City.Id is null";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update ClientLedger.Trip set MainCityId=-1 from ClientLedger.Trip left outer join Common.City on ClientLedger.Trip.MainCityId=Common.City.Id where Common.City.Id is null";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update ClientLedger.TripLineAirSegment set DepartureCityId=-1 from ClientLedger.TripLineAirSegment left outer join Common.City on ClientLedger.TripLineAirSegment.DepartureCityId=Common.City.Id where Common.City.Id is null";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update ClientLedger.TripLineAirSegment set ArrivalCityId=-1 from ClientLedger.TripLineAirSegment left outer join Common.City on ClientLedger.TripLineAirSegment.ArrivalCityId=Common.City.Id where Common.City.Id is null";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update Common.TaxCode set CityId=-1 from Common.TaxCode left outer join Common.City on Common.TaxCode.CityId=Common.City.Id where Common.City.Id is null";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update Accounting.Voucher set SupplierCountryCode=Common.Country.Code from Accounting.Voucher inner join Common.Country on Accounting.Voucher.SupplierCountryCode=Common.Country.IsoCode where Common.Country.Id > 0";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update ClientLedger.ProfileAddress set CountryCode=Common.Country.Code from ClientLedger.ProfileAddress inner join Common.Country on ClientLedger.ProfileAddress.CountryCode=Common.Country.IsoCode where Common.Country.Id > 0";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update ClientLedger.TripAddress set CountryCode=Common.Country.Code from ClientLedger.TripAddress inner join Common.Country on ClientLedger.TripAddress.CountryCode=Common.Country.IsoCode where Common.Country.Id > 0";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update ClientLedger.TripLineLand set SupplierCountryCode=Common.Country.Code from ClientLedger.TripLineLand inner join Common.Country on ClientLedger.TripLineLand.SupplierCountryCode=Common.Country.IsoCode where Common.Country.Id > 0";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update ClientLedger.TripLineLand set StartCountryCode=Common.Country.Code from ClientLedger.TripLineLand inner join Common.Country on ClientLedger.TripLineLand.StartCountryCode=Common.Country.IsoCode where Common.Country.Id > 0";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update ClientLedger.TripLineLand set EndCountryCode=Common.Country.Code from ClientLedger.TripLineLand inner join Common.Country on ClientLedger.TripLineLand.EndCountryCode=Common.Country.IsoCode where Common.Country.Id > 0";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update Common.AgencyAddress set CountryCode=Common.Country.Code from Common.AgencyAddress inner join Common.Country on Common.AgencyAddress.CountryCode=Common.Country.IsoCode where Common.Country.Id > 0";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update Common.BankAccountAddress set CountryCode=Common.Country.Code from Common.BankAccountAddress inner join Common.Country on Common.BankAccountAddress.CountryCode=Common.Country.IsoCode where Common.Country.Id > 0";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update CreditorLedger.CreditorAddress set CountryCode=Common.Country.Code from CreditorLedger.CreditorAddress inner join Common.Country on CreditorLedger.CreditorAddress.CountryCode=Common.Country.IsoCode where Common.Country.Id > 0";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update CreditorLedger.SupplierAddress set CountryCode=Common.Country.Code from CreditorLedger.SupplierAddress inner join Common.Country on CreditorLedger.SupplierAddress.CountryCode=Common.Country.IsoCode where Common.Country.Id > 0";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update DebtorLedger.DebtorAddress set CountryCode=Common.Country.Code from DebtorLedger.DebtorAddress inner join Common.Country on DebtorLedger.DebtorAddress.CountryCode=Common.Country.IsoCode where Common.Country.Id > 0";
                cmd.ExecuteNonQuery();
            }
        }

        private void UpdateSupplierCreditor(SqlConnection con) {
            var sb = new StringBuilder("insert into CreditorLedger.SupplierCreditor (SupplierId, CreditorId, IsDefault, LastWriteTime, CreationTime, LastWriteUser, CreationUser) ");
            sb.AppendFormat("select distinct CreditorLedger.Supplier.Id, CreditorLedger.Creditor.Id, 1, getdate(), getdate(), '{0}', '{0}' ", AppSettings.SystemAccountEmail);
            sb.Append("from CreditorLedger.Creditor inner join CreditorLedger.Supplier on CreditorLedger.Creditor.Name = CreditorLedger.Supplier.Name ");
            sb.Append("left outer join CreditorLedger.SupplierCreditor on CreditorLedger.Supplier.Id = CreditorLedger.SupplierCreditor.SupplierId and CreditorLedger.Creditor.Id = CreditorLedger.SupplierCreditor.CreditorId ");
            sb.Append("where (CreditorLedger.Supplier.Id > 0) and (CreditorLedger.Creditor.Id > 0) and (CreditorLedger.SupplierCreditor.Id is null)");

            using (var cmd = new SqlCommand()) {
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;
                cmd.CommandText = sb.ToString();
                cmd.ExecuteNonQuery();
            }
        }

        private void UpdateReceipt(IPrincipal principal, SqlConnection con) {
            using (var cmd = new SqlCommand()) {
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;

                cmd.CommandText = "update [Accounting].[ReceiptDetail] set DepositDetailId = -1 where (DepositDetailId not in (select Id from Accounting.ReceiptDetail))";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update Accounting.Receipt set ReverseTransferReceiptId = vw_Receipt.Id from (select Id, (select ReverseTransferReceiptId from Accounting.Receipt receipt1 where (receipt1.Id = receipt2.Id)) as ReverseTransferReceiptId from Accounting.Receipt receipt2 where (ReceiptTypeId = 6) and (ReverseTransferReceiptId > 0)) vw_Receipt where vw_Receipt.ReverseTransferReceiptId = Accounting.Receipt.Id";
                cmd.ExecuteNonQuery();
            }

            using (var lazyContext = new AppLazyContext(con.ConnectionString, false)) {
                foreach (var receiptDetail in lazyContext.ReceiptDetail.Where(t => t.MerchantFee != 0).ToList()) {
                    var ccChargeAccount = receiptDetail.GetCreditCardChargeAccount(lazyContext);

                    if (!ccChargeAccount?.IsTaxApplicable ?? true)
                        continue;

                    decimal taxRate = Common.GetTaxRate(principal, receiptDetail.Receipt.DocumentDate);
                    decimal merchantFeeTax = Math.Round(receiptDetail.MerchantFee * taxRate / (1 + taxRate), 2);

                    receiptDetail.MerchantFee -= merchantFeeTax;
                    receiptDetail.MerchantFeeTax = merchantFeeTax;

                    lazyContext.Save(receiptDetail, false);
                }
            }
        }

        private void UpdateBsp(SqlConnection con) {
            using (var sr = new StreamReader(@"D:\Documents\Clients\Travelog\Projects\SqlData\Scripts\UpdateBsp.sql")) {
                using (var cmd = new SqlCommand()) {
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandTimeout = 0;
                    cmd.CommandText = sr.ReadToEnd();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void UpdateBspCreditor(SqlConnection con) {
            int supplierId = 0;

            using (var cmd = new SqlCommand()) {
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;

                cmd.CommandText = "select Id from CreditorLedger.Supplier where (Name='BSP')";

                var reader = cmd.ExecuteReader();
                reader.Read();

                if (reader.HasRows && reader.GetValue(0) is not DBNull)
                    supplierId = reader.GetInt32(0);

                reader.Close();

                if (supplierId == 0)
                    return;

                int creditorId = 0;
                cmd.CommandText = "select Id from CreditorLedger.Creditor where (Name='BSP')";

                reader = cmd.ExecuteReader();
                reader.Read();

                if (reader.HasRows && !(reader.GetValue(0) is DBNull))
                    creditorId = reader.GetInt32(0);

                reader.Close();

                if (creditorId == 0)
                    return;

                bool hasRows = false;
                cmd.CommandText = string.Format("select * from CreditorLedger.SupplierCreditor where (SupplierId={0}) and (CreditorId={1})", supplierId, creditorId);

                reader = cmd.ExecuteReader();
                reader.Read();
                hasRows = reader.HasRows;
                reader.Close();

                if (hasRows)
                    return;

                cmd.CommandText = string.Format("insert into CreditorLedger.SupplierCreditor (SupplierId, CreditorId, IsDefault, LastWriteTime, CreationTime, LastWriteUser, CreationUser) values ({0}, {1}, 0, getdate(), getdate(), '{2}', '{2}')", supplierId, creditorId, AppSettings.SystemAccountEmail);
                cmd.ExecuteNonQuery();

                cmd.CommandText = string.Format("update Accounting.Payment set CreditorId={0} where PaymentTypeId=2 and CreditorId=-1", creditorId);
                cmd.ExecuteNonQuery();
            }
        }

        private void UpdateTripLineAirPassenger(SqlConnection con) {
            using (var cmd = new SqlCommand()) {
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 0;

                cmd.CommandText = "update ClientLedger.TripLineAirPassenger set CreditorId = isnull((select top 1 CreditorId from CreditorLedger.SupplierCreditor where (SupplierId = ClientLedger.TripLineAirPassenger.SupplierId)), CreditorId) where (CreditorId < 0) and (SupplierId > 0)";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update ClientLedger.TripLineAirPassenger set CreditorId = isnull((select top 1 CreditorId from CreditorLedger.SupplierCreditor where (SupplierId = ClientLedger.TripLineAirPassenger.SupplierId)), CreditorId) where (CreditorId in (select Id from CreditorLedger.Creditor where (Name = 'BSP'))) and (SupplierId > 0)";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update ClientLedger.TripLineAirPassenger set CreditorId = (select top 1 Id from CreditorLedger.Creditor where (Name = 'BSP')) where (CreditorId < 0)";
                cmd.ExecuteNonQuery();

                cmd.CommandText = "update ClientLedger.TripLineAirPassenger set SupplierId = (select top 1 SupplierId from CreditorLedger.SupplierCreditor where (CreditorId in (select Id from CreditorLedger.Creditor where (Name = 'BSP')))) where (SupplierId < 0)";
                cmd.ExecuteNonQuery();
            }
        }

        private void UpdateAdjustment(IPrincipal principal, string connString) {
            int customerId = Common.GetCustomerId();

            using (var lazyContext = new AppLazyContext(connString, false)) {
                foreach (var adjustment in lazyContext.Adjustment.AsEnumerable().Where(t => t.IsTaxApplicable).ToList()) {
                    decimal taxRate = Common.GetTaxRate(principal, adjustment.DocumentDate);

                    adjustment.Tax = Math.Round(adjustment.Amount * taxRate / (1 + taxRate), 2);
                    adjustment.Amount -= adjustment.Tax;

                    lazyContext.Save(adjustment, false);
                }
            }
        }

        private void UpdateLastDocumentNo(string connString) {
            using (var context = new AppMainContext(connString, false)) {
                string tripNo = context.Trip.Max(t => t.TripNo) ?? "0";
                LastDocumentNo.DocumentNo(context, "Trip", tripNo);
            }
        }

        private void ReleaseObject(object obj) {
            try {
                if (obj != null)
                    Marshal.ReleaseComObject(obj);
            }
            catch {
            }
            finally {
                GC.Collect();
            }
        }
    }
}