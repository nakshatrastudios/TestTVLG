﻿using System.Data;
using System.Runtime.InteropServices;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Office.Interop.Access;
using Microsoft.Office.Interop.Access.Dao;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Dao.DebtorLedger;
using Travelog.Biz.Enums;
using Travelog.Ledger.Accounting;
using Travelog.WebApp;

namespace Travelog.Console {
    public class Transactions {
        private const int dbSeeChanges = 512;

        public void Update(bool clearTransactions = true) {
            var principal = Utils.GetGenericIdentity(null, "steve@travelog.com.au", "ConsoleApp");

            string connString = Common.GetConnectionString();
            int customerId = Common.GetCustomerId();

            var startTime = DateTime.Now;
            bool isError = false;

            try {
                Common.InitCustomer(principal);

                using (var con = new SqlConnection(connString)) {
                    con.Open();

                    using (var lazyContext = new AppLazyContext(connString, false)) {
                        if (clearTransactions) {
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Resetting identity columns", DateTime.Now));

                            using (var cmd = new SqlCommand()) {
                                cmd.Connection = con;
                                cmd.CommandType = CommandType.Text;
                                cmd.CommandTimeout = 0;

                                cmd.CommandText = "delete [Accounting].[TransactionDetailAllocation]";
                                cmd.ExecuteNonQuery();

                                cmd.CommandText = "delete [Accounting].[TransactionDetail] where Id > 0";
                                cmd.ExecuteNonQuery();

                                cmd.CommandText = "delete [Accounting].[Transaction] where Id > 0";
                                cmd.ExecuteNonQuery();

                                cmd.CommandText = "dbcc checkident ('Accounting.Transaction', reseed, 0)";
                                cmd.ExecuteNonQuery();

                                cmd.CommandText = "dbcc checkident ('Accounting.TransactionDetail', reseed, 0)";
                                cmd.ExecuteNonQuery();

                                cmd.CommandText = "dbcc checkident ('Accounting.TransactionDetailAllocation', reseed, 0)";
                                cmd.ExecuteNonQuery();
                            }
                        }

                        if (!lazyContext.Transaction.Any(t => t.Id == -1)) {
                            using (var cmd = new SqlCommand()) {
                                cmd.Connection = con;
                                cmd.CommandText = "SET IDENTITY_INSERT [Accounting].[Transaction] ON; INSERT INTO [Accounting].[Transaction] (Id, TransactionTypeId, ReceiptId, BspId, NonBspId, PaymentId, InvoiceId, JournalId, AdjustmentId, DocumentType, DocumentNo, DocumentDate, LastWriteTime, CreationTime, LastWriteUser, CreationUser) VALUES (-1, -1, -1, -1, -1, -1, -1, -1, -1, '', '', '01-Jan-0001', '01-Jan-0001', '01-Jan-0001', 'system@travelog.online', 'system@travelog.online'); SET IDENTITY_INSERT [Accounting].[Transaction] OFF";
                                cmd.ExecuteNonQuery();
                            }
                        }

                        if (!lazyContext.TransactionDetail.Any(t => t.Id == -1)) {
                            using (var cmd = new SqlCommand()) {
                                cmd.Connection = con;
                                cmd.CommandText = "SET IDENTITY_INSERT [Accounting].[TransactionDetail] ON; INSERT INTO [Accounting].[TransactionDetail] (Id, TransactionId, LedgerTypeId, SignTypeId, DocumentStatusId, ReversalStatusId, TripId, DebtorId, CreditorId, ChartOfAccountId, ReceiptDetailId, BspDetailId, NonBspDetailId, PaymentDetailId, InvoiceDetailId, JournalDetailId, AgencyId, Description, Reference, Commission, CommissionTax, Discount, DiscountTax, NonCommissionable, NonCommissionableTax, Amount, Tax, TransactionDetailTypeId, TransactionAnalysisTypeId, IsCash, IntegrityCheckFailed, SalesAnalysisAirlineId, SalesAnalysisPassengerId, SalesAnalysisOfferedFare, SalesAnalysisOfferedReasonId, SalesAnalysisDebtorId, SalesAnalysisCreditorId, SalesAnalysisSupplierId, SalesAnalysisSaleTypeId, SalesAnalysisDiscountReasonId, SalesAnalysisGroupId, SalesAnalysisClassId, SalesAnalysisSourceId, SalesAnalysisCategoryId, SalesAnalysisDestinationId, SalesAnalysisRegionId, SalesAnalysisLocationId, SalesAnalysisConsultantId, SalesAnalysisAgentId, LastWriteTime, CreationTime, LastWriteUser, CreationUser) VALUES (-1, -1, 0, 2, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, '01-Jan-0001', '01-Jan-0001', 'system@travelog.online', 'system@travelog.online'); SET IDENTITY_INSERT [Accounting].[TransactionDetail] OFF";
                                cmd.ExecuteNonQuery();
                            }
                        }

                        int count = 0;
                        int rowCount = lazyContext.Receipt.Count(t => t.Id > 0 && !t.IsLegacy) + lazyContext.Bsp.Count(t => t.Id > 0 && !t.IsLegacy) + lazyContext.NonBsp.Count(t => t.Id > 0 && !t.IsLegacy) + lazyContext.Payment.Count(t => t.Id > 0 && !t.IsLegacy) + lazyContext.Invoice.Count(t => t.Id > 0) + lazyContext.Journal.Count(t => t.Id > 0 && !t.IsLegacy) + lazyContext.Adjustment.Count(t => t.Id > 0);

                        foreach (var receipt in lazyContext.Receipt.Where(t => t.Id > 0 && !t.IsLegacy).OrderBy(t => t.DocumentDate).ToList()) {
                            count++;
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2} | Receipt No {3}", DateTime.Now, count, rowCount, receipt.DocumentNo));

                            if (receipt.ReceiptDetails.Count > 0) {
                                using (var context = new AppLazyContext(connString, false)) {
                                    decimal taxRate = Common.GetTaxRate(principal, receipt.DocumentDate);
                                    var receiptDetail = receipt.ReceiptDetails[0];
                                    var merchantFees = receiptDetail.GetMerchantFees(lazyContext, taxRate);
                                    receiptDetail.UpdateTransactions(context, customerId, null, true);
                                }
                            }
                        }

                        foreach (var bsp in lazyContext.Bsp.Where(t => t.Id > 0 && !t.IsLegacy).OrderBy(t => t.DocumentDate).ToList()) {
                            count++;
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2} | BSP No {3}", DateTime.Now, count, rowCount, bsp.DocumentNo));

                            if (bsp.BspDetails.Count > 0) {
                                using (var context = new AppLazyContext(connString, false)) {
                                    bsp.BspDetails[0].UpdateTransactions(context, customerId, null, true);
                                }
                            }
                        }

                        foreach (var nonBsp in lazyContext.NonBsp.Where(t => t.Id > 0 && !t.IsLegacy).OrderBy(t => t.DocumentDate).ToList()) {
                            count++;
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2} | Non-BSP No {3}", DateTime.Now, count, rowCount, nonBsp.DocumentNo));

                            if (nonBsp.NonBspDetails.Count > 0) {
                                using (var context = new AppLazyContext(connString, false)) {
                                    nonBsp.NonBspDetails[0].UpdateTransactions(context, customerId, null, true);
                                }
                            }
                        }

                        foreach (var payment in lazyContext.Payment.Where(t => t.Id > 0 && !t.IsLegacy).OrderBy(t => t.DocumentDate).ToList()) {
                            count++;
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2} | Payment No {3}", DateTime.Now, count, rowCount, payment.DocumentNo));

                            if (payment.PaymentDetails.Count > 0) {
                                using (var context = new AppLazyContext(connString, false)) {
                                    payment.PaymentDetails[0].UpdateTransactions(context, customerId, null, true);
                                }
                            }
                        }

                        foreach (var invoice in lazyContext.Invoice.Where(t1 => t1.Id > 0).OrderBy(t => t.DocumentDate).ToList()) {
                            count++;
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2} | Invoice No {3}", DateTime.Now, count, rowCount, invoice.DocumentNo));

                            if (invoice.InvoiceDetails.Count > 0) {
                                using (var context = new AppLazyContext(connString, false)) {
                                    invoice.InvoiceDetails[0].UpdateTransactions(context, customerId, null, true);
                                }
                            }
                        }

                        foreach (var journal in lazyContext.Journal.Where(t => t.Id > 0).OrderBy(t => t.DocumentDate).ToList()) {
                            count++;
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2} | Journal No {3}", DateTime.Now, count, rowCount, journal.DocumentNo));

                            if (journal.JournalDetails.Count > 0) {
                                using (var context = new AppLazyContext(connString, false)) {
                                    journal.JournalDetails[0].UpdateTransactions(context, customerId, null, true);
                                }
                            }
                        }

                        foreach (var adjustment in lazyContext.Adjustment.Where(t => t.Id > 0).OrderBy(t => t.DocumentDate).ToList()) {
                            count++;
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2} | Adjustment No {3}", DateTime.Now, count, rowCount, adjustment.DocumentNo));

                            using (var context = new AppLazyContext(connString, false)) {
                                adjustment.UpdateTransactions(context, customerId, null, true);
                            }
                        }

                        using (var cmd = new SqlCommand()) {
                            cmd.Connection = con;
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;
                            cmd.CommandText = "update Common.BankAccount set OpeningBalance = isnull((select sum(Amount + Tax) from Accounting.TransactionDetail where JournalDetailId > 0 and ChartOfAccountId = Common.BankAccount.ChartOfAccountId),0)";
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex) {
                isError = true;
                System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: {1}", DateTime.Now, ex.GetErrorMessage()));
                System.Console.WriteLine(string.Format("Stack Trace: {0}", ex.StackTrace));
                System.Console.ReadKey();
            }
            finally {
                var endTime = DateTime.Now;
                System.Console.WriteLine(string.Format(@"{0:dd-MMM-yyyy HH:mm}: {1}. Processing time: {2:hh\:mm\:ss}", endTime, isError ? "Update failed" : "Update completed successfully", endTime.Subtract(startTime)));
            }
        }

        public void UpdateTripLines(int[] tripIds = null) {
            var principal = Utils.GetGenericIdentity(null, "steve@travelog.com.au", "ConsoleApp");

            string connString = Common.GetConnectionString();
            int customerId = Common.GetCustomerId();

            var startTime = DateTime.Now;
            bool isError = false;

            try {
                Common.InitCustomer(principal);

                using (var lazyContext = new AppLazyContext(connString, true)) {
                    var tripLines = lazyContext.TripLine.Include(t => t.Trip).Where(t => t.TripId > 0).OrderBy(t => t.Trip.TripNo).ToList();

                    if (tripIds?.Length > 0)
                        tripLines = tripLines.Where(t => tripIds.Contains(t.TripId)).ToList();

                    int count = 0;
                    int rowCount = tripLines.Count;

                    foreach (var tripLine in tripLines) {
                        count++;
                        System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2} | Trip No {3}", DateTime.Now, count, rowCount, tripLine.Trip.TripNo));

                        using (var context = new AppLazyContext(connString, false)) {
                            context.TripLine.Find(tripLine.Id).Update(principal, customerId, context);
                        }
                    }
                }
            }
            catch (Exception ex) {
                isError = true;
                System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: {1}", DateTime.Now, ex.GetErrorMessage()));
                System.Console.WriteLine(string.Format("Stack Trace: {0}", ex.StackTrace));
                System.Console.ReadKey();
            }
            finally {
                var endTime = DateTime.Now;
                System.Console.WriteLine(string.Format(@"{0:dd-MMM-yyyy HH:mm}: {1}. Processing time: {2:hh\:mm\:ss}", endTime, isError ? "Update failed" : "Update completed successfully", endTime.Subtract(startTime)));
            }
        }

        public void UpdateDebtorReceipts() {
            var principal = Utils.GetGenericIdentity(null, "steve@travelog.com.au", "ConsoleApp");

            Application app = null;
            Database db = null;

            var startTime = DateTime.Now;
            bool isError = false;

            try {
                using (var lazyContext = new AppLazyContext(Common.GetConnectionString(), false)) {
                    System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Updating debtor receipts", DateTime.Now));

                    lazyContext.TransactionDetailAllocation.FromSqlRaw("delete [Accounting].[TransactionDetailAllocation]");
                    lazyContext.TransactionDetailAllocation.FromSqlRaw("dbcc checkident ('Accounting.TransactionDetailAllocation', reseed, 0)");

                    app = new Application();
                    app.OpenCurrentDatabase(@"D:\Documents\Clients\Travelog\Projects\Desktop\DataMapping\DataMapping.accdb");

                    db = app.CurrentDb();
                    db.QueryTimeout = 0;

                    int rowCount = 9;
                    int count = 0;
                    string sql = null;

                    for (int i = 0; i <= 8; i++) {
                        count++;
                        System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing query {1} of {2}", DateTime.Now, count, rowCount));

                        sql = string.Format("insert into Accounting_TransactionDetailAllocation (TransactionDetailId, ReceiptDetailId, PaymentDetailId, InvoiceDetailId, JournalDetailId, AdjustmentId, Amount, MerchantFee, MerchantFeeTax, Reference, TransactionMatchStatusId, LastWriteTime, CreationTime, LastWriteUser, CreationUser) select TransactionDetailId, ReceiptDetailId, PaymentDetailId, InvoiceDetailId, JournalDetailId, AdjustmentId, Amount, MerchantFee, MerchantFeeTax, '', TransactionMatchStatusId, LastWriteTime, CreationTime, LastWriteUser, CreationUser from vw_TransactionDetailAllocation_{0}", i);
                        db.Execute(sql);

                        sql = string.Format("insert into Accounting_TransactionDetailAllocation (TransactionDetailId, ReceiptDetailId, PaymentDetailId, InvoiceDetailId, JournalDetailId, AdjustmentId, Amount, MerchantFee, MerchantFeeTax, Reference, TransactionMatchStatusId, LastWriteTime, CreationTime, LastWriteUser, CreationUser) select TransactionDetailId, ReceiptDetailId, PaymentDetailId, InvoiceDetailId, JournalDetailId, AdjustmentId, Difference, 0, 0, '', 1, LastWriteTime, CreationTime, LastWriteUser, CreationUser from vw_TransactionDetailAllocation_{0} where Difference <> 0", i);
                        db.Execute(sql);
                    }

                    System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Updating merchant fee tax", DateTime.Now));

                    var transactionDetailAllocations = lazyContext.TransactionDetailAllocation.Where(t => t.ReceiptDetailId > 0).ToList();
                    rowCount = transactionDetailAllocations.Count;
                    count = 0;

                    foreach (var allocation in transactionDetailAllocations) {
                        count++;
                        System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2}", DateTime.Now, count, rowCount));

                        var receiptDetail = allocation.ReceiptDetail;
                        var ccChargeAccount = receiptDetail.GetCreditCardChargeAccount(lazyContext);

                        if (ccChargeAccount.IsTaxApplicable) {
                            decimal taxRate = Common.GetTaxRate(principal, receiptDetail.Receipt.DocumentDate);
                            decimal merchantFeeTax = Math.Round(allocation.MerchantFee * taxRate / (1 + taxRate), 2);

                            allocation.MerchantFee -= merchantFeeTax;
                            allocation.MerchantFeeTax = merchantFeeTax;
                            lazyContext.Save(allocation, false);
                        }
                    }

                    System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Updating receipts", DateTime.Now));

                    transactionDetailAllocations = transactionDetailAllocations.Where(t => t.MerchantFee != 0 && t.ReceiptDetail.MerchantFee == 0).ToList();
                    rowCount = transactionDetailAllocations.Count;
                    count = 0;

                    foreach (var allocation in transactionDetailAllocations) {
                        count++;
                        System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2}", DateTime.Now, count, rowCount));

                        var receiptDetail = allocation.ReceiptDetail;

                        receiptDetail.MerchantFee = (receiptDetail.Amount < 0 ? -1 : 1) * Math.Abs(allocation.MerchantFee);
                        receiptDetail.MerchantFeeTax = (receiptDetail.Amount < 0 ? -1 : 1) * Math.Abs(allocation.MerchantFeeTax);
                        lazyContext.Save(receiptDetail, false);
                    }
                }

                UpdateTransactionDetailAllocationReferences();
            }
            catch (Exception ex) {
                isError = true;
                System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: {1}", DateTime.Now, ex.GetErrorMessage()));
                System.Console.WriteLine(string.Format("Stack Trace: {0}", ex.StackTrace));
                System.Console.ReadKey();
            }
            finally {
                var endTime = DateTime.Now;
                System.Console.WriteLine(string.Format(@"{0:dd-MMM-yyyy HH:mm}: {1}. Processing time: {2:hh\:mm\:ss}", endTime, isError ? "Update failed" : "Update completed successfully", endTime.Subtract(startTime)));

                db.Close();
                app.Quit(AcQuitOption.acQuitSaveNone);

                if (app != null) {
                    ReleaseObject(db);
                    ReleaseObject(app);
                }
            }
        }

        public void UpdateInvoiceMatching() {
            var app = new Application();
            app.OpenCurrentDatabase(@"D:\Documents\Clients\Travelog\Projects\Desktop\DataMapping\DataMapping.accdb");

            var db = app.CurrentDb();
            db.QueryTimeout = 0;

            Recordset rst = null;

            try {
                using (var lazyContext = new AppLazyContext(Common.GetConnectionString(), false)) {
                    string sql = string.Format("update Accounting.Invoice set InvoiceLinkId = -1, IsMatched = 0 where (OriginalInvoiceId >= 0 or IsMatched = 1) and CreationUser='{0}'", AppSettings.SystemAccountEmail);
                    lazyContext.Invoice.FromSqlRaw(sql);

                    sql = "vw_InvoiceCreditNote";
                    rst = db.OpenRecordset(sql, 4, dbSeeChanges);

                    for (int i = 0; i < rst.RecordCount; i++) {
                        string invoiceNo = rst.Fields[0].Value.ToString();
                        string creditNoteNo = rst.Fields[1].Value.ToString();

                        var invoice = lazyContext.Invoice.Single(t => t.DocumentNo == invoiceNo);
                        var creditNote = lazyContext.Invoice.Single(t => t.DocumentNo == creditNoteNo);

                        invoice.InvoiceLinkId = creditNote.Id;
                        invoice.IsMatched = true;
                        lazyContext.Save(invoice, false);

                        creditNote.InvoiceLinkId = invoice.Id;
                        creditNote.IsMatched = true;
                        lazyContext.Save(creditNote, false);
                    }

                    rst.Close();

                    foreach (var invoice in lazyContext.Invoice.Where(t1 => t1.Id > 0 && !t1.IsMatched && t1.CreationUser == AppSettings.SystemAccountEmail && (t1.InvoiceDetails.Sum(t2 => (decimal?)(t2.Amount + t2.Tax - t2.Discount)) ?? 0) == 0).ToList()) {
                        invoice.IsMatched = true;
                        lazyContext.Save(invoice, false);
                    }
                }
            }
            catch (Exception ex) {
                System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: {1}", DateTime.Now, ex.GetErrorMessage()));
                System.Console.WriteLine(string.Format("Stack Trace: {0}", ex.StackTrace));
            }
            finally {
                db?.Close();

                if (app != null) {
                    app.CloseCurrentDatabase();
                    app.Quit(AcQuitOption.acQuitSaveNone);
                    ReleaseObject(rst);
                    ReleaseObject(db);
                    ReleaseObject(app);
                }
            }
        }

        public void InsertTransactionDetailAllocations() {
            var app = new Application();
            app.OpenCurrentDatabase(@"D:\Documents\Clients\Travelog\Projects\Desktop\DataMapping\DataMapping.accdb");

            var db = app.CurrentDb();
            db.QueryTimeout = 0;

            Recordset rst = null;

            var startTime = DateTime.Now;
            bool isError = false;

            try {
                using (var lazyContext = new AppLazyContext(Common.GetConnectionString(), false)) {
                    System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Inserting transaction detail allocations", DateTime.Now));

                    using (var con = new SqlConnection(Common.GetConnectionString())) {
                        con.Open();

                        using (var cmd = new SqlCommand()) {
                            cmd.Connection = con;
                            cmd.CommandType = CommandType.Text;
                            cmd.CommandTimeout = 0;

                            cmd.CommandText = "delete Accounting.TransactionDetailAllocation";
                            cmd.ExecuteNonQuery();

                            cmd.CommandText = "dbcc checkident ('Accounting.TransactionDetailAllocation', reseed, 0)";
                            cmd.ExecuteNonQuery();

                            Debtor debtor = null;
                            Creditor creditor = null;

                            for (int i = 0; i < 2; i++) {
                                List<object> entityList;

                                if (i == 0) {
                                    entityList = lazyContext.TransactionDetail.Where(t => t.LedgerType == LedgerType.DebtorLedger && (t.TransactionDetailType == TransactionDetailType.Normal || t.TransactionDetailType == TransactionDetailType.ExcludeFromSalesAnalysis)).Where(t => t.DebtorId > 0).Select(t => t.Debtor).Distinct().ToList<object>();
                                }
                                else {
                                    entityList = lazyContext.TransactionDetail.Where(t => t.LedgerType == LedgerType.CreditorLedger && (t.TransactionDetailType == TransactionDetailType.Normal || t.TransactionDetailType == TransactionDetailType.ExcludeFromSalesAnalysis)).Where(t => t.CreditorId > 0).Select(t => t.Creditor).Distinct().ToList<object>();
                                }

                                int count1 = 0;
                                int rowCount1 = entityList.Count;

                                foreach (var entity in entityList) {
                                    System.Console.WriteLine();
                                    count1++;

                                    string sql;

                                    if (i == 0) {
                                        debtor = entity as Debtor;
                                        System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2}: Debtor {3}", DateTime.Now, count1, rowCount1, debtor.Name));
                                        sql = string.Format("select vw_TransactionDetailAllocation_1.* from vw_TransactionDetailAllocation_1 where DebtorId={0}", debtor.Id);
                                    }
                                    else {
                                        creditor = entity as Creditor;
                                        System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2}: Creditor {3}", DateTime.Now, count1, rowCount1, creditor.Name));
                                        sql = string.Format("select vw_TransactionDetailAllocation_2.* from vw_TransactionDetailAllocation_2 where CreditorId={0}", creditor.Id);
                                    }

                                    rst = db.OpenRecordset(sql, 4, dbSeeChanges);

                                    if (!rst.EOF) {
                                        rst.MoveLast();
                                        rst.MoveFirst();
                                    }

                                    int count2 = 0;
                                    int rowCount2 = rst.RecordCount;

                                    while (!rst.EOF) {
                                        count2++;
                                        System.Console.Write(string.Format("\r{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2}", DateTime.Now, count2, rowCount2));

                                        int receiptDetailId = int.Parse(rst.Fields["ReceiptDetailId"].Value.ToString());
                                        int nonBspDetailId = int.Parse(rst.Fields["NonBspDetailId"].Value.ToString());
                                        int paymentDetailId = int.Parse(rst.Fields["PaymentDetailId"].Value.ToString());
                                        int invoiceDetailId = int.Parse(rst.Fields["InvoiceDetailId"].Value.ToString());
                                        int journalDetailId = int.Parse(rst.Fields["JournalDetailId"].Value.ToString());
                                        int adjustmentId = int.Parse(rst.Fields["AdjustmentId"].Value.ToString());

                                        int transactionTypeId = int.Parse(rst.Fields["TransactionTypeId"].Value.ToString());
                                        int groupNo = int.Parse(rst.Fields["GroupNo"].Value.ToString());
                                        decimal amount = decimal.Parse(rst.Fields["Amount"].Value.ToString());

                                        IQueryable<TransactionDetail> transactionDetails;

                                        if (i == 0) {
                                            transactionDetails = lazyContext.TransactionDetail.Where(t => t.LedgerType == LedgerType.DebtorLedger && t.DebtorId == debtor.Id && (t.TransactionDetailType == TransactionDetailType.Normal || t.TransactionDetailType == TransactionDetailType.ExcludeFromSalesAnalysis));
                                        }
                                        else {
                                            transactionDetails = lazyContext.TransactionDetail.Where(t => t.LedgerType == LedgerType.CreditorLedger && t.CreditorId == creditor.Id && (t.TransactionDetailType == TransactionDetailType.Normal || t.TransactionDetailType == TransactionDetailType.ExcludeFromSalesAnalysis));
                                        }

                                        switch (transactionTypeId) {
                                            case 1:
                                                transactionDetails = transactionDetails.Where(t => t.ReceiptDetailId == receiptDetailId);
                                                break;
                                            case 3:
                                                transactionDetails = transactionDetails.Where(t => t.NonBspDetailId == nonBspDetailId);
                                                break;
                                            case 4:
                                                transactionDetails = transactionDetails.Where(t => t.PaymentDetailId == paymentDetailId);
                                                break;
                                            case 5:
                                                transactionDetails = transactionDetails.Where(t => t.InvoiceDetailId == invoiceDetailId);
                                                break;
                                            case 6:
                                                transactionDetails = transactionDetails.Where(t => t.JournalDetailId == journalDetailId);
                                                break;
                                            case 8:
                                                transactionDetails = transactionDetails.Where(t => t.Transaction.AdjustmentId == adjustmentId);
                                                break;
                                        }

                                        var transactionDetail = transactionDetails.SingleOrDefault();

                                        if (transactionDetail != null) {
                                            cmd.CommandText = string.Format(@"insert into Accounting.TransactionDetailAllocation (TransactionDetailId, ReceiptDetailId, NonBspDetailId, PaymentDetailId, InvoiceDetailId, JournalDetailId, AdjustmentId, Amount, MerchantFee, MerchantFeeTax, Reference, TransactionMatchStatusId, GroupNo, LastWriteTime, CreationTime, LastWriteUser, CreationUser)
                                            values ({0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, 0, 0, '', 2, {8}, getutcdate(), getutcdate(), 'system@travelog.online', 'system@travelog.online')", transactionDetail.Id, receiptDetailId, nonBspDetailId, paymentDetailId, invoiceDetailId, journalDetailId, adjustmentId, amount, groupNo);

                                            cmd.ExecuteNonQuery();
                                        }

                                        rst.MoveNext();
                                    }

                                    rst.Close();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) {
                isError = true;
                System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: {1}", DateTime.Now, ex.GetErrorMessage()));
                System.Console.WriteLine(string.Format("Stack Trace: {0}", ex.StackTrace));
                System.Console.ReadKey();
            }
            finally {
                var endTime = DateTime.Now;
                System.Console.WriteLine(string.Format(@"{0:dd-MMM-yyyy HH:mm}: {1}. Processing time: {2:hh\:mm\:ss}", endTime, isError ? "Update failed" : "Update completed successfully", endTime.Subtract(startTime)));

                db?.Close();

                if (app != null) {
                    app.CloseCurrentDatabase();
                    app.Quit(AcQuitOption.acQuitSaveNone);
                    ReleaseObject(rst);
                    ReleaseObject(db);
                    ReleaseObject(app);
                }

                if (!isError)
                    UpdateTransactionDetailAllocationReferences();
            }
        }

        public void UpdateTransactionDetailAllocationReferences() {
            var startTime = DateTime.Now;
            bool isError = false;

            try {
                using (var lazyContext = new AppLazyContext(Common.GetConnectionString(), false)) {
                    System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Updating transaction detail allocation references", DateTime.Now));

                    var transactionDetailAllocations = lazyContext.TransactionDetailAllocation.ToList();

                    int count = 0;
                    int rowCount = transactionDetailAllocations.Count;

                    foreach (var allocation in transactionDetailAllocations) {
                        count++;
                        System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Processing row {1} of {2}", DateTime.Now, count, rowCount));

                        int masterDocumentId = 0;

                        switch (allocation.TransactionType) {
                            case TransactionType.Receipt:
                                masterDocumentId = allocation.ReceiptDetailId;
                                break;
                            case TransactionType.NonBsp:
                                masterDocumentId = allocation.NonBspDetailId;
                                break;
                            case TransactionType.Payment:
                                masterDocumentId = allocation.PaymentDetailId;
                                break;
                            case TransactionType.Invoice:
                            case TransactionType.CreditNote:
                                masterDocumentId = allocation.InvoiceDetailId;
                                break;
                            case TransactionType.Journal:
                                masterDocumentId = allocation.JournalDetailId;
                                break;
                            case TransactionType.Adjustment:
                                masterDocumentId = allocation.AdjustmentId;
                                break;
                        }

                        allocation.UpdateReference(transactionDetailAllocations, masterDocumentId);
                        lazyContext.Save(allocation, false);
                    }
                }
            }
            catch (Exception ex) {
                isError = true;
                System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: {1}", DateTime.Now, ex.GetErrorMessage()));
                System.Console.WriteLine(string.Format("Stack Trace: {0}", ex.StackTrace));
                System.Console.ReadKey();
            }
            finally {
                var endTime = DateTime.Now;
                System.Console.WriteLine(string.Format(@"{0:dd-MMM-yyyy HH:mm}: {1}. Processing time: {2:hh\:mm\:ss}", endTime, isError ? "Update failed" : "Update completed successfully", endTime.Subtract(startTime)));
            }
        }

        public void UpdateAmountsPayable(bool calculateTax) {
            var principal = Utils.GetGenericIdentity(null, "steve@travelog.com.au", "ConsoleApp");
            string connString = Common.GetConnectionString();

            var startTime = DateTime.Now;
            bool isError = false;

            decimal amountPayable = 0;
            decimal amountPayableTax = 0;
            decimal taxRate = 0;

            try {
                using (var lazyContext = new AppLazyContext(connString, false)) {
                    System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Updating BSP Amount Payable", DateTime.Now));

                    foreach (var bsp in lazyContext.Bsp.Where(t => t.Id > 0).ToList()) {
                        amountPayable = bsp.GetAmountPayable(lazyContext);
                        amountPayableTax = 0;

                        if (amountPayable != bsp.AmountPayable) {
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Updating BSP No {1}", DateTime.Now, bsp.DocumentNo));
                            bsp.AmountPayable = amountPayable;
                            lazyContext.Save(bsp, false);
                        }
                    }

                    System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Updating Non-BSP Amount Payable", DateTime.Now));

                    foreach (var nonBsp in lazyContext.NonBsp.Where(t => t.Id > 0).ToList()) {
                        amountPayable = nonBsp.GetAmountPayable(lazyContext);
                        amountPayableTax = 0;

                        if (amountPayable != nonBsp.AmountPayable) {
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Updating Non-BSP No {1}", DateTime.Now, nonBsp.DocumentNo));
                            nonBsp.AmountPayable = amountPayable;
                            lazyContext.Save(nonBsp, false);
                        }
                    }

                    System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Updating Payment Amount Payable", DateTime.Now));

                    foreach (var payment in lazyContext.Payment.Where(t => t.Id > 0).ToList()) {
                        amountPayable = payment.GetAmountPayable(lazyContext);
                        amountPayableTax = 0;

                        if (payment.IsTaxApplicable && payment.PaymentType != PaymentType.BspReturn && payment.PaymentType != PaymentType.NonBspReturn) {
                            if (calculateTax) {
                                taxRate = Common.GetTaxRate(principal, payment.DocumentDate);
                                amountPayableTax = Math.Round(amountPayable * taxRate / (1 + taxRate), 2);
                                amountPayable -= amountPayableTax;
                            }
                            else {
                                amountPayableTax = payment.GetAmountPayableTax();
                            }
                        }

                        if (amountPayable != payment.AmountPayable || amountPayableTax != payment.AmountPayableTax) {
                            System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: Updating Payment No {1}", DateTime.Now, payment.DocumentNo));
                            payment.AmountPayable = amountPayable;
                            payment.AmountPayableTax = amountPayableTax;
                            lazyContext.Save(payment, false);
                        }
                    }
                }
            }
            catch (Exception ex) {
                isError = true;
                System.Console.WriteLine(string.Format("{0:dd-MMM-yyyy HH:mm}: {1}", DateTime.Now, ex.GetErrorMessage()));
                System.Console.WriteLine(string.Format("Stack Trace: {0}", ex.StackTrace));
                System.Console.ReadKey();
            }
            finally {
                var endTime = DateTime.Now;
                System.Console.WriteLine(string.Format(@"{0:dd-MMM-yyyy HH:mm}: {1}. Processing time: {2:hh\:mm\:ss}", endTime, isError ? "Update failed" : "Update completed successfully", endTime.Subtract(startTime)));
            }
        }

        public void UpdateExchangeRates() {
            ExchangeRate.UpdateExchangeRates();
        }

        private void ReleaseObject(object obj) {
            try {
                if (obj != null)
                    Marshal.ReleaseComObject(obj);
            }
            catch {
            }
            finally {
                GC.Collect();
            }
        }
    }
}