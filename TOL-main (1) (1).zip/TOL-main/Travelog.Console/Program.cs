﻿namespace Travelog.Console {
    internal static class Program {
        private static void Main() {
            System.Console.WriteLine("1: Export data.");
            System.Console.WriteLine("2: Update ledger transactions.");
            System.Console.WriteLine("3: Insert transaction detail allocations.");
            System.Console.WriteLine("4: Update transaction detail allocation references.");
            System.Console.WriteLine("5: Update trip lines.");
            System.Console.WriteLine("6: Update debtor receipts.");
            System.Console.WriteLine("7: Update invoice matching.");
            System.Console.WriteLine("8: Update exchange rates.");
            System.Console.WriteLine("9: Restore table indexes.");
            System.Console.WriteLine("0: Update minimum dates.");
            System.Console.WriteLine("Press any other key to exit application.");

            var keyInfo = System.Console.ReadKey();
            System.Console.WriteLine();

            switch (keyInfo.KeyChar) {
                default:
                    Environment.Exit(-1);
                    break;
                case '1':
                    new ExportData().Export();
                    break;
                case '2':
                    new Transactions().Update(true);
                    break;
                case '3':
                    new Transactions().InsertTransactionDetailAllocations();
                    break;
                case '4':
                    new Transactions().UpdateTransactionDetailAllocationReferences();
                    break;
                case '5':
                    new Transactions().UpdateTripLines();
                    break;
                case '6':
                    new Transactions().UpdateDebtorReceipts();
                    break;
                case '7':
                    new Transactions().UpdateInvoiceMatching();
                    break;
                case '8':
                    new Transactions().UpdateExchangeRates();
                    break;
                case '9':
                    new ExportData().RestoreTableIndexes();
                    break;
                case '0':
                    new ExportData().UpdateMinDates();
                    break;
            }

            System.Console.WriteLine("Press any key to exit application.");
            System.Console.ReadKey();
        }
    }
}