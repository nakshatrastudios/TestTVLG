using System.Diagnostics;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Hosting;
using Softwarehelden.Transactions.Oletx;

namespace Travelog.WebApp {
	public static class Program {
		public static void Main(string[] args) {
            //EnableTracing();
            OletxPatcher.Patch();
			MsSqlPatcher.Patch(typeof(SqlConnection).Assembly);
            CreateHostBuilder(args).Build().Run();
		}

        private static void EnableTracing() {
            Trace.Listeners.Add(new TextWriterTraceListener(Path.Combine("App_Data", "trace.log")));
            Trace.AutoFlush = true;
        }

        public static IHostBuilder CreateHostBuilder(string[] args) => Host.CreateDefaultBuilder(args)
			.ConfigureWebHostDefaults(webBuilder => webBuilder.UseContentRoot(Directory.GetCurrentDirectory()).UseIISIntegration().UseStartup<Startup>());
	}
}