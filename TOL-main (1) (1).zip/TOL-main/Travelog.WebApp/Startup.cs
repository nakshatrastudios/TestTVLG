using System;
using System.IO;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Rewrite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json.Serialization;
using Telerik.Reporting.Cache;
using Telerik.Reporting.Services;
using Travelog.Biz;
using Travelog.Biz.Enums;
using Travelog.WebApp.Controllers;

namespace Travelog.WebApp {
    public class Startup {
		public IConfiguration Configuration { get; }

		public Startup(IConfiguration configuration) {
			Configuration = configuration;
            AppSettings.Initialize(configuration);
        }

        public void ConfigureServices(IServiceCollection services) {
			services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("travelogonline-admin")));
			services.AddHttpContextAccessor();

			services.AddDistributedSqlServerCache(options => {
				options.ConnectionString = Configuration.GetConnectionString("travelogonline-admin");
				options.SchemaName = "dbo";
				options.TableName = "SessionState";
				options.DefaultSlidingExpiration = TimeSpan.FromHours(2);
			});

            services.AddSession(options => {
				options.IdleTimeout = TimeSpan.FromHours(2);
                options.Cookie.Name = "TravelogOnline.Session";
                options.Cookie.IsEssential = false;
			});

            services.AddIdentity<ApplicationUser, IdentityRole>(options => {
				options.User.RequireUniqueEmail = true;
				options.SignIn.RequireConfirmedAccount = true;
				options.Password.RequiredLength = 8;
				options.Password.RequireLowercase = true;
				options.Password.RequireUppercase = true;
                options.Password.RequireDigit = true;
                options.Password.RequireNonAlphanumeric = true;
                options.Lockout.MaxFailedAccessAttempts = 5;
				options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromDays(1);
			}).AddRoles<IdentityRole>()
				.AddEntityFrameworkStores<ApplicationDbContext>()
				.AddClaimsPrincipalFactory<AppUserClaimsPrincipalFactory>()
				.AddDefaultTokenProviders();

			services.ConfigureApplicationCookie(options => {
				options.LoginPath = AppSettings.SignInPage;
				options.LogoutPath = AppSettings.SignOutPage;
				options.AccessDeniedPath = AppSettings.NotAuthorisedPage;
				options.ExpireTimeSpan = TimeSpan.FromHours(1);
				options.SlidingExpiration = true;

				options.Events = new CookieAuthenticationEvents {
					OnRedirectToLogin = context => {
                        if (context.Request.HttpContext.User.Identity.Name == null && context.Request.GetTypedHeaders().Referer != null && context.Request.HttpContext.SessionExpiryStatus().Result != SessionExpiryStatus.ExpiredNotified) {
                            context.Request.HttpContext.NavNext(context.Request.GetTypedHeaders().Referer.AbsolutePath);
                            context.Request.HttpContext.SessionExpiryStatus(SessionExpiryStatus.ExpiredNotNotified).Wait();
                        }

                        if (WebUtils.IsAjaxRequest(context.Request)) {
							context.Response.StatusCode = 999;
						}
						else {
							context.Response.Redirect(context.RedirectUri);
						}

						return Task.CompletedTask;
					}
				};
			});

			services.AddScoped<AppFilter>();

            services.AddMvc(options => {
				options.Filters.AddService(typeof(AppFilter));
				options.ModelBinderProviders.Insert(0, new ModelBinderProvider());
			});

            services.AddControllers().AddNewtonsoftJson(options => {
                options.SerializerSettings.ContractResolver = new DefaultContractResolver();
                //options.SerializerSettings.DateFormatString = "dd-MMM-yyyy HH:mm";
            });

            services.AddControllersWithViews().AddRazorRuntimeCompilation().AddJsonOptions(options => {
                options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
                options.JsonSerializerOptions.AllowTrailingCommas = true;
                options.JsonSerializerOptions.NumberHandling = JsonNumberHandling.AllowReadingFromString;
                options.JsonSerializerOptions.PropertyNamingPolicy = null;
                options.JsonSerializerOptions.Converters.Add(new DateTimeConverter());
            });

            services.AddRazorPages();
			services.AddKendo();

            services.AddSingleton(controller => new BaseController(controller.GetRequiredService<SignInManager<ApplicationUser>>(), controller.GetRequiredService<UserManager<ApplicationUser>>(), controller.GetRequiredService<IWebHostEnvironment>(), controller.GetRequiredService<IDistributedCache>()));

            services.TryAddSingleton<IReportServiceConfiguration>(configuration =>
                new ReportServiceConfiguration {
                    HostAppId = "Reports",
                    ReportingEngineConfiguration = new ConfigurationBuilder().AddJsonFile(Path.Combine(configuration.GetService<IWebHostEnvironment>().ContentRootPath, "appsettings.json"), true).Build(),
                    ReportSourceResolver = new UriReportSourceResolver(Path.Combine(configuration.GetService<IWebHostEnvironment>().ContentRootPath, "App_Data")).AddFallbackResolver(new TypeReportSourceResolver()),
                    Storage = new MsSqlServerStorage(Configuration.GetConnectionString("travelogonline-reporting"))
                }
            );
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env) {
            app.UseSession();

            app.UseRewriter(new RewriteOptions().AddRedirectToNonWwwPermanent().AddRedirectToHttpsPermanent());
            app.UseExceptionHandler(AppSettings.ErrorPage);

            app.UseHsts();
            app.UseRobotsTxt();

            if (env.IsProduction()) {
				app.UseStaticFiles();
			}
			else {
				app.UseStaticFiles("/wwwroot");
			}

			app.UseCookiePolicy();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseEndpoints(endpoints => endpoints.RegisterRoutes());

            app.Use(async (httpContext, next) => {
                await next();

                if (!httpContext.Response.HasStarted) {
                    if (httpContext.Response.StatusCode == 400) {
                        httpContext.Response.Redirect(AppSettings.NotAuthorisedPage);
                    }
                    else if (httpContext.Response.StatusCode == 404) {
                        httpContext.Response.Redirect(AppSettings.ResourceNotFoundPage);
                    }
                    else if (httpContext.Response.StatusCode >= 500 && httpContext.Response.StatusCode <= 503) {
                        httpContext.Response.Redirect(AppSettings.ErrorPage);
                    }
                }
            });
        }
    }
}