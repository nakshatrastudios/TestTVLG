﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Travelog.Biz;

namespace Travelog.WebApp {
    public class ServiceDesk {
        public async Task<string> CreateJiraRequest(string reporterName, string reporterEmail, string summary, string description, string imageContent, IEnumerable<IFormFile> files) {
            string accountId = await GetJiraCustomerAccountId(reporterEmail);

            if (string.IsNullOrEmpty(accountId))
                accountId = await CreateJiraCustomerAccount(reporterName, reporterEmail);

            int i = 0;

            while (string.IsNullOrEmpty(accountId) && i <= 60) {
                i++;
                Thread.Sleep(1000);
                accountId = await GetJiraCustomerAccountId(reporterEmail);
            }

            if (string.IsNullOrEmpty(accountId))
                throw new UnreportedException("Customer account could not be created.");

            string url = string.Format("{0}/request", AppSettings.JiraServiceDeskUrl);
            string issueKey = string.Empty;
            string credentials = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Format("{0}:{1}", AppSettings.JiraUserName, AppSettings.JiraApiToken)));

            using (var httpClient = new HttpClient { BaseAddress = new Uri(url) }) {
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8");

                var request = new Request {
                    serviceDeskId = "2",
                    requestTypeId = "23",
                    raiseOnBehalfOf = accountId,
                    requestParticipants = new string[] { accountId },
                };

                request.requestFieldValues.summary = summary;
                request.requestFieldValues.description = description;

                var jsonFormatter = new JsonMediaTypeFormatter();
                var content = new ObjectContent<Request>(request, jsonFormatter);

                using (var response = await httpClient.PostAsync("request", content)) {
                    if (response.IsSuccessStatusCode) {
                        dynamic result = JsonNode.Parse(await response.Content.ReadAsStringAsync());
                        issueKey = ((JsonObject)result)["issueKey"].ToStringExt();
                        await AddJiraAttachments(httpClient, issueKey, imageContent, files);
                    }
                    else {
                        string result = await response.Content.ReadAsStringAsync();
                        throw new InvalidOperationException(string.Format(@"Request failed with Status Code ""{0}"".{1}", response.StatusCode, string.IsNullOrEmpty(result) ? string.Empty : string.Format("{0}Errors: {1}.", Environment.NewLine, result)));
                    }
                }
            }

            return issueKey;
        }

        private static async Task AddJiraAttachments(HttpClient httpClient, string issueKey, string imageContent, IEnumerable<IFormFile> files) {
            if (string.IsNullOrEmpty(imageContent) && !(files?.Any() ?? false))
                return;

            httpClient.DefaultRequestHeaders.Add("X-Atlassian-Token", "no-check");

            using (var request = new HttpRequestMessage(HttpMethod.Post, string.Format("{0}/{1}/attachments", AppSettings.JiraIssueUrl, issueKey))) {
                ByteArrayContent screenshotContent = null;
                ByteArrayContent fileContent = null;
                string fileName = null;

                if (!string.IsNullOrEmpty(imageContent)) {
                    imageContent = imageContent.Replace("data:image/png;base64,", string.Empty);
                    byte[] bytes = Convert.FromBase64String(imageContent);
                    screenshotContent = new ByteArrayContent(bytes);
                    screenshotContent.Headers.Add("Content-Type", "image/png");
                }

                if (files?.Any() ?? false) {
                    var file = files.Single();

                    fileContent = new ByteArrayContent(file.OpenReadStream().StreamToBytes());
                    fileContent.Headers.Add("Content-Type", file.ContentType);

                    fileName = file.FileName.ToLower() == "screenshot.png" && !string.IsNullOrEmpty(imageContent) ? "screenshot2.png" : file.FileName;
                }

                if (screenshotContent != null && fileContent != null) {
                    request.Content = new MultipartFormDataContent("----MyGreatBoundary") {
                        { fileContent, "file", fileName },
                        { screenshotContent, "file", "screenshot.png" }
                    };
                }
                else if (screenshotContent != null) {
                    request.Content = new MultipartFormDataContent("----MyGreatBoundary") {
                        { screenshotContent, "file", "screenshot.png" }
                    };
                }
                else if (fileContent != null) {
                    request.Content = new MultipartFormDataContent("----MyGreatBoundary") {
                        { fileContent, "file", fileName }
                    };
                }

                await httpClient.SendAsync(request, HttpCompletionOption.ResponseContentRead, CancellationToken.None);
            }
        }

        private static async Task<string> GetJiraCustomerAccountId(string reporterEmail) {
            string credentials = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Format("{0}:{1}", AppSettings.JiraUserName, AppSettings.JiraApiToken)));
            string url = string.Format("{0}/servicedesk/TO/customer", AppSettings.JiraServiceDeskUrl);

            using (var httpClient = new HttpClient { BaseAddress = new Uri(url) }) {
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8");
                httpClient.DefaultRequestHeaders.Add("X-ExperimentalApi", "true");

                using (var request = new HttpRequestMessage(HttpMethod.Get, string.Format("?query={0}&limit=1", reporterEmail))) {
                    request.Headers.Authorization = new AuthenticationHeaderValue("Basic", credentials);

                    var json = await httpClient.SendAsync(request, HttpCompletionOption.ResponseContentRead, CancellationToken.None);
                    dynamic result = JsonNode.Parse(await json.Content.ReadAsStringAsync());

                    return ((JsonObject)result)["values"][0]["accountId"].ToStringExt();
                }
            }
        }

        private static async Task<string> CreateJiraCustomerAccount(string reporterName, string reporterEmail) {
            string credentials = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Format("{0}:{1}", AppSettings.JiraUserName, AppSettings.JiraApiToken)));
            string url = string.Format("{0}/customer", AppSettings.JiraServiceDeskUrl);

            using (var httpClient = new HttpClient { BaseAddress = new Uri(url) }) {
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8");

                var customer = new CustomerAdd {
                    displayName = reporterName,
                    email = reporterEmail
                };

                var jsonFormatter = new JsonMediaTypeFormatter();
                var content = new ObjectContent<CustomerAdd>(customer, jsonFormatter);

                using (var response = await httpClient.PostAsync("customer", content)) {
                    if (response.IsSuccessStatusCode) {
                        dynamic result = JsonNode.Parse(await response.Content.ReadAsStringAsync());

                        using (var request = new HttpRequestMessage(HttpMethod.Post, string.Format("{0}", url))) {
                            await httpClient.SendAsync(request, HttpCompletionOption.ResponseContentRead, CancellationToken.None);
                            return await GetJiraCustomerAccountId(reporterEmail);
                        }
                    }
                    else {
                        string result = await response.Content.ReadAsStringAsync();
                        throw new InvalidOperationException(string.Format(@"Request failed with Status Code ""{0}"".{1}", response.StatusCode, string.IsNullOrEmpty(result) ? string.Empty : string.Format("{0}Errors: {1}.", Environment.NewLine, result)));
                    }
                }
            }
        }

        public async Task DeleteJiraCustomerAccount(string reporterEmail) {
            string credentials = Convert.ToBase64String(Encoding.UTF8.GetBytes(string.Format("{0}:{1}", AppSettings.JiraUserName, AppSettings.JiraApiToken)));
            string url = string.Format("{0}/servicedesk/TO/customer", AppSettings.JiraServiceDeskUrl);

            string accountId = await GetJiraCustomerAccountId(reporterEmail);

            if (string.IsNullOrEmpty(accountId))
                throw new UnreportedException("Account not found.");

            using (var httpClient = new HttpClient()) {
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8");
                httpClient.DefaultRequestHeaders.Add("X-ExperimentalApi", "true");

                var customer = new CustomerDelete {
                    accountIds = new string[] { accountId }
                };

                var jsonFormatter = new JsonMediaTypeFormatter();
                var content = new ObjectContent<CustomerDelete>(customer, jsonFormatter);

                using (var request = new HttpRequestMessage(HttpMethod.Delete, url)) {
                    var json = await httpClient.SendAsync(request, HttpCompletionOption.ResponseContentRead, CancellationToken.None);
                    string result = JsonNode.Parse(await json.Content.ReadAsStringAsync()).ToStringExt();

                    if (result.Contains("errorMessage", StringComparison.OrdinalIgnoreCase)) {
                        string[] message = result.Substring(result.IndexOf("errorMessage") + 14).Split('"');

                        if (message.Length > 1 && message[1].Length > 0) {
                            if (message[1].Contains("the following users could not be found", StringComparison.OrdinalIgnoreCase))
                                message[1] = "Account not found";

                            throw new UnreportedException(string.Format("{0}.", message[1]));
                        }
                    }
                }
            }
        }

        private class CustomerAdd {
            public string displayName { get; set; }
            public string email { get; set; }
        }

        private class CustomerDelete {
            public string[] accountIds { get; set; }
        }

        private class Request {
            public Request() {
                requestFieldValues = new RequestFieldValues();
            }

            public string[] requestParticipants { get; set; }
            public string serviceDeskId { get; set; }
            public string requestTypeId { get; set; }
            public string raiseOnBehalfOf { get; set; }
            public RequestFieldValues requestFieldValues { get; set; }
        }

        private class RequestFieldValues {
            public string summary { get; set; }
            public string description { get; set; }
        }
    }
}