﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Dao.DebtorLedger;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Dao.StaticMethods;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;
using Travelog.Biz.Resources;
using Travelog.Ledger.Accounting;
using Travelog.Ledger.Models;
using Travelog.PaymentGateway;
using Travelog.PaymentGateway.Enums;
using Travelog.Reports.Accounting;
using Travelog.WebApp.Admin;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.Accounting {
    public class RateModel {
        public decimal Commission { get; set; }
        public decimal CommissionRate { get; set; }
        public decimal CommissionTax { get; set; }
        public decimal CommissionTaxRate { get; internal set; }
        public decimal Discount { get; set; }
        public decimal DiscountRate { get; set; }
        public decimal DiscountTax { get; set; }
        public decimal DiscountTaxRate { get; internal set; }
        public decimal Markup { get; set; }
        public decimal MarkupRate { get; set; }
        public decimal MarkupTax { get; set; }
        public decimal MarkupTaxRate { get; internal set; }
        public decimal Amount { get; internal set; }
        public decimal Tax { get; internal set; }
        public decimal TaxRate { get; internal set; }
        public decimal DocumentAmount { get; internal set; }
        public decimal DocumentTax { get; internal set; }
        public bool IsTaxIncluded { get; set; }
        public bool IsFormBinding { get; set; }
        public bool IsTaxApplicableOverride { get; set; }
        public decimal CommissionGross { get { return IsTaxIncluded ? Commission + CommissionTax : Commission; } }
        public decimal DiscountGross { get { return IsTaxIncluded ? Discount + DiscountTax : Discount; } }
        public decimal MarkupGross { get { return IsTaxIncluded ? Markup + MarkupTax : Markup; } }
        public decimal AmountGross { get { return IsTaxIncluded ? Amount + Tax : Amount; } }
        public decimal DocumentAmountGross { get { return IsTaxIncluded ? DocumentAmount + DocumentTax : DocumentAmount; } }

        private decimal nonCommissionableGross;
        public decimal NonCommissionableGross {
            get {
                return IsTaxIncluded ? nonCommissionableGross : NonCommissionable;
            }
            set {
                nonCommissionableGross = value;
            }
        }

        public decimal NonCommissionable {
            get {
                return nonCommissionableGross - NonCommissionableTax;
            }
        }

        public decimal NonCommissionableTax {
            get {
                if (nonCommissionableGross > 0 && TaxRate > 0)
                    return Math.Round(nonCommissionableGross * TaxRate / (1 + TaxRate), 2);

                return 0;
            }
        }
    }

    public class AccountingRates<TEntity> where TEntity : class {
        private HttpContext HttpContext { get; }
        private readonly TEntity Entity;

        private RateModel RateModel { get; }

        private readonly List<string> PermittedSourceFields = new() {
            "Commission",
            "CommissionTax",
            "CommissionRate",
            "Discount",
            "DiscountTax",
            "DiscountRate",
            "Markup",
            "MarkupTax",
            "MarkupRate",
            "Amount",
            "Tax",
            "IsTaxApplicable",
            "CreditorId",
            "SupplierId",
            "ChartOfAccountId",
            "SaleTypeId",
            "TripLineId",
            "TripLineAirPassengerId"
        };

        public AccountingRates(HttpContext httpContext, TEntity entity, RateModel rateModel) {
            HttpContext = httpContext;
            Entity = entity;
            RateModel = rateModel;
        }

        public bool SetRates(List<string> sourceFields, decimal unsavedAmount = 0, decimal unsavedTax = 0, int detailId = 0) {
            sourceFields = sourceFields.Where(t => PermittedSourceFields.Contains(t)).ToList();

            if (sourceFields.Count == 0)
                return false;

            if (sourceFields.Contains("Amount") && unsavedAmount == 0)
                unsavedTax = 0;

            DateTime documentDate = DateTime.MinValue;
            bool isTaxApplicable = false;
            bool isCommissionTaxUpdateable = false;
            bool isTaxUpdateable = false;
            decimal commissionRate = 0;

            RateModel.Amount = 0;
            RateModel.Tax = 0;

            dynamic entity = Entity;

            if (Entity.GetType() == typeof(Receipt) || Entity.GetType() == typeof(Receipt) || Entity.GetType().BaseType == typeof(Receipt)) {
                documentDate = entity.DocumentDate;
                isTaxApplicable = entity.IsTaxApplicable;
                commissionRate = entity.CommissionRateBySupplierCreditorSaleType;
                isCommissionTaxUpdateable = true;
                isTaxUpdateable = true;

                if (Entity.GetType() == typeof(Receipt)) {
                    var q = (entity as Receipt).ReceiptDetails.Where(t => t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
                else {
                    var q = (entity as Receipt).ReceiptDetails.Where(t => t.Id > 0 && t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
            }
            else if (Entity.GetType() == typeof(ReceiptDetail) || Entity.GetType() == typeof(ReceiptDetail) || Entity.GetType().BaseType == typeof(ReceiptDetail)) {
                documentDate = entity.Receipt.DocumentDate;
                isTaxApplicable = RateModel.IsTaxApplicableOverride;
                isCommissionTaxUpdateable = true;
                isTaxUpdateable = true;

                if (Entity.GetType() == typeof(ReceiptDetail)) {
                    var q = (entity as ReceiptDetail).Receipt.ReceiptDetails.Where(t => t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
                else {
                    var q = (entity as ReceiptDetail).Receipt.ReceiptDetails.Where(t => t.Id > 0 && t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
            }
            else if (Entity.GetType() == typeof(Bsp) || Entity.GetType() == typeof(Bsp) || Entity.GetType().BaseType == typeof(Bsp)) {
                documentDate = entity.DocumentDate;
                isTaxApplicable = entity.IsTaxApplicable;
                commissionRate = entity.CommissionRateBySupplierCreditorSaleType;
                isCommissionTaxUpdateable = sourceFields.Contains("Commission");
                isTaxUpdateable = sourceFields.Contains("Amount");

                if (Entity.GetType() == typeof(Bsp)) {
                    var q = (entity as Bsp).BspDetails.Where(t => t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
                else {
                    var q = (entity as Bsp).BspDetails.Where(t => t.Id > 0 && t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
            }
            else if (Entity.GetType() == typeof(BspDetail) || Entity.GetType() == typeof(BspDetail) || Entity.GetType().BaseType == typeof(BspDetail)) {
                documentDate = entity.Bsp.DocumentDate;
                isTaxApplicable = entity.Bsp.IsTaxApplicable;
                isCommissionTaxUpdateable = sourceFields.Contains("Commission");
                isTaxUpdateable = sourceFields.Contains("Amount");

                if (Entity.GetType() == typeof(BspDetail)) {
                    var q = (entity as BspDetail).Bsp.BspDetails.Where(t => t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
                else {
                    var q = (entity as BspDetail).Bsp.BspDetails.Where(t => t.Id > 0 && t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
            }
            else if (Entity.GetType() == typeof(NonBsp) || Entity.GetType() == typeof(NonBsp) || Entity.GetType().BaseType == typeof(NonBsp)) {
                documentDate = entity.DocumentDate;
                isTaxApplicable = entity.IsTaxApplicable;
                commissionRate = entity.CommissionRateBySupplierCreditorSaleType;
                isCommissionTaxUpdateable = sourceFields.Contains("Commission");
                isTaxUpdateable = sourceFields.Contains("Amount");

                if (Entity.GetType() == typeof(NonBsp)) {
                    var q = (entity as NonBsp).NonBspDetails.Where(t => t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
                else {
                    var q = (entity as NonBsp).NonBspDetails.Where(t => t.Id > 0 && t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
            }
            else if (Entity.GetType() == typeof(NonBspDetail) || Entity.GetType() == typeof(NonBspDetail) || Entity.GetType().BaseType == typeof(NonBspDetail)) {
                documentDate = entity.NonBsp.DocumentDate;
                isTaxApplicable = RateModel.IsTaxApplicableOverride;
                isCommissionTaxUpdateable = sourceFields.Contains("Commission");
                isTaxUpdateable = sourceFields.Contains("Amount") || sourceFields.Contains("IsTaxApplicable");

                if (Entity.GetType() == typeof(NonBspDetail)) {
                    var q = (entity as NonBspDetail).NonBsp.NonBspDetails.Where(t => t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
                else {
                    var q = (entity as NonBspDetail).NonBsp.NonBspDetails.Where(t => t.Id > 0 && t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
            }
            else if (Entity.GetType() == typeof(Payment) || Entity.GetType() == typeof(Payment) || Entity.GetType().BaseType == typeof(Payment)) {
                documentDate = entity.DocumentDate;
                isTaxApplicable = entity.IsTaxApplicable;
                commissionRate = entity.CommissionRateBySupplierCreditorSaleType;
                isCommissionTaxUpdateable = true;
                isTaxUpdateable = true;

                if (Entity.GetType() == typeof(Payment)) {
                    var q = (entity as Payment).PaymentDetails.Where(t => t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
                else {
                    var q = (entity as Payment).PaymentDetails.Where(t => t.Id > 0 && t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
            }
            else if (Entity.GetType() == typeof(PaymentDetail) || Entity.GetType() == typeof(PaymentDetail) || Entity.GetType().BaseType == typeof(PaymentDetail)) {
                documentDate = entity.Payment.DocumentDate;
                isTaxApplicable = RateModel.IsTaxApplicableOverride;
                isCommissionTaxUpdateable = true;
                isTaxUpdateable = true;

                if (Entity.GetType() == typeof(PaymentDetail)) {
                    var q = (entity as PaymentDetail).Payment.PaymentDetails.Where(t => t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
                else {
                    var q = (entity as PaymentDetail).Payment.PaymentDetails.Where(t => t.Id > 0 && t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
            }
            else if (Entity.GetType() == typeof(InvoiceDetail) || Entity.GetType() == typeof(InvoiceDetail) || Entity.GetType().BaseType == typeof(InvoiceDetail)) {
                documentDate = entity.Invoice.DocumentDate;
                isTaxApplicable = entity.IsTaxApplicable;
                isTaxUpdateable = true;

                if (Entity.GetType() == typeof(InvoiceDetail)) {
                    var q = (entity as InvoiceDetail).Invoice.InvoiceDetails.Where(t => t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
                else {
                    var q = (entity as InvoiceDetail).Invoice.InvoiceDetails.Where(t => t.Id > 0 && t.Id != detailId);
                    RateModel.DocumentAmount = q.Sum(t => (decimal?)t.Amount) ?? 0;
                    RateModel.DocumentTax = q.Sum(t => (decimal?)t.Tax) ?? 0;
                }
            }
            else if (Entity.GetType() == typeof(Voucher) || Entity.GetType() == typeof(Voucher) || Entity.GetType().BaseType == typeof(Voucher)) {
                documentDate = entity.DocumentDate;
                isTaxApplicable = entity.IsTaxApplicable;
                commissionRate = entity.CommissionRateBySupplierCreditorSaleType;
                isCommissionTaxUpdateable = true;
                isTaxUpdateable = true;
                RateModel.DocumentAmount = 0;
                RateModel.DocumentTax = 0;
            }
            else {
                throw new InvalidOperationException("Invalid entity.");
            }

            var taxRate = isTaxApplicable ? CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), documentDate) : 0;

            RateModel.CommissionTaxRate = Math.Round(taxRate, 3);
            RateModel.DiscountTaxRate = Math.Round(taxRate, 3);
            RateModel.MarkupTaxRate = Math.Round(taxRate, 3);
            RateModel.TaxRate = Math.Round(taxRate, 3);

            if (taxRate == 0) {
                isTaxApplicable = false;
                RateModel.CommissionTax = 0;
                RateModel.DiscountTax = 0;
                RateModel.MarkupTax = 0;
                RateModel.Tax = 0;
            }
            else if (sourceFields.Contains("TripLineId") || sourceFields.Contains("TripLineAirPassengerId")) {
                RateModel.CommissionTax = RateModel.Commission * RateModel.CommissionTaxRate;
                RateModel.DiscountTax = RateModel.Discount * RateModel.DiscountTaxRate;
                RateModel.MarkupTax = RateModel.Markup * RateModel.MarkupTaxRate;
                RateModel.Tax = RateModel.Amount * RateModel.TaxRate;

                if (!RateModel.IsTaxIncluded) {
                    RateModel.Commission -= RateModel.CommissionTax;
                    RateModel.Discount -= RateModel.DiscountTax;
                    RateModel.Markup -= RateModel.MarkupTax;
                    RateModel.Amount -= RateModel.Tax;
                }
            }

            if (!RateModel.IsFormBinding) {
                bool calculateUnsavedValues = isTaxApplicable && (((sourceFields.Contains("Amount") || sourceFields.Contains("IsTaxApplicable")) && unsavedAmount != 0) || (sourceFields.Contains("Tax") && unsavedTax != 0));

                if (calculateUnsavedValues) {
                    if (unsavedAmount != 0) {
                        if (RateModel.IsTaxIncluded) {
                            unsavedTax = Math.Round(unsavedAmount * RateModel.TaxRate / (1 + RateModel.TaxRate), 2);
                            unsavedAmount -= unsavedTax;
                        }
                        else {
                            unsavedTax = Math.Round(unsavedAmount * RateModel.TaxRate, 2);
                        }
                    }
                    else if (unsavedTax != 0) {
                        unsavedAmount = Math.Round(unsavedTax / RateModel.TaxRate, 2);
                    }
                }

                RateModel.DocumentAmount += unsavedAmount;
                RateModel.DocumentTax += unsavedTax;
                RateModel.Amount = unsavedAmount;
                RateModel.Tax = unsavedTax;

                if (!calculateUnsavedValues && isTaxUpdateable) {
                    if (RateModel.IsTaxIncluded) {
                        RateModel.Tax = Math.Round(RateModel.Amount * RateModel.TaxRate / (1 + RateModel.TaxRate), 2);
                    }
                    else {
                        RateModel.Tax = Math.Round(RateModel.Amount * RateModel.TaxRate, 2);
                    }
                }

                if (RateModel.IsTaxIncluded) {
                    RateModel.CommissionTax = Math.Round(RateModel.Commission * RateModel.CommissionTaxRate / (1 + RateModel.CommissionTaxRate), 2);
                    RateModel.Commission -= RateModel.CommissionTax;

                    RateModel.DiscountTax = Math.Round(RateModel.Discount * RateModel.DiscountTaxRate / (1 + RateModel.DiscountTaxRate), 2);
                    RateModel.Discount -= RateModel.DiscountTax;

                    RateModel.MarkupTax = Math.Round(RateModel.Markup * RateModel.MarkupTaxRate / (1 + RateModel.MarkupTaxRate), 2);
                    RateModel.Markup -= RateModel.MarkupTax;

                    if (!calculateUnsavedValues) {
                        RateModel.Amount -= RateModel.Tax;
                        RateModel.DocumentAmount -= RateModel.Tax;
                    }
                }
                else {
                    RateModel.CommissionTax = Math.Round(RateModel.Commission * RateModel.CommissionTaxRate, 2);
                    RateModel.DiscountTax = Math.Round(RateModel.Discount * RateModel.DiscountTaxRate, 2);
                    RateModel.MarkupTax = Math.Round(RateModel.Markup * RateModel.MarkupTaxRate, 2);
                }
            }

            bool calculateCommissionRate = false;

            if (sourceFields.Contains("IsTaxApplicable")) {
                sourceFields.Remove("IsTaxApplicable");

                if (!sourceFields.Contains("Amount"))
                    sourceFields.Add("Amount");
            }

            if (sourceFields.Contains("Amount")) {
                if (!sourceFields.Contains("CommissionRate"))
                    sourceFields.Add("CommissionRate");

                if (!sourceFields.Contains("DiscountRate"))
                    sourceFields.Add("DiscountRate");

                if (!sourceFields.Contains("MarkupRate"))
                    sourceFields.Add("MarkupRate");
            }

            if (sourceFields.Contains("CreditorId")) {
                sourceFields.Remove("CreditorId");
                calculateCommissionRate = commissionRate != 0;
            }

            if (sourceFields.Contains("SupplierId")) {
                sourceFields.Remove("SupplierId");
                calculateCommissionRate = commissionRate != 0;
            }

            if (sourceFields.Contains("SaleTypeId")) {
                sourceFields.Remove("SaleTypeId");
                calculateCommissionRate = commissionRate != 0;
            }

            if (!RateModel.IsFormBinding) {
                foreach (string sourceField in sourceFields) {
                    switch (sourceField) {
                        case "Amount":
                        case "Tax":
                            if (isTaxApplicable) {
                                decimal tax = 0;

                                if (RateModel.IsTaxIncluded) {
                                    tax = Math.Round(RateModel.AmountGross * RateModel.TaxRate / (1 + RateModel.TaxRate), 2);
                                }
                                else {
                                    tax = Math.Round(RateModel.Amount * RateModel.TaxRate, 2);
                                }

                                if (isTaxUpdateable) {
                                    RateModel.Tax = tax;
                                }
                                else if (RateModel.Tax > tax + 0.02m) {
                                    RateModel.Tax = tax + 0.02m;
                                }
                                else if (RateModel.Tax < tax - 0.02m) {
                                    RateModel.Tax = tax - 0.02m;
                                }
                            }
                            else {
                                RateModel.Tax = 0;
                            }

                            break;
                        case "Commission":
                        case "CommissionTax":
                            if (isTaxApplicable) {
                                decimal commissionTax = 0;

                                if (RateModel.IsTaxIncluded) {
                                    commissionTax = Math.Round(RateModel.CommissionGross * RateModel.CommissionTaxRate / (1 + RateModel.CommissionTaxRate), 2);
                                }
                                else {
                                    commissionTax = Math.Round(RateModel.Commission * RateModel.CommissionTaxRate, 2);
                                }

                                if (isCommissionTaxUpdateable) {
                                    RateModel.CommissionTax = commissionTax;
                                }
                                else if (RateModel.CommissionTax > commissionTax + 0.02m) {
                                    RateModel.CommissionTax = commissionTax + 0.02m;
                                }
                                else if (RateModel.CommissionTax < commissionTax - 0.02m) {
                                    RateModel.CommissionTax = commissionTax - 0.02m;
                                }
                            }
                            else {
                                RateModel.CommissionTax = 0;
                            }

                            break;
                    }
                }
            }

            foreach (string sourceField in sourceFields) {
                switch (sourceField) {
                    case "Amount":
                        RateModel.Tax = Math.Round(RateModel.Amount * RateModel.TaxRate, 2);
                        break;
                    case "Commission":
                        RateModel.CommissionRate = Math.Round(RateModel.DocumentAmountGross == 0 ? 0 : RateModel.CommissionGross / RateModel.DocumentAmountGross, 3);
                        break;
                    case "Discount":
                        RateModel.DiscountRate = Math.Round(RateModel.DocumentAmountGross == 0 ? 0 : RateModel.DiscountGross / RateModel.DocumentAmountGross, 3);
                        break;
                    case "Markup":
                        RateModel.MarkupRate = Math.Round(RateModel.DocumentAmountGross == 0 ? 0 : RateModel.MarkupGross / RateModel.DocumentAmountGross, 3);
                        break;
                    case "CommissionTax":
                        if (RateModel.CommissionTaxRate > 0) {
                            RateModel.Commission = Math.Round(RateModel.CommissionTax / RateModel.CommissionTaxRate, 2);
                            RateModel.CommissionRate = Math.Round(RateModel.DocumentAmountGross == 0 ? 0 : RateModel.CommissionGross / RateModel.DocumentAmountGross, 3);
                        }

                        break;
                    case "DiscountTax":
                        if (RateModel.DiscountTaxRate > 0) {
                            RateModel.Discount = Math.Round(RateModel.DiscountTax / RateModel.DiscountTaxRate, 2);
                            RateModel.DiscountRate = Math.Round(RateModel.DocumentAmountGross == 0 ? 0 : RateModel.DiscountGross / RateModel.DocumentAmountGross, 3);
                        }

                        break;
                    case "MarkupTax":
                        if (RateModel.MarkupTaxRate > 0) {
                            RateModel.Markup = Math.Round(RateModel.MarkupTax / RateModel.MarkupTaxRate, 2);
                            RateModel.MarkupRate = Math.Round(RateModel.DocumentAmountGross == 0 ? 0 : RateModel.MarkupGross / RateModel.DocumentAmountGross, 3);
                        }

                        break;
                    case "CommissionRate":
                        if (isTaxApplicable) {
                            RateModel.Commission = Math.Round(RateModel.DocumentAmountGross * RateModel.CommissionRate, 2);
                        }
                        else {
                            RateModel.Commission = Math.Round(RateModel.DocumentAmount * RateModel.CommissionRate, 2);
                        }

                        if (RateModel.IsTaxIncluded) {
                            RateModel.CommissionTax = Math.Round(RateModel.Commission * RateModel.CommissionTaxRate / (1 + RateModel.CommissionTaxRate), 2);
                        }
                        else {
                            RateModel.CommissionTax = Math.Round(RateModel.Commission * RateModel.CommissionTaxRate, 2);
                        }

                        RateModel.Commission -= RateModel.CommissionTax;
                        break;
                    case "DiscountRate":
                        if (isTaxApplicable) {
                            RateModel.Discount = Math.Round(RateModel.DocumentAmountGross * RateModel.DiscountRate, 2);
                        }
                        else {
                            RateModel.Discount = Math.Round(RateModel.DocumentAmount * RateModel.DiscountRate, 2);
                        }

                        if (RateModel.IsTaxIncluded) {
                            RateModel.DiscountTax = Math.Round(RateModel.Discount * RateModel.DiscountTaxRate / (1 + RateModel.DiscountTaxRate), 2);
                        }
                        else {
                            RateModel.DiscountTax = Math.Round(RateModel.Discount * RateModel.DiscountTaxRate, 2);
                        }

                        RateModel.Discount -= RateModel.DiscountTax;
                        break;
                    case "MarkupRate":
                        if (isTaxApplicable) {
                            RateModel.Markup = Math.Round(RateModel.DocumentAmountGross * RateModel.MarkupRate, 2);
                        }
                        else {
                            RateModel.Markup = Math.Round(RateModel.DocumentAmount * RateModel.MarkupRate, 2);
                        }

                        if (RateModel.IsTaxIncluded) {
                            RateModel.MarkupTax = Math.Round(RateModel.Markup * RateModel.MarkupTaxRate / (1 + RateModel.MarkupTaxRate), 2);
                        }
                        else {
                            RateModel.MarkupTax = Math.Round(RateModel.Markup * RateModel.MarkupTaxRate, 2);
                        }

                        RateModel.Markup -= RateModel.MarkupTax;
                        break;
                }
            }

            if (calculateCommissionRate) {
                RateModel.CommissionRate = commissionRate;
                RateModel.Commission = Math.Round(RateModel.DocumentAmount * RateModel.CommissionRate, 2);
                RateModel.CommissionTax = Math.Round(RateModel.Commission * RateModel.CommissionTaxRate, 2);
            }

            if (sourceFields.Contains("Amount")) {
                if (RateModel.Amount >= unsavedAmount - .02m && RateModel.Amount <= unsavedAmount + .02m)
                    RateModel.Amount = unsavedAmount;

                if (RateModel.Tax >= unsavedTax - .02m && RateModel.Tax <= unsavedTax + .02m)
                    RateModel.Tax = unsavedTax;
            }

            if (sourceFields.Contains("TripLineId") || sourceFields.Contains("TripLineAirPassengerId")) {
                if (RateModel.TaxRate > 0) {
                    if (RateModel.IsTaxIncluded) {
                        RateModel.Tax = Math.Round(RateModel.AmountGross * RateModel.TaxRate / (1 + RateModel.TaxRate), 2);
                    }
                    else {
                        RateModel.Tax = Math.Round(RateModel.AmountGross * RateModel.TaxRate, 2);
                    }
                }
                else {
                    RateModel.Tax = 0;
                }
            }

            return true;
        }
    }

    public class ReceiptCommon {
        private HttpContext HttpContext { get; }

        public ReceiptCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        private bool ValidateAndSave(AppLazyContext lazyContext, Receipt receipt, bool validateDocumentStatus = true, decimal totalAmount = 0, bool performRelatedUpdates = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow, int oldTripId = 0) {
            Validate(receipt, false, validateDocumentStatus);

            var receipts = lazyContext.Receipt.Where(t => t.Id != receipt.Id && t.DocumentNo == receipt.DocumentNo && t.ReceiptType == receipt.ReceiptType && t.IsSplit);

            if (receipts.Count() == 1 && !receipt.IsSplit) {
                receipt.IsSplit = false;
            }
            else if (receipts.Any(t => t.TripId > 0 && t.TripId == receipt.TripId)) {
                throw new UnreportedException("The selected Trip has already been added to this Receipt collection.");
            }

            bool result;

            if (receipt.Id <= 0) {
                result = lazyContext.Insert(receipt);
            }
            else {
                result = lazyContext.Save(receipt);
            }

            if (!result && !performRelatedUpdates)
                return false;

            if (receipt.ReceiptType == ReceiptType.Transfer && receipt.ReversalStatus == ReversalStatus.None) {
                if (totalAmount == 0)
                    throw new UnreportedException(AppConstants.ZeroAmountWarning);

                var q = receipt.ReceiptDetails.SingleOrDefault(t => t.ReceiptId == receipt.Id);

                if (q == null) {
                    q = new ReceiptDetail {
                        Id = 0,
                        ReceiptId = receipt.Id,
                        DocumentStatus = DocumentStatus.DepositedPaid,
                        ReversalStatus = ReversalStatus.None,
                        TripLineId = -1,
                        TripLineAirPassengerId = -1,
                        PassengerId = -1,
                        FormOfPaymentId = -1,
                        PaymentMethodId = -1,
                        LoyaltySchemeId = -1,
                        LoyaltySchemeReference = string.Empty,
                        VoucherId = -1,
                        Class = string.Empty,
                        OfferedReasonId = -1,
                        DepositDetailId = -1,
                        BankAccountStatementId = -1,
                        Comments = string.Empty,
                        Receipt = receipt
                    };

                    q.TripLine = lazyContext.TripLine.Find(q.TripLineId);
                    q.TripLineAirPassenger = lazyContext.TripLineAirPassenger.Find(q.TripLineAirPassengerId);
                    q.Passenger = lazyContext.Passenger.Find(q.PassengerId);
                    q.FormOfPayment = lazyContext.FormOfPayment.Find(q.FormOfPaymentId);
                    q.LoyaltyScheme = lazyContext.FormOfPayment.Find(q.LoyaltySchemeId);
                    q.OfferedReason = lazyContext.OfferedReason.Find(q.OfferedReasonId);
                }

                q.Amount = totalAmount;
                new ReceiptDetailCommon(HttpContext).ValidateAndSave(lazyContext, q, validateDocumentStatus, performRelatedUpdates);

                if (receipt.ReverseTransferReceiptId > 0) {
                    using (var receiptContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                        var reverseTransferReceipt = receiptContext.Receipt.Find(receipt.ReverseTransferReceiptId);

                        reverseTransferReceipt.DocumentDate = receipt.DocumentDate;
                        reverseTransferReceipt.BankAccountId = (lazyContext.BankAccount.SingleOrDefault(t => t.ChartOfAccountId == receipt.ChartOfAccountId) ?? new BankAccount { Id = -1 }).Id;
                        reverseTransferReceipt.ChartOfAccountId = receipt.BankAccount.ChartOfAccountId;
                        receiptContext.Save(reverseTransferReceipt, false);

                        if (reverseTransferReceipt.ReceiptDetails.Count > 0) {
                            var documentStatus = q.DocumentStatus;

                            q = reverseTransferReceipt.ReceiptDetails[0];
                            q.DocumentStatus = documentStatus;
                            q.Amount = -totalAmount;
                            new ReceiptDetailCommon(HttpContext).ValidateAndSave(receiptContext, q, validateDocumentStatus, performRelatedUpdates);
                        }
                    }
                }

                lazyContext.Entry(receipt.BankAccount).State = EntityState.Detached;
            }

            if (txnUpdateType != TransactionUpdateType.None)
                receipt.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            if (oldTripId > 0) {
                foreach (var tripLine in lazyContext.Trip.Find(oldTripId).TripLines.Where(t => t.Id > 0).ToList()) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }

            foreach (var tripLine in receipt.ReceiptDetails.Where(t => t.TripLineId > 0).Select(t => t.TripLine).Distinct().ToList()) {
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (receipt.ReceiptDetails.All(t => t.TripLineId <= 0) && receipt.Trip?.Id > 0)
                receipt.Trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            foreach (var receiptDetail in receipt.ReceiptDetails.Where(t => t.LoyaltySchemeId > 0)) {
                new ReceiptDetailCommon(HttpContext).CreateLoyaltySchemeNonBsp(receiptDetail);
            }

            if (receipt.ReceiptType == ReceiptType.OtherCommission && receipt.SupplierCommissionType == SupplierCommissionType.Creditor) {
                return CreateOrUpdateSupplierOtherCommissionNonBsp(receipt);
            }
            else if (receipt.ReceiptType == ReceiptType.Transfer && receipt.ReverseTransferReceiptId <= 0) {
                return CreateOrUpdateReverseTransferReceipt(receipt);
            }

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, Receipt receipt, bool validateDocumentStatus = true) {
            using (var ts = Utils.CreateTransactionScope()) {
                Validate(receipt, true, validateDocumentStatus);

                DeleteCustomerTransactions(lazyContext, receipt);

                int[] receiptIds = lazyContext.Receipt.Where(t => t.ReverseTransferReceiptId > 0 && (t.Id == receipt.Id || t.ReverseTransferReceiptId == receipt.Id)).Select(t => t.ReverseTransferReceiptId).ToArray();

                if (receiptIds.Length > 0) {
                    foreach (var row in lazyContext.Receipt.Include(t => t.Transactions).ThenInclude(t => t.TransactionDetails).ThenInclude(t => t.TransactionDetailAllocations).Include(t => t.ReverseTransferReceipt).ThenInclude(t => t.Transactions).ThenInclude(t => t.TransactionDetails).ThenInclude(t => t.TransactionDetailAllocations).Where(t => receiptIds.Contains(t.ReverseTransferReceiptId)).ToList()) {
                        int receiptId = row.Id;
                        int reverseTransferReceiptId = row.ReverseTransferReceiptId;

                        row.ReverseTransferReceipt.ReverseTransferReceiptId = -1;
                        lazyContext.Save(row.ReverseTransferReceipt, false);

                        row.ReverseTransferReceiptId = -1;
                        lazyContext.Save(row, false);

                        lazyContext.Delete(row);
                    }

                    ts.Complete();
                    return true;
                }

                int[] receiptDetailIds = receipt.ReceiptDetails.Select(t => t.Id).ToArray();

                lazyContext.RemoveRange(lazyContext.NonBsp.Include(t => t.Transactions).Where(t => receiptDetailIds.Contains(t.LoyaltySchemeReceiptDetailId) || (t.SupplierOtherCommissionReceiptId > 0 && t.SupplierOtherCommissionReceiptId == receipt.Id)));
                lazyContext.SaveChanges();

                if (receipt.IsDeposit) {
                    foreach (var row in lazyContext.ReceiptDetail.Where(t => t.DepositDetailId == receipt.ReceiptDetails.Single().Id)) {
                        row.DocumentStatus = DocumentStatus.Open;
                        row.DepositDetailId = -1;
                        lazyContext.Save(row, false);
                    }
                }

                if (HttpContext.IsSuperUser()) {
                    lazyContext.RemoveRange(lazyContext.TransactionDetail.Where(t => receiptDetailIds.Contains(t.ReceiptDetailId)).SelectMany(t => t.TransactionDetailAllocations));
                    lazyContext.SaveChanges();

                    lazyContext.RemoveRange(lazyContext.TransactionDetailAllocation.Where(t => receiptDetailIds.Contains(t.ReceiptDetailId)));
                    lazyContext.SaveChanges();

                    lazyContext.RemoveRange(receipt.IssuedDocuments);
                    lazyContext.SaveChanges();
                }

                lazyContext.RemoveRange(receipt.Transactions);
                lazyContext.SaveChanges();

                var tripLines = receipt.ReceiptDetails.Where(t => t.TripLineId > 0).Select(t => t.TripLine).Distinct().ToList();

                if (!lazyContext.Delete(receipt))
                    return false;

                if (tripLines.Count > 0) {
                    foreach (var tripLine in tripLines) {
                        tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                    }
                }
                else if (receipt.Trip?.Id > 0) {
                    receipt.Trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }

                ts.Complete();
                return true;
            }
        }

        public void Validate(Receipt receipt, bool isDeletion, bool validateDocumentStatus = true) {
            if (!isDeletion && receipt.AgencyId <= 0)
                throw new UnreportedException(AppConstants.AgencyNotSpecified);

            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), receipt.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!isDeletion && receipt.TripId > 0 && !receipt.Trip.IsBooking)
                throw new UnreportedException(AppConstants.RecordIsNotBooking);

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !receipt.CanDelete(HttpContext.IsAdministrator(), HttpContext.IsAccounts(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !receipt.CanEdit(HttpContext.IsAdministrator(), HttpContext.IsAccounts(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public ReceiptViewModel Create(AppLazyContext lazyContext, int tripId, int bankAccountId, int standardCommentId, string receiptAddModels) {
            var models = JsonSerializer.Deserialize<List<ReceiptAddViewModel>>(receiptAddModels, JsonExtensionsBiz.JsonSerializerOptions());

            if (models.Count == 0)
                throw new UnreportedException("No trip lines were selected.");

            using (var ts = Utils.CreateTransactionScope()) {
                var trip = lazyContext.Trip.Find(tripId);

                if (trip.TripLines.Any(t1 => models.Select(t2 => t2.ReceiptAddTripLineId).Contains(t1.Id) && !t1.IsBooking))
                    throw new UnreportedException("Only booked records can be processed for receipting.");

                if (models.Any(t => t.ReceiptAddFormOfPaymentId == null))
                    throw new UnreportedException("Form of Payment is required.");

                decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), DateTime.Today);

                var receiptModel = new ReceiptViewModel {
                    ReceiptId = 0,
                    ReceiptAccountType = AccountType.Client,
                    ReceiptType = ReceiptType.Receipt,
                    ReceiptDocumentStatus = DocumentStatus.Open,
                    ReceiptDocumentDate = models.First().ReceiptAddDocumentDate?.Date,
                    ReceiptPayer = trip.FullName,
                    ReceiptTripId = trip.Id,
                    ReceiptDebtorId = -1,
                    ReceiptCreditorId = -1,
                    ReceiptSupplierId = -1,
                    ReceiptChartOfAccountId = -1,
                    ReceiptBankAccountToId = bankAccountId,
                    ReceiptSaleTypeId = -1,
                    ReceiptCategoryId = trip.CategoryId,
                    ReceiptAgencyId = trip.AgencyId,
                    ReceiptSourceId = trip.SourceId,
                    ReceiptConsultantId = trip.ConsultantId,
                    ReceiptStandardCommentId = standardCommentId,
                    ReceiptDiscountReasonId = -1,
                    ReceiptCancellationSaleTypeId = -1
                };

                CreateOrUpdate(receiptModel, false, 0, 0, 0, true, TransactionUpdateType.None);

                ReceiptDetailViewModel receiptDetailModel = null;

                foreach (var model in models.GroupBy(t => new { t.ReceiptAddTripLineId, t.ReceiptAddTripLineAirPassengerId, t.ReceiptAddPassengerId, t.ReceiptAddFormOfPaymentId, t.ReceiptAddPaymentMethodId, t.ReceiptAddIsTaxApplicable, t.ReceiptAddComments })) {
                    if (model.Sum(t => t.ReceiptAddAmount) == 0)
                        throw new UnreportedException("Receipt amount is zero for one or more trip lines.");

                    var tripLine = lazyContext.TripLine.Find(model.Key.ReceiptAddTripLineId);

                    if (tripLine.AmountReceived == tripLine.AmountReceivable)
                        continue;

                    decimal amount = model.Sum(t => (decimal?)t.ReceiptAddAmount) ?? 0;

                    if (amount == 0)
                        continue;

                    if (Math.Abs(amount - tripLine.AmountReceivable) <= 0.02m)
                        amount = tripLine.AmountReceivable;

                    receiptDetailModel = new ReceiptDetailViewModel {
                        ReceiptDetailId = 0,
                        ReceiptId = receiptModel.ReceiptId,
                        ReceiptDetailDocumentStatus = DocumentStatus.Open,
                        ReceiptDetailReversalStatus = ReversalStatus.None,
                        ReceiptDetailTripLineId = model.Key.ReceiptAddTripLineId,
                        ReceiptDetailTripLineAirPassengerId = model.Key.ReceiptAddTripLineAirPassengerId,
                        ReceiptDetailPassengerId = model.Key.ReceiptAddPassengerId,
                        ReceiptDetailFormOfPaymentId = model.Key.ReceiptAddFormOfPaymentId,
                        ReceiptDetailPaymentMethodId = model.Key.ReceiptAddPaymentMethodId,
                        ReceiptDetailLoyaltySchemeId = -1,
                        ReceiptDetailVoucherId = -1,
                        ReceiptDetailClass = string.Empty,
                        ReceiptDetailOfferedReasonId = -1,
                        ReceiptDetailAmount = amount,
                        ReceiptDetailComments = model.Key.ReceiptAddComments.ToStringExt()
                    };

                    receiptDetailModel.ReceiptDetailTax = model.Key.ReceiptAddIsTaxApplicable ? receiptDetailModel.ReceiptDetailAmount * taxRate : 0;
                    new ReceiptDetailCommon(HttpContext).CreateOrUpdate(receiptDetailModel, null, false, TransactionMatchViewStatus.NotSaved, false, false, false, TransactionUpdateType.None);
                }

                if (receiptDetailModel != null)
                    new ReceiptDetailCommon(HttpContext).CreateOrUpdate(receiptDetailModel, null, false, TransactionMatchViewStatus.NotSaved, false, false, false, TransactionUpdateType.Bulk);

                ts.Complete();
                return receiptModel;
            }
        }

        public bool CreateOrUpdate(ReceiptViewModel model, bool validateDocumentStatus = true, int receiptDetailId = 0, decimal unsavedAmount = 0, decimal unsavedTax = 0, bool performRelatedUpdates = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            if (model.ReceiptAccountType == AccountType.Creditor && (model.ReceiptType == ReceiptType.Refund || model.ReceiptType == ReceiptType.VoucherCommission || (model.ReceiptType == ReceiptType.OtherCommission && model.ReceiptSupplierCommissionType == SupplierCommissionType.None))) {
                if ((model.ReceiptSaleTypeId ?? 0) <= 0)
                    throw new UnreportedException("Type of Sale is required.");

                if ((model.ReceiptConsultantId ?? 0) <= 0)
                    throw new UnreportedException("Consultant is required.");
            }

            if (model.ReceiptType == ReceiptType.Transfer && model.ReceiptBankAccountFromId == model.ReceiptBankAccountToId)
                throw new UnreportedException("From Account cannot be the same as To Account.");

            if (model.ReceiptType == ReceiptType.Refund) {
                if (model.ReceiptDiscount != 0 && (model.ReceiptDiscountReasonId ?? 0) <= 0)
                    throw new UnreportedException("Discount Reason is required when Discount is applied.");

                if (model.ReceiptCancellationFee != 0 && (model.ReceiptCancellationSaleTypeId ?? 0) <= 0)
                    throw new UnreportedException("Cancellation Type of Sale is required when Cancellation Fee is applied.");
            }

            if (model.ReceiptIsTaxIncluded)
                unsavedAmount -= unsavedTax;

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    Receipt q = null;

                    if (model.ReceiptId <= 0) {
                        q = new Receipt {
                            Id = 0,
                            AccountType = model.ReceiptAccountType,
                            ReceiptType = model.ReceiptType,
                            DocumentNo = model.ReceiptId == -2 ? model.ReceiptNewDocumentNo : LastDocumentNo.DocumentNo(lazyContext, "Receipt"),
                            DocumentDate = model.ReceiptDocumentDate ?? DateTime.MinValue,
                            ChartOfAccountId = model.ReceiptChartOfAccountId ?? 0,
                            SaleTypeId = model.ReceiptSaleTypeId ?? 0,
                            AgencyId = HttpContext.CurrentDefaultAgencyId(),
                            ReverseTransferReceiptId = -1,
                            IsSplit = model.ReceiptIsSplit
                        };

                        LastDocumentNo.DocumentNo(lazyContext, "Receipt", q.DocumentNo);
                    }
                    else {
                        q = lazyContext.Receipt.Find(model.ReceiptId);

                        if (q.ReceiptType != model.ReceiptType)
                            throw new UnreportedException("Document Type cannot be changed.");

                        if (q.AccountType == AccountType.GeneralLedger && q.EffectiveAccountType != model.ReceiptEffectiveAccountType && q.ReceiptDetails.Count > 0)
                            throw new UnreportedException("Account Type cannot be changed.");

                        if (q.DebtorId != model.ReceiptDebtorId && q.ReceiptDetails.Count > 0)
                            throw new UnreportedException("Debtor cannot be changed where receipt lines exist. Delete all receipt lines before proceeding.");
                    }

                    var supplierCommissionType = model.ReceiptSupplierCommissionType;

                    int tripId = -1;
                    int debtorId = -1;
                    int creditorId = -1;
                    int chartOfAccountId = -1;
                    int supplierId = -1;

                    int saleTypeId = -1;
                    int sourceId = -1;
                    int categoryId = -1;
                    int consultantId = model.ReceiptConsultantId ?? -1;

                    decimal nonCommissionable = model.ReceiptAccountType == AccountType.Creditor && model.ReceiptType == ReceiptType.Refund ? model.ReceiptNonCommissionable : 0;
                    decimal nonCommissionableTax = 0;
                    decimal commission = 0;
                    decimal commissionTax = 0;
                    decimal discount = 0;
                    decimal discountTax = 0;
                    decimal cancellationFee = 0;
                    decimal cancellationFeeTax = 0;
                    decimal supplierCancellationFee = 0;
                    decimal supplierCancellationFeeTax = 0;
                    decimal taxRate = 0;

                    switch (model.ReceiptType) {
                        case ReceiptType.OtherCommission:
                            switch (model.ReceiptSupplierCommissionType) {
                                case SupplierCommissionType.Creditor:
                                    supplierCommissionType = SupplierCommissionType.Creditor;
                                    saleTypeId = -1;
                                    sourceId = -1;
                                    categoryId = -1;
                                    consultantId = model.ReceiptConsultantId ?? 0;
                                    break;
                            }

                            break;
                        case ReceiptType.VoucherCommission:
                        case ReceiptType.Refund:
                            supplierCommissionType = SupplierCommissionType.None;
                            break;
                        case ReceiptType.Transfer:
                            chartOfAccountId = lazyContext.BankAccount.Find(model.ReceiptBankAccountFromId).ChartOfAccountId;
                            model.ReceiptStandardCommentId = -1;
                            break;
                    }

                    if (model.ReceiptType == ReceiptType.OtherCommission && model.ReceiptSupplierCommissionType == SupplierCommissionType.Creditor) {
                        var glSetting = Setting.GetRow(HttpContext.CurrentCustomerId(), model.ReceiptDocumentDate ?? DateTime.MinValue);

                        switch (model.ReceiptSupplierCommissionType) {
                            case SupplierCommissionType.Creditor:
                                chartOfAccountId = glSetting.CreditorControlAccount.Id;
                                break;
                        }
                    }

                    switch (model.ReceiptAccountType) {
                        case AccountType.Client:
                            tripId = model.ReceiptTripId ?? 0;
                            break;
                        case AccountType.Debtor:
                            tripId = model.ReceiptTripId ?? 0;
                            debtorId = model.ReceiptDebtorId ?? 0;
                            break;
                        case AccountType.Creditor:
                            if (model.ReceiptType == ReceiptType.Refund) {
                                tripId = model.ReceiptTripId ?? 0;
                                commission = model.ReceiptCommission;
                                discount = model.ReceiptDiscount;
                                cancellationFee = model.ReceiptCancellationFee;
                                supplierCancellationFee = model.ReceiptSupplierCancellationFee;
                            }

                            if (model.ReceiptType == ReceiptType.Refund || model.ReceiptType == ReceiptType.VoucherCommission || (model.ReceiptType == ReceiptType.OtherCommission && model.ReceiptSupplierCommissionType == SupplierCommissionType.None)) {
                                if (model.ReceiptType == ReceiptType.VoucherCommission || (model.ReceiptType == ReceiptType.OtherCommission && model.ReceiptSupplierCommissionType == SupplierCommissionType.None))
                                    chartOfAccountId = model.ReceiptChartOfAccountId ?? 0;
                            }
                            else {
                                chartOfAccountId = model.ReceiptChartOfAccountId ?? 0;
                            }

                            creditorId = model.ReceiptCreditorId ?? 0;
                            supplierId = model.ReceiptSupplierId ?? 0;
                            saleTypeId = model.ReceiptSaleTypeId ?? 0;
                            sourceId = model.ReceiptSourceId ?? 0;
                            categoryId = model.ReceiptCategoryId ?? 0;

                            if (model.ReceiptType == ReceiptType.Refund) {
                                if (sourceId <= 0)
                                    throw new UnreportedException("Source is required.");

                                if (categoryId <= 0)
                                    throw new UnreportedException("Category is required.");
                            }

                            break;
                        case AccountType.GeneralLedger:
                            switch (model.ReceiptEffectiveAccountType) {
                                case AccountType.Client:
                                    tripId = model.ReceiptTripId ?? 0;
                                    break;
                                case AccountType.Debtor:
                                    debtorId = model.ReceiptDebtorId ?? 0;
                                    break;
                                case AccountType.Creditor:
                                    creditorId = model.ReceiptCreditorId ?? 0;
                                    model.ReceiptStandardCommentId = -1;
                                    break;
                                case AccountType.GeneralLedger:
                                    if (chartOfAccountId <= 0)
                                        chartOfAccountId = model.ReceiptChartOfAccountId ?? 0;

                                    break;
                            }

                            break;
                    }

                    if (!q.IsDeposit) {
                        q.DocumentDate = (model.ReceiptDocumentDate ?? DateTime.MinValue).Date;
                        model.ReceiptDocumentDate = q.DocumentDate;
                    }

                    q.ChartOfAccountId = chartOfAccountId;
                    q.SaleTypeId = saleTypeId;

                    if (model.ReceiptId <= 0) {
                        q.ChartOfAccount = lazyContext.ChartOfAccount.Find(chartOfAccountId);
                        q.SaleType = lazyContext.SaleType.Find(saleTypeId);
                    }

                    if (!q.ValidateChartOfAccountTaxApplicability(q.ChartOfAccount.IsTaxApplicable) || !q.ValidateSaleTypeTaxApplicability(q.SaleType.IsTaxApplicable))
                        throw new UnreportedException(AppConstants.TaxRelatedRecordCannotBeAltered);

                    switch (model.ReceiptAccountType) {
                        case AccountType.Creditor:
                            if (model.ReceiptType == ReceiptType.Refund || model.ReceiptType == ReceiptType.VoucherCommission || (model.ReceiptType == ReceiptType.OtherCommission && model.ReceiptSupplierCommissionType == SupplierCommissionType.None)) {
                                if (q.IsTaxApplicable) {
                                    taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), (DateTime)model.ReceiptDocumentDate);

                                    nonCommissionableTax = Math.Round(nonCommissionable * taxRate / (1 + taxRate), 2);
                                    nonCommissionable -= nonCommissionableTax;

                                    cancellationFeeTax = Math.Round(cancellationFee * taxRate / (1 + taxRate), 2);
                                    cancellationFee -= cancellationFeeTax;

                                    supplierCancellationFeeTax = Math.Round(supplierCancellationFee * taxRate / (1 + taxRate), 2);
                                    supplierCancellationFee -= supplierCancellationFeeTax;

                                    if (model.ReceiptIsTaxIncluded) {
                                        commissionTax = Math.Round(commission * taxRate / (1 + taxRate), 2);
                                        discountTax = Math.Round(discount * taxRate / (1 + taxRate), 2);
                                        commission -= commissionTax;
                                        discount -= discountTax;
                                    }
                                    else {
                                        commissionTax = Math.Round(commission * taxRate, 2);
                                        discountTax = Math.Round(discount * taxRate, 2);
                                    }
                                }
                            }

                            break;
                    }

                    int oldTripId = q.Id > 0 && q.TripId != tripId ? q.TripId : 0;

                    if (!q.IsClientAccountLocked) {
                        q.TripId = tripId;
                        q.DebtorId = debtorId;
                    }

                    if (consultantId == -1) {
                        if (q.TripId > 0) {
                            q.Trip = lazyContext.Trip.Find(q.TripId);
                            consultantId = q.Trip.ConsultantId;
                        }
                        else {
                            consultantId = HttpContext.CurrentConsultantId();
                        }
                    }

                    q.CreditorId = creditorId;
                    q.SupplierId = supplierId;
                    q.BankAccountId = model.ReceiptBankAccountToId ?? 0;
                    q.Payer = model.ReceiptType == ReceiptType.Admin || model.ReceiptType == ReceiptType.Transfer ? model.ReceiptPayer.ToStringExt() : string.Empty;
                    q.SupplierCommissionType = supplierCommissionType;
                    q.CategoryId = categoryId;
                    q.SourceId = sourceId;
                    q.ConsultantId = consultantId;
                    q.StandardCommentId = model.ReceiptStandardCommentId ?? 0;
                    q.Commission = commission;
                    q.CommissionTax = commissionTax;
                    q.NonCommissionable = nonCommissionable;
                    q.NonCommissionableTax = nonCommissionableTax;
                    q.Discount = discount;
                    q.DiscountTax = discountTax;
                    q.DiscountReasonId = model.ReceiptAccountType == AccountType.Creditor && model.ReceiptType == ReceiptType.Refund ? model.ReceiptDiscountReasonId ?? 0 : -1;
                    q.CancellationFee = cancellationFee;
                    q.CancellationFeeTax = cancellationFeeTax;
                    q.CancellationSaleTypeId = model.ReceiptAccountType == AccountType.Creditor && model.ReceiptType == ReceiptType.Refund ? model.ReceiptCancellationSaleTypeId ?? 0 : -1;
                    q.SupplierCancellationFee = supplierCancellationFee;
                    q.SupplierCancellationFeeTax = supplierCancellationFeeTax;
                    q.AmountToBank = 0;
                    q.AmountToBankTax = 0;

                    if (model.ReceiptId <= 0) {
                        q.BankAccount = lazyContext.BankAccount.Find(q.BankAccountId);
                        q.Trip = lazyContext.Trip.Find(q.TripId);
                        q.Debtor = lazyContext.Debtor.Find(q.DebtorId);
                        q.Creditor = lazyContext.Creditor.Find(q.CreditorId);
                        q.Supplier = lazyContext.Supplier.Find(q.SupplierId);
                        q.ChartOfAccount = lazyContext.ChartOfAccount.Find(q.ChartOfAccountId);
                    }

                    q.IsCreditCardDiscountApplicable = q.SaleType.IsCreditCardDiscountApplicable;
                    q.IsIssued = q.IssuedDocuments.Count > 0;

                    if (model.ReceiptAccountType == AccountType.Creditor) {
                        q.AmountToBank = q.GetAmountToBank(receiptDetailId, unsavedAmount);
                        q.AmountToBankTax = q.GetAmountToBankTax(receiptDetailId, unsavedTax);

                        if (model.ReceiptType == ReceiptType.Refund) {
                            q.OriginalSaleTotal = q.GetOriginalSaleTotal(receiptDetailId, unsavedAmount);
                            q.OriginalSaleTotalTax = q.GetOriginalSaleTotalTax(receiptDetailId, unsavedTax);
                        }
                        else {
                            if (model.ReceiptType == ReceiptType.VoucherCommission || (model.ReceiptType == ReceiptType.OtherCommission && model.ReceiptSupplierCommissionType == SupplierCommissionType.None)) {
                                q.OriginalSaleTotal = model.ReceiptOriginalSaleTotal;
                            }
                            else {
                                q.OriginalSaleTotal = 0;
                            }

                            q.OriginalSaleTotalTax = 0;

                            if (q.IsTaxApplicable && q.OriginalSaleTotal != 0) {
                                q.OriginalSaleTotalTax = Math.Round(q.OriginalSaleTotal * taxRate / (1 + taxRate), 2);
                                q.OriginalSaleTotal -= q.OriginalSaleTotalTax;
                            }
                        }
                    }

                    if (q.SupplierCommissionType != SupplierCommissionType.Creditor && q.ChartOfAccountId > 0 && !ChartOfAccount.IsInRole(lazyContext, q.ChartOfAccountId, HttpContext.RoleId()))
                        throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                    if (q.ChartOfAccountId > 0 && !HttpContext.IsAdministrator() && Setting.IsControlAccount(HttpContext.CurrentCustomerId(), q.DocumentDate, q.ChartOfAccountId))
                        throw new UnreportedException(AppConstants.GlControlAccountWarning);

                    bool result = ValidateAndSave(lazyContext, q, validateDocumentStatus, model.ReceiptTotalAmount, performRelatedUpdates, txnUpdateType, oldTripId);

                    model.ReceiptViewId = q.Id;
                    model.ReceiptId = q.Id;
                    model.ReceiptDocumentNo = q.DocumentNo;
                    model.ReceiptDocumentTotal = q.GetDocumentTotal(lazyContext);
                    model.ReceiptIsTaxApplicable = q.IsTaxApplicable;

                    ts.Complete();
                    return result;
                }
            }
        }

        public bool Delete(AppLazyContext lazyContext, ReceiptViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.Receipt.Find(model.ReceiptId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }

        public bool ProcessSelections(AppLazyContext lazyContext, int[] receiptDetailIds, int bankAccountId, DateTime dateDeposited, bool isDetailView, bool undo) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (undo) {
                foreach (int receiptDetailId in receiptDetailIds) {
                    Undo(lazyContext, receiptDetailId, isDetailView, false);
                }

                return true;
            }

            using (var ts = Utils.CreateTransactionScope()) {
                int depositDetailId = -1;

                var q = lazyContext.ReceiptDetail.Where(t => receiptDetailIds.Contains(t.Id)).Select(row => new {
                    row.Amount,
                    row.Tax
                });

                if (q.Any()) {
                    if (dateDeposited.Hour == 0 && dateDeposited.Minute == 0)
                        dateDeposited = dateDeposited.AddHours(HttpContext.Now().Hour).AddMinutes(HttpContext.Now().Minute);

                    string documentNo = string.Format("{0:yyyyMMddHHmm}", dateDeposited);

                    var receipt = new Receipt {
                        Id = 0,
                        Payer = string.Empty,
                        TripId = -1,
                        Trip = lazyContext.Trip.Find(-1),
                        DebtorId = -1,
                        CreditorId = -1,
                        SupplierId = -1,
                        ChartOfAccountId = -1,
                        AccountType = AccountType.None,
                        ReceiptType = ReceiptType.All,
                        DocumentNo = documentNo,
                        DocumentDate = dateDeposited,
                        BankAccountId = bankAccountId,
                        SupplierCommissionType = SupplierCommissionType.None,
                        SaleTypeId = -1,
                        CategoryId = -1,
                        StandardCommentId = -1,
                        ConsultantId = HttpContext.CurrentConsultantId(),
                        AgencyId = HttpContext.CurrentDefaultAgencyId(),
                        SourceId = -1,
                        Commission = 0,
                        CommissionTax = 0,
                        NonCommissionable = 0,
                        Discount = 0,
                        DiscountTax = 0,
                        DiscountReasonId = -1,
                        CancellationFee = 0,
                        CancellationFeeTax = 0,
                        CancellationSaleTypeId = -1,
                        SupplierCancellationFee = 0,
                        SupplierCancellationFeeTax = 0,
                        ReverseTransferReceiptId = -1,
                        AmountToBank = q.Sum(t => t.Amount),
                        AmountToBankTax = q.Sum(t => t.Tax),
                        IsCreditCardDiscountApplicable = false,
                        IsDeposit = true
                    };

                    ValidateAndSave(lazyContext, receipt, false, 0, true, TransactionUpdateType.None);

                    var receiptDetail = new ReceiptDetail {
                        Id = 0,
                        ReceiptId = receipt.Id,
                        Receipt = receipt,
                        DocumentStatus = DocumentStatus.DepositedPaid,
                        ReversalStatus = ReversalStatus.None,
                        TripLineId = -1,
                        TripLine = lazyContext.TripLine.Find(-1),
                        TripLineAirPassengerId = -1,
                        PassengerId = -1,
                        FormOfPaymentId = -1,
                        PaymentMethodId = -1,
                        LoyaltySchemeId = -1,
                        LoyaltySchemeReference = string.Empty,
                        LoyaltySchemePointsCollected = 0,
                        LoyaltySchemePointsCost = 0,
                        LoyaltySchemeValue = 0,
                        Amount = 0,
                        Tax = 0,
                        VoucherId = -1,
                        Class = string.Empty,
                        OfferedReasonId = -1,
                        DepositDetailId = -1,
                        BankAccountStatementId = -1,
                        Comments = string.Empty
                    };

                    new ReceiptDetailCommon(HttpContext).ValidateAndSave(lazyContext, receiptDetail, false);
                    depositDetailId = receiptDetail.Id;
                }

                foreach (int receiptDetailId in receiptDetailIds) {
                    lazyContext.ReceiptDetail.Find(receiptDetailId).UpdateDocumentStatus(lazyContext, DocumentStatus.DepositedPaid, 0, depositDetailId);
                }

                ts.Complete();
                return true;
            }
        }

        public bool Undo(AppLazyContext lazyContext, int id, bool isDetailView, bool isBankReconciliation) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            using (var ts = Utils.CreateTransactionScope()) {
                Receipt receipt = null;
                ReceiptDetail receiptDetail = null;

                var receiptDetailList = new List<ReceiptDetail>();

                if (isDetailView) {
                    receiptDetail = lazyContext.ReceiptDetail.Find(id);

                    if (!receiptDetail.CanUndo(isBankReconciliation))
                        throw new UnreportedException(AppConstants.RecordCannotBeUndone);

                    if (receiptDetail.DepositDetailId > 0) {
                        receipt = lazyContext.Receipt.Find(receiptDetail.ReceiptId);
                    }
                    else {
                        receipt = receiptDetail.Receipt;
                    }

                    receiptDetailList.Add(receiptDetail);
                }
                else {
                    receipt = lazyContext.Receipt.Find(id);

                    if (!receipt.CanUndo(isBankReconciliation))
                        throw new UnreportedException(AppConstants.RecordCannotBeUndone);

                    receiptDetail = receipt.ReceiptDetails.FirstOrDefault();
                    receiptDetailList.Add(receiptDetail);
                }

                if (receipt.IsDeposit) {
                    var depositDetail = receipt.ReceiptDetails.Single();
                    depositDetail.UpdateDocumentStatus(lazyContext, DocumentStatus.DepositedPaid, -1, 0);

                    foreach (var row in lazyContext.ReceiptDetail.Where(t => t.DocumentStatus == DocumentStatus.Closed && t.DepositDetailId == depositDetail.Id).ToList()) {
                        row.UpdateDocumentStatus(lazyContext, DocumentStatus.DepositedPaid, -1, 0);
                    }
                }
                else {
                    var documentStatus = DocumentStatus.None;
                    int depositDetailId = 0;

                    foreach (var row in receiptDetailList) {
                        if (row.DocumentStatus == DocumentStatus.DepositedPaid) {
                            documentStatus = DocumentStatus.Open;
                            depositDetailId = -1;
                        }
                        else if (row.DocumentStatus == DocumentStatus.Closed) {
                            documentStatus = DocumentStatus.DepositedPaid;
                            depositDetailId = 0;
                        }

                        row.UpdateDocumentStatus(lazyContext, documentStatus, -1, depositDetailId);
                    }

                    foreach (var row in receiptDetailList.Where(t => t.Receipt.ReceiptType == ReceiptType.OtherCommission && t.Receipt.SupplierCommissionType == SupplierCommissionType.Creditor).Select(t => t.Receipt).Distinct()) {
                        foreach (var nonBsp in lazyContext.NonBsp.Where(t => t.SupplierOtherCommissionReceiptId == row.Id)) {
                            nonBsp.UpdateDocumentStatus(lazyContext, row.DocumentStatus);
                        }
                    }

                    foreach (var row in receiptDetailList.Where(t => t.LoyaltySchemeId > 0)) {
                        foreach (var nonBsp in lazyContext.NonBsp.Where(t => t.LoyaltySchemeReceiptDetailId == row.Id)) {
                            nonBsp.UpdateDocumentStatus(lazyContext, row.DocumentStatus);
                        }
                    }
                }

                ts.Complete();
                return true;
            }
        }

        public bool Reverse(AppLazyContext lazyContext, int receiptId, string type, bool validateStatus = true) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.Receipt.Find(receiptId);

                if (validateStatus && !q.CanReverse())
                    throw new UnreportedException(AppConstants.RecordCannotBeReversed);

                if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), q.DocumentDate, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                if (type == "CurrentDate" && !Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                var receipts = lazyContext.Receipt.AsQueryable();

                switch (q.AccountType) {
                    default:
                        throw new InvalidOperationException("Account Type is invalid.");
                    case AccountType.Client:
                        receipts = receipts.Where(t => t.Id == receiptId || (t.DocumentNo == q.DocumentNo && (t.ReceiptType == q.ReceiptType && t.IsSplit || (t.TripId > 0 && t.TripId == q.TripId))));
                        break;
                    case AccountType.Debtor:
                        receipts = receipts.Where(t => t.Id == receiptId || (t.DocumentNo == q.DocumentNo && (t.ReceiptType == q.ReceiptType && t.IsSplit || (t.DebtorId > 0 && t.DebtorId == q.DebtorId))));
                        break;
                    case AccountType.Creditor:
                        receipts = receipts.Where(t => t.Id == receiptId || (t.DocumentNo == q.DocumentNo && (t.ReceiptType == q.ReceiptType && t.IsSplit || (t.SupplierId > 0 && t.SupplierId == q.SupplierId))));
                        break;
                    case AccountType.GeneralLedger:
                        receipts = receipts.Where(t => t.Id == receiptId || (t.DocumentNo == q.DocumentNo && (t.ReceiptType == q.ReceiptType && t.IsSplit || (t.ChartOfAccountId > 0 && t.ChartOfAccountId == q.ChartOfAccountId))));
                        break;
                }

                var receiptDetailIds = new Dictionary<int, int>();

                foreach (var receipt in receipts.ToList()) {
                    var receiptClone = receipt.Clone() as Receipt;

                    receiptClone.Id = 0;
                    receiptClone.DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Receipt");

                    LastDocumentNo.DocumentNo(lazyContext, "Receipt", receiptClone.DocumentNo);

                    if (type == "CurrentDate")
                        receiptClone.DocumentDate = DateTime.Today;

                    receiptClone.NonCommissionable = -receiptClone.NonCommissionable;
                    receiptClone.NonCommissionableTax = -receiptClone.NonCommissionableTax;
                    receiptClone.Commission = -receiptClone.Commission;
                    receiptClone.CommissionTax = -receiptClone.CommissionTax;
                    receiptClone.Discount = -receiptClone.Discount;
                    receiptClone.DiscountTax = -receiptClone.DiscountTax;
                    receiptClone.CancellationFee = -receiptClone.CancellationFee;
                    receiptClone.CancellationFeeTax = -receiptClone.CancellationFeeTax;
                    receiptClone.SupplierCancellationFee = -receiptClone.SupplierCancellationFee;
                    receiptClone.SupplierCancellationFeeTax = -receiptClone.SupplierCancellationFeeTax;
                    receiptClone.AmountToBank = 0;
                    receiptClone.AmountToBankTax = 0;

                    lazyContext.Insert(receiptClone);
                    lazyContext.Entry(receiptClone).State = EntityState.Detached;

                    receiptClone = lazyContext.Receipt.Find(receiptClone.Id);
                    Validate(receiptClone, false, false);

                    ReceiptDetail receiptDetailClone = null;

                    foreach (var receiptDetail in receipt.ReceiptDetails) {
                        receiptDetailClone = receiptDetail.Clone() as ReceiptDetail;
                        receiptDetailClone.Id = 0;
                        receiptDetailClone.ReceiptId = receiptClone.Id;
                        receiptDetailClone.DocumentStatus = receiptDetail.GetDocumentStatus();
                        receiptDetailClone.ReversalStatus = ReversalStatus.Reversal;
                        receiptDetailClone.LoyaltySchemePointsCollected = -receiptDetail.LoyaltySchemePointsCollected;
                        receiptDetailClone.LoyaltySchemePointsCost = -receiptDetail.LoyaltySchemePointsCost;
                        receiptDetailClone.LoyaltySchemeValue = -receiptDetail.LoyaltySchemeValue;
                        receiptDetailClone.Amount = -receiptDetail.Amount;
                        receiptDetailClone.Tax = -receiptDetail.Tax;
                        receiptDetailClone.MerchantFee = -receiptDetail.MerchantFee;
                        receiptDetailClone.MerchantFeeTax = -receiptDetail.MerchantFeeTax;
                        receiptDetailClone.VoucherId = -1;
                        receiptDetailClone.TicketedFare = -receiptDetail.TicketedFare;
                        receiptDetailClone.OfferedFare = -receiptDetail.OfferedFare;
                        receiptDetailClone.VoucherIsPartiallyReceipted = false;
                        receiptDetailClone.DepositDetailId = -1;
                        receiptDetailClone.BankAccountStatementId = -1;

                        lazyContext.Insert(receiptDetailClone, false);
                        receiptDetail.UpdateReversalStatus(lazyContext, ReversalStatus.Reversed, -1);

                        receiptDetailIds.Add(receiptDetail.Id, receiptDetailClone.Id);
                    }

                    lazyContext.Entry(receiptClone).State = EntityState.Detached;
                    receiptClone = lazyContext.Receipt.Find(receiptClone.Id);

                    receiptClone.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, receiptClone.ReceiptDetails[0]?.TripLine);

                    foreach (var nonBspDetail in receiptClone.SupplierOtherCommissionNonBsps.SelectMany(t => t.NonBspDetails).Where(t => t.Id > 0)) {
                        nonBspDetail.UpdateReversalStatus(lazyContext, ReversalStatus.Reversed);
                    }

                    foreach (var nonBspDetail in receiptClone.ReceiptDetails.SelectMany(t => t.LoyaltySchemeNonBsps).SelectMany(t => t.NonBspDetails).Where(t => t.Id > 0)) {
                        nonBspDetail.UpdateReversalStatus(lazyContext, ReversalStatus.Reversed);
                    }

                    foreach (var tripLine in receiptClone.ReceiptDetails.Where(t => t.TripLineId > 0).Select(t => t.TripLine).Distinct().ToList()) {
                        tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                    }

                    int i = -1;
                    string documentNo = null;

                    foreach (var nonBspClone in lazyContext.NonBsp.Where(t1 => receiptDetailIds.Select(t2 => t2.Key).Contains(t1.LoyaltySchemeReceiptDetailId)).ToList()) {
                        i++;

                        if (i == 0)
                            documentNo = NonBspCommon.GetReversedDocumentNo(lazyContext, nonBspClone.DocumentNo);

                        nonBspClone.LoyaltySchemeReceiptDetailId = receiptDetailIds[nonBspClone.LoyaltySchemeReceiptDetailId];
                        new NonBspCommon(HttpContext).Reverse(lazyContext, nonBspClone.Id, type, false, documentNo);
                    }

                    foreach (var nonBspClone in lazyContext.NonBsp.Where(t => receipt.Id == t.SupplierOtherCommissionReceiptId).ToList()) {
                        nonBspClone.SupplierOtherCommissionReceiptId = receiptClone.Id;
                        new NonBspCommon(HttpContext).Reverse(lazyContext, nonBspClone.Id, type, false);
                    }
                }

                ts.Complete();
                return true;
            }
        }

        public bool CreateOrUpdateSupplierOtherCommissionNonBsp(Receipt receipt) {
            if (receipt.ReceiptType != ReceiptType.OtherCommission || receipt.SupplierCommissionType != SupplierCommissionType.Creditor)
                throw new InvalidOperationException("Receipt Type is invalid.");

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                var nonBsp = lazyContext.NonBsp.SingleOrDefault(t => t.SupplierOtherCommissionReceiptId == receipt.Id) ?? new NonBsp { Id = 0, SupplierOtherCommissionReceiptId = receipt.Id };

                nonBsp.NonBspType = NonBspType.Other;
                nonBsp.DocumentNo = receipt.DocumentNo;
                nonBsp.DocumentDate = receipt.DocumentDate;
                nonBsp.TripId = -1;
                nonBsp.TripLineId = -1;
                nonBsp.CreditorId = receipt.CreditorId;
                nonBsp.SupplierId = receipt.SupplierId;
                nonBsp.ChartOfAccountId = -1;
                nonBsp.AirlineId = -1;
                nonBsp.DepartureDate = DateTime.MinValue;
                nonBsp.OfferedReasonId = -1;
                nonBsp.SaleTypeId = -1;
                nonBsp.CategoryId = -1;
                nonBsp.DestinationId = -1;
                nonBsp.AgencyId = receipt.ChartOfAccount.AgencyId;
                nonBsp.ConsultantId = receipt.ConsultantId;
                nonBsp.AgentId = -1;
                nonBsp.SourceId = -1;
                nonBsp.DiscountReasonId = -1;
                nonBsp.MarkupStrategyId = -1;
                nonBsp.AgencyCreditCardBspId = -1;
                nonBsp.AgencyCreditCardNonBspId = -1;
                nonBsp.LoyaltySchemeReceiptDetailId = -1;
                nonBsp.SupplierOtherCommissionReceiptId = receipt.Id;
                nonBsp.AmountPayable = receipt.GetTotalAmountGross();
                nonBsp.PaymentId = -1;
                nonBsp.Comments = string.Empty;

                bool result;

                if (nonBsp.Id <= 0) {
                    result = lazyContext.Insert(nonBsp);
                }
                else {
                    result = lazyContext.Save(nonBsp);
                }

                var nonBspDetail = nonBsp.NonBspDetails.SingleOrDefault() ?? new NonBspDetail();

                nonBspDetail.NonBspId = nonBsp.Id;
                nonBspDetail.DocumentStatus = DocumentStatus.Open;
                nonBspDetail.ReversalStatus = ReversalStatus.None;
                nonBspDetail.TripLineAirPassengerId = -1;
                nonBspDetail.PassengerId = -1;
                nonBspDetail.FormOfPaymentId = -1;
                nonBspDetail.Amount = receipt.GetTotalAmount();
                nonBspDetail.Tax = receipt.GetTotalTax();

                if (nonBspDetail.Id <= 0) {
                    result = lazyContext.Insert(nonBspDetail);
                }
                else {
                    result = lazyContext.Save(nonBspDetail);
                }

                lazyContext.Entry(nonBsp).State = EntityState.Detached;
                nonBsp = lazyContext.NonBsp.Find(nonBsp.Id);
                nonBsp.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, nonBsp.TripLine);

                return result;
            }
        }

        public bool CreateOrUpdateReverseTransferReceipt(Receipt receipt) {
            if (receipt.ReceiptType != ReceiptType.Transfer)
                throw new InvalidOperationException("Receipt Type is invalid.");

            if (receipt.DocumentStatus != DocumentStatus.DepositedPaid)
                return false;

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                var receiptClone = lazyContext.Receipt.SingleOrDefault(t => t.ReverseTransferReceiptId == receipt.Id);

                if (receiptClone == null) {
                    receiptClone = receipt.Clone() as Receipt;
                    receiptClone.Id = 0;
                }

                receiptClone.BankAccountId = (lazyContext.BankAccount.SingleOrDefault(t => t.ChartOfAccountId == receipt.ChartOfAccountId) ?? new BankAccount { Id = -1 }).Id;
                receiptClone.ChartOfAccountId = receipt.BankAccount.ChartOfAccountId;
                receiptClone.ReverseTransferReceiptId = receipt.Id;

                bool result;

                if (receiptClone.Id <= 0) {
                    result = lazyContext.Insert(receiptClone);
                }
                else {
                    result = lazyContext.Save(receiptClone);
                }

                receipt.ReverseTransferReceiptId = receiptClone.Id;
                lazyContext.Save(receipt, false);

                if (result) {
                    foreach (var row in receipt.ReceiptDetails) {
                        var receiptDetailClone = row.Clone() as ReceiptDetail;
                        receiptDetailClone.Id = 0;
                        receiptDetailClone.ReceiptId = receiptClone.Id;
                        receiptDetailClone.Amount = -row.Amount;
                        lazyContext.Insert(receiptDetailClone);
                    }
                }

                if (receiptClone.ReceiptDetails.Count > 0) {
                    var receiptDetailClone = receiptClone.ReceiptDetails[0];
                    lazyContext.Entry(receiptClone).State = EntityState.Detached;
                    lazyContext.Entry(receiptDetailClone).State = EntityState.Detached;
                    receiptDetailClone = lazyContext.ReceiptDetail.Find(receiptDetailClone.Id);
                    receiptDetailClone.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, receiptDetailClone.TripLine);
                }

                return result;
            }
        }

        public bool CreateReceiptVoucherCommission(AppLazyContext lazyContext, string receiptVoucherCommissionModels, string receiptVoucherCommissionDetailModels, DateTime documentDate, int bankAccountId, int chartOfAccountId, int formOfPaymentId, int paymentMethodId) {
            if (!ChartOfAccount.IsInRole(lazyContext, chartOfAccountId, HttpContext.RoleId()))
                throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

            var models = JsonSerializer.Deserialize<List<ReceiptVoucherCommissionViewModel>>(receiptVoucherCommissionModels, JsonExtensionsBiz.JsonSerializerOptions());
            var detailModels = JsonSerializer.Deserialize<List<ReceiptVoucherCommissionViewModel>>(receiptVoucherCommissionDetailModels, JsonExtensionsBiz.JsonSerializerOptions());

            if (models == null || detailModels == null)
                return false;

            using (var ts = Utils.CreateTransactionScope()) {
                decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), documentDate);
                string documentNo = string.Empty;
                int i = -1;

                var q = models.GroupBy(t => new { t.TripId, t.CreditorId, t.SupplierId, t.SourceId, t.CategoryId, t.SaleTypeId, t.ConsultantId }).ToList();
                bool isSplit = q.Count > 1;

                foreach (var model in q) {
                    i++;

                    var receiptModel = new ReceiptViewModel {
                        ReceiptId = i == 0 ? 0 : -2,
                        ReceiptAccountType = AccountType.Creditor,
                        ReceiptType = ReceiptType.VoucherCommission,
                        ReceiptDocumentStatus = DocumentStatus.Open,
                        ReceiptNewDocumentNo = documentNo,
                        ReceiptDocumentDate = documentDate,
                        ReceiptPayer = string.Empty,
                        ReceiptTripId = model.Key.TripId,
                        ReceiptDebtorId = -1,
                        ReceiptCreditorId = model.Key.CreditorId,
                        ReceiptSupplierId = model.Key.SupplierId,
                        ReceiptChartOfAccountId = chartOfAccountId,
                        ReceiptBankAccountToId = bankAccountId,
                        ReceiptSaleTypeId = model.Key.SaleTypeId,
                        ReceiptCategoryId = model.Key.CategoryId,
                        ReceiptAgencyId = HttpContext.CurrentDefaultAgencyId(),
                        ReceiptConsultantId = model.Key.ConsultantId,
                        ReceiptSourceId = model.Key.SourceId,
                        ReceiptStandardCommentId = -1,
                        ReceiptDiscountReasonId = -1,
                        ReceiptCancellationSaleTypeId = -1,
                        ReceiptStandardComment = string.Empty,
                        ReceiptIsSplit = isSplit
                    };

                    CreateOrUpdate(receiptModel, false, 0, 0, 0, true, TransactionUpdateType.None);
                    documentNo = receiptModel.ReceiptDocumentNo;

                    decimal amount = 0;
                    decimal ticketedFare = 0;
                    int j = 0;

                    var modelList = model.Where(t => t.Amount != 0).ToList();
                    ReceiptDetailViewModel receiptDetailModel = null;

                    foreach (var row in modelList) {
                        j++;
                        var detailModel = detailModels.SingleOrDefault(t1 => t1.VoucherId == row.VoucherId) ?? row;

                        amount += detailModel.Amount;
                        ticketedFare += detailModel.TicketedFare;

                        receiptDetailModel = new ReceiptDetailViewModel {
                            ReceiptDetailId = 0,
                            ReceiptId = receiptModel.ReceiptId,
                            ReceiptDetailDocumentStatus = DocumentStatus.Open,
                            ReceiptDetailReversalStatus = ReversalStatus.None,
                            ReceiptDetailTripLineId = -1,
                            ReceiptDetailTripLineAirPassengerId = -1,
                            ReceiptDetailPassengerId = -1,
                            ReceiptDetailFormOfPaymentId = formOfPaymentId,
                            ReceiptDetailPaymentMethodId = paymentMethodId,
                            ReceiptDetailLoyaltySchemeId = -1,
                            ReceiptDetailAmount = row.Amount,
                            ReceiptDetailTax = 0,
                            ReceiptDetailVoucherId = row.VoucherId,
                            ReceiptDetailClass = detailModel.Class.ToStringExt().ToUpper(),
                            ReceiptDetailDaysAway = detailModel.DaysAway,
                            ReceiptDetailTicketedFare = detailModel.TicketedFare,
                            ReceiptDetailOfferedFare = detailModel.OfferedFare,
                            ReceiptDetailOfferedReasonId = detailModel.OfferedReasonId ?? 0,
                            ReceiptDetailVoucherIsPartiallyReceipted = !row.IsFullyPaid,
                            ReceiptDetailIsTaxApplicable = receiptModel.ReceiptIsTaxApplicable,
                            ReceiptDetailComments = string.Empty,
                        };

                        if (j == modelList.Count) {
                            var receipt = lazyContext.Receipt.Find(receiptModel.ReceiptId);
                            receipt.AmountToBank = amount;
                            receipt.OriginalSaleTotal = ticketedFare;

                            if (receipt.AmountToBank > 0 && receipt.IsTaxApplicable) {
                                receipt.AmountToBankTax = Math.Round(receipt.AmountToBank * taxRate / (1 + taxRate), 2);
                                receipt.AmountToBank -= receipt.AmountToBankTax;
                            }

                            if (receipt.OriginalSaleTotal > 0 && receipt.IsTaxApplicable) {
                                receipt.OriginalSaleTotalTax = Math.Round(receipt.OriginalSaleTotal * taxRate / (1 + taxRate), 2);
                                receipt.OriginalSaleTotal -= receipt.OriginalSaleTotalTax;
                            }

                            lazyContext.Save(receipt, false);
                        }

                        new ReceiptDetailCommon(HttpContext).CreateOrUpdate(receiptDetailModel, null, false, TransactionMatchViewStatus.NotSaved, true, false, false, TransactionUpdateType.None);
                    }

                    if (receiptDetailModel != null)
                        new ReceiptDetailCommon(HttpContext).CreateOrUpdate(receiptDetailModel, null, false, TransactionMatchViewStatus.NotSaved, true, false, false, TransactionUpdateType.Bulk);
                }

                ts.Complete();
                return true;
            }
        }

        public bool CreateOrUpdateCustomerTransaction(AppLazyContext lazyContext, Receipt receipt) {
            if (receipt.Debtor?.CustomerId == 0 || receipt.AccountType != AccountType.Debtor)
                return false;

            using (var adminContext = new AppAdminContext(HttpContext.User)) {
                int[] customerTxnIds = receipt.ReceiptDetails.Select(t => t.CustomerTransactionId).Distinct().ToArray();
                var customerTxn = adminContext.CustomerTransaction.SingleOrDefault(t => customerTxnIds.Contains(t.Id));

                customerTxn ??= adminContext.CustomerTransaction.Where(t => t.CustomerId == receipt.Debtor.CustomerId && t.DocumentNo == receipt.DocumentNo && t.Document != null).AsEnumerable().FirstOrDefault(t => t.IsReceiptItem);

                if (customerTxn != null)
                    return false;

                var customerTxnModel = new CustomerTransactionViewModel {
                    CustomerTransactionId = customerTxn?.Id ?? 0,
                    CustomerTransactionCustomerId = receipt.Debtor.CustomerId,
                    CustomerTransactionType = CustomerTransactionType.DirectDeposit,
                    CustomerTransactionApprovalStatus = CustomerTransactionApprovalStatus.Approved,
                    CustomerTransactionDateFrom = receipt.DocumentDate,
                    CustomerTransactionDateTo = receipt.DocumentDate,
                    CustomerTransactionDateDue = receipt.DocumentDate.AddDays(AppSettings.CustomerPaymentTermsDays),
                    CustomerTransactionUserCount = 0,
                    CustomerTransactionUserCharge = 0,
                    CustomerTransactionAmountGross = receipt.ReceiptDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0,
                    CustomerTransactionTax = receipt.ReceiptDetails.Sum(t => (decimal?)t.Tax) ?? 0,
                    CustomerTransactionDocumentNo = receipt.DocumentNo,
                    PaymentTransactionId = 0,
                    CustomerTransactionDescription = "Direct Deposit",
                    IsUserCreated = false
                };

                if (CustomerTransactionCommon.CreateOrUpdate(HttpContext, adminContext, lazyContext, customerTxnModel, CustomerTxnSource.ReceiptCreateOrUpdate, false, receipt)) {
                    foreach (var receiptDetail in receipt.ReceiptDetails) {
                        receiptDetail.CustomerTransactionId = customerTxnModel.CustomerTransactionId;
                        lazyContext.Save(receiptDetail, false);
                    }
                }
            }

            return true;
        }

        private bool DeleteCustomerTransactions(AppLazyContext lazyContext, Receipt receipt, bool resetPaymentTxn = false) {
            if (receipt.Debtor?.CustomerId == 0 || receipt.AccountType != AccountType.Debtor || receipt.ReceiptType != ReceiptType.Debtor)
                return false;

            using (var adminContext = new AppAdminContext(HttpContext.User)) {
                foreach (var receiptDetail in receipt.ReceiptDetails) {
                    int[] groupNos = lazyContext.TransactionDetailAllocation.Where(t => t.ReceiptDetailId == receiptDetail.Id).Select(t => t.GroupNo).Distinct().ToArray();
                    lazyContext.RemoveRange(lazyContext.TransactionDetailAllocation.Where(t => groupNos.Contains(t.GroupNo)));
                    lazyContext.SaveChanges();

                    var customerTxn = adminContext.CustomerTransaction.Find(receiptDetail.CustomerTransactionId);

                    if (customerTxn != null) {
                        if (resetPaymentTxn) {
                            foreach (var txn in adminContext.CustomerTransaction.Where(t => t.PaymentTransactionId > 0 && t.PaymentTransactionId == customerTxn.PaymentTransactionId)) {
                                txn.PaymentTransactionId = 0;
                                adminContext.Save(txn, false);
                            }
                        }

                        adminContext.Delete(customerTxn);
                    }
                }
            }

            return true;
        }

        public bool IssueDocument(AppLazyContext lazyContext, ReceiptViewModel model, string documentNo, int? tripId = null) {
            List<Receipt> receipts = null;

            if (tripId == null) {
                if (model.ReceiptAccountType == AccountType.Client && model.ReceiptTripId <= 0) {
                    throw new UnreportedException("Receipt cannot be issued because it is not assigned to a Trip.");
                }
                else if (model.ReceiptAccountType == AccountType.GeneralLedger || model.ReceiptType == ReceiptType.Transfer) {
                    throw new UnreportedException("Admin and Transfer receipts cannot be issued.");
                }

                var receipt = lazyContext.Receipt.Find(model.ReceiptId);

                if (receipt != null)
                    receipts = new List<Receipt> { receipt };
            }
            else {
                receipts = lazyContext.Receipt.Where(t => t.TripId == tripId).ToList();
            }

            if (receipts == null || receipts.Count == 0)
                throw new UnreportedException("No receipts have been created for this Trip.");

            if (receipts.Sum(t => t.GetTotalAmountGross()) == 0)
                throw new UnreportedException("Receipt cannot be issued with zero value.");

            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var receipt in receipts) {
                    receipt.IsIssued = true;
                    lazyContext.Save(receipt);

                    var q = lazyContext.IssuedDocument.SingleOrDefault(t => t.IssuedDocumentType == IssuedDocumentType.Receipt && t.TripId == receipt.TripId && t.DebtorId == receipt.DebtorId && t.CreditorId == receipt.CreditorId && t.Receipt.DocumentNo == documentNo);

                    if (q != null)
                        continue;

                    TypeReportSource reportSource;

                    if (HttpContext.CustomerSettings().IsManagementCustomer) {
                        reportSource = AccountingDataSources.GetCustomerReceiptReportSource(HttpContext.CurrentCustomerId(), HttpContext.User.Identity.Name, receipt);
                    }
                    else {
                        reportSource = AccountingDataSources.GetReceiptReportSource(lazyContext, HttpContext.CurrentCustomerId(), HttpContext.User.Identity.Name, receipt.Id, receipt.DocumentNo, HttpContext.Now(), HttpContext.UserFullName());
                    }

                    var result = Utils.ExportToPdf(reportSource);

                    q = new IssuedDocument {
                        Id = 0,
                        IssuedDocumentType = IssuedDocumentType.Receipt,
                        TripId = receipt.TripId,
                        DebtorId = receipt.DebtorId,
                        CreditorId = receipt.CreditorId,
                        ReceiptId = receipt.Id,
                        InvoiceId = -1,
                        VoucherId = -1,
                        Name = IssuedDocument.GetReceiptName(receipt.ReceiptType, receipt.DocumentNo),
                        FileExtension = "pdf",
                        Document = result.DocumentBytes
                    };

                    lazyContext.Insert(q);
                }

                ts.Complete();
                return true;
            }
        }

        private static string GetReversedDocumentNo(AppMainContext context, string documentNo) {
            char suffix = Convert.ToChar(documentNo.Right(1).ToUpper());

            if (suffix >= 65 && suffix <= 89) {
                suffix = Convert.ToChar(suffix + 1);
                documentNo = documentNo.Left(documentNo.Length - 1);
            }
            else {
                suffix = 'A';
            }

            while (context.Receipt.Any(t => t.DocumentNo == string.Format("{0}{1}", documentNo, suffix))) {
                if (suffix == 'Z') {
                    documentNo += "A";
                    suffix = 'A';
                    continue;
                }

                suffix = Convert.ToChar(suffix + 1);
            }

            return string.Format("{0}{1}", documentNo, suffix);
        }
    }

    public class ReceiptDetailCommon {
        private HttpContext HttpContext { get; }

        public ReceiptDetailCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool ValidateAndSave(AppLazyContext lazyContext, ReceiptDetail receiptDetail, bool validateDocumentStatus = true, bool performRelatedUpdates = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow, List<ReceiptMerchantFeeModel> merchantFees = null, int oldTripLineId = 0) {
            Validate(receiptDetail, false, validateDocumentStatus);

            if (receiptDetail.TripLineId <= 0 && receiptDetail.TripLine.TripId <= 0)
                receiptDetail.TripLine.Trip = receiptDetail.Receipt.Trip;

            bool result;

            if (receiptDetail.Id <= 0) {
                result = lazyContext.Insert(receiptDetail);
            }
            else {
                result = lazyContext.Save(receiptDetail);
            }

            if (!result && !performRelatedUpdates)
                return false;

            if (txnUpdateType == TransactionUpdateType.Bulk) {
                receiptDetail.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, null, merchantFees);

                foreach (var tripLine in receiptDetail.Receipt.ReceiptDetails.Where(t => t.TripLineId > 0).Select(t => t.TripLine).Distinct().ToList()) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }
            else if (txnUpdateType == TransactionUpdateType.SingleRow) {
                receiptDetail.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, receiptDetail.TripLine, merchantFees);
            }

            if (oldTripLineId > 0) {
                var tripLine = lazyContext.TripLine.Find(oldTripLineId);
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (receiptDetail.TripLineId <= 0 && receiptDetail.Receipt.Trip?.Id > 0)
                receiptDetail.Receipt.Trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            if (receiptDetail.LoyaltySchemeId > 0) {
                return CreateLoyaltySchemeNonBsp(receiptDetail);
            }
            else if (receiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission && receiptDetail.Receipt.SupplierCommissionType == SupplierCommissionType.Creditor) {
                return new ReceiptCommon(HttpContext).CreateOrUpdateSupplierOtherCommissionNonBsp(receiptDetail.Receipt);
            }
            else if (receiptDetail.Receipt.ReceiptType == ReceiptType.Transfer && receiptDetail.Receipt.ReverseTransferReceiptId <= 0) {
                return new ReceiptCommon(HttpContext).CreateOrUpdateReverseTransferReceipt(receiptDetail.Receipt);
            }

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, ReceiptDetail receiptDetail, bool validateDocumentStatus = true) {
            Validate(receiptDetail, true, validateDocumentStatus);

            if (receiptDetail.TripLineId <= 0 && receiptDetail.TripLine.TripId <= 0)
                receiptDetail.TripLine.Trip = receiptDetail.Receipt.Trip;

            var tripLine = receiptDetail.TripLine;

            DeleteCustomerTransaction(lazyContext, receiptDetail);

            lazyContext.RemoveRange(lazyContext.NonBsp.Where(t => t.LoyaltySchemeReceiptDetailId == receiptDetail.Id));
            lazyContext.SaveChanges();

            if (lazyContext.Delete(receiptDetail))
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return true;
        }

        public void Validate(ReceiptDetail receiptDetail, bool isDeletion, bool validateDocumentStatus = true) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), receiptDetail.Receipt.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !receiptDetail.CanDelete(HttpContext.IsAdministrator(), HttpContext.IsAccounts(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !receiptDetail.CanEdit(HttpContext.IsAdministrator(), HttpContext.IsAccounts(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public bool CreateOrUpdate(ReceiptViewModel model, ReceiptDetailViewModel detailModel, bool isNew, List<TransactionDetailAllocationModel> allocationList = null, bool allocationListIsConsolidated = false, TransactionMatchViewStatus transactionMatchViewStatus = TransactionMatchViewStatus.NotSaved) {
            using (var ts = Utils.CreateTransactionScope()) {
                new ReceiptCommon(HttpContext).CreateOrUpdate(model, !isNew, detailModel.ReceiptDetailId, detailModel.ReceiptDetailAmount, detailModel.ReceiptDetailTax, false, TransactionUpdateType.None);
                detailModel.ReceiptId = model.ReceiptId;
                CreateOrUpdate(detailModel, allocationList, allocationListIsConsolidated, transactionMatchViewStatus, model.ReceiptIsTaxIncluded, true, !isNew);
                ts.Complete();
                return true;
            }
        }

        public bool CreateOrUpdate(ReceiptDetailViewModel model, List<TransactionDetailAllocationModel> allocationList, bool allocationListIsConsolidated, TransactionMatchViewStatus transactionMatchViewStatus, bool isTaxIncluded, bool validateLimits, bool validateDocumentStatus = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    var receipt = lazyContext.Receipt.Find(model.ReceiptId);

                    if (!(receipt.AccountType == AccountType.GeneralLedger && receipt.ReceiptType == ReceiptType.Admin))
                        model.ReceiptDetailIsTaxApplicable = receipt.IsTaxApplicable;

                    if (receipt.AccountType == AccountType.Debtor && receipt.Debtor.IsCreditCardDebtor && allocationList?.Count > 0) {
                        model.ReceiptDetailAmount = allocationList.Sum(t => t.Amount);
                        model.ReceiptDetailTax = 0;
                    }

                    ReceiptDetail q = null;

                    int tripLineAirPassengerId = -1;
                    int passengerId = -1;
                    int loyaltySchemeId = -1;

                    decimal pointsCollected = 0;
                    decimal pointsCost = 0;
                    decimal loyaltySchemeValue = 0;
                    bool loyaltySchemeIsTaxApplicable = false;

                    decimal tax = 0;
                    decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), receipt.DocumentDate);
                    decimal amount = model.ReceiptDetailAmount;

                    bool deleteAutoGenerated = false;
                    bool updateDocumentStatus = false;

                    bool isNew = model.ReceiptDetailId <= 0;

                    if (isNew) {
                        updateDocumentStatus = true;

                        q = new ReceiptDetail {
                            Id = 0,
                            ReceiptId = model.ReceiptId,
                            ReversalStatus = ReversalStatus.None,
                            DepositDetailId = -1,
                            BankAccountStatementId = -1,
                            VoucherId = -1,
                            Class = string.Empty,
                            FormOfPaymentId = model.ReceiptDetailFormOfPaymentId ?? 0,
                            FormOfPayment = lazyContext.FormOfPayment.Find(model.ReceiptDetailFormOfPaymentId),
                            OfferedReasonId = -1,
                            LoyaltySchemeId = model.ReceiptDetailLoyaltySchemeId ?? 0,
                            LoyaltyScheme = lazyContext.FormOfPayment.Find(model.ReceiptDetailLoyaltySchemeId),
                            Comments = model.ReceiptDetailComments.ToStringExt(),
                            Receipt = receipt
                        };
                    }
                    else {
                        q = lazyContext.ReceiptDetail.Find(model.ReceiptDetailId);

                        if (q.FormOfPaymentId != model.ReceiptDetailFormOfPaymentId)
                            updateDocumentStatus = true;

                        deleteAutoGenerated = q.LoyaltySchemeId > 0 && model.ReceiptDetailLoyaltySchemeId <= 0;

                        q.FormOfPaymentId = model.ReceiptDetailFormOfPaymentId ?? 0;
                        q.FormOfPayment = lazyContext.FormOfPayment.Find(model.ReceiptDetailFormOfPaymentId);
                        q.LoyaltySchemeId = model.ReceiptDetailLoyaltySchemeId ?? 0;
                        q.LoyaltyScheme = lazyContext.FormOfPayment.Find(model.ReceiptDetailLoyaltySchemeId);
                    }

                    if (updateDocumentStatus)
                        q.DocumentStatus = q.GetDocumentStatus();

                    if ((receipt.AccountType == AccountType.Client && receipt.ReceiptType == ReceiptType.Receipt) || (receipt.AccountType == AccountType.Debtor && receipt.ReceiptType == ReceiptType.Debtor)) {
                        if (model.ReceiptDetailLoyaltySchemeId > 0) {
                            q.GetLoyaltySchemeCalculations("Amount", model.ReceiptDetailAmount, ref pointsCollected, ref pointsCost, ref loyaltySchemeValue, ref loyaltySchemeIsTaxApplicable);

                            if (model.ReceiptDetailAmount == 0 && model.ReceiptDetailTax == 0)
                                q.DocumentStatus = DocumentStatus.Closed;

                            if (q.LoyaltyScheme.LoyaltySchemeCostIsLocked)
                                model.ReceiptDetailLoyaltySchemePointsCost = pointsCost;

                            if (q.LoyaltyScheme.LoyaltySchemeValueIsLocked)
                                model.ReceiptDetailLoyaltySchemeValue = loyaltySchemeValue;

                            if (q.LoyaltyScheme.LoyaltySchemeCostIsLocked && q.LoyaltyScheme.LoyaltySchemeValueIsLocked)
                                model.ReceiptDetailLoyaltySchemePointsCollected = pointsCollected;

                            model.ReceiptDetailLoyaltySchemeIsTaxApplicable = loyaltySchemeIsTaxApplicable;

                            if (model.ReceiptDetailLoyaltySchemeIsPointsOnly && (model.ReceiptDetailLoyaltySchemeId <= 0 || model.ReceiptDetailLoyaltySchemeValue == 0))
                                throw new UnreportedException("Please complete Loyalty Scheme details.");
                        }
                        else if ((!receipt.Debtor.IsCreditCardDebtor || (allocationList?.Count ?? 0) == 0) && model.ReceiptDetailAmount + model.ReceiptDetailTax == 0) {
                            throw new UnreportedException(AppConstants.ZeroAmountWarning);
                        }
                    }
                    else if (model.ReceiptDetailAmount + model.ReceiptDetailTax == 0) {
                        throw new UnreportedException(AppConstants.ZeroAmountWarning);
                    }

                    if (receipt.AccountType == AccountType.Debtor && receipt.Debtor.IsCreditCardDebtor && q.FormOfPayment.Debtor.IsCreditCardDebtor)
                        throw new UnreportedException("This Form of Payment cannot be used because the selected debtor is a credit card debtor.");

                    if (model.ReceiptDetailFormOfPaymentId <= 0 && model.ReceiptDetailPaymentMethodId > 0)
                        model.ReceiptDetailFormOfPaymentId = lazyContext.PaymentMethod.Find(model.ReceiptDetailPaymentMethodId)?.FormOfPaymentId ?? -1;

                    if ((receipt.AccountType == AccountType.Client && receipt.ReceiptType == ReceiptType.Receipt) || (receipt.AccountType == AccountType.Debtor && receipt.ReceiptType == ReceiptType.Debtor) || (receipt.AccountType == AccountType.GeneralLedger && (receipt.TripId > 0 || receipt.DebtorId > 0))) {
                        tripLineAirPassengerId = model.ReceiptDetailTripLineAirPassengerId ?? 0;

                        if (tripLineAirPassengerId <= 0)
                            passengerId = model.ReceiptDetailPassengerId ?? 0;
                    }

                    if ((receipt.AccountType == AccountType.Client && receipt.ReceiptType == ReceiptType.Receipt) || (receipt.AccountType == AccountType.Debtor && receipt.ReceiptType == ReceiptType.Debtor)) {
                        loyaltySchemeId = model.ReceiptDetailLoyaltySchemeId ?? 0;
                        pointsCollected = model.ReceiptDetailLoyaltySchemePointsCollected;
                        pointsCost = model.ReceiptDetailLoyaltySchemePointsCost;
                        loyaltySchemeValue = model.ReceiptDetailLoyaltySchemeValue;
                    }
                    else if (((receipt.AccountType == AccountType.Creditor && (receipt.ReceiptType == ReceiptType.Refund || receipt.ReceiptType == ReceiptType.VoucherCommission || (receipt.ReceiptType == ReceiptType.OtherCommission && receipt.SupplierCommissionType == SupplierCommissionType.None))) || receipt.AccountType == AccountType.GeneralLedger) && model.ReceiptDetailIsTaxApplicable) {
                        if (isTaxIncluded) {
                            tax = Math.Round(amount * taxRate / (1 + taxRate), 2);
                            amount -= tax;
                        }
                        else {
                            tax = Math.Round(amount * taxRate, 2);
                        }

                        if (validateLimits) {
                            if (Math.Abs(model.ReceiptDetailTax - tax) > .02m)
                                throw new UnreportedException(string.Format("{0} value is outside accepted limits.", Resource.TaxLabel));

                            if (tax != model.ReceiptDetailTax) {
                                tax = model.ReceiptDetailTax;

                                if (isTaxIncluded)
                                    amount = model.ReceiptDetailAmount - tax;
                            }
                        }
                    }

                    if (receipt.AccountType == AccountType.Debtor && model.ReceiptDetailId > 0) {
                        if (receipt.Debtor.IsCreditCardDebtor) {
                            if ((allocationList?.Count ?? 0) == 0) {
                                if (-(q.TransactionDetailAllocations.Sum(t => (decimal?)t.Amount) ?? 0) != amount + tax)
                                    throw new UnreportedException("Amount for a credit card debtor must equal the total of all matches.");
                            }
                            else {
                                amount -= q.TransactionDetailAllocations.Sum(t => (decimal?)t.Amount) ?? 0;
                                tax = 0;
                            }
                        }
                        else if ((allocationList?.Count ?? 0) == 0 && -(q.TransactionDetailAllocations.Sum(t => (decimal?)t.Amount) ?? 0) > amount + tax) {
                            throw new UnreportedException("Amount cannot be less than the total of all matches.");
                        }
                    }

                    int oldTripLineId = q.Id > 0 && q.TripLineId != model.ReceiptDetailTripLineId ? q.TripLineId : 0;

                    q.TripLineId = model.ReceiptDetailTripLineId ?? 0;
                    q.TripLineAirPassengerId = tripLineAirPassengerId;
                    q.PassengerId = passengerId;
                    q.LoyaltySchemeId = loyaltySchemeId;
                    q.LoyaltySchemeReference = model.ReceiptDetailLoyaltySchemeReference.ToStringExt();
                    q.FormOfPaymentId = model.ReceiptDetailFormOfPaymentId ?? 0;
                    q.PaymentMethodId = model.ReceiptDetailPaymentMethodId ?? 0;
                    q.LoyaltySchemePointsCollected = pointsCollected;
                    q.LoyaltySchemePointsCost = pointsCost;
                    q.LoyaltySchemeValue = loyaltySchemeValue;
                    q.VoucherId = model.ReceiptDetailVoucherId ?? 0;
                    q.Class = model.ReceiptDetailClass.ToStringExt().ToUpper();
                    q.DaysAway = model.ReceiptDetailDaysAway;
                    q.TicketedFare = model.ReceiptDetailTicketedFare;
                    q.OfferedFare = model.ReceiptDetailOfferedFare;
                    q.OfferedReasonId = model.ReceiptDetailOfferedReasonId ?? 0;
                    q.VoucherIsPartiallyReceipted = model.ReceiptDetailVoucherIsPartiallyReceipted;
                    q.Amount = amount;
                    q.Tax = tax;
                    q.IsTaxApplicable = model.ReceiptDetailIsTaxApplicable;
                    q.Comments = model.ReceiptDetailComments.ToStringExt();

                    if (isNew) {
                        q.TripLine = lazyContext.TripLine.Find(q.TripLineId);
                        q.TripLineAirPassenger = lazyContext.TripLineAirPassenger.Find(q.TripLineAirPassengerId);
                        q.Passenger = lazyContext.Passenger.Find(q.PassengerId);
                        q.LoyaltyScheme = lazyContext.FormOfPayment.Find(q.LoyaltySchemeId);
                        q.FormOfPayment = lazyContext.FormOfPayment.Find(q.FormOfPaymentId);
                        q.OfferedReason = lazyContext.OfferedReason.Find(q.OfferedReasonId);
                        q.Voucher = lazyContext.Voucher.Find(q.VoucherId);
                    }

                    List<ReceiptMerchantFeeModel> merchantFees = null;

                    if (allocationList?.Count > 0 && q.Receipt.Debtor.IsCreditCardDebtor) {
                        if (q.Id <= 0) {
                            lazyContext.Insert(q, false);
                        }
                        else {
                            lazyContext.Save(q, false);
                        }

                        merchantFees = q.GetMerchantFees(lazyContext, taxRate, allocationList);

                        q.MerchantFee = merchantFees.Where(t => t.ReceiptDetailId == q.Id).Sum(t => (decimal?)t.MerchantFee) ?? 0;
                        q.MerchantFeeTax = merchantFees.Where(t => t.ReceiptDetailId == q.Id).Sum(t => (decimal?)t.MerchantFeeTax) ?? 0;
                    }

                    bool result = ValidateAndSave(lazyContext, q, validateDocumentStatus, true, txnUpdateType, merchantFees, oldTripLineId);
                    model.ReceiptDetailId = q.Id;

                    if (receipt.AccountType == AccountType.Creditor) {
                        if (!(receipt.ReceiptType == ReceiptType.VoucherCommission || (receipt.ReceiptType == ReceiptType.OtherCommission && receipt.SupplierCommissionType == SupplierCommissionType.None))) {
                            decimal originalSaleTotal = receipt.GetOriginalSaleTotal();
                            decimal originalSaleTotalTax = receipt.GetOriginalSaleTotalTax();

                            if (receipt.OriginalSaleTotal != originalSaleTotal || receipt.OriginalSaleTotalTax != originalSaleTotalTax) {
                                receipt.OriginalSaleTotal = originalSaleTotal;
                                receipt.OriginalSaleTotalTax = originalSaleTotalTax;
                                lazyContext.Save(receipt, false);
                            }
                        }

                        decimal amountToBank = receipt.GetAmountToBank();
                        decimal amountToBankTax = receipt.GetAmountToBankTax();

                        if (receipt.AmountToBank != amountToBank || receipt.AmountToBankTax != amountToBankTax) {
                            receipt.AmountToBank = amountToBank;
                            receipt.AmountToBankTax = amountToBankTax;
                            lazyContext.Save(receipt, false);
                        }

                        ValidateAndSave(lazyContext, q, validateDocumentStatus);

                        ts.Complete();
                        return result;
                    }

                    if (q.VoucherId > 0 && !q.VoucherIsPartiallyReceipted) {
                        receipt = lazyContext.Receipt.Find(model.ReceiptId);

                        foreach (var row in receipt.ReceiptDetails.Where(t => t.VoucherId == q.VoucherId && t.VoucherIsPartiallyReceipted)) {
                            row.VoucherIsPartiallyReceipted = false;
                            lazyContext.Save(row, false);
                        }
                    }

                    if (allocationList?.Count > 0) {
                        new TransactionDetailAllocationCommon(HttpContext).CreateOrUpdate(lazyContext, LedgerType.DebtorLedger, receipt.Debtor, 0, allocationList, allocationListIsConsolidated, false, false, transactionMatchViewStatus, model.ReceiptId, q.Id);

                        if (isNew && q.Receipt.Debtor.FormOfPayments.Any(t => t.MerchantFeeReducesCommission))
                            q.UpdateTransactions(lazyContext, HttpContext.CurrentCustomerId(), merchantFees);
                    }

                    if (deleteAutoGenerated) {
                        foreach (var loyaltySchemeNonBsp in lazyContext.NonBsp.Where(t => t.LoyaltySchemeReceiptDetailId == q.Id).ToList()) {
                            lazyContext.RemoveRange(loyaltySchemeNonBsp.Transactions.SelectMany(t => t.TransactionDetails).SelectMany(t => t.TransactionDetailAllocations));
                            lazyContext.RemoveRange(loyaltySchemeNonBsp.Transactions);
                            lazyContext.SaveChanges();

                            loyaltySchemeNonBsp.LoyaltySchemeReceiptDetailId = -1;
                            lazyContext.Save(loyaltySchemeNonBsp, false);

                            lazyContext.Delete(loyaltySchemeNonBsp, false);
                        }
                    }

                    ts.Complete();
                    return result;
                }
            }
        }

        public bool Delete(AppLazyContext lazyContext, ReceiptDetailViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.ReceiptDetail.Find(model.ReceiptDetailId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (q.Receipt.ReceiptDetails.Count == 1)
                    throw new UnreportedException(AppConstants.RecordCannotBeDeleted);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }

        public bool CreateLoyaltySchemeNonBsp(ReceiptDetail receiptDetail) {
            if (receiptDetail.LoyaltySchemeId <= 0)
                throw new InvalidOperationException("Loyalty Scheme is invalid.");

            if (!receiptDetail.LoyaltyScheme.Creditor.IsNonBspAgent)
                throw new UnreportedException("The creditor for the selected Loyalty Scheme is not able to make Non-BSP payments.");

            if ((receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType1Id <= 0 || receiptDetail.LoyaltyScheme.LoyaltySchemePointCost1 == 0) && (receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType2Id <= 0 || receiptDetail.LoyaltyScheme.LoyaltySchemePointCost2 == 0))
                throw new UnreportedException("Loyal Scheme information is invalid.");

            if (receiptDetail.LoyaltyScheme.LoyaltySchemePointCost1 + receiptDetail.LoyaltyScheme.LoyaltySchemePointCost2 == 0)
                throw new UnreportedException("Loyal Scheme information is invalid.");

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                lazyContext.RemoveRange(lazyContext.Transaction.Where(t => t.NonBsp.LoyaltySchemeReceiptDetailId == receiptDetail.Id));
                lazyContext.RemoveRange(lazyContext.NonBsp.Where(t => t.LoyaltySchemeReceiptDetailId == receiptDetail.Id));
                lazyContext.SaveChanges();

                decimal pointCost1 = receiptDetail.LoyaltySchemePointsCost * receiptDetail.LoyaltyScheme.LoyaltySchemePointCost1 / (receiptDetail.LoyaltyScheme.LoyaltySchemePointCost1 + receiptDetail.LoyaltyScheme.LoyaltySchemePointCost2);
                decimal pointCost2 = receiptDetail.LoyaltySchemePointsCost - pointCost1;

                decimal taxRate = 0;

                if (pointCost2 <= 0)
                    pointCost2 = 0;

                if (receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType1.IsTaxApplicable || receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType2.IsTaxApplicable)
                    taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), DateTime.Today);

                var nonBsp = new NonBsp {
                    Id = 0,
                    DocumentNo = receiptDetail.Receipt.DocumentNo,
                    DocumentDate = receiptDetail.Receipt.DocumentDate,
                    NonBspType = NonBspType.NonBsp,
                    TripId = receiptDetail.Receipt.TripId,
                    TripLineId = receiptDetail.TripLineId,
                    CreditorId = receiptDetail.LoyaltyScheme.CreditorId,
                    SupplierId = receiptDetail.LoyaltyScheme.DefaultSupplierId,
                    ChartOfAccountId = receiptDetail.Receipt.ChartOfAccountId,
                    AirlineId = -1,
                    AgencyId = receiptDetail.Receipt.AgencyId,
                    OfferedReasonId = -1,
                    DiscountReasonId = -1,
                    MarkupStrategyId = -1,
                    AgencyCreditCardBspId = -1,
                    AgencyCreditCardNonBspId = -1,
                    LoyaltySchemeReceiptDetailId = receiptDetail.Id,
                    SupplierOtherCommissionReceiptId = -1,
                    PaymentId = -1,
                    Comments = string.Empty
                };

                var nonBspDetail = new NonBspDetail {
                    Id = 0,
                    DocumentStatus = DocumentStatus.Open,
                    ReversalStatus = ReversalStatus.None,
                    TripLineAirPassengerId = -1,
                    PassengerId = -1,
                    FormOfPaymentId = receiptDetail.LoyaltySchemeId,
                };

                if (receiptDetail.Receipt.AccountType == AccountType.Client) {
                    nonBsp.DepartureDate = receiptDetail.Receipt.Trip.DepartureDate;
                    nonBsp.SourceId = receiptDetail.Receipt.Trip.SourceId;
                    nonBsp.CategoryId = receiptDetail.Receipt.Trip.CategoryId;
                    nonBsp.DestinationId = receiptDetail.Receipt.Trip.DestinationId;
                    nonBsp.ConsultantId = receiptDetail.Receipt.ConsultantId;
                    nonBsp.AgentId = receiptDetail.Receipt.Trip.AgentId;
                }
                else if (receiptDetail.Receipt.AccountType == AccountType.Debtor) {
                    nonBsp.DepartureDate = receiptDetail.Receipt.DocumentDate;
                    nonBsp.SourceId = receiptDetail.LoyaltyScheme.LoyaltySchemeSourceId;
                    nonBsp.CategoryId = receiptDetail.LoyaltyScheme.LoyaltySchemeCategoryId;
                    nonBsp.DestinationId = receiptDetail.LoyaltyScheme.LoyaltySchemeDestinationId;
                    nonBsp.ConsultantId = receiptDetail.LoyaltyScheme.LoyaltySchemeConsultantId;
                    nonBsp.AgentId = -1;
                }

                if (receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType1Id > 0 && receiptDetail.LoyaltyScheme.LoyaltySchemePointCost1 != 0) {
                    nonBsp.Id = 0;
                    nonBsp.SaleTypeId = receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType1Id;
                    nonBsp.Commission = -pointCost1;

                    if (receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType1.IsTaxApplicable)
                        nonBsp.CommissionTax = -Math.Round(pointCost1 * (taxRate / (1 + taxRate)), 2);

                    nonBsp.Commission -= nonBsp.CommissionTax;
                    nonBsp.AmountPayable = pointCost1;

                    if (lazyContext.Insert(nonBsp)) {
                        nonBspDetail.Id = 0;
                        nonBspDetail.NonBspId = nonBsp.Id;
                        nonBspDetail.IsTaxApplicable = receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType1.IsTaxApplicable;

                        if (lazyContext.Insert(nonBspDetail))
                            lazyContext.Entry(nonBspDetail).State = EntityState.Detached;

                        lazyContext.Entry(nonBsp).State = EntityState.Detached;
                        nonBsp = lazyContext.NonBsp.Find(nonBsp.Id);
                        nonBsp.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, nonBsp.TripLine);
                    }
                }

                if (receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType2Id > 0 && receiptDetail.LoyaltyScheme.LoyaltySchemePointCost2 != 0) {
                    lazyContext.Entry(nonBsp).State = EntityState.Detached;
                    lazyContext.Entry(nonBspDetail).State = EntityState.Detached;

                    nonBsp = nonBsp.Clone() as NonBsp;
                    nonBspDetail = nonBspDetail.Clone() as NonBspDetail;

                    nonBsp.Id = 0;
                    nonBsp.SaleTypeId = receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType2Id;
                    nonBsp.Commission = -pointCost2;

                    if (receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType2.IsTaxApplicable) {
                        nonBsp.CommissionTax = -Math.Round(pointCost2 * (taxRate / (1 + taxRate)), 2);
                    }
                    else {
                        nonBsp.CommissionTax = 0;
                    }

                    nonBsp.Commission -= nonBsp.CommissionTax;
                    nonBsp.AmountPayable = pointCost2;

                    if (lazyContext.Insert(nonBsp)) {
                        nonBspDetail.Id = 0;
                        nonBspDetail.NonBspId = nonBsp.Id;
                        nonBspDetail.IsTaxApplicable = receiptDetail.LoyaltyScheme.LoyaltySchemeSaleType2.IsTaxApplicable;

                        if (lazyContext.Insert(nonBspDetail))
                            lazyContext.Entry(nonBspDetail).State = EntityState.Detached;

                        lazyContext.Entry(nonBsp).State = EntityState.Detached;
                        nonBsp = lazyContext.NonBsp.Find(nonBsp.Id);
                        nonBsp.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, nonBsp.TripLine);
                    }
                }

                return true;
            }
        }

        private bool DeleteCustomerTransaction(AppLazyContext lazyContext, ReceiptDetail receiptDetail, bool resetPaymentTxn = false) {
            var receipt = receiptDetail.Receipt;

            if (receipt.Debtor?.CustomerId == 0 || receipt.AccountType != AccountType.Debtor || receipt.ReceiptType != ReceiptType.Debtor)
                return false;

            using (var adminContext = new AppAdminContext(HttpContext.User)) {
                int[] groupNos = lazyContext.TransactionDetailAllocation.Where(t => t.ReceiptDetailId == receiptDetail.Id).Select(t => t.GroupNo).Distinct().ToArray();
                lazyContext.RemoveRange(lazyContext.TransactionDetailAllocation.Where(t => groupNos.Contains(t.GroupNo)));
                lazyContext.SaveChanges();

                var customerTxn = adminContext.CustomerTransaction.Find(receiptDetail.CustomerTransactionId);

                if (customerTxn != null) {
                    if (resetPaymentTxn) {
                        foreach (var txn in adminContext.CustomerTransaction.Where(t => t.PaymentTransactionId > 0 && t.PaymentTransactionId == customerTxn.PaymentTransactionId)) {
                            txn.PaymentTransactionId = 0;
                            adminContext.Save(txn, false);
                        }
                    }

                    adminContext.Delete(customerTxn);
                }
            }

            return false;
        }
    }

    public class BspCommon {
        private HttpContext HttpContext { get; }

        public BspCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        private bool ValidateAndSave(AppLazyContext lazyContext, Bsp bsp, bool validateDocumentStatus = true, bool performRelatedUpdates = true, bool updateAutoGenerated = false, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow, int oldTripId = 0, int oldTripLineId = 0) {
            Validate(bsp, false, validateDocumentStatus);

            bool result;

            if (bsp.Id <= 0) {
                result = lazyContext.Insert(bsp);
            }
            else {
                result = lazyContext.Save(bsp);
            }

            if (!result && !performRelatedUpdates)
                return false;

            if (bsp.BspType == BspType.Conjunction || bsp.BspType == BspType.Free || bsp.BspType == BspType.Void) {
                var q = bsp.BspDetails.SingleOrDefault(t => t.BspId == bsp.Id);

                q ??= new BspDetail {
                    Id = 0,
                    BspId = bsp.Id,
                    DocumentStatus = DocumentStatus.Open,
                    ReversalStatus = ReversalStatus.None,
                    TripLineAirPassengerId = -1,
                    PassengerId = -1,
                    FormOfPaymentId = -1
                };

                new BspDetailCommon(HttpContext).ValidateAndSave(lazyContext, q, validateDocumentStatus);
            }

            if (txnUpdateType != TransactionUpdateType.None)
                bsp.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            ;

            if (oldTripId > 0) {
                foreach (var tripLine in lazyContext.Trip.Find(oldTripId).TripLines.Where(t => t.Id > 0).ToList()) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }
            else if (oldTripLineId > 0) {
                var tripLine = lazyContext.TripLine.Find(oldTripLineId);
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (bsp.TripLine?.Id > 0) {
                bsp.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }
            else if (bsp.Trip?.Id > 0) {
                bsp.Trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            var bspDetail = bsp.BspDetails.FirstOrDefault();

            if (updateAutoGenerated && bsp.BspType != BspType.AgencyCC && bspDetail != null && (bspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || bspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross))
                new BspDetailCommon(HttpContext).CreateOrUpdateAgencyCcBsp(bspDetail);

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, Bsp bsp, bool validateDocumentStatus = true) {
            Validate(bsp, true, validateDocumentStatus);

            if (lazyContext.Bsp.Any(t => t.AgencyCreditCardBspId == bsp.Id) || lazyContext.NonBsp.Any(t => t.AgencyCreditCardBspId == bsp.Id)) {
                var agencyCreditCardBsp = lazyContext.Bsp.SingleOrDefault(t => t.AgencyCreditCardBspId == bsp.Id);

                if (agencyCreditCardBsp != null) {
                    lazyContext.RemoveRange(agencyCreditCardBsp.Transactions);
                    lazyContext.SaveChanges();
                    lazyContext.Delete(agencyCreditCardBsp, false);
                }

                var agencyCreditCardNonBsp = lazyContext.NonBsp.SingleOrDefault(t => t.AgencyCreditCardBspId == bsp.Id);

                if (agencyCreditCardNonBsp != null) {
                    lazyContext.RemoveRange(agencyCreditCardNonBsp.Transactions);
                    lazyContext.SaveChanges();
                    lazyContext.Delete(agencyCreditCardNonBsp, false);
                }
            }

            if (HttpContext.IsSuperUser()) {
                int[] bspDetailIds = bsp.BspDetails.Select(t => t.Id).ToArray();
                lazyContext.RemoveRange(lazyContext.TransactionDetail.Where(t => bspDetailIds.Contains(t.BspDetailId)).SelectMany(t => t.TransactionDetailAllocations));
                lazyContext.SaveChanges();
            }

            lazyContext.RemoveRange(bsp.Transactions);
            lazyContext.SaveChanges();

            var payment = bsp.Payment;
            var tripLine = bsp.TripLine;

            bool result = lazyContext.Delete(bsp);

            if (payment.Id > 0) {
                if (!lazyContext.Bsp.Any(t => t.PaymentId == payment.Id && t.CreditorId == bsp.CreditorId)) {
                    lazyContext.Delete(payment, false);
                }
                else {
                    payment.AmountPayable = payment.GetAmountPayableGross(lazyContext, true);
                    lazyContext.Save(payment, false);
                }
            }

            if (result)
                return tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return false;
        }

        private void Validate(Bsp bsp, bool isDeletion, bool validateDocumentStatus = true) {
            if (!isDeletion && bsp.AgencyId <= 0)
                throw new UnreportedException(AppConstants.AgencyNotSpecified);

            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), bsp.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!bsp.Creditor.IsBspAgent && !isDeletion)
                throw new UnreportedException("The creditor assigned to this document cannot accept BSP returns.");

            if (!isDeletion && bsp.TripId > 0 && !bsp.Trip.IsBooking)
                throw new UnreportedException(AppConstants.RecordIsNotBooking);

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !bsp.CanDelete(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !bsp.CanEdit(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public bool CreateOrUpdate(BspViewModel model, bool validateLimits, bool validateDocumentStatus = true, bool performRelatedUpdates = true, bool updateAutoGenerated = false, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            if ((model.BspConsultantId ?? 0) <= 0)
                throw new UnreportedException("Consultant is required.");

            if (model.BspType == BspType.Conjunction || model.BspType == BspType.Free || model.BspType == BspType.Void || model.BspType == BspType.AdmNoAnalysis || model.BspType == BspType.AcmNoAnalysis) {
                model.BspSaleTypeId = -1;
            }
            else if (model.BspSaleTypeId <= 0) {
                throw new UnreportedException("Type of Sale is required.");
            }

            if (model.BspType == BspType.Conjunction || model.BspType == BspType.Free || model.BspType == BspType.Void) {
                model.BspDiscount = 0;
                model.BspDiscountReasonId = -1;
                model.BspMarkup = 0;
                model.BspMarkupStrategyId = -1;
                model.BspOfferedFare = 0;
                model.BspOfferedReasonId = -1;
            }
            else {
                if (model.BspDiscount != 0 && (model.BspDiscountReasonId ?? 0) <= 0)
                    throw new UnreportedException("Discount Reason is required when Discount is applied.");

                if (model.BspMarkup != 0 && (model.BspMarkupStrategyId ?? 0) <= 0)
                    throw new UnreportedException("Mark-Up Strategy is required when Mark-Up is applied.");

                if (model.BspOfferedFare != 0 && (model.BspOfferedReasonId ?? 0) <= 0)
                    throw new UnreportedException("Reason Rejected is required when Offered Fare is applied.");
            }

            model.BspDocumentNo = Utils.RemoveExtraSpaces(model.BspDocumentNo).Replace(" ", string.Empty).ToUpper();

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    model.BspDocumentNo = Bsp.GetUniqueDocumentNo(lazyContext, model.BspType, model.BspId, model.BspDocumentNo);

                    Bsp q = null;
                    bool documentDateUpdated = false;

                    if (model.BspId <= 0) {
                        q = new Bsp {
                            Id = 0,
                            BspType = model.BspType,
                            DocumentDate = model.BspDocumentDate ?? DateTime.MinValue,
                            SupplierId = model.BspSupplierId ?? 0,
                            Supplier = lazyContext.Supplier.Find(model.BspSupplierId),
                            TripId = model.BspTripId ?? 0,
                            Trip = lazyContext.Trip.Find(model.BspTripId),
                            TripLineId = model.BspTripLineId ?? 0,
                            TripLine = lazyContext.TripLine.Find(model.BspTripLineId),
                            CreditorId = model.BspCreditorId ?? 0,
                            Creditor = lazyContext.Creditor.Find(model.BspCreditorId),
                            AirlineId = model.BspAirlineId ?? 0,
                            Airline = lazyContext.Airline.Find(model.BspAirlineId),
                            SaleTypeId = model.BspSaleTypeId ?? 0,
                            SaleType = lazyContext.SaleType.Find(model.BspSaleTypeId),
                            AgencyId = HttpContext.CurrentDefaultAgencyId(),
                            AgencyCreditCardBspId = -1,
                            MarkupGrossOther = 0,
                            PaymentId = -1
                        };
                    }
                    else {
                        q = lazyContext.Bsp.Find(model.BspId);

                        if (!q.ValidateTaxApplicability(q.IsTaxApplicable))
                            throw new UnreportedException(AppConstants.TaxRelatedRecordCannotBeAltered);
                    }

                    if (model.BspAirlineId <= 0 && q.TripLine.TripLineType == TripLineType.Air && q.Supplier.SupplierServiceTypes.Any(t => t.ServiceType.TripLineType == TripLineType.Air))
                        throw new UnreportedException("Airline is required.");

                    decimal commission = 0;
                    decimal commissionTax = 0;
                    decimal discount = 0;
                    decimal discountTax = 0;
                    decimal markup = 0;
                    decimal markupTax = 0;
                    decimal supplierCancellationFee = 0;
                    decimal supplierCancellationFeeTax = 0;

                    if (q.BspType == BspType.Conjunction || q.BspType == BspType.Free || q.BspType == BspType.Void) {
                        model.BspSaleTypeId = -1;
                        model.BspDiscount = 0;
                        model.BspDiscountReasonId = -1;
                        model.BspMarkup = 0;
                        model.BspMarkupStrategyId = -1;
                        model.BspIsAutoInvoiced = false;
                    }
                    else {
                        if (!q.IsCommissionPermitted)
                            model.BspCommission = 0;

                        if (!q.IsDiscountPermitted) {
                            model.BspDiscount = 0;
                            model.BspDiscountReasonId = -1;
                            model.BspIsCreditCardDiscountApplicable = false;
                        }

                        if (!q.IsMarkupPermitted) {
                            model.BspMarkup = 0;
                            model.BspMarkupStrategyId = -1;
                            model.BspIncludeMarkupInCreditCardPayment = false;
                        }

                        if (!q.IsCancellationPermitted)
                            model.BspSupplierCancellationFee = 0;

                        documentDateUpdated = q.DocumentDate != model.BspDocumentDate;

                        commission = model.BspCommission;
                        commissionTax = 0;
                        discount = model.BspDiscount;
                        discountTax = 0;
                        markup = model.BspMarkup;
                        markupTax = 0;
                        supplierCancellationFee = model.BspSupplierCancellationFee;
                        supplierCancellationFeeTax = 0;

                        if (q.IsTaxApplicable) {
                            decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), (DateTime)model.BspDocumentDate);

                            supplierCancellationFeeTax = Math.Round(supplierCancellationFee * taxRate / (1 + taxRate), 2);
                            supplierCancellationFee -= supplierCancellationFeeTax;

                            if (model.BspIsTaxIncluded) {
                                commissionTax = Math.Round(commission * taxRate / (1 + taxRate), 2);
                                discountTax = Math.Round(discount * taxRate / (1 + taxRate), 2);
                                markupTax = Math.Round(markup * taxRate / (1 + taxRate), 2);
                                commissionTax = Math.Round(commission * taxRate / (1 + taxRate), 2);

                                commission -= commissionTax;
                                discount -= discountTax;
                                markup -= markupTax;
                            }
                            else {
                                commissionTax = Math.Round(commission * taxRate, 2);
                                discountTax = Math.Round(discount * taxRate, 2);
                                markupTax = Math.Round(markup * taxRate, 2);
                            }

                            if (validateLimits) {
                                if (Math.Abs(model.BspCommissionTax - commissionTax) > .02m)
                                    throw new UnreportedException(string.Format("{0} value is outside accepted limits.", Resource.CommissionTaxLabel));

                                commissionTax = model.BspCommissionTax;
                            }
                        }
                    }

                    int oldTripId = q.Id > 0 && q.TripId != model.BspTripId ? q.TripId : 0;
                    int oldTripLineId = q.Id > 0 && q.TripLineId != model.BspTripLineId ? q.TripLineId : 0;

                    if (!q.IsClientAccountLocked) {
                        q.TripId = model.BspTripId ?? 0;
                        q.TripLineId = model.BspTripLineId ?? 0;
                    }

                    q.DocumentNo = Bsp.GetUniqueDocumentNo(lazyContext, q.BspType, q.Id, model.BspDocumentNo);
                    q.DocumentDate = model.BspDocumentDate ?? DateTime.MinValue;
                    q.CreditorId = model.BspCreditorId ?? 0;
                    q.SupplierId = model.BspSupplierId ?? 0;
                    q.AirlineId = model.BspAirlineId ?? 0;
                    q.DepartureDate = model.BspDepartureDateStatus == DepartureDateStatus.Open ? DateTime.MinValue : model.BspDepartureDateStatus == DepartureDateStatus.ARNK ? lazyContext.VoidDate : model.BspDepartureDate ?? DateTime.Today;
                    q.OfferedFare = model.BspOfferedFare;
                    q.OfferedReasonId = model.BspOfferedReasonId ?? 0;
                    q.SaleTypeId = model.BspSaleTypeId ?? 0;
                    q.CategoryId = model.BspCategoryId ?? 0;
                    q.DestinationId = model.BspDestinationId ?? 0;
                    q.ConsultantId = model.BspConsultantId ?? 0;
                    q.AgentId = model.BspAgentId ?? 0;
                    q.SourceId = model.BspSourceId ?? 0;
                    q.Commission = commission;
                    q.CommissionTax = commissionTax;
                    q.Discount = discount;
                    q.DiscountTax = discountTax;
                    q.DiscountReasonId = model.BspDiscountReasonId ?? 0;
                    q.Markup = markup;
                    q.MarkupTax = markupTax;
                    q.MarkupStrategyId = model.BspMarkupStrategyId ?? 0;
                    q.MarkupGrossOther = q.GetMarkupGross();
                    q.SupplierCancellationFee = supplierCancellationFee;
                    q.SupplierCancellationFeeTax = supplierCancellationFeeTax;
                    q.IsCreditCardDiscountApplicable = model.BspIsCreditCardDiscountApplicable;
                    q.IncludeMarkupInCreditCardPayment = model.BspIncludeMarkupInCreditCardPayment;
                    q.IsAutoInvoiced = model.BspIsAutoInvoiced;
                    q.Comments = model.BspComments.ToStringExt();

                    //q.AgencyId = q.Trip.AgencyId;
                    q.AmountPayable = q.GetAmountPayable(lazyContext);

                    bool result = ValidateAndSave(lazyContext, q, validateDocumentStatus, performRelatedUpdates, updateAutoGenerated, txnUpdateType, oldTripId, oldTripLineId);

                    if (documentDateUpdated) {
                        foreach (var row1 in lazyContext.Bsp.Where(t => t.AgencyCreditCardBspId == q.Id).ToList()) {
                            row1.DocumentDate = q.DocumentDate;
                            lazyContext.Save(row1, false);

                            foreach (var row2 in row1.Transactions) {
                                row2.DocumentDate = q.DocumentDate;
                                lazyContext.Save(row2, false);
                            }
                        }

                        foreach (var row1 in lazyContext.NonBsp.Where(t => t.AgencyCreditCardBspId == q.Id).ToList()) {
                            row1.DocumentDate = q.DocumentDate;
                            lazyContext.Save(row1, false);

                            foreach (var row2 in row1.Transactions) {
                                row2.DocumentDate = q.DocumentDate;
                                lazyContext.Save(row2, false);
                            }
                        }
                    }

                    model.BspId = q.Id;
                    model.BspTripLineType = q.TripLine.TripLineType;
                    model.BspIsTaxApplicable = q.IsTaxApplicable;

                    ts.Complete();
                    return result;
                }
            }
        }

        public bool Delete(AppLazyContext lazyContext, BspViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.Bsp.Include(t => t.AgencyCreditCardBsp).SingleOrDefault(t => t.Id == model.BspId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }

        public bool ProcessSelections(AppLazyContext lazyContext, int[] bspIds, int documentStatusId, int bankAccountId, string documentNo, DateTime documentDate, DateTime returnDate, bool undo) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            var q = lazyContext.Bsp.First(t => bspIds.Contains(t.Id));

            int creditorId = q.CreditorId;
            int supplierId = q.SupplierId;

            var bsps = lazyContext.Bsp.Where(t => (bspIds.Contains(t.Id) || bspIds.Contains(t.AgencyCreditCardBspId)) && t.CreditorId == creditorId).Select(t => new {
                t.DocumentNo,
                t.DocumentDate,
                t.CreditorId,
                t.SupplierId
            }).Distinct();

            bspIds = lazyContext.Bsp.Where(t1 => bsps.Any(t2 => t2.DocumentNo == t1.DocumentNo && t2.DocumentDate == t1.DocumentDate && t2.CreditorId == t1.CreditorId && t2.SupplierId == t1.SupplierId)).Select(t => t.Id).ToArray();
            var documentStatus = (DocumentStatus)documentStatusId;

            if (undo) {
                foreach (int bspId in bspIds) {
                    Undo(lazyContext, bspId, false);
                }

                return true;
            }

            if (documentStatus != (int)DocumentStatus.Open)
                throw new UnreportedException(AppConstants.RecordStatusCannotBeChanged);

            Payment payment = null;

            int paymentId = 0;
            int i = -1;

            var bspList = lazyContext.BspDetail.Include(t => t.Bsp).Where(t => t.Bsp.PaymentId <= 0 && bspIds.Contains(t.BspId)).ToList();

            if (bspList.Count == 0)
                return false;

            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var row in bspList) {
                    i++;

                    var bspDetail = lazyContext.BspDetail.Find(row.Id);
                    var bsp = bspDetail.Bsp;

                    if (i == 0) {
                        payment = new Payment {
                            Id = 0,
                            PaymentType = PaymentType.BspReturn,
                            DocumentNo = Payment.GetUniqueDocumentNo(lazyContext, 0, bankAccountId, false, documentNo),
                            DocumentDate = documentDate,
                            ReturnDate = returnDate,
                            TripId = -1,
                            DebtorId = -1,
                            CreditorId = creditorId,
                            SupplierId = supplierId,
                            ChartOfAccountId = -1,
                            BankAccountId = bankAccountId,
                            Payee = string.Empty,
                            SaleTypeId = -1,
                            CategoryId = -1,
                            AgencyId = bsp.AgencyId,
                            ConsultantId = bsp.ConsultantId,
                            SourceId = -1,
                            AirlineId = -1,
                            Commission = 0,
                            CommissionTax = 0,
                            Discount = 0,
                            DiscountTax = 0,
                            DiscountReasonId = -1,
                            Markup = 0,
                            MarkupTax = 0,
                            MarkupStrategyId = -1,
                            IsAutoInvoiced = false,
                            Comments = string.Format("BSP {0:d} by {1}", returnDate, HttpContext.UserFullName()).Left(100)
                        };

                        if (lazyContext.Insert(payment)) {
                            paymentId = payment.Id;
                            lazyContext.Entry(payment).State = EntityState.Detached;
                            payment = lazyContext.Payment.Find(paymentId);
                        }
                    }

                    var paymentDetail = new PaymentDetail {
                        Id = 0,
                        PaymentId = paymentId,
                        DocumentStatus = DocumentStatus.DepositedPaid,
                        ReversalStatus = ReversalStatus.None,
                        TripLineId = bspDetail.Bsp.TripLineId,
                        TripLineAirPassengerId = bspDetail.TripLineAirPassengerId,
                        PassengerId = bspDetail.PassengerId,
                        FormOfPayment = bspDetail.FormOfPayment,
                        OfferedFare = bspDetail.Bsp.OfferedFare,
                        OfferedReasonId = bspDetail.Bsp.OfferedReasonId,
                        Amount = (bspDetail.Cash - bspDetail.CashNonCommissionable - bspDetail.CommissionProRata - bspDetail.SupplierCancellationFeeProRata) * bspDetail.Bsp.Sign,
                        Tax = (bspDetail.CashTax - bspDetail.CashNonCommissionableTax - bspDetail.CommissionTaxProRata - bspDetail.SupplierCancellationFeeTaxProRata) * bspDetail.Bsp.Sign,
                        NonCommissionable = bspDetail.CashNonCommissionable * bspDetail.Bsp.Sign,
                        NonCommissionableTax = bspDetail.CashNonCommissionableTax * bspDetail.Bsp.Sign,
                        BankAccountStatementId = -1
                    };

                    lazyContext.Insert(paymentDetail);

                    if (bspDetail.Bsp.CreditorId == creditorId && bspDetail.DocumentStatus == DocumentStatus.Open)
                        bspDetail.UpdateDocumentStatus(lazyContext, DocumentStatus.DepositedPaid);

                    if (bsp.CreditorId == creditorId) {
                        bsp.PaymentId = paymentId;
                        lazyContext.Save(bsp, false);
                    }
                }

                payment.AmountPayable = payment.GetAmountPayable(lazyContext);
                payment.AmountPayableTax = payment.GetAmountPayableTax();

                lazyContext.Save(payment, false);
                lazyContext.Entry(payment).State = EntityState.Detached;

                payment = lazyContext.Payment.Find(payment.Id);
                new PaymentCommon(HttpContext).ValidateAndSave(lazyContext, payment, false);

                ts.Complete();
                return true;
            }
        }

        public bool Undo(AppLazyContext lazyContext, int id, bool isDetailView) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            using (var ts = Utils.CreateTransactionScope()) {
                if (isDetailView) {
                    var q = lazyContext.BspDetail.Find(id);

                    if (!q.CanUndo())
                        throw new UnreportedException(AppConstants.RecordCannotBeUndone);

                    new PaymentCommon(HttpContext).ValidateAndDelete(lazyContext, q.Bsp.Payment, false);
                    q.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);
                    q.Bsp.AgencyCreditCardBsp.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);
                }
                else {
                    var q = lazyContext.Bsp.Find(id);

                    if (!q.CanUndo())
                        throw new UnreportedException(AppConstants.RecordCannotBeUndone);

                    if (q.PaymentId > 0) {
                        var bsp = lazyContext.Bsp.Find(q.Id);
                        bsp.PaymentId = -1;
                        lazyContext.Save(bsp, false);
                    }

                    new PaymentCommon(HttpContext).ValidateAndDelete(lazyContext, q.Payment, false);

                    q.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);
                    q.AgencyCreditCardBsp.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);
                }

                ts.Complete();
                return true;
            }
        }

        public bool Reverse(AppLazyContext lazyContext, int bspId, string type, bool validateStatus = true, string agencyCreditCardDocumentNo = null, int agencyCreditCardBspId = 0) {
            using (var ts = Utils.CreateTransactionScope()) {
                var bsp = lazyContext.Bsp.Include(t => t.BspDetails).Single(t => t.Id == bspId);

                if (validateStatus && !bsp.CanReverse())
                    throw new UnreportedException(AppConstants.RecordCannotBeReversed);

                if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), bsp.DocumentDate, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                if (type == "CurrentDate" && !Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                var bspClone = bsp.Clone() as Bsp;
                bspClone.Id = 0;

                if (agencyCreditCardDocumentNo == null) {
                    bspClone.DocumentNo = GetReversedDocumentNo(lazyContext, bsp.DocumentNo);
                }
                else {
                    bspClone.DocumentNo = agencyCreditCardDocumentNo;

                    if (agencyCreditCardBspId > 0)
                        bspClone.AgencyCreditCardBspId = agencyCreditCardBspId;
                }

                if (type == "CurrentDate")
                    bspClone.DocumentDate = DateTime.Today;

                bspClone.Commission = -bspClone.Commission;
                bspClone.CommissionTax = -bspClone.CommissionTax;
                bspClone.Discount = -bspClone.Discount;
                bspClone.DiscountTax = -bspClone.DiscountTax;
                bspClone.Markup = -bspClone.Markup;
                bspClone.MarkupTax = -bspClone.MarkupTax;
                bspClone.MarkupGrossOther = -bspClone.MarkupGrossOther;
                bspClone.SupplierCancellationFee = -bspClone.SupplierCancellationFee;
                bspClone.SupplierCancellationFeeTax = -bspClone.SupplierCancellationFeeTax;
                bspClone.AmountPayable = -bspClone.AmountPayable;
                bspClone.PaymentId = -1;

                lazyContext.Entry(bsp).State = EntityState.Detached;
                lazyContext.Insert(bspClone);
                lazyContext.Entry(bspClone).State = EntityState.Detached;

                bspClone = lazyContext.Bsp.Find(bspClone.Id);
                Validate(bspClone, false, false);

                foreach (var bspDetail in bsp.BspDetails) {
                    var bspDetailClone = bspDetail.Clone() as BspDetail;

                    bspDetailClone.Id = 0;
                    bspDetailClone.BspId = bspClone.Id;
                    bspDetailClone.DocumentStatus = DocumentStatus.Open;
                    bspDetailClone.ReversalStatus = ReversalStatus.Reversal;
                    bspDetailClone.Amount = -bspDetailClone.Amount;
                    bspDetailClone.Tax = -bspDetailClone.Tax;
                    bspDetailClone.NonCommissionable = -bspDetailClone.NonCommissionable;
                    bspDetailClone.NonCommissionableTax = -bspDetailClone.NonCommissionableTax;

                    lazyContext.Insert(bspDetailClone, false);
                    bspDetail.UpdateReversalStatus(lazyContext, ReversalStatus.Reversed, -1);
                }

                bsp.UpdateReversalStatus(lazyContext, ReversalStatus.Reversed);

                lazyContext.Entry(bspClone).State = EntityState.Detached;
                bspClone = lazyContext.Bsp.Find(bspClone.Id);

                bspClone.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, bspClone.TripLine);
                bspClone.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                if (bsp.BspType != BspType.AgencyCC) {
                    foreach (var agencyCreditCardBsp in lazyContext.Bsp.Where(t => t.AgencyCreditCardBspId == bsp.Id).ToList()) {
                        new BspCommon(HttpContext).Reverse(lazyContext, agencyCreditCardBsp.Id, type, false, bspClone.DocumentNo, bspClone.Id);
                    }

                    foreach (var agencyCreditCardNonBsp in lazyContext.NonBsp.Where(t => t.AgencyCreditCardBspId == bsp.Id).ToList()) {
                        new NonBspCommon(HttpContext).Reverse(lazyContext, agencyCreditCardNonBsp.Id, type, false, bspClone.DocumentNo, bspClone.Id);
                    }
                }

                ts.Complete();
                return true;
            }
        }

        private static string GetReversedDocumentNo(AppMainContext context, string documentNo) {
            char suffix = Convert.ToChar(documentNo.Right(1).ToUpper());

            if (suffix >= 65 && suffix <= 89) {
                suffix = Convert.ToChar(suffix + 1);
                documentNo = documentNo.Left(documentNo.Length - 1);
            }
            else {
                suffix = 'A';
            }

            var q = context.Bsp.Where(t => t.BspType != BspType.AgencyCC);

            while (q.Any(t => t.DocumentNo == string.Format("{0}{1}", documentNo, suffix))) {
                if (suffix == 'Z') {
                    documentNo += "A";
                    suffix = 'A';
                    continue;
                }

                suffix = Convert.ToChar(suffix + 1);
            }

            return string.Format("{0}{1}", documentNo, suffix);
        }
    }

    public class BspDetailCommon {
        private HttpContext HttpContext { get; }

        public BspDetailCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool ValidateAndSave(AppLazyContext lazyContext, BspDetail bspDetail, bool validateDocumentStatus = true, bool performRelatedUpdates = false, bool allowAgencyCcUpdate = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            if (bspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || bspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || bspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross) {
                if (bspDetail.Bsp.BspDetails.Any(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard))
                    throw new UnreportedException("This Form of Payment cannot be assigned because another Form of Payment is a credit card or travel card.");
            }

            if (bspDetail.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard && bspDetail.Bsp.BspDetails.Any(t => t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross))
                throw new UnreportedException("This Form of Payment cannot be assigned because another Form of Payment is an agency credit card or is paying the gross amount to the supplier.");

            Validate(lazyContext, bspDetail, false, validateDocumentStatus);

            bool result;

            if (bspDetail.Id <= 0) {
                result = lazyContext.Insert(bspDetail);
            }
            else {
                result = lazyContext.Save(bspDetail);
            }

            if (!result && !performRelatedUpdates)
                return false;

            if (txnUpdateType != TransactionUpdateType.None)
                bspDetail.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            ;

            if (bspDetail.Bsp.TripLine?.Id > 0) {
                bspDetail.Bsp.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }
            else if (bspDetail.Bsp.Trip?.Id > 0) {
                bspDetail.Bsp.Trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (allowAgencyCcUpdate && bspDetail.Bsp.BspType != BspType.AgencyCC && (bspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || bspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross))
                CreateOrUpdateAgencyCcBsp(bspDetail);

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, BspDetail bspDetail, bool validateDocumentStatus = true) {
            Validate(lazyContext, bspDetail, true, validateDocumentStatus);
            var tripLine = bspDetail.Bsp.TripLine;

            if (lazyContext.Delete(bspDetail))
                return tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return false;
        }

        public void Validate(AppLazyContext lazyContext, BspDetail bspDetail, bool isDeletion, bool validateDocumentStatus = true) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), bspDetail.Bsp.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!isDeletion && bspDetail.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard) {
                int agencyId = bspDetail.Bsp.AgencyId;

                if (agencyId <= 0 && bspDetail.Id <= 0)
                    agencyId = HttpContext.CurrentDefaultAgencyId();

                var debtor = bspDetail.Bsp.Trip.Debtor.BillingHeadDebtor;

                if (debtor.Id > 0)
                    debtor.ValidateCreditLimit(lazyContext, TransactionType.Bsp, bspDetail.Id, agencyId, bspDetail.Amount + bspDetail.Tax + bspDetail.NonCommissionableGross - bspDetail.DiscountGrossProRata + bspDetail.MarkupGrossProRata);
            }

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !bspDetail.CanDelete(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !bspDetail.CanEdit(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public bool CreateOrUpdate(BspDetailViewModel model, bool isTaxApplicable, bool isTaxIncluded, bool validateLimits, bool validateDocumentStatus = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    var bsp = lazyContext.Bsp.Find(model.BspId);
                    bool deleteAutoGenerated = false;

                    BspDetail q = null;

                    if (model.BspDetailId <= 0) {
                        q = new BspDetail {
                            Id = 0,
                            DocumentStatus = DocumentStatus.Open,
                            ReversalStatus = ReversalStatus.None,
                            FormOfPaymentId = model.BspDetailFormOfPaymentId ?? 0,
                            FormOfPayment = lazyContext.FormOfPayment.Find(model.BspDetailFormOfPaymentId),
                            Bsp = bsp
                        };

                        if (bsp.BspDetails.Count > 0) {
                            if (bsp.BspDetails.Any(t => t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross))
                                throw new UnreportedException("Due to the Form of Payment Type already assigned, this document can only contain one detail row.");

                            if ((q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross) && bsp.BspDetails.Any(t => t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardNet && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardGross))
                                throw new UnreportedException("Form of Payment Type 'Agency Credit Card' cannot be included with other Forms of Payment.");
                        }
                    }
                    else {
                        q = lazyContext.BspDetail.Find(model.BspDetailId);

                        var formOfPayment = lazyContext.FormOfPayment.Find(model.BspDetailFormOfPaymentId);

                        deleteAutoGenerated = (q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross)
                            && formOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardNet && formOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardGross && formOfPayment.FormOfPaymentType != FormOfPaymentType.PaySupplierGross;
                    }

                    int tripLineAirPassengerId = model.BspDetailTripLineAirPassengerId ?? 0;
                    int passengerId = -1;

                    if (tripLineAirPassengerId <= 0)
                        passengerId = model.BspDetailPassengerId ?? 0;

                    decimal nonCommissionable = model.BspDetailNonCommissionable;
                    decimal nonCommissionableTax = 0;
                    decimal tax = 0;
                    decimal amount = model.BspDetailAmount;

                    if (isTaxApplicable || (!validateLimits && bsp.IsTaxApplicable)) {
                        decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), bsp.DocumentDate);

                        nonCommissionableTax = Math.Round(nonCommissionable * taxRate / (1 + taxRate), 2);
                        nonCommissionable -= nonCommissionableTax;

                        if (isTaxIncluded) {
                            tax = Math.Round(amount * taxRate / (1 + taxRate), 2);
                            amount -= tax;
                        }
                        else {
                            tax = Math.Round(amount * taxRate, 2);
                        }

                        if (validateLimits) {
                            if (Math.Abs(model.BspDetailTax - tax) > .02m)
                                throw new UnreportedException(string.Format("{0} value is outside accepted limits.", Resource.TaxLabel));

                            if (tax != model.BspDetailTax) {
                                tax = model.BspDetailTax;

                                if (isTaxIncluded)
                                    amount = model.BspDetailAmount - tax;
                            }
                        }
                    }

                    q.BspId = model.BspId;
                    q.TripLineAirPassengerId = tripLineAirPassengerId;
                    q.PassengerId = passengerId;
                    q.FormOfPaymentId = model.BspDetailFormOfPaymentId ?? 0;
                    q.Amount = amount;
                    q.Tax = tax;
                    q.NonCommissionable = nonCommissionable;
                    q.NonCommissionableTax = nonCommissionableTax;

                    if (model.BspDetailId <= 0) {
                        q.TripLineAirPassenger = lazyContext.TripLineAirPassenger.Find(q.TripLineAirPassengerId);
                        q.Passenger = lazyContext.Passenger.Find(q.PassengerId);
                        q.FormOfPayment = lazyContext.FormOfPayment.Find(q.FormOfPaymentId);
                    }

                    if (q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross)
                        throw new UnreportedException("Forms of Payment of type 'Pay Supplier Gross' are not permitted for this document.");

                    bool result = ValidateAndSave(lazyContext, q, validateDocumentStatus, false, true, txnUpdateType);

                    bsp = lazyContext.Bsp.Find(model.BspId);
                    bsp.AmountPayable = bsp.GetAmountPayable(lazyContext);
                    lazyContext.Save(bsp, false);

                    if (deleteAutoGenerated) {
                        var agencyCreditCardBsp = lazyContext.Bsp.Single(t => t.AgencyCreditCardBspId == bsp.Id);
                        var agencyCreditCardNonBsp = lazyContext.NonBsp.Single(t => t.AgencyCreditCardBspId == bsp.Id);

                        lazyContext.RemoveRange(agencyCreditCardBsp.Transactions.SelectMany(t => t.TransactionDetails).SelectMany(t => t.TransactionDetailAllocations));
                        lazyContext.RemoveRange(agencyCreditCardNonBsp.Transactions.SelectMany(t => t.TransactionDetails).SelectMany(t => t.TransactionDetailAllocations));
                        lazyContext.RemoveRange(agencyCreditCardBsp.Transactions);
                        lazyContext.RemoveRange(agencyCreditCardNonBsp.Transactions);
                        lazyContext.SaveChanges();

                        bsp.AgencyCreditCardBspId = -1;
                        lazyContext.Save(bsp, false);

                        lazyContext.Delete(agencyCreditCardBsp, false);
                        lazyContext.Delete(agencyCreditCardNonBsp, false);
                    }

                    model.BspDetailId = q.Id;

                    ts.Complete();
                    return result;
                }
            }
        }

        public bool CreateOrUpdate(BspViewModel model, BspDetailViewModel detailModel, bool isNew) {
            using (var ts = Utils.CreateTransactionScope()) {
                new BspCommon(HttpContext).CreateOrUpdate(model, true, !isNew, false, false, TransactionUpdateType.None);
                detailModel.BspId = model.BspId;
                CreateOrUpdate(detailModel, model.BspIsTaxApplicable, model.BspIsTaxIncluded, true, !isNew);
                ts.Complete();
                return true;
            }
        }

        public bool CreateOrUpdateAgencyCcBsp(BspDetail bspDetail) {
            var bsp = bspDetail.Bsp;
            int sign = bsp.Sign;

            if (bsp.BspType == BspType.AgencyCC)
                return false;

            if (bspDetail.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardNet && bspDetail.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardGross)
                throw new UnreportedException("This document does not contain a valid Form of Payment.");

            if (bsp.BspDetails.Count > 1)
                throw new UnreportedException("This document can only contain one detail row.");

            if (bsp.BspDetails.Any(t => t.Id != bspDetail.Id && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardNet && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardGross))
                throw new UnreportedException("This document contains one or more invalid Forms of Payment.");

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                var bspClone = lazyContext.Bsp.SingleOrDefault(t => t.AgencyCreditCardBspId == bsp.Id);

                if (bspClone == null) {
                    bspClone = bsp.Clone() as Bsp;
                    bspClone.Id = 0;
                    bspClone.Comments = string.Empty;
                }

                decimal amountPayable = bspDetail.Amount + bspDetail.Tax - bsp.SupplierCancellationFee - bsp.SupplierCancellationFeeTax;

                if (bspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet)
                    amountPayable -= bsp.Commission + bsp.CommissionTax;

                amountPayable *= sign;

                bspClone.BspType = BspType.AgencyCC;
                bspClone.DocumentNo = bsp.DocumentNo;
                bspClone.DocumentDate = bsp.DocumentDate;
                bspClone.TripId = bsp.TripId;
                bspClone.TripLineId = bsp.TripLineId;
                bspClone.CreditorId = bsp.CreditorId;
                bspClone.SupplierId = bsp.SupplierId;
                bspClone.AirlineId = bsp.AirlineId;
                bspClone.DepartureDate = bsp.DepartureDate;
                bspClone.OfferedFare = bsp.OfferedFare;
                bspClone.OfferedReasonId = bsp.OfferedReasonId;
                bspClone.SaleTypeId = bsp.SaleTypeId;
                bspClone.CategoryId = bsp.CategoryId;
                bspClone.DestinationId = bsp.DestinationId;
                bspClone.AgencyId = bsp.AgencyId;
                bspClone.ConsultantId = bsp.ConsultantId;
                bspClone.AgentId = bsp.AgentId;
                bspClone.SourceId = bsp.SourceId;
                bspClone.Commission = 0;
                bspClone.CommissionTax = 0;
                bspClone.Discount = 0;
                bspClone.DiscountTax = 0;
                bspClone.DiscountReasonId = -1;
                bspClone.Markup = 0;
                bspClone.MarkupTax = 0;
                bspClone.MarkupStrategyId = -1;
                bspClone.SupplierCancellationFee = 0;
                bspClone.SupplierCancellationFeeTax = 0;
                bspClone.AmountPayable = -(amountPayable + bspDetail.NonCommissionableGross * sign);
                bspClone.PaymentId = -1;
                bspClone.AgencyCreditCardBspId = bsp.Id;

                bool result;

                if (bspClone.Id <= 0) {
                    result = lazyContext.Insert(bspClone);
                }
                else {
                    result = lazyContext.Save(bspClone);
                }

                if (result) {
                    var bspDetailClone = lazyContext.Bsp.SingleOrDefault(t => t.AgencyCreditCardBspId == bsp.Id)?.BspDetails.SingleOrDefault();

                    if (bspDetailClone == null) {
                        bspDetailClone = bspDetail.Clone() as BspDetail;
                        bspDetailClone.Id = 0;
                    }

                    bspDetailClone.BspId = bspClone.Id;
                    bspDetailClone.DocumentStatus = DocumentStatus.Open;
                    bspDetailClone.ReversalStatus = ReversalStatus.None;
                    bspDetailClone.Amount = -amountPayable;
                    bspDetailClone.Tax = 0;
                    bspDetailClone.NonCommissionable = -bspDetail.NonCommissionable * sign;
                    bspDetailClone.NonCommissionableTax = -bspDetail.NonCommissionableTax * sign;

                    if (bspDetailClone.Id <= 0) {
                        lazyContext.Insert(bspDetailClone);
                    }
                    else {
                        lazyContext.Save(bspDetailClone);
                    }

                    lazyContext.Entry(bspDetailClone).State = EntityState.Detached;

                    lazyContext.Entry(bspClone).State = EntityState.Detached;
                    bspClone = lazyContext.Bsp.Find(bspClone.Id);
                    bspClone.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, bspClone.TripLine);
                }

                amountPayable += bspDetail.NonCommissionableGross * sign;
                var nonBsp = lazyContext.NonBsp.SingleOrDefault(t => t.AgencyCreditCardBspId == bsp.Id) ?? new NonBsp();

                nonBsp.NonBspType = NonBspType.AgencyCC;
                nonBsp.DocumentNo = bsp.DocumentNo;
                nonBsp.DocumentDate = bsp.DocumentDate;
                nonBsp.TripId = bsp.TripId;
                nonBsp.TripLineId = bsp.TripLineId;
                nonBsp.CreditorId = bspDetail.FormOfPayment.CreditorId;
                nonBsp.SupplierId = bspDetail.FormOfPayment.DefaultSupplierId;
                nonBsp.ChartOfAccountId = -1;
                nonBsp.AirlineId = bsp.AirlineId;
                nonBsp.DepartureDate = DateTime.MinValue;
                nonBsp.OfferedFare = bsp.OfferedFare;
                nonBsp.OfferedReasonId = bsp.OfferedReasonId;
                nonBsp.SaleTypeId = bsp.SaleTypeId;
                nonBsp.CategoryId = bsp.CategoryId;
                nonBsp.DestinationId = bsp.DestinationId;
                nonBsp.AgencyId = bsp.AgencyId;
                nonBsp.ConsultantId = bsp.ConsultantId;
                nonBsp.AgentId = bsp.AgentId;
                nonBsp.SourceId = bsp.SourceId;
                nonBsp.DiscountReasonId = -1;
                nonBsp.MarkupStrategyId = -1;
                nonBsp.AmountPayable = amountPayable;
                nonBsp.PaymentId = -1;
                nonBsp.AgencyCreditCardBspId = bsp.Id;
                nonBsp.AgencyCreditCardNonBspId = -1;
                nonBsp.LoyaltySchemeReceiptDetailId = -1;
                nonBsp.SupplierOtherCommissionReceiptId = -1;
                nonBsp.Comments = string.Empty;

                if (nonBsp.Id <= 0) {
                    result = lazyContext.Insert(nonBsp);
                }
                else {
                    result = lazyContext.Save(nonBsp);
                }

                if (result) {
                    var nonBspDetail = lazyContext.NonBsp.SingleOrDefault(t => t.AgencyCreditCardBspId == bsp.Id)?.NonBspDetails.SingleOrDefault() ?? new NonBspDetail();

                    nonBspDetail.NonBspId = nonBsp.Id;
                    nonBspDetail.DocumentStatus = DocumentStatus.Open;
                    nonBspDetail.ReversalStatus = ReversalStatus.None;
                    nonBspDetail.PassengerId = bspDetail.PassengerId;
                    nonBspDetail.TripLineAirPassengerId = bspDetail.TripLineAirPassengerId;
                    nonBspDetail.FormOfPaymentId = bspDetail.FormOfPaymentId;
                    nonBspDetail.Amount = amountPayable;
                    nonBspDetail.Tax = 0;
                    nonBspDetail.NonCommissionable = 0;
                    nonBspDetail.NonCommissionableTax = 0;
                    nonBspDetail.IsTaxApplicable = false;

                    if (nonBspDetail.Id <= 0) {
                        lazyContext.Insert(nonBspDetail);
                    }
                    else {
                        lazyContext.Save(nonBspDetail);
                    }

                    lazyContext.Entry(nonBsp).State = EntityState.Detached;
                    nonBsp = lazyContext.NonBsp.Find(nonBsp.Id);
                    nonBsp.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, nonBsp.TripLine);
                }

                return true;
            }
        }

        public bool Delete(AppLazyContext lazyContext, BspDetailViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.BspDetail.Find(model.BspDetailId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (q.Bsp.BspDetails.Count == 1)
                    throw new UnreportedException(AppConstants.RecordCannotBeDeleted);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }
    }

    public class NonBspCommon {
        private HttpContext HttpContext { get; }

        public NonBspCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool ValidateAndSave(AppLazyContext lazyContext, NonBsp nonBsp, bool validateDocumentStatus = true, bool performRelatedUpdates = true, bool updateAutoGenerated = false, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow, int oldTripId = 0, int oldTripLineId = 0) {
            Validate(nonBsp, false, validateDocumentStatus);
            bool result;

            if (nonBsp.Id <= 0) {
                result = lazyContext.Insert(nonBsp);
            }
            else {
                result = lazyContext.Save(nonBsp);
            }

            if (!result && !performRelatedUpdates)
                return false;

            if (txnUpdateType != TransactionUpdateType.None)
                nonBsp.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            ;

            if (oldTripId > 0) {
                foreach (var tripLine in lazyContext.Trip.Find(oldTripId).TripLines.Where(t => t.Id > 0).ToList()) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }
            else if (oldTripLineId > 0) {
                var tripLine = lazyContext.TripLine.Find(oldTripLineId);
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (nonBsp.TripLine?.Id > 0) {
                nonBsp.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }
            else if (nonBsp.Trip?.Id > 0) {
                nonBsp.Trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            var nonBspDetail = nonBsp.NonBspDetails.FirstOrDefault();

            if (updateAutoGenerated && nonBsp.NonBspType != NonBspType.AgencyCC && nonBspDetail != null && (nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross))
                new NonBspDetailCommon(HttpContext).CreateOrUpdateAgencyCcNonBsp(nonBspDetail);

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, NonBsp nonBsp, bool validateDocumentStatus = true) {
            Validate(nonBsp, true, validateDocumentStatus);

            if (lazyContext.NonBsp.Any(t => t.AgencyCreditCardNonBspId == nonBsp.Id)) {
                var agencyCreditCardNonBsps = lazyContext.NonBsp.Where(t => t.AgencyCreditCardNonBspId == nonBsp.Id).ToList();

                if (agencyCreditCardNonBsps.Count > 0) {
                    lazyContext.RemoveRange(agencyCreditCardNonBsps.SelectMany(t => t.Transactions));
                    lazyContext.SaveChanges();
                    lazyContext.RemoveRange(agencyCreditCardNonBsps);
                    lazyContext.SaveChanges();
                }
            }

            lazyContext.RemoveRange(lazyContext.Receipt.Where(t => t.Id > 0 && (t.Id == nonBsp.LoyaltySchemeReceiptDetailId || t.Id == nonBsp.SupplierOtherCommissionReceiptId)));
            lazyContext.SaveChanges();

            lazyContext.RemoveRange(lazyContext.NonBsp.Where(t1 => t1.LoyaltySchemeReceiptDetailId > 0 && t1.LoyaltySchemeReceiptDetailId == nonBsp.LoyaltySchemeReceiptDetailId));
            lazyContext.SaveChanges();

            if (HttpContext.IsSuperUser()) {
                int[] nonBspDetailIds = nonBsp.NonBspDetails.Select(t => t.Id).ToArray();

                lazyContext.RemoveRange(lazyContext.TransactionDetail.Where(t => nonBspDetailIds.Contains(t.NonBspDetailId)).SelectMany(t => t.TransactionDetailAllocations));
                lazyContext.SaveChanges();

                lazyContext.RemoveRange(lazyContext.TransactionDetailAllocation.Where(t => nonBspDetailIds.Contains(t.NonBspDetailId)));
                lazyContext.SaveChanges();
            }

            lazyContext.RemoveRange(nonBsp.Transactions);
            lazyContext.SaveChanges();

            var payment = nonBsp.Payment;
            var tripLine = nonBsp.TripLine;

            bool result = lazyContext.Delete(nonBsp);

            if (payment.Id > 0) {
                if (!lazyContext.NonBsp.Any(t => t.PaymentId == payment.Id && t.CreditorId == nonBsp.CreditorId)) {
                    lazyContext.Delete(payment, false);
                }
                else {
                    payment.AmountPayable = payment.GetAmountPayableGross(lazyContext, true);
                    lazyContext.Save(payment, false);
                }
            }

            if (result)
                return tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return false;
        }

        public void Validate(NonBsp nonBsp, bool isDeletion, bool validateDocumentStatus = true) {
            if (!isDeletion && nonBsp.AgencyId <= 0)
                throw new UnreportedException(AppConstants.AgencyNotSpecified);

            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), nonBsp.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!isDeletion && nonBsp.TripId > 0 && !nonBsp.Trip.IsBooking)
                throw new UnreportedException(AppConstants.RecordIsNotBooking);

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !nonBsp.CanDelete(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !nonBsp.CanEdit(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public bool CreateOrUpdate(NonBspViewModel model, bool validateLimits, bool validateDocumentStatus = true, bool performRelatedUpdates = true, bool updateAutoGenerated = false, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            if (model.NonBspDiscount != 0 && (model.NonBspDiscountReasonId ?? 0) <= 0)
                throw new UnreportedException("Discount Reason is required when Discount is applied.");

            if (model.NonBspMarkup != 0 && (model.NonBspMarkupStrategyId ?? 0) <= 0)
                throw new UnreportedException("Mark-Up Strategy is required when Mark-Up is applied.");

            if (model.NonBspType == NonBspType.Admin) {
                model.NonBspOfferedFare = 0;
                model.NonBspOfferedReasonId = -1;
            }
            else {
                if (model.NonBspOfferedFare != 0 && (model.NonBspOfferedReasonId ?? 0) <= 0)
                    throw new UnreportedException("Reason Rejected is required when Offered Fare is applied.");

                if ((model.NonBspConsultantId ?? 0) <= 0)
                    throw new UnreportedException("Consultant is required.");
            }

            model.NonBspDocumentNo = Utils.RemoveExtraSpaces(model.NonBspDocumentNo).Replace(" ", string.Empty).ToUpper();

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    model.NonBspDocumentNo = NonBsp.GetUniqueDocumentNo(lazyContext, model.NonBspType, model.NonBspId, model.NonBspDocumentNo);
                    bool documentDateUpdated = false;

                    if (model.NonBspType == NonBspType.Admin) {
                        model.NonBspSupplierId = -1;
                        model.NonBspTripId = -1;
                        model.NonBspTripLineId = -1;
                        model.NonBspAirlineId = -1;
                        model.NonBspDepartureDateStatus = DepartureDateStatus.Normal;
                        model.NonBspDepartureDate = DateTime.MinValue;
                        model.NonBspSaleTypeId = -1;
                        model.NonBspSourceId = -1;
                        model.NonBspCategoryId = -1;
                        model.NonBspDestinationId = -1;
                        model.NonBspConsultantId = HttpContext.CurrentConsultantId();
                        model.NonBspAgentId = -1;
                        model.NonBspCommission = 0;
                        model.NonBspCommissionTax = 0;
                        model.NonBspDiscount = 0;
                        model.NonBspDiscountTax = 0;
                        model.NonBspDiscountReasonId = -1;
                        model.NonBspMarkup = 0;
                        model.NonBspMarkupTax = 0;
                        model.NonBspMarkupStrategyId = -1;
                    }
                    else {
                        if ((model.NonBspSaleTypeId ?? 0) <= 0)
                            throw new UnreportedException("Type of Sale is required.");

                        model.NonBspChartOfAccountId = -1;
                    }

                    NonBsp q = null;

                    if (model.NonBspId <= 0) {
                        q = new NonBsp {
                            Id = 0,
                            NonBspType = model.NonBspType,
                            DocumentDate = model.NonBspDocumentDate ?? DateTime.MinValue,
                            TripId = model.NonBspTripId ?? 0,
                            Trip = lazyContext.Trip.Find(model.NonBspTripId),
                            TripLineId = model.NonBspTripLineId ?? 0,
                            TripLine = lazyContext.TripLine.Find(model.NonBspTripLineId),
                            ChartOfAccountId = model.NonBspChartOfAccountId ?? 0,
                            ChartOfAccount = lazyContext.ChartOfAccount.Find(model.NonBspChartOfAccountId),
                            SaleTypeId = model.NonBspSaleTypeId ?? 0,
                            SaleType = lazyContext.SaleType.Find(model.NonBspSaleTypeId),
                            AgencyId = HttpContext.CurrentDefaultAgencyId(),
                            AgencyCreditCardBspId = -1,
                            AgencyCreditCardNonBspId = -1,
                            LoyaltySchemeReceiptDetailId = -1,
                            SupplierOtherCommissionReceiptId = -1,
                            MarkupGrossOther = 0,
                            PaymentId = -1
                        };
                    }
                    else {
                        q = lazyContext.NonBsp.Find(model.NonBspId);

                        if (!q.ValidateTaxApplicability(q.IsTaxApplicable))
                            throw new UnreportedException(AppConstants.TaxRelatedRecordCannotBeAltered);
                    }

                    if (!q.IsDiscountPermitted) {
                        model.NonBspDiscountReasonId = -1;
                        model.NonBspIsCreditCardDiscountApplicable = false;
                    }

                    if (!q.IsMarkupPermitted) {
                        model.NonBspMarkupStrategyId = -1;
                        model.NonBspIncludeMarkupInCreditCardPayment = false;
                    }

                    if (!q.IsCancellationPermitted)
                        model.NonBspSupplierCancellationFee = 0;

                    documentDateUpdated = q.DocumentDate != model.NonBspDocumentDate;

                    decimal commission = q.IsCommissionPermitted ? model.NonBspCommission : 0;
                    decimal commissionTax = 0;
                    decimal discount = q.IsDiscountPermitted ? model.NonBspDiscount : 0;
                    decimal discountTax = 0;
                    decimal markup = q.IsMarkupPermitted ? model.NonBspMarkup : 0;
                    decimal markupTax = 0;
                    decimal supplierCancellationFee = model.NonBspSupplierCancellationFee;
                    decimal supplierCancellationFeeTax = 0;

                    if (q.IsTaxApplicable) {
                        decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), (DateTime)model.NonBspDocumentDate);

                        supplierCancellationFeeTax = Math.Round(supplierCancellationFee * taxRate / (1 + taxRate), 2);
                        supplierCancellationFee -= supplierCancellationFeeTax;

                        if (model.NonBspIsTaxIncluded) {
                            commissionTax = Math.Round(commission * taxRate / (1 + taxRate), 2);
                            discountTax = Math.Round(discount * taxRate / (1 + taxRate), 2);
                            markupTax = Math.Round(markup * taxRate / (1 + taxRate), 2);
                            commission -= commissionTax;
                            discount -= discountTax;
                            markup -= markupTax;
                        }
                        else {
                            commissionTax = Math.Round(commission * taxRate, 2);
                            discountTax = Math.Round(discount * taxRate, 2);
                            markupTax = Math.Round(markup * taxRate, 2);
                        }

                        if (validateLimits) {
                            if (Math.Abs(model.NonBspCommissionTax - commissionTax) > .02m)
                                throw new UnreportedException(string.Format("{0} value is outside accepted limits.", Resource.CommissionTaxLabel));

                            commissionTax = model.NonBspCommissionTax;
                        }
                    }

                    int oldTripId = q.Id > 0 && q.TripId != model.NonBspTripId ? q.TripId : 0;
                    int oldTripLineId = q.Id > 0 && q.TripLineId != model.NonBspTripLineId ? q.TripLineId : 0;

                    if (!q.IsClientAccountLocked) {
                        q.TripId = model.NonBspTripId ?? 0;
                        q.TripLineId = model.NonBspTripLineId ?? 0;
                    }

                    q.NonBspType = model.NonBspType;
                    q.DocumentNo = NonBsp.GetUniqueDocumentNo(lazyContext, q.NonBspType, q.Id, model.NonBspDocumentNo);
                    q.DocumentDate = model.NonBspDocumentDate ?? DateTime.MinValue;
                    q.ChartOfAccountId = model.NonBspChartOfAccountId ?? 0;
                    q.SupplierId = model.NonBspSupplierId ?? 0;
                    q.CreditorId = model.NonBspCreditorId ?? 0;
                    q.AirlineId = model.NonBspAirlineId ?? 0;
                    q.DepartureDate = model.NonBspDepartureDateStatus == DepartureDateStatus.Open ? DateTime.MinValue : model.NonBspDepartureDateStatus == DepartureDateStatus.ARNK ? lazyContext.VoidDate : model.NonBspDepartureDate ?? DateTime.Today;
                    q.OfferedFare = model.NonBspOfferedFare;
                    q.OfferedReasonId = model.NonBspOfferedReasonId ?? 0;
                    q.SaleTypeId = model.NonBspSaleTypeId ?? 0;
                    q.CategoryId = model.NonBspCategoryId ?? 0;
                    q.DestinationId = model.NonBspDestinationId ?? 0;
                    q.ConsultantId = model.NonBspConsultantId ?? 0;
                    q.AgentId = model.NonBspAgentId ?? 0;
                    q.SourceId = model.NonBspSourceId ?? 0;
                    q.Commission = commission;
                    q.CommissionTax = commissionTax;
                    q.Discount = discount;
                    q.DiscountTax = discountTax;
                    q.DiscountReasonId = model.NonBspDiscountReasonId ?? 0;
                    q.Markup = markup;
                    q.MarkupTax = markupTax;
                    q.MarkupStrategyId = model.NonBspMarkupStrategyId ?? 0;
                    q.MarkupGrossOther = q.GetMarkupGross();
                    q.SupplierCancellationFee = supplierCancellationFee;
                    q.SupplierCancellationFeeTax = supplierCancellationFeeTax;
                    q.IsCreditCardDiscountApplicable = model.NonBspIsCreditCardDiscountApplicable;
                    q.IncludeMarkupInCreditCardPayment = model.NonBspIncludeMarkupInCreditCardPayment;
                    q.IsAutoInvoiced = model.NonBspIsAutoInvoiced;
                    q.Comments = model.NonBspComments.ToStringExt();

                    q.AmountPayable = q.GetAmountPayable(lazyContext);

                    if (q.ChartOfAccountId > 0 && !ChartOfAccount.IsInRole(lazyContext, q.ChartOfAccountId, HttpContext.RoleId()))
                        throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                    if (q.ChartOfAccountId > 0 && !HttpContext.IsAdministrator() && Setting.IsControlAccount(HttpContext.CurrentCustomerId(), q.DocumentDate, q.ChartOfAccountId))
                        throw new UnreportedException(AppConstants.GlControlAccountWarning);

                    bool result = ValidateAndSave(lazyContext, q, validateDocumentStatus, performRelatedUpdates, updateAutoGenerated, txnUpdateType, oldTripId, oldTripLineId);

                    if (documentDateUpdated) {
                        foreach (var row1 in lazyContext.NonBsp.Where(t => t.AgencyCreditCardNonBspId == q.Id).ToList()) {
                            row1.DocumentDate = q.DocumentDate;
                            lazyContext.Save(row1, false);

                            foreach (var row2 in row1.Transactions) {
                                row2.DocumentDate = q.DocumentDate;
                                lazyContext.Save(row2, false);
                            }
                        }
                    }

                    model.NonBspId = q.Id;
                    model.NonBspDocumentNo = q.DocumentNo;
                    model.NonBspTripLineType = q.TripLine.TripLineType;
                    model.NonBspIsTaxApplicable = q.IsTaxApplicable;

                    ts.Complete();
                    return result;
                }
            }
        }

        public bool Delete(AppLazyContext lazyContext, NonBspViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.NonBsp.Include(t => t.AgencyCreditCardBsp).Include(t => t.AgencyCreditCardNonBsp).SingleOrDefault(t => t.Id == model.NonBspId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }

        public bool ProcessSelections(AppLazyContext lazyContext, int[] nonBspIds, int documentStatusId, int bankAccountId, string documentNo, DateTime documentDate, DateTime returnDate, bool undo) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            var q = lazyContext.NonBsp.First(t => nonBspIds.Contains(t.Id));

            int creditorId = q.CreditorId;
            int supplierId = q.SupplierId;

            var nonBsps = lazyContext.NonBsp.Where(t => (nonBspIds.Contains(t.Id) || nonBspIds.Contains(t.AgencyCreditCardNonBspId)) && t.CreditorId == creditorId).Select(t => new {
                t.DocumentNo,
                t.DocumentDate,
                t.CreditorId,
                t.SupplierId
            }).Distinct();

            nonBspIds = lazyContext.NonBsp.Where(t1 => nonBsps.Any(t2 => t2.DocumentNo == t1.DocumentNo && t2.DocumentDate == t1.DocumentDate && t2.CreditorId == t1.CreditorId && t2.SupplierId == t1.SupplierId)).Select(t => t.Id).ToArray();
            var documentStatus = (DocumentStatus)documentStatusId;

            if (undo) {
                foreach (int nonBspId in nonBspIds) {
                    Undo(lazyContext, nonBspId, false);
                }

                return true;
            }

            if (documentStatus != (int)DocumentStatus.Open)
                throw new UnreportedException(AppConstants.RecordStatusCannotBeChanged);

            Payment payment = null;

            int paymentId = 0;
            int i = -1;

            var nonBspList = lazyContext.NonBspDetail.Include(t => t.NonBsp).Where(t => t.NonBsp.PaymentId <= 0 && nonBspIds.Contains(t.NonBspId)).ToList();

            if (nonBspList.Count == 0)
                return false;

            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var row in nonBspList) {
                    i++;

                    var nonBspDetail = lazyContext.NonBspDetail.Find(row.Id);
                    var nonBsp = nonBspDetail.NonBsp;

                    if (i == 0) {
                        payment = new Payment {
                            Id = 0,
                            PaymentType = PaymentType.NonBspReturn,
                            DocumentNo = Payment.GetUniqueDocumentNo(lazyContext, 0, bankAccountId, false, documentNo),
                            DocumentDate = documentDate,
                            ReturnDate = returnDate,
                            TripId = -1,
                            DebtorId = -1,
                            CreditorId = creditorId,
                            SupplierId = supplierId,
                            ChartOfAccountId = -1,
                            BankAccountId = bankAccountId,
                            Payee = string.Empty,
                            SaleTypeId = -1,
                            CategoryId = -1,
                            AgencyId = nonBsp.AgencyId,
                            ConsultantId = nonBsp.ConsultantId,
                            SourceId = -1,
                            AirlineId = -1,
                            Commission = 0,
                            CommissionTax = 0,
                            Discount = 0,
                            DiscountTax = 0,
                            DiscountReasonId = -1,
                            Markup = 0,
                            MarkupTax = 0,
                            MarkupStrategyId = -1,
                            IsAutoInvoiced = false,
                            Comments = string.Format("Non-BSP {0:d} by {1}", returnDate, HttpContext.UserFullName()).Left(100)
                        };

                        if (lazyContext.Insert(payment)) {
                            paymentId = payment.Id;
                            lazyContext.Entry(payment).State = EntityState.Detached;
                            payment = lazyContext.Payment.Find(paymentId);
                        }
                    }

                    var paymentDetail = new PaymentDetail {
                        Id = 0,
                        PaymentId = paymentId,
                        DocumentStatus = DocumentStatus.DepositedPaid,
                        ReversalStatus = ReversalStatus.None,
                        TripLineId = nonBspDetail.NonBsp.TripLineId,
                        TripLineAirPassengerId = nonBspDetail.TripLineAirPassengerId,
                        PassengerId = nonBspDetail.PassengerId,
                        FormOfPayment = nonBspDetail.FormOfPayment,
                        OfferedFare = nonBspDetail.NonBsp.OfferedFare,
                        OfferedReasonId = nonBspDetail.NonBsp.OfferedReasonId,
                        Amount = (nonBspDetail.Cash - nonBspDetail.CashNonCommissionable - nonBspDetail.CommissionProRata - nonBspDetail.SupplierCancellationFeeProRata) * nonBspDetail.NonBsp.Sign,
                        Tax = (nonBspDetail.CashTax - nonBspDetail.CashNonCommissionableTax - nonBspDetail.CommissionTaxProRata - nonBspDetail.SupplierCancellationFeeTaxProRata) * nonBspDetail.NonBsp.Sign,
                        NonCommissionable = nonBspDetail.CashNonCommissionable * nonBspDetail.NonBsp.Sign,
                        NonCommissionableTax = nonBspDetail.CashNonCommissionableTax * nonBspDetail.NonBsp.Sign,
                        BankAccountStatementId = -1
                    };

                    lazyContext.Insert(paymentDetail);

                    if (nonBspDetail.NonBsp.CreditorId == creditorId && nonBspDetail.DocumentStatus == DocumentStatus.Open)
                        nonBspDetail.UpdateDocumentStatus(lazyContext, DocumentStatus.DepositedPaid);

                    if (nonBsp.CreditorId == creditorId) {
                        nonBsp.PaymentId = paymentId;
                        lazyContext.Save(nonBsp, false);
                    }
                }

                payment.AmountPayable = payment.GetAmountPayable(lazyContext);
                payment.AmountPayableTax = payment.GetAmountPayableTax();

                lazyContext.Save(payment, false);
                lazyContext.Entry(payment).State = EntityState.Detached;

                payment = lazyContext.Payment.Find(payment.Id);
                new PaymentCommon(HttpContext).ValidateAndSave(lazyContext, payment, false);

                ts.Complete();
                return true;
            }
        }

        public bool Undo(AppLazyContext lazyContext, int id, bool isDetailView) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            using (var ts = Utils.CreateTransactionScope()) {
                if (isDetailView) {
                    var q = lazyContext.NonBspDetail.Find(id);

                    if (!q.CanUndo())
                        throw new UnreportedException(AppConstants.RecordCannotBeUndone);

                    new PaymentCommon(HttpContext).ValidateAndDelete(lazyContext, q.NonBsp.Payment, false);
                    q.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);

                    q.NonBsp.AgencyCreditCardBsp.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);
                    q.NonBsp.AgencyCreditCardNonBsp.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);
                }
                else {
                    var q = lazyContext.NonBsp.Find(id);

                    if (!q.CanUndo())
                        throw new UnreportedException(AppConstants.RecordCannotBeUndone);

                    if (q.PaymentId > 0) {
                        var nonBsp = lazyContext.NonBsp.Find(q.Id);
                        nonBsp.PaymentId = -1;
                        lazyContext.Save(nonBsp, false);
                    }

                    new PaymentCommon(HttpContext).ValidateAndDelete(lazyContext, q.Payment, false);
                    q.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);

                    q.AgencyCreditCardBsp.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);
                    q.AgencyCreditCardNonBsp.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);
                }

                ts.Complete();
                return true;
            }
        }

        public bool Reverse(AppLazyContext lazyContext, int nonBspId, string type, bool validateStatus = true, string agencyCreditCardDocumentNo = null, int agencyCreditCardBspId = 0, int agencyCreditCardNonBspId = 0) {
            using (var ts = Utils.CreateTransactionScope()) {
                var nonBsp = lazyContext.NonBsp.Include(t => t.NonBspDetails).Single(t => t.Id == nonBspId);

                if (validateStatus && !nonBsp.CanReverse())
                    throw new UnreportedException(AppConstants.RecordCannotBeReversed);

                if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), nonBsp.DocumentDate, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                if (type == "CurrentDate" && !Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                var nonBspClone = nonBsp.Clone() as NonBsp;
                nonBspClone.Id = 0;

                if (agencyCreditCardDocumentNo == null) {
                    nonBspClone.DocumentNo = GetReversedDocumentNo(lazyContext, nonBsp.DocumentNo);
                }
                else {
                    nonBspClone.DocumentNo = agencyCreditCardDocumentNo;

                    if (agencyCreditCardBspId > 0) {
                        nonBspClone.AgencyCreditCardBspId = agencyCreditCardBspId;
                    }
                    else if (agencyCreditCardNonBspId > 0) {
                        nonBspClone.AgencyCreditCardNonBspId = agencyCreditCardNonBspId;
                    }
                }

                if (type == "CurrentDate")
                    nonBspClone.DocumentDate = DateTime.Today;

                nonBspClone.Commission = -nonBspClone.Commission;
                nonBspClone.CommissionTax = -nonBspClone.CommissionTax;
                nonBspClone.Discount = -nonBspClone.Discount;
                nonBspClone.DiscountTax = -nonBspClone.DiscountTax;
                nonBspClone.Markup = -nonBspClone.Markup;
                nonBspClone.MarkupTax = -nonBspClone.MarkupTax;
                nonBspClone.MarkupGrossOther = -nonBspClone.MarkupGrossOther;
                nonBspClone.SupplierCancellationFee = -nonBspClone.SupplierCancellationFee;
                nonBspClone.SupplierCancellationFeeTax = -nonBspClone.SupplierCancellationFeeTax;
                nonBspClone.AmountPayable = -nonBspClone.AmountPayable;
                nonBspClone.PaymentId = -1;

                lazyContext.Entry(nonBsp).State = EntityState.Detached;
                lazyContext.Insert(nonBspClone);
                lazyContext.Entry(nonBspClone).State = EntityState.Detached;

                nonBspClone = lazyContext.NonBsp.Find(nonBspClone.Id);
                Validate(nonBspClone, false, false);

                foreach (var nonBspDetail in nonBsp.NonBspDetails) {
                    var nonBspDetailClone = nonBspDetail.Clone() as NonBspDetail;

                    nonBspDetailClone.Id = 0;
                    nonBspDetailClone.NonBspId = nonBspClone.Id;
                    nonBspDetailClone.DocumentStatus = DocumentStatus.Open;
                    nonBspDetailClone.ReversalStatus = ReversalStatus.Reversal;
                    nonBspDetailClone.Amount = -nonBspDetailClone.Amount;
                    nonBspDetailClone.Tax = -nonBspDetailClone.Tax;
                    nonBspDetailClone.NonCommissionable = -nonBspDetailClone.NonCommissionable;
                    nonBspDetailClone.NonCommissionableTax = -nonBspDetailClone.NonCommissionableTax;

                    lazyContext.Insert(nonBspDetailClone);
                    nonBspDetail.UpdateReversalStatus(lazyContext, ReversalStatus.Reversed, -1);
                }

                lazyContext.Entry(nonBspClone).State = EntityState.Detached;
                nonBspClone = lazyContext.NonBsp.Find(nonBspClone.Id);

                nonBspClone.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, nonBspClone.TripLine);
                nonBspClone.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                if (nonBsp.NonBspType != NonBspType.AgencyCC) {
                    foreach (var agencyCreditCardNonBsp in lazyContext.NonBsp.Where(t => t.AgencyCreditCardNonBspId == nonBsp.Id).ToList()) {
                        new NonBspCommon(HttpContext).Reverse(lazyContext, agencyCreditCardNonBsp.Id, type, false, nonBspClone.DocumentNo, 0, nonBspClone.Id);
                    }
                }

                ts.Complete();
                return true;
            }
        }

        public static string GetReversedDocumentNo(AppMainContext context, string documentNo) {
            char suffix = Convert.ToChar(documentNo.Right(1).ToUpper());

            if (suffix >= 65 && suffix <= 89) {
                suffix = Convert.ToChar(suffix + 1);
                documentNo = documentNo.Left(documentNo.Length - 1);
            }
            else {
                suffix = 'A';
            }

            var q = context.NonBsp.Where(t => t.NonBspType != NonBspType.AgencyCC);

            while (q.Any(t => t.DocumentNo == string.Format("{0}{1}", documentNo, suffix))) {
                if (suffix == 'Z') {
                    documentNo += "A";
                    suffix = 'A';
                    continue;
                }

                suffix = Convert.ToChar(suffix + 1);
            }

            return string.Format("{0}{1}", documentNo, suffix);
        }
    }

    public class NonBspDetailCommon {
        private HttpContext HttpContext { get; }

        public NonBspDetailCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool ValidateAndSave(AppLazyContext lazyContext, NonBspDetail nonBspDetail, bool validateDocumentStatus = true, bool performRelatedUpdates = false, bool allowAgencyCcUpdate = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            if (nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross) {
                if (nonBspDetail.NonBsp.NonBspDetails.Any(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard))
                    throw new UnreportedException("This Form of Payment cannot be assigned because another Form of Payment is a credit card or travel card.");
            }

            if (nonBspDetail.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard && nonBspDetail.NonBsp.NonBspDetails.Any(t => t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross))
                throw new UnreportedException("This Form of Payment cannot be assigned because another Form of Payment is an agency credit card or is paying the gross amount to the supplier.");

            Validate(lazyContext, nonBspDetail, false, validateDocumentStatus);

            bool result;

            if (nonBspDetail.Id <= 0) {
                result = lazyContext.Insert(nonBspDetail);
            }
            else {
                result = lazyContext.Save(nonBspDetail);
            }

            if (!result && !performRelatedUpdates)
                return false;

            if (txnUpdateType != TransactionUpdateType.None)
                nonBspDetail.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            ;

            if (nonBspDetail.NonBsp.TripLine?.Id > 0) {
                nonBspDetail.NonBsp.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }
            else if (nonBspDetail.NonBsp.Trip?.Id > 0) {
                nonBspDetail.NonBsp.Trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (allowAgencyCcUpdate && nonBspDetail.NonBsp.NonBspType != NonBspType.AgencyCC && (nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross))
                CreateOrUpdateAgencyCcNonBsp(nonBspDetail);

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, NonBspDetail nonBspDetail, bool validateDocumentStatus = true) {
            Validate(lazyContext, nonBspDetail, true, validateDocumentStatus);
            var tripLine = nonBspDetail.NonBsp.TripLine;

            if (lazyContext.Delete(nonBspDetail))
                return tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return false;
        }

        public void Validate(AppLazyContext lazyContext, NonBspDetail nonBspDetail, bool isDeletion, bool validateDocumentStatus = true) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), nonBspDetail.NonBsp.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!isDeletion && nonBspDetail.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard) {
                int agencyId = nonBspDetail.NonBsp.AgencyId;

                if (agencyId <= 0 && nonBspDetail.Id <= 0)
                    agencyId = HttpContext.CurrentDefaultAgencyId();

                var debtor = nonBspDetail.NonBsp.Trip.Debtor.BillingHeadDebtor;

                if (debtor.Id > 0)
                    debtor.ValidateCreditLimit(lazyContext, TransactionType.NonBsp, nonBspDetail.Id, agencyId, nonBspDetail.Amount + nonBspDetail.Tax + nonBspDetail.NonCommissionableGross - nonBspDetail.DiscountGrossProRata + nonBspDetail.MarkupGrossProRata);
            }

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !nonBspDetail.CanDelete(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !nonBspDetail.CanEdit(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public bool CreateOrUpdate(NonBspDetailViewModel model, bool isTaxIncluded, bool validateLimits, bool validateDocumentStatus = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            if (model.NonBspDetailNonBspType == NonBspType.Admin) {
                model.NonBspDetailTripLineAirPassengerId = -1;
                model.NonBspDetailPassengerId = -1;
                model.NonBspDetailNonCommissionable = 0;
            }

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    var nonBsp = lazyContext.NonBsp.Find(model.NonBspId);
                    bool deleteAutoGenerated = false;

                    if (nonBsp.NonBspType != NonBspType.Admin)
                        model.NonBspDetailIsTaxApplicable = nonBsp.IsTaxApplicable;

                    NonBspDetail q = null;

                    if (model.NonBspDetailId <= 0) {
                        q = new NonBspDetail {
                            Id = 0,
                            DocumentStatus = DocumentStatus.Open,
                            ReversalStatus = ReversalStatus.None,
                            FormOfPaymentId = model.NonBspDetailFormOfPaymentId ?? 0,
                            FormOfPayment = lazyContext.FormOfPayment.Find(model.NonBspDetailFormOfPaymentId),
                            NonBsp = nonBsp
                        };

                        if (nonBsp.NonBspDetails.Count > 0) {
                            if (nonBsp.NonBspDetails.Any(t => t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross))
                                throw new UnreportedException("Due to the Form of Payment Type already assigned, this document can only contain one detail row.");

                            if ((q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross) && nonBsp.NonBspDetails.Any(t => t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardNet && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardGross && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.PaySupplierGross))
                                throw new UnreportedException("Form of Payment Type 'Agency Credit Card' or 'Pay Supplier Gross' cannot be included with other Forms of Payment.");
                        }
                    }
                    else {
                        q = lazyContext.NonBspDetail.Find(model.NonBspDetailId);

                        var formOfPayment = lazyContext.FormOfPayment.Find(model.NonBspDetailFormOfPaymentId);

                        deleteAutoGenerated = (q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross)
                            && formOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardNet && formOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardGross && formOfPayment.FormOfPaymentType != FormOfPaymentType.PaySupplierGross;
                    }

                    int tripLineAirPassengerId = model.NonBspDetailTripLineAirPassengerId ?? 0;
                    int passengerId = -1;

                    if (tripLineAirPassengerId <= 0)
                        passengerId = model.NonBspDetailPassengerId ?? 0;

                    decimal nonCommissionable = model.NonBspDetailNonCommissionable;
                    decimal nonCommissionableTax = 0;
                    decimal tax = 0;
                    decimal amount = model.NonBspDetailAmount;

                    if (model.NonBspDetailIsTaxApplicable || (!validateLimits && nonBsp.IsTaxApplicable)) {
                        decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), nonBsp.DocumentDate);

                        nonCommissionableTax = Math.Round(nonCommissionable * taxRate / (1 + taxRate), 2);
                        nonCommissionable -= nonCommissionableTax;

                        if (isTaxIncluded) {
                            tax = Math.Round(amount * taxRate / (1 + taxRate), 2);
                            amount -= tax;
                        }
                        else {
                            tax = Math.Round(amount * taxRate, 2);
                        }

                        if (validateLimits) {
                            if (Math.Abs(model.NonBspDetailTax - tax) > .02m)
                                throw new UnreportedException(string.Format("{0} value is outside accepted limits.", Resource.TaxLabel));

                            if (tax != model.NonBspDetailTax) {
                                tax = model.NonBspDetailTax;

                                if (isTaxIncluded)
                                    amount = model.NonBspDetailAmount - tax;
                            }
                        }
                    }

                    q.NonBspId = model.NonBspId;
                    q.TripLineAirPassengerId = tripLineAirPassengerId;
                    q.PassengerId = passengerId;
                    q.FormOfPaymentId = model.NonBspDetailFormOfPaymentId ?? 0;
                    q.Amount = amount;
                    q.Tax = tax;
                    q.NonCommissionable = nonCommissionable;
                    q.NonCommissionableTax = nonCommissionableTax;
                    q.IsTaxApplicable = model.NonBspDetailIsTaxApplicable;

                    if (model.NonBspDetailId <= 0) {
                        q.TripLineAirPassenger = lazyContext.TripLineAirPassenger.Find(q.TripLineAirPassengerId);
                        q.Passenger = lazyContext.Passenger.Find(q.PassengerId);
                        q.FormOfPayment = lazyContext.FormOfPayment.Find(q.FormOfPaymentId);
                    }

                    if (q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross && q.NonBsp.Creditor.IsBspAgent)
                        throw new UnreportedException("Forms of Payment of type 'Pay Supplier Gross' are not permitted for this document.");

                    bool result = ValidateAndSave(lazyContext, q, validateDocumentStatus, false, true, txnUpdateType);

                    nonBsp = lazyContext.NonBsp.Find(model.NonBspId);
                    nonBsp.AmountPayable = nonBsp.GetAmountPayable(lazyContext);
                    lazyContext.Save(nonBsp, false);

                    if (deleteAutoGenerated) {
                        var agencyCreditCardNonBsps = lazyContext.NonBsp.Where(t => t.AgencyCreditCardNonBspId == nonBsp.Id).ToList();

                        if (agencyCreditCardNonBsps.Count > 0) {
                            if (agencyCreditCardNonBsps.Count == 1 && lazyContext.Bsp.Any(t => t.Id == nonBsp.Id))
                                throw new InvalidOperationException("This document cannot be updated because it has a related BSP Return.");

                            foreach (var agencyCreditCardNonBsp in agencyCreditCardNonBsps) {
                                lazyContext.RemoveRange(agencyCreditCardNonBsp.Transactions.SelectMany(t => t.TransactionDetails).SelectMany(t => t.TransactionDetailAllocations));
                                lazyContext.RemoveRange(agencyCreditCardNonBsp.Transactions);
                                lazyContext.SaveChanges();

                                nonBsp.AgencyCreditCardNonBspId = -1;
                                lazyContext.Save(nonBsp, false);

                                lazyContext.Delete(agencyCreditCardNonBsp, false);
                            }
                        }
                    }

                    model.NonBspDetailId = q.Id;

                    ts.Complete();
                    return result;
                }
            }
        }

        public bool CreateOrUpdate(NonBspViewModel model, NonBspDetailViewModel detailModel, bool isNew) {
            using (var ts = Utils.CreateTransactionScope()) {
                new NonBspCommon(HttpContext).CreateOrUpdate(model, true, !isNew, true, false, TransactionUpdateType.None);
                detailModel.NonBspId = model.NonBspId;
                CreateOrUpdate(detailModel, model.NonBspIsTaxIncluded, detailModel.NonBspDetailId > 0, !isNew);
                ts.Complete();
                return true;
            }
        }

        public bool CreateOrUpdateAgencyCcNonBsp(NonBspDetail nonBspDetail) {
            var nonBsp = nonBspDetail.NonBsp;
            int sign = nonBsp.Sign;

            if (nonBsp.NonBspType == NonBspType.AgencyCC)
                return false;

            if (nonBspDetail.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardNet && nonBspDetail.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardGross && nonBspDetail.FormOfPayment.FormOfPaymentType != FormOfPaymentType.PaySupplierGross)
                throw new UnreportedException("This document does not contain a valid Form of Payment.");

            if (nonBsp.NonBspDetails.Count > 1)
                throw new UnreportedException("This document can only contain one detail row.");

            if (nonBsp.NonBspDetails.Any(t => t.Id != nonBspDetail.Id && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardNet && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardGross && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.PaySupplierGross))
                throw new UnreportedException("This document contains one or more invalid Forms of Payment.");

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                decimal commission = 0;
                decimal commissionTax = 0;
                decimal amountPayable = 0;

                if (nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross) {
                    commission = nonBsp.Commission * sign;
                    commissionTax = nonBsp.CommissionTax * sign;
                    amountPayable = -(nonBsp.Commission + nonBsp.CommissionTax);
                }
                else if (nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet) {
                    amountPayable = nonBspDetail.Amount + nonBspDetail.Tax - nonBsp.Commission - nonBsp.CommissionTax;
                }
                else if (nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross) {
                    amountPayable = nonBspDetail.Amount + nonBspDetail.Tax;
                }

                amountPayable -= nonBsp.SupplierCancellationFee + nonBsp.SupplierCancellationFeeTax;
                amountPayable *= sign;

                var nonBspClone = lazyContext.NonBsp.FirstOrDefault(t => t.AgencyCreditCardNonBspId == nonBsp.Id);

                if (nonBspClone == null) {
                    nonBspClone = nonBsp.Clone() as NonBsp;
                    nonBspClone.Id = 0;
                }

                nonBspClone.NonBspType = NonBspType.AgencyCC;
                nonBspClone.DocumentNo = nonBsp.DocumentNo;
                nonBspClone.DocumentDate = nonBsp.DocumentDate;
                nonBspClone.TripId = nonBsp.TripId;
                nonBspClone.TripLineId = nonBsp.TripLineId;
                nonBspClone.CreditorId = nonBsp.CreditorId;
                nonBspClone.SupplierId = nonBsp.SupplierId;
                nonBspClone.ChartOfAccountId = -1;
                nonBspClone.AirlineId = nonBsp.AirlineId;
                nonBspClone.DepartureDate = DateTime.MinValue;
                nonBspClone.OfferedFare = nonBsp.OfferedFare;
                nonBspClone.OfferedReasonId = nonBsp.OfferedReasonId;
                nonBspClone.SaleTypeId = nonBsp.SaleTypeId;
                nonBspClone.CategoryId = nonBsp.CategoryId;
                nonBspClone.DestinationId = nonBsp.DestinationId;
                nonBspClone.AgencyId = nonBsp.AgencyId;
                nonBspClone.ConsultantId = nonBsp.ConsultantId;
                nonBspClone.AgentId = nonBsp.AgentId;
                nonBspClone.SourceId = nonBsp.SourceId;
                nonBspClone.Commission = -commission;
                nonBspClone.CommissionTax = -commissionTax;
                nonBspClone.Discount = 0;
                nonBspClone.DiscountTax = 0;
                nonBspClone.DiscountReasonId = -1;
                nonBspClone.Markup = 0;
                nonBspClone.MarkupTax = 0;
                nonBspClone.MarkupStrategyId = -1;
                nonBspClone.SupplierCancellationFee = 0;
                nonBspClone.SupplierCancellationFeeTax = 0;
                nonBspClone.AmountPayable = nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross ? (commission + commissionTax) : -(amountPayable + nonBspDetail.NonCommissionableGross * sign);
                nonBspClone.PaymentId = -1;
                nonBspClone.AgencyCreditCardBspId = -1;
                nonBspClone.AgencyCreditCardNonBspId = nonBsp.Id;
                nonBspClone.LoyaltySchemeReceiptDetailId = -1;
                nonBspClone.SupplierOtherCommissionReceiptId = -1;

                bool result;

                if (nonBspClone.Id <= 0) {
                    result = lazyContext.Insert(nonBspClone);
                }
                else {
                    result = lazyContext.Save(nonBspClone);
                }

                if (result) {
                    var nonBspDetailClone = lazyContext.NonBsp.FirstOrDefault(t => t.AgencyCreditCardNonBspId == nonBsp.Id)?.NonBspDetails.SingleOrDefault();

                    if (nonBspDetailClone == null) {
                        nonBspDetailClone = nonBspDetail.Clone() as NonBspDetail;
                        nonBspDetailClone.Id = 0;
                    }

                    nonBspDetailClone.NonBspId = nonBspClone.Id;
                    nonBspDetailClone.DocumentStatus = DocumentStatus.Open;
                    nonBspDetailClone.ReversalStatus = ReversalStatus.None;
                    nonBspDetailClone.Tax = 0;
                    nonBspDetailClone.IsTaxApplicable = false;

                    if (nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross) {
                        nonBspDetailClone.Amount = 0;
                        nonBspDetailClone.Tax = 0;
                        nonBspDetailClone.NonCommissionable = 0;
                        nonBspDetailClone.NonCommissionableTax = 0;
                    }
                    else {
                        nonBspDetailClone.Amount = -amountPayable;
                        nonBspDetailClone.Tax = 0;
                        nonBspDetailClone.NonCommissionable = -nonBspDetail.NonCommissionable * sign;
                        nonBspDetailClone.NonCommissionableTax = -nonBspDetail.NonCommissionableTax * sign;
                    }

                    if (nonBspDetailClone.Id <= 0) {
                        lazyContext.Insert(nonBspDetailClone);
                    }
                    else {
                        lazyContext.Save(nonBspDetailClone);
                    }

                    lazyContext.Entry(nonBspDetailClone).State = EntityState.Detached;

                    lazyContext.Entry(nonBspClone).State = EntityState.Detached;
                    nonBspClone = lazyContext.NonBsp.Find(nonBspClone.Id);
                    nonBspClone.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, nonBspClone.TripLine);
                }

                lazyContext.Entry(nonBspClone).State = EntityState.Detached;
                nonBspClone = lazyContext.NonBsp.Where(t => t.AgencyCreditCardNonBspId == nonBsp.Id).FirstOrDefault(t => t.Id != nonBspClone.Id);

                if (nonBspClone == null) {
                    nonBspClone = nonBsp.Clone() as NonBsp;
                    nonBspClone.Id = 0;
                }

                amountPayable += nonBspDetail.NonCommissionableGross * sign;

                nonBspClone.NonBspType = NonBspType.AgencyCC;
                nonBspClone.DocumentNo = nonBsp.DocumentNo;
                nonBspClone.DocumentDate = nonBsp.DocumentDate;
                nonBspClone.TripId = nonBsp.TripId;
                nonBspClone.TripLineId = nonBsp.TripLineId;
                nonBspClone.CreditorId = nonBspDetail.FormOfPayment.CreditorId;
                nonBspClone.SupplierId = nonBspDetail.FormOfPayment.DefaultSupplierId;
                nonBspClone.ChartOfAccountId = -1;
                nonBspClone.AirlineId = nonBsp.AirlineId;
                nonBspClone.DepartureDate = DateTime.MinValue;
                nonBspClone.OfferedFare = nonBsp.OfferedFare;
                nonBspClone.OfferedReasonId = nonBsp.OfferedReasonId;
                nonBspClone.SaleTypeId = nonBsp.SaleTypeId;
                nonBspClone.CategoryId = nonBsp.CategoryId;
                nonBspClone.DestinationId = nonBsp.DestinationId;
                nonBspClone.AgencyId = nonBsp.AgencyId;
                nonBspClone.ConsultantId = nonBsp.ConsultantId;
                nonBspClone.AgentId = nonBsp.AgentId;
                nonBspClone.SourceId = nonBsp.SourceId;
                nonBspClone.Commission = commission;
                nonBspClone.CommissionTax = commissionTax;
                nonBspClone.Discount = 0;
                nonBspClone.DiscountTax = 0;
                nonBspClone.DiscountReasonId = -1;
                nonBspClone.Markup = 0;
                nonBspClone.MarkupTax = 0;
                nonBspClone.MarkupStrategyId = -1;
                nonBspClone.AmountPayable = nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross ? -(commission + commissionTax) : amountPayable;
                nonBspClone.PaymentId = -1;
                nonBspClone.AgencyCreditCardBspId = -1;
                nonBspClone.AgencyCreditCardNonBspId = nonBsp.Id;
                nonBspClone.LoyaltySchemeReceiptDetailId = -1;
                nonBspClone.SupplierOtherCommissionReceiptId = -1;

                if (nonBspClone.Id <= 0) {
                    result = lazyContext.Insert(nonBspClone);
                }
                else {
                    result = lazyContext.Save(nonBspClone);
                }

                if (result) {
                    var nonBspDetailClone = nonBspClone.NonBspDetails.SingleOrDefault();

                    if (nonBspDetailClone == null) {
                        nonBspDetailClone = nonBspDetail.Clone() as NonBspDetail;
                        nonBspDetailClone.Id = 0;
                    }

                    nonBspDetailClone.NonBspId = nonBspClone.Id;
                    nonBspDetailClone.DocumentStatus = DocumentStatus.Open;
                    nonBspDetailClone.ReversalStatus = ReversalStatus.None;
                    nonBspDetailClone.Tax = 0;
                    nonBspDetailClone.NonCommissionable = 0;
                    nonBspDetailClone.NonCommissionableTax = 0;
                    nonBspDetailClone.IsTaxApplicable = false;

                    if (nonBspDetail.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross) {
                        nonBspDetailClone.Amount = 0;
                        nonBspDetailClone.Tax = 0;
                    }
                    else {
                        nonBspDetailClone.Amount = amountPayable;
                        nonBspDetailClone.Tax = 0;
                    }

                    if (nonBspDetailClone.Id <= 0) {
                        lazyContext.Insert(nonBspDetailClone);
                    }
                    else {
                        lazyContext.Save(nonBspDetailClone);
                    }

                    lazyContext.Entry(nonBspClone).State = EntityState.Detached;
                    nonBspClone = lazyContext.NonBsp.Find(nonBspClone.Id);
                    nonBspClone.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, nonBspClone.TripLine);
                }

                return true;
            }
        }

        public bool Delete(AppLazyContext lazyContext, NonBspDetailViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.NonBspDetail.Find(model.NonBspDetailId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (q.NonBsp.NonBspDetails.Count == 1)
                    throw new UnreportedException(AppConstants.RecordCannotBeDeleted);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }
    }

    public class PaymentCommon {
        private HttpContext HttpContext { get; }

        public PaymentCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool ValidateAndSave(AppLazyContext lazyContext, Payment payment, bool validateDocumentStatus = true, bool performRelatedUpdates = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow, int oldTripId = 0) {
            Validate(lazyContext, payment, false, validateDocumentStatus);

            var payments = lazyContext.Payment.Where(t => t.Id != payment.Id && t.DocumentNo == payment.DocumentNo && t.PaymentType == payment.PaymentType && t.IsSplit);

            if (payments.Count() == 1 && !payment.IsSplit) {
                payment.IsSplit = false;
            }
            else if (payments.Any(t => t.TripId > 0 && t.TripId == payment.TripId)) {
                throw new UnreportedException("The selected Trip has already been added to this Payment collection.");
            }

            bool result;

            if (payment.Id <= 0) {
                result = lazyContext.Insert(payment);
            }
            else {
                result = lazyContext.Save(payment);
            }

            if (!result && !performRelatedUpdates)
                return false;

            if (txnUpdateType != TransactionUpdateType.None)
                payment.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            if (oldTripId > 0) {
                foreach (var tripLine in lazyContext.Trip.Find(oldTripId).TripLines.Where(t => t.Id > 0).ToList()) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }

            foreach (var tripLine in payment.PaymentDetails.Where(t => t.TripLineId > 0).Select(t => t.TripLine).Distinct().ToList()) {
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (payment.PaymentDetails.All(t => t.TripLineId <= 0) && payment.Trip?.Id > 0)
                payment.Trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, Payment payment, bool validateDocumentStatus = true) {
            using (var ts = Utils.CreateTransactionScope()) {
                Validate(lazyContext, payment, true, validateDocumentStatus);

                foreach (var bsp in lazyContext.Bsp.Where(t => t.PaymentId == payment.Id).ToList()) {
                    bsp.PaymentId = -1;
                    lazyContext.Save(bsp, false);
                    bsp.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);
                }

                foreach (var nonBsp in lazyContext.NonBsp.Where(t => t.PaymentId == payment.Id).ToList()) {
                    nonBsp.PaymentId = -1;
                    lazyContext.Save(nonBsp, false);
                    nonBsp.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);
                }

                lazyContext.RemoveRange(payment.Transactions);
                lazyContext.SaveChanges();

                if (HttpContext.IsSuperUser()) {
                    int[] paymentDetailIds = payment.PaymentDetails.Select(t => t.Id).ToArray();

                    lazyContext.RemoveRange(lazyContext.TransactionDetail.Where(t => paymentDetailIds.Contains(t.PaymentDetailId)).SelectMany(t => t.TransactionDetailAllocations));
                    lazyContext.SaveChanges();

                    lazyContext.RemoveRange(lazyContext.TransactionDetailAllocation.Where(t => paymentDetailIds.Contains(t.PaymentDetailId)));
                    lazyContext.SaveChanges();
                }

                var tripLines = payment.PaymentDetails.Where(t => t.TripLineId > 0).Select(t => t.TripLine).Distinct().ToList();

                if (!lazyContext.Delete(payment))
                    return false;

                if (tripLines.Count > 0) {
                    foreach (var tripLine in tripLines) {
                        tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                    }
                }
                else if (payment.Trip?.Id > 0) {
                    payment.Trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }

                ts.Complete();
                return true;
            }
        }

        public void Validate(AppLazyContext lazyContext, Payment payment, bool isDeletion, bool validateDocumentStatus = true) {
            if (!isDeletion && payment.AgencyId <= 0)
                throw new UnreportedException(AppConstants.AgencyNotSpecified);

            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), payment.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (payment.BankAccount.DailyWithdrawalLimit > 0) {
                decimal amount = payment.AmountPayable + payment.AmountPayableTax + (lazyContext.Payment.Where(t => t.Id != payment.Id && t.DocumentDate == payment.DocumentDate && t.BankAccountId == payment.BankAccountId).Sum(t => (decimal?)(t.AmountPayable + t.AmountPayableTax)) ?? 0);
                decimal difference = amount - payment.BankAccount.DailyWithdrawalLimit;

                if (difference > 0)
                    throw new UnreportedException(string.Format("Daily withdrawal limit has been exceeded by {0:c2}.", difference));
            }

            if (!isDeletion && payment.TripId > 0 && !payment.Trip.IsBooking)
                throw new UnreportedException(AppConstants.RecordIsNotBooking);

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !payment.CanDelete(HttpContext.IsAdministrator(), HttpContext.IsAccounts(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !payment.CanEdit(HttpContext.IsAdministrator(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public int Create(AppLazyContext lazyContext, int bankAccountId, string comments, bool isDeposit, string paymentAddModels) {
            var models = JsonSerializer.Deserialize<List<PaymentAddViewModel>>(paymentAddModels, JsonExtensionsBiz.JsonSerializerOptions());

            if (models.Count == 0)
                throw new UnreportedException("No trip lines were selected.");

            models.Reverse();

            if (isDeposit) {
                if (models.Any(t => t.PaymentAddPaymentType == PaymentType.Admin))
                    throw new UnreportedException("Deposits cannot include payment type 'Adjustment'.");

                if (models.Sum(t => t.PaymentAddAmount) == models.Where(t => t.PaymentAddIsParent).Sum(t => t.PaymentAddAmountPayable))
                    throw new UnreportedException("Payment total is equal to amount payable. Payment cannot be flagged as a deposit.");

                foreach (var model in models) {
                    model.PaymentAddNonCommissionable = 0;
                    model.PaymentAddCommission = 0;
                    model.PaymentAddDiscount = 0;
                    model.PaymentAddMarkup = 0;
                }
            }
            else if (models.Sum(t => t.PaymentAddAmount) != models.Where(t => t.PaymentAddIsParent).Sum(t => t.PaymentAddAmountPayable)) {
                throw new UnreportedException("Payment total does not equal amount payable. Payment should be flagged as a deposit.");
            }

            using (var ts = Utils.CreateTransactionScope()) {
                TripLineAirPassenger tripLineAirPassenger = null;
                TripLineLand tripLineLand = null;
                TripLineInsurance tripLineInsurance = null;
                TripLineForeignCurrency tripLineForeignCurrency = null;
                TripLineServiceFee tripLineServiceFee = null;
                TripLineOtherInclusion tripLineOtherInclusion = null;

                var paymentIds = new Dictionary<int, string>();
                var paymentType = PaymentType.All;

                bool isBooking = false;
                bool isCreditCardDiscountApplicable = false;
                bool includeMarkupInCreditCardPayment = false;

                int paymentAddId = -1;
                int tripId = -1;
                int tripLineId = -1;
                int airlineId = -1;
                int creditorId = -1;
                int supplierId = -1;
                int saleTypeId = -1;
                int groupId = -1;
                int categoryId = -1;
                int destinationId = -1;
                int agencyId = -1;
                int consultantId = -1;
                int agentId = -1;
                int sourceId = -1;
                int discountReasonId = -1;
                int markupStrategyId = -1;
                int offeredReasonId = -1;

                int bspCount = 0;
                int nonBspCount = 0;
                int paymentCount = 0;
                int adminCount = 0;

                decimal commissionGross = 0;
                decimal discountGross = 0;
                decimal markupGross = 0;
                decimal offeredFare = 0;

                string documentNo = null;
                string payee = null;
                string message = null;

                DateTime documentDate = DateTime.MinValue;
                DateTime departureDate = DateTime.MinValue;
                DateTime bspDepartureDate = DateTime.MinValue;
                DateTime nonBspDepartureDate = DateTime.MinValue;

                var bspModel = new BspViewModel();
                var nonBspModel = new NonBspViewModel();
                var paymentModel = new PaymentViewModel();
                var adjustmentModel = new AdjustmentViewModel();

                foreach (var model in models.GroupBy(t => new { t.PaymentAddId, PaymentAddDocumentNo = t.PaymentAddDocumentNo.ToUpper(), t.PaymentAddTripLineType })) {
                    if (string.IsNullOrEmpty(model.Key.PaymentAddDocumentNo) && model.Last().PaymentAddPaymentType != PaymentType.Admin) {
                        throw new UnreportedException("Document No is required.");
                    }
                    else if (model.Sum(t => t.PaymentAddAmount) == 0 && model.Sum(t => t.PaymentAddNonCommissionable) == 0 && model.Sum(t => t.PaymentAddCommission) == 0 && model.Sum(t => t.PaymentAddDiscount) == 0 && model.Sum(t => t.PaymentAddMarkup) == 0) {
                        if (model.Last().PaymentAddPaymentType == PaymentType.Admin) {
                            throw new UnreportedException("Payment amount is zero for one or more documents.");
                        }
                        else {
                            throw new UnreportedException(string.Format("Payment amount is zero for Document No {0}.", model.Key.PaymentAddDocumentNo));
                        }
                    }
                    /*else {
                        decimal paymentAddAmount = model.Sum(t => t.PaymentAddAmount);
                        decimal paymentAddCommission = model.Sum(t => t.PaymentAddCommission);
                        decimal paymentAddDiscount = model.Sum(t => t.PaymentAddDiscount);
                        decimal paymentAddMarkup = model.Sum(t => t.PaymentAddMarkup);

                        if (paymentAddAmount > model.Sum(t => t.PaymentAddAmountPayable))
                            throw new UnreportedException(string.Format("Payment amount exceeds the amount required for {0}.", model.Key.PaymentAddTripLineType == TripLineType.ServiceFee ? string.Format("Type {0}", TripLineType.ServiceFee.GetEnumDescription()) : string.Format("Document No {0}", model.Key.PaymentAddDocumentNo)));

                        if (paymentAddCommission > model.Last().PaymentAddCommissionMax)
                            throw new UnreportedException(string.Format("Commission exceeds the amount required for {0}.", model.Key.PaymentAddTripLineType == TripLineType.ServiceFee ? string.Format("Type {0}", TripLineType.ServiceFee.GetEnumDescription()) : string.Format("Document No {0}", model.Key.PaymentAddDocumentNo)));

                        if (paymentAddDiscount > model.Last().PaymentAddDiscountMax)
                            throw new UnreportedException(string.Format("Discount exceeds the amount required for {0}.", model.Key.PaymentAddTripLineType == TripLineType.ServiceFee ? string.Format("Type {0}", TripLineType.ServiceFee.GetEnumDescription()) : string.Format("Document No {0}", model.Key.PaymentAddDocumentNo)));

                        if (paymentAddMarkup > model.Last().PaymentAddMarkupMax)
                            throw new UnreportedException(string.Format("Mark-Up exceeds the amount required for {0}.", model.Key.PaymentAddTripLineType == TripLineType.ServiceFee ? string.Format("Type {0}", TripLineType.ServiceFee.GetEnumDescription()) : string.Format("Document No {0}", model.Key.PaymentAddDocumentNo)));
                    }*/
                }

                foreach (var model in models.Where(t => t.PaymentAddIsParent).GroupBy(t => new { t.PaymentAddTripLineType, t.PaymentAddTripLineId, t.PaymentAddTripLineAirPassengerId, PaymentAddDocumentNo = t.PaymentAddDocumentNo.ToUpper(), t.PaymentAddFormOfPaymentId }).OrderBy(t => t.Key.PaymentAddTripLineType)) {
                    var formOfPayment = lazyContext.FormOfPayment.Find(model.Key.PaymentAddFormOfPaymentId);

                    paymentType = paymentAddId == model.Last().PaymentAddId ? paymentType : model.Last().PaymentAddPaymentType;
                    documentNo = paymentAddId == model.Last().PaymentAddId ? documentNo : model.Last().PaymentAddPaymentType == PaymentType.Admin ? string.Empty : model.Key.PaymentAddDocumentNo;
                    documentDate = paymentAddId == model.Last().PaymentAddId ? documentDate : model.Last().PaymentAddDocumentDate ?? DateTime.MinValue;

                    paymentAddId = model.Last().PaymentAddId;

                    if ((paymentType == PaymentType.SupplierPayment || paymentType == PaymentType.Admin) && (formOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || formOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet))
                        throw new UnreportedException("Agency Credit Card is not permitted for payment type 'Payment' or 'Adjustment'.");

                    bool isCreditorRequired = false;
                    bool isSupplierRequired = false;

                    decimal amountPayable = models.Where(t => t.PaymentAddId == paymentAddId && t.PaymentAddIsParent).Sum(t => (decimal?)t.PaymentAddAmountPayable) ?? 0;

                    if (paymentType == PaymentType.Admin) {
                        if (amountPayable != models.Where(t => t.PaymentAddId == paymentAddId).Sum(t => t.PaymentAddAmount))
                            throw new UnreportedException("Adjustment Amount cannot be part-paid.");
                    }
                    else if (isDeposit || amountPayable != models.Where(t => t.PaymentAddId == paymentAddId).Sum(t => t.PaymentAddAmount)) {
                        decimal nonCommissionableGross = model.Sum(t => (decimal?)t.PaymentAddNonCommissionable) ?? 0;

                        commissionGross = model.Sum(t => (decimal?)t.PaymentAddCommission) ?? 0;
                        discountGross = model.Sum(t => (decimal?)t.PaymentAddDiscount) ?? 0;
                        markupGross = model.Sum(t => (decimal?)t.PaymentAddMarkup) ?? 0;

                        if (nonCommissionableGross != 0 || commissionGross != 0 || discountGross != 0 || markupGross != 0)
                            throw new UnreportedException("Non-Commissionable, Commission, Discount and Mark-Up must be zero for a part-payment.");
                    }

                    paymentModel.PaymentIsDeposit = isDeposit;

                    commissionGross = model.Last().PaymentAddCommission;
                    discountGross = model.Last().PaymentAddDiscount;
                    markupGross = model.Last().PaymentAddMarkup;

                    switch (model.Key.PaymentAddTripLineType) {
                        case TripLineType.Air:
                            tripLineAirPassenger = lazyContext.TripLineAirPassenger.Find(model.Key.PaymentAddTripLineAirPassengerId);

                            if (tripLineAirPassenger.BspEntryType == BspEntryType.Refund) {
                                foreach (var row in model) {
                                    row.PaymentAddAmount = -row.PaymentAddAmount;
                                    row.PaymentAddNonCommissionable = -row.PaymentAddNonCommissionable;
                                    row.PaymentAddCommission = -row.PaymentAddCommission;
                                    row.PaymentAddDiscount = -row.PaymentAddDiscount;
                                    row.PaymentAddMarkup = -row.PaymentAddMarkup;
                                    row.PaymentAddAmountPayable = -row.PaymentAddAmountPayable;
                                }
                            }

                            if (paymentType == PaymentType.BspReturn && !tripLineAirPassenger.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'BSP'.");
                            }
                            else if (paymentType == PaymentType.NonBspReturn && tripLineAirPassenger.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'Non-BSP'.");
                            }

                            isBooking = tripLineAirPassenger.TripLineAir.TripLine.IsBooking;

                            payee = tripLineAirPassenger.Creditor.Name;
                            departureDate = tripLineAirPassenger.TripLineAir.TripLine.Trip.DepartureDate;
                            offeredFare = tripLineAirPassenger.GetOfferedFareDue(lazyContext);

                            tripId = tripLineAirPassenger.TripLineAir.TripLine.TripId;
                            tripLineId = tripLineAirPassenger.TripLineId;
                            agentId = tripLineAirPassenger.TripLineAir.TripLine.Trip.AgentId;
                            creditorId = tripLineAirPassenger.CreditorId;
                            supplierId = tripLineAirPassenger.SupplierId;
                            saleTypeId = tripLineAirPassenger.SaleTypeId;
                            groupId = tripLineAirPassenger.TripLineAir.TripLine.Trip.GroupId;
                            categoryId = tripLineAirPassenger.TripLineAir.TripLine.Trip.CategoryId;
                            destinationId = tripLineAirPassenger.TripLineAir.TripLine.Trip.DestinationId;
                            agencyId = tripLineAirPassenger.TripLineAir.TripLine.Trip.AgencyId;
                            consultantId = tripLineAirPassenger.TripLineAir.TripLine.Trip.ConsultantId;
                            sourceId = tripLineAirPassenger.TripLineAir.TripLine.Trip.SourceId;
                            airlineId = tripLineAirPassenger.AirlineId;
                            discountReasonId = tripLineAirPassenger.DiscountReasonId;
                            markupStrategyId = tripLineAirPassenger.MarkupStrategyId;
                            offeredReasonId = tripLineAirPassenger.OfferedReasonId;

                            isCreditCardDiscountApplicable = tripLineAirPassenger.IsCreditCardDiscountApplicable;
                            includeMarkupInCreditCardPayment = tripLineAirPassenger.IncludeMarkupInCreditCardPayment;

                            isCreditorRequired = creditorId <= 0;
                            isSupplierRequired = supplierId <= 0;

                            if (tripLineAirPassenger.TicketNo != model.Key.PaymentAddDocumentNo) {
                                tripLineAirPassenger.TicketNo = model.Key.PaymentAddDocumentNo;
                                lazyContext.Save(tripLineAirPassenger, false);
                            }

                            break;
                        case TripLineType.Accommodation:
                        case TripLineType.Transport:
                        case TripLineType.Cruise:
                        case TripLineType.Tour:
                        case TripLineType.OtherLand:
                            tripLineLand = lazyContext.TripLineLand.Single(t => t.TripLineId == model.Key.PaymentAddTripLineId);

                            if (paymentType == PaymentType.BspReturn && !tripLineLand.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'BSP'.");
                            }
                            else if (paymentType == PaymentType.NonBspReturn && tripLineLand.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'Non-BSP'.");
                            }

                            isBooking = tripLineLand.TripLine.IsBooking;

                            payee = tripLineLand.Creditor.Name;
                            departureDate = tripLineLand.TripLine.Trip.DepartureDate;
                            offeredFare = tripLineLand.TripLine.GetOfferedFareDue(lazyContext);

                            tripId = tripLineLand.TripLine.TripId;
                            tripLineId = tripLineLand.TripLineId;
                            airlineId = -1;
                            creditorId = tripLineLand.CreditorId;
                            supplierId = tripLineLand.SupplierId;
                            saleTypeId = tripLineLand.SaleTypeId;
                            groupId = tripLineLand.TripLine.Trip.GroupId;
                            categoryId = tripLineLand.TripLine.Trip.CategoryId;
                            destinationId = tripLineLand.TripLine.Trip.DestinationId;
                            agencyId = tripLineLand.TripLine.Trip.AgencyId;
                            consultantId = tripLineLand.TripLine.Trip.ConsultantId;
                            agentId = tripLineLand.TripLine.Trip.AgentId;
                            sourceId = tripLineLand.TripLine.Trip.SourceId;
                            discountReasonId = tripLineLand.DiscountReasonId;
                            markupStrategyId = tripLineLand.MarkupStrategyId;
                            offeredReasonId = tripLineLand.OfferedReasonId;

                            isCreditCardDiscountApplicable = tripLineLand.IsCreditCardDiscountApplicable;
                            includeMarkupInCreditCardPayment = tripLineLand.IncludeMarkupInCreditCardPayment;

                            isCreditorRequired = creditorId <= 0;
                            isSupplierRequired = supplierId <= 0;

                            if (tripLineLand.DocumentNo != model.Key.PaymentAddDocumentNo) {
                                tripLineLand.DocumentNo = model.Key.PaymentAddDocumentNo;
                                lazyContext.Save(tripLineLand, false);
                            }

                            break;
                        case TripLineType.Insurance:
                            tripLineInsurance = lazyContext.TripLineInsurance.Single(t => t.TripLineId == model.Key.PaymentAddTripLineId);

                            if (paymentType == PaymentType.BspReturn && !tripLineInsurance.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'BSP'.");
                            }
                            else if (paymentType == PaymentType.NonBspReturn && tripLineInsurance.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'Non-BSP'.");
                            }

                            isBooking = tripLineInsurance.TripLine.IsBooking;

                            payee = tripLineInsurance.Creditor.Name;
                            departureDate = tripLineInsurance.TripLine.Trip.DepartureDate;
                            offeredFare = tripLineInsurance.TripLine.GetOfferedFareDue(lazyContext);

                            tripId = tripLineInsurance.TripLine.TripId;
                            tripLineId = tripLineInsurance.TripLineId;
                            airlineId = -1;
                            creditorId = tripLineInsurance.CreditorId;
                            supplierId = tripLineInsurance.SupplierId;
                            saleTypeId = tripLineInsurance.SaleTypeId;
                            groupId = tripLineInsurance.TripLine.Trip.GroupId;
                            categoryId = tripLineInsurance.TripLine.Trip.CategoryId;
                            destinationId = tripLineInsurance.TripLine.Trip.DestinationId;
                            agencyId = tripLineInsurance.TripLine.Trip.AgencyId;
                            consultantId = tripLineInsurance.TripLine.Trip.ConsultantId;
                            agentId = tripLineInsurance.TripLine.Trip.AgentId;
                            sourceId = tripLineInsurance.TripLine.Trip.SourceId;
                            discountReasonId = tripLineInsurance.DiscountReasonId;
                            markupStrategyId = tripLineInsurance.MarkupStrategyId;
                            offeredReasonId = -1;

                            isCreditCardDiscountApplicable = tripLineInsurance.IsCreditCardDiscountApplicable;
                            includeMarkupInCreditCardPayment = tripLineInsurance.IncludeMarkupInCreditCardPayment;

                            isCreditorRequired = creditorId <= 0;
                            isSupplierRequired = supplierId <= 0;

                            if (tripLineInsurance.PolicyNo != model.Key.PaymentAddDocumentNo) {
                                tripLineInsurance.PolicyNo = model.Key.PaymentAddDocumentNo;
                                lazyContext.Save(tripLineInsurance, false);
                            }

                            break;
                        case TripLineType.ForeignCurrency:
                            tripLineForeignCurrency = lazyContext.TripLineForeignCurrency.Single(t => t.TripLineId == model.Key.PaymentAddTripLineId);

                            if (paymentType == PaymentType.BspReturn && !tripLineForeignCurrency.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'BSP'.");
                            }
                            else if (paymentType == PaymentType.NonBspReturn && tripLineForeignCurrency.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'Non-BSP'.");
                            }

                            isBooking = tripLineForeignCurrency.TripLine.IsBooking;

                            payee = tripLineForeignCurrency.Creditor.Name;
                            departureDate = tripLineForeignCurrency.TripLine.Trip.DepartureDate;
                            offeredFare = tripLineForeignCurrency.TripLine.GetOfferedFareDue(lazyContext);

                            tripId = tripLineForeignCurrency.TripLine.TripId;
                            tripLineId = tripLineForeignCurrency.TripLineId;
                            airlineId = -1;
                            creditorId = tripLineForeignCurrency.CreditorId;
                            supplierId = tripLineForeignCurrency.SupplierId;
                            saleTypeId = tripLineForeignCurrency.SaleTypeId;
                            groupId = tripLineForeignCurrency.TripLine.Trip.GroupId;
                            categoryId = tripLineForeignCurrency.TripLine.Trip.CategoryId;
                            destinationId = tripLineForeignCurrency.TripLine.Trip.DestinationId;
                            agencyId = tripLineForeignCurrency.TripLine.Trip.AgencyId;
                            consultantId = tripLineForeignCurrency.TripLine.Trip.ConsultantId;
                            agentId = tripLineForeignCurrency.TripLine.Trip.AgentId;
                            sourceId = tripLineForeignCurrency.TripLine.Trip.SourceId;
                            discountReasonId = -1;
                            markupStrategyId = tripLineForeignCurrency.MarkupStrategyId;
                            offeredReasonId = tripLineForeignCurrency.OfferedReasonId;

                            isCreditCardDiscountApplicable = false;
                            includeMarkupInCreditCardPayment = tripLineForeignCurrency.IncludeMarkupInCreditCardPayment;

                            isCreditorRequired = creditorId <= 0;
                            isSupplierRequired = supplierId <= 0;

                            if (tripLineForeignCurrency.DocumentNo != model.Key.PaymentAddDocumentNo) {
                                tripLineForeignCurrency.DocumentNo = model.Key.PaymentAddDocumentNo;
                                lazyContext.Save(tripLineForeignCurrency, false);
                            }

                            break;
                        case TripLineType.ServiceFee:
                            tripLineServiceFee = lazyContext.TripLineServiceFee.Single(t => t.TripLineId == model.Key.PaymentAddTripLineId);

                            if (paymentType == PaymentType.BspReturn && !tripLineServiceFee.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'BSP'.");
                            }
                            else if (paymentType == PaymentType.NonBspReturn && tripLineServiceFee.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'Non-BSP'.");
                            }

                            isBooking = tripLineServiceFee.TripLine.IsBooking;

                            payee = tripLineServiceFee.Creditor.Name;
                            departureDate = tripLineServiceFee.TripLine.Trip.DepartureDate;
                            offeredFare = tripLineServiceFee.TripLine.GetOfferedFareDue(lazyContext);

                            tripId = tripLineServiceFee.TripLine.TripId;
                            tripLineId = tripLineServiceFee.TripLineId;
                            airlineId = -1;
                            creditorId = tripLineServiceFee.CreditorId;
                            supplierId = tripLineServiceFee.SupplierId;
                            saleTypeId = tripLineServiceFee.SaleTypeId;
                            groupId = tripLineServiceFee.TripLine.Trip.GroupId;
                            categoryId = tripLineServiceFee.TripLine.Trip.CategoryId;
                            destinationId = tripLineServiceFee.TripLine.Trip.DestinationId;
                            agencyId = tripLineServiceFee.TripLine.Trip.AgencyId;
                            consultantId = tripLineServiceFee.TripLine.Trip.ConsultantId;
                            agentId = tripLineServiceFee.TripLine.Trip.AgentId;
                            sourceId = tripLineServiceFee.TripLine.Trip.SourceId;
                            discountReasonId = -1;
                            markupStrategyId = tripLineServiceFee.MarkupStrategyId;
                            offeredReasonId = tripLineServiceFee.OfferedReasonId;

                            isCreditCardDiscountApplicable = false;
                            includeMarkupInCreditCardPayment = tripLineServiceFee.IncludeMarkupInCreditCardPayment;

                            isCreditorRequired = tripLineServiceFee.ServiceFeePaymentType != ServiceFeePaymentType.Agency && creditorId <= 0;
                            isSupplierRequired = tripLineServiceFee.ServiceFeePaymentType != ServiceFeePaymentType.Agency && supplierId <= 0;

                            if (tripLineServiceFee.DocumentNo != model.Key.PaymentAddDocumentNo) {
                                tripLineServiceFee.DocumentNo = tripLineServiceFee.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? string.Empty : model.Key.PaymentAddDocumentNo;
                                lazyContext.Save(tripLineServiceFee, false);
                            }

                            if (tripLineServiceFee.ServiceFeePaymentType == ServiceFeePaymentType.Agency)
                                commissionGross = 0;

                            break;
                        case TripLineType.OtherInclusion:
                            tripLineOtherInclusion = lazyContext.TripLineOtherInclusion.Single(t => t.TripLineId == model.Key.PaymentAddTripLineId);

                            if (paymentType == PaymentType.BspReturn && !tripLineOtherInclusion.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'BSP'.");
                            }
                            else if (paymentType == PaymentType.NonBspReturn && tripLineOtherInclusion.Creditor.IsBspAgent) {
                                throw new UnreportedException("One or more creditors do not support payment type 'Non-BSP'.");
                            }

                            isBooking = tripLineOtherInclusion.TripLine.IsBooking;

                            payee = tripLineOtherInclusion.Creditor.Name;
                            departureDate = tripLineOtherInclusion.TripLine.Trip.DepartureDate;
                            offeredFare = tripLineOtherInclusion.TripLine.GetOfferedFareDue(lazyContext);

                            tripId = tripLineOtherInclusion.TripLine.TripId;
                            tripLineId = tripLineOtherInclusion.TripLineId;
                            airlineId = -1;
                            creditorId = tripLineOtherInclusion.CreditorId;
                            supplierId = tripLineOtherInclusion.SupplierId;
                            saleTypeId = tripLineOtherInclusion.SaleTypeId;
                            groupId = tripLineOtherInclusion.TripLine.Trip.GroupId;
                            categoryId = tripLineOtherInclusion.TripLine.Trip.CategoryId;
                            destinationId = tripLineOtherInclusion.TripLine.Trip.DestinationId;
                            agencyId = tripLineOtherInclusion.TripLine.Trip.AgencyId;
                            consultantId = tripLineOtherInclusion.TripLine.Trip.ConsultantId;
                            agentId = tripLineOtherInclusion.TripLine.Trip.AgentId;
                            sourceId = tripLineOtherInclusion.TripLine.Trip.SourceId;
                            discountReasonId = tripLineOtherInclusion.DiscountReasonId;
                            markupStrategyId = tripLineOtherInclusion.MarkupStrategyId;
                            offeredReasonId = tripLineOtherInclusion.OfferedReasonId;

                            isCreditCardDiscountApplicable = tripLineOtherInclusion.IsCreditCardDiscountApplicable;
                            includeMarkupInCreditCardPayment = tripLineOtherInclusion.IncludeMarkupInCreditCardPayment;

                            isCreditorRequired = creditorId <= 0;
                            isSupplierRequired = supplierId <= 0;

                            if (tripLineOtherInclusion.DocumentNo != model.Key.PaymentAddDocumentNo) {
                                tripLineOtherInclusion.DocumentNo = model.Key.PaymentAddDocumentNo;
                                lazyContext.Save(tripLineOtherInclusion, false);
                            }

                            break;
                    }

                    if (!isBooking) {
                        message = "Only booked records can be processed for payment.";
                    }
                    else if (isCreditorRequired) {
                        message = string.Format("Creditor is required for Document No {0}.", model.Key.PaymentAddDocumentNo);
                    }
                    else if (isSupplierRequired) {
                        message = string.Format("Supplier is required for Document No {0}.", model.Key.PaymentAddDocumentNo);
                    }
                    else if (paymentType == PaymentType.Admin && tripLineServiceFee == null) {
                        message = "Payment type 'Adjustment' is not applicable for one or more documents.";
                    }

                    if (message != null)
                        throw new UnreportedException(message);

                    Create(
                        lazyContext: lazyContext,
                        models: models,
                        model: model,
                        paymentType: paymentType,
                        documentNo: documentNo,
                        documentDate: documentDate.Date,
                        departureDate: departureDate,
                        tripId: tripId,
                        tripLineId: tripLineId,
                        creditorId: creditorId,
                        supplierId: supplierId,
                        airlineId: airlineId,
                        saleTypeId: saleTypeId,
                        groupId: groupId,
                        categoryId: categoryId,
                        destinationId: destinationId,
                        agencyId: agencyId,
                        consultantId: consultantId,
                        agentId: agentId,
                        sourceId: sourceId,
                        bankAccountId: bankAccountId,
                        discountReasonId: discountReasonId,
                        markupStrategyId: markupStrategyId,
                        offeredReasonId: offeredReasonId,
                        isCreditCardDiscountApplicable: isCreditCardDiscountApplicable,
                        includeMarkupInCreditCardPayment: includeMarkupInCreditCardPayment,
                        commissionGross: commissionGross,
                        discountGross: discountGross,
                        markupGross: markupGross,
                        offeredFare: offeredFare,
                        payee: payee,
                        comments: comments,
                        tripLineAirPassenger: tripLineAirPassenger,
                        tripLineServiceFee: tripLineServiceFee,
                        bspModel: ref bspModel,
                        nonBspModel: ref nonBspModel,
                        paymentModel: ref paymentModel,
                        adjustmentModel: ref adjustmentModel,
                        paymentIds: ref paymentIds,
                        bspCount: ref bspCount,
                        nonBspCount: ref nonBspCount,
                        paymentCount: ref paymentCount,
                        adminCount: ref adminCount
                    );
                }

                ts.Complete();
                return bspCount + nonBspCount + paymentCount + adminCount;
            }
        }

        public bool Create(AppLazyContext lazyContext, List<PaymentAddViewModel> models, IGrouping<object, PaymentAddViewModel> model, PaymentType paymentType, string documentNo, DateTime documentDate,
            DateTime departureDate, int tripId, int tripLineId, int creditorId, int supplierId, int airlineId, int saleTypeId, int groupId, int categoryId, int destinationId, int agencyId, int consultantId,
            int agentId, int sourceId, int bankAccountId, int discountReasonId, int markupStrategyId, int offeredReasonId, bool isCreditCardDiscountApplicable, bool includeMarkupInCreditCardPayment,
            decimal commissionGross, decimal discountGross, decimal markupGross, decimal offeredFare, string payee, string comments, TripLineAirPassenger tripLineAirPassenger, TripLineServiceFee tripLineServiceFee,
            ref BspViewModel bspModel, ref NonBspViewModel nonBspModel, ref PaymentViewModel paymentModel, ref AdjustmentViewModel adjustmentModel, ref Dictionary<int, string> paymentIds, ref int bspCount,
            ref int nonBspCount, ref int paymentCount, ref int adminCount) {

            decimal amount = 0;
            decimal nonCommmissionable = 0;

            if (paymentType == PaymentType.BspReturn) {
                int sign = tripLineAirPassenger?.BspEntryType == BspEntryType.Refund ? -1 : 1;
                var bspType = tripLineAirPassenger?.BspEntryType == BspEntryType.Refund ? BspType.Refund : BspType.Bsp;

                var newRecord = bspModel.BspType != bspType
                    || bspModel.BspDocumentNo != documentNo
                    || bspModel.BspDepartureDate != departureDate
                    || bspModel.BspTripLineId != tripLineId
                    || bspModel.BspCreditorId != creditorId
                    || bspModel.BspAirlineId != airlineId
                    || bspModel.BspSupplierId != supplierId
                    || bspModel.BspSaleTypeId != saleTypeId
                    || bspModel.BspCategoryId != categoryId
                    || bspModel.BspDestinationId != destinationId
                    || bspModel.BspAgencyId != agencyId
                    || bspModel.BspConsultantId != consultantId
                    || bspModel.BspAgentId != agentId
                    || bspModel.BspSourceId != sourceId
                    || bspModel.BspDiscountReasonId != discountReasonId
                    || bspModel.BspMarkupStrategyId != markupStrategyId;

                if (newRecord) {
                    bspModel = new BspViewModel {
                        BspId = 0,
                        BspDocumentStatus = DocumentStatus.Open,
                        BspType = bspType,
                        BspDocumentNo = documentNo,
                        BspDocumentDate = documentDate,
                        BspCreditorId = creditorId,
                        BspSupplierId = supplierId,
                        BspTripId = tripId,
                        BspTripLineId = tripLineId,
                        BspAirlineId = airlineId,
                        BspDepartureDate = departureDate,
                        BspOfferedFare = paymentModel.PaymentIsDeposit ? 0 : offeredFare,
                        BspOfferedReasonId = paymentModel.PaymentIsDeposit ? -1 : offeredReasonId,
                        BspSaleTypeId = saleTypeId,
                        BspCategoryId = categoryId,
                        BspDestinationId = destinationId,
                        BspAgencyId = agencyId,
                        BspConsultantId = consultantId,
                        BspAgentId = agentId,
                        BspSourceId = sourceId,
                        BspSupplierCancellationFee = 0,
                        BspCommission = paymentModel.PaymentIsDeposit ? 0 : sign * commissionGross,
                        BspCommissionTax = 0,
                        BspDiscount = paymentModel.PaymentIsDeposit ? 0 : sign * discountGross,
                        BspDiscountTax = 0,
                        BspDiscountReasonId = paymentModel.PaymentIsDeposit ? -1 : discountReasonId,
                        BspMarkup = paymentModel.PaymentIsDeposit ? 0 : sign * markupGross,
                        BspMarkupTax = 0,
                        BspMarkupStrategyId = paymentModel.PaymentIsDeposit ? -1 : markupStrategyId,
                        BspIsCreditCardDiscountApplicable = isCreditCardDiscountApplicable,
                        BspIncludeMarkupInCreditCardPayment = includeMarkupInCreditCardPayment,
                        BspIsAutoInvoiced = false,
                        BspIsTaxIncluded = true,
                        BspComments = string.Empty
                    };

                    new BspCommon(HttpContext).CreateOrUpdate(bspModel, false, false, true, false, TransactionUpdateType.None);
                    bspCount++;
                }

                foreach (var detailModel in models.Where(t1 => model.Any(t2 => t2.PaymentAddId == t1.PaymentAddId && t2.PaymentAddFormOfPaymentId == t1.PaymentAddFormOfPaymentId && (tripLineAirPassenger == null || t1.PaymentAddTripLineAirPassengerId == tripLineAirPassenger.Id)))
                    .Select(row => new {
                        row.PaymentAddTripLineType,
                        row.PaymentAddTripLineAirPassengerId,
                        row.PaymentAddPassengerId,
                        row.PaymentAddFormOfPaymentId,
                        row.PaymentAddAmount,
                        row.PaymentAddNonCommissionable
                    }).GroupBy(t => new { t.PaymentAddTripLineType, t.PaymentAddTripLineAirPassengerId, t.PaymentAddPassengerId, t.PaymentAddFormOfPaymentId }).Distinct()) {
                    amount = detailModel.Sum(t => t.PaymentAddAmount);
                    nonCommmissionable = paymentModel.PaymentIsDeposit ? 0 : detailModel.Sum(t => t.PaymentAddNonCommissionable);

                    var bspDetailModel = new BspDetailViewModel {
                        BspDetailId = 0,
                        BspId = bspModel.BspId,
                        BspDetailDocumentStatus = DocumentStatus.Open,
                        BspDetailTripLineAirPassengerId = detailModel.Key.PaymentAddTripLineAirPassengerId,
                        BspDetailPassengerId = detailModel.Key.PaymentAddPassengerId,
                        BspDetailFormOfPaymentId = detailModel.Key.PaymentAddFormOfPaymentId,
                        BspDetailAmount = amount,
                        BspDetailNonCommissionable = nonCommmissionable
                    };

                    new BspDetailCommon(HttpContext).CreateOrUpdate(bspDetailModel, false, true, false, false);
                }
            }
            else if (paymentType == PaymentType.NonBspReturn) {
                int sign = tripLineAirPassenger?.BspEntryType == BspEntryType.Refund ? -1 : 1;
                var nonBspType = tripLineAirPassenger?.BspEntryType == BspEntryType.Refund ? NonBspType.Refund : NonBspType.NonBsp;

                var newRecord = nonBspModel.NonBspType != nonBspType
                    || nonBspModel.NonBspDocumentNo != documentNo
                    || nonBspModel.NonBspDepartureDate != departureDate
                    || nonBspModel.NonBspTripLineId != tripLineId
                    || nonBspModel.NonBspAirlineId != airlineId
                    || nonBspModel.NonBspCreditorId != creditorId
                    || nonBspModel.NonBspSupplierId != supplierId
                    || nonBspModel.NonBspSaleTypeId != saleTypeId
                    || nonBspModel.NonBspCategoryId != categoryId
                    || nonBspModel.NonBspDestinationId != destinationId
                    || nonBspModel.NonBspAgencyId != agencyId
                    || nonBspModel.NonBspConsultantId != consultantId
                    || nonBspModel.NonBspAgentId != agentId
                    || nonBspModel.NonBspSourceId != sourceId
                    || nonBspModel.NonBspDiscountReasonId != discountReasonId
                    || nonBspModel.NonBspMarkupStrategyId != markupStrategyId;

                if (newRecord) {
                    nonBspModel = new NonBspViewModel {
                        NonBspId = 0,
                        NonBspDocumentStatus = DocumentStatus.Open,
                        NonBspType = nonBspType,
                        NonBspDocumentNo = documentNo,
                        NonBspDocumentDate = documentDate,
                        NonBspCreditorId = creditorId,
                        NonBspSupplierId = supplierId,
                        NonBspTripId = tripId,
                        NonBspTripLineId = tripLineId,
                        NonBspChartOfAccountId = -1,
                        NonBspAirlineId = airlineId,
                        NonBspDepartureDate = departureDate,
                        NonBspOfferedFare = paymentModel.PaymentIsDeposit ? 0 : offeredFare,
                        NonBspOfferedReasonId = paymentModel.PaymentIsDeposit ? -1 : offeredReasonId,
                        NonBspSaleTypeId = saleTypeId,
                        NonBspCategoryId = categoryId,
                        NonBspDestinationId = destinationId,
                        NonBspAgencyId = agencyId,
                        NonBspConsultantId = consultantId,
                        NonBspAgentId = agentId,
                        NonBspSourceId = sourceId,
                        NonBspSupplierCancellationFee = 0,
                        NonBspCommission = paymentModel.PaymentIsDeposit ? 0 : sign * commissionGross,
                        NonBspCommissionTax = 0,
                        NonBspDiscount = paymentModel.PaymentIsDeposit ? 0 : sign * discountGross,
                        NonBspDiscountTax = 0,
                        NonBspDiscountReasonId = paymentModel.PaymentIsDeposit ? -1 : discountReasonId,
                        NonBspMarkup = paymentModel.PaymentIsDeposit ? 0 : sign * markupGross,
                        NonBspMarkupTax = 0,
                        NonBspMarkupStrategyId = paymentModel.PaymentIsDeposit ? -1 : markupStrategyId,
                        NonBspIsCreditCardDiscountApplicable = isCreditCardDiscountApplicable,
                        NonBspIncludeMarkupInCreditCardPayment = includeMarkupInCreditCardPayment,
                        NonBspIsAutoInvoiced = false,
                        NonBspIsTaxIncluded = true,
                        NonBspComments = string.Empty
                    };

                    new NonBspCommon(HttpContext).CreateOrUpdate(nonBspModel, false, false, true, false, TransactionUpdateType.None);
                    nonBspCount++;
                }

                foreach (var detailModel in models.Where(t1 => model.Any(t2 => t2.PaymentAddId == t1.PaymentAddId)).Select(t => new { t.PaymentAddTripLineType, t.PaymentAddTripLineAirPassengerId, t.PaymentAddPassengerId, t.PaymentAddFormOfPaymentId, t.PaymentAddAmount, t.PaymentAddNonCommissionable }).GroupBy(t => new { t.PaymentAddTripLineType, t.PaymentAddTripLineAirPassengerId, t.PaymentAddPassengerId, t.PaymentAddFormOfPaymentId }).Distinct()) {
                    amount = detailModel.Sum(t => t.PaymentAddAmount);
                    nonCommmissionable = paymentModel.PaymentIsDeposit ? 0 : detailModel.Sum(t => t.PaymentAddNonCommissionable);

                    var nonBspDetailModel = new NonBspDetailViewModel {
                        NonBspDetailId = 0,
                        NonBspId = nonBspModel.NonBspId,
                        NonBspDetailDocumentStatus = DocumentStatus.Open,
                        NonBspDetailTripLineAirPassengerId = detailModel.Key.PaymentAddTripLineAirPassengerId,
                        NonBspDetailPassengerId = detailModel.Key.PaymentAddPassengerId,
                        NonBspDetailFormOfPaymentId = detailModel.Key.PaymentAddFormOfPaymentId,
                        NonBspDetailAmount = amount,
                        NonBspDetailNonCommissionable = nonCommmissionable
                    };

                    new NonBspDetailCommon(HttpContext).CreateOrUpdate(nonBspDetailModel, true, false, false);
                }
            }
            else if (paymentType == PaymentType.SupplierPayment) {
                var newRecord = paymentModel.PaymentType != paymentType
                    || paymentModel.PaymentPayee != payee
                    || paymentModel.PaymentDocumentNo != documentNo
                    || paymentModel.PaymentAirlineId != airlineId
                    || paymentModel.PaymentCreditorId != creditorId
                    || paymentModel.PaymentSupplierId != supplierId
                    || paymentModel.PaymentSaleTypeId != saleTypeId
                    || paymentModel.PaymentCategoryId != categoryId
                    || paymentModel.PaymentAgencyId != agencyId
                    || paymentModel.PaymentConsultantId != consultantId
                    || paymentModel.PaymentSourceId != sourceId
                    || paymentModel.PaymentDiscountReasonId != discountReasonId
                    || paymentModel.PaymentMarkupStrategyId != markupStrategyId;

                if (newRecord) {
                    paymentModel = new PaymentViewModel {
                        PaymentId = 0,
                        PaymentDocumentStatus = DocumentStatus.DepositedPaid,
                        PaymentType = paymentType,
                        PaymentDocumentNo = documentNo,
                        PaymentDocumentDate = documentDate,
                        PaymentCreditorId = creditorId,
                        PaymentSupplierId = supplierId,
                        PaymentTripId = tripId,
                        PaymentChartOfAccountId = -1,
                        PaymentAirlineId = airlineId,
                        PaymentBankAccountId = bankAccountId,
                        PaymentPayee = payee,
                        PaymentSaleTypeId = saleTypeId,
                        PaymentCategoryId = categoryId,
                        PaymentAgencyId = agencyId,
                        PaymentConsultantId = consultantId,
                        PaymentSourceId = sourceId,
                        PaymentCommission = paymentModel.PaymentIsDeposit ? 0 : commissionGross,
                        PaymentCommissionTax = 0,
                        PaymentDiscount = paymentModel.PaymentIsDeposit ? 0 : discountGross,
                        PaymentDiscountTax = 0,
                        PaymentDiscountReasonId = paymentModel.PaymentIsDeposit ? -1 : discountReasonId,
                        PaymentMarkup = paymentModel.PaymentIsDeposit ? 0 : markupGross,
                        PaymentMarkupTax = 0,
                        PaymentMarkupStrategyId = paymentModel.PaymentIsDeposit ? -1 : markupStrategyId,
                        PaymentIsCreditCardDiscountApplicable = isCreditCardDiscountApplicable,
                        PaymentIncludeMarkupInCreditCardPayment = includeMarkupInCreditCardPayment,
                        PaymentIsAutoInvoiced = false,
                        PaymentIsSplit = false,
                        PaymentIsTaxIncluded = true,
                        PaymentIsDeposit = paymentModel.PaymentIsDeposit,
                        PaymentComments = comments
                    };

                    CreateOrUpdate(paymentModel, false, false, TransactionUpdateType.None);
                    paymentCount++;

                    paymentIds.Add(paymentModel.PaymentId, paymentModel.PaymentDocumentNo);
                }

                PaymentDetailViewModel paymentDetailModel = null;

                foreach (var detailModel in models.Where(t1 => model.Any(t2 => t2.PaymentAddId == t1.PaymentAddId)).Select(t => new { t.PaymentAddTripLineType, t.PaymentAddTripLineAirPassengerId, t.PaymentAddPassengerId, t.PaymentAddFormOfPaymentId, t.PaymentAddAmount, t.PaymentAddNonCommissionable }).GroupBy(t => new { t.PaymentAddTripLineType, t.PaymentAddTripLineAirPassengerId, t.PaymentAddPassengerId, t.PaymentAddFormOfPaymentId }).Distinct()) {
                    amount = detailModel.Sum(t => t.PaymentAddAmount);
                    nonCommmissionable = paymentModel.PaymentIsDeposit ? 0 : detailModel.Sum(t => t.PaymentAddNonCommissionable);

                    paymentDetailModel = new PaymentDetailViewModel {
                        PaymentDetailId = 0,
                        PaymentId = paymentModel.PaymentId,
                        PaymentDetailDocumentStatus = DocumentStatus.DepositedPaid,
                        PaymentDetailTripLineId = tripLineId,
                        PaymentDetailTripLineAirPassengerId = detailModel.Key.PaymentAddTripLineAirPassengerId,
                        PaymentDetailPassengerId = detailModel.Key.PaymentAddPassengerId,
                        PaymentDetailFormOfPaymentId = detailModel.Key.PaymentAddFormOfPaymentId,
                        PaymentDetailOfferedFare = paymentModel.PaymentIsDeposit ? 0 : offeredFare,
                        PaymentDetailOfferedReasonId = paymentModel.PaymentIsDeposit ? -1 : offeredReasonId,
                        PaymentDetailAmount = amount,
                        PaymentDetailNonCommissionable = nonCommmissionable
                    };

                    new PaymentDetailCommon(HttpContext).CreateOrUpdate(paymentDetailModel, true, false, false);
                }

                if (paymentDetailModel != null)
                    new PaymentDetailCommon(HttpContext).CreateOrUpdate(paymentDetailModel, true, false, false, TransactionUpdateType.Bulk);
            }
            else if (paymentType == PaymentType.Admin && tripLineServiceFee != null) {
                DebitCreditType debitType;
                int debitTripId = -1;
                int debitTripLineId = -1;
                int debitDebtorId = -1;
                int debitCreditorId = -1;
                int debitChartOfAccountId = -1;

                DebitCreditType creditType;
                int creditTripId = -1;
                int creditTripLineId = -1;
                int creditDebtorId = -1;
                int creditCreditorId = -1;
                int creditChartOfAccountId = -1;

                if (tripLineServiceFee.ServiceFeeType.AdjustmentType.DebitType == DebitCreditType.Client) {
                    debitType = DebitCreditType.Client;
                    debitTripId = tripId;
                    debitTripLineId = tripLineId;

                    creditType = tripLineServiceFee.ServiceFeeType.AdjustmentType.CreditType;
                    creditDebtorId = tripLineServiceFee.ServiceFeeType.AdjustmentType.CreditDebtorId;
                    creditCreditorId = tripLineServiceFee.ServiceFeeType.AdjustmentType.CreditCreditorId;
                    creditChartOfAccountId = tripLineServiceFee.ServiceFeeType.AdjustmentType.CreditChartOfAccountId;
                }
                else {
                    creditType = DebitCreditType.Client;
                    creditTripId = tripId;
                    creditTripLineId = tripLineId;

                    debitType = tripLineServiceFee.ServiceFeeType.AdjustmentType.DebitType;
                    debitDebtorId = tripLineServiceFee.ServiceFeeType.AdjustmentType.DebitDebtorId;
                    debitCreditorId = tripLineServiceFee.ServiceFeeType.AdjustmentType.DebitCreditorId;
                    debitChartOfAccountId = tripLineServiceFee.ServiceFeeType.AdjustmentType.DebitChartOfAccountId;
                }

                adjustmentModel = new AdjustmentViewModel {
                    AdjustmentId = 0,
                    AdjustmentTypeId = tripLineServiceFee.ServiceFeeType.AdjustmentTypeId,
                    AdjustmentDocumentNo = documentNo,
                    AdjustmentDocumentDate = documentDate,
                    AdjustmentDocumentStatus = DocumentStatus.Open,
                    AdjustmentSupplierId = supplierId,
                    AdjustmentDebitType = debitType,
                    AdjustmentDebitTripId = debitTripId,
                    AdjustmentDebitTripLineId = debitTripLineId,
                    AdjustmentDebitDebtorId = debitDebtorId,
                    AdjustmentDebitCreditorId = debitCreditorId,
                    AdjustmentDebitChartOfAccountId = debitChartOfAccountId,
                    AdjustmentCreditType = creditType,
                    AdjustmentCreditTripId = creditTripId,
                    AdjustmentCreditTripLineId = creditTripLineId,
                    AdjustmentCreditDebtorId = creditDebtorId,
                    AdjustmentCreditCreditorId = creditCreditorId,
                    AdjustmentCreditChartOfAccountId = creditChartOfAccountId,
                    AdjustmentSaleTypeId = saleTypeId,
                    AdjustmentGroupId = groupId,
                    AdjustmentCategoryId = categoryId,
                    AdjustmentDestinationId = destinationId,
                    AdjustmentConsultantId = consultantId,
                    AdjustmentAgentId = agentId,
                    AdjustmentSourceId = sourceId,
                    AdjustmentAmount = tripLineServiceFee.CostToClient,
                    AdjustmentComments = comments
                };

                new AdjustmentCommon(HttpContext).CreateOrUpdate(lazyContext, adjustmentModel, false);
                adminCount++;
            }

            return true;
        }

        public bool CreateOrUpdate(PaymentViewModel model, bool validateDocumentStatus = true, bool performRelatedUpdates = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            if (string.IsNullOrEmpty(model.PaymentDocumentNo))
                throw new UnreportedException("Document No is required.");

            if (model.PaymentType == PaymentType.SupplierPayment) {
                if ((model.PaymentSaleTypeId ?? 0) <= -1)
                    throw new UnreportedException("Type of Sale is required.");

                if ((model.PaymentConsultantId ?? 0) <= 0)
                    throw new UnreportedException("Consultant is required.");
            }

            if (model.PaymentDiscount != 0 && (model.PaymentDiscountReasonId ?? 0) <= 0)
                throw new UnreportedException("Discount Reason is required when Discount is applied.");

            if (model.PaymentMarkup != 0 && (model.PaymentMarkupStrategyId ?? 0) <= 0)
                throw new UnreportedException("Mark-Up Strategy is required when Mark-Up is applied.");

            model.PaymentDocumentNo = Utils.RemoveExtraSpaces(model.PaymentDocumentNo).Replace(" ", string.Empty).ToUpper();

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    model.PaymentDocumentNo = Payment.GetUniqueDocumentNo(lazyContext, model.PaymentId, model.PaymentBankAccountId ?? 0, model.PaymentIsSplit, model.PaymentDocumentNo);
                    Payment q = null;

                    if (model.PaymentId <= 0) {
                        q = new Payment {
                            Id = 0,
                            DocumentNo = model.PaymentDocumentNo,
                            DocumentDate = model.PaymentDocumentDate ?? DateTime.MinValue,
                            ReturnDate = DateTime.MinValue,
                            AgencyId = HttpContext.CurrentDefaultAgencyId(),
                            MarkupGrossOther = 0,
                            IsSplit = model.PaymentIsSplit
                        };
                    }
                    else {
                        q = lazyContext.Payment.Find(model.PaymentId);

                        if (!q.ValidateTaxApplicability(q.IsTaxApplicable))
                            throw new UnreportedException(AppConstants.TaxRelatedRecordCannotBeAltered);

                        if (q.PaymentType != model.PaymentType)
                            throw new UnreportedException("Payment Type cannot be changed.");

                        if (q.PaymentType == PaymentType.Admin && q.AccountType != model.PaymentAccountType && q.PaymentDetails.Count > 0)
                            throw new UnreportedException("Account Type cannot be changed.");

                        if (model.PaymentId > 0 && q.PaymentType == PaymentType.SupplierPayment && (model.PaymentCreditorId != q.CreditorId || model.PaymentSupplierId != q.SupplierId || model.PaymentSaleTypeId != q.SaleTypeId))
                            throw new UnreportedException("Creditor, Supplier and Type of Sale cannot be changed for an existing payment.");

                        q.DocumentNo = model.PaymentDocumentNo;
                    }

                    if (model.PaymentType == PaymentType.BspReturn || model.PaymentType == PaymentType.NonBspReturn)
                        model.PaymentPayee = string.Empty;

                    if (model.PaymentType != PaymentType.SupplierPayment || model.PaymentIsDeposit) {
                        if (model.PaymentType != PaymentType.SupplierPayment)
                            model.PaymentIsDeposit = false;

                        if (!model.PaymentIsDeposit) {
                            model.PaymentSaleTypeId = -1;
                            model.PaymentCategoryId = -1;
                            model.PaymentSourceId = -1;
                            model.PaymentAirlineId = -1;
                        }

                        model.PaymentCommission = 0;
                        model.PaymentCommissionTax = 0;
                        model.PaymentDiscount = 0;
                        model.PaymentDiscountTax = 0;
                        model.PaymentDiscountReasonId = -1;
                        model.PaymentMarkup = 0;
                        model.PaymentMarkupTax = 0;
                        model.PaymentMarkupStrategyId = -1;

                        model.PaymentIsCreditCardDiscountApplicable = false;
                        model.PaymentIncludeMarkupInCreditCardPayment = false;
                        model.PaymentIsAutoInvoiced = false;
                    }

                    int tripId = -1;
                    int debtorId = -1;
                    int creditorId = -1;
                    int chartOfAccountId = -1;
                    int supplierId = -1;
                    int consultantId = -1;

                    switch (model.PaymentType) {
                        case PaymentType.SupplierPayment:
                            tripId = model.PaymentTripId ?? 0;
                            creditorId = model.PaymentCreditorId ?? 0;
                            supplierId = model.PaymentSupplierId ?? 0;
                            consultantId = model.PaymentConsultantId ?? 0;
                            break;
                        case PaymentType.ClientRefund:
                            tripId = model.PaymentTripId ?? 0;
                            creditorId = model.PaymentCreditorId ?? -1;
                            supplierId = model.PaymentSupplierId ?? -1;
                            break;
                        case PaymentType.BspReturn:
                            tripId = model.PaymentTripId ?? 0;
                            creditorId = model.PaymentCreditorId ?? 0;
                            supplierId = model.PaymentSupplierId ?? 0;
                            break;
                        case PaymentType.NonBspReturn:
                            tripId = model.PaymentTripId ?? 0;
                            creditorId = model.PaymentCreditorId ?? 0;
                            supplierId = model.PaymentSupplierId ?? 0;
                            break;
                        case PaymentType.Admin:
                            switch (model.PaymentAccountType) {
                                case AccountType.Client:
                                    tripId = model.PaymentTripId ?? 0;
                                    break;
                                case AccountType.Debtor:
                                    debtorId = model.PaymentDebtorId ?? 0;
                                    break;
                                case AccountType.Creditor:
                                    creditorId = model.PaymentCreditorId ?? 0;
                                    break;
                                case AccountType.GeneralLedger:
                                    chartOfAccountId = model.PaymentChartOfAccountId ?? 0;
                                    break;
                            }

                            break;
                    }

                    decimal commission = model.PaymentCommission;
                    decimal commissionTax = 0;
                    decimal discount = model.PaymentDiscount;
                    decimal discountTax = 0;
                    decimal markup = model.PaymentMarkup;
                    decimal markupTax = 0;

                    q.ChartOfAccountId = chartOfAccountId;
                    q.SaleTypeId = model.PaymentSaleTypeId ?? 0;

                    if (model.PaymentId <= 0) {
                        q.ChartOfAccount = lazyContext.ChartOfAccount.Find(q.ChartOfAccountId);
                        q.SaleType = lazyContext.SaleType.Find(q.SaleTypeId);
                    }

                    if (q.IsTaxApplicable) {
                        decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), (DateTime)model.PaymentDocumentDate);

                        if (model.PaymentIsTaxIncluded) {
                            commissionTax = Math.Round(commission * taxRate / (1 + taxRate), 2);
                            discountTax = Math.Round(discount * taxRate / (1 + taxRate), 2);
                            markupTax = Math.Round(markup * taxRate / (1 + taxRate), 2);
                            commission -= commissionTax;
                            discount -= discountTax;
                            markup -= markupTax;
                        }
                        else {
                            commissionTax = Math.Round(commission * taxRate, 2);
                            discountTax = Math.Round(discount * taxRate, 2);
                            markupTax = Math.Round(markup * taxRate, 2);
                        }
                    }

                    int oldTripId = q.Id > 0 && q.TripId != tripId ? q.TripId : 0;

                    if (!q.IsClientAccountLocked) {
                        q.TripId = tripId;
                        q.DebtorId = debtorId;
                        q.CreditorId = creditorId;
                    }

                    if (consultantId == -1) {
                        if (q.TripId > 0) {
                            q.Trip = lazyContext.Trip.Find(q.TripId);
                            consultantId = q.Trip.ConsultantId;
                        }
                        else {
                            consultantId = HttpContext.CurrentConsultantId();
                        }
                    }

                    q.PaymentType = model.PaymentType;
                    q.DocumentNo = Payment.GetUniqueDocumentNo(lazyContext, q.Id, model.PaymentBankAccountId ?? 0, model.PaymentIsSplit, model.PaymentDocumentNo);
                    q.DocumentDate = model.PaymentDocumentDate ?? DateTime.MinValue;
                    q.SupplierId = supplierId;
                    q.BankAccountId = model.PaymentBankAccountId ?? 0;
                    q.Payee = model.PaymentPayee.ToStringExt();
                    q.CategoryId = model.PaymentCategoryId ?? 0;
                    q.SourceId = model.PaymentSourceId ?? 0;
                    q.AirlineId = model.PaymentAirlineId ?? 0;
                    q.ConsultantId = consultantId;
                    q.Commission = commission;
                    q.CommissionTax = commissionTax;
                    q.Discount = discount;
                    q.DiscountTax = discountTax;
                    q.DiscountReasonId = model.PaymentDiscountReasonId ?? 0;
                    q.Markup = markup;
                    q.MarkupTax = markupTax;
                    q.MarkupGrossOther = q.GetMarkupGross();
                    q.MarkupStrategyId = model.PaymentMarkupStrategyId ?? 0;
                    q.IsCreditCardDiscountApplicable = model.PaymentIsCreditCardDiscountApplicable;
                    q.IncludeMarkupInCreditCardPayment = model.PaymentIncludeMarkupInCreditCardPayment;
                    q.IsDeposit = model.PaymentIsDeposit;
                    q.IsAutoInvoiced = model.PaymentIsAutoInvoiced;
                    q.Comments = model.PaymentComments.ToStringExt();

                    if (model.PaymentId <= 0) {
                        q.BankAccount = lazyContext.BankAccount.Find(q.BankAccountId);
                        q.Trip = lazyContext.Trip.Find(q.TripId);
                        q.Debtor = lazyContext.Debtor.Find(q.DebtorId);
                        q.Creditor = lazyContext.Creditor.Find(q.CreditorId);
                        q.Supplier = lazyContext.Supplier.Find(q.SupplierId);
                    }

                    q.AmountPayable = q.GetAmountPayable(lazyContext);
                    q.AmountPayableTax = q.GetAmountPayableTax();

                    if (q.ChartOfAccountId > 0 && !ChartOfAccount.IsInRole(lazyContext, q.ChartOfAccountId, HttpContext.RoleId()))
                        throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                    if (q.ChartOfAccountId > 0 && !HttpContext.IsAdministrator() && Setting.IsControlAccount(HttpContext.CurrentCustomerId(), q.DocumentDate, q.ChartOfAccountId))
                        throw new UnreportedException(AppConstants.GlControlAccountWarning);

                    bool result = ValidateAndSave(lazyContext, q, validateDocumentStatus, performRelatedUpdates, txnUpdateType, oldTripId);

                    model.PaymentId = q.Id;
                    model.PaymentDocumentTotal = q.GetDocumentTotal(lazyContext);

                    ts.Complete();
                    return result;
                }
            }
        }

        public bool Delete(AppLazyContext lazyContext, PaymentViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.Payment.Include(t => t.PaymentDetails).ThenInclude(t => t.TransactionDetails).Include(t => t.Transactions).SingleOrDefault(t => t.Id == model.PaymentId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }

        public bool ProcessSelections(AppLazyContext lazyContext, int[] paymentIds, bool undo) {
            if (undo) {
                foreach (int paymentId in paymentIds) {
                    Undo(lazyContext, paymentId, false, false);
                }
            }

            return true;
        }

        public bool Undo(AppLazyContext lazyContext, int id, bool isDetailView, bool isBankReconciliation) {
            using (var ts = Utils.CreateTransactionScope()) {
                Payment payment = null;
                PaymentDetail paymentDetail = null;
                PaymentType paymentType;
                DocumentStatus documentStatus;
                int paymentId = 0;

                if (isDetailView) {
                    paymentDetail = lazyContext.PaymentDetail.Find(id);
                    paymentType = paymentDetail.Payment.PaymentType;
                    documentStatus = paymentDetail.DocumentStatus;
                    paymentId = paymentDetail.PaymentId;

                    if (!paymentDetail.CanUndo(isBankReconciliation))
                        throw new UnreportedException(AppConstants.RecordCannotBeUndone);
                }
                else {
                    payment = lazyContext.Payment.Find(id);
                    paymentType = payment.PaymentType;
                    documentStatus = payment.DocumentStatus;
                    paymentId = payment.Id;

                    if (!payment.CanUndo(isBankReconciliation))
                        throw new UnreportedException(AppConstants.RecordCannotBeUndone);
                }

                if (paymentType == PaymentType.BspReturn) {
                    if (documentStatus == DocumentStatus.DepositedPaid || documentStatus == DocumentStatus.Closed) {
                        foreach (var bsp in lazyContext.Bsp.Where(t => t.PaymentId == paymentId).ToList()) {
                            if (documentStatus == DocumentStatus.DepositedPaid) {
                                bsp.PaymentId = -1;
                                lazyContext.Save(bsp, false);
                            }

                            bsp.UpdateDocumentStatus(lazyContext, documentStatus == DocumentStatus.DepositedPaid ? DocumentStatus.Open : DocumentStatus.DepositedPaid);
                        }
                    }
                }
                else if (paymentType == PaymentType.NonBspReturn) {
                    if (documentStatus == DocumentStatus.DepositedPaid || documentStatus == DocumentStatus.Closed) {
                        foreach (var nonBsp in lazyContext.NonBsp.Where(t => t.PaymentId == paymentId).ToList()) {
                            if (documentStatus == DocumentStatus.DepositedPaid) {
                                nonBsp.PaymentId = -1;
                                lazyContext.Save(nonBsp, false);
                            }

                            nonBsp.UpdateDocumentStatus(lazyContext, documentStatus == DocumentStatus.DepositedPaid ? DocumentStatus.Open : DocumentStatus.DepositedPaid);
                        }
                    }
                }

                if (isDetailView) {
                    paymentDetail.UpdateDocumentStatus(lazyContext, documentStatus == DocumentStatus.DepositedPaid ? DocumentStatus.Open : DocumentStatus.DepositedPaid, -1);
                }
                else {
                    payment.UpdateDocumentStatus(lazyContext, documentStatus == DocumentStatus.DepositedPaid ? DocumentStatus.Open : DocumentStatus.DepositedPaid, -1);
                }

                if ((paymentType == PaymentType.BspReturn || paymentType == PaymentType.NonBspReturn) && documentStatus == DocumentStatus.DepositedPaid) {
                    payment = lazyContext.Payment.Find(paymentId);

                    if (payment != null)
                        ValidateAndDelete(lazyContext, payment, false);
                }

                ts.Complete();
                return true;
            }
        }

        public bool Reverse(AppLazyContext lazyContext, int paymentId, string type) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.Payment.Find(paymentId);

                if (!q.CanReverse())
                    throw new UnreportedException(AppConstants.RecordCannotBeReversed);

                if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), q.DocumentDate, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                if (type == "CurrentDate" && !Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                var payments = lazyContext.Payment.AsQueryable();

                switch (q.PaymentType) {
                    default:
                        throw new InvalidOperationException("Payment Type is invalid.");
                    case PaymentType.SupplierPayment:
                        payments = payments.Where(t => t.Id == paymentId || (t.DocumentNo == q.DocumentNo && t.PaymentType == q.PaymentType && (t.IsSplit || (t.SupplierId > 0 && t.SupplierId == q.SupplierId))));
                        break;
                    case PaymentType.Admin:
                        payments = payments.Where(t => t.Id == paymentId || (t.DocumentNo == q.DocumentNo && t.PaymentType == q.PaymentType && (t.IsSplit || (t.ChartOfAccountId > 0 && t.ChartOfAccountId == q.ChartOfAccountId))));
                        break;
                }

                foreach (var payment in payments.ToList()) {
                    var paymentClone = payment.Clone() as Payment;

                    paymentClone.Id = 0;
                    paymentClone.DocumentNo = GetReversedDocumentNo(lazyContext, q.DocumentNo);

                    if (type == "CurrentDate")
                        paymentClone.DocumentDate = DateTime.Today;

                    paymentClone.Commission = -paymentClone.Commission;
                    paymentClone.CommissionTax = -paymentClone.CommissionTax;
                    paymentClone.Discount = -paymentClone.Discount;
                    paymentClone.Markup = -paymentClone.Markup;
                    paymentClone.MarkupGrossOther = -paymentClone.MarkupGrossOther;
                    paymentClone.MarkupTax = -paymentClone.MarkupTax;
                    paymentClone.AmountPayable = -paymentClone.AmountPayable;
                    paymentClone.AmountPayableTax = -paymentClone.AmountPayableTax;

                    lazyContext.Insert(paymentClone);
                    lazyContext.Entry(paymentClone).State = EntityState.Detached;

                    paymentClone = lazyContext.Payment.Find(paymentClone.Id);
                    Validate(lazyContext, paymentClone, false, false);

                    PaymentDetail paymentDetailClone = null;

                    foreach (var paymentDetail in payment.PaymentDetails) {
                        paymentDetailClone = paymentDetail.Clone() as PaymentDetail;

                        paymentDetailClone.Id = 0;
                        paymentDetailClone.BankAccountStatementId = -1;
                        paymentDetailClone.PaymentId = paymentClone.Id;
                        paymentDetailClone.DocumentStatus = DocumentStatus.DepositedPaid;
                        paymentDetailClone.ReversalStatus = ReversalStatus.Reversal;
                        paymentDetailClone.Amount = -paymentDetail.Amount;
                        paymentDetailClone.Tax = -paymentDetail.Tax;
                        paymentDetailClone.NonCommissionable = -paymentDetail.NonCommissionable;
                        paymentDetailClone.NonCommissionableTax = -paymentDetail.NonCommissionableTax;

                        lazyContext.Insert(paymentDetailClone, false);
                        paymentDetail.UpdateReversalStatus(lazyContext, ReversalStatus.Reversed, -1);
                    }

                    lazyContext.Entry(paymentClone).State = EntityState.Detached;
                    paymentClone = lazyContext.Payment.Find(paymentClone.Id);

                    paymentClone.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, paymentDetailClone?.TripLine);

                    foreach (var tripLine in paymentClone.PaymentDetails.Where(t => t.TripLineId > 0).Select(t => t.TripLine).Distinct().ToList()) {
                        tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                    }
                }

                ts.Complete();
                return true;
            }
        }

        private static string GetReversedDocumentNo(AppMainContext context, string documentNo) {
            char suffix = Convert.ToChar(documentNo.Right(1).ToUpper());

            if (suffix >= 65 && suffix <= 89) {
                suffix = Convert.ToChar(suffix + 1);
                documentNo = documentNo.Left(documentNo.Length - 1);
            }
            else {
                suffix = 'A';
            }

            var q = context.Payment;

            while (q.Any(t => t.DocumentNo == string.Format("{0}{1}", documentNo, suffix))) {
                if (suffix == 'Z') {
                    documentNo += "A";
                    suffix = 'A';
                    continue;
                }

                suffix = Convert.ToChar(suffix + 1);
            }

            return string.Format("{0}{1}", documentNo, suffix);
        }
    }

    public class PaymentDetailCommon {
        private HttpContext HttpContext { get; }

        public PaymentDetailCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool ValidateAndSave(AppLazyContext lazyContext, PaymentDetail paymentDetail, bool validateDocumentStatus = true, bool performRelatedUpdates = false, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow, int oldTripLineId = 0) {
            Validate(lazyContext, paymentDetail, false, validateDocumentStatus);
            paymentDetail.Payment.MarkupGrossOther = paymentDetail.Payment.GetMarkupGross();

            bool result;

            if (paymentDetail.Id <= 0) {
                result = lazyContext.Insert(paymentDetail);
            }
            else {
                result = lazyContext.Save(paymentDetail);
            }

            if (!result && !performRelatedUpdates)
                return false;

            if (txnUpdateType == TransactionUpdateType.Bulk) {
                paymentDetail.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                ;

                foreach (var tripLine in paymentDetail.Payment.PaymentDetails.Where(t => t.TripLineId > 0).Select(t => t.TripLine).Distinct().ToList()) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }
            else if (txnUpdateType == TransactionUpdateType.SingleRow) {
                paymentDetail.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, paymentDetail.TripLine);
            }

            if (oldTripLineId > 0) {
                var tripLine = lazyContext.TripLine.Find(oldTripLineId);
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (paymentDetail.TripLineId <= 0 && paymentDetail.Payment.Trip?.Id > 0)
                paymentDetail.Payment.Trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, PaymentDetail paymentDetail, bool validateDocumentStatus = true) {
            Validate(lazyContext, paymentDetail, true, validateDocumentStatus);
            var tripLine = paymentDetail.TripLine;

            if (lazyContext.Delete(paymentDetail))
                return tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return false;
        }

        public void Validate(AppLazyContext lazyContext, PaymentDetail paymentDetail, bool isDeletion, bool validateDocumentStatus = true) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), paymentDetail.Payment.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!isDeletion && paymentDetail.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard) {
                int agencyId = paymentDetail.Payment.AgencyId;

                if (agencyId <= 0 && paymentDetail.Id <= 0)
                    agencyId = HttpContext.CurrentDefaultAgencyId();

                var debtor = paymentDetail.Payment.Trip.Debtor.BillingHeadDebtor;

                if (debtor.Id > 0)
                    debtor.ValidateCreditLimit(lazyContext, TransactionType.Payment, paymentDetail.Id, agencyId, paymentDetail.Amount + paymentDetail.Tax + paymentDetail.NonCommissionableGross - paymentDetail.DiscountGrossProRata + paymentDetail.MarkupGrossProRata);
            }

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !paymentDetail.CanDelete(HttpContext.IsAdministrator(), HttpContext.IsAccounts(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !paymentDetail.CanEdit(HttpContext.IsAdministrator(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public bool CreateOrUpdate(PaymentDetailViewModel model, bool isTaxIncluded, bool validateLimits, bool validateDocumentStatus = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            if (model.PaymentDetailPaymentType != PaymentType.SupplierPayment && model.PaymentDetailPaymentType != PaymentType.Admin) {
                model.PaymentDetailTax = 0;
                model.PaymentDetailNonCommissionable = 0;
            }

            if (model.PaymentDetailPaymentType == PaymentType.Admin) {
                model.PaymentDetailOfferedFare = 0;
                model.PaymentDetailOfferedReasonId = -1;
            }
            else if (model.PaymentDetailOfferedFare != 0 && (model.PaymentDetailOfferedReasonId ?? 0) <= 0) {
                throw new UnreportedException("Reason Rejected is required when Offered Fare is applied.");
            }

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    var payment = lazyContext.Payment.Find(model.PaymentId);

                    if (payment.PaymentType != PaymentType.Admin)
                        model.PaymentDetailIsTaxApplicable = payment.IsTaxApplicable;

                    PaymentDetail q = null;

                    if (model.PaymentDetailId <= 0) {
                        q = new PaymentDetail {
                            Id = 0,
                            DocumentStatus = DocumentStatus.DepositedPaid,
                            ReversalStatus = ReversalStatus.None,
                            BankAccountStatementId = -1,
                            Payment = payment
                        };
                    }
                    else {
                        q = lazyContext.PaymentDetail.Find(model.PaymentDetailId);
                    }

                    int tripLineAirPassengerId = -1;
                    int passengerId = -1;

                    if (model.PaymentDetailPaymentType == PaymentType.SupplierPayment || model.PaymentDetailPaymentType == PaymentType.ClientRefund) {
                        tripLineAirPassengerId = model.PaymentDetailTripLineAirPassengerId ?? 0;

                        if (tripLineAirPassengerId <= 0)
                            passengerId = model.PaymentDetailPassengerId ?? 0;
                    }

                    decimal nonCommissionable = model.PaymentDetailNonCommissionable;
                    decimal nonCommissionableTax = 0;
                    decimal tax = 0;
                    decimal amount = model.PaymentDetailAmount;

                    if (model.PaymentDetailIsTaxApplicable || (!validateLimits && payment.IsTaxApplicable)) {
                        decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), payment.DocumentDate);

                        nonCommissionableTax = Math.Round(nonCommissionable * taxRate / (1 + taxRate), 2);
                        nonCommissionable -= nonCommissionableTax;

                        if (isTaxIncluded) {
                            tax = Math.Round(amount * taxRate / (1 + taxRate), 2);
                            amount -= tax;
                        }
                        else {
                            tax = Math.Round(amount * taxRate, 2);
                        }

                        if (validateLimits) {
                            if (Math.Abs(model.PaymentDetailTax - tax) > .02m)
                                throw new UnreportedException(string.Format("{0} value is outside accepted limits.", Resource.TaxLabel));

                            if (tax != model.PaymentDetailTax) {
                                tax = model.PaymentDetailTax;

                                if (isTaxIncluded)
                                    amount = model.PaymentDetailAmount - tax;
                            }
                        }
                    }

                    int oldTripLineId = q.Id > 0 && q.TripLineId != model.PaymentDetailTripLineId ? q.TripLineId : 0;

                    q.PaymentId = model.PaymentId;
                    q.TripLineId = model.PaymentDetailTripLineId ?? 0;
                    q.TripLineAirPassengerId = tripLineAirPassengerId;
                    q.PassengerId = passengerId;
                    q.FormOfPaymentId = model.PaymentDetailFormOfPaymentId ?? 0;
                    q.OfferedFare = model.PaymentDetailOfferedFare;
                    q.OfferedReasonId = model.PaymentDetailOfferedReasonId ?? 0;
                    q.Amount = amount;
                    q.Tax = tax;
                    q.NonCommissionable = nonCommissionable;
                    q.NonCommissionableTax = nonCommissionableTax;
                    q.IsTaxApplicable = model.PaymentDetailIsTaxApplicable;

                    if (model.PaymentDetailId <= 0) {
                        q.TripLine = lazyContext.TripLine.Find(q.TripLineId);
                        q.TripLineAirPassenger = lazyContext.TripLineAirPassenger.Find(q.TripLineAirPassengerId);
                        q.Passenger = lazyContext.Passenger.Find(q.PassengerId);
                        q.FormOfPayment = lazyContext.FormOfPayment.Find(q.FormOfPaymentId);
                        q.OfferedReason = lazyContext.OfferedReason.Find(q.OfferedReasonId);
                    }

                    bool result = ValidateAndSave(lazyContext, q, validateDocumentStatus, false, txnUpdateType, oldTripLineId);

                    payment.AmountPayableTax = payment.GetAmountPayableTax();
                    payment.AmountPayable = payment.GetAmountPayable(lazyContext);
                    payment.AmountPayableTax = payment.GetAmountPayableTax();
                    lazyContext.Save(payment);

                    model.PaymentDetailId = q.Id;

                    ts.Complete();
                    return result;
                }
            }
        }

        public bool CreateOrUpdate(PaymentViewModel model, PaymentDetailViewModel detailModel, bool isNew) {
            using (var ts = Utils.CreateTransactionScope()) {
                new PaymentCommon(HttpContext).CreateOrUpdate(model, !isNew, false, TransactionUpdateType.None);
                detailModel.PaymentId = model.PaymentId;
                CreateOrUpdate(detailModel, model.PaymentIsTaxIncluded, true, !isNew);
                ts.Complete();
                return true;
            }
        }

        public bool Delete(AppLazyContext lazyContext, PaymentDetailViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.PaymentDetail.Include(t => t.TransactionDetails).SingleOrDefault(t => t.Id == model.PaymentDetailId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (q.Payment.PaymentDetails.Count == 1)
                    throw new UnreportedException(AppConstants.RecordCannotBeDeleted);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }
    }

    public class InvoiceCommon {
        private HttpContext HttpContext { get; }

        public InvoiceCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool ValidateAndSave(AppLazyContext lazyContext, Invoice invoice, bool isNew, bool validateDocumentStatus = true, bool performRelatedUpdates = false, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            Validate(invoice, isNew, false, validateDocumentStatus);

            bool result;

            if (invoice.Id <= 0) {
                result = lazyContext.Insert(invoice);
            }
            else {
                result = lazyContext.Save(invoice);
            }

            if (!result && !performRelatedUpdates)
                return false;

            if (txnUpdateType != TransactionUpdateType.None)
                invoice.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            ;

            foreach (var tripLine in invoice.InvoiceDetails.Where(t => t.TripLineId > 0).Select(t => t.TripLine).Distinct().ToList()) {
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            foreach (var trip in invoice.InvoiceDetails.Where(t => t.TripLineId <= 0 && t.TripId > 0).Select(t => t.Trip).Distinct().ToList()) {
                trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, Invoice invoice, bool isNew, bool validateDocumentStatus = true, bool overrideValidation = false) {
            using (var ts = Utils.CreateTransactionScope()) {
                if (!(overrideValidation && (invoice.DocumentStatus == DocumentStatus.None || invoice.DocumentStatus == DocumentStatus.Open)))
                    Validate(invoice, isNew, true, validateDocumentStatus);

                DeleteCustomerTransactions(lazyContext, invoice);

                if (HttpContext.IsSuperUser()) {
                    int[] invoiceDetailIds = invoice.InvoiceDetails.Select(t => t.Id).ToArray();

                    lazyContext.RemoveRange(lazyContext.TransactionDetail.Where(t => invoiceDetailIds.Contains(t.InvoiceDetailId)).SelectMany(t => t.TransactionDetailAllocations));
                    lazyContext.SaveChanges();

                    lazyContext.RemoveRange(lazyContext.TransactionDetailAllocation.Where(t => invoiceDetailIds.Contains(t.InvoiceDetailId)));
                    lazyContext.SaveChanges();

                    lazyContext.RemoveRange(invoice.IssuedDocuments);
                    lazyContext.SaveChanges();

                    if (invoice.InvoiceLinkId > 0) {
                        var matchedInvoice = lazyContext.Invoice.Find(invoice.InvoiceLinkId);

                        if (matchedInvoice?.InvoiceLinkId > 0) {
                            matchedInvoice.InvoiceLinkId = -1;
                            matchedInvoice.IsMatched = false;
                            lazyContext.Save(matchedInvoice, false);
                        }

                        invoice.InvoiceLinkId = -1;
                        invoice.IsMatched = false;
                        lazyContext.Save(invoice, false);
                    }
                }

                lazyContext.RemoveRange(invoice.Transactions);
                lazyContext.SaveChanges();

                var tripLines = invoice.InvoiceDetails.Select(t => t.TripLine).Where(t => t.Id > 0).Distinct().ToList();

                if (!lazyContext.Delete(invoice))
                    return false;

                foreach (var tripLine in tripLines) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }

                ts.Complete();
                return true;
            }
        }

        private void Validate(Invoice invoice, bool isNew, bool isDeletion, bool validateDocumentStatus = true) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), invoice.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !invoice.CanDelete(isNew, HttpContext.IsAdministrator(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !invoice.CanEdit(isNew, HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public InvoiceViewModel Reissue(AppLazyContext lazyContext, int invoiceId, InvoiceType invoiceType, bool autoMatch) {
            using (var ts = Utils.CreateTransactionScope()) {
                bool isAdministrator = HttpContext.IsAdministrator();
                bool isSuperUser = HttpContext.IsSuperUser();

                var q = lazyContext.Invoice.SingleOrDefault(t => t.Id == invoiceId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (!q.CanReissue())
                    throw new UnreportedException("This document cannot be reissued.");

                if (!q.CanReissue(autoMatch))
                    throw new UnreportedException("This document cannot be reissued with the Matched option.");

                if (q.InvoiceType == InvoiceType.CreditNote)
                    autoMatch = false;

                q.UpdateDocumentStatus(lazyContext, DocumentStatus.Closed);

                var model = new InvoiceViewModel {
                    InvoiceId = 0,
                    InvoiceAccountType = q.AccountType,
                    InvoiceType = invoiceType,
                    InvoiceDocumentNo = q.DocumentNo,
                    InvoiceDocumentDate = q.DocumentDate,
                    InvoiceDebtorId = q.DebtorId,
                    InvoiceSubDebtorId = q.SubDebtorId,
                    InvoiceDebtorContactId = q.DebtorContactId,
                    InvoiceDebtorName = q.DebtorName,
                    InvoiceDebtorAddress1 = q.DebtorAddress1,
                    InvoiceDebtorAddress2 = q.DebtorAddress2,
                    InvoiceDebtorLocality = q.DebtorLocality,
                    InvoiceDebtorRegion = q.DebtorRegion,
                    InvoiceDebtorPostCode = q.DebtorPostCode,
                    InvoiceDebtorCountryCode = q.DebtorCountryCode,
                    InvoiceDebtorOrderNo = q.DebtorOrderNo,
                    InvoiceDebtorCurrencyId = q.DebtorCurrencyId,
                    InvoiceDebtorExchangeRate = q.DebtorExchangeRate,
                    InvoiceDeposit = q.Deposit,
                    InvoiceBalance = q.Balance,
                    InvoiceDepositDueDate = q.DepositDueDate,
                    InvoiceDepositPaidDate = q.DepositPaidDate,
                    InvoiceBalanceDueDate = q.BalanceDueDate,
                    InvoicePaymentTerms = q.PaymentTerms,
                    InvoiceComments = q.Comments,
                    InvoiceTotalAmount = q.TotalAmount,
                    InvoiceTotalTax = q.TotalTax,
                    InvoiceTotalDiscount = q.TotalDiscount,
                    InvoiceIsIssued = false,
                    InvoiceAgencyId = q.AgencyId
                };

                CreateOrUpdate(model, autoMatch ? invoiceId : -1, false, true, TransactionUpdateType.None);

                InvoiceDetailViewModel detailModel = null;

                foreach (var row in q.InvoiceDetails) {
                    detailModel = new InvoiceDetailViewModel {
                        InvoiceDetailId = 0,
                        InvoiceId = model.InvoiceId,
                        InvoiceDetailAccountType = row.Invoice.AccountType,
                        InvoiceDetailDocumentStatus = autoMatch ? DocumentStatus.Closed : DocumentStatus.Open,
                        InvoiceDetailTripId = row.TripId,
                        InvoiceDetailTripLineId = row.TripLineId,
                        InvoiceDetailTripLineAirPassengerId = row.TripLineAirPassengerId,
                        InvoiceDetailChartOfAccountId = row.ChartOfAccountId,
                        InvoiceDetailSaleTypeId = row.SaleTypeId,
                        InvoiceDetailAmount = row.Amount,
                        InvoiceDetailTax = row.Tax,
                        InvoiceDetailPaymentTax = row.PaymentTax,
                        InvoiceDetailDiscount = row.Discount,
                        InvoiceDetailDiscountTax = row.DiscountTax,
                        InvoiceDetailDiscountReasonId = row.DiscountReasonId,
                        InvoiceDetailCreditorId = row.CreditorId,
                        InvoiceDetailSupplierId = row.SupplierId,
                        InvoiceDetailAirlineId = row.AirlineId,
                        InvoiceDetailDocumentNo = row.DocumentNo,
                        InvoiceDetailConfirmationNo = row.ConfirmationNo,
                        InvoiceDetailDescription = row.Description,
                        InvoiceDetailIsPayment = row.IsPayment
                    };

                    new InvoiceDetailCommon(HttpContext).CreateOrUpdate(detailModel, false, false, true, row.InvoiceDetailPassengers.Select(t => t.PassengerId).ToArray());
                }

                model.InvoiceTotalAmount = q.TotalAmount;
                model.InvoiceTotalTax = q.TotalTax;
                model.InvoiceTotalTaxRate = q.TotalTaxRate;
                model.InvoiceTotalDiscount = q.TotalDiscount;
                model.InvoiceTotalDiscountRate = q.TotalDiscountRate;

                ts.Complete();
                return model;
            }
        }

        public InvoiceViewModel Create(AppLazyContext lazyContext, int tripId, int[] tripLineIds, int[] passengerIds, bool ignoreReceiptedAmount, bool deductCreditCardPayments, bool overrideDoNotGenerateInvoiceLine) {
            if (tripLineIds == null || tripLineIds.Length == 0)
                throw new UnreportedException("No trip lines have been selected.");

            using (var ts = Utils.CreateTransactionScope()) {
                var trip = lazyContext.Trip.Find(tripId);

                if (trip.TripPassengers.Count == 0 || passengerIds == null || passengerIds.Length == 0)
                    throw new UnreportedException("No passengers have been selected.");

                if (trip.TripLines.Any(t => tripLineIds.Contains(t.Id) && !t.IsBooking))
                    throw new UnreportedException("Only booked records can be processed for invoicing.");

                if (trip.TripLines.Any(t => tripLineIds.Contains(t.Id) && t.TripLineType == TripLineType.Insurance && t.TripLineInsurance.PolicyNo.Length == 0))
                    throw new UnreportedException("Policy No is required for one or more insurance trip lines.");

                decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), DateTime.Today);

                decimal invoiceDetailAmount = 0;
                decimal invoiceDetailTax = 0;
                decimal invoiceDetailDiscount = 0;
                decimal invoiceDetailDiscountTax = 0;
                decimal passengerRatio = 1;
                decimal basePassengerRatio = 1;

                var debtor = trip.Debtor.BillingHeadDebtor.Id > 0 ? trip.Debtor.BillingHeadDebtor : trip.Debtor;
                bool invoiceAllPassengers = false;

                var invoiceModel = new InvoiceViewModel {
                    InvoiceDocumentStatus = DocumentStatus.Open,
                    InvoiceAccountType = AccountType.Client,
                    InvoiceType = InvoiceType.Invoice,
                    InvoiceDocumentDate = HttpContext.Today(),
                    InvoiceDebtorId = debtor.Id,
                    InvoiceSubDebtorId = trip.Debtor.BillingHeadDebtor.Id > 0 ? trip.DebtorId : -1,
                    InvoiceDebtorName = debtor.Name,
                    InvoiceAgencyId = HttpContext.CurrentDefaultAgencyId(),
                    InvoiceDebtorCurrencyId = debtor.CurrencyId,
                    InvoiceDebtorExchangeRate = debtor.Currency.GetExchangeRate(),
                    InvoicePaymentTerms = debtor.PaymentTerm.Name,
                    InvoiceComments = string.Empty
                };

                if (tripId > 0) {
                    invoiceModel.InvoiceDebtorOrderNo = trip.DebtorOrderNo;
                    invoiceModel.InvoiceDebtorContactId = trip.DebtorBookedById;
                }

                if (invoiceModel.InvoiceDebtorContactId <= 0 && debtor.DebtorContacts.Count == 1) {
                    var contact = debtor.DebtorContacts.OrderBy(t => t.IsDefault ? 0 : 1).FirstOrDefault();
                    invoiceModel.InvoiceDebtorContactId = contact.Id;
                }
                else {
                    invoiceModel.InvoiceDebtorContactId = -1;
                }

                var address = debtor.DebtorAddresses.OrderBy(t => t.IsDefault ? 0 : 1).FirstOrDefault();

                if (address != null) {
                    invoiceModel.InvoiceDebtorAddress1 = address.Address1;
                    invoiceModel.InvoiceDebtorAddress2 = address.Address2;
                    invoiceModel.InvoiceDebtorLocality = address.Locality;
                    invoiceModel.InvoiceDebtorRegion = address.Region;
                    invoiceModel.InvoiceDebtorPostCode = address.PostCode;
                    invoiceModel.InvoiceDebtorCountryCode = address.CountryCode;
                }

                CreateOrUpdate(invoiceModel, -1, true, true, TransactionUpdateType.None);

                var tripLines = trip.TripLines.Where(t => tripLineIds.Contains(t.Id) && ((ignoreReceiptedAmount ? t.GetAmountInvoiceable() : t.GetAmountInvoiceableDue(lazyContext)) + t.PersonalTravelAmount != 0));

                if (!tripLines.Any())
                    throw new UnreportedException("Selected trip lines have already been invoiced or are zero value.");

                if (tripLines.Any(t => t.TripLineType == TripLineType.Air && t.TripLineAir.TripLineAirPassengers.Any(t2 => t2.PassengerId <= 0)))
                    throw new UnreportedException("One or more air trip lines do not have a passenger defined.");

                InvoiceDetailViewModel invoiceDetailModel = null;

                foreach (var tripLine in tripLines.Where(t => !t.FormOfPayment.DoNotGenerateInvoiceLine || overrideDoNotGenerateInvoiceLine)) {
                    invoiceDetailModel = new InvoiceDetailViewModel {
                        InvoiceDetailId = 0,
                        InvoiceId = invoiceModel.InvoiceId,
                        InvoiceDetailTripId = tripId,
                        InvoiceDetailChartOfAccountId = -1,
                        InvoiceDetailCreditorId = -1,
                        InvoiceDetailSupplierId = -1,
                        InvoiceDetailAirlineId = -1
                    };

                    switch (tripLine.TripLineType) {
                        default:
                            continue;
                        case TripLineType.Air:
                            var tripLineAirPassengers = tripLine.TripLineAir.TripLineAirPassengers.Where(t => passengerIds.Contains(t.PassengerId)).ToList();
                            invoiceAllPassengers = tripLineAirPassengers.Count <= passengerIds.Length;

                            foreach (var row in tripLineAirPassengers) {
                                if (row.FormOfPayment.DoNotGenerateInvoiceLine && !overrideDoNotGenerateInvoiceLine)
                                    continue;

                                if (invoiceAllPassengers) {
                                    invoiceDetailAmount = ignoreReceiptedAmount ? row.GetAmountInvoiceable(HttpContext.CurrentCustomerId()) : row.GetAmountInvoiceableDue(lazyContext, HttpContext.CurrentCustomerId());
                                }
                                else {
                                    invoiceDetailAmount = row.GetAmountInvoiceable(HttpContext.CurrentCustomerId());
                                }

                                invoiceDetailDiscount = row.Discount;

                                if (row.SaleType.IsTaxApplicable) {
                                    invoiceDetailTax = invoiceDetailAmount * taxRate / (1 + taxRate);
                                    invoiceDetailDiscountTax = invoiceDetailDiscount * taxRate / (1 + taxRate);
                                }
                                else {
                                    invoiceDetailTax = 0;
                                    invoiceDetailDiscountTax = 0;
                                }

                                invoiceDetailAmount -= invoiceDetailTax;
                                invoiceDetailDiscount -= invoiceDetailDiscountTax;

                                if (invoiceDetailAmount == 0 && row.PersonalTravelAmount == 0)
                                    continue;

                                invoiceDetailModel.InvoiceDetailId = 0;
                                invoiceDetailModel.InvoiceDetailTripLineId = row.TripLineAir.TripLineId;
                                invoiceDetailModel.InvoiceDetailTripLineAirPassengerId = row.Id;
                                invoiceDetailModel.InvoiceDetailSaleTypeId = row.SaleType.Id;

                                invoiceDetailModel.InvoiceDetailDiscountReasonId = row.DiscountReason.Id;
                                invoiceDetailModel.InvoiceDetailAmount = invoiceDetailAmount + invoiceDetailDiscount;
                                invoiceDetailModel.InvoiceDetailTax = invoiceDetailTax + invoiceDetailDiscountTax;
                                invoiceDetailModel.InvoiceDetailDiscount = invoiceDetailDiscount;
                                invoiceDetailModel.InvoiceDetailDiscountTax = invoiceDetailDiscountTax;

                                invoiceDetailModel.InvoiceDetailCreditorId = row.CreditorId;
                                invoiceDetailModel.InvoiceDetailSupplierId = row.SupplierId;
                                invoiceDetailModel.InvoiceDetailAirlineId = row.AirlineId;
                                invoiceDetailModel.InvoiceDetailDocumentNo = row.TicketNo;
                                invoiceDetailModel.InvoiceDetailConfirmationNo = string.Empty;

                                invoiceDetailModel.InvoiceDetailDescription = row.TripLineAir.TripLine.GetTravelDocumentInvoiceDetails(lazyContext, HttpContext.CurrentCustomerId(), row.Id);
                                new InvoiceDetailCommon(HttpContext).CreateOrUpdate(invoiceDetailModel, false, false, false, passengerIds, true, TransactionUpdateType.None);
                            }

                            continue;
                        case TripLineType.Accommodation:
                        case TripLineType.Transport:
                        case TripLineType.Cruise:
                        case TripLineType.Tour:
                        case TripLineType.OtherLand:
                        case TripLineType.ForeignCurrency:
                        case TripLineType.ServiceFee:
                        case TripLineType.OtherInclusion:
                            bool allowPassengerInvoicing = false;
                            int passengerCount = 1;

                            switch (tripLine.TripLineType) {
                                case TripLineType.Accommodation:
                                case TripLineType.Transport:
                                case TripLineType.Cruise:
                                case TripLineType.Tour:
                                case TripLineType.OtherLand:
                                    allowPassengerInvoicing = tripLine.TripLineLand.AllowPassengerInvoicing;
                                    break;
                                case TripLineType.ForeignCurrency:
                                    allowPassengerInvoicing = tripLine.TripLineForeignCurrency.AllowPassengerInvoicing;
                                    break;
                                case TripLineType.ServiceFee:
                                    allowPassengerInvoicing = tripLine.TripLineServiceFee.AllowPassengerInvoicing;
                                    break;
                                case TripLineType.OtherInclusion:
                                    allowPassengerInvoicing = tripLine.TripLineOtherInclusion.AllowPassengerInvoicing;
                                    break;
                            }

                            if (allowPassengerInvoicing) {
                                passengerCount = tripLine.PaxNo;
                                basePassengerRatio = passengerCount == 0 ? 1 : (decimal)passengerIds.Length / passengerCount;

                                passengerCount -= tripLine.InvoiceDetailPassengers.Select(t => t.PassengerId).Distinct().Count();
                                passengerRatio = passengerCount == 0 ? 1 : (decimal)passengerIds.Length / passengerCount;
                            }

                            break;
                        case TripLineType.Insurance:
                            passengerCount = 1;

                            if (tripLine.TripLineInsurance.AllowPassengerInvoicing) {
                                passengerCount = tripLine.TripLineInsurance.TripLineInsurancePassengers.Count;

                                if (passengerCount == 0)
                                    passengerCount = tripLine.PaxNo;

                                basePassengerRatio = passengerCount == 0 ? 1 : (decimal)passengerIds.Length / passengerCount;

                                passengerCount -= tripLine.InvoiceDetailPassengers.Select(t => t.PassengerId).Distinct().Count();
                                passengerRatio = passengerCount == 0 ? 1 : (decimal)passengerIds.Length / passengerCount;
                            }

                            break;
                    }

                    if (passengerRatio > 1)
                        passengerRatio = 1;

                    decimal amountInvoiceableDue = ignoreReceiptedAmount ? tripLine.GetAmountInvoiceable() : tripLine.GetAmountInvoiceableDue(lazyContext);
                    invoiceAllPassengers = passengerRatio == 1;

                    if (invoiceAllPassengers) {
                        invoiceDetailAmount = amountInvoiceableDue;
                        invoiceDetailDiscount = tripLine.Discount;
                    }
                    else {
                        invoiceDetailAmount = tripLine.GetAmountInvoiceable() * passengerRatio;
                        invoiceDetailDiscount = tripLine.Discount * basePassengerRatio;

                        if (invoiceDetailAmount > amountInvoiceableDue * passengerRatio)
                            invoiceDetailAmount = amountInvoiceableDue * passengerRatio;
                    }

                    if (tripLine.SaleType.IsTaxApplicable) {
                        invoiceDetailTax = invoiceDetailAmount * taxRate / (1 + taxRate);
                        invoiceDetailDiscountTax = invoiceDetailDiscount * taxRate / (1 + taxRate);
                    }
                    else {
                        invoiceDetailTax = 0;
                        invoiceDetailDiscountTax = 0;
                    }

                    invoiceDetailAmount -= invoiceDetailTax;
                    invoiceDetailDiscount -= invoiceDetailDiscountTax;

                    if (invoiceDetailAmount == 0 && tripLine.PersonalTravelAmount == 0)
                        continue;

                    invoiceDetailModel.InvoiceDetailAmount = invoiceDetailAmount + invoiceDetailDiscount;
                    invoiceDetailModel.InvoiceDetailTax = invoiceDetailTax + invoiceDetailDiscountTax;
                    invoiceDetailModel.InvoiceDetailDiscount = invoiceDetailDiscount;
                    invoiceDetailModel.InvoiceDetailDiscountTax = invoiceDetailDiscountTax;

                    invoiceDetailModel.InvoiceDetailTripLineId = tripLine.Id;
                    invoiceDetailModel.InvoiceDetailTripLineAirPassengerId = -1;
                    invoiceDetailModel.InvoiceDetailSaleTypeId = tripLine.SaleType.Id;
                    invoiceDetailModel.InvoiceDetailDiscountReasonId = invoiceDetailDiscount == 0 ? -1 : tripLine.DiscountReason.Id;

                    invoiceDetailModel.InvoiceDetailCreditorId = tripLine.Creditor.Id;
                    invoiceDetailModel.InvoiceDetailSupplierId = tripLine.Supplier.Id;
                    invoiceDetailModel.InvoiceDetailAirlineId = -1;
                    invoiceDetailModel.InvoiceDetailDocumentNo = tripLine.DocumentNo;
                    invoiceDetailModel.InvoiceDetailConfirmationNo = tripLine.ConfirmationNo;

                    invoiceDetailModel.InvoiceDetailDescription = tripLine.GetTravelDocumentInvoiceDetails(lazyContext, HttpContext.CurrentCustomerId(), 0, passengerIds);
                    new InvoiceDetailCommon(HttpContext).CreateOrUpdate(invoiceDetailModel, false, false, false, passengerIds, true, TransactionUpdateType.None);
                }

                if (invoiceDetailModel != null) {
                    new InvoiceDetailCommon(HttpContext).CreateOrUpdate(invoiceDetailModel, false, false, false, passengerIds, true, TransactionUpdateType.Bulk);

                    if (deductCreditCardPayments)
                        new InvoiceDetailCommon(HttpContext).CreateOrUpdateCreditCardPayment(lazyContext, invoiceModel.InvoiceId, true, basePassengerRatio, passengerIds);
                }

                var invoice = lazyContext.Invoice.Find(invoiceModel.InvoiceId);

                if (invoice.TotalAmount < 0) {
                    invoice.InvoiceType = InvoiceType.CreditNote;
                    lazyContext.Save(invoice, false);

                    foreach (var invoiceDetail in invoice.InvoiceDetails) {
                        invoiceDetail.Amount = -invoiceDetail.Amount;
                        invoiceDetail.Tax = -invoiceDetail.Tax;
                        invoiceDetail.Discount = -invoiceDetail.Discount;
                        invoiceDetail.DiscountTax = -invoiceDetail.DiscountTax;
                        lazyContext.Save(invoiceDetail, false);
                    }
                }

                ts.Complete();
                return invoiceModel;
            }
        }

        public bool CreateOrUpdate(InvoiceViewModel model, int originalInvoiceId = -1, bool validateDocumentStatus = true, bool performRelatedUpdates = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            if (HttpContext.CustomerSettings().IsManagementCustomer && HttpContext.CustomerSettings().ExcludeFromBilling)
                throw new UnreportedException("This company is excluded from billing and does not support invoicing.");

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    Invoice q = null;

                    if (model.InvoiceId <= 0) {
                        var debtor = lazyContext.Debtor.Find(model.InvoiceDebtorId ?? -1);
                        var parentDebtor = debtor.BillingHeadDebtor;

                        q = new Invoice {
                            Id = 0,
                            DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Invoice"),
                            DocumentDate = model.InvoiceDocumentDate ?? DateTime.MinValue,
                            DebtorId = debtor.Id,
                            Debtor = debtor,
                            SubDebtorId = model.InvoiceSubDebtorId ?? 0,
                            SubDebtor = lazyContext.Debtor.Find(model.InvoiceSubDebtorId),
                            DebtorCurrencyId = model.InvoiceDebtorCurrencyId ?? 0,
                            DebtorCurrency = lazyContext.Currency.Find(model.InvoiceDebtorCurrencyId),
                            InvoiceLinkId = originalInvoiceId,
                            InvoiceLink = lazyContext.Invoice.Find(originalInvoiceId),
                            IsMatched = originalInvoiceId > 0
                        };

                        if (parentDebtor.Id > 0) {
                            model.InvoiceDebtorId = parentDebtor.Id;
                            model.InvoiceDebtorCurrencyId = parentDebtor.CurrencyId;
                            model.InvoiceDebtorExchangeRate = parentDebtor.Currency.GetExchangeRate();

                            if (model.InvoiceDebtorName == debtor.Name)
                                model.InvoiceDebtorName = parentDebtor.Name;

                            if (model.InvoiceSubDebtorId <= 0)
                                model.InvoiceSubDebtorId = debtor.Id;
                        }

                        q.DebtorId = model.InvoiceDebtorId ?? 0;
                        LastDocumentNo.DocumentNo(lazyContext, "Invoice", q.DocumentNo);
                    }
                    else {
                        q = lazyContext.Invoice.Find(model.InvoiceId);
                    }

                    q.AgencyId = HttpContext.CurrentDefaultAgencyId();

                    q.AccountType = model.InvoiceAccountType;
                    q.InvoiceType = model.InvoiceType;
                    q.DocumentDate = model.InvoiceDocumentDate ?? DateTime.MinValue;
                    q.SubDebtorId = model.InvoiceSubDebtorId ?? 0;
                    q.DebtorContactId = model.InvoiceDebtorContactId ?? 0;
                    q.DebtorName = model.InvoiceDebtorName.ToStringExt();
                    q.DebtorAddress1 = model.InvoiceDebtorAddress1.ToStringExt();
                    q.DebtorAddress2 = model.InvoiceDebtorAddress2.ToStringExt();
                    q.DebtorLocality = model.InvoiceDebtorLocality.ToStringExt();
                    q.DebtorRegion = model.InvoiceDebtorRegion.ToStringExt();
                    q.DebtorPostCode = model.InvoiceDebtorPostCode.ToStringExt();
                    q.DebtorCountryCode = model.InvoiceDebtorCountryCode.ToStringExt();
                    q.DebtorOrderNo = model.InvoiceDebtorOrderNo.ToStringExt();
                    q.DebtorCurrencyId = model.InvoiceDebtorCurrencyId ?? 0;
                    q.DebtorExchangeRate = model.InvoiceDebtorExchangeRate;
                    q.Deposit = model.InvoiceDeposit;
                    q.Balance = model.InvoiceBalance;
                    q.DepositDueDate = model.InvoiceDepositDueDate ?? DateTime.MinValue;
                    q.DepositPaidDate = model.InvoiceDepositPaidDate ?? DateTime.MinValue;
                    q.BalanceDueDate = model.InvoiceBalanceDueDate ?? DateTime.MinValue;
                    q.PaymentTerms = model.InvoicePaymentTerms.ToStringExt();
                    q.Comments = model.InvoiceComments.ToStringExt();
                    q.IsIssued = q.IssuedDocuments.Count > 0;

                    bool result = ValidateAndSave(lazyContext, q, model.InvoiceIsNew, validateDocumentStatus, performRelatedUpdates, txnUpdateType);
                    model.InvoiceId = q.Id;

                    if (originalInvoiceId > 0) {
                        q.InvoiceLinkId = originalInvoiceId;
                        q.IsMatched = true;
                        lazyContext.Save(q);

                        q = lazyContext.Invoice.Find(originalInvoiceId);
                        q.InvoiceLinkId = model.InvoiceId;
                        q.IsMatched = true;
                        lazyContext.Save(q);
                    }

                    ts.Complete();
                    return result;
                }
            }
        }

        public bool Delete(AppLazyContext lazyContext, InvoiceViewModel model, bool overrideValidation = false) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.Invoice.Include(t => t.InvoiceDetails).ThenInclude(t => t.TripLine).Include(t => t.InvoiceDetails).ThenInclude(t => t.Trip).Include(t => t.InvoiceDetails).Include(t => t.Transactions).SingleOrDefault(t => t.Id == model.InvoiceId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                ValidateAndDelete(lazyContext, q, model.InvoiceIsNew, true, overrideValidation);

                ts.Complete();
                return true;
            }
        }

        public bool CreateOrUpdateCustomerTransaction(AppLazyContext lazyContext, Invoice invoice) {
            if (invoice.Debtor?.CustomerId == 0 || invoice.AccountType != AccountType.GeneralLedger)
                return false;

            using (var adminContext = new AppAdminContext(HttpContext.User)) {
                int[] customerTxnIds = invoice.InvoiceDetails.Select(t => t.CustomerTransactionId).Distinct().ToArray();
                var customerTxn = adminContext.CustomerTransaction.SingleOrDefault(t => customerTxnIds.Contains(t.Id));

                customerTxn ??= adminContext.CustomerTransaction.Where(t => t.CustomerId == invoice.Debtor.CustomerId && t.DocumentNo == invoice.DocumentNo && t.Document != null).AsEnumerable().FirstOrDefault(t => t.IsInvoiceItem);

                if (customerTxn != null)
                    return false;

                var customerTxnModel = new CustomerTransactionViewModel {
                    CustomerTransactionId = customerTxn?.Id ?? 0,
                    CustomerTransactionCustomerId = invoice.Debtor.CustomerId,
                    CustomerTransactionType = invoice.InvoiceType == InvoiceType.CreditNote ? CustomerTransactionType.Refund : CustomerTransactionType.Invoice,
                    CustomerTransactionApprovalStatus = CustomerTransactionApprovalStatus.Approved,
                    CustomerTransactionDateFrom = invoice.DocumentDate,
                    CustomerTransactionDateTo = invoice.DocumentDate,
                    CustomerTransactionDateDue = invoice.BalanceDueDate == DateTime.MinValue ? invoice.DocumentDate.AddDays(AppSettings.CustomerPaymentTermsDays) : invoice.BalanceDueDate,
                    CustomerTransactionUserCount = 0,
                    CustomerTransactionUserCharge = 0,
                    CustomerTransactionAmountGross = invoice.InvoiceDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0,
                    CustomerTransactionTax = invoice.InvoiceDetails.Sum(t => (decimal?)t.Tax) ?? 0,
                    CustomerTransactionDocumentNo = invoice.DocumentNo,
                    PaymentTransactionId = 0,
                    CustomerTransactionDescription = invoice.InvoiceType == InvoiceType.CreditNote ? "Refund" : "Subscription",
                    IsUserCreated = false
                };

                if (CustomerTransactionCommon.CreateOrUpdate(HttpContext, adminContext, lazyContext, customerTxnModel, CustomerTxnSource.InvoiceCreateOrUpdate, false, null, invoice)) {
                    foreach (var invoiceDetail in invoice.InvoiceDetails) {
                        invoiceDetail.CustomerTransactionId = customerTxnModel.CustomerTransactionId;
                        lazyContext.Save(invoiceDetail, false);
                    }
                }
            }

            return true;
        }

        private bool DeleteCustomerTransactions(AppLazyContext lazyContext, Invoice invoice) {
            if (invoice.Debtor?.CustomerId == 0 || invoice.AccountType != AccountType.GeneralLedger)
                return false;

            using (var adminContext = new AppAdminContext(HttpContext.User)) {
                foreach (var invoiceDetail in invoice.InvoiceDetails) {
                    int[] groupNos = lazyContext.TransactionDetailAllocation.Where(t => t.InvoiceDetailId == invoiceDetail.Id).Select(t => t.GroupNo).Distinct().ToArray();
                    lazyContext.RemoveRange(lazyContext.TransactionDetailAllocation.Where(t => groupNos.Contains(t.GroupNo)));
                    lazyContext.SaveChanges();

                    var customerTxn = adminContext.CustomerTransaction.Find(invoiceDetail.CustomerTransactionId);

                    if (customerTxn != null)
                        adminContext.Delete(customerTxn);
                }
            }

            return true;
        }

        public bool IssueDocument(AppLazyContext lazyContext, IssuedDocumentType issuedDocumentType, TimeFormat travelDocumentTimeFormat, int invoiceId, int tripId = 0, int quoteNo = 0, int[] tripLineIds = null, int[] passengerIds = null) {
            if (issuedDocumentType == IssuedDocumentType.Invoice) {
                List<Invoice> invoices = null;

                if (invoiceId > 0) {
                    var invoice = lazyContext.Invoice.Find(invoiceId);

                    if (invoice != null)
                        invoices = new List<Invoice> { invoice };
                }
                else {
                    invoices = lazyContext.Invoice.Include(t1 => t1.InvoiceDetails).Include(t1 => t1.Debtor).Where(t1 => t1.InvoiceDetails.Any(t2 => t2.TripId == tripId)).ToList();
                }

                if (invoices == null || invoices.Count == 0)
                    throw new UnreportedException("No invoices have been created for this Trip.");

                using (var ts = Utils.CreateTransactionScope()) {
                    foreach (var invoice in invoices) {
                        invoice.IsIssued = true;
                        lazyContext.Save(invoice);

                        foreach (var row in invoice.InvoiceDetails.Where(t => t.TripId > 0).GroupBy(t => new { t.TripId })) {
                            TypeReportSource reportSource;

                            if (HttpContext.CustomerSettings().IsManagementCustomer) {
                                reportSource = AccountingDataSources.GetCustomerInvoiceReportSource(HttpContext.CurrentCustomerId(), invoice);
                            }
                            else {
                                reportSource = AccountingDataSources.GetInvoiceReportSource(lazyContext, HttpContext.CurrentCustomerId(), issuedDocumentType, travelDocumentTimeFormat, invoice.Id, tripId, quoteNo, string.Join(",", tripLineIds ?? new int[] { 0 }), string.Join(",", passengerIds ?? new int[] { 0 }), invoice.Debtor.IsTaxInInvoiceLineAmount, HttpContext.Now(), HttpContext.UserFullName(), DateTime.Today);
                            }

                            var result = Utils.ExportToPdf(reportSource);
                            var q = lazyContext.IssuedDocument.SingleOrDefault(t => t.IssuedDocumentType == issuedDocumentType && t.InvoiceId == invoice.Id && t.DebtorId == invoice.DebtorId && t.TripId == row.Key.TripId);

                            if (q != null)
                                continue;

                            q = new IssuedDocument {
                                Id = 0,
                                IssuedDocumentType = IssuedDocumentType.Invoice,
                                TripId = row.Key.TripId,
                                DebtorId = invoice.DebtorId,
                                CreditorId = -1,
                                ReceiptId = -1,
                                InvoiceId = invoice.Id,
                                VoucherId = -1,
                                Name = IssuedDocument.GetInvoiceName(invoice.InvoiceType, invoice.DocumentNo),
                                FileExtension = "pdf",
                                Document = result.DocumentBytes
                            };

                            lazyContext.Insert(q);
                        }
                    }

                    ts.Complete();
                }
            }
            else {
                TypeReportSource reportSource;

                if (HttpContext.CustomerSettings().IsManagementCustomer) {
                    reportSource = AccountingDataSources.GetCustomerInvoiceReportSource(HttpContext.CurrentCustomerId(), lazyContext.Invoice.Find(invoiceId));
                }
                else {
                    reportSource = AccountingDataSources.GetInvoiceReportSource(lazyContext, HttpContext.CurrentCustomerId(), issuedDocumentType, travelDocumentTimeFormat, -1, tripId, quoteNo, string.Join(",", tripLineIds ?? new int[] { 0 }), string.Join(",", passengerIds ?? new int[] { 0 }), false, HttpContext.Now(), HttpContext.UserFullName(), DateTime.Today);
                }

                var result = Utils.ExportToPdf(reportSource);

                string name = IssuedDocument.GetStatementName(lazyContext, tripId, quoteNo);

                var q = new IssuedDocument {
                    Id = 0,
                    IssuedDocumentType = issuedDocumentType,
                    TripId = tripId,
                    DebtorId = -1,
                    CreditorId = -1,
                    ReceiptId = -1,
                    InvoiceId = -1,
                    VoucherId = -1,
                    Name = name,
                    FileExtension = "pdf",
                    Document = result.DocumentBytes
                };

                lazyContext.Insert(q);
            }

            return true;
        }
    }

    public class InvoiceDetailCommon {
        private HttpContext HttpContext { get; }

        public InvoiceDetailCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool ValidateAndSave(AppLazyContext lazyContext, InvoiceDetail invoiceDetail, bool isNew, bool validateDocumentStatus = true, bool performRelatedUpdates = false, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow, int oldTripId = 0, int oldTripLineId = 0) {
            Validate(lazyContext, invoiceDetail, isNew, false, validateDocumentStatus);

            bool result;

            if (invoiceDetail.Id <= 0) {
                result = lazyContext.Insert(invoiceDetail);
            }
            else {
                result = lazyContext.Save(invoiceDetail);
            }

            if (!result && !performRelatedUpdates)
                return false;

            if (txnUpdateType == TransactionUpdateType.Bulk) {
                invoiceDetail.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                ;

                foreach (var tripLine in invoiceDetail.Invoice.InvoiceDetails.Where(t => t.TripLineId > 0).Select(t => t.TripLine).Distinct().ToList()) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }
            else if (txnUpdateType == TransactionUpdateType.SingleRow) {
                invoiceDetail.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, invoiceDetail.TripLine);
            }

            if (oldTripId > 0) {
                foreach (var tripLine in lazyContext.Trip.Find(oldTripId).TripLines.Where(t => t.Id > 0).ToList()) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }
            else if (oldTripLineId > 0) {
                var tripLine = lazyContext.TripLine.Find(oldTripLineId);
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (invoiceDetail.TripLineId <= 0 && invoiceDetail.Trip?.Id > 0)
                invoiceDetail.Trip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, InvoiceDetail invoiceDetail, bool isNew, bool validateDocumentStatus = true) {
            Validate(lazyContext, invoiceDetail, isNew, true, validateDocumentStatus);

            var tripLine = invoiceDetail.TripLine;

            if (invoiceDetail.TripLineId <= 0 && invoiceDetail.TripLine.TripId <= 0)
                invoiceDetail.TripLine.Trip = invoiceDetail.Trip;

            DeleteCustomerTransaction(lazyContext, invoiceDetail);

            if (lazyContext.Delete(invoiceDetail))
                return tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return false;
        }

        private void Validate(AppLazyContext lazyContext, InvoiceDetail invoiceDetail, bool isNew, bool isDeletion, bool validateDocumentStatus = true) {
            var invoice = invoiceDetail.Invoice;
            invoiceDetail.AvailableCredit = 0;

            if (!isDeletion) {
                int agencyId = invoiceDetail.Invoice.Debtor.AgencyId;

                if (agencyId <= 0 && invoiceDetail.Id <= 0)
                    agencyId = HttpContext.CurrentDefaultAgencyId();

                if (invoiceDetail.TripLineId > 0) {
                    var voucher = invoiceDetail.TripLine.Voucher;

                    if (voucher.PaymentClass == PaymentClass.PaidDirect)
                        throw new UnreportedException(string.Format("This Trip Line cannot be invoiced because a {0} voucher has been created for it.", voucher.VoucherType.GetEnumDescription()));
                }

                decimal availableCredit = 0;

                if (!invoice.Debtor.ValidateCreditLimit(lazyContext, TransactionType.Invoice, invoiceDetail.Id, agencyId, invoiceDetail.Amount + invoiceDetail.Tax - invoiceDetail.Discount - invoiceDetail.DiscountTax, ref availableCredit))
                    invoiceDetail.AvailableCredit = availableCredit;
            }

            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), invoice.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!isDeletion && invoiceDetail.TripId > 0 && !invoiceDetail.Trip.IsBooking)
                throw new UnreportedException(AppConstants.RecordIsNotBooking);

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !invoiceDetail.CanDelete(isNew, HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !invoiceDetail.CanEdit(isNew, HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public bool CreateOrUpdate(AppLazyContext lazyContext, InvoiceViewModel model, InvoiceDetailViewModel detailModel, bool isNew) {
            using (var ts = Utils.CreateTransactionScope()) {
                new InvoiceCommon(HttpContext).CreateOrUpdate(model, -1, !isNew, false, TransactionUpdateType.None);
                detailModel.InvoiceId = model.InvoiceId;
                CreateOrUpdate(detailModel, detailModel.InvoiceDetailIsTaxApplicable, model.InvoiceIsTaxIncluded, false, null, !isNew);

                if (isNew)
                    CreateOrUpdateCreditCardPayment(lazyContext, model.InvoiceId, model.InvoiceIsNew);

                ts.Complete();
                return true;
            }
        }

        public bool CreateOrUpdate(InvoiceDetailViewModel model, bool calculateTax, bool isTaxIncluded, bool isReissue = false, int[] passengerIds = null, bool validateDocumentStatus = true, TransactionUpdateType txnUpdateType = TransactionUpdateType.SingleRow) {
            if (model.InvoiceDetailTripLineType == TripLineType.Air && model.InvoiceDetailTripLineAirPassengerId <= 0)
                throw new UnreportedException("Passenger is required.");

            if ((model.InvoiceDetailSaleTypeId ?? 0) <= 0 && model.InvoiceDetailAccountType == AccountType.Client && !isReissue)
                throw new UnreportedException("Type of Sale is required.");

            if (model.InvoiceDetailTripLineId <= 0)
                model.InvoiceDetailTripLineAirPassengerId = -1;

            bool isNew = model.InvoiceDetailId <= 0;

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    var invoice = lazyContext.Invoice.Find(model.InvoiceId);
                    InvoiceDetail q = null;

                    if (isNew) {
                        q = new InvoiceDetail {
                            Id = 0,
                            DocumentStatus = isReissue ? model.InvoiceDetailDocumentStatus : invoice.IsMatched ? DocumentStatus.Closed : DocumentStatus.Open,
                            TripId = model.InvoiceDetailTripId ?? 0,
                            Trip = lazyContext.Trip.Find(model.InvoiceDetailTripId),
                            TripLineId = model.InvoiceDetailTripLineId ?? 0,
                            TripLine = lazyContext.TripLine.Find(model.InvoiceDetailTripLineId),
                            TripLineAirPassengerId = model.InvoiceDetailTripLineAirPassengerId ?? 0,
                            TripLineAirPassenger = lazyContext.TripLineAirPassenger.Find(model.InvoiceDetailTripLineAirPassengerId),
                            ChartOfAccountId = model.InvoiceDetailChartOfAccountId ?? 0,
                            ChartOfAccount = lazyContext.ChartOfAccount.Find(model.InvoiceDetailChartOfAccountId),
                            SaleTypeId = model.InvoiceDetailSaleTypeId ?? 0,
                            SaleType = lazyContext.SaleType.Find(model.InvoiceDetailSaleTypeId),
                            DiscountReasonId = model.InvoiceDetailDiscountReasonId ?? 0,
                            DiscountReason = lazyContext.DiscountReason.Find(model.InvoiceDetailDiscountReasonId),
                            CreditorId = model.InvoiceDetailCreditorId ?? 0,
                            Creditor = lazyContext.Creditor.Find(model.InvoiceDetailCreditorId),
                            SupplierId = model.InvoiceDetailSupplierId ?? 0,
                            Supplier = lazyContext.Supplier.Find(model.InvoiceDetailSupplierId),
                            AirlineId = model.InvoiceDetailAirlineId ?? 0,
                            Airline = lazyContext.Airline.Find(model.InvoiceDetailAirlineId),
                            PaymentTax = model.InvoiceDetailPaymentTax,
                            IsPayment = model.InvoiceDetailIsPayment,
                            Invoice = invoice
                        };
                    }
                    else {
                        q = lazyContext.InvoiceDetail.Find(model.InvoiceDetailId);
                    }

                    if (model.InvoiceDetailAmount == 0 && q.TripLine.PersonalTravelAmount == 0)
                        throw new UnreportedException(AppConstants.ZeroAmountWarning);

                    decimal discountTax = 0;
                    decimal tax = 0;
                    decimal discount = model.InvoiceDetailDiscount;
                    decimal amount = model.InvoiceDetailAmount;
                    decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), invoice.DocumentDate);

                    if (calculateTax) {
                        if (isTaxIncluded) {
                            discountTax = Math.Round(discount * taxRate / (1 + taxRate), 2);
                            tax = Math.Round(amount * taxRate / (1 + taxRate), 2);
                            discount -= discountTax;
                            amount -= tax;
                        }
                        else {
                            discountTax = Math.Round(discount * taxRate, 2);
                            tax = Math.Round(amount * taxRate, 2);
                        }
                    }
                    else {
                        discountTax = model.InvoiceDetailDiscountTax;
                        tax = model.InvoiceDetailTax;
                    }

                    int oldTripId = q.Id > 0 && q.TripId != model.InvoiceDetailTripId ? q.TripId : 0;
                    int oldTripLineId = q.Id > 0 && q.TripLineId != model.InvoiceDetailTripLineId ? q.TripLineId : 0;

                    q.AgencyId = HttpContext.CurrentDefaultAgencyId();

                    q.InvoiceId = model.InvoiceId;
                    q.TripId = model.InvoiceDetailTripId ?? 0;
                    q.TripLineId = model.InvoiceDetailTripLineId ?? 0;
                    q.TripLineAirPassengerId = model.InvoiceDetailTripLineAirPassengerId ?? 0;
                    q.ChartOfAccountId = model.InvoiceDetailChartOfAccountId ?? 0;
                    q.SaleTypeId = model.InvoiceDetailSaleTypeId ?? 0;
                    q.Amount = amount;
                    q.Tax = tax;
                    q.Discount = discount;
                    q.DiscountTax = discountTax;
                    q.DiscountReasonId = model.InvoiceDetailDiscountReasonId ?? 0;
                    q.CreditorId = model.InvoiceDetailCreditorId ?? 0;
                    q.SupplierId = model.InvoiceDetailSupplierId ?? 0;
                    q.AirlineId = model.InvoiceDetailAirlineId ?? 0;
                    q.DocumentNo = model.InvoiceDetailDocumentNo.ToStringExt();
                    q.ConfirmationNo = model.InvoiceDetailConfirmationNo.ToStringExt();
                    q.Description = model.InvoiceDetailDescription;

                    if (q.ChartOfAccountId > 0 && !ChartOfAccount.IsInRole(lazyContext, q.ChartOfAccountId, HttpContext.RoleId()))
                        throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                    bool result = ValidateAndSave(lazyContext, q, validateDocumentStatus, model.InvoiceDetailIsNew, true, txnUpdateType, oldTripId, oldTripLineId);

                    model.InvoiceDetailId = q.Id;
                    model.InvoiceDetailTotalAmount = q.InvoiceDetailTotalAmount;
                    model.InvoiceDetailIsTaxApplicable = q.IsTaxApplicable;
                    model.InvoiceDetailAvailableCredit = q.AvailableCredit;

                    if (isNew) {
                        if ((passengerIds == null || passengerIds.Length == 0) && q.TripLineId > 0)
                            passengerIds = q.TripLine.Trip.TripPassengers.Where(t => t.Id > 0).Select(t => t.Id).ToArray();

                        if (passengerIds != null && passengerIds.Length > 0) {
                            foreach (int passengerId in passengerIds) {
                                var invoiceDetailPassenger = new InvoiceDetailPassenger {
                                    Id = 0,
                                    InvoiceDetailId = q.Id,
                                    TripLineId = q.TripLineId,
                                    PassengerId = passengerId
                                };

                                lazyContext.Insert(invoiceDetailPassenger, false);
                            }
                        }
                    }

                    ts.Complete();
                    return result;
                }
            }
        }

        public bool CreateOrUpdateCreditCardPayment(AppLazyContext lazyContext, int invoiceId, bool isNew, decimal passengerRatio = 1, int[] passengerIds = null) {
            decimal amount = 0;
            decimal tax = 0;

            string description = string.Empty;

            var invoice = lazyContext.Invoice.Find(invoiceId);
            decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), invoice.DocumentDate);

            var tripLineIds = new List<int>();

            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var invoiceDetail in invoice.InvoiceDetails.Where(t => !t.IsPayment).ToList()) {
                    if (tripLineIds.Any(t => t == invoiceDetail.TripLineId))
                        continue;

                    tripLineIds.Add(invoiceDetail.TripLineId);

                    if (invoiceDetail.TripLine.TripLineType == TripLineType.Air) {
                        var tripLineAirPassengers = invoiceDetail.TripLine.TripLineAir.TripLineAirPassengers.Where(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard);

                        if (passengerIds != null && passengerIds.Length > 0)
                            tripLineAirPassengers = tripLineAirPassengers.Where(t => passengerIds.Contains(t.PassengerId));

                        foreach (var tripLineAirPassenger in tripLineAirPassengers) {
                            amount = tripLineAirPassenger.CreditCardAmount + tripLineAirPassenger.CreditCardNonCommissionable;
                            tax = 0;

                            if (amount == 0)
                                continue;

                            if (tripLineAirPassenger.SaleType.IsTaxApplicable) {
                                tax = amount * taxRate / (1 + taxRate);
                                amount -= tax;
                            }

                            description = tripLineAirPassenger.GetFormOfPaymentDetails(lazyContext);

                            var q = lazyContext.InvoiceDetail.SingleOrDefault(t => t.InvoiceId == invoiceId && t.TripLineId == invoiceDetail.TripLineId && t.TripLineAirPassengerId == tripLineAirPassenger.Id && t.IsPayment);

                            if (q == null) {
                                q = new InvoiceDetail {
                                    Id = 0,
                                    InvoiceId = invoiceId,
                                    AgencyId = invoiceDetail.AgencyId,
                                    DocumentStatus = DocumentStatus.Closed,
                                    TripId = invoiceDetail.TripLine.TripId,
                                    Trip = lazyContext.Trip.Find(invoiceDetail.TripLine.TripId),
                                    TripLineId = -1,
                                    TripLine = lazyContext.TripLine.Find(-1),
                                    TripLineAirPassengerId = -1,
                                    TripLineAirPassenger = lazyContext.TripLineAirPassenger.Find(-1),
                                    ChartOfAccountId = -1,
                                    ChartOfAccount = lazyContext.ChartOfAccount.Find(-1),
                                    SaleTypeId = -1,
                                    SaleType = lazyContext.SaleType.Find(-1),
                                    DiscountReasonId = -1,
                                    DiscountReason = lazyContext.DiscountReason.Find(-1),
                                    CreditorId = -1,
                                    Creditor = lazyContext.Creditor.Find(-1),
                                    SupplierId = -1,
                                    Supplier = lazyContext.Supplier.Find(-1),
                                    AirlineId = -1,
                                    Airline = lazyContext.Airline.Find(-1),
                                    DocumentNo = string.Empty,
                                    ConfirmationNo = string.Empty,
                                    IsPayment = true,
                                    Invoice = invoice
                                };
                            }
                            else if (q.TripLineId == invoiceDetail.TripLineId && q.TripLineAirPassengerId == tripLineAirPassenger.Id && q.Description == description && q.Amount == -amount && q.Tax == -tax) {
                                continue;
                            }

                            q.TripLineId = invoiceDetail.TripLineId;
                            q.TripLineAirPassengerId = tripLineAirPassenger.Id;
                            q.Description = description;
                            q.Amount = -amount;
                            q.PaymentTax = -tax;

                            ValidateAndSave(lazyContext, q, isNew, false, true);
                        }
                    }
                    else if (invoiceDetail.TripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
                        amount = (invoiceDetail.TripLine.CreditCardAmount + invoiceDetail.TripLine.CreditCardNonCommissionable) * passengerRatio;
                        tax = 0;

                        if (amount == 0)
                            continue;

                        if (invoiceDetail.TripLine.SaleType.IsTaxApplicable) {
                            tax = amount * taxRate / (1 + taxRate);
                            amount -= tax;
                        }

                        description = invoiceDetail.TripLine.GetFormOfPaymentDetails(lazyContext);

                        var q = lazyContext.InvoiceDetail.SingleOrDefault(t => t.InvoiceId == invoiceId && t.TripLineId == invoiceDetail.TripLineId && t.TripLineAirPassengerId <= 0 && t.IsPayment);

                        if (q == null) {
                            q = new InvoiceDetail {
                                Id = 0,
                                InvoiceId = invoiceId,
                                AgencyId = invoiceDetail.AgencyId,
                                DocumentStatus = DocumentStatus.Closed,
                                TripId = invoiceDetail.TripLine.TripId,
                                Trip = lazyContext.Trip.Find(invoiceDetail.TripLine.TripId),
                                TripLineId = -1,
                                TripLine = lazyContext.TripLine.Find(-1),
                                TripLineAirPassengerId = -1,
                                TripLineAirPassenger = lazyContext.TripLineAirPassenger.Find(-1),
                                ChartOfAccountId = -1,
                                ChartOfAccount = lazyContext.ChartOfAccount.Find(-1),
                                SaleTypeId = -1,
                                SaleType = lazyContext.SaleType.Find(-1),
                                DiscountReasonId = -1,
                                DiscountReason = lazyContext.DiscountReason.Find(-1),
                                CreditorId = -1,
                                Creditor = lazyContext.Creditor.Find(-1),
                                SupplierId = -1,
                                Supplier = lazyContext.Supplier.Find(-1),
                                AirlineId = -1,
                                Airline = lazyContext.Airline.Find(-1),
                                DocumentNo = string.Empty,
                                ConfirmationNo = string.Empty,
                                IsPayment = true,
                                Invoice = invoice
                            };
                        }
                        else if (q.TripLineId == invoiceDetail.TripLineId && q.Description == description && q.Amount == -amount && q.Tax == -tax) {
                            continue;
                        }

                        q.TripLineId = invoiceDetail.TripLineId;
                        q.Description = description;
                        q.Amount = -amount;
                        q.PaymentTax = -tax;

                        ValidateAndSave(lazyContext, q, isNew, false, true);
                    }
                }

                ts.Complete();
            }

            return true;
        }

        public bool Delete(AppLazyContext lazyContext, InvoiceDetailViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.InvoiceDetail.Find(model.InvoiceDetailId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (q.Invoice.InvoiceDetails.Count == 1)
                    throw new UnreportedException(AppConstants.RecordCannotBeDeleted);

                ValidateAndDelete(lazyContext, q, model.InvoiceDetailIsNew);

                ts.Complete();
                return true;
            }
        }

        private bool DeleteCustomerTransaction(AppLazyContext lazyContext, InvoiceDetail invoiceDetail) {
            var invoice = invoiceDetail.Invoice;

            if (invoice.Debtor?.CustomerId == 0 || invoice.AccountType != AccountType.GeneralLedger)
                return false;

            using (var adminContext = new AppAdminContext(HttpContext.User)) {
                int[] groupNos = lazyContext.TransactionDetailAllocation.Where(t => t.InvoiceDetailId == invoiceDetail.Id).Select(t => t.GroupNo).Distinct().ToArray();
                lazyContext.RemoveRange(lazyContext.TransactionDetailAllocation.Where(t => groupNos.Contains(t.GroupNo)));
                lazyContext.SaveChanges();

                var customerTxn = adminContext.CustomerTransaction.Find(invoiceDetail.CustomerTransactionId);

                if (customerTxn != null)
                    adminContext.Delete(customerTxn);
            }

            return false;
        }
    }

    public class JournalCommon {
        private HttpContext HttpContext { get; }

        public JournalCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool ValidateAndSave(AppLazyContext lazyContext, Journal journal, bool postJournal, bool validateDocumentStatus = true) {
            Validate(journal, false, validateDocumentStatus);

            if (postJournal)
                journal.DocumentStatus = DocumentStatus.Closed;

            if (journal.Id <= 0) {
                lazyContext.Insert(journal);
            }
            else {
                lazyContext.Save(journal);
            }

            if (postJournal) {
                if (journal.JournalDetails.Sum(t => t.SignType == SignType.Debit ? t.Amount : -t.Amount) != 0)
                    throw new UnreportedException("Journal balance must be zero before it can be posted.");

                journal.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                ;
            }

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, Journal journal, bool validateDocumentStatus = true) {
            Validate(journal, true, validateDocumentStatus);

            if (HttpContext.IsSuperUser()) {
                int[] journalDetailIds = journal.JournalDetails.Select(t => t.Id).ToArray();

                lazyContext.RemoveRange(lazyContext.TransactionDetail.Where(t => journalDetailIds.Contains(t.JournalDetailId)).SelectMany(t => t.TransactionDetailAllocations));
                lazyContext.SaveChanges();

                lazyContext.RemoveRange(lazyContext.TransactionDetailAllocation.Where(t => journalDetailIds.Contains(t.JournalDetailId)));
                lazyContext.SaveChanges();
            }

            lazyContext.RemoveRange(journal.Transactions);
            lazyContext.SaveChanges();

            var tripLines = journal.JournalDetails.SelectMany(t => t.Trip.TripLines).Where(t => t.Id > 0).Distinct().ToList();

            if (!lazyContext.Delete(journal))
                return false;

            foreach (var tripLine in tripLines) {
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            return true;
        }

        private void Validate(Journal journal, bool isDeletion, bool validateDocumentStatus = true) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), journal.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !journal.CanDelete(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !journal.CanEdit(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public bool CreateOrUpdate(AppLazyContext lazyContext, JournalViewModel model, bool postJournal, bool validateDocumentStatus = true) {
            using (var ts = Utils.CreateTransactionScope()) {
                Journal q = null;

                if (model.JournalId <= 0) {
                    q = new Journal {
                        Id = 0,
                        DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Journal"),
                        DocumentStatus = DocumentStatus.Open
                    };

                    LastDocumentNo.DocumentNo(lazyContext, "Journal", q.DocumentNo);
                }
                else {
                    q = lazyContext.Journal.Find(model.JournalId);
                }

                q.DocumentDate = model.JournalDocumentDate ?? DateTime.MinValue;

                bool result = ValidateAndSave(lazyContext, q, postJournal, validateDocumentStatus);
                model.JournalId = q.Id;

                ts.Complete();
                return result;
            }
        }

        public bool Delete(AppLazyContext lazyContext, JournalViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.Journal.Include(t => t.Transactions).Single(t => t.Id == model.JournalId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }

        public bool Reverse(AppLazyContext lazyContext, int journalId, string type) {
            using (var ts = Utils.CreateTransactionScope()) {
                var journal = lazyContext.Journal.Find(journalId);

                if (!journal.CanReverse())
                    throw new UnreportedException(AppConstants.RecordCannotBeReversed);

                if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), journal.DocumentDate, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                if (type == "CurrentDate" && !Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                var journalClone = journal.Clone() as Journal;

                journalClone.Id = 0;
                journalClone.DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Journal");
                journalClone.DocumentStatus = DocumentStatus.Closed;
                journalClone.ReversalStatus = ReversalStatus.Reversal;

                LastDocumentNo.DocumentNo(lazyContext, "Journal", journalClone.DocumentNo);

                if (type == "CurrentDate")
                    journalClone.DocumentDate = DateTime.Today;

                ValidateAndSave(lazyContext, journalClone, false, false);
                journal.UpdateReversalStatus(lazyContext, ReversalStatus.Reversed);

                foreach (var journalDetail in journal.JournalDetails) {
                    var journalDetailClone = journalDetail.Clone() as JournalDetail;
                    journalDetailClone.Id = 0;
                    journalDetailClone.JournalId = journalClone.Id;
                    journalDetailClone.Amount = -journalDetailClone.Amount;
                    journalDetailClone.Commission = -journalDetailClone.Commission;
                    journalDetailClone.CommissionTax = -journalDetailClone.CommissionTax;
                    lazyContext.Insert(journalDetailClone, false);
                }

                lazyContext.Entry(journalClone).State = EntityState.Detached;
                journalClone = lazyContext.Journal.Find(journalClone.Id);

                journalClone.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                ;

                ts.Complete();
                return true;
            }
        }
    }

    public class JournalDetailCommon {
        private HttpContext HttpContext { get; }

        public JournalDetailCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool ValidateAndSave(AppLazyContext lazyContext, JournalDetail journalDetail, bool postJournal, bool validateDocumentStatus = true, int oldTripId = 0) {
            Validate(lazyContext, journalDetail, false, validateDocumentStatus);

            bool result;

            if (journalDetail.Id <= 0) {
                result = lazyContext.Insert(journalDetail);
            }
            else {
                result = lazyContext.Save(journalDetail);
            }

            if (postJournal)
                journalDetail.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            ;

            if (result && oldTripId > 0) {
                foreach (var tripLine in lazyContext.Trip.Find(oldTripId).TripLines) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, JournalDetail journalDetail, bool validateDocumentStatus = true) {
            Validate(lazyContext, journalDetail, true, validateDocumentStatus);

            var tripLines = journalDetail.Trip.TripLines.Where(t => t.Id > 0).Distinct().ToList();

            if (!lazyContext.Delete(journalDetail))
                return false;

            foreach (var tripLine in tripLines) {
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            return true;
        }

        public void Validate(AppLazyContext lazyContext, JournalDetail journalDetail, bool isDeletion, bool validateDocumentStatus = true) {
            if (!isDeletion && journalDetail.AccountType == AccountType.Debtor) {
                int agencyId = journalDetail.AgencyId;

                if (agencyId <= 0 && journalDetail.Id <= 0)
                    agencyId = HttpContext.CurrentDefaultAgencyId();

                var debtor = journalDetail.Debtor.BillingHeadDebtor;

                if (debtor.Id > 0)
                    debtor.ValidateCreditLimit(lazyContext, TransactionType.Journal, journalDetail.Id, agencyId, journalDetail.Amount);
            }

            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), journalDetail.Journal.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !journalDetail.CanDelete(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !journalDetail.CanEdit(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public bool CreateOrUpdate(AppLazyContext lazyContext, JournalDetailViewModel model, bool postJournal, bool validateDocumentStatus = true) {
            if (model.JournalDetailAmount == 0)
                throw new UnreportedException(AppConstants.ZeroAmountWarning);

            using (var ts = Utils.CreateTransactionScope()) {
                int tripId = -1;
                int debtorId = -1;
                int creditorId = -1;
                int chartOfAccountId = -1;

                switch (model.JournalDetailAccountType) {
                    case AccountType.Client:
                        tripId = model.JournalDetailTripId ?? 0;
                        break;
                    case AccountType.Debtor:
                        debtorId = model.JournalDetailDebtorId ?? 0;
                        break;
                    case AccountType.Creditor:
                        creditorId = model.JournalDetailCreditorId ?? 0;
                        break;
                    case AccountType.GeneralLedger:
                        chartOfAccountId = model.JournalDetailChartOfAccountId ?? 0;
                        break;
                }

                JournalDetail q = null;

                if (model.JournalDetailId > 0) {
                    q = lazyContext.JournalDetail.Find(model.JournalDetailId);

                    if (q.AccountType != model.JournalDetailAccountType) {
                        lazyContext.Delete(q, false);
                        model.JournalDetailId = 0;
                    }
                }

                if (model.JournalDetailId <= 0) {
                    q = new JournalDetail {
                        Id = 0,
                        Journal = lazyContext.Journal.Find(model.JournalId)
                    };
                }

                int oldTripId = q.Id > 0 && q.TripId != tripId ? q.TripId : 0;

                q.AgencyId = HttpContext.CurrentDefaultAgencyId();

                q.JournalId = model.JournalId;
                q.AccountType = model.JournalDetailAccountType;
                q.TripId = tripId;
                q.DebtorId = debtorId;
                q.CreditorId = creditorId;
                q.ChartOfAccountId = chartOfAccountId;
                q.SignType = model.JournalDetailSignType;
                q.Amount = model.JournalDetailAmount;
                q.Comments = model.JournalDetailComments.ToStringExt();

                if (model.JournalDetailId <= 0) {
                    q.Trip = lazyContext.Trip.Find(tripId);
                    q.Debtor = lazyContext.Debtor.Find(debtorId);
                    q.Creditor = lazyContext.Creditor.Find(creditorId);
                    q.ChartOfAccount = lazyContext.ChartOfAccount.Find(chartOfAccountId);
                }

                if (q.ChartOfAccountId > 0 && !ChartOfAccount.IsInRole(lazyContext, q.ChartOfAccountId, HttpContext.RoleId()))
                    throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                bool result = ValidateAndSave(lazyContext, q, validateDocumentStatus);

                model.JournalDetailId = q.Id;
                model.JournalDetailListAmount = model.JournalDetailAmount;

                new JournalCommon(HttpContext).ValidateAndSave(lazyContext, q.Journal, postJournal);

                ts.Complete();
                return result;
            }
        }

        public bool CreateOrUpdate(AppLazyContext lazyContext, JournalViewModel model, JournalDetailViewModel detailModel, bool isNew, bool postJournal) {
            using (var ts = Utils.CreateTransactionScope()) {
                new JournalCommon(HttpContext).CreateOrUpdate(lazyContext, model, false, !isNew);
                detailModel.JournalId = model.JournalId;
                CreateOrUpdate(lazyContext, detailModel, postJournal);
                ts.Complete();
                return true;
            }
        }

        public bool Delete(AppLazyContext lazyContext, JournalDetailViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.JournalDetail.Find(model.JournalDetailId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (q.Journal.JournalDetails.Count == 1)
                    throw new UnreportedException(AppConstants.RecordCannotBeDeleted);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }
    }

    public class AdjustmentCommon {
        private HttpContext HttpContext { get; }

        public AdjustmentCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        private bool ValidateAndSave(AppLazyContext lazyContext, Adjustment adjustment, bool validateDocumentStatus = true, bool performRelatedUpdates = false, int oldDebitTripId = 0, int oldCreditTripId = 0, int oldDebitTripLineId = 0, int oldCreditTripLineId = 0) {
            Validate(lazyContext, adjustment, false, validateDocumentStatus);

            bool result;

            if (adjustment.Id <= 0) {
                result = lazyContext.Insert(adjustment);
            }
            else {
                result = lazyContext.Save(adjustment);
            }

            if (!result && !performRelatedUpdates)
                return false;

            if (adjustment.DebitType == DebitCreditType.Client && adjustment.DebitTripLine.TripLineType == TripLineType.ServiceFee && string.IsNullOrEmpty(adjustment.DebitTripLine.TripLineServiceFee.DocumentNo)) {
                adjustment.DebitTripLine.TripLineServiceFee.DocumentNo = adjustment.DocumentNo;
                lazyContext.Save(adjustment.DebitTripLine.TripLineServiceFee);
            }

            if (adjustment.CreditType == DebitCreditType.Client && adjustment.CreditTripLine.TripLineType == TripLineType.ServiceFee && string.IsNullOrEmpty(adjustment.CreditTripLine.TripLineServiceFee.DocumentNo)) {
                adjustment.CreditTripLine.TripLineServiceFee.DocumentNo = adjustment.DocumentNo;
                lazyContext.Save(adjustment.CreditTripLine.TripLineServiceFee);
            }

            adjustment.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext, adjustment.DebitTripLine);

            if (oldDebitTripId > 0) {
                foreach (var tripLine in lazyContext.Trip.Find(oldDebitTripId).TripLines) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }
            else if (oldDebitTripLineId > 0) {
                var tripLine = lazyContext.TripLine.Find(oldDebitTripLineId);
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (oldCreditTripId > 0) {
                foreach (var tripLine in lazyContext.Trip.Find(oldCreditTripId).TripLines) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }
            else if (oldCreditTripLineId > 0) {
                var tripLine = lazyContext.TripLine.Find(oldCreditTripLineId);
                tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (adjustment.DebitTripLine?.Id > 0) {
                adjustment.DebitTripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }
            else if (adjustment.DebitTrip?.Id > 0) {
                adjustment.DebitTrip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            if (adjustment.CreditTripLine?.Id > 0) {
                adjustment.CreditTripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }
            else if (adjustment.CreditTrip?.Id > 0) {
                adjustment.CreditTrip.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            return true;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, Adjustment adjustment, bool validateDocumentStatus = true) {
            Validate(lazyContext, adjustment, true, validateDocumentStatus);

            lazyContext.RemoveRange(adjustment.Transactions);
            lazyContext.SaveChanges();

            var debitTripLine = adjustment.DebitTripLine;
            var creditTripLine = adjustment.CreditTripLine;

            if (lazyContext.Delete(adjustment)) {
                debitTripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                creditTripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
            }

            return true;
        }

        private void Validate(AppLazyContext lazyContext, Adjustment adjustment, bool isDeletion, bool validateDocumentStatus = true) {
            if (!isDeletion) {
                int agencyId = adjustment.DebitAgencyId;

                if (agencyId <= 0 && adjustment.Id <= 0)
                    agencyId = HttpContext.CurrentDefaultAgencyId();

                if (adjustment.DebitDebtorId > 0) {
                    var debtor = adjustment.DebitDebtor.BillingHeadDebtor;

                    if (debtor.Id > 0)
                        debtor.ValidateCreditLimit(lazyContext, TransactionType.Adjustment, adjustment.Id, agencyId, adjustment.Amount);
                }

                if (adjustment.CreditDebtorId > 0) {
                    var debtor = adjustment.CreditDebtor.BillingHeadDebtor;

                    if (debtor.Id > 0)
                        debtor.ValidateCreditLimit(lazyContext, TransactionType.Adjustment, adjustment.Id, agencyId, adjustment.Amount);
                }
            }

            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), adjustment.DocumentDate, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if (!validateDocumentStatus)
                return;

            if (isDeletion && !adjustment.CanDelete(HttpContext.IsAdministrator(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !adjustment.CanEdit(HttpContext.IsAdministrator(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public bool CreateOrUpdate(AppLazyContext lazyContext, AdjustmentViewModel model, bool validateDocumentStatus = true) {
            if (model.AdjustmentDebitType == model.AdjustmentCreditType && ((model.AdjustmentDebitType == DebitCreditType.Client && model.AdjustmentDebitTripId == model.AdjustmentCreditTripId && model.AdjustmentDebitTripLineId == model.AdjustmentCreditTripLineId) || (model.AdjustmentDebitType == DebitCreditType.Debtor && model.AdjustmentDebitDebtorId == model.AdjustmentCreditDebtorId) || (model.AdjustmentDebitType == DebitCreditType.Creditor && model.AdjustmentDebitCreditorId == model.AdjustmentCreditCreditorId) || (model.AdjustmentDebitType == DebitCreditType.Debtor && model.AdjustmentDebitChartOfAccountId == model.AdjustmentCreditChartOfAccountId)))
                throw new UnreportedException("Debit and Credit accounts cannot be the same.");

            if (model.AdjustmentAmount == 0)
                throw new UnreportedException(AppConstants.ZeroAmountWarning);

            var adjustmentType = lazyContext.AdjustmentType.Find(model.AdjustmentTypeId);

            if (!adjustmentType.IsDebitAccountUnlocked && adjustmentType.DebitType != model.AdjustmentDebitType)
                throw new UnreportedException("Debit Type is invalid.");

            if (!adjustmentType.IsCreditAccountUnlocked && adjustmentType.CreditType != model.AdjustmentCreditType)
                throw new UnreportedException("Credit Type is invalid.");

            switch (model.AdjustmentDebitType) {
                case DebitCreditType.Client:
                    model.AdjustmentDebitDebtorId = -1;
                    model.AdjustmentDebitChartOfAccountId = -1;
                    model.AdjustmentDebitCreditorId = -1;
                    break;
                case DebitCreditType.Debtor:
                    model.AdjustmentDebitTripId = -1;
                    model.AdjustmentDebitTripLineId = -1;
                    model.AdjustmentDebitChartOfAccountId = -1;
                    model.AdjustmentDebitCreditorId = -1;
                    break;
                case DebitCreditType.Creditor:
                    model.AdjustmentDebitTripId = -1;
                    model.AdjustmentDebitTripLineId = -1;
                    model.AdjustmentDebitDebtorId = -1;
                    model.AdjustmentDebitChartOfAccountId = -1;
                    break;
                case DebitCreditType.GeneralLedger:
                    model.AdjustmentDebitTripId = -1;
                    model.AdjustmentDebitTripLineId = -1;
                    model.AdjustmentDebitDebtorId = -1;
                    model.AdjustmentDebitCreditorId = -1;
                    break;
            }

            switch (model.AdjustmentCreditType) {
                case DebitCreditType.Client:
                    model.AdjustmentCreditDebtorId = -1;
                    model.AdjustmentCreditChartOfAccountId = -1;
                    model.AdjustmentCreditCreditorId = -1;
                    break;
                case DebitCreditType.Debtor:
                    model.AdjustmentCreditTripId = -1;
                    model.AdjustmentCreditTripLineId = -1;
                    model.AdjustmentCreditChartOfAccountId = -1;
                    model.AdjustmentCreditCreditorId = -1;
                    break;
                case DebitCreditType.Creditor:
                    model.AdjustmentCreditTripId = -1;
                    model.AdjustmentCreditTripLineId = -1;
                    model.AdjustmentCreditDebtorId = -1;
                    model.AdjustmentCreditChartOfAccountId = -1;
                    break;
                case DebitCreditType.GeneralLedger:
                    model.AdjustmentCreditTripId = -1;
                    model.AdjustmentCreditTripLineId = -1;
                    model.AdjustmentCreditDebtorId = -1;
                    model.AdjustmentCreditCreditorId = -1;
                    break;
            }

            if (model.AdjustmentDebitChartOfAccountId > 0 && model.AdjustmentCreditChartOfAccountId > 0)
                throw new UnreportedException("Adjustments cannot be made between two GL accounts.");

            using (var ts = Utils.CreateTransactionScope()) {
                Adjustment q = null;

                if (model.AdjustmentId <= 0) {
                    q = new Adjustment {
                        Id = 0,
                        DocumentStatus = DocumentStatus.Open,
                        ReversalStatus = ReversalStatus.None,
                        DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Adjustment"),
                        DocumentDate = model.AdjustmentDocumentDate ?? DateTime.MinValue,
                        AdjustmentTypeId = adjustmentType.Id,
                        AdjustmentType = adjustmentType,

                        SupplierId = model.AdjustmentSupplierId ?? 0,
                        Supplier = lazyContext.Supplier.Find(model.AdjustmentSupplierId),

                        DebitTripId = model.AdjustmentDebitTripId ?? 0,
                        DebitTrip = lazyContext.Trip.Find(model.AdjustmentDebitTripId),
                        CreditTripId = model.AdjustmentCreditTripId ?? 0,
                        CreditTrip = lazyContext.Trip.Find(model.AdjustmentCreditTripId),

                        DebitTripLineId = model.AdjustmentDebitTripLineId ?? 0,
                        DebitTripLine = lazyContext.TripLine.Find(model.AdjustmentDebitTripLineId),
                        CreditTripLineId = model.AdjustmentCreditTripLineId ?? 0,
                        CreditTripLine = lazyContext.TripLine.Find(model.AdjustmentCreditTripLineId),

                        DebitDebtorId = model.AdjustmentDebitDebtorId ?? 0,
                        DebitDebtor = lazyContext.Debtor.Find(model.AdjustmentDebitDebtorId),
                        CreditDebtorId = model.AdjustmentCreditDebtorId ?? 0,
                        CreditDebtor = lazyContext.Debtor.Find(model.AdjustmentCreditDebtorId),

                        DebitCreditorId = model.AdjustmentDebitCreditorId ?? 0,
                        DebitCreditor = lazyContext.Creditor.Find(model.AdjustmentDebitCreditorId),
                        CreditCreditorId = model.AdjustmentCreditDebtorId ?? 0,
                        CreditCreditor = lazyContext.Creditor.Find(model.AdjustmentCreditCreditorId),

                        DebitChartOfAccountId = model.AdjustmentDebitChartOfAccountId ?? 0,
                        DebitChartOfAccount = lazyContext.ChartOfAccount.Find(model.AdjustmentDebitChartOfAccountId),
                        CreditChartOfAccountId = model.AdjustmentCreditChartOfAccountId ?? 0,
                        CreditChartOfAccount = lazyContext.ChartOfAccount.Find(model.AdjustmentCreditChartOfAccountId),

                        SaleTypeId = model.AdjustmentSaleTypeId ?? 0,
                        SaleType = lazyContext.SaleType.Find(model.AdjustmentSaleTypeId),
                        GroupId = model.AdjustmentGroupId ?? 0,
                        Group = lazyContext.Group.Find(model.AdjustmentGroupId),
                        SourceId = model.AdjustmentSourceId ?? 0,
                        Source = lazyContext.Source.Find(model.AdjustmentSourceId),
                        CategoryId = model.AdjustmentCategoryId ?? 0,
                        Category = lazyContext.Category.Find(model.AdjustmentCategoryId),
                        DestinationId = model.AdjustmentDestinationId ?? 0,
                        Destination = lazyContext.Destination.Find(model.AdjustmentDestinationId),
                        AgentId = model.AdjustmentAgentId ?? 0,
                        Agent = lazyContext.Agent.Find(model.AdjustmentAgentId)
                    };

                    LastDocumentNo.DocumentNo(lazyContext, "Adjustment", q.DocumentNo);
                }
                else {
                    q = lazyContext.Adjustment.Find(model.AdjustmentId);
                }

                bool raiseDebitError = false;
                bool raiseCreditError = false;

                if (!q.AdjustmentType.IsDebitAccountUnlocked) {
                    switch (model.AdjustmentDebitType) {
                        case DebitCreditType.Client:
                            if (model.AdjustmentDebitTripId != adjustmentType.DebitTripId && adjustmentType.DebitTripId > 0)
                                raiseDebitError = true;

                            break;
                        case DebitCreditType.Debtor:
                            if (model.AdjustmentDebitDebtorId != adjustmentType.DebitDebtorId && adjustmentType.DebitDebtorId > 0)
                                raiseDebitError = true;

                            break;
                        case DebitCreditType.Creditor:
                            if (model.AdjustmentDebitCreditorId != adjustmentType.DebitCreditorId && adjustmentType.DebitCreditorId > 0)
                                raiseDebitError = true;

                            break;
                        case DebitCreditType.GeneralLedger:
                            if (model.AdjustmentDebitChartOfAccountId != adjustmentType.DebitChartOfAccountId && adjustmentType.DebitChartOfAccountId > 0)
                                raiseDebitError = true;

                            break;
                    }
                }

                if (!q.AdjustmentType.IsCreditAccountUnlocked) {
                    switch (model.AdjustmentCreditType) {
                        case DebitCreditType.Client:
                            if (model.AdjustmentCreditTripId != adjustmentType.CreditTripId && adjustmentType.CreditTripId > 0)
                                raiseCreditError = true;

                            break;
                        case DebitCreditType.Debtor:
                            if (model.AdjustmentCreditDebtorId != adjustmentType.CreditDebtorId && adjustmentType.CreditDebtorId > 0)
                                raiseCreditError = true;

                            break;
                        case DebitCreditType.Creditor:
                            if (model.AdjustmentCreditCreditorId != adjustmentType.CreditCreditorId && adjustmentType.CreditCreditorId > 0)
                                raiseCreditError = true;

                            break;
                        case DebitCreditType.GeneralLedger:
                            if (model.AdjustmentCreditChartOfAccountId != adjustmentType.CreditChartOfAccountId && adjustmentType.CreditChartOfAccountId > 0)
                                raiseCreditError = true;

                            break;
                    }
                }

                if (raiseDebitError)
                    throw new UnreportedException("The selected Adjustment Type does not permit changes to the Debit Account.");

                if (raiseCreditError)
                    throw new UnreportedException("The selected Adjustment Type does not permit changes to the Credit Account.");

                if (q.AdjustmentType.AdjustmentTransactionType != AdjustmentTransactionType.None) {
                    if (model.AdjustmentSaleTypeId <= 0 || model.AdjustmentCategoryId <= 0 || model.AdjustmentDestinationId <= 0 || model.AdjustmentConsultantId <= 0 || model.AdjustmentSourceId <= 0)
                        throw new UnreportedException("Type of Sale, Source, Category, Destination and Consultant are required when transaction updates apply to the selected Adjustment Type.");
                }
                else if (model.AdjustmentSaleTypeId > 0 && model.AdjustmentDebitType == DebitCreditType.Client && model.AdjustmentCreditType == DebitCreditType.Client) {
                    model.AdjustmentSaleTypeId = -1;
                }

                int oldDebitTripId = q.Id > 0 && q.DebitTripId != model.AdjustmentDebitTripId ? q.DebitTripId : 0;
                int oldCreditTripId = q.Id > 0 && q.CreditTripId != model.AdjustmentCreditTripId ? q.CreditTripId : 0;

                int oldDebitTripLineId = q.Id > 0 && q.DebitTripLineId != model.AdjustmentDebitTripLineId ? q.DebitTripLineId : 0;
                int oldCreditTripLineId = q.Id > 0 && q.CreditTripLineId != model.AdjustmentCreditTripLineId ? q.CreditTripLineId : 0;

                q.DebitAgencyId = HttpContext.CurrentDefaultAgencyId();
                q.CreditAgencyId = -1;

                q.AdjustmentTypeId = model.AdjustmentTypeId ?? 0;
                q.DocumentDate = model.AdjustmentDocumentDate ?? DateTime.MinValue;
                q.DebitType = model.AdjustmentDebitType;
                q.DebitTripId = model.AdjustmentDebitTripId ?? 0;
                q.DebitTripLineId = model.AdjustmentDebitTripLineId ?? 0;
                q.DebitDebtorId = model.AdjustmentDebitDebtorId ?? 0;
                q.DebitCreditorId = model.AdjustmentDebitCreditorId ?? 0;
                q.DebitChartOfAccountId = model.AdjustmentDebitChartOfAccountId ?? 0;
                q.CreditType = model.AdjustmentCreditType;
                q.CreditTripId = model.AdjustmentCreditTripId ?? 0;
                q.CreditTripLineId = model.AdjustmentCreditTripLineId ?? 0;
                q.CreditDebtorId = model.AdjustmentCreditDebtorId ?? 0;
                q.CreditCreditorId = model.AdjustmentCreditCreditorId ?? 0;
                q.CreditChartOfAccountId = model.AdjustmentCreditChartOfAccountId ?? 0;
                q.SupplierId = model.AdjustmentSupplierId ?? 0;
                q.SaleTypeId = model.AdjustmentSaleTypeId ?? 0;
                q.GroupId = model.AdjustmentGroupId ?? 0;
                q.CategoryId = model.AdjustmentCategoryId ?? 0;
                q.DestinationId = model.AdjustmentDestinationId ?? 0;
                q.ConsultantId = model.AdjustmentConsultantId ?? 0;
                q.AgentId = model.AdjustmentAgentId ?? 0;
                q.SourceId = model.AdjustmentSourceId ?? 0;
                q.Amount = model.AdjustmentAmount;
                q.Tax = q.GetTax(HttpContext.CurrentCustomerId());
                q.Amount -= q.Tax;
                q.Comments = model.AdjustmentComments.ToStringExt();

                if ((q.DebitChartOfAccountId > 0 && !ChartOfAccount.IsInRole(lazyContext, q.DebitChartOfAccountId, HttpContext.RoleId())) || (q.CreditChartOfAccountId > 0 && !ChartOfAccount.IsInRole(lazyContext, q.CreditChartOfAccountId, HttpContext.RoleId())))
                    throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                bool result = ValidateAndSave(lazyContext, q, validateDocumentStatus, false, oldDebitTripId, oldCreditTripId, oldDebitTripLineId, oldCreditTripLineId);
                model.AdjustmentId = q.Id;

                ts.Complete();
                return result;
            }
        }

        public bool Delete(AppLazyContext lazyContext, AdjustmentViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.Adjustment.Find(model.AdjustmentId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }

        public bool ProcessSelections(AppLazyContext lazyContext, int[] adjustmentIds) {
            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var adjustment in lazyContext.Adjustment.Where(t => adjustmentIds.Contains(t.Id))) {
                    Validate(lazyContext, adjustment, false);

                    string message = null;

                    if (adjustment.Amount == 0)
                        message = string.Format("Document No {0}: {1}", adjustment.DocumentNo, AppConstants.ZeroAmountWarning);

                    if (!string.IsNullOrEmpty(message))
                        throw new UnreportedException(message);

                    adjustment.DocumentStatus = DocumentStatus.Closed;
                    ValidateAndSave(lazyContext, adjustment, false);
                }

                ts.Complete();
                return true;
            }
        }

        public bool Reverse(AppLazyContext lazyContext, int adjustmentId, string type) {
            using (var ts = Utils.CreateTransactionScope()) {
                var adjustment = lazyContext.Adjustment.Find(adjustmentId);

                if (!adjustment.CanReverse())
                    throw new UnreportedException(AppConstants.RecordCannotBeReversed);

                if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), adjustment.DocumentDate, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                if (type == "CurrentDate" && !Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                adjustment.UpdateReversalStatus(lazyContext, ReversalStatus.Reversed);
                var adjustmentClone = adjustment.Clone() as Adjustment;

                adjustmentClone.Id = 0;
                adjustmentClone.DocumentStatus = DocumentStatus.Open;
                adjustmentClone.ReversalStatus = ReversalStatus.Reversal;

                adjustmentClone.DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Adjustment");
                LastDocumentNo.DocumentNo(lazyContext, "Adjustment", adjustmentClone.DocumentNo);

                adjustmentClone.Comments = string.Format("Reversal of Document No {0}.", adjustment.DocumentNo);

                if (type == "CurrentDate")
                    adjustmentClone.DocumentDate = DateTime.Today;

                adjustmentClone.Amount = -adjustmentClone.Amount;
                adjustmentClone.Tax = -adjustmentClone.Tax;

                lazyContext.Insert(adjustmentClone);
                Validate(lazyContext, adjustmentClone, false, false);

                lazyContext.Entry(adjustmentClone).State = EntityState.Detached;
                adjustmentClone = lazyContext.Adjustment.Find(adjustmentClone.Id);

                adjustmentClone.UpdateTransactions(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                ;

                if (adjustmentClone.DebitTripLineId > 0)
                    adjustmentClone.DebitTripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                if (adjustmentClone.CreditTripLineId > 0)
                    adjustmentClone.CreditTripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                ts.Complete();
                return true;
            }
        }
    }

    public class VoucherCommon {
        private HttpContext HttpContext { get; }

        public VoucherCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        private bool ValidateAndSave(AppLazyContext lazyContext, Voucher voucher, bool performRelatedUpdates = false) {
            Validate(lazyContext, voucher, false);
            bool result;

            if (voucher.Id <= 0) {
                result = lazyContext.Insert(voucher);
            }
            else {
                result = lazyContext.Save(voucher);
            }

            if (result || performRelatedUpdates)
                return voucher.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return false;
        }

        public bool ValidateAndDelete(AppLazyContext lazyContext, Voucher voucher) {
            Validate(lazyContext, voucher, true);

            if (HttpContext.IsSuperUser()) {
                lazyContext.RemoveRange(voucher.IssuedDocuments);
                lazyContext.SaveChanges();
            }

            var tripLine = voucher.TripLine;

            if (lazyContext.Delete(voucher))
                return tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

            return false;
        }

        public void Validate(AppLazyContext lazyContext, Voucher voucher, bool isDeletion) {
            if (!isDeletion && voucher.Trip.DebtorId > 0) {
                var tripLine = voucher.TripLine;

                if (tripLine.AmountInvoiced > 0 || (tripLine.AmountPaid > 0 && tripLine.AmountPaid == tripLine.AmountPayable)) {
                    if (voucher.PaymentClass == PaymentClass.PaidDirect)
                        throw new UnreportedException(string.Format("A {0} voucher cannot be created because the Trip Line has already been invoiced or paid.", voucher.VoucherType.GetEnumDescription()));
                }
                else if (voucher.VoucherType == VoucherType.PrePaid || voucher.VoucherType == VoucherType.Billback) {
                    voucher.Trip.Debtor.ValidateCreditLimit(lazyContext, TransactionType.All, 0, HttpContext.CurrentDefaultAgencyId(), voucher.Amount + voucher.Tax);
                }
            }

            if (isDeletion && !voucher.CanDelete(HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);

            if (!isDeletion && !voucher.CanEdit(HttpContext.IsAdministrator(), HttpContext.IsSuperUser()))
                throw new UnreportedException(AppConstants.RecordIsReadOnly);
        }

        public int Create(AppLazyContext lazyContext, int voucherTypeId, DateTime documentDate, int tripId, string tripLineIds, int[] passengerIds, string comments) {
            VoucherViewModel model = null;
            int count = 0;

            if (passengerIds.Length == 0)
                throw new UnreportedException("No passengers have been selected.");

            using (var ts = Utils.CreateTransactionScope()) {
                var tripLineIdList = tripLineIds.Split(',').Select(int.Parse).ToArray();
                var trip = lazyContext.Trip.Find(tripId);

                if (trip.TripLines.Any(t => tripLineIdList.Contains(t.Id) && t.Voucher.Id < 0 && !t.IsBooking))
                    throw new UnreportedException("Vouchers can only be created for booked records.");

                foreach (int tripLineId in tripLineIdList) {
                    if (trip.TripLines.SingleOrDefault(t => t.Id == tripLineId && t.Voucher.Id > 0) != null)
                        continue;

                    var tripLine = lazyContext.TripLine.Find(tripLineId);

                    switch (tripLine.TripLineType) {
                        default:
                            continue;
                        case TripLineType.Accommodation:
                        case TripLineType.Transport:
                        case TripLineType.Cruise:
                        case TripLineType.Tour:
                        case TripLineType.OtherLand:
                            count++;
                            var voucherType = (VoucherType)voucherTypeId;

                            model = new VoucherViewModel {
                                VoucherType = voucherType,
                                VoucherDocumentStatus = DocumentStatus.None,
                                VoucherDocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Voucher"),
                                VoucherDocumentDate = documentDate.Date,
                                VoucherTripId = trip.Id,
                                VoucherTripLineId = tripLineId,
                                VoucherCreditorId = tripLine.TripLineLand.CreditorId,
                                VoucherSupplierId = tripLine.TripLineLand.SupplierId,
                                VoucherServiceTypeId = (lazyContext.ServiceType.FirstOrDefault(t => t.TripLineType == tripLine.TripLineType) ?? new ServiceType { Id = -1 }).Id,
                                VoucherConfirmationNo = tripLine.TripLineLand.ConfirmationNo,
                                VoucherDuration = tripLine.TripLineLand.Duration,
                                VoucherDurationCoverageType = tripLine.TripLineLand.DurationCoverageType,
                                VoucherSupplierServiceId = -1,
                                VoucherSupplierName = tripLine.TripLineLand.SupplierName,
                                VoucherSupplierAddress1 = tripLine.TripLineLand.SupplierAddress1,
                                VoucherSupplierAddress2 = tripLine.TripLineLand.SupplierAddress2,
                                VoucherSupplierLocality = tripLine.TripLineLand.SupplierLocality,
                                VoucherSupplierRegion = tripLine.TripLineLand.SupplierRegion,
                                VoucherSupplierPostCode = tripLine.TripLineLand.SupplierPostCode,
                                VoucherSupplierCountryCode = tripLine.TripLineLand.SupplierCountryCode,
                                VoucherSupplierContactTitle = tripLine.TripLineLand.SupplierContactTitle,
                                VoucherSupplierContactName = tripLine.TripLineLand.SupplierContactName,
                                VoucherSupplierContactPhoneHome = tripLine.TripLineLand.SupplierContactPhoneHome,
                                VoucherSupplierContactPhoneWork = tripLine.TripLineLand.SupplierContactPhoneWork,
                                VoucherSupplierContactMobile = tripLine.TripLineLand.SupplierContactMobile,
                                VoucherSupplierContactFax = tripLine.TripLineLand.SupplierContactFax,
                                VoucherSupplierContactEmail = tripLine.TripLineLand.SupplierContactEmail,
                                VoucherStartDate = tripLine.TripLineLand.StartDate,
                                VoucherStartTime = tripLine.TripLineLand.StartTime,
                                VoucherStartDetails = tripLine.TripLineLand.StartDetails,
                                VoucherEndDate = tripLine.TripLineLand.EndDate,
                                VoucherEndTime = tripLine.TripLineLand.EndTime,
                                VoucherEndDetails = tripLine.TripLineLand.EndDetails,
                                VoucherPassengerClassification = tripLine.TripLineLand.PassengerClassification,
                                VoucherPaxAdultNo = tripLine.TripLineLand.PaxAdultNo,
                                VoucherPaxAdultRate = tripLine.TripLineLand.PaxAdultRate,
                                VoucherPaxAdultQty = tripLine.TripLineLand.PaxAdultQty,
                                VoucherPaxChildNo = tripLine.TripLineLand.PaxChildNo,
                                VoucherPaxChildRate = tripLine.TripLineLand.PaxChildRate,
                                VoucherPaxChildQty = tripLine.TripLineLand.PaxChildQty,
                                VoucherPaxInfantNo = tripLine.TripLineLand.PaxInfantNo,
                                VoucherPaxInfantRate = tripLine.TripLineLand.PaxInfantRate,
                                VoucherPaxInfantQty = tripLine.TripLineLand.PaxInfantQty,
                                VoucherServiceTypeRateBasisId = tripLine.TripLineLand.ServiceTypeRateBasisId,
                                VoucherServiceComments = tripLine.TripLineLand.Comments,
                                VoucherSaleTypeId = tripLine.TripLineLand.SaleTypeId,
                                VoucherCurrencyId = trip.CurrencyId,
                                VoucherDiscount = tripLine.TripLineLand.Discount,
                                VoucherDiscountReasonId = tripLine.TripLineLand.DiscountReasonId,
                                VoucherAmount = tripLine.TripLineLand.SellingPrice,
                                VoucherCommission = tripLine.TripLineLand.Commission,
                                VoucherComments = comments.ToStringExt(),
                            };

                            break;
                    }

                    CreateOrUpdate(lazyContext, model);

                    foreach (int passengerId in passengerIds) {
                        var voucherDetailModel = new VoucherDetailViewModel {
                            VoucherId = model.VoucherId,
                            VoucherDetailPassengerId = passengerId
                        };

                        VoucherDetailCommon.CreateOrUpdate(lazyContext, voucherDetailModel, voucherDetailModel.VoucherId);
                    }

                    var voucher = lazyContext.Voucher.Find(model.VoucherId);
                    voucher.DocumentStatus = voucher.VoucherType == VoucherType.PaidDirect || voucher.VoucherType == VoucherType.BillbackClientDirect ? DocumentStatus.Closed : DocumentStatus.Open;
                    lazyContext.Save(voucher, false);
                }

                ts.Complete();
                return count;
            }
        }

        public bool CreateOrUpdate(AppLazyContext lazyContext, VoucherViewModel model) {
            if ((model.VoucherSaleTypeId ?? 0) <= 0)
                throw new UnreportedException("Type of Sale is required.");

            using (var ts = Utils.CreateTransactionScope()) {
                Voucher q = null;

                if (model.VoucherId <= 0) {
                    q = new Voucher {
                        Id = 0,
                        DocumentStatus = model.VoucherDocumentStatus,
                        ReversalStatus = ReversalStatus.None,
                        DocumentNo = string.IsNullOrEmpty(model.VoucherDocumentNo) ? LastDocumentNo.DocumentNo(lazyContext, "Voucher") : model.VoucherDocumentNo,
                        TripId = model.VoucherTripId ?? 0,
                        Trip = lazyContext.Trip.Find(model.VoucherTripId),
                        TripLineId = model.VoucherTripLineId ?? 0,
                        TripLine = lazyContext.TripLine.Find(model.VoucherTripLineId),
                        CreditorId = model.VoucherCreditorId ?? 0,
                        Creditor = lazyContext.Creditor.Find(model.VoucherCreditorId),
                        SupplierId = model.VoucherSupplierId ?? 0,
                        Supplier = lazyContext.Supplier.Find(model.VoucherSupplierId),
                        ServiceTypeId = model.VoucherServiceTypeId ?? 0,
                        ServiceType = lazyContext.ServiceType.Find(model.VoucherServiceTypeId),
                        ServiceTypeRateBasisId = model.VoucherServiceTypeRateBasisId ?? 0,
                        ServiceTypeRateBasis = lazyContext.ServiceTypeRateBasis.Find(model.VoucherServiceTypeRateBasisId),
                        SupplierServiceId = model.VoucherSupplierServiceId ?? 0,
                        SupplierService = lazyContext.SupplierService.Find(model.VoucherSupplierServiceId),
                        SaleTypeId = model.VoucherSaleTypeId ?? 0,
                        SaleType = lazyContext.SaleType.Find(model.VoucherSaleTypeId),
                        CurrencyId = model.VoucherCurrencyId ?? 0,
                        Currency = lazyContext.Currency.Find(model.VoucherCurrencyId),
                        DiscountReasonId = model.VoucherDiscountReasonId ?? 0,
                        DiscountReason = lazyContext.DiscountReason.Find(model.VoucherDiscountReasonId)
                    };

                    LastDocumentNo.DocumentNo(lazyContext, "Voucher", q.DocumentNo);
                }
                else {
                    q = lazyContext.Voucher.Find(model.VoucherId);
                }

                if (model.VoucherId <= 0 && q.TripLine.Voucher.Id > 0)
                    throw new UnreportedException(string.Format("Voucher No {0} has already been issued for this trip line.", q.TripLine.Voucher.DocumentNo));

                if ((model.VoucherType == VoucherType.PaidDirect || model.VoucherType == VoucherType.BillbackClientDirect) && (q.TripLine.Discount != 0 || q.TripLine.Markup != 0))
                    throw new UnreportedException("Paid Direct and Billback to Client vouchers cannot be created for trip lines containing discount or mark-up.");

                q.VoucherType = model.VoucherType;
                q.DocumentDate = model.VoucherDocumentDate ?? DateTime.MinValue;
                q.TripId = model.VoucherTripId ?? 0;
                q.TripLineId = model.VoucherTripLineId ?? 0;
                q.CreditorId = model.VoucherCreditorId ?? 0;
                q.SupplierId = model.VoucherSupplierId ?? 0;
                q.ConfirmationNo = model.VoucherConfirmationNo.ToStringExt();
                q.ServiceTypeId = model.VoucherServiceTypeId ?? 0;
                q.ServiceTypeRateBasisId = model.VoucherServiceTypeRateBasisId ?? 0;
                q.SupplierServiceId = model.VoucherSupplierServiceId ?? 0;
                q.Duration = model.VoucherDuration;
                q.DurationCoverageType = model.VoucherDurationCoverageType;
                q.SupplierName = model.VoucherSupplierName;
                q.SupplierAddress1 = model.VoucherSupplierAddress1.ToStringExt();
                q.SupplierAddress2 = model.VoucherSupplierAddress2.ToStringExt();
                q.SupplierLocality = model.VoucherSupplierLocality.ToStringExt();
                q.SupplierRegion = model.VoucherSupplierRegion.ToStringExt();
                q.SupplierPostCode = model.VoucherSupplierPostCode.ToStringExt();
                q.SupplierCountryCode = model.VoucherSupplierCountryCode.ToStringExt();
                q.SupplierContactTitle = model.VoucherSupplierContactTitle.ToStringExt();
                q.SupplierContactName = model.VoucherSupplierContactName.ToStringExt();
                q.SupplierContactPhoneHome = model.VoucherSupplierContactPhoneHome.ToStringExt();
                q.SupplierContactPhoneWork = model.VoucherSupplierContactPhoneWork.ToStringExt();
                q.SupplierContactMobile = model.VoucherSupplierContactMobile.ToStringExt();
                q.SupplierContactFax = model.VoucherSupplierContactFax.ToStringExt();
                q.SupplierContactEmail = model.VoucherSupplierContactEmail.ToStringExt();
                q.StartDate = model.VoucherStartDate ?? DateTime.MinValue;
                q.StartTime = model.VoucherStartTime.ToStringExt();
                q.StartDetails = model.VoucherStartDetails.ToStringExt();
                q.EndDate = model.VoucherEndDate ?? DateTime.MinValue;
                q.EndTime = model.VoucherEndTime.ToStringExt();
                q.EndDetails = model.VoucherEndDetails.ToStringExt();
                q.PassengerClassification = model.VoucherPassengerClassification;
                q.PaxAdultNo = model.VoucherPaxAdultNo;
                q.PaxAdultRate = model.VoucherPaxAdultRate;
                q.PaxAdultQty = model.VoucherPaxAdultQty;
                q.PaxChildNo = model.VoucherPaxChildNo;
                q.PaxChildRate = model.VoucherPaxChildRate;
                q.PaxChildQty = model.VoucherPaxChildQty;
                q.PaxInfantNo = model.VoucherPaxInfantNo;
                q.PaxInfantRate = model.VoucherPaxInfantRate;
                q.PaxInfantQty = model.VoucherPaxInfantQty;
                q.ServiceComments = model.VoucherServiceComments.ToStringExt();
                q.SaleTypeId = model.VoucherSaleTypeId ?? 0;
                q.CurrencyId = model.VoucherCurrencyId ?? 0;
                q.Amount = model.VoucherAmount;
                q.Tax = model.VoucherTax;
                q.Commission = model.VoucherCommission;
                q.CommissionTax = model.VoucherCommissionTax;
                q.Discount = model.VoucherDiscount;
                q.DiscountTax = model.VoucherDiscountTax;
                q.DiscountReasonId = model.VoucherDiscountReasonId ?? 0;
                q.IncludePricing = model.VoucherIncludePricing;
                q.Comments = model.VoucherComments.ToStringExt();
                q.IsIssued = q.IssuedDocuments.Count > 0;

                bool result = ValidateAndSave(lazyContext, q);
                model.VoucherId = q.Id;

                ts.Complete();
                return result;
            }
        }

        public bool Delete(AppLazyContext lazyContext, VoucherViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.Voucher.Find(model.VoucherId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                ValidateAndDelete(lazyContext, q);

                ts.Complete();
                return true;
            }
        }

        public bool Undo(AppLazyContext lazyContext, int voucherId) {
            var q = lazyContext.Voucher.Find(voucherId);

            if (!q.CanUndo())
                throw new UnreportedException(AppConstants.RecordCannotBeUndone);

            Validate(lazyContext, q, false);
            return q.UpdateDocumentStatus(lazyContext, DocumentStatus.Open);
        }

        public bool Reverse(AppLazyContext lazyContext, int voucherId, string type) {
            using (var ts = Utils.CreateTransactionScope()) {
                var voucher = lazyContext.Voucher.Find(voucherId);

                if (!voucher.CanReverse())
                    throw new UnreportedException(AppConstants.RecordCannotBeReversed);

                if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), voucher.DocumentDate, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                if (type == "CurrentDate" && !Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                    throw new UnreportedException(AppConstants.RecordIsClosed);

                voucher.UpdateReversalStatus(lazyContext, ReversalStatus.Reversed);
                var voucherClone = voucher.Clone() as Voucher;

                voucherClone.Id = 0;
                voucherClone.ReversalStatus = ReversalStatus.Reversal;

                voucherClone.DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Voucher");
                LastDocumentNo.DocumentNo(lazyContext, "Voucher", voucherClone.DocumentNo);

                if (type == "CurrentDate")
                    voucherClone.DocumentDate = DateTime.Today;

                voucherClone.Amount = -voucherClone.Amount;
                voucherClone.Tax = -voucherClone.Tax;
                voucherClone.Commission = -voucherClone.Commission;
                voucherClone.CommissionTax = -voucherClone.CommissionTax;
                voucherClone.Discount = -voucherClone.Discount;
                voucherClone.DiscountTax = -voucherClone.DiscountTax;

                lazyContext.Insert(voucherClone);

                if (voucherClone.TripLineId > 0)
                    lazyContext.TripLine.Find(voucherClone.TripLineId).Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                ts.Complete();
                return true;
            }
        }

        public bool IssueDocument(AppLazyContext lazyContext, int voucherId, int? tripId = null) {
            List<Voucher> vouchers = null;

            if (tripId == null) {
                var voucher = lazyContext.Voucher.Find(voucherId);

                if (voucher != null)
                    vouchers = new List<Voucher> { voucher };
            }
            else {
                vouchers = lazyContext.Voucher.Where(t => t.TripId == tripId).ToList();
            }

            if (vouchers == null || vouchers.Count == 0)
                throw new UnreportedException("No vouchers have been created for this Trip.");

            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var voucher in vouchers) {
                    if (voucher.Amount == 0)
                        throw new UnreportedException("Voucher cannot be issued with zero value.");

                    voucher.DocumentStatus = DocumentStatus.Closed;
                    voucher.IsIssued = true;
                    lazyContext.Save(voucher);

                    var reportSource = AccountingDataSources.GetVoucherReportSource(lazyContext, HttpContext.CurrentCustomerId(), voucher.Id);
                    var result = Utils.ExportToPdf(reportSource);

                    var q = lazyContext.IssuedDocument.SingleOrDefault(t => t.IssuedDocumentType == IssuedDocumentType.Voucher && t.VoucherId == voucher.Id);

                    if (q != null)
                        continue;

                    q = new IssuedDocument {
                        Id = 0,
                        IssuedDocumentType = IssuedDocumentType.Voucher,
                        TripId = voucher.TripId,
                        DebtorId = -1,
                        CreditorId = voucher.CreditorId,
                        ReceiptId = -1,
                        InvoiceId = -1,
                        VoucherId = voucher.Id,
                        Name = IssuedDocument.GetVoucherName(voucher.DocumentNo),
                        FileExtension = "pdf",
                        Document = result.DocumentBytes
                    };

                    lazyContext.Insert(q);
                }

                ts.Complete();
                return true;
            }
        }
    }

    public static class VoucherDetailCommon {
        public static bool CreateOrUpdate(AppMainContext context, VoucherDetailViewModel model, int voucherId) {
            using (var ts = Utils.CreateTransactionScope()) {
                VoucherDetail q = null;

                if (model.VoucherDetailId <= 0) {
                    q = new VoucherDetail {
                        Id = 0,
                        VoucherId = voucherId,
                        Voucher = context.Voucher.Find(voucherId)
                    };
                }
                else {
                    q = context.VoucherDetail.Find(model.VoucherDetailId);
                }

                q.VoucherId = voucherId;
                q.PassengerId = model.VoucherDetailPassengerId ?? 0;

                bool result;

                if (q.Id <= 0) {
                    result = context.Insert(q);
                }
                else {
                    result = context.Save(q);
                }

                model.VoucherDetailId = q.Id;

                ts.Complete();
                return result;
            }
        }

        public static bool Delete(AppMainContext context, VoucherDetailViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = context.VoucherDetail.Find(model.VoucherDetailId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);

                ts.Complete();
                return true;
            }
        }
    }

    public class PaymentMethodCommon {
        private HttpContext HttpContext { get; }

        public PaymentMethodCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool CreateOrUpdate(AppMainContext context, PaymentMethodViewModel model, string encryptedCardNo, string encryptedCvn) {
            PaymentMethod q = null;

            if (model.PaymentMethodId <= 0) {
                q = new PaymentMethod();
            }
            else {
                q = context.PaymentMethod.Find(model.PaymentMethodId);
            }

            int profileId = -1;
            int tripId = -1;
            int debtorId = -1;
            int creditorId = -1;
            int chartOfAccountId = -1;

            if (model.PaymentMethodAccountType == AccountType.None) {
                if (model.PaymentMethodDebtorId > 0) {
                    model.PaymentMethodAccountType = AccountType.Debtor;
                }
                else if (model.PaymentMethodCreditorId > 0) {
                    model.PaymentMethodAccountType = AccountType.Creditor;
                }
                else if (model.PaymentMethodChartOfAccountId > 0) {
                    model.PaymentMethodAccountType = AccountType.GeneralLedger;
                }
                else if (model.PaymentMethodProfileId > 0 || model.PaymentMethodTripId > 0) {
                    model.PaymentMethodAccountType = AccountType.Client;
                }
                else {
                    throw new UnreportedException("Invalid Account Type.");
                }
            }

            switch (model.PaymentMethodAccountType) {
                case AccountType.Client:
                    if (model.PaymentMethodIsProfile) {
                        profileId = model.PaymentMethodProfileId ?? 0;

                        if (profileId <= 0)
                            throw new UnreportedException("Profile is required.");
                    }
                    else {
                        tripId = model.PaymentMethodTripId ?? 0;

                        if (tripId <= 0)
                            throw new UnreportedException("Trip is required.");
                    }

                    break;
                case AccountType.Debtor:
                    debtorId = model.PaymentMethodDebtorId ?? 0;

                    if (debtorId <= 0)
                        throw new UnreportedException("Debtor is required.");

                    break;
                case AccountType.Creditor:
                    tripId = model.PaymentMethodTripId ?? 0;

                    if (tripId <= 0)
                        throw new UnreportedException("Trip is required.");

                    creditorId = model.PaymentMethodCreditorId ?? 0;

                    if (creditorId <= 0)
                        throw new UnreportedException("Creditor is required.");

                    break;
                case AccountType.GeneralLedger:
                    chartOfAccountId = model.PaymentMethodChartOfAccountId ?? 0;

                    if (chartOfAccountId <= 0)
                        throw new UnreportedException("GL Account is required.");

                    break;
            }

            var formOfPayment = context.FormOfPayment.Find(model.PaymentMethodFormOfPaymentId ?? -1);

            switch (formOfPayment.FormOfPaymentType) {
                default:
                    model.PaymentMethodAccountNo = string.Empty;
                    model.PaymentMethodPaymentDetails1 = string.Empty;
                    model.PaymentMethodPaymentDetails2 = string.Empty;
                    model.PaymentMethodPaymentDetails3 = string.Empty;
                    model.PaymentMethodCreditLimit = 0;
                    model.PaymentMethodExpiryDate = DateTime.MinValue;
                    break;
                case FormOfPaymentType.AgencyCreditCardGross:
                case FormOfPaymentType.AgencyCreditCardNet:
                case FormOfPaymentType.CreditCard:
                case FormOfPaymentType.TravelCard:
                case FormOfPaymentType.EFTPOS:
                    model.PaymentMethodPaymentDetails2 = string.Empty;
                    model.PaymentMethodPaymentDetails3 = string.Empty;
                    break;
                case FormOfPaymentType.Cheque:
                    model.PaymentMethodCreditLimit = 0;
                    model.PaymentMethodExpiryDate = DateTime.MinValue;
                    break;
                case FormOfPaymentType.DirectDebitCredit:
                case FormOfPaymentType.LoyaltyScheme:
                case FormOfPaymentType.Reward:
                    model.PaymentMethodPaymentDetails2 = string.Empty;
                    model.PaymentMethodPaymentDetails3 = string.Empty;
                    model.PaymentMethodCreditLimit = 0;
                    model.PaymentMethodExpiryDate = DateTime.MinValue;
                    break;
            }

            long tokenCustomerId = q.TokenCustomerId;

            if (formOfPayment.FormOfPaymentType == FormOfPaymentType.CreditCard) {
                var eWay = new Eway(HttpContext.CurrentCustomerId(), PaymentGatewayClientType.Customer, AppSettings.IsDevelopmentMode);

                string expiryMonth = (model.PaymentMethodExpiryDate ?? DateTime.MinValue).Month.ToString("D2");
                string expiryYear = (model.PaymentMethodExpiryDate ?? DateTime.MinValue).Year.ToString();

                tokenCustomerId = eWay.CreateOrUpdateTokenCustomer(
                    cardNo: encryptedCardNo,
                    cardholderName: model.PaymentMethodPaymentDetails1,
                    expiryMonth: expiryMonth,
                    expiryYear: expiryYear,
                    cvn: encryptedCvn,
                    countryIsoCode: CustomerSettings.Setting(HttpContext.CurrentCustomerId()).CountryIsoCode,
                    tokenCustomerId: tokenCustomerId
                );

                var response = eWay.QueryCustomer(tokenCustomerId);
                tokenCustomerId = response.TokenCustomerID.ToLong();

                model.PaymentMethodAccountNo = response.CardDetails.Number;
            }

            q.ProfileId = profileId;
            q.TripId = tripId;
            q.DebtorId = debtorId;
            q.CreditorId = creditorId;
            q.ChartOfAccountId = chartOfAccountId;
            q.AccountType = model.PaymentMethodAccountType;
            q.FormOfPaymentId = model.PaymentMethodFormOfPaymentId ?? 0;
            q.TokenCustomerId = tokenCustomerId;
            q.AccountNo = model.PaymentMethodAccountNo.ToStringExt();
            q.PaymentDetails1 = model.PaymentMethodPaymentDetails1.ToStringExt();
            q.PaymentDetails2 = model.PaymentMethodPaymentDetails2.ToStringExt();
            q.PaymentDetails3 = model.PaymentMethodPaymentDetails3.ToStringExt();
            q.CreditLimit = model.PaymentMethodCreditLimit;
            q.ExpiryDate = model.PaymentMethodExpiryDate ?? DateTime.MinValue;
            q.Comments = model.PaymentMethodComments.ToStringExt();
            q.IsActive = model.PaymentMethodIsActive;

            if (q.ChartOfAccountId > 0 && !ChartOfAccount.IsInRole(context, q.ChartOfAccountId, HttpContext.RoleId()))
                throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

            bool result;

            if (q.Id <= 0) {
                result = context.Insert(q);
            }
            else {
                result = context.Save(q);
            }

            model.PaymentMethodId = q.Id;
            model.PaymentMethodFormOfPaymentId = q.FormOfPaymentId;
            model.PaymentMethodProfileId = q.ProfileId;
            model.PaymentMethodTripId = q.TripId;
            model.PaymentMethodDebtorId = q.DebtorId;
            model.PaymentMethodCreditorId = q.CreditorId;
            model.PaymentMethodChartOfAccountId = q.ChartOfAccountId;

            return result;
        }
    }

    public class TransactionCommon {
        private HttpContext HttpContext { get; }

        public TransactionCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool Delete(AppLazyContext lazyContext, TransactionViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                switch (model.TransactionType) {
                    case TransactionType.Receipt:
                        var receipt = lazyContext.Receipt.Find(model.TransactionRefId);

                        if (receipt == null)
                            throw new UnreportedException(AppConstants.RecordNotFound);

                        new ReceiptCommon(HttpContext).ValidateAndDelete(lazyContext, receipt);
                        break;
                    case TransactionType.Bsp:
                        var bsp = lazyContext.Bsp.Include(t => t.AgencyCreditCardBsp).SingleOrDefault(t => t.Id == model.TransactionRefId);

                        if (bsp == null)
                            throw new UnreportedException(AppConstants.RecordNotFound);

                        new BspCommon(HttpContext).ValidateAndDelete(lazyContext, bsp);
                        break;
                    case TransactionType.NonBsp:
                        var nonBsp = lazyContext.NonBsp.Include(t => t.AgencyCreditCardBsp).Include(t => t.AgencyCreditCardNonBsp).SingleOrDefault(t => t.Id == model.TransactionRefId);

                        if (nonBsp == null)
                            throw new UnreportedException(AppConstants.RecordNotFound);

                        new NonBspCommon(HttpContext).ValidateAndDelete(lazyContext, nonBsp);
                        break;
                    case TransactionType.Payment:
                        var payment = lazyContext.Payment.Find(model.TransactionRefId);

                        if (payment == null)
                            throw new UnreportedException(AppConstants.RecordNotFound);

                        new PaymentCommon(HttpContext).ValidateAndDelete(lazyContext, payment);
                        break;
                    case TransactionType.Invoice:
                    case TransactionType.CreditNote:
                        var invoice = lazyContext.Invoice.Include(t => t.Transactions).Single(t => t.Id == model.TransactionRefId);

                        if (invoice == null)
                            throw new UnreportedException(AppConstants.RecordNotFound);

                        new InvoiceCommon(HttpContext).ValidateAndDelete(lazyContext, invoice, false);
                        break;
                    case TransactionType.Journal:
                        var journal = lazyContext.Journal.Include(t => t.Transactions).Single(t => t.Id == model.TransactionRefId);

                        if (journal == null)
                            throw new UnreportedException(AppConstants.RecordNotFound);

                        new JournalCommon(HttpContext).ValidateAndDelete(lazyContext, journal);
                        break;
                    case TransactionType.Adjustment:
                        var adjustment = lazyContext.Adjustment.Find(model.TransactionRefId);

                        if (adjustment == null)
                            throw new UnreportedException(AppConstants.RecordNotFound);

                        new AdjustmentCommon(HttpContext).ValidateAndDelete(lazyContext, adjustment);
                        break;
                }

                ts.Complete();
                return true;
            }
        }
    }

    public class BankReconciliationCommon {
        private HttpContext HttpContext { get; }

        public BankReconciliationCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool ProcessSelections(AppLazyContext lazyContext, int[] receiptDetailIds, int[] paymentDetailIds, int bankAccountStatementId, string action, string type) {
            if (!Setting.IsFiscalPeriodOpen(HttpContext.CurrentCustomerId(), DateTime.Today, HttpContext.IsAdministrator()))
                throw new UnreportedException(AppConstants.RecordIsClosed);

            if ((receiptDetailIds == null || receiptDetailIds.Length == 0) && (paymentDetailIds == null || paymentDetailIds.Length == 0))
                throw new UnreportedException("No documents have been selected.");

            using (var ts = Utils.CreateTransactionScope()) {
                if (action == "Undo" || action == "Reverse" || action == "Delete") {
                    if (receiptDetailIds?.Length > 0) {
                        if (action == "Reverse") {
                            foreach (int receiptId in lazyContext.ReceiptDetail.Where(t => receiptDetailIds.Contains(t.Id)).Select(t => t.ReceiptId).Distinct()) {
                                new ReceiptCommon(HttpContext).Reverse(lazyContext, receiptId, type);
                            }
                        }
                        else {
                            foreach (int receiptDetailId in receiptDetailIds) {
                                if (action == "Undo") {
                                    new ReceiptCommon(HttpContext).Undo(lazyContext, receiptDetailId, true, true);
                                }
                                else {
                                    var receiptDetail = lazyContext.ReceiptDetail.Find(receiptDetailId);

                                    if (receiptDetail == null)
                                        continue;

                                    var receipt = receiptDetail.Receipt;

                                    if (receipt.IsDeposit || receipt.ReceiptDetails.All(t => receiptDetailIds.Contains(t.Id))) {
                                        new ReceiptCommon(HttpContext).ValidateAndDelete(lazyContext, receipt);
                                    }
                                    else {
                                        new ReceiptDetailCommon(HttpContext).ValidateAndDelete(lazyContext, receiptDetail);
                                    }
                                }
                            }
                        }
                    }

                    if (paymentDetailIds?.Length > 0) {
                        if (action == "Reverse") {
                            foreach (int paymentId in lazyContext.PaymentDetail.Where(t => paymentDetailIds.Contains(t.Id)).Select(t => t.PaymentId).Distinct()) {
                                new PaymentCommon(HttpContext).Reverse(lazyContext, paymentId, type);
                            }
                        }
                        else {
                            foreach (int paymentDetailId in paymentDetailIds) {
                                if (action == "Undo") {
                                    new PaymentCommon(HttpContext).Undo(lazyContext, paymentDetailId, true, true);
                                }
                                else {
                                    var paymentDetail = lazyContext.PaymentDetail.Find(paymentDetailId);

                                    if (paymentDetail == null)
                                        continue;

                                    var payment = paymentDetail.Payment;

                                    if (payment.PaymentDetails.All(t => paymentDetailIds.Contains(t.Id))) {
                                        new PaymentCommon(HttpContext).ValidateAndDelete(lazyContext, payment);
                                    }
                                    else {
                                        new PaymentDetailCommon(HttpContext).ValidateAndDelete(lazyContext, paymentDetail);
                                    }
                                }
                            }
                        }
                    }

                    ts.Complete();
                    return true;
                }

                if (receiptDetailIds != null && receiptDetailIds.Length > 0) {
                    int receiptId = 0;
                    int i = 0;

                    foreach (int receiptDetailId in receiptDetailIds) {
                        i++;

                        var q = lazyContext.ReceiptDetail.Find(receiptDetailId);
                        q.UpdateDocumentStatus(lazyContext, DocumentStatus.Closed, bankAccountStatementId);

                        if (receiptId != q.ReceiptId)
                            i = 1;

                        receiptId = q.ReceiptId;

                        if (q.Receipt.IsDeposit && i == 1) {
                            int depositDetailId = q.Receipt.ReceiptDetails.Single().Id;

                            foreach (var receiptDetail in lazyContext.ReceiptDetail.Where(t => t.DepositDetailId == depositDetailId).ToList()) {
                                receiptDetail.UpdateDocumentStatus(lazyContext, DocumentStatus.Closed, bankAccountStatementId);
                            }
                        }
                    }
                }

                if (paymentDetailIds != null && paymentDetailIds.Length > 0) {
                    foreach (int paymentDetailId in paymentDetailIds) {
                        var q = lazyContext.PaymentDetail.Find(paymentDetailId);
                        q.UpdateDocumentStatus(lazyContext, DocumentStatus.Closed, bankAccountStatementId);
                    }
                }

                ts.Complete();
                return true;
            }
        }
    }

    public class TransactionDetailAllocationCommon {
        private const string ClassName = "Travelog.WebApp.Accounting.TransactionDetailAllocationCommon";
        private HttpContext HttpContext { get; }

        public TransactionDetailAllocationCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool CreateOrUpdate(AppLazyContext lazyContext, LedgerType allocationType, Debtor debtor, int creditorId, List<TransactionDetailAllocationModel> allocationList, bool allocationListIsConsolidated, bool isCreditAllocation, bool unmatchSelections, TransactionMatchViewStatus transactionMatchViewStatus, int receiptId = 0, int receiptDetailId = 0) {
            if (allocationList.Count == 0)
                return false;

            if (allocationType != LedgerType.DebtorLedger && allocationType != LedgerType.CreditorLedger)
                throw new InvalidOperationException("Invalid Ledger Type.");

            if (allocationList.Where(t => t.IsMasterDocument).Select(t => t.TransactionRefId).Distinct().Count() > 1)
                throw new UnreportedException("Only one master document can be selected.");

            using (var ts = Utils.CreateTransactionScope()) {
                int debtorId = debtor?.Id ?? 0;
                bool isCreditCardDebtor = debtor?.IsCreditCardDebtor ?? false;

                int masterDocumentId = 0;
                var masterDocument = allocationList.SingleOrDefault(t => t.IsMasterDocument);

                if (masterDocument != null) {
                    if (masterDocument.TransactionType == TransactionType.Adjustment) {
                        masterDocumentId = masterDocument.TransactionRefId;
                    }
                    else {
                        masterDocumentId = masterDocument.TransactionDetailRefId;
                    }
                }

                if (allocationListIsConsolidated)
                    ConsolidatedToDetail(lazyContext, transactionMatchViewStatus, allocationType, debtorId, creditorId, isCreditAllocation, ref allocationList);

                if (allocationList.Any(t => t.Amount == 0))
                    throw new UnreportedException("One or more rows have a zero value. To unmatch rows, make selections in Saved/Detail view and select 'Unmatch Selections'.");

                if (unmatchSelections) {
                    if (allocationListIsConsolidated || transactionMatchViewStatus == TransactionMatchViewStatus.NotSaved)
                        throw new UnreportedException("Unmatching can only be performed in Saved/Detail view.");

                    if (UnmatchSelections(lazyContext, allocationList))
                        ts.Complete();

                    return true;
                }

                if (isCreditAllocation) {
                    int count = allocationList.Count(t => t.TransactionType == TransactionType.Receipt);

                    if (count == 1 || isCreditCardDebtor) {
                        if (isCreditCardDebtor) {
                            int[] receiptDetailIds = allocationList.Where(t => t.TransactionType == TransactionType.Receipt).Select(t => t.TransactionDetailRefId).ToArray();
                            var receiptDetails = lazyContext.ReceiptDetail.Where(t => receiptDetailIds.Contains(t.Id)).AsEnumerable();

                            if (receiptDetails.Count(t => t.Receipt.Debtor.IsCreditCardDebtor) > 1)
                                throw new UnreportedException("Only one Credit Card Debtor Receipt Detail row can be matched at a time.");

                            var receiptDetail = receiptDetails.Single(t => t.Receipt.Debtor.IsCreditCardDebtor);

                            receiptId = receiptDetail.ReceiptId;
                            receiptDetailId = receiptDetail.Id;

                            allocationList = allocationList.Where(t => t.TransactionDetailRefId != receiptDetailId).ToList();
                        }
                        else {
                            receiptId = allocationList.Single(t => t.TransactionType == TransactionType.Receipt).TransactionRefId;
                            receiptDetailId = allocationList.Single(t => t.TransactionType == TransactionType.Receipt).TransactionDetailRefId;
                            allocationList = allocationList.Where(t => t.TransactionType != TransactionType.Receipt).ToList();
                        }

                        isCreditAllocation = false;
                    }
                }

                if (isCreditAllocation) {
                    if (allocationType == LedgerType.DebtorLedger) {
                        int count = allocationList.Where(t => t.SignType == SignType.Credit).Select(t => new { t.TransactionRefId, t.SignType }).Distinct().Count();

                        if (count == 0 || count > 1) {
                            count = allocationList.Where(t => t.SignType == SignType.Debit && t.Amount < 0).Select(t => t.TransactionRefId).Distinct().Count();

                            if (count == 1) {
                                foreach (var allocation in allocationList.Where(t => t.SignType == SignType.Debit && t.Amount < 0).OrderBy(t => (int)t.TransactionType).ToList()) {
                                    masterDocumentId = allocation.TransactionType == TransactionType.Adjustment ? allocation.TransactionRefId : allocation.TransactionDetailRefId;
                                    allocation.SignType = SignType.Credit;
                                }
                            }
                            else {
                                if (!allocationList.Any(t => t.IsMasterDocument))
                                    throw new UnreportedException("Please select a master document.");

                                foreach (var allocation in allocationList.Where(t => t.IsMasterDocument).ToList()) {
                                    allocation.SignType = SignType.Credit;
                                }
                            }
                        }
                    }
                    else if (allocationType == LedgerType.CreditorLedger) {
                        int count = allocationList.Where(t => t.SignType == SignType.Debit).Select(t => new { t.TransactionRefId, t.SignType }).Distinct().Count();

                        if (count == 0 || count > 1) {
                            count = allocationList.Where(t => t.SignType == SignType.Credit && t.Amount > 0).Select(t => t.TransactionRefId).Distinct().Count();

                            if (count == 1) {
                                foreach (var allocation in allocationList.Where(t => t.SignType == SignType.Credit && t.Amount > 0).OrderBy(t => (int)t.TransactionType).ToList()) {
                                    masterDocumentId = allocation.TransactionType == TransactionType.Adjustment ? allocation.TransactionRefId : allocation.TransactionDetailRefId;
                                    allocation.SignType = SignType.Debit;
                                }
                            }
                            else {
                                if (!allocationList.Any(t => t.IsMasterDocument))
                                    throw new UnreportedException("Please select a master document.");

                                foreach (var allocation in allocationList.Where(t => t.IsMasterDocument).ToList()) {
                                    allocation.SignType = SignType.Debit;
                                }
                            }
                        }
                    }

                    if (transactionMatchViewStatus == TransactionMatchViewStatus.Saved && allocationList.Sum(t => t.Amount) != 0)
                        throw new UnreportedException("Selections do not balance to zero.");
                }

                ManageAutoMatches(lazyContext, allocationType, allocationList);

                if (allocationType == LedgerType.DebtorLedger)
                    ManageZeroValueInvoices(lazyContext, allocationList);

                if (allocationType == LedgerType.DebtorLedger && !isCreditAllocation) {
                    var newAllocationList = new List<TransactionDetailAllocationModel>();

                    foreach (var allocation in allocationList) {
                        newAllocationList.Add(new TransactionDetailAllocationModel {
                            TransactionDetailOrAllocationId = allocation.TransactionDetailOrAllocationId,
                            TransactionId = allocation.TransactionId,
                            TransactionDetailId = allocation.TransactionDetailId,
                            TransactionRefId = receiptId,
                            TransactionDetailRefId = receiptDetailId,
                            TransactionType = TransactionType.Receipt,
                            SignType = SignType.Credit,
                            Amount = -allocation.Amount,
                            IsMasterDocument = false,
                            Reference = string.Empty,
                            TransactionMatchStatus = TransactionMatchStatus.Matched
                        });
                    }

                    allocationList = newAllocationList.Concat(allocationList).ToList();
                }

                var txnDetailAllocationList = new List<TransactionDetailAllocation>();
                int groupNo = (lazyContext.TransactionDetailAllocation.Max(t => (int?)t.GroupNo) ?? 0) + 1;

                foreach (var allocation in allocationList) {
                    var transactionDetailAllocations = CreateAllocations(lazyContext, allocation, groupNo, receiptDetailId, isCreditAllocation, isCreditCardDebtor, false);

                    if (transactionDetailAllocations.Any(t => t.ReceiptDetailId <= 0 && t.NonBspDetailId <= 0 && t.PaymentDetailId <= 0 && t.InvoiceDetailId <= 0 && t.JournalDetailId <= 0 && t.AdjustmentId <= 0)) {
                        const string message = "A processing error has resulted in an invalid allocation entry. It has been logged for review.";
                        string error = string.Format("{0} Transaction Detail ID: {1}.", message, allocation.TransactionDetailId);
                        ExceptionManager.HandleException(HttpContext, ClassName, "CreateOrUpdate", new InvalidOperationException(error));
                        throw new UnreportedException(message);
                    }

                    txnDetailAllocationList.AddRange(transactionDetailAllocations);
                }

                if (txnDetailAllocationList.Where(t => t.TransactionMatchStatus == TransactionMatchStatus.Matched).Sum(t => t.Amount) != 0) {
                    const string message = "A processing error has resulted in allocations not balancing to zero. It has been logged for review.";
                    string error = string.Format("{0} Transaction Detail IDs: {1}.", message, string.Join(", ", txnDetailAllocationList.Select(t => t.TransactionDetailId).Distinct()));
                    ExceptionManager.HandleException(HttpContext, ClassName, "CreateOrUpdate", new InvalidOperationException(error));
                    throw new UnreportedException(message);
                }

                long transactionDetailId = 0;

                if (isCreditAllocation) {
                    foreach (var row in txnDetailAllocationList.OrderBy(t => allocationType == LedgerType.DebtorLedger ? (t.TransactionType == TransactionType.Receipt ? 0 : (t.TransactionType == TransactionType.Invoice && t.InvoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote) ? 1 : 2) : (t.TransactionType == TransactionType.Payment ? 0 : 1))) {
                        if ((allocationType == LedgerType.DebtorLedger && (row.TransactionType == TransactionType.Receipt || (row.TransactionType == TransactionType.Invoice && row.InvoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote))) || (allocationType == LedgerType.CreditorLedger && row.TransactionType == TransactionType.Payment))
                            transactionDetailId = row.TransactionDetailId;

                        row.TransactionDetailId = transactionDetailId;
                        row.Reference ??= string.Empty;
                    }
                }
                else {
                    if (isCreditCardDebtor) {
                        var receiptDetail = lazyContext.ReceiptDetail.Find(receiptDetailId);
                        transactionDetailId = receiptDetail.TransactionDetails.First(t => t.LedgerType == LedgerType.DebtorLedger && (t.TransactionDetailType == TransactionDetailType.Normal || t.TransactionDetailType == TransactionDetailType.ExcludeFromSalesAnalysis)).Id;
                    }
                    else {
                        transactionDetailId = lazyContext.TransactionDetail.First(t => t.LedgerType == LedgerType.DebtorLedger && (t.TransactionDetailType == TransactionDetailType.Normal || t.TransactionDetailType == TransactionDetailType.ExcludeFromSalesAnalysis) && t.DebtorId == debtorId && t.ReceiptDetailId == receiptDetailId).Id;
                    }

                    foreach (var row in txnDetailAllocationList.Where(t => t.TransactionType != TransactionType.Receipt)) {
                        row.TransactionDetailId = transactionDetailId;
                    }
                }

                int i = -1;

                foreach (var row in txnDetailAllocationList.Where(t => t.Id <= 0)) {
                    row.Id = i--;
                }

                foreach (var row in txnDetailAllocationList) {
                    row.UpdateReference(txnDetailAllocationList, masterDocumentId);

                    if (row.Id <= 0) {
                        row.Id = 0;
                        lazyContext.Insert(row, false);
                    }
                    else {
                        lazyContext.Save(row, false);
                    }
                }

                if (isCreditCardDebtor) {
                    var receiptDetail = lazyContext.ReceiptDetail.Find(receiptDetailId);
                    decimal allocationTotal = -lazyContext.TransactionDetailAllocation.Where(t => t.ReceiptDetailId == receiptDetailId).Sum(t => (decimal?)t.Amount) ?? 0;

                    if (receiptDetail.Amount + receiptDetail.Tax != allocationTotal) {
                        if (receiptDetail.Receipt.IsTaxApplicable) {
                            decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), receiptDetail.Receipt.DocumentDate);
                            receiptDetail.Tax = Math.Round(allocationTotal * taxRate, 2);
                        }
                        else {
                            receiptDetail.Tax = 0;
                        }

                        receiptDetail.Amount = allocationTotal - receiptDetail.Tax;
                        lazyContext.Save(receiptDetail, false);
                    }
                }

                ts.Complete();
                return true;
            }
        }

        private static bool ConsolidatedToDetail(AppLazyContext lazyContext, TransactionMatchViewStatus transactionMatchViewStatus, LedgerType allocationType, int debtorId, int creditorId, bool isCreditAllocation, ref List<TransactionDetailAllocationModel> allocationList) {
            var newAllocationList = new List<TransactionDetailAllocationModel>();

            foreach (var allocation in allocationList) {
                IQueryable<TransactionDetail> transactionDetailList = null;

                if (isCreditAllocation) {
                    transactionDetailList = lazyContext.TransactionDetail.Where(t => t.TransactionId == allocation.TransactionId && t.LedgerType == allocationType
                        && (t.TransactionDetailType == TransactionDetailType.Normal || t.TransactionDetailType == TransactionDetailType.ExcludeFromSalesAnalysis));

                    if (allocationType == LedgerType.DebtorLedger) {
                        transactionDetailList = transactionDetailList.Where(t => t.Transaction.TransactionType != TransactionType.Journal || (t.JournalDetail.AccountType == AccountType.Debtor && t.JournalDetail.DebtorId == debtorId && t.JournalDetail.AgencyId == t.AgencyId));
                    }
                    else {
                        transactionDetailList = transactionDetailList.Where(t => t.Transaction.TransactionType != TransactionType.Journal || (t.JournalDetail.AccountType == AccountType.Creditor && t.JournalDetail.CreditorId == creditorId && t.JournalDetail.AgencyId == t.AgencyId));
                    }
                }
                else {
                    transactionDetailList = lazyContext.TransactionDetail.Where(t => t.LedgerType == allocationType && (t.TransactionDetailType == TransactionDetailType.Normal || t.TransactionDetailType == TransactionDetailType.ExcludeFromSalesAnalysis));

                    switch (allocation.TransactionType) {
                        case TransactionType.Receipt:
                            transactionDetailList = transactionDetailList.Where(t => t.ReceiptDetail.ReceiptId == allocation.TransactionRefId);
                            break;
                        case TransactionType.NonBsp:
                            transactionDetailList = transactionDetailList.Where(t => t.NonBspDetail.NonBspId == allocation.TransactionRefId);
                            break;
                        case TransactionType.Payment:
                            transactionDetailList = transactionDetailList.Where(t => t.PaymentDetail.PaymentId == allocation.TransactionRefId);
                            break;
                        case TransactionType.Invoice:
                        case TransactionType.CreditNote:
                            transactionDetailList = transactionDetailList.Where(t => t.InvoiceDetail.InvoiceId == allocation.TransactionRefId);
                            break;
                        case TransactionType.Journal:
                            if (allocationType == LedgerType.DebtorLedger) {
                                transactionDetailList = transactionDetailList.Where(t => t.JournalDetail.JournalId == allocation.TransactionRefId && t.JournalDetail.DebtorId == debtorId && t.JournalDetail.AgencyId == t.AgencyId);
                            }
                            else {
                                transactionDetailList = transactionDetailList.Where(t => t.JournalDetail.JournalId == allocation.TransactionRefId && t.JournalDetail.CreditorId == creditorId && t.JournalDetail.AgencyId == t.AgencyId);
                            }

                            break;
                        case TransactionType.Adjustment:
                            transactionDetailList = transactionDetailList.Where(t => t.Transaction.AdjustmentId == allocation.TransactionRefId);
                            break;
                    }
                }

                decimal amount = allocation.Amount;
                int count = 0;

                var transactionDetails = transactionDetailList.ToList();

                foreach (var transactionDetail in transactionDetails) {
                    int transactionRefId = transactionDetail.Transaction.TransactionType == TransactionType.Receipt ? transactionDetail.ReceiptDetail.ReceiptId : transactionDetail.Transaction.TransactionType == TransactionType.NonBsp ? transactionDetail.NonBspDetail.NonBspId : transactionDetail.Transaction.TransactionType == TransactionType.Payment ? transactionDetail.PaymentDetail.PaymentId : (transactionDetail.Transaction.TransactionType == TransactionType.Invoice || transactionDetail.Transaction.TransactionType == TransactionType.CreditNote) ? transactionDetail.InvoiceDetail.InvoiceId : transactionDetail.Transaction.TransactionType == TransactionType.Journal ? transactionDetail.JournalDetail.JournalId : transactionDetail.Transaction.AdjustmentId;
                    int transactionDetailRefId = transactionDetail.Transaction.TransactionType == TransactionType.Receipt ? transactionDetail.ReceiptDetailId : transactionDetail.Transaction.TransactionType == TransactionType.NonBsp ? transactionDetail.NonBspDetailId : transactionDetail.Transaction.TransactionType == TransactionType.Payment ? transactionDetail.PaymentDetailId : (transactionDetail.Transaction.TransactionType == TransactionType.Invoice || transactionDetail.Transaction.TransactionType == TransactionType.CreditNote) ? transactionDetail.InvoiceDetailId : transactionDetail.Transaction.TransactionType == TransactionType.Journal ? transactionDetail.JournalDetailId : transactionDetail.Transaction.AdjustmentId;

                    decimal netValue = 0;
                    count++;

                    if (transactionMatchViewStatus == TransactionMatchViewStatus.NotSaved) {
                        if (amount == 0)
                            break;

                        netValue = transactionDetail.Amount + transactionDetail.Tax - (transactionDetail.InvoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote ? -1 : 1) * (transactionDetail.InvoiceDetail.Discount + transactionDetail.InvoiceDetail.DiscountTax) - transactionDetail.ReceiptDetail.MerchantFee - transactionDetail.ReceiptDetail.MerchantFeeTax - (transactionDetail.TransactionDetailAllocations.Sum(t => (decimal?)t.Amount) ?? 0);

                        if (count == transactionDetails.Count) {
                            netValue = amount;
                            amount = 0;
                        }
                        else {
                            amount -= netValue;
                        }
                    }
                    else {
                        netValue = amount;
                    }

                    if (transactionMatchViewStatus == TransactionMatchViewStatus.Saved || netValue != 0) {
                        newAllocationList.Add(new TransactionDetailAllocationModel {
                            TransactionDetailOrAllocationId = allocation.TransactionDetailOrAllocationId,
                            TransactionId = allocation.TransactionId,
                            TransactionDetailId = transactionDetail.Id,
                            TransactionRefId = transactionRefId,
                            TransactionDetailRefId = transactionDetailRefId,
                            TransactionType = transactionDetail.Transaction.TransactionType,
                            SignType = allocation.SignType,
                            Amount = netValue,
                            Reference = allocation.Reference,
                            TransactionMatchStatus = allocation.TransactionMatchStatus,
                            IsMasterDocument = allocation.IsMasterDocument
                        });
                    }
                }
            }

            allocationList = newAllocationList;
            return true;
        }

        private static bool ManageAutoMatches(AppLazyContext lazyContext, LedgerType allocationType, List<TransactionDetailAllocationModel> allocationList, bool resolveInvoicePayments = false) {
            var detailIds = new List<int>();

            foreach (var allocation in allocationList.Where(t => (allocationType == LedgerType.DebtorLedger && (t.TransactionType == TransactionType.Invoice || t.TransactionType == TransactionType.CreditNote)) || (allocationType == LedgerType.CreditorLedger && t.TransactionType == TransactionType.NonBsp)).ToList()) {
                switch (allocation.TransactionType) {
                    case TransactionType.NonBsp:
                        var nonBsp = lazyContext.NonBsp.Single(t1 => t1.NonBspDetails.Any(t2 => t2.Id == allocation.TransactionDetailRefId));

                        if (nonBsp.IsMatched)
                            detailIds.AddRange(nonBsp.NonBspDetails.Select(t => t.Id));

                        break;
                    case TransactionType.Payment:
                        var payment = lazyContext.Payment.Single(t1 => t1.PaymentDetails.Any(t2 => t2.Id == allocation.TransactionDetailRefId));

                        if (payment.IsMatched)
                            detailIds.AddRange(payment.PaymentDetails.Select(t => t.Id));

                        break;
                    case TransactionType.Invoice:
                    case TransactionType.CreditNote:
                        var invoice = lazyContext.Invoice.Single(t1 => t1.InvoiceDetails.Any(t2 => t2.Id == allocation.TransactionDetailRefId));

                        int[] invoiceDetailIds = invoice.InvoiceDetails.Select(t => t.Id).ToArray();
                        int[] allocationDetailIds = allocationList.Select(t => t.TransactionDetailRefId).ToArray();

                        if (invoice.IsMatched)
                            detailIds.AddRange(invoiceDetailIds);

                        if (!resolveInvoicePayments || invoiceDetailIds.All(t => allocationDetailIds.Contains(t)))
                            continue;

                        foreach (var invoiceDetail in invoice.InvoiceDetails.Where(t => !allocationDetailIds.Contains(t.Id) && t.IsPayment).ToList()) {
                            decimal amount = invoiceDetail.Amount + invoiceDetail.Tax + invoiceDetail.PaymentTax - invoiceDetail.Discount - invoiceDetail.DiscountTax;
                            var invoiceDetailMatch = invoice.InvoiceDetails.FirstOrDefault(t => !allocationDetailIds.Contains(t.Id) && !t.IsPayment && t.Amount + t.Tax - t.Discount - t.DiscountTax == -amount);

                            if (invoiceDetailMatch == null)
                                continue;

                            var transactionDetail = invoiceDetail.TransactionDetails.SingleOrDefault(t => t.LedgerType == LedgerType.DebtorLedger && t.DebtorId == invoiceDetail.Invoice.DebtorId && t.TransactionDetailType == TransactionDetailType.Normal);
                            var transactionDetailMatch = invoiceDetail.TransactionDetails.SingleOrDefault(t => t.LedgerType == LedgerType.DebtorLedger && t.DebtorId == invoiceDetailMatch.Invoice.DebtorId && t.TransactionDetailType == TransactionDetailType.Normal);

                            if (transactionDetail == null || transactionDetailMatch == null)
                                continue;

                            allocationList.Add(new TransactionDetailAllocationModel {
                                TransactionType = invoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote ? TransactionType.CreditNote : TransactionType.Invoice,
                                SignType = SignType.Credit,
                                TransactionDetailOrAllocationId = -invoiceDetail.Id,
                                TransactionId = transactionDetail.TransactionId,
                                TransactionDetailId = transactionDetail.Id,
                                TransactionRefId = invoiceDetail.InvoiceId,
                                TransactionDetailRefId = invoiceDetail.Id,
                                Amount = amount
                            });

                            allocationList.Add(new TransactionDetailAllocationModel {
                                TransactionType = invoiceDetailMatch.Invoice.InvoiceType == InvoiceType.CreditNote ? TransactionType.CreditNote : TransactionType.Invoice,
                                SignType = SignType.Debit,
                                TransactionDetailOrAllocationId = -invoiceDetailMatch.Id,
                                TransactionId = transactionDetailMatch.TransactionId,
                                TransactionDetailId = transactionDetailMatch.Id,
                                TransactionRefId = invoiceDetailMatch.InvoiceId,
                                TransactionDetailRefId = invoiceDetailMatch.Id,
                                Amount = -amount
                            });
                        }

                        break;
                }
            }

            if (detailIds.Count > 0)
                allocationList = allocationList.Where(t => !detailIds.Contains(t.TransactionDetailRefId)).ToList();

            return true;
        }

        private static bool ManageZeroValueInvoices(AppLazyContext lazyContext, List<TransactionDetailAllocationModel> allocationList) {
            using (var ts = Utils.CreateTransactionScope()) {
                var invoiceDetailIds = new List<int>();

                foreach (var row in allocationList.Where(t => (t.TransactionType == TransactionType.Invoice || t.TransactionType == TransactionType.CreditNote) && t.Amount == 0)) {
                    var invoice = lazyContext.Invoice.SingleOrDefault(t1 => t1.InvoiceDetails.Any(t2 => t2.Id == row.TransactionDetailRefId));

                    if (invoice?.TotalAmount == 0) {
                        var q = lazyContext.Invoice.Find(invoice.Id);
                        q.IsMatched = true;
                        lazyContext.Save(q, false);
                        invoiceDetailIds.AddRange(invoice.InvoiceDetails.Select(t => t.Id));
                    }
                }

                if (invoiceDetailIds.Count > 0)
                    allocationList = allocationList.Where(t => !invoiceDetailIds.Contains(t.TransactionDetailRefId)).ToList();

                ts.Complete();
                return true;
            }
        }

        private bool UnmatchSelections(AppLazyContext lazyContext, List<TransactionDetailAllocationModel> allocationList) {
            if (!HttpContext.IsAdministrator())
                throw new UnauthorizedAccessException(AppConstants.UnauthorisedAccess);

            var parentIds = new List<int>();
            var groupNos = new List<int>();

            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var allocation in allocationList.Where(t => t.TransactionDetailOrAllocationId > 0)) {
                    var transactionDetailAllocation = lazyContext.TransactionDetailAllocation.Find((int)allocation.TransactionDetailOrAllocationId);
                    int parentId = transactionDetailAllocation.TransactionDetail.DebtorId > 0 ? transactionDetailAllocation.TransactionDetail.DebtorId : transactionDetailAllocation.TransactionDetail.CreditorId;

                    if (!parentIds.Contains(parentId))
                        parentIds.Add(parentId);

                    if (parentIds.Count > 1) {
                        const string message = "A processing error has resulted in an invalid allocation entry. It has been logged for review.";
                        string error = string.Format("{0} Transaction Detail ID: {1}.", message, transactionDetailAllocation.TransactionDetailId);
                        ExceptionManager.HandleException(HttpContext, ClassName, "UnmatchSelections", new InvalidOperationException(error));
                        throw new UnreportedException(message);
                    }

                    if (!groupNos.Contains(transactionDetailAllocation.GroupNo))
                        groupNos.Add(transactionDetailAllocation.GroupNo);

                    lazyContext.Delete(transactionDetailAllocation, true);
                }

                lazyContext.RemoveRange(lazyContext.TransactionDetailAllocation.Where(t => groupNos.Contains(t.GroupNo)));
                lazyContext.SaveChanges();

                ts.Complete();
            }

            return true;
        }

        private static List<TransactionDetailAllocation> CreateAllocations(AppLazyContext lazyContext, TransactionDetailAllocationModel allocation, int groupNo, int receiptDetailId, bool isCreditAllocation, bool isCreditCardDebtor, bool processPartials) {
            var allocationList = new List<TransactionDetailAllocation>();
            var transactionDetail = lazyContext.TransactionDetail.Find(allocation.TransactionDetailId);

            if (transactionDetail == null)
                return allocationList;

            if (transactionDetail.TransactionDetailType != TransactionDetailType.Normal && transactionDetail.TransactionDetailType != TransactionDetailType.ExcludeFromSalesAnalysis)
                return allocationList;

            var allocation1 = new TransactionDetailAllocation {
                Id = 0,
                TransactionDetailId = allocation.TransactionDetailId,
                TransactionDetail = lazyContext.TransactionDetail.Find(allocation.TransactionDetailId),
                ReceiptDetailId = -1,
                ReceiptDetail = lazyContext.ReceiptDetail.Find(-1),
                NonBspDetailId = -1,
                NonBspDetail = lazyContext.NonBspDetail.Find(-1),
                PaymentDetailId = -1,
                PaymentDetail = lazyContext.PaymentDetail.Find(-1),
                InvoiceDetailId = -1,
                InvoiceDetail = lazyContext.InvoiceDetail.Find(-1),
                JournalDetailId = -1,
                JournalDetail = lazyContext.JournalDetail.Find(-1),
                AdjustmentId = -1,
                Adjustment = lazyContext.Adjustment.Find(-1),
                Amount = allocation.Amount,
                MerchantFee = allocation.MerchantFee,
                MerchantFeeTax = allocation.MerchantFeeTax,
                Reference = allocation.Reference,
                GroupNo = groupNo,
                TransactionMatchStatus = TransactionMatchStatus.Matched
            };

            switch (allocation.TransactionType) {
                case TransactionType.Receipt:
                    allocation1.ReceiptDetailId = allocation.TransactionDetailRefId;
                    allocation1.ReceiptDetail = lazyContext.ReceiptDetail.Find(allocation.TransactionDetailRefId);
                    break;
                case TransactionType.NonBsp:
                    allocation1.NonBspDetailId = allocation.TransactionDetailRefId;
                    allocation1.NonBspDetail = lazyContext.NonBspDetail.Find(allocation.TransactionDetailRefId);
                    break;
                case TransactionType.Payment:
                    allocation1.PaymentDetailId = allocation.TransactionDetailRefId;
                    allocation1.PaymentDetail = lazyContext.PaymentDetail.Find(allocation.TransactionDetailRefId);
                    break;
                case TransactionType.Invoice:
                case TransactionType.CreditNote:
                    allocation1.InvoiceDetailId = allocation.TransactionDetailRefId;
                    allocation1.InvoiceDetail = lazyContext.InvoiceDetail.Find(allocation.TransactionDetailRefId);
                    break;
                case TransactionType.Journal:
                    allocation1.JournalDetailId = allocation.TransactionDetailRefId;
                    allocation1.JournalDetail = lazyContext.JournalDetail.Find(allocation.TransactionDetailRefId);
                    break;
                case TransactionType.Adjustment:
                    allocation1.AdjustmentId = allocation.TransactionDetailRefId;
                    allocation1.Adjustment = lazyContext.Adjustment.Find(allocation.TransactionDetailRefId);
                    break;
            }

            decimal allocationAmount = allocation.Amount;
            decimal transactionAmount = transactionDetail.Amount + transactionDetail.Tax - (transactionDetail.InvoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote ? -1 : 1) * (transactionDetail.InvoiceDetail.Discount + transactionDetail.InvoiceDetail.DiscountTax);

            if (isCreditCardDebtor)
                transactionAmount += transactionDetail.ReceiptDetail.MerchantFee + transactionDetail.ReceiptDetail.MerchantFeeTax;

            //allocation1.Amount = allocationAmount;
            //allocation1.MerchantFee = 0;
            //allocation1.MerchantFeeTax = 0;

            if (isCreditCardDebtor) {
                //if (allocation.TransactionType == TransactionType.Receipt && allocation1.ReceiptDetailId != receiptDetailId) {
                //    ReceiptDetail receiptDetail;
                //    decimal merchantFeeGross;

                //    receiptDetail = transactionDetail.ReceiptDetail;
                //    merchantFeeGross = transactionDetail.Amount + transactionDetail.Tax - allocationAmount;

                //    decimal merchantFeeTaxRate = receiptDetail.MerchantFee + receiptDetail.MerchantFeeTax == 0 ? 0 : receiptDetail.MerchantFeeTax / (receiptDetail.MerchantFee + receiptDetail.MerchantFeeTax);
                //    decimal merchantFeeTax = Math.Round(merchantFeeGross * merchantFeeTaxRate, 2);

                //    allocation1.MerchantFee = merchantFeeGross - merchantFeeTax;
                //    allocation1.MerchantFeeTax = merchantFeeTax;
                //}

                allocationList.Add(allocation1);
                return allocationList;
            }

            allocationList.Add(allocation1);

            if (!processPartials || (!isCreditAllocation && allocation.TransactionType == TransactionType.Receipt))
                return allocationList;

            decimal remainder;

            if (isCreditAllocation) {
                remainder = transactionAmount - allocationAmount;
            }
            else {
                remainder = -transactionAmount - ((allocation.SignType == SignType.Debit ? -1 : 1) * allocationAmount);
            }

            if (transactionDetail.InvoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote)
                remainder = -remainder;

            if (remainder == 0)
                return allocationList;

            var allocation2 = lazyContext.TransactionDetailAllocation.Find((int)allocation.TransactionDetailOrAllocationId);

            if (allocation2 == null) {
                allocation2 = allocation1.Clone() as TransactionDetailAllocation;
                allocation2.Id = 0;
                allocation2.MerchantFee = 0;
                allocation2.MerchantFeeTax = 0;
                allocation2.Reference = allocation1.TransactionDetail.Reference;
                allocation2.GroupNo = groupNo;
                allocation2.TransactionMatchStatus = TransactionMatchStatus.Partial;

                allocation2.TransactionDetail = lazyContext.TransactionDetail.Find(allocation2.TransactionDetailId);
                allocation2.ReceiptDetail = lazyContext.ReceiptDetail.Find(allocation2.ReceiptDetailId);
                allocation2.NonBspDetail = lazyContext.NonBspDetail.Find(allocation2.NonBspDetailId);
                allocation2.PaymentDetail = lazyContext.PaymentDetail.Find(allocation2.PaymentDetailId);
                allocation2.InvoiceDetail = lazyContext.InvoiceDetail.Find(allocation2.InvoiceDetailId);
                allocation2.JournalDetail = lazyContext.JournalDetail.Find(allocation2.JournalDetailId);
                allocation2.Adjustment = lazyContext.Adjustment.Find(allocation2.AdjustmentId);

                if (isCreditAllocation) {
                    allocation2.Amount = remainder;
                }
                else {
                    allocation2.Amount = -remainder;

                    allocation2.ReceiptDetailId = transactionDetail.ReceiptDetailId;
                    allocation2.ReceiptDetail = lazyContext.ReceiptDetail.Find(transactionDetail.ReceiptDetailId);

                    switch (transactionDetail.Transaction.TransactionType) {
                        case TransactionType.NonBsp:
                            allocation2.NonBspDetailId = transactionDetail.NonBspDetailId;
                            allocation2.NonBspDetail = lazyContext.NonBspDetail.Find(transactionDetail.NonBspDetailId);
                            break;
                        case TransactionType.Payment:
                            allocation2.PaymentDetailId = transactionDetail.PaymentDetailId;
                            allocation2.PaymentDetail = lazyContext.PaymentDetail.Find(transactionDetail.PaymentDetailId);
                            break;
                        case TransactionType.Invoice:
                        case TransactionType.CreditNote:
                            allocation2.InvoiceDetailId = transactionDetail.InvoiceDetailId;
                            allocation2.InvoiceDetail = lazyContext.InvoiceDetail.Find(transactionDetail.InvoiceDetailId);
                            break;
                        case TransactionType.Journal:
                            allocation2.JournalDetailId = transactionDetail.JournalDetailId;
                            allocation2.JournalDetail = lazyContext.JournalDetail.Find(transactionDetail.JournalDetailId);
                            break;
                        case TransactionType.Adjustment:
                            allocation2.AdjustmentId = transactionDetail.Transaction.AdjustmentId;
                            allocation2.Adjustment = lazyContext.Adjustment.Find(transactionDetail.Transaction.AdjustmentId);
                            break;
                    }
                }

                allocationList.Add(allocation2);
            }
            else if (allocation2.Amount == allocationAmount) {
                lazyContext.Delete(allocation2, false);
            }
            else {
                allocation2.Amount -= allocationAmount;
                allocationList.Add(allocation2);
            }

            return allocationList;
        }
    }

    public static class FinancialIntegrityCommon {
        public static void InsertMissingTransactions(AppLazyContext lazyContext, int customerId) {
            foreach (var receipt in lazyContext.Receipt.Where(t => t.Id > 0 && t.Transactions.Count == 0 && t.ReceiptDetails.Count > 0 && !t.IsLegacy).ToList()) {
                receipt.ReceiptDetails[0].UpdateTransactions(lazyContext, customerId);
            }

            foreach (var bsp in lazyContext.Bsp.Where(t => t.Id > 0 && t.Transactions.Count == 0 && t.BspDetails.Count > 0 && !t.IsLegacy).ToList()) {
                bsp.BspDetails[0].UpdateTransactions(lazyContext, customerId);
            }

            foreach (var nonBsp in lazyContext.NonBsp.Where(t => t.Id > 0 && t.Transactions.Count == 0 && t.NonBspDetails.Count > 0 && !t.IsLegacy).ToList()) {
                nonBsp.NonBspDetails[0].UpdateTransactions(lazyContext, customerId);
            }

            foreach (var payment in lazyContext.Payment.Where(t => t.Id > 0 && t.PaymentDetails.Count > 0 && t.Transactions.Count == 0 && !t.IsLegacy).ToList()) {
                payment.PaymentDetails[0].UpdateTransactions(lazyContext, customerId);
            }

            foreach (var invoice in lazyContext.Invoice.Where(t => t.Id > 0 && t.InvoiceDetails.Count > 0 && t.Transactions.Count == 0).ToList()) {
                invoice.InvoiceDetails[0].UpdateTransactions(lazyContext, customerId);
            }

            foreach (var journal in lazyContext.Journal.Where(t => t.Id > 0 && t.Transactions.Count == 0 && !t.IsLegacy).ToList()) {
                journal.JournalDetails[0].UpdateTransactions(lazyContext, customerId);
            }

            foreach (var adjustment in lazyContext.Adjustment.Where(t => t.Id > 0 && t.Transactions.Count == 0).ToList()) {
                adjustment.UpdateTransactions(lazyContext, customerId);
            }
        }

        public static void CloseOffFiscalPeriods(AppMainContext context) {
            int fiscalPeriodAutoCloseOffMonths = int.Parse(context.AppSetting.Find("FiscalPeriodAutoCloseOffMonths").Value);

            if (fiscalPeriodAutoCloseOffMonths <= 0)
                return;

            DateTime endDate = context.SettingDetail.Include(t => t.Setting).OrderByDescending(t => t.Setting.FiscalYearStartDate).FirstOrDefault(t => t.Setting.FiscalYearStartDate < DateTime.Today)?.Setting.FiscalYearStartDate.AddMonths(-fiscalPeriodAutoCloseOffMonths) ?? DateTime.MinValue;

            if (endDate == DateTime.MinValue)
                return;

            foreach (var settingDetail in context.SettingDetail.Where(t => (!t.IsUserClosed || !t.IsAdminClosed) && t.FiscalPeriodEndDate < endDate).ToList()) {
                settingDetail.IsUserClosed = true;
                settingDetail.IsAdminClosed = true;
                context.Save(settingDetail, false);
            }
        }

        public static void RunFinancialIntegrityCheck(AppAdminContext adminContext, AppLazyContext lazyContext, string countryCode, int customerId, int agencyId) {
            var transactionDetail = GetTransactionDetailQuery(lazyContext, agencyId);

            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var row in transactionDetail.Where(t => t.IntegrityCheckFailed).ToList()) {
                    row.IntegrityCheckFailed = false;
                    lazyContext.Attach(row);
                }

                lazyContext.SaveChanges();
                IQueryable<TransactionDetail> glAccount = null;

                foreach (var row in lazyContext.Setting.Where(t => t.Id > 0).OrderByDescending(t => t.FiscalYearStartDate).ToList()) {
                    var glAccountBase = transactionDetail.Where(t => t.LedgerType == LedgerType.GeneralLedger && (t.ChartOfAccount.RowType == RowType.Normal || t.ChartOfAccount.RowType == RowType.RetainedProfits) && t.Transaction.DocumentDate <= row.FiscalYearEndDate);

                    foreach (var ledgerType in ((LedgerType[])Enum.GetValues(typeof(LedgerType))).Where(t => t != LedgerType.None && t != LedgerType.CurrentAccountOnly).ToList()) {
                        var ledgerAccount = transactionDetail.Where(t => t.LedgerType == ledgerType && t.Transaction.DocumentDate <= row.FiscalYearEndDate);

                        switch (ledgerType) {
                            case LedgerType.ClientLedger:
                                glAccount = glAccountBase.Where(t => t.ChartOfAccountId == row.ClientControlAccountId);
                                UpdateIntegrityFailures(lazyContext, ledgerType, glAccount, ledgerAccount);
                                break;
                            case LedgerType.DebtorLedger:
                                glAccount = glAccountBase.Where(t => t.ChartOfAccountId == row.DebtorControlAccountId);
                                UpdateIntegrityFailures(lazyContext, ledgerType, glAccount, ledgerAccount);
                                break;
                            case LedgerType.CreditorLedger:
                                glAccount = glAccountBase.Where(t => t.ChartOfAccountId == row.CreditorControlAccountId);
                                UpdateIntegrityFailures(lazyContext, ledgerType, glAccount, ledgerAccount);

                                glAccount = glAccountBase.Where(t => t.ChartOfAccountId == row.BspAccrualAccountId);
                                var bspAccrualAccount = Creditor.GetBspAccrualQuery(lazyContext, agencyId, PaidStatusReportOption.All, LedgerDocumentType.Reconciliation, DateTime.MaxValue, true);
                                UpdateIntegrityFailures(lazyContext, ledgerType, glAccount, bspAccrualAccount, -1);

                                glAccount = glAccountBase.Where(t => t.ChartOfAccountId == row.SupplierReturnsAccountId);
                                var supplierReturnsAccount = ledgerAccount.Where(t => t.Transaction.TransactionType != TransactionType.Bsp && t.CreditorId <= 0 && t.Transaction.DocumentDate <= row.FiscalYearEndDate);
                                UpdateIntegrityFailures(lazyContext, ledgerType, glAccount, supplierReturnsAccount);
                                break;
                            case LedgerType.GeneralLedger:
                                UpdateIntegrityFailures(lazyContext, ledgerType, glAccountBase, ledgerAccount);
                                break;
                        }
                    }
                }

                ts.Complete();
            }

            bool integrityCheckFailed = transactionDetail.Any(t => t.IntegrityCheckFailed);
            var q = lazyContext.Agency.Find(agencyId);

            q.FinancialIntegrityCheckLastRunTime = DateTime.UtcNow;
            q.FinancialIntegrityStatus = integrityCheckFailed ? FinancialIntegrityStatus.Failed : FinancialIntegrityStatus.Passed;
            q.DebtorCreditAllocationStatus = GetDebtorCreditAllocationErrorList(lazyContext, agencyId).Any() ? FinancialIntegrityStatus.Warning : FinancialIntegrityStatus.Passed;
            q.CreditorCreditAllocationStatus = GetCreditorCreditAllocationErrorList(lazyContext, agencyId).Any() ? FinancialIntegrityStatus.Warning : FinancialIntegrityStatus.Passed;
            q.MissingTransactionsStatus = GetMissingTransactionsList(lazyContext, agencyId).Any() ? FinancialIntegrityStatus.Warning : FinancialIntegrityStatus.Passed;
            q.TaxRateConflictStatus = GetTaxRateConflictList(adminContext, lazyContext, countryCode).Any() ? FinancialIntegrityStatus.Warning : FinancialIntegrityStatus.Passed;
            q.GeneralLedgerSettingErrorStatus = GetGeneralLedgerSettingErrorList(lazyContext, customerId).Count > 0 ? FinancialIntegrityStatus.Warning : FinancialIntegrityStatus.Passed;
            q.MissingAutoGeneratedDocumentStatus = GetMissingAutoGeneratedDocumentList(lazyContext, agencyId).Sum(t => t.Value) > 0 ? FinancialIntegrityStatus.Warning : FinancialIntegrityStatus.Passed;

            lazyContext.Save(q, false);
        }

        private static void UpdateIntegrityFailures(AppLazyContext lazyContext, LedgerType ledgerType, IQueryable<TransactionDetail> glAccount, IQueryable<TransactionDetail> ledgerAccount, int bspAccrualAccountId = 0) {
            if (ledgerType == LedgerType.GeneralLedger) {
                #region Loyalty Scheme Receipts
                var q = glAccount.Where(t => t.Transaction.NonBsp.LoyaltySchemeReceiptDetailId > 0)
                .GroupBy(t => new { t.TransactionId, ReceiptId = t.Transaction.NonBsp.LoyaltySchemeReceiptDetailId }).Select(row => new {
                    row.Key.TransactionId,
                    row.Key.ReceiptId,
                    Amount1 = row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0,
                    Amount2 = glAccount.Where(t => t.Transaction.ReceiptId == row.Key.ReceiptId).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0
                }).Where(t => t.Amount1 != -t.Amount2);

                int[] ids = q.Select(t => t.TransactionId).Distinct().ToArray();

                if (ids.Length > 0) {
                    var predicate = PredicateBuilder.False<TransactionDetail>();

                    foreach (var array in ids.Split(2100).ToArray()) {
                        predicate = predicate.Or(t => array.Contains(t.TransactionId));
                    }

                    foreach (var row in glAccount.Where(predicate).ToList()) {
                        row.IntegrityCheckFailed = true;
                        lazyContext.Attach(row);
                    }
                }

                ids = q.Select(t => t.ReceiptId).Distinct().ToArray();

                if (ids.Length > 0) {
                    var predicate = PredicateBuilder.False<TransactionDetail>();

                    foreach (var array in ids.Split(2100).ToArray()) {
                        predicate = predicate.Or(t => array.Contains(t.Transaction.ReceiptId));
                    }

                    foreach (var row in glAccount.Where(predicate).ToList()) {
                        row.IntegrityCheckFailed = true;
                        lazyContext.Attach(row);
                    }
                }
                #endregion

                #region Supplier Other Commission Receipts
                q = glAccount.Where(t => t.Transaction.NonBsp.SupplierOtherCommissionReceiptId > 0)
                .GroupBy(t => new { t.TransactionId, ReceiptId = t.Transaction.NonBsp.SupplierOtherCommissionReceiptId }).Select(row => new {
                    row.Key.TransactionId,
                    row.Key.ReceiptId,
                    Amount1 = row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0,
                    Amount2 = glAccount.Where(t => t.Transaction.ReceiptId == row.Key.ReceiptId).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0
                }).Where(t => t.Amount1 != -t.Amount2);

                ids = q.Select(t => t.TransactionId).Distinct().ToArray();

                if (ids.Length > 0) {
                    var predicate = PredicateBuilder.False<TransactionDetail>();

                    foreach (var array in ids.Split(2100).ToArray()) {
                        predicate = predicate.Or(t => array.Contains(t.TransactionId));
                    }

                    foreach (var row in glAccount.Where(predicate).ToList()) {
                        row.IntegrityCheckFailed = true;
                        lazyContext.Attach(row);
                    }
                }

                ids = q.Select(t => t.ReceiptId).Distinct().ToArray();

                if (ids.Length > 0) {
                    var predicate = PredicateBuilder.False<TransactionDetail>();

                    foreach (var array in ids.Split(2100).ToArray()) {
                        predicate = predicate.Or(t => array.Contains(t.Transaction.ReceiptId));
                    }

                    foreach (var row in glAccount.Where(predicate).ToList()) {
                        row.IntegrityCheckFailed = true;
                        lazyContext.Attach(row);
                    }
                }
                #endregion

                #region Transfer Receipts
                ids = glAccount.Where(t => t.Transaction.Receipt.ReceiptType == ReceiptType.Transfer).AsEnumerable()
                .GroupBy(t => new { t.Transaction.Receipt.DocumentNo }).Select(row => new {
                    ReceiptIds = row.Select(t => t.Transaction.ReceiptId).ToArray(),
                    row.Key.DocumentNo,
                    Amount1 = row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0,
                    Amount2 = glAccount.Where(t => t.Transaction.Receipt.ReceiptType == ReceiptType.Transfer && t.Transaction.DocumentNo == row.Key.DocumentNo).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0
                }).Where(t => t.Amount1 != -t.Amount2).Select(t => t.ReceiptIds).SelectMany(t => t).Distinct().ToArray();

                if (ids.Length > 0) {
                    var predicate = PredicateBuilder.False<TransactionDetail>();

                    foreach (var array in ids.Split(2100).ToArray()) {
                        predicate = predicate.Or(t => array.Contains(t.Transaction.ReceiptId));
                    }

                    foreach (var row in glAccount.Where(predicate).ToList()) {
                        row.IntegrityCheckFailed = true;
                        lazyContext.Attach(row);
                    }
                }
                #endregion

                #region Agency Credit Card BSP Returns
                ids = glAccount.Where(t => t.Transaction.BspId > 0 && t.Transaction.Bsp.AgencyCreditCardBspId > 0).Select(row => new {
                    row.Transaction.Bsp.AgencyCreditCardBspId,
                    AmountGross = row.Amount + row.Tax
                }).Concat(glAccount.Where(t => t.Transaction.NonBspId > 0 && t.Transaction.NonBsp.AgencyCreditCardBspId > 0).Select(row => new {
                    row.Transaction.NonBsp.AgencyCreditCardBspId,
                    AmountGross = row.Amount + row.Tax
                })).GroupBy(t => t.AgencyCreditCardBspId).Select(row => new {
                    AgencyCreditCardBspId = row.Key,
                    AmountGross = row.Sum(t => (decimal?)t.AmountGross) ?? 0
                }).Where(t => t.AmountGross != 0).Select(t => t.AgencyCreditCardBspId).Distinct().ToArray();

                if (ids.Length > 0) {
                    var predicate = PredicateBuilder.False<TransactionDetail>();

                    foreach (var array in ids.Split(2100).ToArray()) {
                        predicate = predicate.Or(t => array.Contains(t.Transaction.Bsp.AgencyCreditCardBspId));
                    }

                    foreach (var row in glAccount.Where(predicate).ToList()) {
                        row.IntegrityCheckFailed = true;
                        lazyContext.Attach(row);
                    }

                    predicate = PredicateBuilder.False<TransactionDetail>();

                    foreach (var array in ids.Split(2100).ToArray()) {
                        predicate = predicate.Or(t => array.Contains(t.Transaction.NonBsp.AgencyCreditCardBspId));
                    }

                    foreach (var row in glAccount.Where(predicate).ToList()) {
                        row.IntegrityCheckFailed = true;
                        lazyContext.Attach(row);
                    }
                }
                #endregion

                #region Agency Credit Card Non-BSP Returns
                ids = glAccount.Where(t => t.Transaction.NonBspId > 0 && t.Transaction.NonBsp.AgencyCreditCardNonBspId > 0)
                .GroupBy(t => new { NonBspId = t.Transaction.NonBsp.AgencyCreditCardNonBspId }).Select(row => new {
                    row.Key.NonBspId,
                    AmountGross = row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0
                }).Where(t => t.AmountGross != 0).Select(t => t.NonBspId).Distinct().ToArray();

                if (ids.Length > 0) {
                    var predicate = PredicateBuilder.False<TransactionDetail>();

                    foreach (var array in ids.Split(2100).ToArray()) {
                        predicate = predicate.Or(t => array.Contains(t.Transaction.NonBsp.AgencyCreditCardNonBspId));
                    }

                    foreach (var row in glAccount.Where(predicate).ToList()) {
                        row.IntegrityCheckFailed = true;
                        lazyContext.Attach(row);
                    }
                }
                #endregion

                #region Other
                ids = glAccount.Where(t => !(t.Transaction.Receipt.ReceiptType == ReceiptType.OtherCommission && t.Transaction.Receipt.SupplierCommissionType == SupplierCommissionType.Creditor) && t.Transaction.Receipt.ReceiptType != ReceiptType.Transfer && t.Transaction.Bsp.AgencyCreditCardBspId <= 0 && t.Transaction.NonBsp.AgencyCreditCardBspId <= 0 && t.Transaction.NonBsp.AgencyCreditCardNonBspId <= 0 && t.Transaction.NonBsp.SupplierOtherCommissionReceiptId <= 0)
                .GroupBy(t => new { t.TransactionId }).Select(row => new {
                    row.Key.TransactionId,
                    AmountGross = row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0
                }).Where(t => t.AmountGross != 0).Select(t => t.TransactionId).Distinct().ToArray();

                if (ids.Length > 0) {
                    var predicate = PredicateBuilder.False<TransactionDetail>();

                    foreach (var array in ids.Split(2100).ToArray()) {
                        predicate = predicate.Or(t => array.Contains(t.TransactionId));
                    }

                    foreach (var row in glAccount.Where(predicate).ToList()) {
                        row.IntegrityCheckFailed = true;
                        lazyContext.Attach(row);
                    }
                }
                #endregion
            }
            else {
                if (bspAccrualAccountId == -1)
                    return;

                int[] ids = null;
                int[] transactionIds = null;

                if (bspAccrualAccountId > 0) {
                    transactionIds = ledgerAccount.AsEnumerable().Select(t => t.TransactionId).Distinct().ToArray();

                    ids = ledgerAccount.AsEnumerable().Where(t => (t.LedgerType == LedgerType.ClientLedger && t.TransactionDetailType == TransactionDetailType.Normal && t.Transaction.Bsp.AgencyCreditCardBspId <= 0) || t.Transaction.Bsp.AgencyCreditCardBspId > 0).Select(row => new {
                        row.Transaction,
                        AmountGross = row.Amount + row.Tax
                    }).Concat(glAccount.Where(t => transactionIds.Contains(t.TransactionId)).Select(row => new {
                        row.Transaction,
                        AmountGross = row.Amount + row.Tax
                    })).GroupBy(row => new {
                        Bsp = row.Transaction.Bsp.AgencyCreditCardBspId > 0 ? row.Transaction.Bsp.AgencyCreditCardBsp : row.Transaction.Bsp
                    }).Where(t1 => t1.Sum(t2 => t2.AmountGross) != 0).SelectMany(t => t.Key.Bsp.Transactions).Select(t => t.Id).Distinct().ToArray();
                }
                else {
                    ids = ledgerAccount.Select(row => new {
                        row.TransactionId,
                        AmountGross = row.Amount + row.Tax
                    }).Concat(glAccount.Select(row => new {
                        row.TransactionId,
                        AmountGross = (bspAccrualAccountId == 0 ? -1 : 1) * (row.Amount + row.Tax)
                    })).GroupBy(row => new {
                        row.TransactionId
                    }).Where(t1 => t1.Sum(t2 => t2.AmountGross) != 0).Select(t1 => t1.Key.TransactionId).Distinct().ToArray();
                }

                if (ids.Length > 0) {
                    if (bspAccrualAccountId > 0)
                        ledgerAccount = lazyContext.TransactionDetail.Where(t => transactionIds.Contains(t.TransactionId) && t.ChartOfAccountId == bspAccrualAccountId);

                    foreach (var array in ids.Split(2100).ToArray()) {
                        foreach (var row in ledgerAccount.Where(t => array.Contains(t.TransactionId)).ToList()) {
                            row.IntegrityCheckFailed = true;
                            lazyContext.Attach(row);
                        }

                        var q = glAccount.Where(t => array.Contains(t.TransactionId)).ToList();

                        if (q.Count > 0 && q.Sum(t => t.Amount + t.Tax) != 0) {
                            foreach (var row in q) {
                                row.IntegrityCheckFailed = true;
                                lazyContext.Attach(row);
                            }
                        }
                    }
                }
            }

            lazyContext.SaveChanges();
        }

        public static List<FinancialIntegrity> GetFinancialIntegrityList(AppLazyContext lazyContext, int customerId, int agencyId, DateTime runTime, DateTime fiscalPeriodEndDate) {
            var transactionDetail = GetTransactionDetailQuery(lazyContext, agencyId);
            bool failuresExist = transactionDetail.Any(t => t.IntegrityCheckFailed);

            var q = new List<FinancialIntegrity>();
            int i = 0;

            DateTime monthEnd = new DateTime(fiscalPeriodEndDate.Year, fiscalPeriodEndDate.Month, 1).AddMonths(1).AddDays(-1);
            fiscalPeriodEndDate = lazyContext.SettingDetail.SingleOrDefault(t => t.FiscalPeriodEndDate == monthEnd)?.FiscalPeriodEndDate ?? monthEnd;

            DateTime endDate = fiscalPeriodEndDate;

            foreach (var setting in lazyContext.Setting.Include(t => t.SettingDetails).Where(t1 => t1.Id > 0 && t1.SettingDetails.Any(t2 => t2.FiscalPeriodEndDate <= fiscalPeriodEndDate)).OrderByDescending(t => t.FiscalYearStartDate)) {
                fiscalPeriodEndDate = endDate;

                if (fiscalPeriodEndDate > setting.FiscalYearEndDate)
                    fiscalPeriodEndDate = setting.FiscalYearEndDate;

                var ledgerAccountBase = transactionDetail.Where(t => t.Transaction.DocumentDate <= fiscalPeriodEndDate);
                var glAccountBase = transactionDetail.Where(t => t.LedgerType == LedgerType.GeneralLedger && (t.ChartOfAccount.RowType == RowType.Normal || t.ChartOfAccount.RowType == RowType.RetainedProfits) && t.Transaction.DocumentDate <= fiscalPeriodEndDate);

                foreach (var account in FinancialIntegrityAccountList) {
                    IQueryable<TransactionDetail> ledgerAccount = null;
                    IQueryable<TransactionDetail> glAccount = null;
                    IEnumerable<TransactionDetail> bspAccrualAccount = null;

                    GetAccountQuery(lazyContext, account, setting, agencyId, fiscalPeriodEndDate, glAccountBase, ledgerAccountBase, ref glAccount, ref ledgerAccount, ref bspAccrualAccount);

                    decimal glAccountTotal = glAccount.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
                    decimal ledgerAccountTotal = 0;

                    int failureCount = failuresExist ? GetFinancialIntegrityDetailList(lazyContext, setting, agencyId, account.AccountName, endDate).Count() : 0;

                    switch (account.AccountName) {
                        default:
                            ledgerAccountTotal = ledgerAccount.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
                            break;
                        case "BSP Accrual Account":
                            ledgerAccountTotal = bspAccrualAccount.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
                            break;
                        case "Supplier Returns Account":
                            ledgerAccountTotal = ledgerAccount.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
                            break;
                        case "General Ledger":
                            ledgerAccountTotal = 0;
                            break;
                    }

                    q.Add(new FinancialIntegrity {
                        Id = i++,
                        SettingId = setting.Id,
                        AccountName = account.AccountName,
                        FiscalYearStartDate = setting.FiscalYearStartDate,
                        FiscalYearStartDateName = setting.FiscalYearStartDateName,
                        LedgerAccountTotal = ledgerAccountTotal,
                        GlAccountTotal = glAccountTotal,
                        FailureCount = failureCount
                    });
                }
            }

            var settingCurrent = Setting.GetRow(customerId, runTime.Date);

            foreach (var item in FinancialIntegrityAccountList) {
                if (!q.Any(t => t.AccountName == item.AccountName)) {
                    q.Add(new FinancialIntegrity {
                        Id = i++,
                        SettingId = 0,
                        AccountName = item.AccountName,
                        FiscalYearStartDate = settingCurrent.FiscalYearStartDate,
                        FiscalYearStartDateName = settingCurrent.FiscalYearStartDateName,
                        LedgerAccountTotal = 0,
                        GlAccountTotal = 0,
                        FailureCount = 0
                    });
                }
            }

            return q;
        }

        public static IQueryable<TransactionDetail> GetFinancialIntegrityDetailList(AppLazyContext lazyContext, int agencyId, string accountName, string fiscalYearStartDateName, DateTime endDate) {
            var setting = lazyContext.Setting.Single(t => t.FiscalYearStartDateName == fiscalYearStartDateName);
            return GetFinancialIntegrityDetailList(lazyContext, setting, agencyId, accountName, endDate);
        }

        private static IQueryable<TransactionDetail> GetFinancialIntegrityDetailList(AppLazyContext lazyContext, Setting setting, int agencyId, string accountName, DateTime endDate) {
            var transactionDetail = GetTransactionDetailQuery(lazyContext, agencyId).Where(t => t.IntegrityCheckFailed);
            var account = FinancialIntegrityAccountList.Single(t => t.AccountName == accountName);

            var q = transactionDetail.Where(t => t.Transaction.DocumentDate <= endDate && t.Transaction.DocumentDate >= setting.FiscalYearStartDate);

            switch (account.AccountName) {
                default:
                    q = q.Where(t => t.LedgerType == account.LedgerType);
                    break;
                case "BSP Accrual Account":
                    int chartOfAccountId = GetFinancialIntegrityAccountId(accountName, setting);
                    q = q.Where(t => t.LedgerType == LedgerType.GeneralLedger && t.ChartOfAccountId == chartOfAccountId);
                    break;
                case "Supplier Returns Account":
                    chartOfAccountId = GetFinancialIntegrityAccountId(accountName, setting);
                    q = q.Where(t => t.LedgerType == account.LedgerType && t.ChartOfAccountId == chartOfAccountId && t.CreditorId <= 0);
                    break;
                case "General Ledger":
                    chartOfAccountId = GetFinancialIntegrityAccountId("BSP Accrual Account", setting);
                    q = q.Where(t => t.LedgerType == account.LedgerType && t.ChartOfAccountId != chartOfAccountId);
                    break;
            }

            return q;
        }

        private static int GetFinancialIntegrityAccountId(string accountName, Setting setting) {
            switch (accountName) {
                default:
                    return 0;
                case "Client Control Account":
                    return setting.ClientControlAccountId;
                case "Debtor Control Account":
                    return setting.DebtorControlAccountId;
                case "Creditor Control Account":
                    return setting.CreditorControlAccountId;
                case "BSP Accrual Account":
                    return setting.BspAccrualAccountId;
                case "Supplier Returns Account":
                    return setting.SupplierReturnsAccountId;
            }
        }

        private static void GetAccountQuery(AppLazyContext lazyContext, AccountModel account, Setting setting, int agencyId, DateTime fiscalPeriodEndDate, IQueryable<TransactionDetail> glAccountBase, IQueryable<TransactionDetail> ledgerAccountBase, ref IQueryable<TransactionDetail> glAccount, ref IQueryable<TransactionDetail> ledgerAccount, ref IEnumerable<TransactionDetail> bspAccrualAccount) {
            int chartOfAccountId = GetFinancialIntegrityAccountId(account.AccountName, setting);
            glAccount = glAccountBase.Where(t => t.ChartOfAccountId == chartOfAccountId);

            switch (account.AccountName) {
                default:
                    ledgerAccount = ledgerAccountBase;

                    if (account.AccountName == "Supplier Returns Account") {
                        ledgerAccount = ledgerAccount.Where(t => t.LedgerType == account.LedgerType && t.CreditorId <= 0);
                    }
                    else {
                        switch (account.LedgerType) {
                            case LedgerType.ClientLedger:
                            case LedgerType.DebtorLedger:
                            case LedgerType.CreditorLedger:
                                ledgerAccount = ledgerAccount.Where(t => t.LedgerType == account.LedgerType);
                                break;
                            case LedgerType.GeneralLedger:
                                glAccount = glAccountBase;
                                break;
                        }
                    }

                    break;
                case "BSP Accrual Account":
                    bspAccrualAccount = Creditor.GetBspAccrualQuery(lazyContext, agencyId, PaidStatusReportOption.All, LedgerDocumentType.Reconciliation, fiscalPeriodEndDate, true, true);
                    break;
            }
        }

        private static IQueryable<TransactionDetail> GetTransactionDetailQuery(AppLazyContext lazyContext, int agencyId) {
            var q = lazyContext.TransactionDetail;

            if (agencyId <= 0)
                return q;

            return q.Where(t => (t.Transaction.TransactionType == TransactionType.Receipt ? t.Transaction.Receipt.AgencyId
                : t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.AgencyId
                : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.AgencyId
                : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.AgencyId
                : t.Transaction.TransactionType == TransactionType.Invoice ? t.InvoiceDetail.AgencyId
                : t.Transaction.TransactionType == TransactionType.Journal ? t.JournalDetail.AgencyId
                : t.Transaction.TransactionType == TransactionType.Adjustment ? t.Transaction.Adjustment.DebitAgencyId : -1) == agencyId);
        }

        public static IEnumerable<TransactionDetailAllocationErrorViewModel> GetDebtorCreditAllocationErrorList(AppLazyContext lazyContext, int agencyId) {
            var q = lazyContext.Debtor.Where(t => t.Id > 0);

            if (agencyId > 0)
                q = q.Where(t => t.AgencyId == agencyId);

            return from row in q.OrderBy(t => t.Name)
                   let AllocationAmount = row.TransactionDetails.SelectMany(t => t.TransactionDetailAllocations).Sum(t => (decimal?)t.Amount) ?? 0
                   let TxnAmount = row.TransactionDetails.Where(t => t.InvoiceDetail.Invoice.IsMatched).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0
                   where AllocationAmount + TxnAmount != 0
                   select new TransactionDetailAllocationErrorViewModel {
                       Id = row.Id,
                       AccountNameLink = row.AccountNameLink,
                       Imbalance = AllocationAmount + TxnAmount
                   };
        }

        public static IEnumerable<TransactionDetailAllocationErrorViewModel> GetCreditorCreditAllocationErrorList(AppLazyContext lazyContext, int agencyId) {
            var q = lazyContext.Creditor.Where(t => t.Id > 0);

            if (agencyId > 0)
                q = q.Where(t => t.AgencyId == agencyId);

            return from row in q.OrderBy(t => t.Name)
                   let AllocationAmount = row.TransactionDetails.SelectMany(t => t.TransactionDetailAllocations).Sum(t => (decimal?)t.Amount) ?? 0
                   let TxnAmount = row.TransactionDetails.Where(t => t.NonBspDetail.NonBsp.PaymentId > 0 || t.PaymentDetail.Payment.PaymentType == PaymentType.NonBspReturn).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0
                   where AllocationAmount + TxnAmount != 0
                   select new TransactionDetailAllocationErrorViewModel {
                       Id = row.Id,
                       AccountNameLink = row.AccountNameLink,
                       Imbalance = AllocationAmount + TxnAmount
                   };
        }

        public static IEnumerable<MissingTransactionsViewModel> GetMissingTransactionsList(AppLazyContext lazyContext, int agencyId) {
            int i = 0;

            return lazyContext.Receipt.Where(t => t.Id > 0 && t.AgencyId == agencyId && !t.IsDeposit && !t.IsLegacy && t.Transactions.Count == 0).OrderByDescending(t => t.DocumentDate).AsEnumerable().Select(row => new MissingTransactionsViewModel {
                Id = i++,
                DocumentType = "Receipt",
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            }).Concat(lazyContext.Bsp.Where(t => t.Id > 0 && t.AgencyId == agencyId && t.BspType != BspType.Conjunction && t.BspType != BspType.Free && t.BspType != BspType.Void && !t.IsLegacy && t.Transactions.Count == 0).OrderByDescending(t => t.DocumentDate).AsEnumerable().Select(row => new MissingTransactionsViewModel {
                Id = i++,
                DocumentType = "BSP Return",
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            })).Concat(lazyContext.NonBsp.Where(t => t.Id > 0 && t.AgencyId == agencyId && !t.IsLegacy && t.Transactions.Count == 0).OrderByDescending(t => t.DocumentDate).AsEnumerable().Select(row => new MissingTransactionsViewModel {
                Id = i++,
                DocumentType = "Non-BSP Return",
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            })).Concat(lazyContext.Payment.Where(t => t.Id > 0 && t.AgencyId == agencyId && !t.IsLegacy && t.Transactions.Count == 0).AsEnumerable().Select(row => new MissingTransactionsViewModel {
                Id = i++,
                DocumentType = "Payment",
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            })).Concat(lazyContext.Invoice.Where(t => t.Id > 0 && t.Debtor.AgencyId == agencyId && t.Transactions.Count == 0).OrderByDescending(t => t.DocumentDate).AsEnumerable().Select(row => new MissingTransactionsViewModel {
                Id = i++,
                DocumentType = row.InvoiceType.GetEnumDescription(),
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            })).Concat(lazyContext.Journal.Where(t => t.Id > 0 && !t.IsLegacy && t.DocumentStatus == DocumentStatus.Closed && t.Transactions.Count == 0).OrderByDescending(t => t.DocumentDate).AsEnumerable().Where(t1 => t1.JournalDetails.Any(t2 => t2.AgencyId == agencyId)).Select(row => new MissingTransactionsViewModel {
                Id = i++,
                DocumentType = "Journal",
                AccountName = string.Empty,
                AccountNameLink = string.Empty,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            })).Concat(lazyContext.Adjustment.Where(t => t.Id > 0 && t.Transactions.Count == 0).OrderByDescending(t => t.DocumentDate).AsEnumerable().Where(t => t.DebitAgencyId == agencyId).Select(row => new MissingTransactionsViewModel {
                Id = i++,
                DocumentType = "Adjustment",
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            }));
        }

        public static IEnumerable<TaxRateConflictViewModel> GetTaxRateConflictList(AppAdminContext adminContext, AppLazyContext lazyContext, string countryCode) {
            DateTime taxDateEffective = adminContext.TaxRate.Where(t => t.CountryCode == countryCode).Max(t => (DateTime?)t.DateEffective) ?? DateTime.MinValue;

            if (taxDateEffective == DateTime.MinValue)
                return new List<TaxRateConflictViewModel>();

            int i = 0;

            return lazyContext.Receipt.Where(t => t.DocumentDate >= taxDateEffective && t.LastWriteTime.Date < taxDateEffective).OrderByDescending(t => t.DocumentDate).AsEnumerable().Select(row => new TaxRateConflictViewModel {
                Id = i++,
                DocumentType = "Receipt",
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            }).Concat(lazyContext.Bsp.Where(t => t.DocumentDate >= taxDateEffective && t.LastWriteTime.Date < taxDateEffective).OrderByDescending(t => t.DocumentDate).AsEnumerable().Select(row => new TaxRateConflictViewModel {
                Id = i++,
                DocumentType = "BSP Return",
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            })).Concat(lazyContext.NonBsp.Where(t => t.DocumentDate >= taxDateEffective && t.LastWriteTime.Date < taxDateEffective).OrderByDescending(t => t.DocumentDate).AsEnumerable().Select(row => new TaxRateConflictViewModel {
                Id = i++,
                DocumentType = "Non-BSP Return",
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            })).Concat(lazyContext.Payment.Where(t => t.DocumentDate >= taxDateEffective && t.LastWriteTime.Date < taxDateEffective).OrderByDescending(t => t.DocumentDate).AsEnumerable().Select(row => new TaxRateConflictViewModel {
                Id = i++,
                DocumentType = "Payment",
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            })).Concat(lazyContext.Invoice.Where(t => t.DocumentDate >= taxDateEffective && t.LastWriteTime.Date < taxDateEffective).OrderByDescending(t => t.DocumentDate).AsEnumerable().Select(row => new TaxRateConflictViewModel {
                Id = i++,
                DocumentType = row.InvoiceType.GetEnumDescription(),
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            })).Concat(lazyContext.Voucher.Where(t => t.DocumentDate >= taxDateEffective && t.LastWriteTime.Date < taxDateEffective).OrderByDescending(t => t.DocumentDate).AsEnumerable().Select(row => new TaxRateConflictViewModel {
                Id = i++,
                DocumentType = "Voucher",
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = row.DocumentNo,
                DocumentNoLink = row.GetDocumentNoLink("FinancialIntegrity"),
                DocumentDate = row.DocumentDate
            })).Concat(lazyContext.Trip.Where(t1 => t1.TripLines.Any(t2 => t2.TripLineAir.TripLineAirPassengers.Count > 0 && t2.TripLineAir.TripLineAirSegments.Any(t3 => t3.DepartureDate >= taxDateEffective && t3.LastWriteTime.Date < taxDateEffective))).OrderByDescending(t => t.DepartureDate).AsEnumerable().Select(row => new TaxRateConflictViewModel {
                Id = i++,
                DocumentType = "Air Passenger",
                AccountName = row.AccountName,
                AccountNameLink = row.AccountNameLink,
                DocumentNo = string.Empty,
                DocumentNoLink = string.Empty,
                DocumentDate = row.DepartureDate
            }));
        }

        public static List<GeneralLedgerSettingErrorViewModel> GetGeneralLedgerSettingErrorList(AppMainContext context, int customerId) {
            return GeneralLedgerSettings.GetGeneralLedgerSettingErrorsList(context, customerId).ConvertAll(row => new GeneralLedgerSettingErrorViewModel {
                SettingId = row.SettingId,
                PreviousFiscalYearEndDate = row.PreviousFiscalYearEndDate,
                CurrentFiscalYearStartDate = row.CurrentFiscalYearStartDate
            });
        }

        public static List<MissingAutoGeneratedDocumentViewModel> GetMissingAutoGeneratedDocumentList(AppMainContext context, int agencyId) {
            return new List<MissingAutoGeneratedDocumentViewModel> {
                new MissingAutoGeneratedDocumentViewModel { Id = 1, Description = string.Format(@"<a href=""/Accounting/Receipts/?receiptStatusId={0}"" target=""_blank"">Loyalty Scheme Receipts</a>", (int)ReceiptStatus.NoAutoLoyaltyScheme), Value = ReceiptDetail.GetMissingAutoLoyaltySchemeReceiptDetails(context, agencyId).Count() },
                new MissingAutoGeneratedDocumentViewModel { Id = 2, Description = string.Format(@"<a href=""/Accounting/Receipts/?receiptStatusId={0}"" target=""_blank"">Supplier Other Commission Receipts</a>", (int)ReceiptStatus.NoAutoOtherCommission), Value = Receipt.GetMissingAutoSupplierOtherCommissionReceipts(context, agencyId).Count() },
                new MissingAutoGeneratedDocumentViewModel { Id = 3, Description = string.Format(@"<a href=""/Accounting/Receipts/?receiptStatusId={0}"" target=""_blank"">Transfer Receipts</a>", (int)ReceiptStatus.NoAutoTransfer), Value = Receipt.GetMissingAutoTransferReceipts(context, agencyId).Count() },
                new MissingAutoGeneratedDocumentViewModel { Id = 4, Description = string.Format(@"<a href=""/Accounting/BspReturns/?bspStatusId={0}"" target=""_blank"">Agency Credit Card BSP Returns</a>", (int)BspStatus.NoAutoAgencyCc), Value = Bsp.GetMissingAutoAgencyCcBspIds(context, agencyId).Count() },
                new MissingAutoGeneratedDocumentViewModel { Id = 5, Description = string.Format(@"<a href=""/Accounting/NonBspReturns/?nonBspStatusId={0}"" target=""_blank"">Agency Credit Card Non-BSP Returns</a>", (int)NonBspStatus.NoAutoAgencyCc), Value = NonBsp.GetMissingAutoAgencyCcNonBspIds(context, agencyId).Count() },
            };
        }

        private static List<AccountModel> FinancialIntegrityAccountList {
            get {
                return new List<AccountModel> {
                    new AccountModel { AccountName = "Client Control Account", LedgerType = LedgerType.ClientLedger },
                    new AccountModel { AccountName = "Debtor Control Account", LedgerType = LedgerType.DebtorLedger },
                    new AccountModel { AccountName = "Creditor Control Account", LedgerType = LedgerType.CreditorLedger },
                    new AccountModel { AccountName = "BSP Accrual Account", LedgerType = LedgerType.None },
                    new AccountModel { AccountName = "Supplier Returns Account", LedgerType = LedgerType.CreditorLedger },
                    new AccountModel { AccountName = "General Ledger", LedgerType = LedgerType.GeneralLedger }
                };
            }
        }

        private class AccountModel {
            public string AccountName { get; set; }
            public LedgerType LedgerType { get; set; }
        }
    }
}