﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Kendo.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.Infrastructure;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.Admin;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Dao.DebtorLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;
using Travelog.Ledger.Models;
using Travelog.WebApp.Models;

namespace Travelog.WebApp {
	public static class TripBindingExtensions {
		public static IQueryable<Trip> ApplySorting(this IQueryable<Trip> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<Trip> AddSortExpression(IQueryable<Trip> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "ClientAccountTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.ClientAccountType);
					}
					else {
						data = data.OrderByDescending(t => t.ClientAccountType);
					}

					break;
				case "TripNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Id);
					}
					else {
						data = data.OrderByDescending(t => t.Id);
					}

					break;
				case "ProfileCode":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Profile.Code);
					}
					else {
						data = data.OrderByDescending(t => t.Profile.Code);
					}

					break;
				case "FullName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.FirstName).ThenBy(t => t.LastName);
					}
					else {
						data = data.OrderByDescending(t => t.FirstName).ThenByDescending(t => t.LastName);
					}

					break;
				case "PhoneNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Mobile == string.Empty ? t.PhoneWork == string.Empty ? t.PhoneHome : t.PhoneWork : t.Mobile);
					}
					else {
						data = data.OrderByDescending(t => t.Mobile == string.Empty ? t.PhoneWork == string.Empty ? t.PhoneHome : t.PhoneWork : t.Mobile);
					}

					break;
				case "TripDepartureDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DepartureDate);
					}
					else {
						data = data.OrderByDescending(t => t.DepartureDate);
					}

					break;
				case "Consultant":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.ConsultantId <= 0 ? string.Empty : t.Consultant.Name);
					}
					else {
						data = data.OrderByDescending(t => t.ConsultantId <= 0 ? string.Empty : t.Consultant.Name);
					}

					break;
			}

			return data;
		}

		public static IQueryable<Trip> ApplyPaging(this IQueryable<Trip> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}
	}

	public static class ReceiptBindingExtensions {
		public static IQueryable<ReceiptViewModel> ApplyFiltering(this IQueryable<ReceiptViewModel> data, IList<IFilterDescriptor> filterDescriptors) {
			if (filterDescriptors?.Count > 0)
				data = data.Where(ExpressionBuilder.Expression<ReceiptViewModel>(filterDescriptors, false));

			return data;
		}

		public static IQueryable<Receipt> ApplySorting(this IQueryable<Receipt> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<Receipt> AddSortExpression(IQueryable<Receipt> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "ReceiptAccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.AccountName);
					}
					else {
						data = data.OrderByDescending(t => t.AccountName);
					}

					break;
				case "ReceiptTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.ReceiptType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.ReceiptType);
					}

					break;
				case "ReceiptDocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentNo);
					}

					break;
				case "ReceiptDocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentDate);
					}

					break;
			}

			return data;
		}

		public static IQueryable<ReceiptDetail> ApplySorting(this IQueryable<ReceiptDetail> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<ReceiptDetail> AddSortExpression(IQueryable<ReceiptDetail> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "ReceiptAccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Receipt.AccountName);
					}
					else {
						data = data.OrderByDescending(t => t.Receipt.AccountName);
					}

					break;
				case "ReceiptTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.Receipt.ReceiptType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.Receipt.ReceiptType);
					}

					break;
				case "ReceiptDocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Receipt.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.Receipt.DocumentNo);
					}

					break;
				case "ReceiptDocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Receipt.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.Receipt.DocumentDate);
					}

					break;
				case "ReceiptFormOfPayment":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.FormOfPayment.Name);
					}
					else {
						data = data.OrderByDescending(t => t.FormOfPayment.Name);
					}

					break;
			}

			return data;
		}

		public static IQueryable<ReceiptViewModel> ApplySorting(this IQueryable<ReceiptViewModel> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<ReceiptViewModel> AddSortExpression(IQueryable<ReceiptViewModel> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "ReceiptAccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.ReceiptAccountName);
					}
					else {
						data = data.OrderByDescending(t => t.ReceiptAccountName);
					}

					break;
				case "ReceiptTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.ReceiptType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.ReceiptType);
					}

					break;
				case "ReceiptDocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.ReceiptDocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.ReceiptDocumentNo);
					}

					break;
				case "ReceiptDocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.ReceiptDocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.ReceiptDocumentDate);
					}

					break;
			}

			return data;
		}

		public static IQueryable<ReceiptViewModel> ApplyPaging(this IQueryable<ReceiptViewModel> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}

		public static IEnumerable ApplyGrouping(this IQueryable<ReceiptViewModel> data, IList<GroupDescriptor> groupDescriptors, IQueryable<ReceiptDetail> dataSet) {
			if (groupDescriptors == null || groupDescriptors.Count == 0)
				return data;

			Func<IEnumerable<ReceiptViewModel>, IEnumerable<AggregateFunctionsGroup>> selector = null;

			foreach (var descriptor in groupDescriptors.Reverse()) {
				switch (descriptor.Member) {
					case "ReceiptDocumentNo":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.ReceiptDocumentNo, group, dataSet);
						}
						else {
							selector = BuildGroup(t => t.ReceiptDocumentNo, selector, dataSet);
						}

						break;
					case "ReceiptDocumentDate":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.ReceiptDocumentDate, group, dataSet);
						}
						else {
							selector = BuildGroup(t => t.ReceiptDocumentDate, selector, dataSet);
						}

						break;
				}
			}

			return selector.Invoke(data).ToList();
		}

		private static Func<IEnumerable<ReceiptViewModel>, IEnumerable<AggregateFunctionsGroup>> BuildGroup<T>(Expression<Func<ReceiptViewModel, T>> groupSelector, Func<IEnumerable<ReceiptViewModel>, IEnumerable<AggregateFunctionsGroup>> selectorBuilder, IQueryable<ReceiptDetail> dataSet) {
			var tempSelector = selectorBuilder;

			return group => group.GroupBy(groupSelector.Compile()).Select(row => new AggregateFunctionsGroup {
				Key = row.Key,
				HasSubgroups = true,
				Member = groupSelector.MemberWithoutInstance(),
				Items = tempSelector.Invoke(row).ToList(),
				AggregateFunctionsProjection = GetAggregateFunctionsProjection(dataSet, row.Key)
			});
		}

		private static IEnumerable<AggregateFunctionsGroup> BuildInnerGroup<T>(Expression<Func<ReceiptViewModel, T>> groupSelector, IEnumerable<ReceiptViewModel> group, IQueryable<ReceiptDetail> dataSet) {
			return group.GroupBy(groupSelector.Compile()).Select(row => new AggregateFunctionsGroup {
				Key = row.Key,
				Member = groupSelector.MemberWithoutInstance(),
				Items = row.ToList(),
				AggregateFunctionsProjection = GetAggregateFunctionsProjection(dataSet, row.Key)
			});
		}

		private static object GetAggregateFunctionsProjection(IQueryable<ReceiptDetail> dataSet, object key) {
			IQueryable<ReceiptDetail> q;

			if (key.GetType() == typeof(DateTime)) {
				q = dataSet.Where(t => t.Receipt.DocumentDate == (DateTime)key);
			}
			else {
				q = dataSet.Where(t => t.Receipt.DocumentNo == key.ToString());
			}

			return new {
				ReceiptTotalLoyaltySchemeValue = new AggregateResult(q.Sum(t => t.LoyaltySchemeValue), new SumFunction { FunctionName = "Sum", SourceField = "ReceiptTotalLoyaltySchemeValue", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				ReceiptTotalAmount = new AggregateResult(q.Sum(t => t.Amount + t.Tax), new SumFunction { FunctionName = "Sum", SourceField = "ReceiptTotalAmount", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				ReceiptTotalMerchantFee = new AggregateResult(q.Sum(t => t.MerchantFee + t.MerchantFeeTax), new SumFunction { FunctionName = "Sum", SourceField = "ReceiptTotalMerchantFee", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				ReceiptTotalAmountNet = new AggregateResult(q.Sum(t => t.Amount + t.Tax - t.MerchantFee - t.MerchantFeeTax), new SumFunction { FunctionName = "Sum", SourceField = "ReceiptTotalAmountNet", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" })
			};
		}
	}

	public static class BspBindingExtensions {
		public static IQueryable<BspViewModel> ApplyFiltering(this IQueryable<BspViewModel> data, IList<IFilterDescriptor> filterDescriptors) {
			if (filterDescriptors?.Count > 0)
				data = data.Where(ExpressionBuilder.Expression<BspViewModel>(filterDescriptors, false));

			return data;
		}

		public static IQueryable<BspViewModel> ApplySorting(this IQueryable<BspViewModel> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<BspViewModel> AddSortExpression(IQueryable<BspViewModel> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "BspAccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspAccountName);
					}
					else {
						data = data.OrderByDescending(t => t.BspAccountName);
					}

					break;
				case "BspDocumentStatusDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.BspDocumentStatus);
					}
					else {
						data = data.OrderByDescending(t => (int)t.BspDocumentStatus);
					}

					break;
				case "BspTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.BspType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.BspType);
					}

					break;
				case "BspDocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspDocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.BspDocumentNo);
					}

					break;
				case "BspDocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspDocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.BspDocumentDate);
					}

					break;
				case "BspDepartureDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspDepartureDate);
					}
					else {
						data = data.OrderByDescending(t => t.BspDepartureDate);
					}

					break;
				case "BspSaleType":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspSaleType);
					}
					else {
						data = data.OrderByDescending(t => t.BspSaleType);
					}

					break;
				case "BspFormOfPayment":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspFormOfPayment);
					}
					else {
						data = data.OrderByDescending(t => t.BspFormOfPayment);
					}

					break;
				case "BspTotalCash":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspTotalCash);
					}
					else {
						data = data.OrderByDescending(t => t.BspTotalCash);
					}

					break;
				case "BspTotalCashNonCommissionable":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspTotalCashNonCommissionable);
					}
					else {
						data = data.OrderByDescending(t => t.BspTotalCashNonCommissionable);
					}

					break;
				case "BspTotalCreditCard":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspTotalCreditCard);
					}
					else {
						data = data.OrderByDescending(t => t.BspTotalCreditCard);
					}

					break;
				case "BspTotalCreditCardNonCommissionable":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspTotalCreditCardNonCommissionable);
					}
					else {
						data = data.OrderByDescending(t => t.BspTotalCreditCardNonCommissionable);
					}

					break;
				case "BspCommission":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspCommission);
					}
					else {
						data = data.OrderByDescending(t => t.BspCommission);
					}

					break;
				case "BspCommissionTax":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspCommissionTax);
					}
					else {
						data = data.OrderByDescending(t => t.BspCommissionTax);
					}

					break;
				case "BspTotalTax":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspTotalTax);
					}
					else {
						data = data.OrderByDescending(t => t.BspTotalTax);
					}

					break;
				case "BspTotalAmount":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspTotalAmount);
					}
					else {
						data = data.OrderByDescending(t => t.BspTotalAmount);
					}

					break;
				case "BspAmountPayable":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BspAmountPayable);
					}
					else {
						data = data.OrderByDescending(t => t.BspAmountPayable);
					}

					break;
			}

			return data;
		}

		public static IQueryable<BspViewModel> ApplyPaging(this IQueryable<BspViewModel> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}
	}

	public static class NonBspBindingExtensions {
		public static IQueryable<NonBspViewModel> ApplyFiltering(this IQueryable<NonBspViewModel> data, IList<IFilterDescriptor> filterDescriptors) {
			if (filterDescriptors?.Count > 0)
				data = data.Where(ExpressionBuilder.Expression<NonBspViewModel>(filterDescriptors, false));

			return data;
		}

		public static IQueryable<NonBspViewModel> ApplySorting(this IQueryable<NonBspViewModel> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<NonBspViewModel> AddSortExpression(IQueryable<NonBspViewModel> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "NonBspAccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspAccountName);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspAccountName);
					}

					break;
				case "NonBspDocumentStatusDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.NonBspDocumentStatus);
					}
					else {
						data = data.OrderByDescending(t => (int)t.NonBspDocumentStatus);
					}

					break;
				case "NonBspTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.NonBspType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.NonBspType);
					}

					break;
				case "NonBspDocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspDocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspDocumentNo);
					}

					break;
				case "NonBspDocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspDocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspDocumentDate);
					}

					break;
				case "NonBspCreditor":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspCreditor);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspCreditor);
					}

					break;
				case "NonBspSupplier":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspSupplier);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspSupplier);
					}

					break;
				case "NonBspSaleType":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspSaleType);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspSaleType);
					}

					break;
				case "NonBspFormOfPayment":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspFormOfPayment);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspFormOfPayment);
					}

					break;
				case "NonBspTotalCash":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspTotalCash);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspTotalCash);
					}

					break;
				case "NonBspTotalCashNonCommissionable":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspTotalCashNonCommissionable);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspTotalCashNonCommissionable);
					}

					break;
				case "NonBspTotalCreditCard":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspTotalCreditCard);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspTotalCreditCard);
					}

					break;
				case "NonBspTotalCreditCardNonCommissionable":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspTotalCreditCardNonCommissionable);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspTotalCreditCardNonCommissionable);
					}

					break;
				case "NonBspCommission":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspCommission);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspCommission);
					}

					break;
				case "NonBspCommissionTax":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspCommissionTax);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspCommissionTax);
					}

					break;
				case "NonBspTotalTax":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspTotalTax);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspTotalTax);
					}

					break;
				case "NonBspTotalAmount":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspTotalAmount);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspTotalAmount);
					}

					break;
				case "NonBspAmountPayable":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.NonBspAmountPayable);
					}
					else {
						data = data.OrderByDescending(t => t.NonBspAmountPayable);
					}

					break;
			}

			return data;
		}

		public static IQueryable<NonBspViewModel> ApplyPaging(this IQueryable<NonBspViewModel> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}
	}

	public static class PaymentBindingExtensions {
		public static IQueryable<Payment> ApplyFiltering(this IQueryable<Payment> data, IList<IFilterDescriptor> filterDescriptors) {
			if (filterDescriptors?.Count > 0)
				data = data.Where(ExpressionBuilder.Expression<Payment>(filterDescriptors, false));

			return data;
		}

		public static IQueryable<Payment> ApplySorting(this IQueryable<Payment> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<Payment> AddSortExpression(IQueryable<Payment> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "PaymentAccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.AccountName);
					}
					else {
						data = data.OrderByDescending(t => t.AccountName);
					}

					break;
				case "PaymentCombinedStatusDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t1 => t1.PaymentDetails.Min(t2 => (int)t2.DocumentStatus));
					}
					else {
						data = data.OrderByDescending(t1 => t1.PaymentDetails.Min(t2 => (int)t2.DocumentStatus));
					}

					break;
				case "PaymentTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.PaymentType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.PaymentType);
					}

					break;
				case "PaymentPayee":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Payee);
					}
					else {
						data = data.OrderByDescending(t => t.Payee);
					}

					break;
				case "PaymentDocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentNo);
					}

					break;
				case "PaymentDocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentDate);
					}

					break;
				case "PaymentSaleType":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.SaleTypeId <= 0 ? string.Empty : t.SaleType.Name);
					}
					else {
						data = data.OrderByDescending(t => t.SaleTypeId <= 0 ? string.Empty : t.SaleType.Name);
					}

					break;
			}

			return data;
		}

		public static IQueryable<Payment> ApplyPaging(this IQueryable<Payment> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}

		public static IEnumerable ApplyGrouping(this IEnumerable<PaymentViewModel> data, IList<GroupDescriptor> groupDescriptors, List<PaymentViewModel> dataSet) {
			if (groupDescriptors == null || groupDescriptors.Count == 0)
				return data;

			Func<IEnumerable<PaymentViewModel>, IEnumerable<AggregateFunctionsGroup>> selector = null;

			foreach (var descriptor in groupDescriptors.Reverse()) {
				switch (descriptor.Member) {
					case "PaymentDocumentNo":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.PaymentDocumentNo, group, dataSet);
						}
						else {
							selector = BuildGroup(t => t.PaymentDocumentNo, selector, dataSet);
						}

						break;
					case "PaymentDocumentDate":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.PaymentDocumentDate, group, dataSet);
						}
						else {
							selector = BuildGroup(t => t.PaymentDocumentDate, selector, dataSet);
						}

						break;
				}
			}

			return selector.Invoke(data).ToList();
		}

		private static Func<IEnumerable<PaymentViewModel>, IEnumerable<AggregateFunctionsGroup>> BuildGroup<T>(Expression<Func<PaymentViewModel, T>> groupSelector, Func<IEnumerable<PaymentViewModel>, IEnumerable<AggregateFunctionsGroup>> selectorBuilder, List<PaymentViewModel> dataSet) {
			var tempSelector = selectorBuilder;

			return group => group.GroupBy(groupSelector.Compile()).Select(row => new AggregateFunctionsGroup {
				Key = row.Key,
				HasSubgroups = true,
				Member = groupSelector.MemberWithoutInstance(),
				Items = tempSelector.Invoke(row).ToList(),
				AggregateFunctionsProjection = GetAggregateFunctionsProjection(dataSet, row.Key)
			});
		}

		private static IEnumerable<AggregateFunctionsGroup> BuildInnerGroup<T>(Expression<Func<PaymentViewModel, T>> groupSelector, IEnumerable<PaymentViewModel> group, List<PaymentViewModel> dataSet) {
			return group.GroupBy(groupSelector.Compile()).Select(row => new AggregateFunctionsGroup {
				Key = row.Key,
				Member = groupSelector.MemberWithoutInstance(),
				Items = row.ToList(),
				AggregateFunctionsProjection = GetAggregateFunctionsProjection(dataSet, row.Key)
			});
		}

		private static object GetAggregateFunctionsProjection(List<PaymentViewModel> dataSet, object key) {
			IEnumerable<PaymentViewModel> q;

			if (key.GetType() == typeof(DateTime)) {
				q = dataSet.Where(t => t.PaymentDocumentDate == (DateTime)key);
			}
			else {
				q = dataSet.Where(t => t.PaymentDocumentNo == key.ToString());
			}

			return new {
				PaymentTotalCash = new AggregateResult(q.Sum(t => t.PaymentTotalCash), new SumFunction { FunctionName = "Sum", SourceField = "PaymentTotalCash", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				PaymentTotalCashNonCommissionable = new AggregateResult(q.Sum(t => t.PaymentTotalCashNonCommissionable), new SumFunction { FunctionName = "Sum", SourceField = "PaymentTotalCashNonCommissionable", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				PaymentTotalCreditCard = new AggregateResult(q.Sum(t => t.PaymentTotalCreditCard), new SumFunction { FunctionName = "Sum", SourceField = "PaymentTotalCreditCard", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				PaymentTotalCreditCardNonCommissionable = new AggregateResult(q.Sum(t => t.PaymentTotalCreditCardNonCommissionable), new SumFunction { FunctionName = "Sum", SourceField = "PaymentTotalCreditCardNonCommissionable", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				PaymentCommission = new AggregateResult(q.Sum(t => t.PaymentCommission), new SumFunction { FunctionName = "Sum", SourceField = "PaymentCommission", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				PaymentCommissionTax = new AggregateResult(q.Sum(t => t.PaymentCommissionTax), new SumFunction { FunctionName = "Sum", SourceField = "PaymentCommissionTax", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				PaymentAmountPayable = new AggregateResult(q.Sum(t => t.PaymentAmountPayable), new SumFunction { FunctionName = "Sum", SourceField = "PaymentAmountPayable", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				PaymentAmountPayableTax = new AggregateResult(q.Sum(t => t.PaymentAmountPayableTax), new SumFunction { FunctionName = "Sum", SourceField = "PaymentAmountPayableTax", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" })
			};
		}
	}

	public static class InvoiceBindingExtensions {
		public static IQueryable<InvoiceViewModel> ApplyFiltering(this IQueryable<InvoiceViewModel> data, IList<IFilterDescriptor> filterDescriptors) {
			if (filterDescriptors?.Count > 0)
				data = data.Where(ExpressionBuilder.Expression<InvoiceViewModel>(filterDescriptors, false));

			return data;
		}

		public static IQueryable<Invoice> ApplySorting(this IQueryable<Invoice> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<Invoice> AddSortExpression(IQueryable<Invoice> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "InvoiceAccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.AccountName);
					}
					else {
						data = data.OrderByDescending(t => t.AccountName);
					}

					break;
				case "InvoiceDocumentStatusDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t1 => t1.InvoiceDetails.Min(t2 => (int)t2.DocumentStatus));
					}
					else {
						data = data.OrderByDescending(t1 => t1.InvoiceDetails.Min(t2 => (int)t2.DocumentStatus));
					}

					break;
				case "InvoiceTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.InvoiceType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.InvoiceType);
					}

					break;
				case "InvoiceDocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentNo);
					}

					break;
				case "InvoiceDocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentDate);
					}

					break;
			}

			return data;
		}

		public static IQueryable<Invoice> ApplyPaging(this IQueryable<Invoice> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}
	}

	public static class JournalBindingExtensions {
		public static IQueryable<JournalViewModel> ApplyFiltering(this IQueryable<JournalViewModel> data, IList<IFilterDescriptor> filterDescriptors) {
			if (filterDescriptors?.Count > 0)
				data = data.Where(ExpressionBuilder.Expression<JournalViewModel>(filterDescriptors, false));

			return data;
		}

		public static IQueryable<Journal> ApplySorting(this IQueryable<Journal> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<Journal> AddSortExpression(IQueryable<Journal> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "JournalDocumentStatusDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.DocumentStatus);
					}
					else {
						data = data.OrderByDescending(t => (int)t.DocumentStatus);
					}

					break;
				case "JournalDocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentNo);
					}

					break;
				case "JournalDocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentDate);
					}

					break;
				case "JournalTotalDebit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t1 => t1.JournalDetails.Sum(t2 => (decimal?)(t2.SignType == SignType.Debit ? t2.Amount : 0)) ?? 0);
					}
					else {
						data = data.OrderByDescending(t1 => t1.JournalDetails.Sum(t2 => (decimal?)(t2.SignType == SignType.Debit ? t2.Amount : 0)) ?? 0);
					}

					break;
				case "JournalTotalCredit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t1 => t1.JournalDetails.Sum(t2 => (decimal?)(t2.SignType == SignType.Debit ? 0 : t2.Amount)) ?? 0);
					}
					else {
						data = data.OrderByDescending(t1 => t1.JournalDetails.Sum(t2 => (decimal?)(t2.SignType == SignType.Debit ? 0 : t2.Amount)) ?? 0);
					}

					break;
				case "JournalBalance":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t1 => t1.JournalDetails.Sum(t => (decimal?)(t.SignType == SignType.Debit ? t.Amount : -t.Amount)) ?? 0);
					}
					else {
						data = data.OrderByDescending(t1 => t1.JournalDetails.Sum(t => (decimal?)(t.SignType == SignType.Debit ? t.Amount : -t.Amount)) ?? 0);
					}

					break;
			}

			return data;
		}

		public static IQueryable<Journal> ApplyPaging(this IQueryable<Journal> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}
	}

	public static class AdjustmentBindingExtensions {
		public static IQueryable<AdjustmentViewModel> ApplyFiltering(this IQueryable<AdjustmentViewModel> data, IList<IFilterDescriptor> filterDescriptors) {
			if (filterDescriptors?.Count > 0)
				data = data.Where(ExpressionBuilder.Expression<AdjustmentViewModel>(filterDescriptors, false));

			return data;
		}

		public static IQueryable<Adjustment> ApplySorting(this IQueryable<Adjustment> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<Adjustment> AddSortExpression(IQueryable<Adjustment> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "AdjustmentDebitAccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DebitAccountName);
					}
					else {
						data = data.OrderByDescending(t => t.DebitAccountName);
					}

					break;
				case "AdjustmentCreditAccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.CreditAccountName);
					}
					else {
						data = data.OrderByDescending(t => t.CreditAccountName);
					}

					break;
				case "AdjustmentDocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentNo);
					}

					break;
				case "AdjustmentDocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentDate);
					}

					break;
				case "AdjustmentDocumentStatusDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.DocumentStatus);
					}
					else {
						data = data.OrderByDescending(t => (int)t.DocumentStatus);
					}

					break;
				case "AdjustmentDebitTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.DebitType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.DebitType);
					}

					break;
				case "AdjustmentCreditTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.CreditType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.CreditType);
					}

					break;
				case "AdjustmentAmount":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Amount);
					}
					else {
						data = data.OrderByDescending(t => t.Amount);
					}

					break;
			}

			return data;
		}

		public static IQueryable<AdjustmentViewModel> ApplyPaging(this IQueryable<AdjustmentViewModel> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}
	}

	public static class VoucherBindingExtensions {
		public static IQueryable<Voucher> ApplySorting(this IQueryable<Voucher> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<Voucher> AddSortExpression(IQueryable<Voucher> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "VoucherAccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.AccountName);
					}
					else {
						data = data.OrderByDescending(t => t.AccountName);
					}

					break;
				case "VoucherDocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentNo);
					}

					break;
				case "VoucherDocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentDate);
					}

					break;
				case "VoucherAmount":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Amount);
					}
					else {
						data = data.OrderByDescending(t => t.Amount);
					}

					break;
				case "VoucherTax":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Tax);
					}
					else {
						data = data.OrderByDescending(t => t.Tax);
					}

					break;
				case "VoucherDiscount":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Discount + t.DiscountTax);
					}
					else {
						data = data.OrderByDescending(t => t.Discount + t.DiscountTax);
					}

					break;
			}

			return data;
		}
	}

	public static class TransactionBindingExtensions {
		public static IQueryable<TransactionViewModel> ApplyFiltering(this IQueryable<TransactionViewModel> data, IList<IFilterDescriptor> filterDescriptors) {
			if (filterDescriptors?.Count > 0)
				data = data.Where(ExpressionBuilder.Expression<TransactionViewModel>(filterDescriptors, false));

			return data;
		}

		public static IQueryable<TransactionViewModel> ApplySorting(this IQueryable<TransactionViewModel> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<TransactionViewModel> AddSortExpression(IQueryable<TransactionViewModel> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "TransactionTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.TransactionType);
					}
					else {
						data = data.OrderByDescending(t => t.TransactionType);
					}

					break;
				case "DocumentType":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentType);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentType);
					}

					break;
				case "DocumentStatusDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentStatus);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentStatus);
					}

					break;
				case "DocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentNo);
					}

					break;
				case "DocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentDate);
					}

					break;
				case "TotalDebit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.TotalDebit);
					}
					else {
						data = data.OrderByDescending(t => t.TotalDebit);
					}

					break;
				case "TotalCredit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.TotalCredit);
					}
					else {
						data = data.OrderByDescending(t => t.TotalCredit);
					}

					break;
				case "TotalCommission":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.TotalCommission);
					}
					else {
						data = data.OrderByDescending(t => t.TotalCommission);
					}

					break;
				case "TotalDiscount":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.TotalDiscount);
					}
					else {
						data = data.OrderByDescending(t => t.TotalDiscount);
					}

					break;
				case "TotalNonCommissionable":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.TotalNonCommissionable);
					}
					else {
						data = data.OrderByDescending(t => t.TotalNonCommissionable);
					}

					break;
			}

			return data;
		}

		public static IQueryable<TransactionViewModel> ApplyPaging(this IQueryable<TransactionViewModel> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}
	}

	public static class TransactionDetailBindingExtensions {
		public static IQueryable<TransactionDetail> ApplyFiltering(this IQueryable<TransactionDetail> data, IList<IFilterDescriptor> filterDescriptors) {
			if (filterDescriptors?.Count > 0)
				data = data.Where(ExpressionBuilder.Expression<TransactionDetail>(filterDescriptors, false));

			return data;
		}

		public static IQueryable<TransactionDetail> ApplySorting(this IQueryable<TransactionDetail> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<TransactionDetail> AddSortExpression(IQueryable<TransactionDetail> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "TransactionTypeDescription":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.Transaction.TransactionType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.Transaction.TransactionType);
					}

					break;
				case "DocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Transaction.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.Transaction.DocumentNo);
					}

					break;
				case "DocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Transaction.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.Transaction.DocumentDate);
					}

					break;
				case "AccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.AccountName);
					}
					else {
						data = data.OrderByDescending(t => t.AccountName);
					}

					break;
				case "Reference":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Reference);
					}
					else {
						data = data.OrderByDescending(t => t.Reference);
					}

					break;
				case "Description":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Description);
					}
					else {
						data = data.OrderByDescending(t => t.Description);
					}

					break;
				case "Debit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.SignType == SignType.Debit ? t.Amount + t.Tax : 0);
					}
					else {
						data = data.OrderByDescending(t => t.SignType == SignType.Debit ? t.Amount + t.Tax : 0);
					}

					break;
				case "Credit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.SignType == SignType.Credit ? t.Amount + t.Tax : 0);
					}
					else {
						data = data.OrderByDescending(t => t.SignType == SignType.Credit ? t.Amount + t.Tax : 0);
					}

					break;
			}

			return data;
		}

		public static IEnumerable<TransactionDetailViewModel> ApplyPaging(this IEnumerable<TransactionDetailViewModel> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}
	}

	public static class TransactionDetailAllocationBindingExtensions {
		public static IEnumerable<TransactionDetailAllocationViewModel> ApplyPaging(this IEnumerable<TransactionDetailAllocationViewModel> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}
	}

	public static class DebtorLedgerTransactionBindingExtensions {
		public static IQueryable<DebtorLedgerTransaction> ApplyFiltering(this IQueryable<DebtorLedgerTransaction> data, IList<IFilterDescriptor> filterDescriptors) {
			if (filterDescriptors?.Count > 0)
				data = data.AsQueryable().Where(ExpressionBuilder.Expression<DebtorLedgerTransaction>(filterDescriptors, false));

			return data;
		}

		public static IQueryable<DebtorLedgerTransaction> ApplySorting(this IQueryable<DebtorLedgerTransaction> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<DebtorLedgerTransaction> AddSortExpression(IQueryable<DebtorLedgerTransaction> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "TransactionType":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.TransactionType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.TransactionType);
					}

					break;
				case "DocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentNo);
					}

					break;
				case "DocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentDate);
					}

					break;
				case "Description":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Description);
					}
					else {
						data = data.OrderByDescending(t => t.Description);
					}

					break;
				case "Reference":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Reference);
					}
					else {
						data = data.OrderByDescending(t => t.Reference);
					}

					break;
				case "Debit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.SignType == SignType.Credit ? (decimal?)null : t.AmountGross);
					}
					else {
						data = data.OrderByDescending(t => t.SignType == SignType.Credit ? (decimal?)null : t.AmountGross);
					}

					break;
				case "Credit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.SignType == SignType.Credit ? t.AmountGross : (decimal?)null);
					}
					else {
						data = data.OrderByDescending(t => t.SignType == SignType.Credit ? t.AmountGross : (decimal?)null);
					}

					break;
			}

			return data;
		}
	}

	public static class CreditorLedgerTransactionBindingExtensions {
		public static IQueryable<CreditorLedgerTransaction> ApplyFiltering(this IQueryable<CreditorLedgerTransaction> data, IList<IFilterDescriptor> filterDescriptors) {
			if (filterDescriptors?.Count > 0)
				data = data.AsQueryable().Where(ExpressionBuilder.Expression<CreditorLedgerTransaction>(filterDescriptors, false));

			return data;
		}

		public static IQueryable<CreditorLedgerTransaction> ApplySorting(this IQueryable<CreditorLedgerTransaction> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<CreditorLedgerTransaction> AddSortExpression(IQueryable<CreditorLedgerTransaction> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "TransactionType":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.TransactionType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.TransactionType);
					}

					break;
				case "DocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentNo);
					}

					break;
				case "DocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentDate);
					}

					break;
				case "Description":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Description);
					}
					else {
						data = data.OrderByDescending(t => t.Description);
					}

					break;
				case "Reference":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Reference);
					}
					else {
						data = data.OrderByDescending(t => t.Reference);
					}

					break;
				case "Debit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.SignType == SignType.Credit ? (decimal?)null : t.AmountGross);
					}
					else {
						data = data.OrderByDescending(t => t.SignType == SignType.Credit ? (decimal?)null : t.AmountGross);
					}

					break;
				case "Credit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.SignType == SignType.Credit ? t.AmountGross : (decimal?)null);
					}
					else {
						data = data.OrderByDescending(t => t.SignType == SignType.Credit ? t.AmountGross : (decimal?)null);
					}

					break;
			}

			return data;
		}
	}

	public static class BankReconciliationBindingExtensions {
		public static IEnumerable<BankReconciliationViewModel> ApplySorting(this IEnumerable<BankReconciliationViewModel> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IEnumerable<BankReconciliationViewModel> AddSortExpression(IEnumerable<BankReconciliationViewModel> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "AccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.AccountName);
					}
					else {
						data = data.OrderByDescending(t => t.AccountName);
					}

					break;
				case "DocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentNo);
					}

					break;
				case "DocumentDate":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentDate);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentDate);
					}

					break;
				case "DocumentType":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentType);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentType);
					}

					break;
				case "FormOfPayment":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.FormOfPayment);
					}
					else {
						data = data.OrderByDescending(t => t.FormOfPayment);
					}

					break;
				case "BankAccountName":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.BankAccountName);
					}
					else {
						data = data.OrderByDescending(t => t.BankAccountName);
					}

					break;
				case "Debit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Debit ?? 0);
					}
					else {
						data = data.OrderByDescending(t => t.Debit ?? 0);
					}

					break;
				case "Credit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Credit ?? 0);
					}
					else {
						data = data.OrderByDescending(t => t.Credit ?? 0);
					}

					break;
			}

			return data;
		}

		public static IEnumerable<BankReconciliationViewModel> ApplyPaging(this IEnumerable<BankReconciliationViewModel> data, int page, int pageSize) {
			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}
	}

	public static class SalesAnalysisBindingExtensions {
		public class MemberModel {
			public string Member { get; set; }
			public int MemberCount { get; set; }
			public int Level { get; set; }
			public object Value { get; set; }
		}

		public static IQueryable<TransactionDetail> ApplyFiltering(this IQueryable<TransactionDetail> data, IList<IFilterDescriptor> filterDescriptors, bool autoOperation = true) {
			if (autoOperation) {
				if (filterDescriptors?.Count > 0)
					data = data.Where(ExpressionBuilder.Expression<TransactionDetail>(filterDescriptors, false));

				return data;
			}

			var transactionDescriptors = new List<IFilterDescriptor>();
			var transactionDetailDescriptors = new List<IFilterDescriptor>();
			var manualDescriptors = new Dictionary<string, object>();

			if (filterDescriptors?.Count > 0) {
				if (filterDescriptors[0].GetType() == typeof(CompositeFilterDescriptor)) {
					foreach (CompositeFilterDescriptor compositeDescriptor in filterDescriptors) {
						AddFilterDescriptor(compositeDescriptor.FilterDescriptors, transactionDescriptors, transactionDetailDescriptors, manualDescriptors);
					}
				}
				else {
					AddFilterDescriptor(filterDescriptors, transactionDescriptors, transactionDetailDescriptors, manualDescriptors);
				}

				if (transactionDescriptors.Count > 0)
					data = data.Select(t => t.Transaction).Where(ExpressionBuilder.Expression<Transaction>(transactionDescriptors, false)).SelectMany(t => t.TransactionDetails);

				if (transactionDetailDescriptors.Count > 0)
					data = data.Where(ExpressionBuilder.Expression<TransactionDetail>(transactionDetailDescriptors, false));

				foreach (var descriptor in manualDescriptors) {
					switch (descriptor.Key) {
						case "Account":
							data = data.Where(TransactionDetail.AccountNameWhereClause(descriptor.Value, false));
							break;
						case "Airline":
							data = data.Where(TransactionDetail.AirlineNameWhereClause(descriptor.Value, false));
							break;
						case "Passenger":
							data = data.Where(TransactionDetail.PassengerNameWhereClause(descriptor.Value, false));
							break;
						case "OfferedReason":
							data = data.Where(TransactionDetail.OfferedReasonNameWhereClause(descriptor.Value, false));
							break;
						case "Debtor":
							data = data.Where(TransactionDetail.DebtorNameWhereClause(descriptor.Value, false));
							break;
						case "Creditor":
							data = data.Where(TransactionDetail.CreditorNameWhereClause(descriptor.Value, false));
							break;
						case "Supplier":
							data = data.Where(TransactionDetail.SupplierNameWhereClause(descriptor.Value, false));
							break;
						case "SaleType":
							data = data.Where(TransactionDetail.SaleTypeNameWhereClause(descriptor.Value, false));
							break;
						case "DiscountReason":
							data = data.Where(TransactionDetail.DiscountReasonNameWhereClause(descriptor.Value, false));
							break;
						case "Group":
							data = data.Where(TransactionDetail.GroupNameWhereClause(descriptor.Value, false));
							break;
						case "Class":
							data = data.Where(TransactionDetail.ClassNameWhereClause(descriptor.Value, false));
							break;
						case "Source":
							data = data.Where(TransactionDetail.SourceNameWhereClause(descriptor.Value, false));
							break;
						case "Category":
							data = data.Where(TransactionDetail.CategoryNameWhereClause(descriptor.Value, false));
							break;
						case "Destination":
							data = data.Where(TransactionDetail.DestinationNameWhereClause(descriptor.Value, false));
							break;
						case "Region":
							data = data.Where(TransactionDetail.RegionNameWhereClause(descriptor.Value, false));
							break;
						case "Location":
							data = data.Where(TransactionDetail.LocationNameWhereClause(descriptor.Value, false));
							break;
						case "Agency":
							data = data.Where(TransactionDetail.AgencyNameWhereClause(descriptor.Value, false));
							break;
						case "Consultant":
							data = data.Where(TransactionDetail.ConsultantNameWhereClause(descriptor.Value, false));
							break;
						case "Agent":
							data = data.Where(TransactionDetail.AgentNameWhereClause(descriptor.Value, false));
							break;
					}
				}
			}

			return data;
		}

		private static void AddFilterDescriptor(IList<IFilterDescriptor> filterDescriptors, IList<IFilterDescriptor> transactionDescriptors, IList<IFilterDescriptor> transactionDetailDescriptors, Dictionary<string, object> manualDescriptors) {
			foreach (FilterDescriptor descriptor in filterDescriptors) {
				switch (descriptor.Member) {
					default:
						transactionDetailDescriptors.Add(descriptor);
						break;
					case "TransactionType":
					case "DocumentType":
					case "DocumentNo":
					case "DocumentDate":
						transactionDescriptors.Add(descriptor);
						break;
					case "Account":
					case "Airline":
					case "Passenger":
					case "Debtor":
					case "Creditor":
					case "Supplier":
					case "SaleType":
					case "DiscountReason":
					case "Group":
					case "Class":
					case "Source":
					case "Category":
					case "Destination":
					case "Region":
					case "Location":
					case "Agency":
					case "Consultant":
					case "Agent":
						manualDescriptors.Add(descriptor.Member, descriptor.Value);
						break;
				}
			}
		}

		public static IQueryable<TransactionDetail> ApplyPaging(this IQueryable<TransactionDetail> data, int page, int pageSize, bool ignorePaging) {
			if (ignorePaging)
				return data;

			return data.Skip((page - 1) * pageSize).Take(pageSize);
		}

		public static IEnumerable ApplyGrouping(this IEnumerable<SalesAnalysisReportModel> data, IList<GroupDescriptor> groupDescriptors, IQueryable<TransactionDetail> dataSet, IList<MemberModel> members, bool isTaxIncluded) {
			if (groupDescriptors == null || groupDescriptors.Count == 0)
				return data;

			Func<IEnumerable<SalesAnalysisReportModel>, IEnumerable<AggregateFunctionsGroup>> selector = null;

			foreach (var descriptor in groupDescriptors.Reverse()) {
				switch (descriptor.Member) {
					case "TransactionType":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.TransactionType, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.TransactionType, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "DocumentType":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.DocumentType, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.DocumentType, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "DocumentNo":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.DocumentNo, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.DocumentNo, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "DocumentDate":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.DocumentDate, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.DocumentDate, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "AccountName":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Account, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Account, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Airline":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Airline, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Airline, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Passenger":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Passenger, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Passenger, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "DepartureDate":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.DepartureDate, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.DepartureDate, selector, dataSet, members, isTaxIncluded);
						}

						break;
                    case "ReturnDate":
                        if (selector == null) {
                            selector = group => BuildInnerGroup(t => t.ReturnDate, group, dataSet, members, isTaxIncluded);
                        }
                        else {
                            selector = BuildGroup(t => t.ReturnDate, selector, dataSet, members, isTaxIncluded);
                        }

                        break;
                    case "Reference":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Reference, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Reference, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Debtor":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Debtor, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Debtor, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Creditor":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Creditor, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Creditor, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Supplier":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Supplier, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Supplier, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "SaleType":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.SaleType, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.SaleType, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "DiscountReason":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.DiscountReason, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.DiscountReason, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Group":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Group, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Group, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Class":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Class, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Class, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Source":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Source, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Source, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Category":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Category, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Category, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Destination":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Destination, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Destination, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Region":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Region, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Region, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Location":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Location, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Location, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Agency":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Agency, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Agency, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Consultant":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Consultant, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Consultant, selector, dataSet, members, isTaxIncluded);
						}

						break;
					case "Agent":
						if (selector == null) {
							selector = group => BuildInnerGroup(t => t.Agent, group, dataSet, members, isTaxIncluded);
						}
						else {
							selector = BuildGroup(t => t.Agent, selector, dataSet, members, isTaxIncluded);
						}

						break;
				}
			}

			return selector.Invoke(data).ToList();
		}

		private static Func<IEnumerable<SalesAnalysisReportModel>, IEnumerable<AggregateFunctionsGroup>> BuildGroup<T>(Expression<Func<SalesAnalysisReportModel, T>> groupSelector, Func<IEnumerable<SalesAnalysisReportModel>, IEnumerable<AggregateFunctionsGroup>> selectorBuilder, IQueryable<TransactionDetail> dataSet, IList<MemberModel> members, bool isTaxIncluded) {
			string member = groupSelector.MemberWithoutInstance();
			var tempSelector = selectorBuilder;

			return group => group.GroupBy(groupSelector.Compile()).Select(row => new AggregateFunctionsGroup {
				Key = row.Key,
				HasSubgroups = true,
				Member = member,
				Items = tempSelector.Invoke(row).ToList(),
				AggregateFunctionsProjection = GetAggregateFunctionsProjection(dataSet, members, member, row.Key, isTaxIncluded)
			});
		}

		private static IEnumerable<AggregateFunctionsGroup> BuildInnerGroup<T>(Expression<Func<SalesAnalysisReportModel, T>> groupSelector, IEnumerable<SalesAnalysisReportModel> group, IQueryable<TransactionDetail> dataSet, IList<MemberModel> members, bool isTaxIncluded) {
			string member = groupSelector.MemberWithoutInstance();

			return group.GroupBy(groupSelector.Compile()).Select(row => new AggregateFunctionsGroup {
				Key = row.Key,
				Member = member,
				Items = row.ToList(),
				AggregateFunctionsProjection = GetAggregateFunctionsProjection(dataSet, members, member, row.Key, isTaxIncluded)
			});
		}

		private static object GetAggregateFunctionsProjection(IQueryable<TransactionDetail> dataSet, IList<MemberModel> members, string member, object value, bool isTaxIncluded) {
			int memberCount = members.Count(t => t.Member == member) + 1;
			int level = members.FirstOrDefault(t => t.Member == member)?.Level ?? (members.Max(t => (int?)t.Level) ?? 0) + 1;

			members.Add(new MemberModel { Member = member, MemberCount = memberCount, Level = level, Value = value });

			foreach (var item in members.Where(t => (t.Member == member && t.MemberCount == memberCount) || t.Level < level)) {
				if (item.Member != member && item.MemberCount != members.Count(t => t.Member == item.Member && t.Level == item.Level))
					continue;

				switch (item.Member) {
					case "TransactionType":
						dataSet = dataSet.Where(t => t.Transaction.TransactionType.Equals(item.Value));
						break;
					case "DocumentType":
						dataSet = dataSet.Where(t => t.Transaction.DocumentType.Equals(item.Value));
						break;
					case "DocumentNo":
						dataSet = dataSet.Where(t => t.Transaction.DocumentNo.Equals(item.Value));
						break;
					case "DocumentDate":
						dataSet = dataSet.Where(t => t.Transaction.DocumentDate.Equals(item.Value));
						break;
					case "AccountName":
						dataSet = dataSet.Where(TransactionDetail.AccountNameWhereClause(item.Value));
						break;
					case "Airline":
						dataSet = dataSet.Where(TransactionDetail.AirlineNameWhereClause(item.Value));
						break;
					case "Passenger":
						dataSet = dataSet.Where(TransactionDetail.PassengerNameWhereClause(item.Value));
						break;
					case "OfferedReason":
						dataSet = dataSet.Where(TransactionDetail.OfferedReasonNameWhereClause(item.Value));
						break;
					case "DepartureDate":
						dataSet = dataSet.Where(t => t.Trip.DepartureDate.Equals(item.Value));
						break;
					case "Reference":
						dataSet = dataSet.Where(t => t.Reference.Equals(item.Value));
						break;
					case "Debtor":
						dataSet = dataSet.Where(TransactionDetail.DebtorNameWhereClause(item.Value));
						break;
					case "Creditor":
						dataSet = dataSet.Where(TransactionDetail.CreditorNameWhereClause(item.Value));
						break;
					case "Supplier":
						dataSet = dataSet.Where(TransactionDetail.SupplierNameWhereClause(item.Value));
						break;
					case "SaleType":
						dataSet = dataSet.Where(TransactionDetail.SaleTypeNameWhereClause(item.Value));
						break;
					case "DiscountReason":
						dataSet = dataSet.Where(TransactionDetail.DiscountReasonNameWhereClause(item.Value));
						break;
					case "Group":
						dataSet = dataSet.Where(TransactionDetail.GroupNameWhereClause(item.Value));
						break;
					case "Class":
						dataSet = dataSet.Where(TransactionDetail.ClassNameWhereClause(item.Value));
						break;
					case "Source":
						dataSet = dataSet.Where(TransactionDetail.SourceNameWhereClause(item.Value));
						break;
					case "Category":
						dataSet = dataSet.Where(TransactionDetail.CategoryNameWhereClause(item.Value));
						break;
					case "Destination":
						dataSet = dataSet.Where(TransactionDetail.DestinationNameWhereClause(item.Value));
						break;
					case "Region":
						dataSet = dataSet.Where(TransactionDetail.RegionNameWhereClause(item.Value));
						break;
					case "Location":
						dataSet = dataSet.Where(TransactionDetail.LocationNameWhereClause(item.Value));
						break;
					case "Agency":
						dataSet = dataSet.Where(TransactionDetail.AgencyNameWhereClause(item.Value));
						break;
					case "Consultant":
						dataSet = dataSet.Where(TransactionDetail.ConsultantNameWhereClause(item.Value));
						break;
					case "Agent":
						dataSet = dataSet.Where(TransactionDetail.AgentNameWhereClause(item.Value));
						break;
				}
			}

			decimal totalCommission = 0;
			decimal totalCash = 0;
			decimal totalCashNonCommissionable = 0;
			decimal totalCreditCard = 0;
			decimal totalCreditCardNonCommissionable = 0;
			decimal totalGross = 0;
			decimal totalNonCommissionable = 0;
			decimal totalNet = 0;
			decimal totalYield = 0;

			var q = (from t1 in dataSet.AsEnumerable()
					 group t1 by 1 into t2
					 select new {
						 TotalCommission = t2.Sum(t3 => (decimal?)(isTaxIncluded ? t3.CommissionLessDiscountGross : t3.CommissionLessDiscount)) ?? 0,
						 TotalCash = t2.Sum(t3 => (decimal?)(isTaxIncluded ? t3.CashLessNonCommissionableGross : t3.CashLessNonCommissionable)) ?? 0,
						 TotalCashNonCommissionable = t2.Sum(t3 => (decimal?)t3.CashNonCommissionable) ?? 0,
						 TotalCreditCard = t2.Sum(t3 => (decimal?)(isTaxIncluded ? t3.CreditCardLessNonCommissionableGross : t3.CreditCardLessNonCommissionable)) ?? 0,
						 TotalCreditCardNonCommissionable = t2.Sum(t3 => (decimal?)t3.CreditCardNonCommissionable) ?? 0
					 }).SingleOrDefault();

			if (q != null) {
				totalCommission = q.TotalCommission;
				totalCash = q.TotalCash;
				totalCashNonCommissionable = q.TotalCashNonCommissionable;
				totalCreditCard = q.TotalCreditCard;
				totalCreditCardNonCommissionable = q.TotalCreditCardNonCommissionable;
				totalGross = q.TotalCash + q.TotalCreditCard;
				totalNonCommissionable = totalCashNonCommissionable + totalCreditCardNonCommissionable;
				totalNet = totalGross + totalNonCommissionable - totalCommission;
				totalYield = totalCash + totalCreditCard == 0 ? (totalCommission == 0 ? 0 : 1) : totalCommission / (totalCash + totalCreditCard);
			}

			return new {
				TotalCommission = new AggregateResult(totalCommission, new SumFunction { FunctionName = "Sum", SourceField = "Commission", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				TotalCash = new AggregateResult(totalCash, new SumFunction { FunctionName = "Sum", SourceField = "Cash", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				TotalCashNonCommissionable = new AggregateResult(totalCashNonCommissionable, new SumFunction { FunctionName = "Sum", SourceField = "CashNonCommissionable", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				TotalCreditCard = new AggregateResult(totalCreditCard, new SumFunction { FunctionName = "Sum", SourceField = "CreditCard", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				TotalCreditCardNonCommissionable = new AggregateResult(totalCreditCardNonCommissionable, new SumFunction { FunctionName = "Sum", SourceField = "CreditCardNonCommissionable", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				TotalGross = new AggregateResult(totalGross, new SumFunction { FunctionName = "Sum", SourceField = "AmountGross", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				TotalNonCommissionable = new AggregateResult(totalNonCommissionable, new SumFunction { FunctionName = "Sum", SourceField = "NonCommissionable", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				TotalNet = new AggregateResult(totalNet, new SumFunction { FunctionName = "Sum", SourceField = "AmountNet", MemberType = typeof(decimal), ResultFormatString = "{0:c2}" }),
				TotalYield = new AggregateResult(totalYield, new SumFunction { FunctionName = "Sum", SourceField = "Yield", MemberType = typeof(decimal), ResultFormatString = "{0:p3}" })
			};
		}
	}

	public static class CustomerTransactionBindingExtensions {
		public static IQueryable<CustomerTransactionView> ApplySorting(this IQueryable<CustomerTransactionView> data, IList<GroupDescriptor> groupDescriptors, IList<SortDescriptor> sortDescriptors) {
			if (groupDescriptors?.Count > 0) {
				foreach (var descriptor in groupDescriptors.Reverse()) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			if (sortDescriptors?.Count > 0) {
				foreach (var descriptor in sortDescriptors) {
					data = AddSortExpression(data, descriptor.SortDirection, descriptor.Member);
				}
			}

			return data;
		}

		private static IQueryable<CustomerTransactionView> AddSortExpression(IQueryable<CustomerTransactionView> data, ListSortDirection sortDirection, string member) {
			switch (member) {
				case "CustomerTransactionNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Id);
					}
					else {
						data = data.OrderByDescending(t => t.Id);
					}

					break;
				case "CustomerTransactionTypeId":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => (int)t.CustomerTransactionType);
					}
					else {
						data = data.OrderByDescending(t => (int)t.CustomerTransactionType);
					}

					break;
				case "DateFrom":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DateFrom);
					}
					else {
						data = data.OrderByDescending(t => t.DateFrom);
					}

					break;
				case "DateTo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DateTo);
					}
					else {
						data = data.OrderByDescending(t => t.DateTo);
					}

					break;
				case "DateDue":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DateDue);
					}
					else {
						data = data.OrderByDescending(t => t.DateDue);
					}

					break;
				case "CustomerTransactionUserCount":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.UserCount);
					}
					else {
						data = data.OrderByDescending(t => t.UserCount);
					}

					break;
				case "CustomerTransactionUserCharge":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.UserCharge);
					}
					else {
						data = data.OrderByDescending(t => t.UserCharge);
					}

					break;
				case "Debit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Debit);
					}
					else {
						data = data.OrderByDescending(t => t.Debit);
					}

					break;
				case "Credit":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Credit);
					}
					else {
						data = data.OrderByDescending(t => t.Credit);
					}

					break;
				case "Balance":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.Balance);
					}
					else {
						data = data.OrderByDescending(t => t.Balance);
					}

					break;
				case "DocumentNo":
					if (sortDirection == ListSortDirection.Ascending) {
						data = data.OrderBy(t => t.DocumentNo);
					}
					else {
						data = data.OrderByDescending(t => t.DocumentNo);
					}

					break;
			}

			return data;
		}
	}
}