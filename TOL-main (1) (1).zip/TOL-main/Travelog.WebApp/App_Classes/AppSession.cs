﻿using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace Travelog.WebApp {
    public static class AppSession {
        public static async Task<T> GetSessionValueAsync<T>(this HttpContext httpContext, SessionKey key) {
            if (httpContext == null)
                return default;

            await httpContext.Session.LoadAsync();
            string value = httpContext.Session.GetString(key.ToString());

            if (value == null)
                return default;

            return JsonSerializer.Deserialize<T>(value);
        }

        public static async Task SetSessionValueAsync(this HttpContext httpContext, SessionKey key, object value) {
            if (httpContext == null)
                return;

            await httpContext.Session.LoadAsync();
            httpContext.Session.SetString(key.ToString(), JsonSerializer.Serialize(value));
        }

        public static async Task RemoveSessionValueAsync(this HttpContext httpContext, SessionKey key) {
            if (httpContext == null)
                return;

            await httpContext.Session.LoadAsync();
            httpContext.Session.Remove(key.ToString());
        }

        public static async Task ClearSessionAsync(this HttpContext httpContext) {
            if (httpContext == null)
                return;

            await httpContext.Session.LoadAsync();
            httpContext.Session.Clear();
        }
    }

    public enum SessionKey {
        AuthenticationStartTime = 0,
        SessionExpiryStatus = 1,
        GoogleAccountSecretKey = 2,
        NewUserMessage = 3,
        ImageContent = 4
    }
}