﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;

namespace Travelog.WebApp {
	public static class RouteConfig {
		public static void RegisterRoutes(this IEndpointRouteBuilder endpoint) {
			endpoint.MapControllerRoute(
				name: "Login",
				pattern: "Account/Login",
				defaults: new { controller = "Account", action = "SignIn" }
			);

			endpoint.MapControllerRoute(
				name: "ResourceNotFound",
				pattern: "ResourceNotFound",
				defaults: new { controller = "Shared", action = "ResourceNotFound" }
			);

			endpoint.MapControllerRoute(
				name: "Error",
				pattern: "Error",
				defaults: new { controller = "Shared", action = "Error" }
			);

			endpoint.MapControllerRoute(
				name: "NotAuthorised",
				pattern: "NotAuthorised",
				defaults: new { controller = "Shared", action = "NotAuthorised" }
			);

            endpoint.MapControllerRoute(
                name: "SupplierChains",
                pattern: "Maintenance/SupplierChains",
                defaults: new { controller = "CreditorLedger", action = "SupplierChains" }
            );

            endpoint.MapControllerRoute(
				name: "AccountManagement",
				pattern: "Admin/AccountManagement",
				defaults: new { controller = "Account", action = "CustomerAccount" }
			);

			endpoint.MapControllerRoute(
				name: "UserAccounts",
				pattern: "Admin/UserAccounts",
				defaults: new { controller = "Account", action = "UserAccounts" }
			);

			endpoint.MapControllerRoute(
				name: "UserRoles",
				pattern: "Admin/UserRoles",
				defaults: new { controller = "Account", action = "UserRoles" }
			);

            endpoint.MapControllerRoute(
                name: "GeneralLedgerSettings",
                pattern: "Admin/GeneralLedgerSettings",
                defaults: new { controller = "GeneralLedger", action = "GeneralLedgerSettings" }
            );

            endpoint.MapControllerRoute(
				name: "AuditLog",
				pattern: "Admin/AuditLog",
				defaults: new { controller = "Account", action = "AuditLog" }
			);

			endpoint.MapControllerRoute(
				name: "Admin",
				pattern: "Admin/{action}",
				defaults: new { controller = "Common" }
			);

			endpoint.MapControllerRoute(
				name: "Maintenance",
				pattern: "Maintenance/{action}",
				defaults: new { controller = "Common" }
			);

			endpoint.MapControllerRoute(
				name: "Default",
				pattern: "{controller}/{action}/{id?}",
				defaults: new { controller = "Home", action = "Index" }
			);
		}
	}
}