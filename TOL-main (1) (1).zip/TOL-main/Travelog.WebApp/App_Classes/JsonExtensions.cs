using System;
using System.IO;
using System.Text.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Travelog.WebApp {
    public static class JsonExtensions {
        public static IMvcBuilder AddJsonOptions(this IMvcBuilder builder, string settingsName, Action<JsonOptions> configureOptions) {
            ArgumentNullException.ThrowIfNull(builder);
            ArgumentNullException.ThrowIfNull(configureOptions);

            builder.Services.Configure(settingsName, configureOptions);

            builder.Services.AddSingleton<IConfigureOptions<MvcOptions>>(configuration => {
                var jsonOptions = configuration.GetRequiredService<IOptionsMonitor<JsonOptions>>();
                var loggerFactory = configuration.GetRequiredService<ILoggerFactory>();
                return new ConfigureMvcJsonOptions(settingsName, jsonOptions, loggerFactory);
            });

            return builder;
        }

        public static IMvcBuilder AddNewtonsoftJson(this IMvcBuilder builder, string settingsName, Action<MvcNewtonsoftJsonOptions> configureOptions) {
            ArgumentNullException.ThrowIfNull(builder);
            ArgumentNullException.ThrowIfNull(configureOptions);

            NewtonsoftJsonMvcBuilderExtensions.AddNewtonsoftJson(builder);
            builder.Services.Configure(settingsName, configureOptions);

            builder.Services.AddSingleton<IConfigureOptions<MvcOptions>>(configuration => {
                var jsonOptions = configuration.GetRequiredService<IOptionsMonitor<JsonOptions>>();
                var loggerFactory = configuration.GetRequiredService<ILoggerFactory>();
                return new ConfigureMvcJsonOptions(settingsName, jsonOptions, loggerFactory);
            });

            return builder;
        }

        public static string GetJsonSettingsName(this HttpContext context) {
            return context.GetEndpoint()?.Metadata.GetMetadata<JsonSettingsNameAttribute>()?.Name;
        }

        public static IConfiguration ResolveConfiguration(this IWebHostEnvironment webHostEnvironment) {
            string filePath = Path.Combine(webHostEnvironment.ContentRootPath, "appsettings.json");
            return new ConfigurationBuilder().AddJsonFile(filePath, true).Build();
        }
    }

    public class ConfigureMvcJsonOptions : IConfigureOptions<MvcOptions> {
        private readonly string JsonSettingsName;
        private readonly IOptionsMonitor<JsonOptions> JsonOptions;
        private readonly ILoggerFactory LoggerFactory;

        public ConfigureMvcJsonOptions(string jsonSettingsName, IOptionsMonitor<JsonOptions> jsonOptions, ILoggerFactory loggerFactory) {
            JsonSettingsName = jsonSettingsName;
            JsonOptions = jsonOptions;
            LoggerFactory = loggerFactory;
        }

        public void Configure(MvcOptions options) {
            var jsonOptions = JsonOptions.Get(JsonSettingsName);
            var logger = LoggerFactory.CreateLogger<SystemTextJsonInputFormatterExt>();
            options.InputFormatters.Insert(0, new SystemTextJsonInputFormatterExt(JsonSettingsName, jsonOptions, logger));
            options.OutputFormatters.Insert(0, new SystemTextJsonOutputFormatterExt(JsonSettingsName, jsonOptions.JsonSerializerOptions));
        }
    }

    public class SystemTextJsonInputFormatterExt : SystemTextJsonInputFormatter {
        public string SettingsName { get; }

        public SystemTextJsonInputFormatterExt(string settingsName, JsonOptions options, ILogger<SystemTextJsonInputFormatterExt> logger) : base(options, logger) {
            SettingsName = settingsName;
        }

        public override bool CanRead(InputFormatterContext context) {
            if (context.HttpContext.GetJsonSettingsName() != SettingsName)
                return false;

            return base.CanRead(context);
        }
    }

    public class SystemTextJsonOutputFormatterExt : SystemTextJsonOutputFormatter {
        public string SettingsName { get; }

        public SystemTextJsonOutputFormatterExt(string settingsName, JsonSerializerOptions jsonSerializerOptions) : base(jsonSerializerOptions) {
            SettingsName = settingsName;
        }

        public override bool CanWriteResult(OutputFormatterCanWriteContext context) {
            if (context.HttpContext.GetJsonSettingsName() != SettingsName)
                return false;

            return base.CanWriteResult(context);
        }
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class JsonSettingsNameAttribute : Attribute {
        public string Name { get; }

        public JsonSettingsNameAttribute(string name) {
            Name = name;
        }
    }
}