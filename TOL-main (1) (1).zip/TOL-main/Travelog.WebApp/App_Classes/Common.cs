using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.Admin;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Enums;
using Travelog.PaymentGateway;
using Travelog.PaymentGateway.Enums;
using Travelog.WebApp.Admin;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.Common {
    public static class ProcessPaymentCommon {
        public static bool CreateOrUpdate(HttpContext httpContext, AppAdminContext adminContext, AppMainContext context, ProcessPaymentViewModel model, int customerId, bool isCardOnFile, string encryptedCardNo, string encryptedCvn) {
            if (httpContext.CurrentCustomerId() == (int)CustomerType.TravelogDev || httpContext.CurrentCustomerId() == (int)CustomerType.TravelogStaging || httpContext.CurrentCustomerId() == (int)CustomerType.TravelogProd)
                throw new ReportedException("Management companies cannot make payments.");

            if (httpContext.IsExternalUser())
                throw new ReportedException(AppConstants.UnauthorisedAccessRemoteAssistanceUser);

            bool isRefund = model.ProcessPaymentIsRefund;

            //if (isRefund && !ProcessPaymentTypeIdIsEnabled(httpContext, model.ProcessPaymentClientType))
            if (isRefund)
                throw new ReportedException("Refunds are not supported.");

            if (model.ProcessPaymentClientType == PaymentGatewayClientType.Principal) {
                if (httpContext.IsGlobalUser()) {
                    if (!isRefund && customerId > (int)CustomerType.TravelogProd)
                        throw new ReportedException("Support providers cannot make payments on behalf of customers.");
                }
                else if (isRefund) {
                    throw new ReportedException("Only support providers can process refunds.");
                }
            }

            using (var ts = Utils.CreateTransactionScope()) {
                model.ProcessPaymentPaymentMethodId ??= 0;

                var eWay = new Eway(customerId, model.ProcessPaymentClientType, AppSettings.IsDevelopmentMode);

                string expiryMonth = model.ProcessPaymentExpiryDate.Left(2);
                string expiryYear = model.ProcessPaymentExpiryDate.Substring(3, 4);

                int amount = (int)(model.ProcessPaymentAmount * 100);
                long tokenCustomerId = 0;

                if (model.ProcessPaymentPaymentMethodId > 0) {
                    if (model.ProcessPaymentClientType == PaymentGatewayClientType.Principal) {
                        var q = adminContext.CustomerPaymentMethod.Find(model.ProcessPaymentPaymentMethodId);
                        tokenCustomerId = q.TokenCustomerId;
                    }
                    else {
                        var q = context.PaymentMethod.Find(model.ProcessPaymentPaymentMethodId);
                        tokenCustomerId = q.TokenCustomerId;
                    }
                }

                int paymentTransactionId;
                var customer = adminContext.Customer.Include(t => t.CustomerTransactions).Single(t => t.Id == customerId);

                if (isCardOnFile) {
                    tokenCustomerId = eWay.CreateOrUpdateTokenCustomer(
                        cardNo: encryptedCardNo,
                        cardholderName: model.ProcessPaymentCardholderName,
                        expiryMonth: expiryMonth,
                        expiryYear: expiryYear,
                        cvn: encryptedCvn,
                        countryIsoCode: customer.CountryIsoCode,
                        tokenCustomerId: tokenCustomerId
                    );
                }

                var companyAddress = new eWAY.Rapid.Models.Address {
                    Street1 = customer.Address1,
                    Street2 = customer.Address2,
                    City = customer.Locality,
                    State = customer.Region,
                    PostalCode = customer.PostCode,
                    Country = customer.CountryIsoCode
                };

                if (isRefund) {
                    paymentTransactionId = eWay.ProcessRefund(
                        transactionId: customer.CustomerTransactions.OrderByDescending(t => t.PaymentTransactionId).FirstOrDefault(t => t.IsInvoiceItem && t.PaymentTransactionId != 0)?.PaymentTransactionId ?? 0,
                        expiryMonth: expiryMonth,
                        expiryYear: expiryYear,
                        amount: amount,
                        currencyCode: customer.CurrencyCode,
                        companyName: customer.GetBusinessName(),
                        companyAddress: companyAddress,
                        contactName: customer.BillingContactName,
                        contactPhone: customer.BillingContactPhone,
                        contactEmail: customer.BillingContactEmail
                    );
                }
                else {
                    if (tokenCustomerId == 0) {
                        paymentTransactionId = eWay.MakeNonTokenPayment(cardNo: encryptedCardNo,
                            cardholderName: model.ProcessPaymentCardholderName,
                            expiryMonth: expiryMonth,
                            expiryYear: expiryYear,
                            cvn: encryptedCvn,
                            amount: amount,
                            currencyCode: customer.CurrencyCode,
                            transactionType: PaymentGatewayTransactionType.Purchase,
                            companyName: customer.GetBusinessName(),
                            companyAddress: companyAddress,
                            contactName: customer.BillingContactName,
                            contactPhone: customer.BillingContactPhone,
                            contactEmail: customer.BillingContactEmail
                        );
                    }
                    else {
                        paymentTransactionId = eWay.MakeTokenPayment(
                            tokenCustomerId: tokenCustomerId,
                            cardNo: encryptedCardNo,
                            cardholderName: model.ProcessPaymentCardholderName,
                            expiryMonth: expiryMonth,
                            expiryYear: expiryYear,
                            cvn: encryptedCvn,
                            amount: amount,
                            currencyCode: customer.CurrencyCode,
                            transactionType: PaymentGatewayTransactionType.Purchase,
                            companyName: customer.GetBusinessName(),
                            companyAddress: companyAddress,
                            contactName: customer.BillingContactName,
                            contactPhone: customer.BillingContactPhone,
                            contactEmail: customer.BillingContactEmail
                        );
                    }
                }

                if (isCardOnFile) {
                    if (model.ProcessPaymentClientType == PaymentGatewayClientType.Principal) {
                        var q = adminContext.CustomerPaymentMethod.Find(model.ProcessPaymentPaymentMethodId);

                        q ??= new CustomerPaymentMethod {
                            Id = 0,
                            CustomerId = customerId,
                            IsActive = true
                        };

                        var response = eWay.QueryCustomer(tokenCustomerId);

                        q.TokenCustomerId = response.TokenCustomerID.ToLong();
                        q.CardNo = response.CardDetails.Number;
                        q.CardholderName = model.ProcessPaymentCardholderName;
                        q.ExpiryDate = DateTime.Parse(model.ProcessPaymentExpiryDate);
                        q.IsRecurringPayment = model.ProcessPaymentIsRecurringPayment;

                        if (model.ProcessPaymentPaymentMethodId <= 0) {
                            adminContext.Insert(q);
                        }
                        else {
                            adminContext.Save(q);
                        }
                    }
                    else {
                        var q = context.PaymentMethod.Find(model.ProcessPaymentPaymentMethodId);

                        q ??= new PaymentMethod {
                            Id = 0,
                            AccountType = AccountType.None,
                            ProfileId = model.ProcessPaymentProfileId,
                            TripId = model.ProcessPaymentTripId,
                            DebtorId = model.ProcessPaymentDebtorId,
                            CreditorId = model.ProcessPaymentCreditorId,
                            ChartOfAccountId = model.ProcessPaymentChartOfAccountId,
                            PaymentDetails2 = string.Empty,
                            PaymentDetails3 = string.Empty,
                            Comments = string.Empty,
                            IsActive = true
                        };

                        var response = eWay.QueryCustomer(tokenCustomerId);

                        q.TokenCustomerId = response.TokenCustomerID.ToLong();
                        q.FormOfPaymentId = FormOfPayment.GetFormOfPaymentIdByCardNo(customerId, response.CardDetails.Number);
                        q.AccountNo = response.CardDetails.Number;
                        q.PaymentDetails1 = model.ProcessPaymentCardholderName;
                        q.ExpiryDate = DateTime.Parse(model.ProcessPaymentExpiryDate);

                        if (q.Id <= 0) {
                            context.Insert(q);
                        }
                        else {
                            context.Save(q);
                        }
                    }
                }

                if (model.ProcessPaymentClientType == PaymentGatewayClientType.Principal) {
                    var customerTransactionModel = new CustomerTransactionViewModel {
                        CustomerTransactionId = 0,
                        CustomerTransactionCustomerId = customerId,
                        CustomerTransactionType = isRefund ? CustomerTransactionType.Refund : CustomerTransactionType.DirectDeposit,
                        CustomerTransactionApprovalStatus = CustomerTransactionApprovalStatus.ApprovedAndEmailed,
                        CustomerTransactionDateFrom = DateTime.Today,
                        CustomerTransactionDateTo = DateTime.Today,
                        CustomerTransactionDateDue = DateTime.MinValue,
                        CustomerTransactionUserCount = 0,
                        CustomerTransactionUserCharge = 0,
                        CustomerTransactionAmountGross = model.ProcessPaymentAmount,
                        CustomerTransactionTax = 0,
                        CustomerTransactionDocumentNo = string.Empty,
                        PaymentTransactionId = paymentTransactionId,
                        CustomerTransactionDescription = isRefund ? "Refund" : "Direct Deposit",
                        IsUserCreated = false
                    };

                    CustomerTransactionCommon.CreateOrUpdate(httpContext, adminContext, context, customerTransactionModel, CustomerTxnSource.OnlinePayment, false);
                }

                ts.Complete();
                return true;
            }
        }

        public static bool ProcessPaymentTypeIdIsEnabled(HttpContext httpContext, PaymentGatewayClientType clientType) => httpContext.User.Identity.IsAuthenticated && ((clientType == PaymentGatewayClientType.Principal && httpContext.IsGlobalUser()) || clientType == PaymentGatewayClientType.Customer);
    }

    public static class AgencyCommon {
        public static bool CreateOrUpdate(HttpContext httpContext, AppMainContext context, IDistributedCache cache, AgencyViewModel model) {
            bool resetAgencyList = false;

            using (var ts = Utils.CreateTransactionScope()) {
                Agency q = null;

                if (model.AgencyId <= 0) {
                    q = new Agency();
                }
                else {
                    q = context.Agency.Include(t => t.AgencyHeaders).Single(t => t.Id == model.AgencyId);
                }

                if (model.AccentColor == AppConstants.DefaultAccentColor)
                    model.IsAccentColorPageHeaderFooterOnly = false;

                resetAgencyList = q.Name != model.Name || q.AccentColor != model.AccentColor || q.HighlightColor != model.HighlightColor || q.IsAccentColorPageHeaderFooterOnly != model.IsAccentColorPageHeaderFooterOnly;

                q.Name = model.Name;
                q.Abbreviation = model.Abbreviation.ToUpper();
                q.BspRegister = model.BspRegister;
                q.TaxNo = model.TaxNo.ToStringExt();
                q.TravelBankAccountId = model.TravelBankAccountId ?? 0;
                q.AdminBankAccountId = model.AdminBankAccountId ?? 0;
                q.AccentColor = model.AccentColor;
                q.HighlightColor = model.HighlightColor;
                q.IsAccentColorPageHeaderFooterOnly = model.IsAccentColorPageHeaderFooterOnly;
                q.IsHeadOffice = model.IsHeadOffice;
                q.TaxAuditReportPeriod = model.TaxAuditReportPeriod;
                q.TravelDocumentTimeFormat = model.TravelDocumentTimeFormat;
                q.PayIdType = model.PayIdType;
                q.PayId = model.PayId.ToStringExt();
                q.TravelPayUrl = model.TravelPayUrl.ToStringExt();
                q.MintUrl = model.MintUrl.ToStringExt();
                q.PaymentOptions = model.PaymentOptions.ToStringExt();
                q.BillingAddress1 = model.BillingAddress1.ToStringExt();
                q.BillingAddress2 = model.BillingAddress2.ToStringExt();
                q.BillingLocality = model.BillingLocality.ToStringExt();
                q.BillingRegion = model.BillingRegion.ToStringExt();
                q.BillingPostCode = model.BillingPostCode.ToStringExt();
                q.BillingCountryCode = model.BillingCountryCode.ToStringExt();
                q.BillingContactName = model.BillingContactName.ToStringExt();
                q.BillingContactPhone = model.BillingContactPhone.ToStringExt();
                q.BillingContactEmail = model.BillingContactEmail.ToStringExt();
                q.TechnicalContactName = model.TechnicalContactName.ToStringExt();
                q.TechnicalContactPhone = model.TechnicalContactPhone.ToStringExt();
                q.TechnicalContactEmail = model.TechnicalContactEmail.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                if ((q.AgencyHeaders?.Count ?? 0) == 0) {
                    foreach (var row in (IssuedDocumentType[])Enum.GetValues(typeof(IssuedDocumentType))) {
                        if (row == IssuedDocumentType.Other || row == IssuedDocumentType.PersonalStatement || row == IssuedDocumentType.TrialBalance)
                            continue;

                        var agencyHeader = new AgencyHeader {
                            Id = 0,
                            AgencyId = q.Id,
                            IssuedDocumentType = row,
                            HeaderContent = string.Empty,
                            HeaderStandardCommentId = -1,
                            FooterStandardCommentId = -1,
                            LogoPosition = Position.Left,
                            Logo = null
                        };

                        context.Insert(agencyHeader);
                    }
                }

                model.AgencyId = q.Id;

                if (model.IsHeadOffice) {
                    if (CustomerSettings.Setting(httpContext.CurrentCustomerId()).AgencyType == AgencyType.MultiAgencyGLIndividual) {
                        foreach (var row in context.Agency.Where(t => t.Id != q.Id && t.IsHeadOffice)) {
                            row.IsHeadOffice = false;
                            context.Save(row, false);
                        }
                    }
                }
                else if (!context.Agency.Any(t => t.IsHeadOffice)) {
                    var agency = context.Agency.OrderBy(t => t.CreationTime).First(t => t.Id > 0);
                    agency.IsHeadOffice = true;
                    context.Save(agency, false);
                }

                httpContext.TravelBankAccountId(q.TravelBankAccountId);
                httpContext.AdminBankAccountId(q.AdminBankAccountId);

                ts.Complete();
            }

            if (resetAgencyList)
                cache.RemoveAsync(httpContext.User.Identity.Name, CacheKey.AgencyList).Wait();

            return true;
        }

        public static bool Delete(HttpContext httpContext, AppAdminContext adminContext, AppMainContext context, IDistributedCache cache, AgencyViewModel model) {
            var q = context.Agency.Include(t => t.AgencyAddresses).Include(t => t.AgencyContacts).Include(t => t.AgencyHeaders).SingleOrDefault(t => t.Id == model.AgencyId);

            if (q == null)
                throw new UnreportedException(AppConstants.RecordNotFound);

            if (adminContext.AspNetUsers.Any(t => t.CurrentDefaultAgencyId == model.AgencyId) || adminContext.AspNetUserRoles.Any(t => t.DefaultAgencyId == model.AgencyId))
                throw new UnreportedException(AppConstants.SqlReferenceConstraintDelete);

            context.Delete(q);
            cache.RemoveAsync(httpContext.User.Identity.Name, CacheKey.AgencyList).Wait();

            return true;
        }
    }

    public static class AgencyAddressCommon {
        public static bool CreateOrUpdate(AppMainContext context, AddressViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                AgencyAddress q = null;

                if (model.AddressId <= 0) {
                    q = new AgencyAddress();
                }
                else {
                    q = context.AgencyAddress.Find(model.AddressId);
                }

                q.AgencyId = model.ParentId;
                q.AddressType = model.AddressType;
                q.Address1 = model.Address1.ToStringExt();
                q.Address2 = model.Address2.ToStringExt();
                q.Locality = model.Locality.ToStringExt();
                q.Region = model.Region.ToStringExt();
                q.PostCode = model.PostCode.ToStringExt();
                q.CountryCode = model.CountryCode.ToStringExt();
                q.IsDefault = model.IsDefaultAddress;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.AddressId = q.Id;

                if (model.IsDefaultAddress) {
                    foreach (var row in context.AgencyAddress.Where(t => t.Id != q.Id && t.AgencyId == model.ParentId && t.IsDefault)) {
                        row.IsDefault = false;
                        context.Save(row, false);
                    }
                }

                ts.Complete();
                return true;
            }
        }
    }

    public static class AgencyContactCommon {
        public static bool CreateOrUpdate(AppMainContext context, ContactViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                AgencyContact q = null;

                if (model.ContactId <= 0) {
                    q = new AgencyContact();
                }
                else {
                    q = context.AgencyContact.Find(model.ContactId);
                }

                if (!context.ContactTitle.Any(t => t.Name == model.Title))
                    model.Title = string.Empty;

                q.AgencyId = model.ParentId;
                q.Title = model.Title.ToStringExt();
                q.Name = model.Name.ToStringExt();
                q.PhoneHome = model.PhoneHome.ToStringExt();
                q.PhoneWork = model.PhoneWork.ToStringExt();
                q.Mobile = model.Mobile.ToStringExt();
                q.Fax = model.Fax.ToStringExt();
                q.Email = model.Email.ToStringExt();
                q.IsDefault = model.IsDefaultContact;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ContactId = q.Id;

                if (model.IsDefaultContact) {
                    foreach (var row in context.AgencyContact.Where(t => t.AgencyId == model.ParentId && t.Id != q.Id && t.IsDefault)) {
                        row.IsDefault = false;
                        context.Save(row, false);
                    }
                }

                ts.Complete();
                return true;
            }
        }
    }

    public static class BankAccountAddressCommon {
        public static bool BankAccountAddress_CreateOrUpdate(AppMainContext context, AddressViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                BankAccountAddress q = null;

                if (model.AddressId <= 0) {
                    q = new BankAccountAddress();
                }
                else {
                    q = context.BankAccountAddress.Find(model.AddressId);
                }

                q.BankAccountId = model.ParentId;
                q.AddressType = model.AddressType;
                q.Address1 = model.Address1.ToStringExt();
                q.Address2 = model.Address2.ToStringExt();
                q.Locality = model.Locality.ToStringExt();
                q.Region = model.Region.ToStringExt();
                q.PostCode = model.PostCode.ToStringExt();
                q.CountryCode = model.CountryCode.ToStringExt();
                q.IsDefault = model.IsDefaultAddress;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.AddressId = q.Id;

                if (model.IsDefaultAddress) {
                    foreach (var row in context.BankAccountAddress.Where(t => t.Id != q.Id && t.BankAccountId == model.ParentId && t.IsDefault)) {
                        row.IsDefault = false;
                        context.Save(row, false);
                    }
                }

                ts.Complete();
                return true;
            }
        }
    }

    public static class IssuedDocumentCommon {
        public static bool Create(AppMainContext context, IssuedDocumentViewModel model, IEnumerable<IFormFile> files) {
            if (model.IssuedDocumentTripId <= 0 && model.IssuedDocumentDebtorId <= 0 && model.IssuedDocumentCreditorId <= 0)
                throw new UnreportedException("Key parameters are invalid. Please try reloading the page.");

            var q = context.IssuedDocument.Where(t => t.IssuedDocumentType == model.IssuedDocumentType).AsEnumerable();
            bool exists = false;

            switch (model.IssuedDocumentType) {
                case IssuedDocumentType.Receipt:
                    exists = q.Any(t => t.ReceiptId == model.IssuedDocumentReceiptId);
                    break;
                case IssuedDocumentType.Invoice:
                    exists = q.Any(t => t.InvoiceId == model.IssuedDocumentInvoiceId);
                    break;
                case IssuedDocumentType.Voucher:
                    exists = q.Any(t => t.VoucherId == model.IssuedDocumentVoucherId);
                    break;
            }

            if (exists)
                throw new UnreportedException("Document already exists.");

            using (var ts = Utils.CreateTransactionScope()) {
                var file = files.Single();
                byte[] document = null;

                string fileName = IssuedDocument.GetFileName(file.FileName);
                string fileExtension = IssuedDocument.GetFileExtension(file.FileName);

                if (model.IssuedDocumentType != IssuedDocumentType.Other && fileExtension.Equals("docx", StringComparison.OrdinalIgnoreCase)) {
                    document = WebUtils.ConvertToPdf(file);
                    fileExtension = "pdf";
                }
                else {
                    document = files.Single().OpenReadStream().StreamToBytes();
                }

                var issuedDocument = new IssuedDocument {
                    Id = 0,
                    IssuedDocumentType = model.IssuedDocumentType,
                    TripId = model.IssuedDocumentTripId,
                    DebtorId = model.IssuedDocumentDebtorId,
                    CreditorId = model.IssuedDocumentCreditorId,
                    ReceiptId = model.IssuedDocumentReceiptId,
                    InvoiceId = model.IssuedDocumentInvoiceId,
                    VoucherId = model.IssuedDocumentVoucherId,
                    Name = fileName,
                    FileExtension = fileExtension,
                    Document = document
                };

                context.Insert(issuedDocument);
                model.IssuedDocumentId = issuedDocument.Id;

                switch (model.IssuedDocumentType) {
                    case IssuedDocumentType.Receipt:
                        issuedDocument.Receipt.IsIssued = true;
                        context.Save(issuedDocument.Receipt, false);
                        break;
                    case IssuedDocumentType.Invoice:
                        issuedDocument.Invoice.IsIssued = true;
                        context.Save(issuedDocument.Invoice, false);
                        break;
                    case IssuedDocumentType.Voucher:
                        issuedDocument.Voucher.IsIssued = true;
                        context.Save(issuedDocument.Voucher, false);
                        break;
                }

                ts.Complete();
                return true;
            }
        }
    }

    public class SupplierServiceCommon {
        public bool CreateOrUpdate(AppMainContext context, SupplierServiceViewModel model) {
            SupplierService q;

            if (model.SupplierServiceId <= 0) {
                q = new SupplierService();
            }
            else {
                q = context.SupplierService.Find(model.SupplierServiceId);
            }

            q.Name = model.Name;
            q.Comments = model.Comments.ToStringExt();
            q.RelatedRemarks = model.RelatedRemarks.ToStringExt();
            q.UnitOfService = model.UnitOfService.ToStringExt();
            q.ServiceCharged = model.ServiceCharged.ToStringExt();
            q.ServiceTypeId = model.ServiceTypeId ?? 0;

            if (q.Id <= 0) {
                context.Insert(q);
            }
            else {
                context.Save(q);
            }

            model.SupplierServiceId = q.Id;
            return true;
        }

        public bool Delete(AppMainContext context, SupplierServiceViewModel model) {
            var q = context.SupplierService.Find(model.SupplierServiceId);

            if (q == null)
                throw new UnreportedException(AppConstants.RecordNotFound);

            return context.Delete(q);
        }
    }
}