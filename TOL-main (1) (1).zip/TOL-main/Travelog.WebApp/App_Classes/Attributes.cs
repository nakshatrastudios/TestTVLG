﻿using System;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Net.Http.Headers;

namespace Travelog.WebApp {
    [AttributeUsage(AttributeTargets.Method)]
	public class BasicAuthenticationAttribute : ActionFilterAttribute {
		public string BasicRealm { get; set;  }
		protected string UserName { get; }
		protected string Password { get; }

		public BasicAuthenticationAttribute(string userName, string password) {
			UserName = userName;
			Password = password;
		}

		public override void OnActionExecuting(ActionExecutingContext filterContext) {
			var request = filterContext.HttpContext.Request;
			var authorization = request.Headers[HeaderNames.Authorization][0];

			if (!string.IsNullOrEmpty(authorization)) {
				var credentials = Encoding.ASCII.GetString(Convert.FromBase64String(authorization.Substring(6))).Split(':');
				var user = new { Name = credentials[0], Password = credentials[1] };

				if (user.Name == UserName && user.Password == Password)
					return;
			}

			filterContext.HttpContext.Response.Headers.Add("WWW-Authenticate", string.Format(@"Basic realm=""{0}""", BasicRealm ?? "travelog"));
			filterContext.Result = new UnauthorizedResult();
		}
	}
}