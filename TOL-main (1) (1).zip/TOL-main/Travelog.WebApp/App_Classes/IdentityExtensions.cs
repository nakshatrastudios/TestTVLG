﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using Travelog.Biz;
using Travelog.Biz.Enums;

namespace Travelog.WebApp {
    public static class IdentityExtensions {
		public static string GetId(this IPrincipal principal) {
			return principal.GetClaim("Id") ?? string.Empty;
		}

		public static string GetFullName(this IPrincipal principal) {
			return principal.GetClaim("FullName") ?? string.Empty;
		}

		public static void SetFullName(this IPrincipal principal, string value) {
			principal.SetClaim("FullName", value);
		}

        public static string GetAgencyEmail(this IPrincipal principal) {
            return principal.GetClaim("AgencyEmail") ?? string.Empty;
        }

        public static void SetAgencyEmail(this IPrincipal principal, string value) {
            principal.SetClaim("AgencyEmail", value);
        }

        public static string GetTheme(this IPrincipal principal) {
			return principal.GetClaim("Theme") ?? string.Empty;
		}

		public static void SetTheme(this IPrincipal principal, string value) {
			principal.SetClaim("Theme", value);
		}

		public static FormValidationMethod GetFormValidationMethod(this IPrincipal principal) {
			return (FormValidationMethod)int.Parse(principal.GetClaim("FormValidationMethodId") ?? "0");
		}

		public static void SetFormValidationMethod(this IPrincipal principal, FormValidationMethod value) {
			principal.SetClaim("FormValidationMethodId", ((int)value).ToString());
		}

		public static int GetCurrentCustomerId(this IPrincipal principal) {
			return int.Parse(principal.GetClaim("CurrentCustomerId") ?? "0");
		}

		public static void SetCurrentCustomerId(this IPrincipal principal, int value) {
			principal.SetClaim("CurrentCustomerId", value.ToString());
		}

        public static int GetCurrentConsultantId(this IPrincipal principal) {
			return int.Parse(principal.GetClaim("CurrentConsultantId") ?? "-1");
		}

		public static void SetCurrentConsultantId(this IPrincipal principal, int value) {
			principal.SetClaim("CurrentConsultantId", value.ToString());
		}

		public static int GetCurrentDefaultAgencyId(this IPrincipal principal) {
			return int.Parse(principal.GetClaim("CurrentDefaultAgencyId") ?? "-1");
		}

		public static void SetCurrentDefaultAgencyId(this IPrincipal principal, int value) {
			principal.SetClaim("CurrentDefaultAgencyId", value.ToString());
		}

		public static string GetSessionId(this IPrincipal principal) {
			return principal.GetClaim("SessionId") ?? string.Empty;
		}

		public static void SetSessionId(this IPrincipal principal, string value) {
			principal.SetClaim("SessionId", value);
		}

		public static bool GetIsTwoFactorEnabled(this IPrincipal principal) {
			return bool.Parse(principal.GetClaim("IsTwoFactorEnabled") ?? "False");
		}

		public static void SetIsTwoFactorEnabled(this IPrincipal principal, bool value) {
			principal.SetClaim("IsTwoFactorEnabled", value.ToString());
		}

		public static string GetGoogleAccountSecretKey(this IPrincipal principal) {
			return principal.GetClaim("GoogleAccountSecretKey");
		}

		public static void SetGoogleAccountSecretKey(this IPrincipal principal, string value) {
			principal.SetClaim("GoogleAccountSecretKey", value);
		}

		public static int GetTimeZoneOffsetMinutes(this IPrincipal principal) {
			return int.Parse(principal.GetClaim("TimeZoneOffsetMinutes") ?? "0");
		}

		public static void SetTimeZoneOffsetMinutes(this IPrincipal principal, int value) {
			principal.SetClaim("TimeZoneOffsetMinutes", value.ToString());
		}

		public static DateTime GetLastSignInTime(this IPrincipal principal) {
			return DateTime.Parse(principal.GetClaim("LastSignInTime") ?? DateTime.UtcNow.ToShortDateTimeStringExt());
		}

		public static void SetLastSignInTime(this IPrincipal principal, DateTime value) {
			principal.SetClaim("LastSignInTime", value.ToString());
		}

		public static DateTime GetLastPasswordChangeDate(this IPrincipal principal) {
			return DateTime.Parse(principal.GetClaim("LastPasswordChangeDate") ?? DateTime.UtcNow.ToShortDateStringExt());
		}

		public static void SetLastPasswordChangeDate(this IPrincipal principal, DateTime value) {
			principal.SetClaim("LastPasswordChangeDate", value.ToString());
		}

		public static int GetTravelBankAccountId(this IPrincipal principal) {
			return int.Parse(principal.GetClaim("TravelBankAccountId") ?? "-1");
		}

		public static void SetTravelBankAccountId(this IPrincipal principal, int value) {
			principal.SetClaim("TravelBankAccountId", value.ToString());
		}

		public static int GetAdminBankAccountId(this IPrincipal principal) {
			return int.Parse(principal.GetClaim("AdminBankAccountId") ?? "-1");
		}

		public static void SetAdminBankAccountId(this IPrincipal principal, int value) {
			principal.SetClaim("AdminBankAccountId", value.ToString());
		}

		public static AppUserRole GetAppUserRole(this IPrincipal principal) {
			return (AppUserRole)Enum.Parse(typeof(AppUserRole), principal.GetClaim("AppUserRoleId") ?? nameof(AppUserRole.None));
		}

		public static void SetAppUserRole(this IPrincipal principal, AppUserRole value) {
			principal.SetClaim("AppUserRoleId", ((int)value).ToString());
		}

        public static bool GetOtherAgencies(this IPrincipal principal) {
			return bool.Parse(principal.GetClaim("OtherAgencies") ?? "False");
		}

		public static void SetOtherAgencies(this IPrincipal principal, bool value) {
			principal.SetClaim("OtherAgencies", value.ToString());
		}

		public static bool GetOtherConsultants(this IPrincipal principal) {
			return bool.Parse(principal.GetClaim("OtherConsultants") ?? "False");
		}

		public static void SetOtherConsultants(this IPrincipal principal, bool value) {
			principal.SetClaim("OtherConsultants", value.ToString());
		}

		public static bool GetIsExternalUser(this IPrincipal principal) {
			return bool.Parse(principal.GetClaim("IsExternalUser") ?? "False");
		}

		public static void SetIsExternalUser(this IPrincipal principal, bool value) {
			principal.SetClaim("IsExternalUser", value.ToString());
		}

		public static bool GetIsGlobalUser(this IPrincipal principal) {
			return bool.Parse(principal.GetClaim("IsGlobalUser") ?? "False");
		}

		public static void SetIsGlobalUser(this IPrincipal principal, bool value) {
			principal.SetClaim("IsGlobalUser", value.ToString());
		}

		public static bool GetIsSupportUser(this IPrincipal principal) {
			return bool.Parse(principal.GetClaim("IsSupportUser") ?? "False");
		}

		public static void SetIsSupportUser(this IPrincipal principal, bool value) {
			principal.SetClaim("IsSupportUser", value.ToString());
		}

		public static bool GetIsSuperUser(this IPrincipal principal) {
			return bool.Parse(principal.GetClaim("IsSuperUser") ?? "False");
		}

		public static void SetIsSuperUser(this IPrincipal principal, bool value) {
			principal.SetClaim("IsSuperUser", value.ToString());
		}

		public static bool GetForceSignOut(this IPrincipal principal) {
			return bool.Parse(principal.GetClaim("ForceSignOut") ?? "False");
		}

		public static void SetForceSignOut(this IPrincipal principal, bool value) {
			principal.SetClaim("ForceSignOut", value.ToString());
		}

		public static bool GetInactive(this IPrincipal principal) {
			return bool.Parse(principal.GetClaim("Inactive") ?? "False");
		}

		public static void SetInactive(this IPrincipal principal, bool value) {
			principal.SetClaim("Inactive", value.ToString());
		}

        private static string GetClaim(this IPrincipal principal, string type) {
            if (principal.Identity is not ClaimsIdentity identity)
                return null;

            return identity.Claims.FirstOrDefault(t => t.Type == type)?.Value;
		}

		private static void SetClaim(this IPrincipal principal, string type, string value) {
			if (!(principal.Identity is ClaimsIdentity identity))
				return;

			var claim = identity.FindFirst(type);

			if (claim != null)
				identity.RemoveClaim(claim);

			identity.AddClaim(new Claim(type, value));
		}
	}
}