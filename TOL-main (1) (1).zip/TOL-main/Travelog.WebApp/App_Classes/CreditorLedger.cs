﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Enums;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.CreditorLedger {
	public class CreditorCommon {
		private HttpContext HttpContext { get; }

		public CreditorCommon(HttpContext httpContext) {
			HttpContext = httpContext;
		}

		public bool CreateOrUpdate(AppMainContext context, CreditorViewModel model) {
			if (model.IsBspAgent && model.IsNonBspAgent)
				throw new UnreportedException("Payment by both BSP and Non-BSP is not permitted.");

            var creditor = context.Creditor.Include(t => t.Agency).SingleOrDefault(t => t.AgencyId != model.AgencyId && t.Name == model.Name);

            if (creditor != null && CustomerSettings.Setting(HttpContext.CurrentCustomerId()).AgencyType != AgencyType.MultiAgencyGLIndividual)
                throw new UnreportedException(string.Format("{0} already exists in agency {1} and cannot be duplicated with agency type {2}.", creditor.Name, creditor.Agency.Name, CustomerSettings.Setting(HttpContext.CurrentCustomerId()).AgencyType.GetEnumDescription()));

            Creditor q = null;

			if (model.CreditorId <= 0) {
				q = new Creditor();
			}
			else {
				q = context.Creditor.Find(model.CreditorId);

				if (q.IsBspAgent && !model.IsBspAgent) {
					if (context.Bsp.Any(t => t.CreditorId == model.CreditorId)) {
						throw new UnreportedException("This creditor has BSP documents assigned to it. Payment by BSP must be selected.");
					}
					else if (q.Id == AppSettings.Setting(HttpContext.CurrentCustomerId()).BspCreditorId) {
						throw new UnreportedException("This creditor is the default BSP Returns creditor. Either Payment by BSP must be selected, or the default should be be changed in Application Settings.");
					}
				}

				if (q.IsNonBspAgent && !model.IsNonBspAgent && context.NonBsp.Any(t => t.CreditorId == model.CreditorId))
					throw new UnreportedException("This creditor has Non-BSP documents assigned to it. Payment by Non-BSP must be selected.");
			}

			q.Name = model.Name;
			q.AgencyId = model.AgencyId ?? 0;
			q.CurrencyId = model.CurrencyId ?? 0;
			q.ClassId = model.ClassId ?? 0;
			q.LocationId = model.LocationId ?? 0;
			q.AgingCycle = model.AgingCycle;
			q.IsBspAgent = model.IsBspAgent;
			q.IsNonBspAgent = model.IsNonBspAgent;
			q.IsTaxOnCommission = model.IsTaxOnCommission;
			q.IsRcti = model.IsRcti;
			q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;
			q.CommissionRate = model.CommissionRate / 100;
			q.CreditLimit = model.CreditLimit;
			q.Rules = model.Rules.ToStringExt();
			q.Remarks = model.Remarks.ToStringExt();

			if (q.Id <= 0) {
				context.Insert(q);
			}
			else {
				context.Save(q);
			}

			model.CreditorId = q.Id;
			return true;
		}

		public bool Delete(AppMainContext context, CreditorViewModel model) {
			var q = context.Creditor.Find(model.CreditorId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class CreditorAddressCommon {
		public bool CreateOrUpdate(AppMainContext context, AddressViewModel model) {
			using (var ts = Utils.CreateTransactionScope()) {
				CreditorAddress q = null;

				if (model.AddressId <= 0) {
					q = new CreditorAddress();
				}
				else {
					q = context.CreditorAddress.Find(model.AddressId);
				}

				q.CreditorId = model.ParentId;
				q.AddressType = model.AddressType;
				q.Address1 = model.Address1.ToStringExt();
				q.Address2 = model.Address2.ToStringExt();
				q.Locality = model.Locality.ToStringExt();
				q.Region = model.Region.ToStringExt();
				q.PostCode = model.PostCode.ToStringExt();
				q.CountryCode = model.CountryCode.ToStringExt();
				q.IsDefault = model.IsDefaultAddress;

				if (q.Id <= 0) {
					context.Insert(q);
				}
				else {
					context.Save(q);
				}

				model.AddressId = q.Id;

				if (model.IsDefaultAddress) {
					foreach (var row in context.CreditorAddress.Where(t => t.Id != q.Id && t.CreditorId == model.ParentId && t.IsDefault)) {
						row.IsDefault = false;
						context.Save(row, false);
					}
				}

				ts.Complete();
				return true;
			}
		}

		public bool Delete(AppMainContext context, AddressViewModel model) {
			var q = context.CreditorAddress.Find(model.AddressId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class CreditorContactCommon {
		public bool CreateOrUpdate(AppMainContext context, ContactViewModel model) {
			using (var ts = Utils.CreateTransactionScope()) {
				CreditorContact q = null;

				if (model.ContactId <= 0) {
					q = new CreditorContact();
				}
				else {
					q = context.CreditorContact.Find(model.ContactId);
				}

				if (!context.ContactTitle.Any(t => t.Name == model.Title))
					model.Title = string.Empty;

				q.CreditorId = model.ParentId;
				q.Title = model.Title.ToStringExt();
				q.Name = model.Name.ToStringExt();
				q.PhoneHome = model.PhoneHome.ToStringExt();
				q.PhoneWork = model.PhoneWork.ToStringExt();
				q.Mobile = model.Mobile.ToStringExt();
				q.Fax = model.Fax.ToStringExt();
				q.Email = model.Email.ToStringExt();
				q.IsDefault = model.IsDefaultContact;

				if (q.Id <= 0) {
					context.Insert(q);
				}
				else {
					context.Save(q);
				}

				model.ContactId = q.Id;

				if (model.IsDefaultContact) {
					foreach (var row in context.CreditorContact.Where(t => t.CreditorId == model.ParentId && t.Id != q.Id && t.IsDefault)) {
						row.IsDefault = false;
						context.Save(row, false);
					}
				}

				ts.Complete();
				return true;
			}
		}

		public bool Delete(AppMainContext context, ContactViewModel model) {
			var q = context.CreditorContact.Find(model.ContactId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class CreditorSupplierCommon {
		public bool CreateOrUpdate(AppMainContext context, CreditorSupplierViewModel model) {
			using (var ts = Utils.CreateTransactionScope()) {
				SupplierCreditor q = null;

				if (model.CreditorSupplierId <= 0) {
					q = new SupplierCreditor();
				}
				else {
					q = context.SupplierCreditor.Find(model.CreditorSupplierId);
				}

				q.SupplierId = model.SupplierId ?? 0;
				q.CreditorId = model.CreditorId;
				q.IsDefault = model.IsDefault;

				if (q.Id <= 0) {
					context.Insert(q);
				}
				else {
					context.Save(q);
				}

				model.CreditorSupplierId = q.Id;

				if (model.IsDefault) {
					foreach (var row in context.SupplierCreditor.Where(t => t.CreditorId == model.CreditorId && t.Id != q.Id && t.IsDefault)) {
						row.IsDefault = false;
						context.Save(row, false);
					}
				}

				ts.Complete();
				return true;
			}
		}

		public bool Delete(AppMainContext context, CreditorSupplierViewModel model) {
			var q = context.SupplierCreditor.Find(model.CreditorSupplierId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class CreditorCrsCommon {
		public bool CreateOrUpdate(AppMainContext context, CreditorCrsViewModel model) {
			CreditorCrs q;

			if (model.CreditorCrsId <= 0) {
				q = new CreditorCrs();
			}
			else {
				q = context.CreditorCrs.Find(model.CreditorCrsId);
			}

			q.CreditorId = model.CreditorId;
			q.Crs = model.Crs;
            q.CrsCode = model.CrsCode.ToUpper();

            if (q.Id <= 0) {
				context.Insert(q);
			}
			else {
				context.Save(q);
			}

			model.CreditorCrsId = q.Id;
			return true;
		}

		public bool Delete(AppMainContext context, CreditorCrsViewModel model) {
			var q = context.CreditorCrs.Find(model.CreditorCrsId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class SupplierCommon {
		public bool CreateOrUpdate(AppMainContext context, SupplierViewModel model) {
			using (var ts = Utils.CreateTransactionScope()) {
				Supplier q = null;

				if (model.SupplierId <= 0) {
					q = new Supplier();
				}
				else {
					q = context.Supplier.Include(t => t.SupplierServiceTypes).SingleOrDefault(t => t.Id == model.SupplierId);
				}

				q.Name = model.Name;
				q.Comments = model.Comments.ToStringExt();
				q.PickupComments = model.PickupComments.ToStringExt();
				q.DropoffComments = model.DropoffComments.ToStringExt();
				q.IataCode = model.IataCode.ToStringExt();
				q.DxNo = model.DxNo.ToStringExt();
				q.AddressPrintOption = model.AddressPrintOption;
				q.DefaultVoucherType = model.DefaultVoucherType;
				q.CityId = model.CityId ?? 0;
				q.ClassId = model.ClassId ?? 0;
				q.SaleTypeId = model.SaleTypeId ?? 0;
				q.SupplierChainId = model.SupplierChainId ?? 0;
				q.CommissionRate = model.CommissionRate / 100;
				q.ReminderLetter = model.ReminderLetter;

				if (q.Id <= 0) {
					context.Insert(q);
				}
				else {
					context.Save(q);
				}

				model.SupplierId = q.Id;

				model.ContactViewModel = new ContactViewModel {
					ContactId = 0,
					Title = string.Empty,
					Name = string.Empty,
					PhoneHome = string.Empty,
					PhoneWork = string.Empty,
					Mobile = string.Empty,
					PhoneNo = string.Empty,
					Fax = string.Empty,
					Email = string.Empty
				};

				if (model.ServiceTypeIds == null) {
					if (q.SupplierServiceTypes != null) {
						foreach (var row in q.SupplierServiceTypes.ToList()) {
							context.Delete(row, false);
						}
					}
				}
				else {
					foreach (var row in Lists.GetServiceTypeList(context, false).ToList()) {
						int serviceTypeId = row.Value.ToInt();

						var supplierServiceType = context.SupplierServiceType.SingleOrDefault(t => t.SupplierId == model.SupplierId && t.ServiceTypeId == serviceTypeId);

						if (model.ServiceTypeIds.Any(t => t == serviceTypeId)) {
							if (supplierServiceType == null) {
								supplierServiceType = new SupplierServiceType {
									Id = 0,
									SupplierId = model.SupplierId,
									ServiceTypeId = serviceTypeId
								};

								context.Insert(supplierServiceType, false);
							}
						}
						else if (supplierServiceType != null) {
							context.Delete(supplierServiceType, false);
						}
					}
				}

				ts.Complete();
				return true;
			}
		}

		public bool Delete(AppMainContext context, SupplierViewModel model) {
			var q = context.Supplier.Find(model.SupplierId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}

		public int Add(AppMainContext context, string name, int creditorId, int cityId, TripLineType tripLineType, string address1, string address2, string locality, string region, string postCode, string countryCode, string contactTitle, string contactName, string phoneHome, string phoneWork, string mobile, string fax, string email) {
			using (var ts = Utils.CreateTransactionScope()) {
				var q = new Supplier {
					Id = 0,
					Name = name,
					IataCode = string.Empty,
					DxNo = string.Empty,
					AddressPrintOption = AddressPrintOption.Never,
					DefaultVoucherType = VoucherType.None,
					CityId = cityId,
					ClassId = -1,
					SaleTypeId = -1,
					SupplierChainId = -1,
					CommissionRate = 0,
					ReminderLetter = false,
					Comments = string.Empty,
					PickupComments = string.Empty,
					DropoffComments = string.Empty
				};

				context.Insert(q);

				if (creditorId > 0) {
					var supplierCreditor = new SupplierCreditor {
						Id = 0,
						SupplierId = q.Id,
						CreditorId = creditorId,
						IsDefault = true
					};

					context.Insert(supplierCreditor);
				}

				if (!string.IsNullOrEmpty(address1) || !string.IsNullOrEmpty(address2) || !string.IsNullOrEmpty(locality) || !string.IsNullOrEmpty(region) || !string.IsNullOrEmpty(postCode) || !string.IsNullOrEmpty(countryCode)) {
					var supplierAddress = new SupplierAddress {
						Id = 0,
						SupplierId = q.Id,
						Address1 = address1.ToStringExt(),
						Address2 = address2.ToStringExt(),
						Locality = locality.ToStringExt(),
						Region = region.ToStringExt(),
						PostCode = postCode.ToStringExt(),
						CountryCode = countryCode.ToStringExt(),
						IsDefault = false
					};

					context.Insert(supplierAddress);
				}

				if (!string.IsNullOrEmpty(contactName) || !string.IsNullOrEmpty(phoneHome) || !string.IsNullOrEmpty(phoneWork) || !string.IsNullOrEmpty(mobile) || !string.IsNullOrEmpty(fax) || !string.IsNullOrEmpty(email)) {
					var supplierContact = new SupplierContact {
						Id = 0,
						SupplierId = q.Id,
						Title = contactTitle.ToStringExt(),
						Name = contactName.ToStringExt(),
						PhoneHome = phoneHome.ToStringExt(),
						PhoneWork = phoneWork.ToStringExt(),
						Mobile = mobile.ToStringExt(),
						Fax = fax.ToStringExt(),
						Email = email.ToStringExt(),
						IsDefault = false
					};

					context.Insert(supplierContact);
				}

				if (tripLineType != TripLineType.All) {
					foreach (var row in context.ServiceType.Where(t => t.TripLineType == tripLineType)) {
						if (!context.SupplierServiceType.Any(t => t.SupplierId == q.Id && t.ServiceTypeId == row.Id)) {
							var supplierServiceType = new SupplierServiceType {
								Id = 0,
								SupplierId = q.Id,
								ServiceTypeId = row.Id
							};

							context.Insert(supplierServiceType);
						}
					}
				}

				ts.Complete();
				return q.Id;
			}
		}
	}

	public class SupplierAddressCommon {
		public bool CreateOrUpdate(AppMainContext context, AddressViewModel model) {
			using (var ts = Utils.CreateTransactionScope()) {
				SupplierAddress q = null;

				if (model.AddressId <= 0) {
					q = new SupplierAddress();
				}
				else {
					q = context.SupplierAddress.Find(model.AddressId);
				}

				q.SupplierId = model.ParentId;
				q.AddressType = model.AddressType;
				q.Address1 = model.Address1.ToStringExt();
				q.Address2 = model.Address2.ToStringExt();
				q.Locality = model.Locality.ToStringExt();
				q.Region = model.Region.ToStringExt();
				q.PostCode = model.PostCode.ToStringExt();
				q.CountryCode = model.CountryCode.ToStringExt();
				q.IsDefault = model.IsDefaultAddress;

				if (q.Id <= 0) {
					context.Insert(q);
				}
				else {
					context.Save(q);
				}

				model.AddressId = q.Id;

				if (model.IsDefaultAddress) {
					foreach (var row in context.SupplierAddress.Where(t => t.Id != q.Id && t.SupplierId == model.ParentId && t.IsDefault)) {
						row.IsDefault = false;
						context.Save(row, false);
					}
				}

				ts.Complete();
				return true;
			}
		}

		public bool Delete(AppMainContext context, AddressViewModel model) {
			var q = context.CreditorAddress.Find(model.AddressId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class SupplierContactCommon {
		public bool CreateOrUpdate(AppMainContext context, ContactViewModel model) {
			using (var ts = Utils.CreateTransactionScope()) {
				SupplierContact q = null;

				if (model.ContactId <= 0)
					q = new SupplierContact();
				else
					q = context.SupplierContact.Find(model.ContactId);

				if (!context.ContactTitle.Any(t => t.Name == model.Title))
					model.Title = string.Empty;

				q.SupplierId = model.ParentId;
				q.Title = model.Title.ToStringExt();
				q.Name = model.Name.ToStringExt();
				q.PhoneHome = model.PhoneHome.ToStringExt();
				q.PhoneWork = model.PhoneWork.ToStringExt();
				q.Mobile = model.Mobile.ToStringExt();
				q.Fax = model.Fax.ToStringExt();
				q.Email = model.Email.ToStringExt();
				q.IsDefault = model.IsDefaultContact;

				if (q.Id <= 0) {
					context.Insert(q);
				}
				else {
					context.Save(q);
				}

				model.ContactId = q.Id;

				if (model.IsDefaultContact) {
					foreach (var row in context.SupplierContact.Where(t => t.SupplierId == model.ParentId && t.Id != q.Id && t.IsDefault)) {
						row.IsDefault = false;
						context.Save(row, false);
					}
				}

				ts.Complete();
				return true;
			}
		}

		public bool Delete(AppMainContext context, ContactViewModel model) {
			var q = context.SupplierContact.Find(model.ContactId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class SupplierCreditorCommon {
		public bool CreateOrUpdate(AppMainContext context, SupplierCreditorViewModel model) {
			using (var ts = Utils.CreateTransactionScope()) {
				SupplierCreditor q = null;

				if (model.SupplierCreditorId <= 0) {
					q = new SupplierCreditor();
				}
				else {
					q = context.SupplierCreditor.Find(model.SupplierCreditorId);
				}

				q.SupplierId = model.SupplierId;
				q.CreditorId = model.CreditorId ?? 0;
				q.IsDefault = model.IsDefault;

				if (q.Id <= 0) {
					context.Insert(q);
				}
				else {
					context.Save(q);
				}

				model.SupplierCreditorId = q.Id;

				if (model.IsDefault) {
					foreach (var row in context.SupplierCreditor.Where(t => t.SupplierId == model.SupplierId && t.Id != q.Id && t.IsDefault)) {
						row.IsDefault = false;
						context.Save(row, false);
					}
				}

				ts.Complete();
				return true;
			}
		}

		public bool Delete(AppMainContext context, SupplierCreditorViewModel model) {
			var q = context.SupplierCreditor.Find(model.SupplierCreditorId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class SupplierServiceRateCommon {
		public bool CreateOrUpdate(AppMainContext context, SupplierServiceRateViewModel model) {
			SupplierServiceRate q;

			if (model.SupplierServiceRateId <= 0) {
				q = new SupplierServiceRate();
			}
			else {
				q = context.SupplierServiceRate.Find(model.SupplierServiceRateId);
			}

			q.SupplierId = model.SupplierId;
			q.Name = model.SupplierServiceRateName;
			q.TravelSeason = model.TravelSeason.ToStringExt();
			q.EffectiveFromDate = model.EffectiveFromDate ?? DateTime.MinValue;
			q.EffectiveToDate = model.EffectiveToDate ?? DateTime.MinValue;
			q.CreditorId = model.SupplierServiceRateCreditorId ?? 0;
            q.SaleTypeId = model.SupplierServiceRateSaleTypeId ?? 0;
            q.SupplierServiceId = model.SupplierServiceId ?? 0;
			q.ServiceTypeRateBasisId = model.ServiceTypeRateBasisId ?? 0;
            q.Rules = Utils.ValidateHtmlTags(model.Rules.ToStringExt());
            q.Comments = model.ServiceTypeRateComments.ToStringExt();
			q.Inactive = model.Inactive;

			if (q.Id <= 0) {
				context.Insert(q);
			}
			else {
				context.Save(q);
			}

			model.SupplierServiceRateId = q.Id;
			return true;
		}

		public bool Delete(AppMainContext context, SupplierServiceRateViewModel model) {
			var q = context.SupplierServiceRate.Find(model.SupplierServiceRateId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class SupplierServiceRateDetailCommon {
		public bool CreateOrUpdate(AppMainContext context, SupplierServiceRateDetailViewModel model, int parentId) {
			SupplierServiceRateDetail q;

			if (model.SupplierServiceRateDetailId <= 0) {
				q = new SupplierServiceRateDetail();
			}
			else {
				q = context.SupplierServiceRateDetail.Find(model.SupplierServiceRateDetailId);
			}

			q.SupplierServiceRateId = parentId;
			q.Name = model.Name;
			q.CurrencyId = model.CurrencyId ?? 0;
			q.ExchangeRate = model.ExchangeRate;
            q.Cost = model.Cost;
            q.Amount = model.Amount;

            if (q.Id <= 0) {
				context.Insert(q);
			}
			else {
				context.Save(q);
			}

			model.SupplierServiceRateDetailId = q.Id;
			return true;
		}

		public bool Delete(AppMainContext context, SupplierServiceRateDetailViewModel model) {
			var q = context.SupplierServiceRateDetail.Find(model.SupplierServiceRateDetailId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class SupplierCrsCommon {
		public bool CreateOrUpdate(AppMainContext context, SupplierCrsViewModel model) {
			if (!string.IsNullOrEmpty(model.CityCode)) {
				var city = context.City.SingleOrDefault(t => t.Code.ToLower() == model.CityCode.ToLower());

				if (city == null)
					throw new UnreportedException("City Code is invalid.");
			}

			SupplierCrs q = null;

			if (model.SupplierCrsId <= 0) {
				q = new SupplierCrs();
			}
			else {
				q = context.SupplierCrs.Find(model.SupplierCrsId);
			}

			q.SupplierId = model.SupplierId;
			q.Crs = model.Crs;
            q.CrsCode = model.CrsCode.ToUpper();
            q.CityCode = Utils.RemoveExtraSpaces(model.CityCode.ToStringExt()).Replace(" ", string.Empty).ToUpper();

			if (q.Id <= 0) {
				context.Insert(q);
			}
			else {
				context.Save(q);
			}

			model.SupplierCrsId = q.Id;
			return true;
		}

		public bool Delete(AppMainContext context, SupplierCrsViewModel model) {
			var q = context.SupplierCrs.Find(model.SupplierCrsId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class SupplierUrlCommon {
		public bool CreateOrUpdate(AppMainContext context, SupplierUrlViewModel model) {
			SupplierUrl q;

			if (model.SupplierUrlId <= 0) {
				q = new SupplierUrl();
			}
			else {
				q = context.SupplierUrl.Find(model.SupplierUrlId);
			}

			q.SupplierId = model.SupplierId;
			q.Name = model.UrlName;
			q.Url = model.Url;

			if (q.Id <= 0) {
				context.Insert(q);
			}
			else {
				context.Save(q);
			}

			model.SupplierUrlId = q.Id;
			return true;
		}

		public bool Delete(AppMainContext context, SupplierUrlViewModel model) {
			var q = context.SupplierUrl.Find(model.SupplierUrlId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class SupplierChainCommon {
		public bool CreateOrUpdate(AppMainContext context, SupplierChainViewModel model) {
			SupplierChain q;

			if (model.SupplierChainId <= 0) {
				q = new SupplierChain();
			}
			else {
				q = context.SupplierChain.Find(model.SupplierChainId);
			}

			q.Name = model.Name;
			q.IataCode = model.IataCode.ToStringExt();
			q.ServiceTypeId = model.ServiceTypeId ?? 0;
			q.CreditorId = model.CreditorId ?? 0;

			if (q.Id <= 0) {
				context.Insert(q);
			}
			else {
				context.Save(q);
			}

			model.SupplierChainId = q.Id;
			return true;
		}

		public bool Delete(AppMainContext context, SupplierChainViewModel model) {
			var q = context.SupplierChain.Find(model.SupplierChainId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class SupplierChainCrsCommon {
		public bool CreateOrUpdate(AppMainContext context, SupplierChainCrsViewModel model, int parentId) {
			SupplierChainCrs q;

			if (model.SupplierChainCrsId <= 0) {
				q = new SupplierChainCrs();
			}
			else {
				q = context.SupplierChainCrs.Find(parentId);
			}

			q.SupplierChainId = parentId;
			q.Crs = model.Crs;
            q.CrsCode = model.CrsCode.ToUpper();

            if (q.Id <= 0) {
				context.Insert(q);
			}
			else {
				context.Save(q);
			}

			model.SupplierChainCrsId = q.Id;
			return true;
		}

		public bool Delete(AppMainContext context, SupplierChainCrsViewModel model) {
			var q = context.SupplierChainCrs.Find(model.SupplierChainCrsId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}
}