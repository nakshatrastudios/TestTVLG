﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.DebtorLedger;
using Travelog.Biz.Enums;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.DebtorLedger {
    public class DebtorCommon {
		private HttpContext HttpContext { get; }

		public DebtorCommon(HttpContext httpContext) {
			HttpContext = httpContext;
		}

		public bool CreateOrUpdate(AppLazyContext lazyContext, DebtorViewModel model) {
			if (model.DebtorId == model.ReportingParentId)
				throw new UnreportedException("Reporting Parent cannot be linked to itself.");

			if (model.DebtorId == model.BillingParentId)
				throw new UnreportedException("Billing Parent cannot be linked to itself.");

			if (lazyContext.Debtor.Any(t => t.Id != model.DebtorId && t.Code == model.Code))
				throw new UnreportedException("Code already exists.");

			var debtor = lazyContext.Debtor.SingleOrDefault(t => t.AgencyId != model.AgencyId && t.Name == model.Name);

            if (debtor != null && CustomerSettings.Setting(HttpContext.CurrentCustomerId()).AgencyType != AgencyType.MultiAgencyGLIndividual)
                throw new UnreportedException(string.Format("{0} already exists in agency {1} and cannot be duplicated with agency type {2}.", debtor.Name, debtor.Agency.Name, CustomerSettings.Setting(HttpContext.CurrentCustomerId()).AgencyType.GetEnumDescription()));

            Debtor q = null;

			if (model.DebtorId <= 0) {
				q = new Debtor();
			}
			else {
				q = lazyContext.Debtor.Find(model.DebtorId);
			}

			int agencyId = model.AgencyId ?? 0;

            q.Code = Utils.RemoveExtraSpaces(model.Code).Replace(" ", string.Empty).ToUpper();
			q.Name = model.Name;
			q.ReportingParentId = model.ReportingParentId ?? 0;
			q.BillingParentId = model.BillingParentId ?? 0;
            q.AmadeusCid = model.AmadeusCid.ToStringExt();
			q.GalileoCid = model.GalileoCid.ToStringExt();
			q.SabreCid = model.SabreCid.ToStringExt();
			q.OrderNoMinLength = model.OrderNoMinLength;
			q.AgencyId = agencyId;
			q.CurrencyId = model.CurrencyId ?? 0;
			q.ClassId = model.ClassId ?? 0;
			q.LocationId = model.LocationId ?? 0;
			q.AgingCycle = model.AgingCycle;
			q.AgingCycleStartDay = model.AgingCycleStartDay;
			q.PaymentTermId = model.PaymentTermId ?? 0;
			q.MatchedTxnsReportOption = model.MatchedTxnsReportOption;
			q.ItineraryPricingOption = model.ItineraryPricingOption;
			q.PrismReporting = model.PrismReporting;
			q.PrismReportingStartDate = model.PrismReporting ? model.PrismReportingStartDate ?? DateTime.MinValue : DateTime.MinValue;
			q.PrismReportingTripId = model.PrismReporting ? model.PrismReportingTripId ?? 0 : -1;
			q.VideoConferencingDomestic = model.VideoConferencingDomestic;
			q.VideoConferencingShortHaul = model.VideoConferencingShortHaul;
			q.VideoConferencingInternational = model.VideoConferencingInternational;
			q.IsAutoInvoice = model.IsAutoInvoice;
			q.IsTaxInInvoiceLineAmount = model.IsTaxInInvoiceLineAmount;
			q.IsContactLimitedToCurrentList = model.IsContactLimitedToCurrentList;
			q.IsAuthorisationMandatory = model.IsAuthorisationMandatory;
			q.IsProfileChangesPrevented = model.IsProfileChangesPrevented;
			q.IsContactMandatory = model.IsContactMandatory;
			q.IsOrderNoMandatory = model.IsOrderNoMandatory;
			q.IsTravelReasonMandatory = model.IsTravelReasonMandatory;
			q.Rules = model.Rules.ToStringExt();
			q.Remarks = model.Remarks.ToStringExt();

			if (HttpContext.IsAdministrator()) {
				q.CreditLimit = model.CreditLimit;
				q.InvoiceValidationType = model.InvoiceValidationType;
			}

			if (CustomerSettings.Setting(HttpContext.CurrentCustomerId()).IsManagementCustomer) {
				if ((model.CustomerId ?? 0) != 0 && model.CustomerId != q.CustomerId) {
                    if (lazyContext.Debtor.Any(t => t.CustomerId == model.CustomerId))
                        throw new UnreportedException("This customer is already in use.");
				}

                q.CustomerId = model.CustomerId ?? 0;
            }

            if (q.IsReportingParentDebtorCircular(lazyContext))
				throw new UnreportedException("This debtor has a circular reference in its reporting parent hierarchy. Changes were not saved.");

			if (q.IsBillingParentDebtorCircular(lazyContext))
				throw new UnreportedException("This debtor has a circular reference in its billing parent hierarchy. Changes were not saved.");

			if (q.Id <= 0) {
				lazyContext.Insert(q);
			}
			else {
				lazyContext.Save(q);
			}

			model.DebtorId = q.Id;
			return true;
		}

		public bool Delete(AppMainContext context, DebtorViewModel model) {
			var q = context.Debtor.Find(model.DebtorId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}

		public DebtorViewModel UpdateParent(AppLazyContext lazyContext, int debtorParentTypeId, int debtorId, int parentId) {
			var q = lazyContext.Debtor.Find(debtorId);

			if (debtorId == parentId)
				throw new UnreportedException("A parent cannot be linked to itself.");

			if (debtorParentTypeId == 0) {
				q.ReportingParentId = parentId;

				if (q.IsReportingParentDebtorCircular(lazyContext))
					throw new UnreportedException("This debtor has a circular reference in its reporting parent hierarchy. Changes were not saved.");
			}
			else {
				q.BillingParentId = parentId;

				if (q.IsBillingParentDebtorCircular(lazyContext))
					throw new UnreportedException("This debtor has a circular reference in its billing parent hierarchy. Changes were not saved.");
			}

			lazyContext.Save(q);

			return new DebtorViewModel {
				DebtorId = q.Id,
				Code = q.Code,
				Name = q.Name
			};
		}
	}

	public class DebtorAddressCommon {
		public bool CreateOrUpdate(AppMainContext context, AddressViewModel model) {
			using (var ts = Utils.CreateTransactionScope()) {
				DebtorAddress q = null;

				if (model.AddressId <= 0) {
					q = new DebtorAddress();
				}
				else {
					q = context.DebtorAddress.Find(model.AddressId);
				}

				q.DebtorId = model.ParentId;
				q.AddressType = model.AddressType;
				q.Address1 = model.Address1.ToStringExt();
				q.Address2 = model.Address2.ToStringExt();
				q.Locality = model.Locality.ToStringExt();
				q.Region = model.Region.ToStringExt();
				q.PostCode = model.PostCode.ToStringExt();
				q.CountryCode = model.CountryCode.ToStringExt();
				q.IsDefault = model.IsDefaultAddress;

				if (q.Id <= 0) {
					context.Insert(q);
				}
				else {
					context.Save(q);
				}

				model.AddressId = q.Id;

				if (model.IsDefaultAddress) {
					foreach (var row in context.DebtorAddress.Where(t => t.Id != q.Id && t.DebtorId == model.ParentId && t.IsDefault)) {
						row.IsDefault = false;
						context.Save(row, false);
					}
				}

				ts.Complete();
				return true;
			}
		}

		public bool Delete(AppMainContext context, AddressViewModel model) {
			var q = context.DebtorAddress.Find(model.AddressId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}
	}

	public class DebtorContactCommon {
		public bool CreateOrUpdate(AppMainContext context, ContactViewModel model) {
			using (var ts = Utils.CreateTransactionScope()) {
				DebtorContact q = null;

				if (model.ContactId <= 0) {
					q = new DebtorContact();
				}
				else {
					q = context.DebtorContact.Find(model.ContactId);
				}

				if (!context.ContactTitle.Any(t => t.Name == model.Title))
					model.Title = string.Empty;

				q.DebtorId = model.ParentId;
				q.Title = model.Title.ToStringExt();
				q.Name = model.Name.ToStringExt();
				q.PhoneHome = model.PhoneHome.ToStringExt();
				q.PhoneWork = model.PhoneWork.ToStringExt();
				q.Mobile = model.Mobile.ToStringExt();
				q.Fax = model.Fax.ToStringExt();
				q.Email = model.Email.ToStringExt();
				q.IsDefault = model.IsDefaultContact;
				q.CanBook = (bool)model.Option1;
				q.CanAuthorise = (bool)model.Option2;

				if (q.Id <= 0) {
					context.Insert(q);
				}
				else {
					context.Save(q);
				}

				model.ContactId = q.Id;

				if (model.IsDefaultContact) {
					foreach (var row in context.DebtorContact.Where(t => t.DebtorId == model.ParentId && t.Id != q.Id && t.IsDefault)) {
						row.IsDefault = false;
						context.Save(row, false);
					}
				}

				ts.Complete();
				return true;
			}
		}

		public bool Delete(AppMainContext context, ContactViewModel model) {
			var q = context.DebtorContact.Find(model.ContactId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			return context.Delete(q);
		}

		public int Add(AppMainContext context, int debtorId, string type, string title, string name, string phoneHome, string phoneWork, string mobile, string email) {
			var q = context.DebtorContact.FirstOrDefault(t => t.DebtorId == debtorId && t.Name.ToLower() == name.ToLower()) ?? new DebtorContact();

			q.DebtorId = debtorId;
			q.Title = title.ToStringExt();
			q.Name = name.ToStringExt();
			q.PhoneHome = phoneHome.ToStringExt();
			q.PhoneWork = phoneWork.ToStringExt();
			q.Mobile = mobile.ToStringExt();
			q.Fax = string.Empty;
			q.Email = email.ToStringExt();

			if (type == "Booker") {
				q.CanBook = true;
			}
			else if (type == "Authoriser") {
				q.CanAuthorise = true;
			}

			if (q.Id <= 0) {
				context.Insert(q);
			}
			else {
				context.Save(q);
			}

			return q.Id;
		}
	}
}