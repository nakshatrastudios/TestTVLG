﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Kendo.Mvc.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;
using Travelog.Gds;
using Travelog.Gds.Models;
using Travelog.WebApp.Models;
using CrsGalileoExportModel = Travelog.Gds.Models.CrsGalileoExportModel;
using DataValidation = Travelog.Biz.DataValidation;
using Passenger = Travelog.Biz.Dao.ClientLedger.Passenger;
using PassengerClubMembership = Travelog.Biz.Dao.ClientLedger.PassengerClubMembership;
using PassengerDocument = Travelog.Biz.Dao.ClientLedger.PassengerDocument;
using PassengerType = Travelog.Biz.Enums.PassengerType;
using TripLineAir = Travelog.Biz.Dao.ClientLedger.TripLineAir;
using TripLineAirPassenger = Travelog.Biz.Dao.ClientLedger.TripLineAirPassenger;
using TripLineAirPassengerAirSegment = Travelog.Biz.Dao.ClientLedger.TripLineAirPassengerAirSegment;
using TripLineAirSegment = Travelog.Biz.Dao.ClientLedger.TripLineAirSegment;
using TripLineLand = Travelog.Biz.Dao.ClientLedger.TripLineLand;
using TripLineRemark = Travelog.Biz.Dao.ClientLedger.TripLineRemark;
using TripLineServiceFee = Travelog.Biz.Dao.ClientLedger.TripLineServiceFee;

namespace Travelog.WebApp.ClientLedger {
    public class ProfileCommon {
        private HttpContext HttpContext { get; }

        public ProfileCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public int CreateOrUpdate(AppMainContext context, ProfileViewModel model, int baseTripId = -1) {
            using (var ts = Utils.CreateTransactionScope()) {
                Profile q = null;
                bool isNew = false;

                if (model.ProfileId <= 0) {
                    isNew = true;
                    q = new Profile();
                }
                else {
                    q = context.Profile.Find(model.ProfileId);
                }

                if (!context.ContactTitle.Any(t => t.Name == model.Title))
                    model.Title = string.Empty;

                string rules = model.Rules.ToStringExt();

                if (rules.Contains("Debtor Rules & Regulations:"))
                    rules = rules.Left(rules.IndexOf("Debtor Rules & Regulations:"));

                string remarks = model.Remarks.ToStringExt();

                if (remarks.Contains("Debtor Remarks:"))
                    remarks = remarks.Left(remarks.IndexOf("Debtor Remarks:"));

                rules = rules.TrimStart(Environment.NewLine).TrimEnd(Environment.NewLine);
                remarks = remarks.TrimStart(Environment.NewLine).TrimEnd(Environment.NewLine);

                if (HttpContext.IsAdministrator() || isNew) {
                    q.AgencyId = model.AgencyId ?? 0;
                    q.ConsultantId = model.ConsultantId ?? 0;
                }

                q.Code = model.Code;
                q.Title = model.Title.ToStringExt();
                q.FirstName = model.FirstName;
                q.LastName = model.LastName;
                q.PhoneHome = model.PhoneHome.ToStringExt();
                q.PhoneWork = model.PhoneWork.ToStringExt();
                q.Mobile = model.Mobile.ToStringExt();
                q.Fax = model.Fax.ToStringExt();
                q.Email = model.Email.ToStringExt();
                q.MaritalStatus = model.MaritalStatus;
                q.BirthDate = model.BirthDate ?? DateTime.MinValue;
                q.BirthCountryId = model.BirthCountryId ?? 0;
                q.NationalityId = model.NationalityId ?? 0;
                q.Occupation = model.Occupation.ToStringExt();
                q.BusinessType = model.BusinessType.ToStringExt();
                q.DebtorId = model.DebtorId ?? 0;
                q.Rules = rules;
                q.Remarks = remarks;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ProfileId = q.Id;
                Passenger leadPassenger = null;

                if (baseTripId > 0) {
                    var trip = context.Trip.Find(baseTripId);
                    trip.ProfileId = q.Id;
                    context.Save(trip, false);
                    leadPassenger = context.Passenger.Where(t => t.Id == baseTripId).AsEnumerable().FirstOrDefault(t => t.IsLeadPassenger);
                }

                if (isNew || baseTripId > 0) {
                    leadPassenger ??= new Passenger {
                        Alias = string.Empty,
                        DisplayName = q.FullName,
                        PhoneNo = q.Mobile,
                        Email = q.Email,
                        BirthDate = q.BirthDate,
                        Gender = ContactTitle.GetContactTitle(context, q.Title, false).Gender
                    };

                    var passenger = new Passenger {
                        Id = 0,
                        ProfileId = q.Id,
                        TripId = -1,
                        Title = q.Title,
                        FirstName = q.FirstName,
                        LastName = q.LastName,
                        Alias = leadPassenger.Alias,
                        DisplayName = leadPassenger.DisplayName,
                        PhoneNo = leadPassenger.PhoneNo,
                        Email = leadPassenger.Email,
                        BirthDate = leadPassenger.BirthDate,
                        Gender = leadPassenger.Gender,
                        PassengerProfileId = -1,
                        ProfilePassengerId = -1,
                        CrsKey = string.Empty
                    };

                    passenger.PassengerType = passenger.GetPassengerType();
                    passenger.Age = passenger.GetAge();

                    context.Insert(passenger);
                }

                ts.Complete();
                return q.Id;
            }
        }

        public bool Delete(AppMainContext context, ProfileViewModel model) {
            var q = context.Profile.Include(t => t.ProfileAddresses).Include(t => t.ProfilePassengers).Include(t => t.ProfileAirlines).Include(t => t.ProfileClubMemberships)
                .Include(t => t.ProfileSuppliers).Include(t => t.ProfileLeisureActivities).Include(t => t.ProfileSpecialRequests).Include(t => t.ProfileFutureDestinations).Include(t => t.PaymentMethods)
                .Single(t => t.Id == model.ProfileId);

            if (q == null)
                throw new UnreportedException(AppConstants.RecordNotFound);

            return context.Delete(q);
        }

        public bool MergeProfile(AppMainContext context, int primaryProfileId, int[] profileIds) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = context.Profile.Find(primaryProfileId);

                foreach (int profileId in profileIds.Where(t => t != primaryProfileId)) {
                    var profile = context.Profile.Find(profileId);

                    q.Title = q.Title.Length == 0 ? profile.Title : q.Title;
                    q.PhoneHome = q.PhoneHome.Length == 0 ? profile.PhoneHome : q.PhoneHome;
                    q.PhoneWork = q.PhoneWork.Length == 0 ? profile.PhoneWork : q.PhoneWork;
                    q.Mobile = q.Mobile.Length == 0 ? profile.Mobile : q.Mobile;
                    q.Fax = q.Fax.Length == 0 ? profile.Fax : q.Fax;
                    q.Email = q.Email.Length == 0 ? profile.Email : q.Email;
                    q.MaritalStatus = q.MaritalStatus == MaritalStatus.NotSpecified ? profile.MaritalStatus : q.MaritalStatus;
                    q.BirthDate = q.BirthDate == DateTime.MinValue ? profile.BirthDate : q.BirthDate;
                    q.BirthCountryId = q.BirthCountryId == -1 ? profile.BirthCountryId : q.BirthCountryId;
                    q.NationalityId = q.NationalityId == -1 ? profile.NationalityId : q.NationalityId;
                    q.Occupation = q.Occupation.Length == 0 ? profile.Occupation : q.Occupation;
                    q.BusinessType = q.BusinessType.Length == 0 ? profile.BusinessType : q.BusinessType;
                    q.DebtorId = q.DebtorId == -1 ? profile.DebtorId : q.DebtorId;
                    q.AgencyId = q.AgencyId == -1 ? profile.AgencyId : q.AgencyId;
                    q.ConsultantId = q.ConsultantId == -1 ? profile.ConsultantId : q.ConsultantId;
                    q.Rules = q.Rules.Length == 0 ? profile.Rules : q.Rules;
                    q.Remarks = q.Remarks.Length == 0 ? profile.Remarks : q.Remarks;

                    context.Save(q);

                    foreach (var row in context.ProfileAddress.Where(t => t.ProfileId == profileId)) {
                        row.ProfileId = primaryProfileId;
                        context.Save(row, false);
                    }

                    foreach (var row in context.ProfileAirline.Where(t => t.ProfileId == profileId)) {
                        row.ProfileId = primaryProfileId;
                        context.Save(row, false);
                    }

                    foreach (var row in context.ProfileClubMembership.Where(t => t.ProfileId == profileId)) {
                        row.ProfileId = primaryProfileId;
                        context.Save(row, false);
                    }

                    foreach (var row in context.ProfileFutureDestination.Where(t => t.ProfileId == profileId)) {
                        row.ProfileId = primaryProfileId;
                        context.Save(row, false);
                    }

                    foreach (var row in context.ProfileLeisureActivity.Where(t => t.ProfileId == profileId)) {
                        row.ProfileId = primaryProfileId;
                        context.Save(row, false);
                    }

                    foreach (var row in context.ProfileSpecialRequest.Where(t => t.ProfileId == profileId)) {
                        row.ProfileId = primaryProfileId;
                        context.Save(row, false);
                    }

                    foreach (var row in context.ProfileSupplier.Where(t => t.ProfileId == profileId)) {
                        row.ProfileId = primaryProfileId;
                        context.Save(row, false);
                    }

                    foreach (var row in context.Trip.Where(t => t.ProfileId == profileId)) {
                        row.ProfileId = primaryProfileId;
                        context.Save(row, false);
                    }

                    foreach (var row in context.Passenger.Where(t => t.ProfileId == profileId)) {
                        row.ProfileId = primaryProfileId;
                        row.PassengerProfileId = -1;
                        context.Save(row, false);
                    }

                    foreach (var row in context.Passenger.Where(t => t.ProfileId == profileId)) {
                        row.PassengerProfileId = primaryProfileId;
                        context.Save(row, false);
                    }

                    context.Delete(profile);
                }

                ts.Complete();
                return true;
            }
        }
    }

    public static class ProfileAddressCommon {
        public static bool CreateOrUpdate(AppMainContext context, AddressViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                ProfileAddress q = null;

                if (model.AddressId <= 0) {
                    q = new ProfileAddress();
                }
                else {
                    q = context.ProfileAddress.Find(model.AddressId);
                }

                q.ProfileId = model.ParentId;
                q.AddressType = model.AddressType;
                q.Address1 = model.Address1.ToStringExt();
                q.Address2 = model.Address2.ToStringExt();
                q.Locality = model.Locality.ToStringExt();
                q.Region = model.Region.ToStringExt();
                q.PostCode = model.PostCode.ToStringExt();
                q.CountryCode = model.CountryCode.ToStringExt();
                q.IsDefault = model.IsDefaultAddress;

                bool result;

                if (q.Id <= 0) {
                    result = context.Insert(q);
                }
                else {
                    result = context.Save(q);
                }

                if (result) {
                    model.AddressId = q.Id;

                    if (model.IsDefaultAddress) {
                        foreach (var row in context.ProfileAddress.Where(t => t.Id != q.Id && t.ProfileId == model.ParentId && t.IsDefault).ToList()) {
                            row.IsDefault = false;
                            context.Save(row, false);
                        }
                    }
                }

                ts.Complete();
                return true;
            }
        }
    }

    public class TripCommon {
        private HttpContext HttpContext { get; }

        public TripCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public async Task<int> CrsImportAmadeus(AppLazyContext lazyContext, CrsImportModel model, string filePath, string[] fileNames) {
            bool isError = false;

            try {
                int profileId = model.CrsProfileId;
                int tripId = model.CrsTripId;

                var q = Amadeus.GetPnrList(lazyContext, HttpContext.CurrentCustomerId(), filePath, fileNames, true, model);

                if (q.Count == 0)
                    throw new UnreportedException("One or more selected files are invalid and cannot be imported.");

                foreach (var crsModel in q) {
                    crsModel.ClientDetail.ProfileId = profileId;
                    crsModel.ClientDetail.TripId = tripId;

                    CrsMapData(lazyContext, model, crsModel);

                    profileId = crsModel.ClientDetail.ProfileId;
                    tripId = crsModel.ClientDetail.TripId;
                }

                model.CrsProfileId = profileId;
                model.CrsTripId = tripId;

                return model.CrsProfileId == 0 || model.CrsTripId == 0 ? 0 : 1;
            }
            catch (Exception ex) {
                isError = true;

                if (ex is UnreportedException)
                    throw new UnreportedException(ex.Message);

                string error = ExceptionManagerBiz.Instance.GetErrorMessage("Travelog.WebApp.ClientLedger.TripCommon", "CrsImportAmadeus", ex, HttpContext.CurrentCustomerId(), HttpContext.User.Identity.Name);

                foreach (string fileName in fileNames) {
                    var fi = new FileInfo(Path.Combine(filePath, fileName));

                    if (!fi.Exists)
                        continue;

                    error = string.Format("{1}{0}{2}{0}", Environment.NewLine, error, fi.Name);
                    error = string.Format("{0}{1}", error, string.Join(Environment.NewLine, File.ReadAllLines(fi.FullName)));
                }

                ExceptionManagerBiz.Instance.LogError(error);

                string subject = string.Format("{0} - Application Error", AppSettings.AppTitle);
                string body = string.Format(AppConstants.MailBody, WebUtility.HtmlEncode(error).Replace(Environment.NewLine, AppConstants.HtmlLineBreak));

                await Mail.Instance.SendMailAsync(AppSettings.EmailErrors, subject, body);
                return -1;
            }
            finally {
                if (!isError && !AppSettings.IsLocal) {
                    foreach (string fileName in fileNames) {
                        var fi = new FileInfo(Path.Combine(filePath, fileName));
                        fi.Delete();
                    }
                }
            }
        }

        public bool CrsExportAmadeus(AppLazyContext lazyContext, CrsAmadeusExportModel model) {
            var trip = lazyContext.Trip.Find(model.AmadeusExportTripId);
            var sb = new StringBuilder();
            var passengers = new Dictionary<int, int>();

            if (trip.ConsultantId > 0)
                sb.AppendFormat("AP{0}OS YY CONSULTANT CONTACT {1}{0}", Environment.NewLine, trip.Consultant.Name);

            var q = trip.TripPassengers.Select(row => new {
                row.Id,
                row.PassengerType,
                row.Title,
                FirstName = row.FirstName.Replace("-", " ").Replace("'", string.Empty),
                LastName = row.LastName.Replace("-", " ").Replace("'", string.Empty),
                row.BirthDate
            }).OrderBy(t => t.LastName).ThenBy(t => t.FirstName);

            int index = 1;

            foreach (var passenger in q.Where(t => t.PassengerType != PassengerType.Infant).ToList()) {
                passengers.Add(passenger.Id, index++);

                string line = string.Concat(string.Format("NM1{0}/{1}{2}",
                    passenger.LastName,
                    string.Format("{0} {1}", passenger.FirstName, passenger.Title).Trim(),
                    passenger.PassengerType == PassengerType.Child ? string.Format("(CHD{0})", passenger.BirthDate == DateTime.MinValue ? string.Empty : string.Format("/{0:dMMMyy}", passenger.BirthDate)) : string.Empty)
                );

                foreach (string row in line.Split(62)) {
                    sb.AppendFormat("{0}{1}", row, Environment.NewLine);
                }
            }

            sb = sb.Replace(" /", "/");

            index = 1;
            int i = 1;

            foreach (var passenger in q.Where(t => t.PassengerType == PassengerType.Infant).ToList()) {
                passengers.Add(passenger.Id, index++);
                sb.AppendFormat("{1}/(INF/{2}{3}){0}", Environment.NewLine, i++, passenger.FirstName, passenger.BirthDate == DateTime.MinValue ? string.Empty : string.Format("/{0:dMMMyy}", passenger.BirthDate));
            }

            model.AmadeusExportContent1 = sb.ToString().ToUpper();
            sb = new StringBuilder();

            foreach (var passport in trip.TripPassengers.SelectMany(t => t.PassengerDocuments).Where(t => t.DocumentType == DocumentType.Passport && t.IssuingCountryId > 0 && t.Passenger.BirthDate > DateTime.MinValue && t.Passenger.Gender != Gender.NotSpecified).OrderBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName)) {
                sb.AppendFormat("SRDOCSYYHK1-P-{1}-{2}-{3}-{4:ddMMMyy}-{5}-{6:ddMMMyy}-{7}-{8}-H/P{9}{0}",
                    Environment.NewLine,
                    passport.IssuingCountry.Code,
                    passport.DocumentNo,
                    passport.Nationality.Code,
                    passport.Passenger.BirthDate,
                    passport.Passenger.Gender == Gender.Female ? "F" : "M",
                    passport.ExpiryDate,
                    passport.Passenger.LastName.Replace("-", string.Empty),
                    passport.Passenger.FirstName.Replace(" ", "-"),
                    passengers[passport.PassengerId]
                );
            }

            var address = trip.TripAddresses.OrderBy(t => t.IsDefault ? 0 : 1).FirstOrDefault();

            if (address?.Address1.Length > 0 && address.PostCode.Length > 0) {
                sb.AppendFormat("AM /{1}{2}{3}{4}{5}{6}{0}", Environment.NewLine,
                    address.Address1.Length == 0 ? string.Empty : string.Format("/A1-{0}", address.Address1),
                    address.Address2.Length == 0 ? string.Empty : string.Format("/A2-{0}", address.Address2),
                    address.Locality.Length == 0 ? string.Empty : string.Format("/CI-{0}", address.Locality),
                    address.Region.Length == 0 ? string.Empty : string.Format("/ST-{0}", address.Region),
                    address.CountryCode.Length == 0 ? string.Empty : string.Format("/CO-{0}", address.CountryCode),
                    address.PostCode.Length == 0 ? string.Empty : string.Format("/ZP-{0}", address.PostCode));
            }

            if (trip.PhoneHome.Length > 0)
                sb.AppendFormat("APH-{1}{0}", Environment.NewLine, trip.PhoneHome);

            if (trip.PhoneWork.Length > 0)
                sb.AppendFormat("APB-{1}{0}", Environment.NewLine, trip.PhoneWork);

            if (trip.Mobile.Length > 0) {
                sb.AppendFormat("APM-{1}{0}", Environment.NewLine, trip.Mobile);
                sb.AppendFormat("SRCTCM-{1}{0}", Environment.NewLine, trip.Mobile);
            }

            if (trip.Fax.Length > 0)
                sb.AppendFormat("APF-{1}{0}", Environment.NewLine, trip.Fax);

            if (trip.Email.Length > 0) {
                sb.AppendFormat("APE-{1}{0}", Environment.NewLine, trip.Email);
                sb.AppendFormat("SRCTCE-{1}/P1{0}", Environment.NewLine, trip.Email.Replace("@", "//").Replace("-", "./").Replace("_", ".."));
            }

            sb.AppendFormat("RM QUOTE NUMBER {1}{0}", Environment.NewLine, trip.TripNo);

            if (trip.ProfileId > 0)
                sb.AppendFormat("RM PROFILE CODE {1}{0}", Environment.NewLine, trip.Profile.Code);

            foreach (var clubMembership in trip.TripPassengers.SelectMany(t => t.PassengerClubMemberships)) {
                sb.AppendFormat("FFN{1}-{2}/P{3}{0}", Environment.NewLine, clubMembership.ClubMembership.CrsCode, clubMembership.ClubMembershipNo, passengers[clubMembership.PassengerId]);
            }

            sb.AppendFormat("RF {1}{0}", Environment.NewLine, model.AmadeusConsultant.Length > 0 ? model.AmadeusConsultant : trip.ConsultantId > 0 ? trip.Consultant.Name : "Travelog Export");
            sb.AppendFormat("ER");

            model.AmadeusExportContent2 = sb.ToString().ToUpper();
            return true;
        }

        public bool CrsImportCalypso(AppLazyContext lazyContext, CrsImportModel model) {
            var crsModel = Calypso.RetrievePnr(lazyContext, HttpContext.CurrentCustomerId(), model);
            CrsMapData(lazyContext, model, crsModel);

            model.CrsTripId = crsModel.ClientDetail.TripId;
            model.CrsProfileId = crsModel.ClientDetail.ProfileId;

            return true;
        }

        public async Task<bool> CrsImportEtg(AppLazyContext lazyContext, CrsImportModel model) {
            var crsModel = await ExpressTravelGroup.RetrievePnrAsync(lazyContext, HttpContext.CurrentCustomerId(), model);

            CrsMapData(lazyContext, model, crsModel);

            model.CrsTripId = crsModel.ClientDetail.TripId;
            model.CrsProfileId = crsModel.ClientDetail.ProfileId;

            return true;
        }

        public async Task<bool> CrsImportGalileo(AppLazyContext lazyContext, CrsImportModel model) {
            bool isDevelopmentMode = AppSettings.IsDevelopmentMode && !AppSettings.Setting(HttpContext.CurrentCustomerId()).CrsGalileoUseProduction;
            var crsModel = await Travelport.RetrievePnrAsync(lazyContext, HttpContext.CurrentCustomerId(), model, isDevelopmentMode);

            CrsMapData(lazyContext, model, crsModel);

            model.CrsTripId = crsModel.ClientDetail.TripId;
            model.CrsProfileId = crsModel.ClientDetail.ProfileId;

            return true;
        }

        public async Task<bool> CrsExportGalileo(AppLazyContext lazyContext, CrsGalileoExportModel model) {
            bool isDevelopmentMode = AppSettings.IsDevelopmentMode && !AppSettings.Setting(HttpContext.CurrentCustomerId()).CrsGalileoUseProduction;
            //await Travelport.CreatePnr(lazyContext, HttpContext.CurrentCustomerId(), model, isDevelopmentMode);
            return !string.IsNullOrEmpty(model.GalileoExportCrsPnrRef);
        }

        private void CrsMapData(AppMainContext context, CrsImportModel model, CrsModel crsModel, bool mergeTripLines = false) {
            DateTime startDate1 = DateTime.MinValue;
            DateTime startDate2 = DateTime.MinValue;

            crsModel.PassengerList = crsModel.PassengerList.Where(t => !t.IsDuplicate).ToList();

            foreach (var row in crsModel.TripLineAirList.Where(t => t.TripLineAirSegmentList.Count == 0 && t.TripLineAirPassengerList.Count == 0).ToList()) {
                crsModel.TripLineAirList.Remove(row);
            }

            if (crsModel.TripLineAirList.SelectMany(t => t.TripLineAirSegmentList).Any())
                startDate1 = crsModel.TripLineAirList.SelectMany(t => t.TripLineAirSegmentList).Min(t => t.DepartureDate);

            if (crsModel.TripLineLandList.Count > 0)
                startDate2 = crsModel.TripLineLandList.Min(t => t.StartDate);

            if (startDate1 == DateTime.MinValue) {
                startDate1 = startDate2;
            }
            else if (startDate2 == DateTime.MinValue) {
                startDate2 = startDate1;
            }

            if (startDate1 > DateTime.MinValue && startDate2 > DateTime.MinValue && startDate1 > startDate2)
                startDate1 = startDate2;

            if (startDate1 > DateTime.MinValue) {
                foreach (var row in crsModel.PassengerList.Where(t => t.PassengerType == PassengerType.NotSpecified && t.BirthDate > DateTime.MinValue)) {
                    row.PassengerType = Passenger.GetPassengerType(row.BirthDate, startDate1);
                }
            }

            if (!context.TripItineraryDetail.Include(t => t.TripItinerary).Include(t => t.TripLine).Any(t => t.TripItinerary.TripId == model.CrsTripId && t.TripLine.TripLineType == TripLineType.ServiceFee)) {
                context.RemoveRange(context.TripLineServiceFee.Include(t => t.TripLine).Where(t => t.Crs == crsModel.Crs && t.CrsPnrRef == crsModel.CrsPnrRef && t.TripLine.TripId == crsModel.ClientDetail.TripId && t.TripLine.TripLineType == TripLineType.ServiceFee && t.ServiceFeePaymentType == ServiceFeePaymentType.Supplier).Select(t => t.TripLine));
                context.SaveChanges();
            }

            if (!context.TripItineraryDetail.Include(t => t.TripItinerary).Include(t => t.TripLine).Any(t => t.TripItinerary.TripId == model.CrsTripId && t.TripLine.TripLineType == TripLineType.Remark)) {
                context.RemoveRange(context.TripLineRemark.Include(t => t.TripLine).Where(t => t.Crs == crsModel.Crs && t.CrsPnrRef == crsModel.CrsPnrRef && t.TripLine.TripId == crsModel.ClientDetail.TripId && t.TripLine.TripLineType == TripLineType.Remark).Select(t => t.TripLine));
                context.SaveChanges();
            }

            using (var ts = Utils.CreateTransactionScope()) {
                CrsMapDataIds(context, model, crsModel);
                CrsMapDataTrip(context, model, crsModel);
                CrsMapDataPassenger(context, crsModel);
                CrsMapDataIds(context, model, crsModel);

                var tripLineList = crsModel.TripLineAirList.Select(row => new {
                    row.CrsRefId,
                    StartDate = row.TripLineAirSegmentList.Min(t => (DateTime?)t.DepartureDate) ?? DateTime.MinValue,
                    EndDate = row.TripLineAirSegmentList.Max(t => (DateTime?)t.ArrivalDate) ?? DateTime.MinValue,
                    TripLineType = TripLineType.Air
                }).Concat(crsModel.TripLineLandList.Select(row => new {
                    row.CrsRefId,
                    row.StartDate,
                    row.EndDate,
                    row.TripLineType
                })).Concat(crsModel.TripLineRemarkList.Select(row => new {
                    row.CrsRefId,
                    row.StartDate,
                    row.EndDate,
                    TripLineType = TripLineType.Remark
                }));

                if (crsModel.Crs == Crs.Galileo || crsModel.Crs == Crs.Amadeus) {
                    tripLineList = tripLineList.OrderBy(t => t.StartDate).ThenByDescending(t => (t.EndDate - t.StartDate).Days).ToList();
                }
                else {
                    tripLineList = tripLineList.OrderBy(t => t.CrsRefId).ToList();
                }

                foreach (var row in tripLineList.Where(t => t.TripLineType != TripLineType.Remark)) {
                    if (row.TripLineType == TripLineType.Air) {
                        if (model.CrsImportAirTripLines)
                            CrsMapDataAir(context, model, crsModel, row.CrsRefId);
                    }
                    else {
                        CrsMapDataLand(context, model, crsModel, row.CrsRefId);
                    }
                }

                CrsMapDataServiceFee(model, crsModel);

                if (tripLineList.Any(t => t.TripLineType == TripLineType.Remark))
                    CrsMapDataRemark(context, crsModel);

                using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                    foreach (var row in lazyContext.TripLineAirSegment.Include(t1 => t1.TripLineAir).ThenInclude(t1 => t1.TripLine).Include(t1 => t1.TripLineAirPassengerAirSegments).ThenInclude(t1 => t1.TripLineAirPassenger).Include(t1 => t1.TripLineRemarks).Where(t1 => t1.TripLineAir.TripLine.TripId == crsModel.ClientDetail.TripId).AsEnumerable().Where(t1 => t1.CrsKey.Length > 0 && crsModel.TripLineAirList.Any(t2 => t2.TripLineId == t1.TripLineId && !t2.TripLineAirSegmentList.Any(t3 => t3.TripLineAirSegmentId == t1.Id && t3.CrsKey.Length > 0))).ToList()) {
                        bool segmentDeleted = false;

                        if (row.DepartureDate > DateTime.Today && !row.TripLineAirPassengerAirSegments.Any(t => t.TripLineAirPassenger.TicketNo.Length > 0)) {
                            try {
                                segmentDeleted = lazyContext.Delete(row);
                            }
                            catch {
                            }
                        }
                    }

                    var tripLines = context.TripLine.Include(t => t.Trip).ThenInclude(t => t.TripPassengers).Include(t => t.TripLineLand).ThenInclude(t => t.ServiceTypeRateBasis)
                        .Include(t => t.TripLineAir).ThenInclude(t => t.TripLineAirPassengers).ThenInclude(t => t.TripLineAirPassengerAirSegments)
                        .Include(t => t.TripLineAir).ThenInclude(t => t.TripLineAirSegments).ThenInclude(t => t.TripLineAirPassengerAirSegments)
                        .Where(t => t.TripId == crsModel.ClientDetail.TripId && t.TripLineType == TripLineType.Air && t.TripLineAir.CrsPnrRef == crsModel.CrsPnrRef).OrderBy(t => t.Id).ToList();

                    if (mergeTripLines && tripLines.Count > 1) {
                        var tripLineAirExisting = tripLines.First().TripLineAir;
                        var tripLineAirNew = tripLines.Last().TripLineAir;
                        CrsMergeAirTripLines(context, tripLineAirExisting, tripLineAirNew);
                    }

                    var tripLineAirCommon = new TripLineAirCommon(HttpContext);

                    try {
                        foreach (var tripLine in tripLines.Where(t => t.TripLineType == TripLineType.Air).ToList()) {
                            tripLineAirCommon.InsertArnkAirSegments(HttpContext.User, HttpContext.CurrentCustomerId(), tripLine.Id, false, true);
                        }
                    }
                    catch (Exception ex) {
                        if (ex is CrsException)
                            model.ErrorMessage = "This import may have issues with flight segments that require rectification.";
                    }

                    Trip trip;

                    if (tripLines.Count > 0) {
                        trip = tripLines[0].Trip;
                    }
                    else {
                        trip = lazyContext.Trip.Find(crsModel.ClientDetail.TripId);
                    }

                    UpdateDepartureReturnDates(lazyContext, trip.Id);
                    trip.UpdatePassengerCount(context);

                    try {
                        TripLineSelectionCommon.Reorder(lazyContext, trip.Id, -1, TripLineOrderType.StartDate, null, true);
                    }
                    catch (Exception ex) {
                        if (ex is CrsException)
                            model.ErrorMessage = "This import may have issues with flight segments that require rectification.";
                    }
                }

                ts.Complete();
            }

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                foreach (var tripLine in lazyContext.TripLine.Where(t => t.TripId == crsModel.ClientDetail.TripId && (t.TripLineAir.CrsPnrRef == crsModel.CrsPnrRef || t.TripLineLand.CrsPnrRef == crsModel.CrsPnrRef || t.TripLineServiceFee.CrsPnrRef == crsModel.CrsPnrRef)).ToList()) {
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }
            }
        }

        private void CrsMapDataIds(AppMainContext context, CrsImportModel model, CrsModel crsModel) {
            foreach (var row1 in crsModel.PassengerList.Where(t => t.PassengerId == 0).ToList()) {
                if (row1.CrsKey.Length > 0 && (crsModel.Crs == Crs.Amadeus || crsModel.Crs == Crs.ExpressTravelGroup || crsModel.Crs == Crs.Galileo))
                    row1.PassengerId = context.Passenger.SingleOrDefault(t => t.TripId == crsModel.ClientDetail.TripId && t.CrsKey == row1.CrsKey)?.Id ?? 0;

                if (row1.PassengerId <= 0)
                    row1.PassengerId = context.Passenger.Where(t => !crsModel.PassengerList.Select(t => t.PassengerId).Contains(t.Id) && (t.ProfileId == -1 || t.ProfileId == crsModel.ClientDetail.ProfileId) && t.TripId == crsModel.ClientDetail.TripId).AsEnumerable().FirstOrDefault(t => t.Title.ToLower().Left(20).Trim() == row1.Title.ToLower().Left(20).Trim() && t.FirstName.ToLower().Replace(" ", string.Empty).ToLower().Left(50).Trim() == row1.FirstName.Replace(" ", string.Empty).ToLower().Left(50).Trim() && t.LastName.Replace(" ", string.Empty).ToLower().Left(50).Trim() == row1.LastName.Replace(" ", string.Empty).ToLower().Left(50).Trim())?.Id ?? 0;

                foreach (var row2 in row1.PassengerDocumentList.Where(t => t.CrsPassengerKey == row1.CrsKey && t.PassengerDocumentId == 0).ToList()) {
                    row2.PassengerDocumentId = context.PassengerDocument.Where(t => t.PassengerId == row1.PassengerId && !row1.PassengerDocumentList.Select(t => t.PassengerDocumentId).Contains(t.Id)).FirstOrDefault(t => t.DocumentType == row2.DocumentType && t.DocumentNo.ToLower() == row2.DocumentNo.ToLower() && t.IssuingCountryId == row2.IssuingCountryId)?.Id ?? 0;
                }

                foreach (var row2 in row1.PassengerClubMembershipList.Where(t => t.CrsPassengerKey == row1.CrsKey && t.PassengerClubMembershipId == 0).ToList()) {
                    row2.PassengerClubMembershipId = context.PassengerClubMembership.Where(t => t.PassengerId == row1.PassengerId && !row1.PassengerClubMembershipList.Select(t => t.PassengerClubMembershipId).Contains(t.Id)).FirstOrDefault(t => t.ClubMembershipId == row2.ClubMembershipId && t.ClubMembershipNo.ToLower() == row2.ClubMembershipNo.ToLower() && t.AirlineId == row2.AirlineId)?.Id ?? 0;
                }
            }

            foreach (var row1 in crsModel.TripLineAirList) {
                var tripLineAirPassengerList = new List<int>();

                foreach (var row2 in row1.TripLineAirSegmentList) {
                    TripLineAirSegment tripLineAirSegment = null;

                    if (row2.CrsKey.Length > 0 && (crsModel.Crs == Crs.Amadeus || crsModel.Crs == Crs.ExpressTravelGroup || crsModel.Crs == Crs.Galileo))
                        tripLineAirSegment = context.TripLineAirSegment.Include(t => t.TripLineAir).ThenInclude(t => t.TripLine).SingleOrDefault(t => t.CrsKey == row2.CrsKey && t.TripLineAir.CrsPnrRef == row1.CrsPnrRef && t.AirlinePnr == row2.AirlinePnr && t.TripLineAir.TripLine.TripId == crsModel.ClientDetail.TripId && t.DepartureCityId == row2.DepartureCityId && t.ArrivalCityId == row2.ArrivalCityId);

                    if (tripLineAirSegment == null) {
                        var tripLineAirSegmentBase = context.TripLineAirSegment.Include(t => t.TripLineAir).ThenInclude(t => t.TripLine).Where(t => t.TripLineAir.CrsPnrRef == row1.CrsPnrRef && t.AirlinePnr == row2.AirlinePnr && t.TripLineAir.TripLine.TripId == crsModel.ClientDetail.TripId && t.DepartureCityId == row2.DepartureCityId && t.ArrivalCityId == row2.ArrivalCityId).AsEnumerable();

                        if (crsModel.Crs == Crs.Amadeus || crsModel.Crs == Crs.ExpressTravelGroup) {
                            tripLineAirSegmentBase = tripLineAirSegmentBase.Where(t => t.TripLineAir.Crs == Crs.Amadeus || t.TripLineAir.Crs == Crs.ExpressTravelGroup);
                        }
                        else {
                            tripLineAirSegmentBase = tripLineAirSegmentBase.Where(t => t.TripLineAir.Crs == crsModel.Crs);
                        }

                        int count = 0;

                        while (tripLineAirSegment == null && count <= 16) {
                            count++;

                            if (count > 1 && model.CrsAirSegmentsUpdated)
                                break;

                            switch (count) {
                                case 1:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.Class.ToLower().Left(3) == row2.Class.ToLower().Left(3) && t.FlightNo.ToLower().Left(8) == row2.FlightNo.ToLower().Left(8) && t.DepartureDate == row2.DepartureDate && t.DepartureTime == row2.DepartureTime && t.AircraftId == row2.AircraftId);
                                    break;
                                case 2:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.Class.ToLower().Left(3) == row2.Class.ToLower().Left(3) && t.FlightNo.ToLower().Left(8) == row2.FlightNo.ToLower().Left(8) && t.DepartureDate == row2.DepartureDate && t.DepartureTime == row2.DepartureTime);
                                    break;
                                case 3:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.Class.ToLower().Left(3) == row2.Class.ToLower().Left(3) && t.FlightNo.ToLower().Left(8) == row2.FlightNo.ToLower().Left(8) && t.AircraftId == row2.AircraftId);
                                    break;
                                case 4:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.Class.ToLower().Left(3) == row2.Class.ToLower().Left(3) && t.DepartureDate == row2.DepartureDate && t.DepartureTime == row2.DepartureTime && t.AircraftId == row2.AircraftId);
                                    break;
                                case 5:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.FlightNo.ToLower().Left(8) == row2.FlightNo.ToLower().Left(8) && t.DepartureDate == row2.DepartureDate && t.DepartureTime == row2.DepartureTime && t.AircraftId == row2.AircraftId);
                                    break;
                                case 6:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.Class.ToLower().Left(3) == row2.Class.ToLower().Left(3) && t.FlightNo.ToLower().Left(8) == row2.FlightNo.ToLower().Left(8));
                                    break;
                                case 7:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.Class.ToLower().Left(3) == row2.Class.ToLower().Left(3) && t.DepartureDate == row2.DepartureDate && t.DepartureTime == row2.DepartureTime);
                                    break;
                                case 8:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.Class.ToLower().Left(3) == row2.Class.ToLower().Left(3) && t.AircraftId == row2.AircraftId);
                                    break;
                                case 9:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.FlightNo.ToLower().Left(8) == row2.FlightNo.ToLower().Left(8) && t.DepartureDate == row2.DepartureDate && t.DepartureTime == row2.DepartureTime);
                                    break;
                                case 10:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.FlightNo.ToLower().Left(8) == row2.FlightNo.ToLower().Left(8) && t.AircraftId == row2.AircraftId);
                                    break;
                                case 11:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.DepartureDate == row2.DepartureDate && t.DepartureTime == row2.DepartureTime && t.AircraftId == row2.AircraftId);
                                    break;
                                case 12:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.Class.ToLower().Left(3) == row2.Class.ToLower().Left(3));
                                    break;
                                case 13:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.FlightNo.ToLower().Left(8) == row2.FlightNo.ToLower().Left(8));
                                    break;
                                case 14:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.DepartureDate == row2.DepartureDate && t.DepartureTime == row2.DepartureTime);
                                    break;
                                case 15:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault(t => t.AircraftId == row2.AircraftId);
                                    break;
                                case 16:
                                    tripLineAirSegment = tripLineAirSegmentBase.FirstOrDefault();
                                    break;
                            }
                        }
                    }

                    if (tripLineAirSegment != null) {
                        if (row1.TripLineId <= 0)
                            row1.TripLineId = tripLineAirSegment.TripLineId;

                        if (row2.TripLineAirSegmentId <= 0)
                            row2.TripLineAirSegmentId = tripLineAirSegment.Id;
                    }

                    foreach (var row3 in row1.TripLineAirPassengerList.Where(t1 => t1.TripLineAirPassengerAirSegmentList.Count == 0 || t1.TripLineAirPassengerAirSegmentList.Any(t2 => t2.CrsAirSegmentKey == row2.CrsKey && t2.CrsPassengerKey == t1.CrsPassengerKey))) {
                        row3.TripLineAirSegmentId = row2.TripLineAirSegmentId;
                        row3.PassengerId = crsModel.PassengerList.SingleOrDefault(t => t.CrsKey == row3.CrsPassengerKey)?.PassengerId ?? 0;

                        foreach (var row4 in crsModel.TripLineRemarkList.Where(t => t.TripLineId == 0 && t.CrsTripLineAirSegmentNo == row2.CrsKey && t.CrsPassengerNo == row3.CrsPassengerKey)) {
                            row4.TripLineId = context.TripLineRemark.Include(t => t.TripLine).Where(t => !crsModel.TripLineRemarkList.Select(t => t.TripLineId).Contains(t.TripLineId) && row4.CrsTripLineAirSegmentNo == row2.CrsKey && row4.CrsPassengerNo == row3.CrsPassengerKey && t.StartDate == row4.StartDate && t.EndDate == row4.EndDate && t.TripLine.TripId == crsModel.ClientDetail.TripId).AsEnumerable().FirstOrDefault(t => t.Description.ToLower().Left(50).Trim() == row4.Description.ToLower().Left(50).Trim())?.TripLineId ?? 0;
                            row4.TripLineAirSegmentId = row2.TripLineAirSegmentId;
                        }

                        var tripLineAirPassengers = context.TripLineAirPassenger.Where(t => t.TripLineId == row1.TripLineId && t.PassengerId == row3.PassengerId && t.TripLineAir.CrsPnrRef == crsModel.CrsPnrRef
                            && t.TripLineAir.TripLine.TripId == crsModel.ClientDetail.TripId && t.CreditorId == row3.CreditorId && t.SupplierId == row3.SupplierId && t.AirlineId == row3.AirlineId).AsEnumerable()
                            .Where(t => t.BspEntryType == row3.BspEntryType && ((t.TicketNo.Length > 0 && row3.TicketNo.Length == 0) || t.TicketNo.ToLower().Left(25).Trim() == row3.TicketNo.ToLower().Left(25).Trim()) && !tripLineAirPassengerList.Contains(t.Id));

                        TripLineAirPassenger tripLineAirPassenger;

                        if (crsModel.Crs == Crs.Amadeus || crsModel.Crs == Crs.ExpressTravelGroup) {
                            tripLineAirPassenger = tripLineAirPassengers.FirstOrDefault(t => t.TripLineAir.Crs == Crs.Amadeus || t.TripLineAir.Crs == Crs.ExpressTravelGroup);
                        }
                        else {
                            tripLineAirPassenger = tripLineAirPassengers.FirstOrDefault(t => t.TripLineAir.Crs == crsModel.Crs);
                        }

                        if (tripLineAirPassenger == null)
                            continue;

                        tripLineAirPassengerList.Add(tripLineAirPassenger.Id);

                        if (row3.TripLineAirPassengerId <= 0)
                            row3.TripLineAirPassengerId = tripLineAirPassenger.Id;

                        if (row1.TripLineId <= 0)
                            row1.TripLineId = tripLineAirPassenger.TripLineId;
                    }
                }
            }

            foreach (var row in crsModel.TripLineLandList.Where(t => t.TripLineId == 0)) {
                row.TripLineId = context.TripLineLand.Include(t => t.TripLine).Where(t => !crsModel.TripLineLandList.Select(t => t.TripLineId).Contains(t.TripLineId) && t.TripLine.TripId == crsModel.ClientDetail.TripId && t.TripLine.TripLineType == row.TripLineType && t.CreditorId == row.CreditorId && t.SupplierId == (row.SupplierId == -1 ? model.CrsSupplierLandId : row.SupplierId) && t.Crs == crsModel.Crs && t.CrsPnrRef == crsModel.CrsPnrRef && t.StartDate == row.StartDate && t.EndDate == row.EndDate && t.SaleTypeId == row.SaleTypeId && t.CurrencyId == row.CurrencyId).AsEnumerable().FirstOrDefault(t => t.SupplierServiceDescription.ToLower().Left(50).Trim() == row.SupplierServiceDescription.ToLower().Left(50).Trim())?.TripLineId ?? 0;
            }
        }

        private void CrsMapDataTrip(AppMainContext context, CrsImportModel model, CrsModel crsModel) {
            Trip trip = null;
            string notes = string.Empty;

            if (crsModel.Crs == Crs.Amadeus) {
                string[] fileParts = crsModel.FileName.Split('.');
                string fileName;

                if (fileParts.Length == 2) {
                    fileName = string.Format("{0}.{1}", fileParts[0].ToUpper(), fileParts[1].ToLower());
                }
                else {
                    fileName = crsModel.FileName;
                }

                notes = crsModel.Crs == Crs.Amadeus ? string.Format("PNR {0} [{1}] imported on {2:g}.", crsModel.CrsPnrRef, fileName, DateTime.Now) : string.Empty;
            }

            if (crsModel.ClientDetail.TripId > 0) {
                trip = context.Trip.Include(t => t.TripLines).ThenInclude(t => t.TripLineAir).Include(t => t.TripLines).ThenInclude(t => t.TripLineLand).Single(t => t.Id == crsModel.ClientDetail.TripId);

                if (notes.Length > 0)
                    trip.Notes = string.Format("{1}{0}{0}{2}", Environment.NewLine, trip.Notes, notes).TrimStart(Environment.NewLine.ToCharArray());

                IEnumerable<TripLine> tripLineList = null;

                if (model.CrsImportAirTripLines) {
                    tripLineList = trip.TripLines.Where(t => t.TripLineType == TripLineType.Air || t.TripLineType == TripLineType.Accommodation || t.TripLineType == TripLineType.Transport || t.TripLineType == TripLineType.Cruise || t.TripLineType == TripLineType.Tour || t.TripLineType == TripLineType.OtherLand);
                }
                else {
                    tripLineList = trip.TripLines.Where(t => t.TripLineType == TripLineType.Accommodation || t.TripLineType == TripLineType.Transport || t.TripLineType == TripLineType.Cruise || t.TripLineType == TripLineType.Tour || t.TripLineType == TripLineType.OtherLand);
                }

                if (crsModel.Crs == Crs.Amadeus || crsModel.Crs == Crs.ExpressTravelGroup) {
                    tripLineList = tripLineList.Where(t => (t.TripLineType == TripLineType.Air && t.TripLineAir != null && (t.TripLineAir.Crs == Crs.Amadeus || t.TripLineAir.Crs == Crs.ExpressTravelGroup) && t.TripLineAir.CrsPnrRef == crsModel.CrsPnrRef) || (t.TripLineLand != null && t.TripLineLand.Crs == crsModel.Crs && t.TripLineLand.CrsPnrRef == crsModel.CrsPnrRef)).ToList();
                }
                else {
                    tripLineList = tripLineList.Where(t => (t.TripLineType == TripLineType.Air && t.TripLineAir != null && t.TripLineAir.Crs == crsModel.Crs && t.TripLineAir.CrsPnrRef == crsModel.CrsPnrRef) || (t.TripLineLand != null && t.TripLineLand.Crs == crsModel.Crs && t.TripLineLand.CrsPnrRef == crsModel.CrsPnrRef)).ToList();
                }
            }
            else {
                trip = new Trip {
                    Id = 0,
                    Code = string.Empty,
                    ProfileId = -1,
                    ClientAccountType = ClientAccountType.Client,
                    BookingType = BookingType.NotSpecified,
                    SerkoOnlineBookingStatus = SerkoOnlineBookingStatus.NotSpecified,
                    MaritalStatus = MaritalStatus.NotSpecified,
                    Occupation = string.Empty,
                    BusinessType = string.Empty,
                    UserReferenceNo = string.Empty,
                    AgencyId = crsModel.ClientDetail.AgencyId <= 0 ? HttpContext.CurrentDefaultAgencyId() : crsModel.ClientDetail.AgencyId,
                    ConsultantId = crsModel.ClientDetail.ConsultantId <= 0 ? HttpContext.CurrentConsultantId() : crsModel.ClientDetail.ConsultantId,
                    AgentId = -1,
                    SourceId = -1,
                    GroupId = -1,
                    ClassId = -1,
                    CategoryId = -1,
                    DestinationId = -1,
                    LocationId = -1,
                    MainCityId = -1,
                    DebtorId = -1,
                    DebtorBookedById = -1,
                    DebtorAuthorisedById = -1,
                    DebtorOrderNo = string.Empty,
                    DebtorTravelReason = string.Empty,
                    DebtorVideoConferencingConsidered = false,
                    DebtorVideoConferencingReasonRejected = string.Empty,
                    ReturnDate = DateTime.MinValue,
                    ExchangeRate = 0,
                    Rules = string.Empty,
                    Remarks = string.Empty,
                    Notes = notes,
                    ChecklistComments = string.Empty,
                    ChecklistContactMethod = ContactMethod.NotSpecified,
                    ChecklistContactById = -1,
                    ChecklistFollowUpDate = DateTime.MinValue,
                    CancellationContactMethod = ContactMethod.NotSpecified,
                    CancellationById = -1,
                    IsBooking = false,
                    IsCancellation = false,
                    IsLocked = false
                };
            }

            var tripViewModel = new TripViewModel {
                TripId = trip.Id,
                Code = trip.Code,
                ProfileId = trip.ProfileId,
                ClientAccountType = trip.ClientAccountType,
                BookingType = trip.BookingType,
                SerkoOnlineBookingStatus = trip.SerkoOnlineBookingStatus,
                Title = string.IsNullOrEmpty(trip.Title) ? crsModel.ClientDetail.Title : trip.Title,
                FirstName = string.IsNullOrEmpty(trip.FirstName) ? crsModel.ClientDetail.FirstName : trip.FirstName,
                LastName = string.IsNullOrEmpty(trip.LastName) ? crsModel.ClientDetail.LastName : trip.LastName,
                PhoneHome = string.IsNullOrEmpty(trip.PhoneHome) ? crsModel.ClientDetail.PhoneHome : trip.PhoneHome,
                PhoneWork = string.IsNullOrEmpty(trip.PhoneWork) ? crsModel.ClientDetail.PhoneWork : trip.PhoneWork,
                Mobile = string.IsNullOrEmpty(trip.Mobile) ? crsModel.ClientDetail.Mobile : trip.Mobile,
                Fax = string.IsNullOrEmpty(trip.Fax) ? crsModel.ClientDetail.Fax : trip.Fax,
                Email = string.IsNullOrEmpty(trip.Email) ? crsModel.ClientDetail.Email : trip.Email,
                MaritalStatus = trip.MaritalStatus,
                Occupation = trip.Occupation,
                BusinessType = trip.BusinessType,
                UserReferenceNo = trip.UserReferenceNo,
                AgencyId = trip.AgencyId,
                ConsultantId = trip.ConsultantId,
                AgentId = trip.AgentId,
                SourceId = trip.SourceId,
                TripCurrencyId = trip.CurrencyId <= 0 ? crsModel.ClientDetail.CurrencyId : trip.CurrencyId,
                GroupId = trip.GroupId,
                ClassId = trip.ClassId,
                CategoryId = trip.CategoryId,
                DestinationId = trip.DestinationId,
                LocationId = trip.LocationId,
                MainCityId = trip.MainCityId,
                DebtorId = trip.DebtorId,
                DebtorBookedById = trip.DebtorBookedById,
                DebtorAuthorisedById = trip.DebtorAuthorisedById,
                DebtorOrderNo = trip.DebtorOrderNo,
                DebtorTravelReason = trip.DebtorTravelReason,
                DebtorVideoConferencingConsidered = false,
                DebtorVideoConferencingReasonRejected = string.Empty,
                TripDepartureDate = crsModel.ClientDetail.DepartureDate,
                TripReturnDate = DateTime.MinValue,
                BalanceDueDate = crsModel.ClientDetail.BalanceDueDate,
                TripExchangeRate = trip.ExchangeRate,
                Rules = trip.Rules,
                Remarks = trip.Remarks,
                Notes = trip.Notes,
                ChecklistContactMethod = trip.ChecklistContactMethod,
                ChecklistContactById = trip.ChecklistContactById,
                ChecklistFollowUpDate = trip.ChecklistFollowUpDate,
                ChecklistComments = trip.ChecklistComments,
                CancellationContactMethod = trip.CancellationContactMethod,
                CancellationById = trip.CancellationById,
                TripCrs = trip.GetCrs(HttpContext.CurrentCustomerId()),
                IsBooking = trip.IsBooking,
                IsCancellation = trip.IsCancellation,
                TripIsLocked = trip.IsLocked
            };

            CreateOrUpdate(context, tripViewModel, false, false, true);

            if (!string.IsNullOrEmpty(crsModel.ClientDetail.Address1) || !string.IsNullOrEmpty(crsModel.ClientDetail.Address2) || !string.IsNullOrEmpty(crsModel.ClientDetail.Locality) || !string.IsNullOrEmpty(crsModel.ClientDetail.Region) || !string.IsNullOrEmpty(crsModel.ClientDetail.PostCode) || !string.IsNullOrEmpty(crsModel.ClientDetail.CountryCode)) {
                var tripAddress = context.TripAddress.FirstOrDefault(t => t.TripId == tripViewModel.TripId && t.Address1 == crsModel.ClientDetail.Address1 && t.Address2 == crsModel.ClientDetail.Address2 && t.Locality == crsModel.ClientDetail.Locality && t.Region == crsModel.ClientDetail.Region && t.PostCode == crsModel.ClientDetail.PostCode && t.CountryCode == crsModel.ClientDetail.CountryCode);

                var addressViewModel = new AddressViewModel {
                    AddressId = tripAddress?.Id ?? 0,
                    ParentId = tripViewModel.TripId,
                    Address1 = crsModel.ClientDetail.Address1.Left(50).Trim(),
                    Address2 = crsModel.ClientDetail.Address2.Left(50).Trim(),
                    Locality = crsModel.ClientDetail.Locality.Left(50).Trim(),
                    Region = crsModel.ClientDetail.Region.Left(20),
                    PostCode = crsModel.ClientDetail.PostCode.Left(20),
                    CountryCode = crsModel.ClientDetail.CountryCode
                };

                TripAddressCommon.CreateOrUpdate(context, addressViewModel);
            }

            crsModel.ClientDetail.TripId = tripViewModel.TripId;
            crsModel.ClientDetail.ProfileId = tripViewModel.ProfileId;
        }

        private void CrsMapDataPassenger(AppMainContext context, CrsModel crsModel) {
            foreach (var passenger in crsModel.PassengerList.Where(t => t.PassengerId != -2).ToList()) {
                Passenger tripPassenger = null;

                if (passenger.PassengerId > 0) {
                    tripPassenger = context.Passenger.Find(passenger.PassengerId);

                    if (tripPassenger != null) {
                        if (passenger.PassengerType == PassengerType.NotSpecified)
                            passenger.PassengerType = tripPassenger.PassengerType;

                        if (passenger.Title.Length == 0)
                            passenger.Title = tripPassenger.Title;

                        if (passenger.PhoneNo.Length == 0)
                            passenger.PhoneNo = tripPassenger.PhoneNo;

                        if (passenger.Email.Length == 0)
                            passenger.Email = tripPassenger.Email;

                        if (passenger.BirthDate == DateTime.MinValue)
                            passenger.BirthDate = tripPassenger.BirthDate;

                        if (passenger.Age == 0)
                            passenger.Age = tripPassenger.Age;

                        if (passenger.Gender == Gender.NotSpecified)
                            passenger.Gender = tripPassenger.Gender;
                    }
                }

                var passengerViewModel = new PassengerViewModel {
                    PassengerId = passenger.PassengerId,
                    PassengerType = passenger.PassengerType,
                    PassengerProfileId = -1,
                    PassengerTripId = crsModel.ClientDetail.TripId,
                    PassengerTitle = passenger.Title,
                    PassengerFirstName = passenger.FirstName,
                    PassengerLastName = passenger.LastName,
                    PassengerPhoneNo = passenger.PhoneNo,
                    PassengerEmail = passenger.Email,
                    PassengerAlias = string.Empty,
                    PassengerDisplayName = passenger.FullName,
                    PassengerBirthDate = passenger.BirthDate,
                    PassengerAge = passenger.Age,
                    PassengerGender = passenger.Gender,
                    PassengerPassengerProfileId = tripPassenger?.PassengerProfileId ?? -1,
                    PassengerProfilePassengerId = tripPassenger?.ProfilePassengerId ?? -1,
                    CrsKey = passenger.CrsKey
                };

                new PassengerCommon(HttpContext).CreateOrUpdate(passengerViewModel, false, true);
                passenger.PassengerId = passengerViewModel.PassengerId;

                var originalPassenger = crsModel.PassengerList.SingleOrDefault(t => t.PassengerId == -2 && t.OriginalPassengerNo == passenger.PassengerNo && t.AccompaniedInfant == passenger.AccompaniedInfant);

                if (originalPassenger != null)
                    originalPassenger.PassengerId = passenger.PassengerId;

                foreach (var passengerDocument in passenger.PassengerDocumentList.Where(t => t.CrsPassengerKey == passenger.CrsKey)) {
                    var passengerDocumentViewModel = new PassengerDocumentViewModel {
                        PassengerDocumentId = passengerDocument.PassengerDocumentId,
                        PassengerDocumentPassengerId = passenger.PassengerId,
                        PassengerDocumentType = passengerDocument.DocumentType,
                        PassengerDocumentNo = passengerDocument.DocumentNo,
                        PassengerDocumentIssueDate = passengerDocument.IssueDate,
                        PassengerDocumentExpiryDate = passengerDocument.ExpiryDate,
                        PassengerDocumentPlaceOfIssue = string.Empty,
                        PassengerDocumentIssuingCountryId = passengerDocument.IssuingCountryId,
                        PassengerDocumentNationalityId = passengerDocument.NationalityId,
                        PassengerDocumentComments = string.Empty
                    };

                    new PassengerDocumentCommon(HttpContext).CreateOrUpdate(passengerDocumentViewModel, true);
                    passengerDocument.PassengerDocumentId = passengerDocumentViewModel.PassengerDocumentId;
                }

                foreach (var passengerDocument in passenger.PassengerClubMembershipList.Where(t => t.CrsPassengerKey == passenger.CrsKey)) {
                    var passengerClubMembershipViewModel = new PassengerClubMembershipViewModel {
                        PassengerClubMembershipId = passengerDocument.PassengerClubMembershipId,
                        PassengerClubMembershipPassengerId = passenger.PassengerId,
                        PassengerClubMembershipClubMembershipId = passengerDocument.ClubMembershipId,
                        PassengerClubMembershipClubMembershipNo = passengerDocument.ClubMembershipNo,
                        PassengerClubMembershipAirlineId = passengerDocument.AirlineId
                    };

                    new PassengerClubMembershipCommon(HttpContext).CreateOrUpdate(passengerClubMembershipViewModel);
                    passengerDocument.PassengerClubMembershipId = passengerClubMembershipViewModel.PassengerClubMembershipId;
                }
            }
        }

        private void CrsMapDataAir(AppMainContext context, CrsImportModel model, CrsModel crsModel, int crsRefId = 0) {
            decimal taxRate = 0;

            if (crsModel.TripLineAirList.SelectMany(t => t.TripLineAirSegmentList).Any(t => t.AirportType == AirportType.Domestic))
                taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), crsModel.CrsPnrDate);

            var tripLineIdList = new List<int>();

            foreach (var tripLineAir in crsModel.TripLineAirList.Where(t => crsRefId == 0 || t.CrsRefId == crsRefId)) {
                int tripLineId = tripLineAir.TripLineId;

                if (context.TripLineAir.AsNoTracking().Any(t => t.TripLineId == tripLineId && t.CrsPnrRef.ToLower() != tripLineAir.CrsPnrRef.ToStringExt().ToLower()))
                    tripLineId = 0;

                var tripLineAirViewModel = new TripLineAirViewModel {
                    TripLineId = tripLineId,
                    AirlineId = tripLineAir.AirlineId,
                    ValidUntilDate = tripLineAir.ValidUntilDate,
                    TripLineAirCrs = crsModel.Crs,
                    TripLineAirCrsPnrRef = tripLineAir.CrsPnrRef,
                    ReferenceNo = string.Empty,
                    ConditionId = -1,
                    ServiceDescription = string.Empty,
                    TripLineViewModel = new TripLineViewModel {
                        TripLineId = tripLineId,
                        TripId = crsModel.ClientDetail.TripId,
                        TripLineType = TripLineType.Air,
                        TripLineStatus = TripLineStatus.Entry,
                        PrintOnQuote = true,
                        PrintOnConfirmation = true,
                        PrintOnItinerary = true,
                        PrintOnStatement = true
                    }
                };

                new TripLineAirCommon(HttpContext).CreateOrUpdate(tripLineAirViewModel);
                tripLineId = tripLineAirViewModel.TripLineId;

                if (!tripLineIdList.Contains(tripLineId))
                    tripLineIdList.Add(tripLineId);

                var tripLineAirPassengerList = new List<TripLineAirPassengerViewModel>();

                int tripLineAirSegmentId = -1;
                int tripLineAirPassengerId = 0;

                foreach (var tripLineAirSegment in tripLineAir.TripLineAirSegmentList) {
                    if (tripLineAirSegment.DepartureCityCode != "???" && tripLineAirSegment.ArrivalCityCode != "???") {
                        var tripLineAirSegmentViewModel = new TripLineAirSegmentViewModel {
                            TripLineAirSegmentId = tripLineAirSegment.TripLineAirSegmentId,
                            TripLineId = tripLineId,
                            TripStatus = tripLineAirSegment.TripStatus,
                            DepartureCityId = tripLineAirSegment.DepartureCityId,
                            ArrivalCityId = tripLineAirSegment.ArrivalCityId,
                            Class = tripLineAirSegment.Class,
                            FlightNo = tripLineAirSegment.FlightNo,
                            CheckInTime = crsModel.Crs == Crs.Amadeus ? string.Empty : tripLineAirSegment.CheckInTime,
                            TripLineAirSegmentDepartureDate = tripLineAirSegment.DepartureDate,
                            DepartureTime = tripLineAirSegment.DepartureTime,
                            ArrivalTime = tripLineAirSegment.ArrivalTime,
                            FlightTime = tripLineAirSegment.FlightTime,
                            InternationalDateOffset = tripLineAirSegment.InternationalDateOffset,
                            AirportType = tripLineAirSegment.AirportType,
                            DepartureTerminal = tripLineAirSegment.DepartureTerminal,
                            ArrivalTerminal = tripLineAirSegment.ArrivalTerminal,
                            TripLineAirSegmentAirlinePnr = tripLineAirSegment.AirlinePnr,
                            AircraftId = tripLineAirSegment.AircraftId,
                            Operator = tripLineAirSegment.Operator,
                            TransitStops = tripLineAirSegment.TransitStops,
                            DistanceFlownKm = tripLineAirSegment.DistanceFlownKm,
                            CO2Emissions = tripLineAirSegment.CO2Emissions,
                            Meals = tripLineAirSegment.Meals.Left(100),
                            SeqNo = tripLineAirSegment.SeqNo,
                            CrsKey = tripLineAirSegment.CrsKey
                        };

                        new TripLineAirSegmentCommon(HttpContext).CreateOrUpdate(tripLineAirSegmentViewModel, false);
                        tripLineAirSegment.TripLineAirSegmentId = tripLineAirSegmentViewModel.TripLineAirSegmentId;
                        tripLineAirSegmentId = tripLineAirSegmentViewModel.TripLineAirSegmentId;
                    }

                    var q = context.TripLineAirSegment.Include(t => t.DepartureCity).ThenInclude(t => t.Country).Include(t => t.ArrivalCity).ThenInclude(t => t.Country).Single(t => t.Id == tripLineAirSegmentId);

                    var arrivalCity = q.ArrivalCity ?? context.City.Include(t => t.Country).Single(t => t.Id == q.ArrivalCityId);
                    var departureCity = q.DepartureCity ?? context.City.Include(t => t.Country).Single(t => t.Id == q.DepartureCityId);

                    string crsAirSegmentKey = q.CrsKey.Length == 0 ? tripLineAirSegment.CrsKey : q.CrsKey;

                    foreach (var tripLineAirPassenger in tripLineAir.TripLineAirPassengerList.Where(t1 => t1.TripLineAirPassengerAirSegmentList.Any(t2 => t2.CrsAirSegmentKey == crsAirSegmentKey)).OrderBy(t => t.CrsPassengerKey).ToList()) {
                        var tripLineAirPassengerViewModel = new TripLineAirPassengerViewModel {
                            TripLineAirPassengerId = tripLineAirPassenger.TripLineAirPassengerId,
                            TripLineId = tripLineId,
                            CreditorId = tripLineAirPassenger.CreditorId,
                            SupplierId = tripLineAirPassenger.SupplierId,
                            IssueDate = tripLineAirPassenger.IssueDate,
                            PassengerId = tripLineAirPassenger.PassengerId,
                            TripLineAirPassengerAirlineId = tripLineAirPassenger.AirlineId,
                            FormOfPaymentId = tripLineAirPassenger.FormOfPaymentId,
                            SaleTypeId = tripLineAirPassenger.SaleTypeId,
                            DiscountReasonId = -1,
                            OverrideBasis = OverrideBasis.None,
                            MarkupStrategyId = -1,
                            BspEntryType = tripLineAirPassenger.BspEntryType,
                            TicketNo = tripLineAirPassenger.TicketNo,
                            OriginalTicketNo = tripLineAirPassenger.OriginalTicketNo,
                            ConnectingTicketNos = tripLineAirPassenger.ConnectingTicketNos,
                            OfferedReasonId = -1,
                            Comments = string.Empty
                        };

                        var tripLineAirPassengerAirSegment = tripLineAirPassenger.TripLineAirPassengerAirSegmentList.SingleOrDefault(t => t.CrsAirSegmentKey == crsAirSegmentKey && t.CrsPassengerKey == tripLineAirPassenger.CrsPassengerKey);

                        if (tripLineAirPassengerAirSegment == null)
                            continue;

                        if (tripLineAirPassenger.TripLineAirPassengerId == 0 || model.CrsImportOption != CrsImportOption.DoNotUpdatePricing) {
                            if (crsModel.Crs == Crs.Amadeus) {
                                tripLineAirPassengerViewModel.TicketMethod = tripLineAirPassenger.TicketMethod;
                                tripLineAirPassengerViewModel.TicketedFare = tripLineAirPassenger.TicketedFare;
                                tripLineAirPassengerViewModel.FullFare = tripLineAirPassenger.TicketedFare;
                                tripLineAirPassengerViewModel.Commission = tripLineAirPassenger.Commission * Math.Round(1 + taxRate, 2);
                                tripLineAirPassengerViewModel.NonCommissionable = tripLineAirPassenger.NonCommissionable;
                            }
                            else {
                                tripLineAirPassengerViewModel.TicketMethod = tripLineAirPassengerAirSegment.TicketMethod;
                                tripLineAirPassengerViewModel.TicketedFare = tripLineAirPassengerAirSegment.TicketedFare;
                                tripLineAirPassengerViewModel.FullFare = tripLineAirPassengerAirSegment.TicketedFare;
                                tripLineAirPassengerViewModel.Commission = tripLineAirPassengerAirSegment.Commission * Math.Round(1 + taxRate, 2);
                                tripLineAirPassengerViewModel.NonCommissionable = tripLineAirPassengerAirSegment.NonCommissionable;
                            }
                        }

                        tripLineAirPassengerId = 0;

                        if (tripLineAirPassenger.BspEntryType == BspEntryType.Exchange) {
                            tripLineAirPassengerId = tripLineAirPassengerList.SingleOrDefault(t => t.CreditorId == tripLineAirPassengerViewModel.CreditorId
                                && t.SupplierId == tripLineAirPassengerViewModel.SupplierId
                                && t.IssueDate == tripLineAirPassengerViewModel.IssueDate
                                && t.PassengerId == tripLineAirPassengerViewModel.PassengerId
                                && t.FormOfPaymentId == tripLineAirPassengerViewModel.FormOfPaymentId
                                && t.SaleTypeId == tripLineAirPassengerViewModel.SaleTypeId
                                && t.BspEntryType == tripLineAirPassengerViewModel.BspEntryType
                                && t.TicketNo == tripLineAirPassengerViewModel.TicketNo
                                && t.OriginalTicketNo == tripLineAirPassengerViewModel.OriginalTicketNo
                                && t.ConnectingTicketNos == tripLineAirPassengerViewModel.ConnectingTicketNos
                                && t.TicketMethod == tripLineAirPassengerViewModel.TicketMethod
                                && t.Comments == tripLineAirPassengerViewModel.Comments
                                && t.TicketedFare == tripLineAirPassengerViewModel.TicketedFare
                                && t.FullFare == tripLineAirPassengerViewModel.FullFare
                                && t.Commission == tripLineAirPassengerViewModel.Commission
                                && t.NonCommissionable == tripLineAirPassengerViewModel.NonCommissionable)?.TripLineAirPassengerId ?? 0;

                            if (tripLineAirPassengerId > 0 && !tripLineAirPassengerList.Any(t => t.TripLineAirPassengerId == tripLineAirPassengerId))
                                tripLineAirPassengerList.Add(tripLineAirPassengerViewModel);
                        }

                        if (tripLineAirPassengerId > 0) {
                            tripLineAirPassengerViewModel.TripLineAirPassengerId = tripLineAirPassengerId;
                        }
                        else {
                            new TripLineAirPassengerCommon(HttpContext).CreateOrUpdate(tripLineAirPassengerViewModel, model.CrsImportOption, departureCity.Country.CountryZone, true);
                            tripLineAirPassenger.TripLineAirPassengerId = tripLineAirPassengerViewModel.TripLineAirPassengerId;
                        }

                        int tripLineAirPassengerAirSegmentId = context.TripLineAirPassengerAirSegment.SingleOrDefault(t => t.TripLineAirPassengerId == tripLineAirPassengerViewModel.TripLineAirPassengerId && t.TripLineAirSegmentId == tripLineAirSegmentId)?.Id ?? 0;

                        var tripLineAirPassengerAirSegmentViewModel = new TripLineAirPassengerAirSegmentViewModel {
                            TripLineAirPassengerAirSegmentId = tripLineAirPassengerAirSegmentId,
                            TripLineAirPassengerId = tripLineAirPassengerViewModel.TripLineAirPassengerId,
                            TripLineAirSegmentId = tripLineAirSegmentId,
                            SeatNo = tripLineAirPassengerAirSegment.SeatNo?.Trim(),
                            SeatStatus = tripLineAirPassengerAirSegment.SeatStatus,
                            Class = tripLineAirSegment.Class,
                            BaggageAllowance = tripLineAirPassengerAirSegment.BaggageAllowance,
                            BaggageUnit = tripLineAirPassengerAirSegment.BaggageUnit,
                            FareBasis = tripLineAirPassengerAirSegment.FareBasis,
                            TicketDesignator = tripLineAirPassengerAirSegment.TicketDesignator,
                            TourCode = tripLineAirPassengerAirSegment.TourCode,
                            TripLineAirPassengerAirSegmentAmount = tripLineAirPassengerAirSegment.ExcludePassengerSegmentPricing ? 0 : tripLineAirPassengerAirSegment.Amount,
                            TripLineAirPassengerAirSegmentTax = tripLineAirPassengerAirSegment.ExcludePassengerSegmentPricing ? 0 : tripLineAirPassengerAirSegment.Tax
                        };

                        new TripLineAirPassengerAirSegmentCommon(HttpContext).CreateOrUpdate(tripLineAirPassengerAirSegmentViewModel);
                        tripLineAirSegment.IsProcessed = true;
                    }
                }

                foreach (var tripLineAirPassenger in tripLineAir.TripLineAirPassengerList.Where(t => t.TripLineAirPassengerAirSegmentList.Count == 0 || t.TripLineAirPassengerAirSegmentList.Any(t => t.IsEmd)).ToList()) {
                    var tripLineAirPassengerAirSegmentList = tripLineAirPassenger.TripLineAirPassengerAirSegmentList;
                    int passengerId = crsModel.PassengerList.SingleOrDefault(t => t.CrsKey == tripLineAirPassenger.CrsPassengerKey)?.PassengerId ?? -1;

                    bool isEmd = tripLineAirPassengerAirSegmentList.Any(t => t.IsEmd);

                    if (isEmd) {
                        tripLineAirPassengerId = context.TripLineAirPassenger.FirstOrDefault(t => t.TripLineId == tripLineId && t.PassengerId == passengerId && t.BspEntryType == BspEntryType.Emd)?.Id ?? 0;
                        tripLineAirPassengerAirSegmentList = tripLineAirPassengerAirSegmentList.Where(t => t.IsEmd).ToList();
                    }
                    else {
                        tripLineAirPassengerId = tripLineAirPassenger.TripLineAirPassengerId;
                    }

                    var tripLineAirPassengerViewModel = new TripLineAirPassengerViewModel {
                        TripLineAirPassengerId = tripLineAirPassengerId,
                        TripLineId = tripLineId,
                        CreditorId = tripLineAirPassenger.CreditorId,
                        SupplierId = tripLineAirPassenger.SupplierId,
                        IssueDate = tripLineAirPassenger.IssueDate,
                        PassengerId = passengerId,
                        TripLineAirPassengerAirlineId = tripLineAirPassenger.AirlineId,
                        FormOfPaymentId = tripLineAirPassenger.FormOfPaymentId,
                        SaleTypeId = tripLineAirPassenger.SaleTypeId,
                        DiscountReasonId = -1,
                        OverrideBasis = OverrideBasis.None,
                        MarkupStrategyId = -1,
                        BspEntryType = isEmd ? BspEntryType.Emd : tripLineAirPassenger.BspEntryType,
                        TicketNo = tripLineAirPassenger.TicketNo,
                        OriginalTicketNo = tripLineAirPassenger.OriginalTicketNo,
                        ConnectingTicketNos = tripLineAirPassenger.ConnectingTicketNos,
                        OfferedReasonId = -1,
                        Comments = string.Empty
                    };

                    if ((tripLineAirPassenger.TripLineAirPassengerId == 0 || model.CrsImportOption != CrsImportOption.DoNotUpdatePricing) && tripLineAirPassengerAirSegmentList.Count > 0) {
                        if (crsModel.Crs == Crs.Amadeus) {
                            tripLineAirPassengerViewModel.TicketedFare = tripLineAirPassengerAirSegmentList.Sum(t => t.TicketedFare);
                            tripLineAirPassengerViewModel.Comments = string.Concat(tripLineAirPassengerAirSegmentList.Select(t => t.Comments)).TrimEnd(Environment.NewLine.ToCharArray());
                        }
                        else {
                            tripLineAirPassengerViewModel.TicketedFare = tripLineAirPassengerAirSegmentList[0].TicketedFare;
                            tripLineAirPassengerViewModel.Comments = tripLineAirPassenger.Comments;
                        }

                        tripLineAirPassengerViewModel.FullFare = tripLineAirPassengerViewModel.TicketedFare;
                        tripLineAirPassengerViewModel.TicketMethod = tripLineAirPassengerAirSegmentList[0].TicketMethod;
                    }

                    bool result = new TripLineAirPassengerCommon(HttpContext).CreateOrUpdate(tripLineAirPassengerViewModel, model.CrsImportOption, null, true) != null;

                    if (result && isEmd && crsModel.Crs == Crs.Amadeus && tripLineAirPassengerAirSegmentList.Count > 0) {
                        tripLineAirPassengerId = tripLineAirPassengerViewModel.TripLineAirPassengerId;

                        foreach (string segmentNo in tripLineAirPassengerAirSegmentList[0].EmdSegmentNos) {
                            tripLineAirSegmentId = tripLineAir.TripLineAirSegmentList.SingleOrDefault(t => t.SegmentNo == segmentNo)?.TripLineAirSegmentId ?? 0;

                            if (tripLineAirSegmentId == 0)
                                continue;

                            int tripLineAirPassengerAirSegmentId = context.TripLineAirPassengerAirSegment.SingleOrDefault(t => t.TripLineAirPassengerId == tripLineAirPassengerId && t.TripLineAirSegmentId == tripLineAirSegmentId)?.Id ?? 0;

                            var tripLineAirPassengerAirSegmentViewModel = new TripLineAirPassengerAirSegmentViewModel {
                                TripLineAirPassengerAirSegmentId = tripLineAirPassengerAirSegmentId,
                                TripLineAirPassengerId = tripLineAirPassengerId,
                                TripLineAirSegmentId = tripLineAirSegmentId,
                                SeatNo = string.Empty,
                                SeatStatus = SeatStatus.NotSpecified,
                                Class = string.Empty,
                                BaggageAllowance = 0,
                                BaggageUnit = BaggageUnit.Piece,
                                FareBasis = string.Empty,
                                TicketDesignator = string.Empty,
                                TourCode = string.Empty,
                                TripLineAirPassengerAirSegmentAmount = 0,
                                TripLineAirPassengerAirSegmentTax = 0
                            };

                            new TripLineAirPassengerAirSegmentCommon(HttpContext).CreateOrUpdate(tripLineAirPassengerAirSegmentViewModel);
                        }
                    }
                }
            }

            foreach (int tripLineId in tripLineIdList) {
                foreach (var tripLineAirPassenger in context.TripLineAirPassenger.Where(t => t.TripLineAir.TripLineId == tripLineId)) {
                    TripLineAirPassengerAirSegment.UpdateGroupNo(context, tripLineId, tripLineAirPassenger.Id);
                }
            }
        }

        private void CrsMapDataLand(AppMainContext context, CrsImportModel model, CrsModel crsModel, int crsRefId = 0) {
            foreach (var tripLineLand in crsModel.TripLineLandList.Where(t => crsRefId == 0 || t.CrsRefId == crsRefId)) {
                if (!model.CrsUpdateExistingLandTripLines && tripLineLand.TripLineId > 0)
                    continue;

                var tripLineLandViewModel = new TripLineLandViewModel {
                    TripLineId = tripLineLand.TripLineId,
                    TripStatus = tripLineLand.TripStatus,
                    CreditorId = tripLineLand.CreditorId,
                    SupplierId = tripLineLand.SupplierId == -1 ? model.CrsSupplierLandId : tripLineLand.SupplierId,
                    SupplierChainId = tripLineLand.SupplierChainId,
                    TripLineLandCrs = crsModel.Crs,
                    TripLineLandCrsPnrRef = crsModel.CrsPnrRef.ToStringExt(),
                    SupplierCityCode = tripLineLand.SupplierCityCode,
                    SupplierCrsCode = tripLineLand.SupplierCrsCode,
                    BookingPnr = string.Empty,
                    ConfirmationNo = tripLineLand.ConfirmationNo,
                    DocumentNo = string.Empty,
                    SupplierName = tripLineLand.SupplierName,
                    SupplierAddress1 = tripLineLand.SupplierAddress1,
                    SupplierAddress2 = tripLineLand.SupplierAddress2,
                    SupplierLocality = tripLineLand.SupplierLocality,
                    SupplierRegion = tripLineLand.SupplierRegion,
                    SupplierPostCode = tripLineLand.SupplierPostCode,
                    SupplierCountryCode = tripLineLand.SupplierCountryCode,
                    SupplierContactTitle = string.Empty,
                    SupplierContactName = string.Empty,
                    SupplierContactPhoneHome = string.Empty,
                    SupplierContactPhoneWork = tripLineLand.SupplierContactPhoneWork,
                    SupplierContactMobile = string.Empty,
                    SupplierContactFax = string.Empty,
                    SupplierContactEmail = string.Empty,
                    StartDate = tripLineLand.StartDate,
                    StartTime = tripLineLand.StartTime,
                    StartDetails = tripLineLand.StartDetails,
                    StartAddress1 = tripLineLand.StartAddress1,
                    StartAddress2 = tripLineLand.StartAddress2,
                    StartLocality = tripLineLand.StartLocality,
                    StartRegion = tripLineLand.StartRegion,
                    StartPostCode = tripLineLand.StartPostCode,
                    StartCountryCode = tripLineLand.StartCountryCode,
                    EndDate = tripLineLand.EndDate,
                    EndTime = tripLineLand.EndTime,
                    EndDetails = tripLineLand.EndDetails,
                    EndAddress1 = tripLineLand.EndAddress1,
                    EndAddress2 = tripLineLand.EndAddress2,
                    EndLocality = tripLineLand.EndLocality,
                    EndRegion = tripLineLand.EndRegion,
                    EndPostCode = tripLineLand.EndPostCode,
                    EndCountryCode = tripLineLand.EndCountryCode,
                    ServiceTypeRateBasisId = (int)tripLineLand.ServiceTypeRateBasis,
                    PassengerClassification = tripLineLand.PassengerClassification,
                    DurationCoverageType = tripLineLand.DurationCoverageType,
                    Duration = tripLineLand.Duration,
                    PayForDuration = tripLineLand.PayForDuration,
                    PaxAdultNo = tripLineLand.PaxAdultNo,
                    PaxAdultRate = tripLineLand.PaxAdultRate,
                    PaxAdultQty = tripLineLand.PaxAdultQty,
                    PaxChildNo = tripLineLand.PaxChildNo,
                    PaxChildRate = tripLineLand.PaxChildRate,
                    PaxChildQty = tripLineLand.PaxChildQty,
                    PaxInfantNo = tripLineLand.PaxInfantNo,
                    PaxInfantRate = tripLineLand.PaxInfantRate,
                    PaxInfantQty = tripLineLand.PaxInfantQty,
                    ServiceDescription = string.Empty,
                    SupplierServiceId = context.SupplierService.SingleOrDefault(t => t.Name.ToLower() == tripLineLand.SupplierServiceDescription.ToLower())?.Id ?? -1,
                    SupplierServiceRateDetailId = context.SupplierServiceRateDetail.SingleOrDefault(t => t.Name.ToLower() == tripLineLand.SupplierServiceDescription.ToLower())?.Id ?? -1,
                    SupplierServiceDescription = tripLineLand.SupplierServiceDescription,
                    CurrencyId = tripLineLand.CurrencyId,
                    ForeignAmount = tripLineLand.ForeignAmount,
                    ExchangeRate = tripLineLand.ExhangeRate,
                    FormOfPaymentId = tripLineLand.FormOfPaymentId,
                    PaymentDueDate = DateTime.MinValue,
                    SaleTypeId = tripLineLand.SaleTypeId,
                    Discount = 0,
                    DiscountReasonId = -1,
                    Commission = tripLineLand.Commission,
                    RemainderCommission = 0,
                    NonCommissionable = tripLineLand.NonCommissionable,
                    Markup = 0,
                    MarkupStrategyId = -1,
                    OfferedFare = 0,
                    OfferedReasonId = -1,
                    Inclusions = Utils.HtmlEncodeExceptTags(tripLineLand.Inclusions.Replace(Environment.NewLine, AppConstants.HtmlLineBreak)),
                    Comments = tripLineLand.Comments,
                    TripLineViewModel = new TripLineViewModel {
                        TripLineId = tripLineLand.TripLineId,
                        TripId = crsModel.ClientDetail.TripId,
                        TripLineType = tripLineLand.TripLineType,
                        TripLineStatus = TripLineStatus.Entry,
                        PersonalTravelAmount = 0,
                        PrintOnQuote = true,
                        PrintOnConfirmation = true,
                        PrintOnItinerary = true,
                        PrintOnStatement = true
                    }
                };

                tripLineLandViewModel.SupplierServiceRateDetailDescription = tripLineLandViewModel.SupplierServiceDescription;
                new TripLineLandCommon(HttpContext).CreateOrUpdate(tripLineLandViewModel, model.CrsImportOption, tripLineLandViewModel.Commission == 0);
            }
        }

        private void CrsMapDataServiceFee(CrsImportModel model, CrsModel crsModel) {
            foreach (var tripLineServiceFee in crsModel.TripLineServiceFeeList) {
                var tripLineServiceFeeViewModel = new TripLineServiceFeeViewModel {
                    TripLineId = 0,
                    ServiceFeePaymentType = ServiceFeePaymentType.Supplier,
                    ServiceFeeTypeId = tripLineServiceFee.ServiceFeeTypeId,
                    TripLineServiceFeeCrs = crsModel.Crs,
                    TripLineServiceFeeCrsPnrRef = crsModel.CrsPnrRef,
                    DocumentNo = crsModel.CrsPnrRef,
                    Description = tripLineServiceFee.Description,
                    CreditorId = model.CrsCreditorAirId,
                    SupplierId = model.CrsSupplierAirId,
                    PassengerType = PassengerType.NotSpecified,
                    PaxNo = tripLineServiceFee.PaxNo,
                    FormOfPaymentId = tripLineServiceFee.FormOfPaymentId,
                    SaleTypeId = tripLineServiceFee.SaleTypeId,
                    ItemCost = tripLineServiceFee.ItemCost,
                    MarkupStrategyId = -1,
                    OfferedReasonId = -1,
                    TripLineViewModel = new TripLineViewModel {
                        TripLineId = 0,
                        TripId = crsModel.ClientDetail.TripId,
                        TripLineType = TripLineType.ServiceFee,
                        TripLineStatus = TripLineStatus.Entry,
                        PersonalTravelAmount = 0,
                        PrintOnQuote = true,
                        PrintOnConfirmation = true,
                        PrintOnItinerary = false,
                        PrintOnStatement = true
                    }
                };

                new TripLineServiceFeeCommon(HttpContext).CreateOrUpdate(tripLineServiceFeeViewModel);
            }
        }

        private void CrsMapDataRemark(AppMainContext context, CrsModel crsModel) {
            var tripLineAirSegmentList = crsModel.TripLineAirList.SelectMany(t => t.TripLineAirSegmentList).ToList();

            foreach (var row in crsModel.TripLineRemarkList) {
                row.TripLineId = -1;
                row.TripLineAirSegmentId = tripLineAirSegmentList.FirstOrDefault(t => t.CrsKey == row.CrsAirSegmentKey)?.TripLineAirSegmentId ?? -1;
                row.PassengerId = crsModel.PassengerList.FirstOrDefault(t => t.CrsKey == row.CrsPassengerKey)?.PassengerId ?? -1;
            }

            foreach (var tripLineRemark in crsModel.TripLineRemarkList) {
                int tripLineId = -1;
                int tripLineAirSegmentId = tripLineRemark.TripLineAirSegmentId;

                if (tripLineAirSegmentId > 0)
                    tripLineId = context.TripLineAirSegment.Find(tripLineAirSegmentId)?.TripLineId ?? -1;

                string relatedTripLineSegmentId = tripLineRemark.TripLineAirSegmentId <= 0 ? string.Format("1.{0}", tripLineId) : string.Format("2.{0}.{1}", tripLineId, tripLineRemark.TripLineAirSegmentId);

                var tripLineRemarkViewModel = new TripLineRemarkViewModel {
                    TripLineId = 0,
                    TripLineRemarkCrs = crsModel.Crs,
                    TripLineRemarkCrsPnrRef = crsModel.CrsPnrRef,
                    StartDate = tripLineRemark.StartDate == DateTime.MinValue ? null : tripLineRemark.StartDate,
                    EndDate = tripLineRemark.EndDate == DateTime.MinValue ? null : tripLineRemark.EndDate,
                    Time = string.Empty,
                    RelatedTripLineSegmentId = relatedTripLineSegmentId,
                    PassengerId = tripLineRemark.PassengerId,
                    StandardCommentType = StandardCommentType.Comment,
                    StandardCommentId = null,
                    Description = tripLineRemark.Description.Left(100),
                    Remark = Utils.HtmlEncodeExceptTags(tripLineRemark.Remark),
                    PrintAfterTotals = false,
                    TripLineViewModel = new TripLineViewModel {
                        TripLineId = 0,
                        TripId = crsModel.ClientDetail.TripId,
                        TripLineType = TripLineType.Remark,
                        TripLineStatus = TripLineStatus.Entry,
                        PersonalTravelAmount = 0,
                        PrintOnQuote = true,
                        PrintOnConfirmation = true,
                        PrintOnItinerary = true,
                        PrintOnStatement = true
                    }
                };

                new TripLineRemarkCommon(HttpContext).CreateOrUpdate(tripLineRemarkViewModel);
            }
        }

        private void CrsMergeAirTripLines(AppMainContext context, TripLineAir tripLineAirExisting, TripLineAir tripLineAirNew) {
            var tripLineNew = tripLineAirNew.TripLine;
            var tripLineExisting = tripLineAirExisting.TripLine;

            tripLineNew.TripLineStatus = tripLineExisting.TripLineStatus;

            tripLineNew.AmountReceived = tripLineExisting.AmountReceived;
            tripLineNew.AmountPaid = tripLineExisting.AmountPaid;
            tripLineNew.AmountInvoiced = tripLineExisting.AmountInvoiced;
            tripLineNew.PersonalTravelAmount = tripLineExisting.PersonalTravelAmount;

            tripLineNew.ReceiptInfo = tripLineExisting.ReceiptInfo;
            tripLineNew.PaymentInfo = tripLineExisting.PaymentInfo;
            tripLineNew.InvoiceInfo = tripLineExisting.InvoiceInfo;

            tripLineNew.PackageNo = tripLineExisting.PackageNo;

            tripLineNew.PrintOnQuote = tripLineExisting.PrintOnQuote;
            tripLineNew.PrintOnConfirmation = tripLineExisting.PrintOnConfirmation;
            tripLineNew.PrintOnItinerary = tripLineExisting.PrintOnItinerary;
            tripLineNew.PrintOnStatement = tripLineExisting.PrintOnStatement;

            context.Save(tripLineNew, false);

            tripLineAirNew.ReferenceNo = tripLineAirExisting.ReferenceNo;
            tripLineAirNew.ConditionId = tripLineAirExisting.ConditionId;
            tripLineAirNew.ServiceDescription = tripLineAirExisting.ServiceDescription;

            context.Save(tripLineAirNew, false);

            bool reorderAirSegments = false;

            foreach (var tripLineAirSegmentNew in tripLineAirNew.TripLineAirSegments) {
                var tripLineAirSegmentExisting = context.TripLineAirSegment.FirstOrDefault(t => t.DepartureDate == tripLineAirSegmentNew.DepartureDate && t.DepartureCityId == tripLineAirSegmentNew.DepartureCityId && t.ArrivalCityId == tripLineAirSegmentNew.ArrivalCityId);

                if (tripLineAirSegmentExisting == null) {
                    reorderAirSegments = true;
                    continue;
                }

                tripLineAirSegmentNew.SeqNo = tripLineAirSegmentExisting.SeqNo;
                context.Save(tripLineAirSegmentNew, false);

                foreach (var tripLineAirPassengerNew in tripLineAirNew.TripLineAirPassengers) {
                    var tripLineAirPassengerExisting = context.TripLineAirPassenger.FirstOrDefault(t1 => t1.TripLineAirPassengerAirSegments.Any(t2 => t2.TripLineAirSegmentId == tripLineAirSegmentNew.Id && t2.TripLineAirPassenger.PassengerId == tripLineAirPassengerNew.PassengerId));

                    if (tripLineAirPassengerExisting == null)
                        continue;

                    tripLineAirPassengerNew.FormOfPaymentId = tripLineAirPassengerExisting.FormOfPaymentId;
                    tripLineAirPassengerNew.PersonalTravelAmount = tripLineAirPassengerExisting.PersonalTravelAmount;
                    tripLineAirPassengerNew.RemainderCommission = tripLineAirPassengerExisting.RemainderCommission;

                    tripLineAirPassengerNew.Discount = tripLineAirPassengerExisting.Discount;
                    tripLineAirPassengerNew.DiscountReasonId = tripLineAirPassengerExisting.DiscountReasonId;
                    tripLineAirPassengerNew.OverrideAmount = tripLineAirPassengerExisting.OverrideAmount;
                    tripLineAirPassengerNew.OverrideBasis = tripLineAirPassengerExisting.OverrideBasis;

                    tripLineAirPassengerNew.Markup = tripLineAirPassengerExisting.Markup;
                    tripLineAirPassengerNew.MarkupTax = tripLineAirPassengerExisting.MarkupTax;
                    tripLineAirPassengerNew.MarkupStrategyId = tripLineAirPassengerExisting.MarkupStrategyId;

                    if (tripLineAirPassengerNew.TicketNo.Length == 0)
                        tripLineAirPassengerNew.TicketNo = tripLineAirPassengerExisting.TicketNo;

                    tripLineAirPassengerNew.OriginalTicketNo = tripLineAirPassengerExisting.OriginalTicketNo;

                    tripLineAirPassengerNew.BspEntryType = tripLineAirPassengerExisting.BspEntryType;
                    tripLineAirPassengerNew.TicketMethod = tripLineAirPassengerExisting.TicketMethod;

                    tripLineAirPassengerNew.OfferedFare = tripLineAirPassengerExisting.OfferedFare;
                    tripLineAirPassengerNew.OfferedReasonId = tripLineAirPassengerExisting.OfferedReasonId;

                    tripLineAirPassengerNew.IsCreditCardDiscountApplicable = tripLineAirPassengerExisting.IsCreditCardDiscountApplicable;
                    tripLineAirPassengerNew.IncludeMarkupInCreditCardPayment = tripLineAirPassengerExisting.IncludeMarkupInCreditCardPayment;

                    context.Save(tripLineAirPassengerNew, false);

                    foreach (var row in context.ReceiptDetail.Include(t => t.Receipt).Where(t => t.Receipt.TripId == tripLineAirExisting.TripLine.TripId && (t.TripLineId == tripLineAirExisting.TripLineId || t.TripLineAirPassengerId == tripLineAirPassengerExisting.Id)).ToList()) {
                        if (row.TripLineId == tripLineAirExisting.TripLineId)
                            row.TripLineId = tripLineAirNew.TripLineId;

                        if (row.TripLineAirPassengerId == tripLineAirPassengerExisting.TripLineId)
                            row.TripLineAirPassengerId = tripLineAirPassengerNew.Id;

                        context.Save(row, false);
                    }

                    foreach (var row in context.BspDetail.Include(t => t.Bsp).Where(t => t.Bsp.TripId == tripLineAirExisting.TripLine.TripId && (t.Bsp.TripLineId == tripLineAirExisting.TripLineId || t.TripLineAirPassengerId == tripLineAirPassengerExisting.Id)).ToList()) {
                        if (row.Bsp.TripLineId == tripLineAirExisting.TripLineId)
                            row.Bsp.TripLineId = tripLineAirNew.TripLineId;

                        context.Save(row.Bsp, false);

                        if (row.TripLineAirPassengerId == tripLineAirPassengerExisting.TripLineId)
                            row.TripLineAirPassengerId = tripLineAirPassengerNew.Id;

                        context.Save(row, false);
                    }

                    foreach (var row in context.NonBspDetail.Include(t => t.NonBsp).Where(t => t.NonBsp.TripId == tripLineAirExisting.TripLine.TripId && (t.NonBsp.TripLineId == tripLineAirExisting.TripLineId || t.TripLineAirPassengerId == tripLineAirPassengerExisting.Id)).ToList()) {
                        if (row.NonBsp.TripLineId == tripLineAirExisting.TripLineId)
                            row.NonBsp.TripLineId = tripLineAirNew.TripLineId;

                        context.Save(row.NonBsp, false);

                        if (row.TripLineAirPassengerId == tripLineAirPassengerExisting.TripLineId)
                            row.TripLineAirPassengerId = tripLineAirPassengerNew.Id;

                        context.Save(row, false);
                    }

                    foreach (var row in context.PaymentDetail.Include(t => t.Payment).Where(t => t.Payment.TripId == tripLineAirExisting.TripLine.TripId && (t.TripLineId == tripLineAirExisting.TripLineId || t.TripLineAirPassengerId == tripLineAirPassengerExisting.Id)).ToList()) {
                        if (row.TripLineId == tripLineAirExisting.TripLineId)
                            row.TripLineId = tripLineAirNew.TripLineId;

                        if (row.TripLineAirPassengerId == tripLineAirPassengerExisting.TripLineId)
                            row.TripLineAirPassengerId = tripLineAirPassengerNew.Id;

                        context.Save(row, false);
                    }

                    foreach (var row in context.InvoiceDetail.Include(t => t.Invoice).Where(t => t.TripId == tripLineAirExisting.TripLine.TripId && (t.TripLineId == tripLineAirExisting.TripLineId || t.TripLineAirPassengerId == tripLineAirPassengerExisting.Id)).ToList()) {
                        if (row.TripLineId == tripLineAirExisting.TripLineId)
                            row.TripLineId = tripLineAirNew.TripLineId;

                        if (row.TripLineAirPassengerId == tripLineAirPassengerExisting.TripLineId)
                            row.TripLineAirPassengerId = tripLineAirPassengerNew.Id;

                        context.Save(row, false);
                    }

                    foreach (var row in context.Adjustment.Where(t => t.DebitTripId == tripLineAirExisting.TripLine.TripId && t.DebitTripLineId == tripLineAirExisting.TripLineId).ToList()) {
                        if (row.DebitTripLineId == tripLineAirExisting.TripLineId)
                            row.DebitTripLineId = tripLineAirNew.TripLineId;

                        context.Save(row, false);
                    }

                    foreach (var row in context.Adjustment.Where(t => t.CreditTripId == tripLineAirExisting.TripLine.TripId && t.CreditTripLineId == tripLineAirExisting.TripLineId).ToList()) {
                        if (row.CreditTripLineId == tripLineAirExisting.TripLineId)
                            row.CreditTripLineId = tripLineAirNew.TripLineId;

                        context.Save(row, false);
                    }
                }
            }

            if (reorderAirSegments) {
                int seqNo = -1;

                foreach (var tripLineAirSegmentNew in tripLineAirNew.TripLineAirSegments.OrderBy(t => t.DepartureDate).ThenBy(t => t.DepartureTime)) {
                    seqNo++;

                    if (tripLineAirSegmentNew.SeqNo != seqNo) {
                        tripLineAirSegmentNew.SeqNo = seqNo;
                        context.Save(tripLineAirSegmentNew, false);
                    }
                }
            }

            int[] tripLineAirSegmentIds = tripLineAirExisting.TripLineAirSegments.Select(t => t.Id).ToArray();

            foreach (var row in context.TripLineAirSegment.Include(t => t.TripItineraryDetails).Where(t => tripLineAirSegmentIds.Contains(t.Id) && t.TripItineraryDetails.Count == 0).ToList()) {
                context.Delete(row, false);
            }

            context.Delete(tripLineAirExisting.TripLine, false);
        }

        public bool CreateBooking(AppMainContext context, int tripId, int quoteNo) {
            using (var ts = Utils.CreateTransactionScope()) {
                var trip = context.Trip.Find(tripId);
                trip.IsBooking = true;
                context.Save(trip);

                if (quoteNo == -1) {
                    int seqNo = 0;

                    foreach (var row in context.TripLine.Where(t => t.TripId == tripId).ToList()) {
                        var q = new TripLineSelection {
                            Id = 0,
                            TripLineId = row.Id,
                            QuoteNo = 0,
                            SeqNo = seqNo
                        };

                        context.Insert(q, false);
                        seqNo++;
                    }
                }
                else if (quoteNo != 0) {
                    foreach (var row in context.TripLineSelection.Where(t => t.TripLine.TripId == tripId && t.QuoteNo == quoteNo).OrderBy(t => t.SeqNo).ToList()) {
                        var q = context.TripLineSelection.Find(row.Id).Clone() as TripLineSelection;
                        q.Id = 0;
                        q.QuoteNo = 0;
                        context.Insert(q, false);
                    }
                }

                ts.Complete();
                return true;
            }
        }

        public bool CreateOrUpdate(AppMainContext context, TripViewModel model, bool createPassengerFromClientDetails, bool updateNotNullDepartureDate = true, bool isCrsImport = false) {
            using (var ts = Utils.CreateTransactionScope()) {
                if (model.ProfileId == 0) {
                    var profile = new Profile {
                        Id = 0,
                        Code = Profile.GetNewCode(context, model.LastName),
                        Title = model.Title.ToStringExt(),
                        FirstName = model.FirstName,
                        LastName = model.LastName,
                        PhoneHome = model.PhoneHome.ToStringExt(),
                        PhoneWork = model.PhoneWork.ToStringExt(),
                        Mobile = model.Mobile.ToStringExt(),
                        Fax = model.Fax.ToStringExt(),
                        Email = model.Email.ToStringExt(),
                        MaritalStatus = model.MaritalStatus,
                        BirthDate = DateTime.MinValue,
                        BirthCountryId = -1,
                        NationalityId = -1,
                        Occupation = model.Occupation.ToStringExt(),
                        BusinessType = model.BusinessType.ToStringExt(),
                        DebtorId = model.DebtorId ?? 0,
                        AgencyId = model.AgencyId ?? 0,
                        ConsultantId = model.ConsultantId ?? 0,
                        Rules = string.Empty,
                        Remarks = string.Empty
                    };

                    if (profile.Id <= 0) {
                        context.Insert(profile);
                    }
                    else {
                        context.Save(profile);
                    }

                    model.ProfileId = profile.Id;
                }

                Trip q = null;
                bool isNew = false;

                if (model.TripId <= 0) {
                    isNew = true;

                    q = new Trip {
                        Id = 0,
                        TripNo = LastDocumentNo.DocumentNo(context, "Trip"),
                        DepartureDate = DateTime.Today,
                        AgencyId = model.AgencyId ?? 0,
                        ConsultantId = model.ConsultantId ?? 0
                    };

                    LastDocumentNo.DocumentNo(context, "Trip", q.TripNo);
                }
                else {
                    q = context.Trip.Include(t => t.TripLines).ThenInclude(t => t.TripLineSelections).Include(t => t.TripPassengers).Include(t => t.TripLines).ThenInclude(t => t.TripLineLand).ThenInclude(t => t.ServiceTypeRateBasis).Include(t => t.Receipts).Single(t => t.Id == model.TripId);

                    if (!model.IsBooking)
                        model.IsBooking = q.TripLines.Any(t => t.IsBooking);

                    if (HttpContext.IsAdministrator() && q.ConsultantId != model.ConsultantId && q.Receipts.Count > 0)
                        throw new UnreportedException("Consultant cannot be changed because one or more receipts have been raised on this Trip.");
                }

                q.Code = Utils.RemoveExtraSpaces(model.Code.ToStringExt()).Replace(" ", string.Empty).ToUpper();

                if (q.Code.Length > 0 && context.Trip.Any(t => t.Id != q.Id && t.Code.ToLower() == q.Code.ToLower()))
                    throw new UnreportedException("Client Code already exists.");

                if (!context.ContactTitle.Any(t => t.Name == model.Title))
                    model.Title = string.Empty;

                string rules = model.Rules.ToStringExt();

                if (rules.Contains("Profile Rules & Regulations:"))
                    rules = rules.Left(rules.IndexOf("Profile Rules & Regulations:"));

                if (rules.Contains("Debtor Rules & Regulations:"))
                    rules = rules.Left(rules.IndexOf("Debtor Rules & Regulations:"));

                string remarks = model.Remarks.ToStringExt();

                if (remarks.Contains("Profile Remarks:"))
                    remarks = remarks.Left(remarks.IndexOf("Profile Remarks:"));

                if (remarks.Contains("Debtor Remarks:"))
                    remarks = remarks.Left(remarks.IndexOf("Debtor Remarks:"));

                rules = rules.TrimStart(Environment.NewLine).TrimEnd(Environment.NewLine);
                remarks = remarks.TrimStart(Environment.NewLine).TrimEnd(Environment.NewLine);

                if (HttpContext.IsAdministrator() || isNew) {
                    q.AgencyId = model.AgencyId ?? 0;
                    q.ConsultantId = model.ConsultantId ?? 0;
                }

                q.ProfileId = model.ProfileId;
                q.ClientAccountType = model.ClientAccountType;
                q.BookingType = model.BookingType;
                q.SerkoOnlineBookingStatus = model.SerkoOnlineBookingStatus;
                q.Title = model.Title.ToStringExt();
                q.FirstName = model.FirstName;
                q.LastName = model.LastName;
                q.PhoneHome = model.PhoneHome.ToStringExt();
                q.PhoneWork = model.PhoneWork.ToStringExt();
                q.Mobile = model.Mobile.ToStringExt();
                q.Fax = model.Fax.ToStringExt();
                q.Email = model.Email.ToStringExt();
                q.MaritalStatus = model.MaritalStatus;
                q.Occupation = model.Occupation.ToStringExt();
                q.BusinessType = model.BusinessType.ToStringExt();
                q.UserReferenceNo = model.UserReferenceNo.ToStringExt();
                q.AgentId = model.AgentId ?? 0;
                q.SourceId = model.SourceId ?? 0;
                q.CurrencyId = model.TripCurrencyId ?? 0;
                q.GroupId = model.GroupId ?? 0;
                q.ClassId = model.ClassId ?? 0;
                q.CategoryId = model.CategoryId ?? 0;
                q.DestinationId = model.DestinationId ?? 0;
                q.LocationId = model.LocationId ?? 0;
                q.MainCityId = model.MainCityId ?? 0;
                q.DebtorId = model.DebtorId ?? 0;
                q.DebtorBookedById = model.DebtorBookedById ?? 0;
                q.DebtorAuthorisedById = model.DebtorAuthorisedById ?? 0;
                q.DebtorOrderNo = model.DebtorOrderNo.ToStringExt();
                q.DebtorTravelReason = model.DebtorTravelReason.ToStringExt();
                q.DebtorVideoConferencingConsidered = model.DebtorVideoConferencingConsidered;
                q.DebtorVideoConferencingReasonRejected = model.DebtorVideoConferencingReasonRejected.ToStringExt();
                q.PaxAdult = model.PaxAdult;
                q.PaxChild = model.PaxChild;
                q.PaxInfant = model.PaxInfant;
                q.ReturnDate = model.TripReturnDate ?? DateTime.MinValue;
                q.BalanceDueDate = model.BalanceDueDate ?? DateTime.MinValue;
                q.ExchangeRate = model.TripExchangeRate;
                q.Rules = rules;
                q.Remarks = remarks;
                q.Notes = model.Notes.ToStringExt();
                q.ChecklistContactMethod = model.ChecklistContactMethod;
                q.ChecklistContactById = model.ChecklistContactById ?? 0;
                q.ChecklistFollowUpDate = model.ChecklistFollowUpDate ?? DateTime.MinValue;
                q.ChecklistComments = model.ChecklistComments.ToStringExt();
                q.CancellationContactMethod = model.CancellationContactMethod;
                q.CancellationById = model.CancellationById ?? 0;
                q.IsBooking = model.IsBooking;
                q.IsCancellation = model.IsCancellation;
                q.IsLocked = model.TripIsLocked;

                if (updateNotNullDepartureDate || q.DepartureDate == DateTime.MinValue)
                    q.DepartureDate = model.TripDepartureDate ?? DateTime.MinValue;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.TripId = q.Id;

                if (isNew) {
                    if (model.AddressViewModel != null && !isCrsImport) {
                        model.AddressViewModel.ParentId = model.TripId;
                        TripAddressCommon.CreateOrUpdate(context, model.AddressViewModel);
                    }

                    TripChecklistCommon.Create(context, model.TripId);

                    if (createPassengerFromClientDetails) {
                        var passenger = new Passenger {
                            Id = 0,
                            ProfileId = -1,
                            TripId = q.Id,
                            PassengerType = PassengerType.NotSpecified,
                            Title = q.Title,
                            FirstName = q.FirstName,
                            LastName = q.LastName,
                            Alias = string.Empty,
                            DisplayName = string.Empty,
                            PhoneNo = q.PhoneNo,
                            Email = q.Email,
                            BirthDate = DateTime.MinValue,
                            PassengerProfileId = q.ProfileId,
                            ProfilePassengerId = -1,
                            CrsKey = string.Empty,
                            Gender = ContactTitle.GetContactTitle(context, q.Title, false).Gender
                        };

                        context.Insert(passenger);
                    }

                    if (model.ProfileId > 0) {
                        foreach (var row in context.Passenger.Where(t => t.ProfileId == model.ProfileId)) {
                            var passenger = new Passenger {
                                Id = 0,
                                ProfileId = -1,
                                TripId = q.Id,
                                PassengerType = row.PassengerType,
                                Title = row.Title,
                                FirstName = row.FirstName,
                                LastName = row.LastName,
                                Alias = row.Alias,
                                DisplayName = row.DisplayName,
                                PhoneNo = row.PhoneNo,
                                Email = row.Email,
                                BirthDate = row.BirthDate,
                                Gender = row.Gender,
                                PassengerProfileId = -1,
                                ProfilePassengerId = row.Id,
                                CrsKey = string.Empty
                            };

                            passenger.Age = passenger.GetAge();

                            if (context.Passenger.Where(t => t.TripId == passenger.TripId).AsEnumerable().Any(t => t.IsDuplicate(passenger)))
                                continue;

                            context.Insert(passenger);
                        }
                    }
                }

                if (!isCrsImport)
                    q.UpdatePassengerCount(context);

                ts.Complete();
                return true;
            }
        }

        public bool Delete(AppLazyContext lazyContext, int tripId) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.Trip.Find(tripId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (q.ChecklistContactById > 0 || q.CancellationById > 0) {
                    q.ChecklistContactById = -1;
                    q.CancellationById = -1;
                    lazyContext.Save(q, false);
                    lazyContext.Entry(q).State = EntityState.Detached;
                }

                lazyContext.RemoveRange(lazyContext.PassengerDocument.Where(t => t.Passenger.TripId == tripId));
                lazyContext.SaveChanges();

                lazyContext.RemoveRange(lazyContext.PassengerClubMembership.Where(t => t.Passenger.TripId == tripId));
                lazyContext.SaveChanges();

                q = lazyContext.Trip.Include(t => t.TripAddresses).Include(t => t.TripChecklists)
                    .Include(t => t.TripPassengers)
                    .Include(t => t.TripIntineraries)
                    .Include(t => t.TripLines).ThenInclude(t => t.TripLineSelections)
                    .Include(t => t.TripLines).ThenInclude(t => t.TripLineAir).ThenInclude(t => t.TripLineAirSegments).ThenInclude(t => t.TripLineAirPassengerAirSegments)
                    .Include(t => t.TripLines).ThenInclude(t => t.TripLineAir).ThenInclude(t => t.TripLineAirPassengers).ThenInclude(t => t.TripLineAirPassengerAirSegments)
                    .Include(t => t.TripLines).ThenInclude(t => t.TripLineLand)
                    .Include(t => t.TripLines).ThenInclude(t => t.TripLineInsurance).ThenInclude(t => t.TripLineInsurancePassengers)
                    .Include(t => t.TripLines).ThenInclude(t => t.TripLineInsurance).ThenInclude(t => t.TripLineInsuranceSurcharges)
                    .Include(t => t.TripLines).ThenInclude(t => t.TripLineForeignCurrency)
                    .Include(t => t.TripLines).ThenInclude(t => t.TripLineServiceFee)
                    .Include(t => t.TripLines).ThenInclude(t => t.TripLineOtherInclusion)
                    .Include(t => t.TripLines).ThenInclude(t => t.TripLineRemark)
                    .Single(t => t.Id == tripId);

                bool result = lazyContext.Delete(q);

                ts.Complete();
                return result;
            }
        }

        public int CreateTripFromProfile(AppLazyContext lazyContext, int profileId, int[] passengerIds, int? tripId = null) {
            if (profileId <= 0)
                throw new UnreportedException("No profile has been selected.");

            using (var ts = Utils.CreateTransactionScope()) {
                int currencyId = AppSettings.Setting(HttpContext.CurrentCustomerId()).CurrencyId;

                var profile = lazyContext.Profile.Find(profileId);
                var currency = lazyContext.Currency.Find(currencyId);

                Trip q = null;

                if (tripId == null) {
                    string rules = string.Empty;
                    string remarks = string.Empty;

                    if (!string.IsNullOrEmpty(profile.Rules) && !string.IsNullOrEmpty(profile.Debtor.Rules)) {
                        rules = string.Format("Profile Rules & Regulations:{0}{1}{0}{0}Debtor Rules & Regulations:{0}{2}", Environment.NewLine, profile.Rules, profile.Debtor.Rules);
                    }
                    else if (!string.IsNullOrEmpty(profile.Rules)) {
                        rules = profile.Rules;
                    }
                    else if (!string.IsNullOrEmpty(profile.Debtor.Rules)) {
                        rules = profile.Debtor.Rules;
                    }

                    if (!string.IsNullOrEmpty(profile.Remarks) && !string.IsNullOrEmpty(profile.Debtor.Remarks)) {
                        remarks = string.Format("Profile Remarks:{0}{1}{0}{0}Debtor Remarks:{0}{2}", Environment.NewLine, profile.Remarks, profile.Debtor.Remarks);
                    }
                    else if (!string.IsNullOrEmpty(profile.Remarks)) {
                        remarks = profile.Remarks;
                    }
                    else if (!string.IsNullOrEmpty(profile.Debtor.Remarks)) {
                        remarks = profile.Debtor.Remarks;
                    }

                    q = new Trip {
                        Id = 0,
                        TripNo = LastDocumentNo.DocumentNo(lazyContext, "Trip"),
                        Code = string.Empty,
                        ProfileId = profile.Id,
                        ClientAccountType = profile.DebtorId > 0 ? ClientAccountType.Debtor : ClientAccountType.Client,
                        BookingType = BookingType.NotSpecified,
                        SerkoOnlineBookingStatus = SerkoOnlineBookingStatus.NotSpecified,
                        Title = profile.Title.ToStringExt(),
                        FirstName = profile.FirstName,
                        LastName = profile.LastName,
                        PhoneHome = profile.PhoneHome.ToStringExt(),
                        PhoneWork = profile.PhoneWork.ToStringExt(),
                        Mobile = profile.Mobile.ToStringExt(),
                        Fax = profile.Fax.ToStringExt(),
                        Email = profile.Email.ToStringExt(),
                        MaritalStatus = profile.MaritalStatus,
                        Occupation = profile.Occupation.ToStringExt(),
                        BusinessType = profile.BusinessType.ToStringExt(),
                        UserReferenceNo = string.Empty,
                        AgencyId = HttpContext.CurrentDefaultAgencyId(),
                        ConsultantId = HttpContext.CurrentConsultantId(),
                        AgentId = -1,
                        SourceId = -1,
                        CurrencyId = currency.Id,
                        GroupId = -1,
                        ClassId = -1,
                        CategoryId = -1,
                        DestinationId = -1,
                        LocationId = -1,
                        MainCityId = -1,
                        DebtorId = profile.DebtorId,
                        DebtorBookedById = -1,
                        DebtorAuthorisedById = -1,
                        DebtorOrderNo = string.Empty,
                        DebtorTravelReason = string.Empty,
                        DebtorVideoConferencingConsidered = false,
                        DebtorVideoConferencingReasonRejected = string.Empty,
                        PaxAdult = profile.ProfilePassengers.Count(t => t.PassengerType != PassengerType.Child && t.PassengerType != PassengerType.Infant),
                        PaxChild = profile.ProfilePassengers.Count(t => t.PassengerType == PassengerType.Child),
                        PaxInfant = profile.ProfilePassengers.Count(t => t.PassengerType == PassengerType.Infant),
                        DepartureDate = DateTime.Today,
                        ReturnDate = DateTime.MinValue,
                        BalanceDueDate = DateTime.MinValue,
                        ExchangeRate = currency.GetExchangeRate(),
                        Rules = rules,
                        Remarks = remarks,
                        Notes = string.Empty,
                        ChecklistComments = string.Empty,
                        ChecklistContactMethod = ContactMethod.NotSpecified,
                        ChecklistContactById = -1,
                        CancellationContactMethod = ContactMethod.NotSpecified,
                        CancellationById = -1
                    };

                    LastDocumentNo.DocumentNo(lazyContext, "Trip", q.TripNo);
                    lazyContext.Insert(q);
                }
                else {
                    q = lazyContext.Trip.Find(tripId);
                }

                foreach (var row in profile.ProfileAddresses) {
                    var tripAddress = new TripAddress {
                        Id = 0,
                        TripId = q.Id,
                        AddressType = row.AddressType,
                        Address1 = row.Address1,
                        Address2 = row.Address2,
                        Locality = row.Locality,
                        Region = row.Region,
                        PostCode = row.PostCode,
                        CountryCode = row.CountryCode,
                        IsDefault = row.IsDefault
                    };

                    lazyContext.Insert(tripAddress);
                }

                if (passengerIds != null && passengerIds.Length > 0) {
                    foreach (var profilePassenger in profile.ProfilePassengers.Where(t => passengerIds.Contains(t.Id))) {
                        var passenger = lazyContext.Passenger.Find(profilePassenger.Id).Clone() as Passenger;

                        passenger.Id = 0;
                        passenger.ProfileId = -1;
                        passenger.TripId = q.Id;
                        passenger.PassengerProfileId = -1;
                        passenger.ProfilePassengerId = profilePassenger.Id;

                        if (lazyContext.Passenger.Where(t => t.TripId == passenger.TripId).AsEnumerable().Any(t => t.IsDuplicate(passenger)))
                            continue;

                        lazyContext.Insert(passenger);

                        foreach (var profilePassengerDocument in profilePassenger.PassengerDocuments) {
                            var passengerDocument = new PassengerDocument {
                                Id = 0,
                                PassengerId = passenger.Id,
                                DocumentType = profilePassengerDocument.DocumentType,
                                DocumentNo = profilePassengerDocument.DocumentNo,
                                IssueDate = profilePassengerDocument.IssueDate,
                                ExpiryDate = profilePassengerDocument.ExpiryDate,
                                PlaceOfIssue = profilePassengerDocument.PlaceOfIssue,
                                IssuingCountryId = profilePassengerDocument.IssuingCountryId,
                                NationalityId = profilePassengerDocument.NationalityId,
                                Comments = profilePassengerDocument.Comments
                            };

                            lazyContext.Insert(passengerDocument);
                        }

                        foreach (var profileClubMembership in profile.ProfileClubMemberships.Where(t => t.PassengerId == profilePassenger.Id)) {
                            var passengerClubMembership = new PassengerClubMembership {
                                Id = 0,
                                PassengerId = passenger.Id,
                                ClubMembershipId = profileClubMembership.ClubMembershipId,
                                ClubMembershipNo = profileClubMembership.ClubMembershipNo,
                                AirlineId = -1
                            };

                            lazyContext.Insert(passengerClubMembership);
                        }
                    }
                }

                ts.Complete();
                return q.Id;
            }
        }

        public static bool UpdateDepartureReturnDates(AppMainContext context, int tripId) {
            var q = context.Trip.Include(t => t.TripLines).Single(t => t.Id == tripId);

            DateTime departureDate = q.GetDepartureDate();
            DateTime returnDate = q.GetReturnDate();

            if (q.DepartureDate == departureDate && q.ReturnDate == returnDate)
                return false;

            q.DepartureDate = departureDate;
            q.ReturnDate = returnDate;

            return context.Save(q, false);
        }
    }

    public static class TripPaymentScheduleCommon {
        public static bool CreateOrUpdate(AppMainContext context, TripPaymentScheduleViewModel model) {
            TripPaymentSchedule q;

            if (model.TripPaymentScheduleId <= 0) {
                q = new TripPaymentSchedule();
            }
            else {
                q = context.TripPaymentSchedule.Find(model.TripPaymentScheduleId);
            }

            q.TripId = model.TripPaymentScheduleTripId;
            q.TransactionDate = model.TripPaymentScheduleTransactionDate ?? DateTime.MinValue;
            q.Amount = model.TripPaymentScheduleAmount;
            q.Description = model.TripPaymentScheduleDescription.ToStringExt();
            q.IsCompleted = model.TripPaymentScheduleIsCompleted;

            bool result;

            if (q.Id <= 0) {
                result = context.Insert(q);
            }
            else {
                result = context.Save(q);
            }

            return result;
        }
    }

    public static class TripAddressCommon {
        public static bool CreateOrUpdate(AppMainContext context, AddressViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                TripAddress q;

                if (model.AddressId <= 0) {
                    q = new TripAddress();
                }
                else {
                    q = context.TripAddress.Find(model.AddressId);
                }

                q.TripId = model.ParentId;
                q.AddressType = model.AddressType;
                q.Address1 = model.Address1.ToStringExt();
                q.Address2 = model.Address2.ToStringExt();
                q.Locality = model.Locality.ToStringExt();
                q.Region = model.Region.ToStringExt();
                q.PostCode = model.PostCode.ToStringExt();
                q.CountryCode = model.CountryCode.ToStringExt();
                q.IsDefault = model.IsDefaultAddress;

                bool result;

                if (q.Id <= 0) {
                    result = context.Insert(q);
                }
                else {
                    result = context.Save(q);
                }

                model.AddressId = q.Id;

                if (model.IsDefaultAddress) {
                    foreach (var row in context.TripAddress.Where(t => t.Id != q.Id && t.TripId == model.ParentId && t.IsDefault)) {
                        row.IsDefault = false;
                        context.Save(row, false);
                    }
                }

                ts.Complete();
                return result;
            }
        }
    }

    public static class TripChecklistCommon {
        public static bool Create(AppMainContext context, int tripId) {
            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var row in context.TripChecklistDefault.OrderBy(t => t.SeqNo)) {
                    var q = new TripChecklist {
                        Id = 0,
                        TripId = tripId,
                        Name = row.Name,
                        ActionDate = DateTime.MinValue
                    };

                    context.Insert(q, false);
                }

                ts.Complete();
                return true;
            }
        }

        public static bool Update(AppMainContext context, int tripId, int contactMethodId, int? contactById, DateTime? followUpDate, string comments, string tripChecklistDetailModels) {
            if (contactById == null)
                throw new UnreportedException("Contact By is required.");

            var detailModels = JsonSerializer.Deserialize<List<TripChecklistViewModel>>(tripChecklistDetailModels, JsonExtensionsBiz.JsonSerializerOptions());

            using (var ts = Utils.CreateTransactionScope()) {
                var q = context.Trip.Include(t => t.TripChecklists).Single(t => t.Id == tripId);

                q.ChecklistContactMethod = (ContactMethod)contactMethodId;
                q.ChecklistContactById = contactById ?? 0;
                q.ChecklistFollowUpDate = followUpDate == null ? DateTime.MinValue : (DateTime)followUpDate;
                q.ChecklistComments = comments.ToStringExt();

                context.Save(q);

                foreach (var row in q.TripChecklists) {
                    var detailModel = detailModels.SingleOrDefault(t => t.TripChecklistId == row.Id);

                    if (detailModel == null)
                        continue;

                    DateTime actionDate = detailModel.ActionDate == null ? DateTime.MinValue : (DateTime)detailModel.ActionDate;
                    bool isCompleted = detailModel.ActionDate != null && detailModel.IsCompleted;

                    if (row.ActionDate != actionDate || row.IsCompleted != isCompleted) {
                        row.ActionDate = actionDate;
                        row.IsCompleted = isCompleted;
                        context.Save(row);
                    }
                }

                ts.Complete();
                return true;
            }
        }
    }

    public static class TripItineraryCommon {
        public static bool Update(AppMainContext context, int tripItineraryId, string name, int[] passengerIds) {
            using (var ts = Utils.CreateTransactionScope()) {
                var tripItinerary = context.TripItinerary.Find(tripItineraryId);

                if (tripItinerary.Name != name) {
                    if (string.IsNullOrEmpty(name))
                        name = GetUniqueName(context, tripItinerary.TripId);

                    tripItinerary.Name = name;
                    context.Save(tripItinerary);
                }

                context.RemoveRange(context.TripItineraryPassenger.Where(t => t.TripItineraryId == tripItineraryId && !passengerIds.Contains(t.PassengerId)));
                context.SaveChanges();

                foreach (int passengerId in passengerIds) {
                    var tripItineraryPassenger = context.TripItineraryPassenger.SingleOrDefault(t => t.TripItineraryId == tripItineraryId && t.PassengerId == passengerId);

                    if (tripItineraryPassenger != null)
                        continue;

                    tripItineraryPassenger = new TripItineraryPassenger {
                        Id = 0,
                        TripItineraryId = tripItineraryId,
                        PassengerId = passengerId,
                    };

                    context.Insert(tripItineraryPassenger);
                }

                ts.Complete();
                return true;
            }
        }

        public static bool Delete(AppMainContext context, int tripItineraryId) {
            var tripItinerary = context.TripItinerary.Find(tripItineraryId);

            if (tripItinerary == null)
                throw new UnreportedException(AppConstants.RecordNotFound);

            return context.Delete(tripItinerary);
        }

        public static int Build(AppLazyContext lazyContext, int tripId, int tripItineraryId, int quoteNo) {
            using (var ts = Utils.CreateTransactionScope()) {
                List<TripItineraryDetail> itineraryDetailList = null;

                var tripItinerary = lazyContext.TripItinerary.Find(tripItineraryId);

                if (tripItinerary == null) {
                    tripItinerary = new TripItinerary {
                        Id = 0,
                        TripId = tripId,
                        Name = GetUniqueName(lazyContext, tripId)
                    };

                    lazyContext.Insert(tripItinerary);
                    tripItineraryId = tripItinerary.Id;
                }

                if (lazyContext.TripLineSelection.Include(t => t.TripLine).Any(t => t.TripLine.TripId == tripId && t.QuoteNo == quoteNo && t.TripLine.PrintOnItinerary)) {
                    var q = lazyContext.TripLineSelection.Where(t => t.TripLine.TripId == tripId && t.QuoteNo == quoteNo && t.TripLine.PrintOnItinerary).AsEnumerable()
                        .OrderBy(t => t.TripLine.GetSeqNo(quoteNo)).ThenBy(t => t.TripLine.StartDate <= AppConstants.VoidDate || t.TripLine.EndDate <= AppConstants.VoidDate ? 1 : 0).ThenBy(t => t.Id).ToList();

                    itineraryDetailList = new List<TripItineraryDetail>();

                    foreach (var tripLineSelection in q) {
                        if (tripLineSelection.TripLine.TripLineType == TripLineType.Air) {
                            foreach (var tripLineAirSegment in tripLineSelection.TripLine.TripLineAir.TripLineAirSegments) {
                                itineraryDetailList.Add(new TripItineraryDetail {
                                    TripLineId = tripLineAirSegment.TripLineAir.TripLineId,
                                    TripLine = tripLineAirSegment.TripLineAir.TripLine,
                                    TripLineAirSegmentId = tripLineAirSegment.Id,
                                    TripLineAirSegment = tripLineAirSegment
                                });
                            }
                        }
                        else {
                            itineraryDetailList.Add(new TripItineraryDetail {
                                TripLineId = tripLineSelection.TripLineId,
                                TripLine = tripLineSelection.TripLine,
                                TripLineAirSegmentId = -1,
                                TripLineAirSegment = new TripLineAirSegment { Id = -1 },
                            });
                        }
                    }
                }
                else {
                    itineraryDetailList = lazyContext.TripLineAirSegment.Where(t => t.TripLineAir.TripLine.TripId == tripId && t.TripLineAir.TripLine.PrintOnItinerary).ToList().ConvertAll(row => new TripItineraryDetail {
                        TripLineId = row.TripLineId,
                        TripLine = row.TripLineAir.TripLine,
                        TripLineAirSegmentId = row.Id,
                        TripLineAirSegment = row
                    }).Concat(lazyContext.TripLine.Where(t => t.TripId == tripId && t.TripLineType != TripLineType.Air && t.PrintOnItinerary).AsEnumerable().OrderBy(t => t.GetSeqNo(quoteNo)).ThenBy(t => t.StartDate <= AppConstants.VoidDate || t.EndDate <= AppConstants.VoidDate ? 1 : 0).ThenBy(t => t.Id).ToList().ConvertAll(row => new TripItineraryDetail {
                        TripLineId = row.Id,
                        TripLine = row,
                        TripLineAirSegmentId = -1,
                        TripLineAirSegment = new TripLineAirSegment { Id = -1 }
                    })).ToList();
                }

                lazyContext.RemoveRange(lazyContext.TripItineraryDetail.Where(t => t.TripItineraryId == tripItineraryId));
                lazyContext.SaveChanges();

                int seqNo = 1;

                foreach (var row in itineraryDetailList.OrderBy(t => t.SeqDate)) {
                    row.Id = 0;
                    row.TripItineraryId = tripItineraryId;
                    row.TripLineId = row.TripLineId;
                    row.TripLineAirSegmentId = row.TripLineAirSegmentId;
                    row.SeqNo = seqNo++;
                    lazyContext.Insert(row, false);
                }

                ts.Complete();
                return tripItineraryId;
            }
        }

        public static bool Reorder(AppLazyContext lazyContext, int tripItineraryId, TripLineOrderType tripLineOrderType, int[] itineraryDetailIds = null) {
            var q = lazyContext.TripItineraryDetail.Where(t => t.TripItineraryId == tripItineraryId).ToList();

            if (q.Count == 0)
                return false;

            switch (tripLineOrderType) {
                default:
                    q = q.OrderBy(t => t.SeqNo).ToList();
                    break;
                case TripLineOrderType.None:
                    q = q.OrderBy(t => t.Id).ToList();
                    break;
                case TripLineOrderType.StartDate:
                    q = q.OrderBy(t => t.TripLineAirSegmentId > 0 ? t.TripLineAirSegment.DepartureDate : t.TripLine.TripLineType == TripLineType.Remark && t.TripLine.TripLineRemark.RelatedTripLineId > 0 ? t.TripLine.TripLineRemark.RelatedTripLine.StartDate : t.TripLine.StartDate).ThenBy(t => t.TripLine.GetSeqNo(0)).ThenByDescending(t => ((t.TripLineAirSegment.Id > 0 ? t.TripLineAirSegment.ArrivalDate : t.TripLine.EndDate) - (t.TripLineAirSegment.Id > 0 ? t.TripLineAirSegment.DepartureDate : t.TripLine.StartDate)).Days).ToList();
                    break;
            }

            var itineraryDetailIdList = new List<int>(q.Select(t => t.Id));

            if (itineraryDetailIds != null && itineraryDetailIds.Length > 0 && (tripLineOrderType == TripLineOrderType.Up || tripLineOrderType == TripLineOrderType.Down)) {
                if (tripLineOrderType == TripLineOrderType.Down) {
                    q.Reverse();
                    itineraryDetailIdList.Reverse();
                }

                foreach (int itineraryDetailId in q.Where(t => itineraryDetailIds.Contains(t.Id)).Select(t => t.Id)) {
                    int index = q.FindIndex(t => t.Id == itineraryDetailId);

                    if (index == 0)
                        return false;

                    var currentRow = q.ElementAt(index);
                    index--;

                    itineraryDetailIdList.Remove(currentRow.Id);
                    itineraryDetailIdList.Insert(index, currentRow.Id);
                }

                if (tripLineOrderType == TripLineOrderType.Down)
                    itineraryDetailIdList.Reverse();
            }

            using (var ts = Utils.CreateTransactionScope()) {
                int seqNo = 1;

                foreach (int itineraryDetailId in itineraryDetailIdList) {
                    var itineraryDetail = lazyContext.TripItineraryDetail.Find(itineraryDetailId);

                    if (itineraryDetail.SeqNo != seqNo) {
                        itineraryDetail.SeqNo = seqNo;
                        lazyContext.Save(itineraryDetail, false);
                    }

                    seqNo++;
                }

                ts.Complete();
                return true;
            }
        }

        public static bool DeleteSelections(AppMainContext context, int[] itineraryDetailIds) {
            context.RemoveRange(context.TripItineraryDetail.Where(t => itineraryDetailIds.Contains(t.Id)));
            context.SaveChanges();
            return true;
        }

        private static string GetUniqueName(AppMainContext context, int tripId) {
            var q = context.TripItinerary.Where(t => t.TripId == tripId && t.Name.StartsWith("Itinerary ")).ToList();

            int i = 1;
            string name = "Itinerary 1";

            while (q.Any(t => t.Name.ToLower() == name.ToLower())) {
                i++;
                name = string.Format("Itinerary {0}", i);
            }

            return name;
        }
    }

    public class TripLineCommon {
        private HttpContext HttpContext { get; }

        public TripLineCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool CreateOrUpdate(AppMainContext context, TripLineViewModel model) {
            TripLine q;

            if (model.TripLineId <= 0) {
                q = new TripLine {
                    Id = 0,
                    StartDate = DateTime.MinValue,
                    EndDate = DateTime.MinValue,
                    Description = string.Empty,
                    ReceiptInfo = string.Empty,
                    PaymentInfo = string.Empty,
                    InvoiceInfo = string.Empty,
                    PackageNo = 0
                };
            }
            else {
                q = context.TripLine.Find(model.TripLineId);
            }

            q.TripId = model.TripId;
            q.TripLineType = model.TripLineType;
            q.TripLineStatus = model.TripLineStatus;
            q.PersonalTravelAmount = model.PersonalTravelAmount;
            q.PrintOnQuote = model.PrintOnQuote;
            q.PrintOnConfirmation = model.PrintOnConfirmation;
            q.PrintOnItinerary = model.PrintOnItinerary;
            q.PrintOnStatement = model.PrintOnStatement;

            bool result;

            if (q.Id <= 0) {
                result = context.Insert(q);
            }
            else {
                result = context.Save(q);
            }

            model.TripLineId = q.Id;
            return result;
        }

        public static Trip Delete(AppLazyContext lazyContext, TripLineViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = GetTripLine(lazyContext, model.TripLineId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (q.Trip.IsLocked)
                    throw new UnreportedException(AppConstants.RecordIsLockedCannotDelete);

                var voucher = q.Voucher;

                if (voucher.Id > 0)
                    throw new UnreportedException(string.Format("This trip line cannot be deleted because it is assigned to Voucher No {0}.", voucher.DocumentNo));

                lazyContext.RemoveRange(q.TripItineraryDetails);
                lazyContext.SaveChanges();

                var trip = q.Trip;
                lazyContext.Delete(q);

                ts.Complete();
                return trip;
            }
        }

        public int Duplicate(AppLazyContext lazyContext, ref int profileId, int tripId, int baseTripId, string tripLineIds, int[] sourcePassengerIds, int[] targetPassengerIds, bool includeProfile, bool includeClientDetails, bool includeTripInformation, bool includePassengerDetails) {
            if ((sourcePassengerIds == null || sourcePassengerIds.Length == 0) && targetPassengerIds != null && targetPassengerIds.Length > 0)
                throw new UnreportedException("No source passengers have been selected.");

            if (sourcePassengerIds != null && sourcePassengerIds.Length > 0 && targetPassengerIds != null && targetPassengerIds.Length > 0 && sourcePassengerIds.Length != targetPassengerIds.Length)
                throw new UnreportedException("Source passenger count does not match destination passenger count.");

            if (includePassengerDetails && (sourcePassengerIds == null || sourcePassengerIds.Length == 0 || targetPassengerIds == null || targetPassengerIds.Length == 0))
                throw new UnreportedException("Source and target passengers must be selected when 'Include Passenger Details' is selected.");

            if (!includeProfile)
                profileId = -1;

            using (var ts = Utils.CreateTransactionScope()) {
                var trip = lazyContext.Trip.Find(baseTripId);
                int[] tripLineIdList = null;

                if (!includePassengerDetails) {
                    if (sourcePassengerIds == null || sourcePassengerIds.Length == 0)
                        sourcePassengerIds = new int[] { -1 };

                    if (targetPassengerIds == null || targetPassengerIds.Length == 0)
                        targetPassengerIds = new int[] { -1 };
                }

                if (string.IsNullOrEmpty(tripLineIds)) {
                    tripLineIdList = trip.TripLines.Select(t => t.Id).ToArray();
                }
                else {
                    tripLineIdList = tripLineIds.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
                }

                Dictionary<int, int> passengerList = null;

                if (sourcePassengerIds != null && sourcePassengerIds.Length > 0 && targetPassengerIds != null && targetPassengerIds.Length > 0) {
                    passengerList = new Dictionary<int, int>();
                    int i = 0;

                    foreach (int passengerId in sourcePassengerIds) {
                        if (i > targetPassengerIds.Length - 1)
                            break;

                        passengerList.Add(passengerId, targetPassengerIds[i]);
                        i++;
                    }
                }

                if (tripId <= 0) {
                    var tripClone = trip.Duplicate(lazyContext, HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.CurrentDefaultAgencyId(), HttpContext.CurrentConsultantId(), tripLineIdList, sourcePassengerIds, targetPassengerIds, includeProfile, includeClientDetails, includeTripInformation, includePassengerDetails);
                    ts.Complete();
                    profileId = tripClone.ProfileId;
                    return tripClone.Id;
                }

                trip = lazyContext.Trip.Find(tripId);
                profileId = trip.ProfileId;

                foreach (int tripLineId in tripLineIdList) {
                    var tripLine = lazyContext.TripLine.Find(tripLineId);

                    if (tripLine == null)
                        continue;

                    tripLine.Duplicate(lazyContext, HttpContext.User, HttpContext.CurrentCustomerId(), trip, passengerList, includePassengerDetails);
                }

                ts.Complete();
                return tripId;
            }
        }

        public static bool SetPackageNo(AppMainContext context, int[] tripLineIds, bool clearPackage) {
            var q = context.TripLine.Include(t => t.Trip).ThenInclude(t => t.TripLines).Where(t => tripLineIds.Contains(t.Id)).ToList();

            if (q.Count == 0)
                return true;

            int packageNo = clearPackage ? 0 : (q[0].Trip.TripLines.Max(t => (int?)t.PackageNo) ?? 0) + 1;

            if (packageNo > 99)
                throw new UnreportedException("Maximum Package No has been reached.");

            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var row in q) {
                    row.PackageNo = packageNo;
                    context.Save(row);
                }

                ts.Complete();
                return true;
            }
        }

        public static void SetCashAndCreditCardAmounts(FormOfPaymentClass formOfPaymentClass, bool isCreditCardDiscountApplicable, bool isCreditCardMarkupApplicable, decimal amount, decimal nonCommissionable,
            decimal discount, decimal markup, ref decimal cashAmount, ref decimal cashNonCommissionable, ref decimal creditCardAmount, ref decimal creditCardNonCommissionable) {

            if (!isCreditCardDiscountApplicable)
                discount = 0;

            if (!isCreditCardMarkupApplicable)
                markup = 0;

            if (formOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
                cashAmount = discount;
                creditCardAmount = amount - discount + markup;
                cashNonCommissionable = 0;
                creditCardNonCommissionable = nonCommissionable;
            }
            else {
                cashAmount = amount;
                creditCardAmount = 0;
                cashNonCommissionable = nonCommissionable;
                creditCardNonCommissionable = 0;
            }
        }

        public static bool ValidateCashAndCreditCardAmounts(FormOfPaymentClass formOfPaymentClass, int formOfPaymentId, decimal cashAmount, decimal cashNonCommissionable, decimal creditCardAmount, decimal creditCardNonCommissionable) {
            if ((cashAmount != 0 || cashNonCommissionable != 0) && creditCardAmount == 0 && creditCardNonCommissionable == 0 && formOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
                return false;
            }
            else if ((creditCardAmount != 0 || creditCardNonCommissionable != 0) && cashAmount == 0 && cashNonCommissionable == 0 && formOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard && formOfPaymentId > 0) {
                return false;
            }

            return true;
        }

        public static TripLine GetTripLine(AppLazyContext lazyContext, int tripLineId) {
            return lazyContext.TripLine.Include(t => t.Trip).Include(t => t.TripLineSelections)
                .Include(t => t.TripLineAir).ThenInclude(t => t.TripLineAirSegments).ThenInclude(t => t.TripLineAirPassengerAirSegments)
                .Include(t => t.TripLineAir).ThenInclude(t => t.TripLineAirPassengers).ThenInclude(t => t.TripLineAirPassengerAirSegments)
                .Include(t => t.TripLineLand)
                .Include(t => t.TripLineInsurance).ThenInclude(t => t.TripLineInsurancePassengers)
                .Include(t => t.TripLineInsurance).ThenInclude(t => t.TripLineInsuranceSurcharges)
                .Include(t => t.TripLineForeignCurrency)
                .Include(t => t.TripLineServiceFee)
                .Include(t => t.TripLineOtherInclusion)
                .Include(t => t.TripLineRemark)
                .SingleOrDefault(t => t.Id == tripLineId);
        }
    }

    public class TripLineAirCommon {
        private HttpContext HttpContext { get; }

        public TripLineAirCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public object CreateOrUpdate(TripLineAirViewModel model) {
            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    new TripLineCommon(HttpContext).CreateOrUpdate(lazyContext, model.TripLineViewModel);
                    TripLineAir q = null;

                    if (model.TripLineId <= 0) {
                        q = new TripLineAir();
                    }
                    else {
                        q = lazyContext.TripLineAir.Include(t => t.TripLine).ThenInclude(t => t.TripLineSelections).Single(t => t.TripLineId == model.TripLineId);
                    }

                    q.TripLineId = model.TripLineViewModel.TripLineId;
                    q.TripLine = lazyContext.TripLine.Include(t => t.Trip).SingleOrDefault(t => t.Id == model.TripLineViewModel.TripLineId);
                    q.AirlineId = model.AirlineId ?? 0;
                    q.Airline = lazyContext.Airline.Find(model.AirlineId ?? 0);
                    q.ValidUntilDate = model.ValidUntilDate ?? DateTime.MinValue;
                    q.Crs = model.TripLineAirCrs;
                    q.CrsPnrRef = model.TripLineAirCrsPnrRef.ToStringExt();
                    q.ReferenceNo = model.ReferenceNo.ToStringExt();
                    q.ConditionId = model.ConditionId ?? 0;
                    q.ServiceDescription = model.ServiceDescription.ToStringExt();

                    bool result;

                    if (model.TripLineId <= 0) {
                        result = lazyContext.Insert(q);
                    }
                    else {
                        result = lazyContext.Save(q);
                    }

                    model.TripLineId = q.TripLineId;

                    if (result)
                        q.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                    if (q.TripLine.Trip.IsBooking && !q.TripLine.IsBooking)
                        TripLineSelectionCommon.Add(lazyContext, HttpContext.User, HttpContext.CurrentCustomerId(), q.TripLine.TripId, new int[] { q.TripLineId }, 0);

                    TripCommon.UpdateDepartureReturnDates(lazyContext, q.TripLine.TripId);

                    var returnModel = new {
                        q.TripLineId,
                        TripDepartureDate = q.TripLine.Trip.DepartureDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.DepartureDate,
                        TripReturnDate = q.TripLine.Trip.ReturnDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.ReturnDate
                    };

                    ts.Complete();
                    return returnModel;
                }
            }
        }

        public bool InsertArnkAirSegments(IPrincipal principal, int customerId, int tripLineId, bool assignPassengers = false, bool isCrsImport = false) {
            int seqNo = 0;
            int index = -1;
            bool isUpdated = false;

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    var tripLineAirSegments = lazyContext.TripLineAirSegment.Where(t => t.TripLineId == tripLineId).OrderBy(t => t.SeqNo).ToList();

                    foreach (var tripLineAirSegment in tripLineAirSegments) {
                        index++;

                        if (tripLineAirSegment.DepartureDate == lazyContext.VoidDate)
                            continue;

                        if (index > 0 && index < tripLineAirSegments.Count && tripLineAirSegment.DepartureCityId > 0 && tripLineAirSegments[index - 1].ArrivalCityId > 0 && tripLineAirSegment.DepartureCityId != tripLineAirSegments[index - 1].ArrivalCityId) {
                            var q = new TripLineAirSegment {
                                Id = 0,
                                TripLineId = tripLineAirSegment.TripLineId,
                                TripStatus = TripStatus.NotSpecified,
                                DepartureCityId = tripLineAirSegments[index - 1].ArrivalCityId,
                                ArrivalCityId = tripLineAirSegment.DepartureCityId,
                                Class = string.Empty,
                                FlightNo = string.Empty,
                                DepartureDate = lazyContext.VoidDate,
                                CheckInTime = string.Empty,
                                DepartureTime = string.Empty,
                                ArrivalTime = string.Empty,
                                FlightTime = string.Empty,
                                InternationalDateOffset = InternationalDateOffset.None,
                                AirportType = AirportType.NotSpecified,
                                DepartureTerminal = string.Empty,
                                ArrivalTerminal = string.Empty,
                                AirlinePnr = string.Empty,
                                AircraftId = -1,
                                Operator = string.Empty,
                                Meals = string.Empty,
                                TransitStops = string.Empty,
                                DistanceFlownKm = 0,
                                CO2Emissions = 0,
                                SeqNo = tripLineAirSegment.SeqNo,
                                CrsKey = string.Empty
                            };

                            try {
                                lazyContext.Insert(q);
                            }
                            catch {
                                if (isCrsImport) {
                                    ts.Complete();
                                    throw new CrsException("CRS import failed.");
                                }

                                throw;
                            }

                            if (assignPassengers) {
                                var tripLineAirPassengers = tripLineAirSegments[index - 1].TripLineAirPassengerAirSegments.Select(t => t.TripLineAirPassenger);

                                if (!tripLineAirPassengers.SequenceEqual(tripLineAirSegment.TripLineAirPassengerAirSegments.Select(t => t.TripLineAirPassenger)))
                                    tripLineAirPassengers = tripLineAirPassengers.Concat(tripLineAirSegment.TripLineAirPassengerAirSegments.Select(t => t.TripLineAirPassenger));

                                foreach (var tripLineAirPassenger in tripLineAirPassengers) {
                                    if (tripLineAirPassenger.TripLineAirPassengerAirSegments.Any(t => t.TripLineAirSegmentId == q.Id))
                                        continue;

                                    var tripLineAirPassengerAirSegment = new TripLineAirPassengerAirSegment {
                                        Id = 0,
                                        TripLineAirPassengerId = tripLineAirPassenger.Id,
                                        TripLineAirSegmentId = q.Id,
                                        GroupNo = 0,
                                        SeatNo = string.Empty,
                                        SeatStatus = SeatStatus.NotSpecified,
                                        BaggageAllowance = 0,
                                        BaggageUnit = BaggageUnit.Piece,
                                        FareBasis = string.Empty,
                                        TicketDesignator = string.Empty,
                                        TourCode = string.Empty,
                                        Amount = 0,
                                        Tax = 0
                                    };

                                    lazyContext.Insert(tripLineAirPassengerAirSegment, false);
                                }
                            }

                            isUpdated = true;
                            seqNo++;
                        }
                        else if (tripLineAirSegment.DepartureDate == lazyContext.VoidDate) {
                            if (index > 0)
                                tripLineAirSegment.DepartureCityId = tripLineAirSegments[index - 1].ArrivalCityId;

                            if (index < tripLineAirSegments.Count - 1)
                                tripLineAirSegment.ArrivalCityId = tripLineAirSegments[index + 1].DepartureCityId;
                        }

                        if (seqNo > 0) {
                            tripLineAirSegment.SeqNo += seqNo;

                            var segment = lazyContext.TripLineAirSegment.Find(tripLineAirSegment.Id);
                            segment.DepartureCityId = tripLineAirSegment.DepartureCityId;
                            segment.ArrivalCityId = tripLineAirSegment.ArrivalCityId;
                            segment.SeqNo = tripLineAirSegment.SeqNo;
                            lazyContext.Save(segment, false);
                        }
                    }

                    tripLineAirSegments = lazyContext.TripLineAirSegment.Where(t => t.TripLineId == tripLineId).OrderBy(t => t.SeqNo).ToList();
                    index = 0;

                    foreach (var tripLineAirSegment in tripLineAirSegments.ToList()) {
                        if (index == 0 && tripLineAirSegment.DepartureDate == lazyContext.VoidDate) {
                            lazyContext.Delete(tripLineAirSegment, false);
                            isUpdated = true;
                            continue;
                        }

                        index++;
                    }

                    if (isUpdated) {
                        foreach (var tripLineAirSegment in tripLineAirSegments.Where(t => t.TripLineAir != null).ToList()) {
                            tripLineAirSegment.TripLineAir.TripLine.Update(principal, customerId, lazyContext);
                        }
                    }

                    ts.Complete();
                    return isUpdated;
                }
            }
        }
    }

    public class TripLineAirSegmentCommon {
        private HttpContext HttpContext { get; }

        public TripLineAirSegmentCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public bool QuickCompletionCreate(AppLazyContext lazyContext, IEnumerable<TripLineAirSegmentQuickCompletionViewModel> models, int parentId) {
            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var model in models) {
                    string message = null;

                    var departureCity = lazyContext.City.SingleOrDefault(t => t.Code == model.DepartureCityCode.ToStringExt());
                    var arrivalCity = lazyContext.City.SingleOrDefault(t => t.Code == model.ArrivalCityCode.ToStringExt());

                    if (!DataValidation.IsAlphaNumeric(model.FlightNo)) {
                        message = "Flight No is invalid.";
                    }
                    else if (!string.IsNullOrEmpty(model.DepartureTime) && !DataValidation.IsTime(model.DepartureTime)) {
                        message = "Departure Time is invalid.";
                    }
                    else if (!string.IsNullOrEmpty(model.ArrivalTime) && !DataValidation.IsTime(model.ArrivalTime)) {
                        message = "Arrival Time is invalid.";
                    }

                    StringLengthAttribute attribute = null;

                    if (string.IsNullOrEmpty(message) && !string.IsNullOrEmpty(model.DepartureCityCode)) {
                        attribute = typeof(TripLineAirSegmentQuickCompletionViewModel).GetProperty("DepartureCityCode").GetCustomAttributes(typeof(StringLengthAttribute), false).SingleOrDefault() as StringLengthAttribute;

                        if (model.DepartureCityCode.Length > attribute.MaximumLength) {
                            message = attribute.FormatErrorMessage("From");
                        }
                    }

                    if (string.IsNullOrEmpty(message) && !string.IsNullOrEmpty(model.ArrivalCityCode)) {
                        attribute = typeof(TripLineAirSegmentQuickCompletionViewModel).GetProperty("ArrivalCityCode").GetCustomAttributes(typeof(StringLengthAttribute), false).SingleOrDefault() as StringLengthAttribute;

                        if (model.ArrivalCityCode.Length > attribute.MaximumLength) {
                            message = attribute.FormatErrorMessage("To");
                        }
                    }

                    if (string.IsNullOrEmpty(message) && !string.IsNullOrEmpty(model.FlightNo)) {
                        attribute = typeof(TripLineAirSegmentQuickCompletionViewModel).GetProperty("FlightNo").GetCustomAttributes(typeof(StringLengthAttribute), false).SingleOrDefault() as StringLengthAttribute;

                        if (model.FlightNo.Length > attribute.MaximumLength) {
                            message = attribute.FormatErrorMessage("Flight No");
                        }
                    }

                    if (string.IsNullOrEmpty(message)) {
                        if (departureCity == null) {
                            message = "From is invalid.";
                        }
                        else if (departureCity.Id == -1) {
                            message = "From is required.";
                        }
                        else if (arrivalCity == null) {
                            message = "To is invalid.";
                        }
                        else if (arrivalCity.Id == -1) {
                            message = "To is required.";
                        }
                        else if (departureCity.Id == arrivalCity.Id) {
                            message = "From and To cannot be the same.";
                        }
                    }

                    if (!string.IsNullOrEmpty(message))
                        throw new UnreportedException(message);

                    var q = new TripLineAirSegment {
                        Id = 0,
                        TripLineId = parentId,
                        TripStatus = TripStatus.OnRequest,
                        DepartureCityId = departureCity == null ? -1 : departureCity.Id,
                        ArrivalCityId = arrivalCity == null ? -1 : arrivalCity.Id,
                        Class = model.Class.ToStringExt().ToUpper(),
                        FlightNo = model.FlightNo.ToStringExt().ToUpper(),
                        DepartureDate = model.DepartureDateStatus == DepartureDateStatus.Open ? DateTime.MinValue : model.DepartureDateStatus == DepartureDateStatus.ARNK ? AppConstants.VoidDate : model.TripLineAirSegmentDepartureDate ?? DateTime.MinValue,
                        DepartureTime = model.DepartureDateStatus == DepartureDateStatus.Open || model.DepartureDateStatus == DepartureDateStatus.ARNK ? string.Empty : model.TripLineAirSegmentDepartureDate == null ? string.Empty : model.DepartureTime.ToStringExt(),
                        ArrivalTime = model.DepartureDateStatus == DepartureDateStatus.Open || model.DepartureDateStatus == DepartureDateStatus.ARNK ? string.Empty : model.TripLineAirSegmentDepartureDate == null ? string.Empty : model.ArrivalTime.ToStringExt(),
                        InternationalDateOffset = model.InternationalDateOffset,
                        CheckInTime = string.Empty,
                        FlightTime = string.Empty,
                        DistanceFlownKm = 0,
                        CO2Emissions = 0,
                        AirportType = AirportType.NotSpecified,
                        DepartureTerminal = string.Empty,
                        ArrivalTerminal = string.Empty,
                        AirlinePnr = string.Empty,
                        AircraftId = -1,
                        Operator = string.Empty,
                        Meals = string.Empty,
                        TransitStops = string.Empty,
                        CrsKey = string.Empty
                    };

                    if (lazyContext.Insert(q))
                        lazyContext.TripLine.Find(q.TripLineId).Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                }

                ts.Complete();
                return true;
            }
        }

        public object CreateOrUpdate(TripLineAirSegmentViewModel model, bool validateArnk = true) {
            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    TripLineAirSegment q = null;

                    if (model.TripLineAirSegmentId <= 0) {
                        q = new TripLineAirSegment {
                            Id = 0,
                            SeqNo = model.SeqNo == 0 ? ((lazyContext.TripLineAirSegment.Where(t => t.TripLineId == model.TripLineId).Max(t => (int?)t.SeqNo) ?? 0) + 1) : model.SeqNo,
                            TripLineAirPassengerAirSegments = new List<TripLineAirPassengerAirSegment>()
                        };
                    }
                    else {
                        q = lazyContext.TripLineAirSegment.Find(model.TripLineAirSegmentId);
                    }

                    if (validateArnk && model.DepartureDateStatus == DepartureDateStatus.ARNK) {
                        int departureCityId = lazyContext.TripLineAirSegment.Where(t => t.TripLineId == model.TripLineId).OrderByDescending(t => t.SeqNo).FirstOrDefault(t => t.SeqNo < q.SeqNo)?.ArrivalCityId ?? 0;

                        if (departureCityId > 0)
                            model.DepartureCityId = departureCityId;

                        int arrivalCityId = lazyContext.TripLineAirSegment.Where(t => t.TripLineId == model.TripLineId).OrderBy(t => t.SeqNo).FirstOrDefault(t => t.SeqNo > q.SeqNo)?.DepartureCityId ?? 0;

                        if (arrivalCityId > 0)
                            model.ArrivalCityId = arrivalCityId;
                    }

                    q.TripLineId = model.TripLineId;
                    q.TripLineAir = lazyContext.TripLineAir.Find(model.TripLineId);
                    q.TripStatus = model.TripStatus;
                    q.DepartureCityId = model.DepartureCityId ?? 0;
                    q.DepartureCity = lazyContext.City.Find(model.DepartureCityId ?? 0);
                    q.ArrivalCityId = model.ArrivalCityId ?? 0;
                    q.ArrivalCity = lazyContext.City.Find(model.ArrivalCityId ?? 0);
                    q.Class = model.Class.ToStringExt().ToUpper();
                    q.FlightNo = model.FlightNo.ToStringExt().ToUpper();
                    q.DepartureDate = model.DepartureDateStatus == DepartureDateStatus.Open ? DateTime.MinValue : model.DepartureDateStatus == DepartureDateStatus.ARNK ? lazyContext.VoidDate : model.TripLineAirSegmentDepartureDate ?? DateTime.Today;
                    q.CheckInTime = model.CheckInTime.ToStringExt();
                    q.DepartureTime = model.DepartureDateStatus == DepartureDateStatus.Open || model.DepartureDateStatus == DepartureDateStatus.ARNK ? string.Empty : model.TripLineAirSegmentDepartureDate == null ? string.Empty : model.DepartureTime.ToStringExt();
                    q.ArrivalTime = model.DepartureDateStatus == DepartureDateStatus.Open || model.DepartureDateStatus == DepartureDateStatus.ARNK ? string.Empty : model.TripLineAirSegmentDepartureDate == null ? string.Empty : model.ArrivalTime.ToStringExt();
                    q.FlightTime = model.FlightTime.ToStringExt();
                    q.InternationalDateOffset = model.DepartureDateStatus == DepartureDateStatus.Open || model.DepartureDateStatus == DepartureDateStatus.ARNK || model.TripLineAirSegmentDepartureDate == null ? 0 : model.InternationalDateOffset;
                    q.DistanceFlownKm = model.DistanceFlownKm;
                    q.CO2Emissions = model.CO2Emissions;
                    q.AirportType = model.AirportType;
                    q.DepartureTerminal = model.DepartureTerminal.ToStringExt().ToUpper();
                    q.ArrivalTerminal = model.ArrivalTerminal.ToStringExt().ToUpper();
                    q.AirlinePnr = model.TripLineAirSegmentAirlinePnr.ToStringExt();
                    q.AircraftId = model.AircraftId ?? 0;
                    q.Operator = model.Operator.ToStringExt();
                    q.Meals = model.Meals.ToStringExt();
                    q.TransitStops = model.TransitStops.ToStringExt();
                    q.CrsKey = model.CrsKey.ToStringExt();

                    bool result;

                    if (q.Id <= 0) {
                        result = lazyContext.Insert(q);
                    }
                    else {
                        result = lazyContext.Save(q);
                    }

                    model.TripLineAirSegmentId = q.Id;

                    if (result) {
                        if (model.TripLineAirSegmentId <= 0 && q.TripLineAir.TripLine.Trip.TripPassengers.Count == 1) {
                            var tripLineAirPassenger = lazyContext.TripLineAirPassenger.FirstOrDefault(t => t.TripLineId == q.TripLineId && t.PassengerId == q.TripLineAir.TripLine.Trip.TripPassengers.Single().Id);

                            if (tripLineAirPassenger == null) {
                                tripLineAirPassenger = new TripLineAirPassenger {
                                    Id = 0,
                                    TripLineId = q.TripLineId,
                                    CreditorId = Creditor.GetBspAgent(lazyContext, HttpContext.CurrentCustomerId(), TripLineType.Air).Id,
                                    SupplierId = Supplier.GetBspAgent(lazyContext, HttpContext.CurrentCustomerId(), TripLineType.Air).Id,
                                    IssueDate = DateTime.Today,
                                    PassengerId = q.TripLineAir.TripLine.Trip.TripPassengers.Single().Id,
                                    AirlineId = q.TripLineAir.TripLine.TripLineAir.AirlineId,
                                    FormOfPaymentId = -1,
                                    SaleTypeId = -1,
                                    DiscountReasonId = -1,
                                    OverrideBasis = OverrideBasis.None,
                                    MarkupStrategyId = -1,
                                    TicketNo = string.Empty,
                                    OriginalTicketNo = string.Empty,
                                    BspEntryType = BspEntryType.Ticket,
                                    TicketMethod = TicketMethod.ETicket,
                                    OfferedReasonId = -1
                                };

                                lazyContext.Insert(tripLineAirPassenger);
                            }

                            var tripLineAirPassengerAirSegment = lazyContext.TripLineAirPassengerAirSegment.SingleOrDefault(t => t.TripLineAirPassengerId == tripLineAirPassenger.Id && t.TripLineAirSegmentId == q.Id);

                            if (tripLineAirPassengerAirSegment == null) {
                                tripLineAirPassengerAirSegment = new TripLineAirPassengerAirSegment {
                                    Id = 0,
                                    TripLineAirPassengerId = tripLineAirPassenger.Id,
                                    TripLineAirSegmentId = q.Id,
                                    SeatNo = string.Empty,
                                    SeatStatus = SeatStatus.NotSpecified,
                                    BaggageAllowance = 0,
                                    BaggageUnit = BaggageUnit.Piece,
                                    FareBasis = string.Empty,
                                    TicketDesignator = string.Empty,
                                    TourCode = string.Empty
                                };

                                lazyContext.Insert(tripLineAirPassengerAirSegment);
                            }
                        }

                        q.TripLineAir.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                    }

                    var returnModel = new {
                        q.TripLineId,
                        TripLineAirSegmentId = q.Id,
                        TripLineAirPassengerAirSegmentCount = TripLineAirPassengerAirSegmentCommon.GetRows(lazyContext, q.TripLineId, -1, q.Id).Count,
                        TripDepartureDate = q.TripLineAir.TripLine.Trip.GetDepartureDate() == DateTime.MinValue ? q.TripLineAir.TripLine.Trip.DepartureDate : q.TripLineAir.TripLine.Trip.GetDepartureDate(),
                        TripReturnDate = q.TripLineAir.TripLine.Trip.GetReturnDate() == DateTime.MinValue ? (DateTime?)null : q.TripLineAir.TripLine.Trip.GetReturnDate()
                    };

                    ts.Complete();
                    return returnModel;
                }
            }
        }

        public bool Delete(AppLazyContext lazyContext, TripLineAirSegmentViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.TripLineAirSegment.Include(t => t.TripLineAirPassengerAirSegments).SingleOrDefault(t => t.Id == model.TripLineAirSegmentId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                var tripLine = q.TripLineAir.TripLine;

                if (lazyContext.Delete(q))
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                ts.Complete();
                return true;
            }
        }

        public bool Reorder(AppMainContext context, int tripLineId, int index, int direction) {
            using (var ts = Utils.CreateTransactionScope()) {
                int seqNo = 0;

                var q1 = context.TripLineAirSegment.Where(t => t.TripLineAir.TripLineId == tripLineId).OrderBy(t => t.SeqNo).ThenBy(t => t.Id).ToList().ConvertAll(row => new KeyValueModel {
                    Key = row.Id,
                    Value = seqNo++
                });

                seqNo = 0;

                foreach (var row in q1) {
                    if (seqNo == index) {
                        if (direction == 0) {
                            if (seqNo > 0) {
                                var q2 = q1.LastOrDefault(t => t.Value < seqNo);

                                if (q2 != null) {
                                    q2.Value = seqNo;
                                    row.Value = seqNo - 1;
                                }
                            }
                        }
                        else if (direction == 1) {
                            if (seqNo < q1.Count) {
                                var q2 = q1.Find(t => t.Value > seqNo);

                                if (q2 != null) {
                                    q2.Value = seqNo;
                                    row.Value = seqNo + 1;
                                }
                            }
                        }
                    }

                    seqNo++;
                }

                foreach (var row in q1) {
                    var q2 = context.TripLineAirSegment.Find(row.Key);

                    if (q2.SeqNo != row.Value + 1) {
                        q2.SeqNo = row.Value + 1;
                        context.Save(q2, false);
                    }
                }

                ts.Complete();
                return true;
            }
        }
    }

    public class TripLineAirPassengerCommon {
        private HttpContext HttpContext { get; }

        public TripLineAirPassengerCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public object CreateOrUpdate(TripLineAirPassengerViewModel model, CrsImportOption crsImportOption = CrsImportOption.UpdatePricingIncludingPaid, CountryZone? countryZone = null, bool isCrsImport = false) {
            if (model.PassengerId <= 0)
                throw new UnreportedException("Passenger is required.");

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    TripLineAirPassenger q = null;

                    if (model.TripLineAirPassengerId <= 0) {
                        q = new TripLineAirPassenger();
                    }
                    else {
                        q = lazyContext.TripLineAirPassenger.Find(model.TripLineAirPassengerId);
                    }

                    if (model.TicketNo?.Any(t => !char.IsLetterOrDigit(t)) ?? false)
                        throw new UnreportedException("Ticket No can only contain digits or letters.");

                    if (model.TicketNoConjunction?.Any(t => !char.IsDigit(t)) ?? false)
                        throw new UnreportedException("Ticket No Conjunction can only contain digits.");

                    bool updatePersonalTravelAmount = (model.TripLineAirPassengerId <= 0 && model.PersonalTravelAmount != 0) || (model.TripLineAirPassengerId > 0 && q.PersonalTravelAmount != model.PersonalTravelAmount);

                    string ticketNo = string.IsNullOrEmpty(model.TicketNo) && string.IsNullOrEmpty(model.TicketNoConjunction) ? string.Empty : (string.IsNullOrEmpty(model.TicketNoConjunction) ? model.TicketNo : string.Format("{0}/{1}", model.TicketNo, model.TicketNoConjunction)).ToUpper();
                    string originalTicketNo = string.Empty;

                    if (model.BspEntryType == BspEntryType.Exchange)
                        originalTicketNo = string.IsNullOrEmpty(model.OriginalTicketNo) && string.IsNullOrEmpty(model.OriginalTicketNoConjunction) ? string.Empty : (string.IsNullOrEmpty(model.OriginalTicketNoConjunction) ? model.OriginalTicketNo : string.Format("{0}/{1}", model.OriginalTicketNo, model.OriginalTicketNoConjunction)).ToUpper();

                    q.TripLineId = model.TripLineId;
                    q.TripLineAir = lazyContext.TripLineAir.Find(model.TripLineId);
                    q.PassengerId = model.PassengerId ?? 0;
                    q.Passenger = lazyContext.Passenger.Find(model.PassengerId ?? 0);
                    q.AirlineId = model.TripLineAirPassengerAirlineId ?? 0;
                    q.Airline = lazyContext.Airline.Find(model.TripLineAirPassengerAirlineId ?? 0);
                    q.OverrideBasis = model.OverrideBasis;
                    q.TicketNo = ticketNo;
                    q.OriginalTicketNo = originalTicketNo;
                    q.ConnectingTicketNos = model.ConnectingTicketNos.ToStringExt();
                    q.BspEntryType = model.BspEntryType;
                    q.TicketMethod = model.TicketMethod;
                    q.OfferedReasonId = model.ClientAccountType == ClientAccountType.Client ? -1 : model.OfferedReasonId ?? 0;
                    q.Comments = model.Comments.ToStringExt();

                    if (q.IssueDate == DateTime.MinValue || !(isCrsImport && q.TripLineAir.Crs == Crs.Amadeus))
                        q.IssueDate = model.IssueDate ?? DateTime.MinValue;

                    int sign = q.BspEntryType == BspEntryType.Refund ? -1 : 1;

                    if (model.TripLineAirPassengerId <= 0 || (!q.TripLineAir.TripLine.Trip.IsLocked && (crsImportOption == CrsImportOption.UpdatePricingIncludingPaid || (crsImportOption == CrsImportOption.UpdatePricingExcludingPaid && q.GetAmountPaid(lazyContext) == 0)))) {
                        q.FullFare = sign * model.FullFare;
                        q.OfferedFare = model.ClientAccountType == ClientAccountType.Client ? 0 : sign * model.OfferedFare;
                        q.TicketedFare = sign * model.TicketedFare;
                        q.OverrideAmount = sign * model.OverrideAmount;
                        q.RemainderCommission = sign * model.RemainderCommission;
                        q.NonCommissionable = sign * model.NonCommissionable;
                        q.PersonalTravelAmount = sign * model.PersonalTravelAmount;

                        q.CreditorId = model.CreditorId ?? 0;
                        q.Creditor = lazyContext.Creditor.Find(model.CreditorId ?? 0);
                        q.SupplierId = model.SupplierId ?? 0;
                        q.Supplier = lazyContext.Supplier.Find(model.SupplierId ?? 0);
                        q.SaleTypeId = model.SaleTypeId ?? 0;
                        q.SaleType = lazyContext.SaleType.Find(model.SaleTypeId ?? 0);
                        q.FormOfPaymentId = model.FormOfPaymentId ?? 0;
                        q.FormOfPayment = lazyContext.FormOfPayment.Find(model.FormOfPaymentId ?? 0);

                        q.IsCreditCardDiscountApplicable = model.IsCreditCardDiscountApplicable;
                        q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;

                        q.Discount = sign * model.Discount;
                        q.DiscountReasonId = model.DiscountReasonId ?? 0;
                        q.DiscountReason = lazyContext.DiscountReason.Find(model.DiscountReasonId ?? 0);

                        q.Markup = sign * model.Markup;
                        q.MarkupStrategyId = model.MarkupStrategyId ?? 0;
                        q.MarkupStrategy = lazyContext.MarkupStrategy.Find(model.MarkupStrategyId ?? 0);

                        if (q.MarkupTax == 0 && q.SaleType.IsTaxApplicable) {
                            q.MarkupTax = Math.Round(q.Markup * CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), model.IssueDate ?? DateTime.MinValue), 2);
                        }
                        else {
                            q.MarkupTax = 0;
                        }

                        if (model.Commission == 0 && model.CommissionRate == 0) {
                            q.Commission = Math.Round(q.TicketedFare * q.Airline.GetCommissionRate(lazyContext, q.SaleTypeId, countryZone), 2);
                        }
                        else {
                            q.Commission = sign * model.Commission;
                        }

                        decimal cashAmount = 0;
                        decimal cashNonCommissionable = 0;
                        decimal creditCardAmount = 0;
                        decimal creditCardNonCommissionable = 0;

                        TripLineCommon.SetCashAndCreditCardAmounts(
                            formOfPaymentClass: q.FormOfPayment.FormOfPaymentClass,
                            isCreditCardDiscountApplicable: q.IsCreditCardDiscountApplicable,
                            isCreditCardMarkupApplicable: q.IncludeMarkupInCreditCardPayment,
                            amount: q.TicketedFare,
                            nonCommissionable: q.NonCommissionable,
                            discount: q.Discount,
                            markup: q.Markup,
                            cashAmount: ref cashAmount,
                            cashNonCommissionable: ref cashNonCommissionable,
                            creditCardAmount: ref creditCardAmount,
                            creditCardNonCommissionable: ref creditCardNonCommissionable
                        );

                        q.CashAmount = cashAmount;
                        q.CashNonCommissionable = cashNonCommissionable;
                        q.CreditCardAmount = creditCardAmount;
                        q.CreditCardNonCommissionable = creditCardNonCommissionable;

                        if (!isCrsImport && !TripLineCommon.ValidateCashAndCreditCardAmounts(q.FormOfPayment.FormOfPaymentClass, q.FormOfPaymentId, cashAmount, cashNonCommissionable, creditCardAmount, creditCardNonCommissionable))
                            throw new UnreportedException("Form of Payment Type is invalid.");
                    }

                    if (!isCrsImport && q.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross && q.Creditor.IsBspAgent)
                        throw new UnreportedException("Forms of Payment of type 'Pay Supplier Gross' are not permitted for this document.");

                    decimal costToClient = q.GetCostToClient(HttpContext.CurrentCustomerId());

                    if (!isCrsImport && ((costToClient > 0 && model.PersonalTravelAmount > costToClient) || (costToClient < 0 && model.PersonalTravelAmount < costToClient)))
                        throw new UnreportedException("Personal Amount cannot be greater than Cost to Client.");

                    bool result;

                    if (q.Id <= 0) {
                        result = lazyContext.Insert(q);
                    }
                    else {
                        result = lazyContext.Save(q);
                    }

                    model.TripLineAirPassengerId = q.Id;

                    if (result) {
                        if (updatePersonalTravelAmount)
                            q.TripLineAir.TripLine.PersonalTravelAmount = lazyContext.TripLineAirPassenger.Where(t => t.TripLineId == model.TripLineId).Sum(t => (decimal?)t.PersonalTravelAmount) ?? 0;

                        q.TripLineAir.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);
                    }

                    var returnModel = new {
                        q.TripLineId,
                        TripLineAirPassengerId = q.Id,
                        TripLineAirPassengerAirSegmentCount = TripLineAirPassengerAirSegmentCommon.GetRows(lazyContext, q.TripLineId, q.Id, -1).Count,
                        q.TripLineAir.TripLine.PersonalTravelAmount,
                        q.Commission,
                        q.TripLineAir.TripLine.Trip.IsLocked
                    };

                    ts.Complete();
                    return returnModel;
                }
            }
        }

        public bool Delete(AppLazyContext lazyContext, TripLineAirPassengerViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.TripLineAirPassenger.Include(t => t.TripLineAirPassengerAirSegments).SingleOrDefault(t => t.Id == model.TripLineAirPassengerId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (q.TripLineAir.TripLine.Trip.IsLocked)
                    throw new UnreportedException(AppConstants.RecordIsLockedCannotDelete);

                var tripLine = q.TripLineAir.TripLine;

                if (lazyContext.Delete(q))
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                ts.Complete();
                return true;
            }
        }
    }

    public class TripLineAirPassengerAirSegmentCommon {
        private HttpContext HttpContext { get; }

        public TripLineAirPassengerAirSegmentCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public static List<TripLineAirPassengerAirSegmentViewModel> GetRows(AppMainContext context, int tripLineId, int tripLineAirPassengerId, int tripLineAirSegmentId, bool assignedRowsOnly = false) {
            var q = (from t1 in context.TripLineAirPassenger.Where(t => t.Id > 0 && t.TripLineId == tripLineId && (tripLineAirPassengerId == -1 || t.Id == tripLineAirPassengerId))
                     from t2 in context.TripLineAirPassengerAirSegment.Where(t => t.TripLineAirPassengerId == t1.Id && t.TripLineAirSegmentId == tripLineAirSegmentId).DefaultIfEmpty()
                     from t3 in context.TripLineAirSegment.Where(t => t.Id > 0 && t.TripLineId == tripLineId && (tripLineAirSegmentId == -1 || t.Id == tripLineAirSegmentId))
                     from t4 in context.TripLineAirPassengerAirSegment.Where(t => t.TripLineAirSegmentId == t3.Id && t.TripLineAirPassengerId == tripLineAirPassengerId).DefaultIfEmpty()
                     orderby (tripLineAirSegmentId == -1 ? t3.SeqNo : t1.Passenger.Trip == null ? 0 : t1.Passenger.Trip.FirstName.ToLower() == t1.Passenger.FirstName.ToLower() && t1.Passenger.Trip.LastName.ToLower() == t1.Passenger.LastName.ToLower() ? 0 : 1), (tripLineAirPassengerId == -1 ? string.Empty : t1.Passenger.LastName), (tripLineAirPassengerId == -1 ? string.Empty : t1.Passenger.FirstName), (tripLineAirPassengerId == -1 ? string.Empty : t1.Passenger.Title)
                     select new TripLineAirPassengerAirSegmentViewModel {
                         TripLineAirPassengerAirSegmentId = t2 == null ? t4 == null ? -1 : t4.Id : t2.Id,
                         TripLineAirPassengerId = t2 == null ? t1.Id : t2.TripLineAirPassengerId,
                         TripLineAirPassenger = string.Concat(string.Concat(t1.Passenger.Title, " ", t1.Passenger.FirstName, " ", t1.Passenger.LastName).Trim(), t1.TicketNo.Length == 0 ? string.Empty : string.Concat(" [", t1.TicketNo, "]")),
                         TripLineAirSegmentId = t4 == null ? t3.Id : t4.TripLineAirSegmentId,
                         TripLineAirSegment = string.Concat(t3.DepartureCity.Code, "/", t3.ArrivalCity.Code, t3.DepartureDate != context.VoidDate && t3.FlightNo.Length == 0 ? string.Empty : string.Concat(" [", t3.DepartureDate == context.VoidDate ? "ARNK" : t3.FlightNo, "]")),
                         TripLineAirPassengerTicketNo = t1.TicketNo,
                         Class = t3.Class,
                         GroupNo = t2 == null ? t4 == null ? 0 : t4.GroupNo : t2.GroupNo,
                         SeatNo = t2 == null ? t4.SeatNo : t2.SeatNo,
                         SeatStatus = t2 == null ? t4 == null ? SeatStatus.NotSpecified : t4.SeatStatus : t2.SeatStatus,
                         BaggageAllowance = t2 == null ? t4 == null ? 0 : t4.BaggageAllowance : t2.BaggageAllowance,
                         BaggageUnit = t2 == null ? t4 == null ? BaggageUnit.Piece : t4.BaggageUnit : t2.BaggageUnit,
                         FareBasis = t2 == null ? t4 == null ? string.Empty : t4.FareBasis : t2.FareBasis,
                         TicketDesignator = t2 == null ? t4 == null ? string.Empty : t4.TicketDesignator : t2.TicketDesignator,
                         TourCode = t2 == null ? t4 == null ? string.Empty : t4.TourCode : t2.TourCode,
                         TripLineAirPassengerAirSegmentAmount = t2 == null ? t4 == null ? 0 : t4.Amount : t2.Amount,
                         TripLineAirPassengerAirSegmentTax = t2 == null ? t4 == null ? 0 : t4.Tax : t2.Tax,
                         LastWriteTime = t1.LastWriteTime.ToLocalTime(),
                         CreationTime = t1.CreationTime.ToLocalTime(),
                         LastWriteUser = t1.LastWriteUser,
                         CreationUser = t1.CreationUser
                     }).ToList();

            if (assignedRowsOnly)
                q = q.Where(t => t.TripLineAirPassengerAirSegmentId > 0).ToList();

            int i = 0;

            foreach (var row in q) {
                if (row.TripLineAirPassengerAirSegmentId == -1) {
                    i--;
                    row.TripLineAirPassengerAirSegmentId = i;
                }
            }

            return q;
        }

        public TripLineAirPassengerAirSegmentViewModel CreateOrUpdate(TripLineAirPassengerAirSegmentViewModel model) {
            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    TripLineAirPassengerAirSegment q = null;

                    if (model.TripLineAirPassengerAirSegmentId <= 0) {
                        q = new TripLineAirPassengerAirSegment {
                            Id = 0,
                            TripLineAirPassengerId = model.TripLineAirPassengerId,
                            TripLineAirPassenger = lazyContext.TripLineAirPassenger.Find(model.TripLineAirPassengerId),
                            TripLineAirSegmentId = model.TripLineAirSegmentId,
                            TripLineAirSegment = lazyContext.TripLineAirSegment.Find(model.TripLineAirSegmentId),
                        };
                    }
                    else {
                        q = lazyContext.TripLineAirPassengerAirSegment.Find(model.TripLineAirPassengerAirSegmentId);
                    }

                    q.TripLineAirPassengerId = model.TripLineAirPassengerId;
                    q.TripLineAirSegmentId = model.TripLineAirSegmentId;
                    q.GroupNo = model.GroupNo ?? 0;
                    q.SeatNo = model.SeatNo.ToStringExt().ToUpper();
                    q.SeatStatus = model.SeatStatus;
                    q.BaggageAllowance = model.BaggageAllowance;
                    q.BaggageUnit = model.BaggageUnit;
                    q.FareBasis = model.FareBasis.ToStringExt();
                    q.TicketDesignator = model.TicketDesignator.ToStringExt();
                    q.TourCode = model.TourCode.ToStringExt();
                    q.Amount = model.TripLineAirPassengerAirSegmentAmount;
                    q.Tax = model.TripLineAirPassengerAirSegmentTax;

                    bool result;

                    if (q.Id <= 0) {
                        result = lazyContext.Insert(q);
                    }
                    else {
                        result = lazyContext.Save(q);
                    }

                    model.TripLineAirPassengerAirSegmentId = q.Id;
                    model.TripLineAirPassenger = q.TripLineAirPassenger.Passenger.FullName;
                    model.TripLineAirSegment = string.IsNullOrEmpty(q.TripLineAirSegment.FlightNo) ? string.Format("{0} - {1}", q.TripLineAirSegment.DepartureCity.Name, q.TripLineAirSegment.ArrivalCity.Name) : string.Format("{0} - {1} - {2}", q.TripLineAirSegment.FlightNo, q.TripLineAirSegment.DepartureCity.Name, q.TripLineAirSegment.ArrivalCity.Name);

                    if (result)
                        q.TripLineAirSegment.TripLineAir.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                    ts.Complete();
                    return model;
                }
            }
        }

        public bool UpdateSelections(AppMainContext context, int tripLineId, int tripLineAirPassengerId, int tripLineAirSegmentId, int[] tripLineAirPassengerAirSegmentIds) {
            using (var ts = Utils.CreateTransactionScope()) {
                foreach (var row in TripLineAirPassengerAirSegmentCommon.GetRows(context, tripLineId, tripLineAirPassengerId, tripLineAirSegmentId)) {
                    if (tripLineAirPassengerAirSegmentIds?.Any(t => t == row.TripLineAirPassengerAirSegmentId) == true) {
                        var q = context.TripLineAirPassengerAirSegment.SingleOrDefault(t => t.TripLineAirPassengerId == row.TripLineAirPassengerId && t.TripLineAirSegmentId == row.TripLineAirSegmentId);

                        if (q == null) {
                            q = new TripLineAirPassengerAirSegment {
                                Id = 0,
                                TripLineAirPassengerId = row.TripLineAirPassengerId,
                                TripLineAirSegmentId = row.TripLineAirSegmentId,
                                SeatNo = row.SeatNo.ToStringExt(),
                                SeatStatus = row.SeatStatus,
                                BaggageAllowance = row.BaggageAllowance,
                                BaggageUnit = row.BaggageUnit,
                                FareBasis = row.FareBasis.ToStringExt(),
                                TicketDesignator = row.TicketDesignator.ToStringExt(),
                                TourCode = row.TourCode.ToStringExt(),
                                Amount = row.TripLineAirPassengerAirSegmentAmount,
                                Tax = row.TripLineAirPassengerAirSegmentTax
                            };

                            context.Insert(q);
                        }
                    }
                    else if (tripLineAirPassengerAirSegmentIds?.Any(t => t == row.TripLineAirPassengerAirSegmentId) != true) {
                        var q = context.TripLineAirPassengerAirSegment.SingleOrDefault(t => t.TripLineAirPassengerId == row.TripLineAirPassengerId && t.TripLineAirSegmentId == row.TripLineAirSegmentId);
                        context.Delete(q);
                    }
                }

                ts.Complete();
                return true;
            }
        }
    }

    public class TripLineLandCommon {
        private HttpContext HttpContext { get; }

        public TripLineLandCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public object CreateOrUpdate(TripLineLandViewModel model, CrsImportOption crsImportOption = CrsImportOption.UpdatePricingIncludingPaid, bool calculateCommission = false) {
            if (model.SaleTypeId <= 0)
                throw new UnreportedException("Type of Sale is required.");

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    new TripLineCommon(HttpContext).CreateOrUpdate(lazyContext, model.TripLineViewModel);

                    if (model.SupplierServiceId == 0)
                        model.SupplierServiceId = -1;

                    TripLineLand q = null;

                    if (model.TripLineId <= 0) {
                        q = new TripLineLand();
                    }
                    else {
                        q = lazyContext.TripLineLand.Find(model.TripLineId);
                    }

                    q.TripLineId = model.TripLineViewModel.TripLineId;
                    q.TripLine = lazyContext.TripLine.Find(model.TripLineViewModel.TripLineId);
                    q.TripLine.Trip = lazyContext.Trip.Find(model.TripLineViewModel.TripId);
                    q.TripStatus = model.TripStatus;
                    q.SupplierChainId = model.SupplierChainId ?? 0;
                    q.SupplierCityCode = model.SupplierCityCode.ToStringExt();
                    q.SupplierCrsCode = model.SupplierCrsCode.ToStringExt();
                    q.ConfirmationNo = model.ConfirmationNo.ToStringExt();
                    q.DocumentNo = model.DocumentNo.ToStringExt();
                    q.Crs = model.TripLineLandCrs;
                    q.CrsPnrRef = model.TripLineLandCrsPnrRef.ToStringExt();
                    q.BookingPnr = model.BookingPnr.ToStringExt();
                    q.Duration = model.Duration;
                    q.DurationCoverageType = model.DurationCoverageType;
                    q.SupplierName = model.SupplierName;
                    q.SupplierAddress1 = model.SupplierAddress1.ToStringExt();
                    q.SupplierAddress2 = model.SupplierAddress2.ToStringExt();
                    q.SupplierLocality = model.SupplierLocality.ToStringExt();
                    q.SupplierRegion = model.SupplierRegion.ToStringExt();
                    q.SupplierPostCode = model.SupplierPostCode.ToStringExt();
                    q.SupplierCountryCode = model.SupplierCountryCode.ToStringExt();
                    q.SupplierContactTitle = model.SupplierContactTitle.ToStringExt();
                    q.SupplierContactName = model.SupplierContactName.ToStringExt();
                    q.SupplierContactPhoneHome = model.SupplierContactPhoneHome.ToStringExt();
                    q.SupplierContactPhoneWork = model.SupplierContactPhoneWork.ToStringExt();
                    q.SupplierContactMobile = model.SupplierContactMobile.ToStringExt();
                    q.SupplierContactFax = model.SupplierContactFax.ToStringExt();
                    q.SupplierContactEmail = model.SupplierContactEmail.ToStringExt();
                    q.StartDate = model.StartDate ?? DateTime.MinValue;
                    q.StartTime = model.StartTime.ToStringExt();
                    q.StartDetails = model.StartDetails.ToStringExt();
                    q.StartAddress1 = model.StartAddress1.ToStringExt();
                    q.StartAddress2 = model.StartAddress2.ToStringExt();
                    q.StartLocality = model.StartLocality.ToStringExt();
                    q.StartRegion = model.StartRegion.ToStringExt();
                    q.StartPostCode = model.StartPostCode.ToStringExt();
                    q.StartCountryCode = model.StartCountryCode.ToStringExt();
                    q.EndDate = model.EndDate ?? DateTime.MinValue;
                    q.EndTime = model.EndTime.ToStringExt();
                    q.EndDetails = model.EndDetails.ToStringExt();
                    q.EndAddress1 = model.EndAddress1.ToStringExt();
                    q.EndAddress2 = model.EndAddress2.ToStringExt();
                    q.EndLocality = model.EndLocality.ToStringExt();
                    q.EndRegion = model.EndRegion.ToStringExt();
                    q.EndPostCode = model.EndPostCode.ToStringExt();
                    q.EndCountryCode = model.EndCountryCode.ToStringExt();
                    q.ServiceDescription = model.ServiceDescription.ToStringExt().Left(50).Trim();
                    q.SupplierServiceId = model.SupplierServiceId;
                    q.SupplierServiceDescription = model.SupplierServiceDescription.ToStringExt().Left(50).Trim();
                    q.SupplierServiceRateDetailId = model.SupplierServiceRateDetailId;
                    q.SupplierServiceRateDetailDescription = model.SupplierServiceRateDetailDescription.ToStringExt().Left(50).Trim();
                    q.PaymentDueDate = model.PaymentDueDate ?? DateTime.MinValue;
                    q.OfferedReasonId = model.TripLineViewModel.ClientAccountType == ClientAccountType.Client ? -1 : model.OfferedReasonId ?? 0;
                    q.AllowPassengerInvoicing = model.AllowPassengerInvoicing;
                    q.Inclusions = Utils.ValidateHtmlTags(model.Inclusions.ToStringExt());
                    q.Comments = model.Comments.ToStringExt();
                    q.RateCost = model.RateCost;

                    if (model.TripLineId <= 0 || (!q.TripLine.Trip.IsLocked && (crsImportOption == CrsImportOption.UpdatePricingIncludingPaid || (crsImportOption == CrsImportOption.UpdatePricingExcludingPaid && q.TripLine.AmountPaid == 0)))) {
                        q.CurrencyId = model.CurrencyId ?? 0;
                        q.ForeignAmount = model.ForeignAmount;
                        q.ExchangeRate = model.ExchangeRate;

                        q.OfferedFare = model.TripLineViewModel.ClientAccountType == ClientAccountType.Client ? 0 : model.OfferedFare;
                        q.NonCommissionable = model.NonCommissionable;
                        q.RemainderCommission = model.RemainderCommission;

                        q.ServiceTypeRateBasisId = model.ServiceTypeRateBasisId ?? 0;
                        q.ServiceTypeRateBasis = lazyContext.ServiceTypeRateBasis.Find(model.ServiceTypeRateBasisId ?? 0);

                        q.PassengerClassification = model.PassengerClassification;
                        q.PayForDuration = model.PayForDuration;

                        q.CreditorId = model.CreditorId ?? 0;
                        q.Creditor = lazyContext.Creditor.Find(q.CreditorId);

                        q.SupplierId = model.SupplierId ?? 0;
                        q.Supplier = lazyContext.Supplier.Find(q.SupplierId);

                        q.SaleTypeId = model.SaleTypeId ?? 0;
                        q.SaleType = lazyContext.SaleType.Find(q.SaleTypeId);

                        q.FormOfPaymentId = model.FormOfPaymentId ?? 0;
                        q.FormOfPayment = lazyContext.FormOfPayment.Find(q.FormOfPaymentId);

                        q.IsCreditCardDiscountApplicable = model.IsCreditCardDiscountApplicable;
                        q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;

                        q.Discount = model.Discount;
                        q.DiscountReasonId = model.DiscountReasonId ?? 0;

                        q.Markup = model.Markup;
                        q.MarkupStrategyId = model.MarkupStrategyId ?? 0;

                        if (calculateCommission) {
                            q.Commission = Math.Round((q.Gross - q.NonCommissionable) * q.GetCommissionRate(), 2);
                        }
                        else {
                            q.Commission = model.Commission;
                        }

                        decimal cashAmount = 0;
                        decimal cashNonCommissionable = 0;
                        decimal creditCardAmount = 0;
                        decimal creditCardNonCommissionable = 0;

                        TripLineCommon.SetCashAndCreditCardAmounts(
                            formOfPaymentClass: q.FormOfPayment.FormOfPaymentClass,
                            isCreditCardDiscountApplicable: q.IsCreditCardDiscountApplicable,
                            isCreditCardMarkupApplicable: q.IncludeMarkupInCreditCardPayment,
                            amount: q.CommissionableValue,
                            nonCommissionable: q.NonCommissionable,
                            discount: q.Discount,
                            markup: q.Markup,
                            cashAmount: ref cashAmount,
                            cashNonCommissionable: ref cashNonCommissionable,
                            creditCardAmount: ref creditCardAmount,
                            creditCardNonCommissionable: ref creditCardNonCommissionable
                        );

                        if (!TripLineCommon.ValidateCashAndCreditCardAmounts(q.FormOfPayment.FormOfPaymentClass, q.FormOfPaymentId, cashAmount, cashNonCommissionable, creditCardAmount, creditCardNonCommissionable))
                            throw new UnreportedException("Form of Payment Type is invalid.");

                        q.CashAmount = cashAmount;
                        q.CashNonCommissionable = cashNonCommissionable;
                        q.CreditCardAmount = creditCardAmount;
                        q.CreditCardNonCommissionable = creditCardNonCommissionable;

                        SetPricing(lazyContext, model, q);
                    }

                    decimal costToClient = q.GetCostToClient(HttpContext.CurrentCustomerId());

                    if ((costToClient > 0 && model.TripLineViewModel.PersonalTravelAmount > costToClient) || (costToClient < 0 && model.TripLineViewModel.PersonalTravelAmount < costToClient))
                        throw new UnreportedException("Personal Amount cannot be greater than Cost to Client.");

                    bool result;

                    if (model.TripLineId <= 0) {
                        result = lazyContext.Insert(q);
                    }
                    else {
                        result = lazyContext.Save(q);
                    }

                    model.TripLineId = q.TripLineId;

                    if (result)
                        q.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                    if (q.TripLine.Trip.IsBooking && !q.TripLine.IsBooking)
                        TripLineSelectionCommon.Add(lazyContext, HttpContext.User, HttpContext.CurrentCustomerId(), q.TripLine.TripId, new int[] { q.TripLineId }, 0);

                    TripCommon.UpdateDepartureReturnDates(lazyContext, q.TripLine.TripId);

                    var returnModel = new {
                        q.TripLineId,
                        q.Commission,
                        q.TripLine.Trip.IsLocked,
                        TripDepartureDate = q.TripLine.Trip.DepartureDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.DepartureDate,
                        TripReturnDate = q.TripLine.Trip.ReturnDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.ReturnDate
                    };

                    ts.Complete();
                    return returnModel;
                }
            }
        }

        public static void SetPricing(AppMainContext context, TripLineLandViewModel model, TripLineLand tripLineLand) {
            tripLineLand.TripLine.Trip.UpdatePassengerCount(context);

            if (tripLineLand.ServiceTypeRateBasisId == (int)ServiceTypeRateBasisBase.AccommodationPerRoom)
                model.PassengerClassification = PassengerClassification.Group;

            if (model.PassengerClassification == PassengerClassification.Group) {
                model.PaxChildNo = 0;
                model.PaxChildRate = 0;
                model.PaxChildQty = 0;
                model.PaxInfantNo = 0;
                model.PaxInfantRate = 0;
                model.PaxInfantQty = 0;
            }

            tripLineLand.PaxAdultRate = model.PaxAdultRate;
            tripLineLand.PaxChildRate = model.PaxChildRate;
            tripLineLand.PaxInfantRate = model.PaxInfantRate;

            if (tripLineLand.ServiceTypeRateBasis.IsPaxNoApplicable) {
                if (model.PaxAdultNo <= 0)
                    model.PaxAdultNo = 1;

                tripLineLand.PaxAdultNo = model.PaxAdultNo;
                tripLineLand.PaxAdultQty = 0;
                tripLineLand.PaxChildNo = model.PaxChildNo;
                tripLineLand.PaxChildQty = 0;
                tripLineLand.PaxInfantNo = model.PaxInfantNo;
                tripLineLand.PaxInfantQty = 0;
            }
            else {
                tripLineLand.PaxAdultNo = tripLineLand.TripLine.Trip.PaxAdult;
                tripLineLand.PaxAdultQty = model.PaxAdultQty;
                tripLineLand.PaxChildNo = tripLineLand.TripLine.Trip.PaxChild;
                tripLineLand.PaxChildQty = model.PaxChildQty;
                tripLineLand.PaxInfantNo = tripLineLand.TripLine.Trip.PaxInfant;
                tripLineLand.PaxInfantQty = model.PaxInfantQty;
            }
        }
    }

    public class TripLineInsuranceCommon {
        private HttpContext HttpContext { get; }

        public TripLineInsuranceCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public object CreateOrUpdate(TripLineInsuranceViewModel model) {
            if (model.SaleTypeId <= 0)
                throw new UnreportedException("Type of Sale is required.");

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    new TripLineCommon(HttpContext).CreateOrUpdate(lazyContext, model.TripLineViewModel);
                    TripLineInsurance q = null;

                    if (model.TripLineId <= 0) {
                        q = new TripLineInsurance();
                    }
                    else {
                        q = lazyContext.TripLineInsurance.Find(model.TripLineId);
                    }

                    q.TripLineId = model.TripLineViewModel.TripLineId;
                    q.TripLine = lazyContext.TripLine.Find(model.TripLineViewModel.TripLineId);
                    q.TripLine.Trip = lazyContext.Trip.Find(model.TripLineViewModel.TripId);
                    q.TripType = model.TripType;
                    q.PolicyNo = model.PolicyNo.ToUpper();
                    q.StartDate = model.StartDate;
                    q.EndDate = model.EndDate;
                    q.InsurancePolicyId = model.InsurancePolicyId ?? 0;
                    q.InsurancePolicyPlanId = model.InsurancePolicyPlanId ?? 0;
                    q.InsurancePolicyCoverage = model.InsurancePolicyCoverage;
                    q.AllowPassengerInvoicing = model.AllowPassengerInvoicing;

                    if (!q.TripLine.Trip.IsLocked) {
                        q.PolicyValue = model.PolicyValue;
                        q.AmountAlreadyPaid = model.AmountAlreadyPaid;
                        q.Commission = model.Commission;

                        q.CreditorId = model.CreditorId ?? 0;
                        q.Creditor = lazyContext.Creditor.Find(q.CreditorId);

                        q.SupplierId = model.SupplierId ?? 0;
                        q.Supplier = lazyContext.Supplier.Find(q.SupplierId);

                        q.SaleTypeId = model.SaleTypeId ?? 0;
                        q.SaleType = lazyContext.SaleType.Find(q.SaleTypeId);

                        q.FormOfPaymentId = model.FormOfPaymentId ?? 0;
                        q.FormOfPayment = lazyContext.FormOfPayment.Find(q.FormOfPaymentId);

                        q.IsCreditCardDiscountApplicable = model.IsCreditCardDiscountApplicable;
                        q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;

                        q.Discount = model.Discount;
                        q.DiscountReasonId = model.DiscountReasonId ?? 0;

                        q.Markup = model.Markup;
                        q.MarkupStrategyId = model.MarkupStrategyId ?? 0;

                        decimal cashAmount = 0;
                        decimal cashNonCommissionable = 0;
                        decimal creditCardAmount = 0;
                        decimal creditCardNonCommissionable = 0;

                        TripLineCommon.SetCashAndCreditCardAmounts(
                            formOfPaymentClass: q.FormOfPayment.FormOfPaymentClass,
                            isCreditCardDiscountApplicable: q.IsCreditCardDiscountApplicable,
                            isCreditCardMarkupApplicable: q.IncludeMarkupInCreditCardPayment,
                            amount: q.PolicyValue + q.TotalCommissionableSurcharge,
                            nonCommissionable: q.TotalNonCommissionableSurcharge,
                            discount: q.Discount,
                            markup: q.Markup,
                            cashAmount: ref cashAmount,
                            cashNonCommissionable: ref cashNonCommissionable,
                            creditCardAmount: ref creditCardAmount,
                            creditCardNonCommissionable: ref creditCardNonCommissionable
                        );

                        if (!TripLineCommon.ValidateCashAndCreditCardAmounts(q.FormOfPayment.FormOfPaymentClass, q.FormOfPaymentId, cashAmount, cashNonCommissionable, creditCardAmount, creditCardNonCommissionable))
                            throw new UnreportedException("Form of Payment Type is invalid.");

                        q.CashAmount = cashAmount;
                        q.CashNonCommissionable = cashNonCommissionable;
                        q.CreditCardAmount = creditCardAmount;
                        q.CreditCardNonCommissionable = creditCardNonCommissionable;
                    }

                    decimal costToClient = q.GetCostToClient(HttpContext.CurrentCustomerId());

                    if ((costToClient > 0 && model.TripLineViewModel.PersonalTravelAmount > costToClient) || (costToClient < 0 && model.TripLineViewModel.PersonalTravelAmount < costToClient))
                        throw new UnreportedException("Personal Amount cannot be greater than Cost to Client.");

                    bool result;

                    if (model.TripLineId <= 0) {
                        result = lazyContext.Insert(q);

                        foreach (var row in lazyContext.Passenger.Where(t => t.TripId == q.TripLine.TripId).ToList()) {
                            var tripLineInsurancePassenger = new TripLineInsurancePassenger {
                                Id = 0,
                                TripLineId = q.TripLineId,
                                PassengerId = row.Id
                            };

                            lazyContext.Insert(tripLineInsurancePassenger);
                        }
                    }
                    else {
                        result = lazyContext.Save(q);
                    }

                    if (result)
                        q.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                    model.TripLineId = q.TripLineId;

                    if (q.TripLine.Trip.IsBooking && !q.TripLine.IsBooking)
                        TripLineSelectionCommon.Add(lazyContext, HttpContext.User, HttpContext.CurrentCustomerId(), q.TripLine.TripId, new int[] { q.TripLineId }, 0);

                    TripCommon.UpdateDepartureReturnDates(lazyContext, q.TripLine.TripId);

                    var returnModel = new {
                        q.TripLineId,
                        q.Commission,
                        q.TripLine.Trip.IsLocked,
                        TripDepartureDate = q.TripLine.Trip.DepartureDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.DepartureDate,
                        TripReturnDate = q.TripLine.Trip.ReturnDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.ReturnDate
                    };

                    ts.Complete();
                    return returnModel;
                }
            }
        }
    }

    public class TripLineInsurancePassengerCommon {
        private HttpContext HttpContext { get; }

        public TripLineInsurancePassengerCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public int CreateOrUpdate(int passengerId, int parentId) {
            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    if (lazyContext.TripLineInsurancePassenger.Any(t => t.TripLineId == parentId && t.PassengerId == passengerId))
                        throw new UnreportedException("Passenger already exists.");

                    var q = new TripLineInsurancePassenger {
                        Id = 0,
                        TripLineId = parentId,
                        TripLineInsurance = lazyContext.TripLineInsurance.Find(parentId),
                        PassengerId = passengerId
                    };

                    bool result = lazyContext.Insert(q);

                    if (result)
                        q.TripLineInsurance.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                    ts.Complete();
                    return passengerId;
                }
            }
        }

        public bool Delete(AppLazyContext lazyContext, int passengerId, int tripLineInsurancePassengerId) {
            using (var ts = Utils.CreateTransactionScope()) {
                if (lazyContext.TripLineInsuranceSurcharge.Any(t => t.PassengerId == passengerId))
                    throw new UnreportedException("This passenger has has one or more surcharges assigned and cannot be deleted.");

                var q = lazyContext.TripLineInsurancePassenger.Find(tripLineInsurancePassengerId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                var tripLine = q.TripLineInsurance.TripLine;

                if (lazyContext.Delete(q))
                    tripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                ts.Complete();
                return true;
            }
        }
    }

    public class TripLineInsuranceSurchargeCommon {
        private HttpContext HttpContext { get; }

        public TripLineInsuranceSurchargeCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public int CreateOrUpdate(TripLineInsuranceSurchargeViewModel model, int parentId) {
            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                TripLineInsuranceSurcharge q = null;

                if (model.TripLineInsuranceSurchargeId <= 0) {
                    q = new TripLineInsuranceSurcharge();
                }
                else {
                    q = lazyContext.TripLineInsuranceSurcharge.Find(model.TripLineInsuranceSurchargeId);
                }

                q.TripLineId = parentId;
                q.TripLineInsurance = lazyContext.TripLineInsurance.Find(parentId);
                q.PassengerId = model.PassengerId ?? 0;
                q.Name = model.Name.ToStringExt();

                q.TripLineInsurance = lazyContext.TripLineInsurance.Find(parentId);

                if (q.TripLineInsurance.TripLine.AmountPaid == 0) {
                    q.SurchargeType = model.SurchargeType;
                    q.SurchargeRateType = model.SurchargeRateType;
                    q.SurchargeRate = model.SurchargeRateType == SurchargeRateType.FixedAmount ? 0 : model.SurchargeRate;
                    q.Amount = model.SurchargeAmount;
                    q.IsCommissionable = model.IsCommissionable;
                }

                bool result;

                if (model.TripLineId <= 0) {
                    result = lazyContext.Insert(q);
                }
                else {
                    result = lazyContext.Save(q);
                }

                model.TripLineInsuranceSurchargeId = q.Id;

                if (result) {
                    decimal cashAmount = 0;
                    decimal cashNonCommissionable = 0;
                    decimal creditCardAmount = 0;
                    decimal creditCardNonCommissionable = 0;

                    TripLineCommon.SetCashAndCreditCardAmounts(
                        formOfPaymentClass: q.TripLineInsurance.FormOfPayment.FormOfPaymentClass,
                        isCreditCardDiscountApplicable: q.TripLineInsurance.SaleType.IsCreditCardDiscountApplicable,
                        isCreditCardMarkupApplicable: q.TripLineInsurance.Creditor.IncludeMarkupInCreditCardPayment,
                        amount: q.TripLineInsurance.PolicyValue + q.TripLineInsurance.TotalCommissionableSurcharge,
                        nonCommissionable: q.TripLineInsurance.TotalNonCommissionableSurcharge,
                        discount: q.TripLineInsurance.Discount,
                        markup: q.TripLineInsurance.Markup,
                        cashAmount: ref cashAmount,
                        cashNonCommissionable: ref cashNonCommissionable,
                        creditCardAmount: ref creditCardAmount,
                        creditCardNonCommissionable: ref creditCardNonCommissionable
                    );

                    if (!TripLineCommon.ValidateCashAndCreditCardAmounts(q.TripLineInsurance.FormOfPayment.FormOfPaymentClass, q.TripLineInsurance.FormOfPaymentId, cashAmount, cashNonCommissionable, creditCardAmount, creditCardNonCommissionable))
                        throw new UnreportedException("Form of Payment Type is invalid.");

                    q.TripLineInsurance.CashAmount = cashAmount;
                    q.TripLineInsurance.CashNonCommissionable = cashNonCommissionable;
                    q.TripLineInsurance.CreditCardAmount = creditCardAmount;
                    q.TripLineInsurance.CreditCardNonCommissionable = creditCardNonCommissionable;

                    lazyContext.Save(q.TripLineInsurance);
                }

                return model.TripLineInsuranceSurchargeId;
            }
        }

        public bool Delete(AppLazyContext lazyContext, TripLineInsuranceSurchargeViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.TripLineInsuranceSurcharge.Find(model.TripLineInsuranceSurchargeId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                var tripLineInsurance = q.TripLineInsurance;

                if (lazyContext.Delete(q)) {
                    decimal cashAmount = 0;
                    decimal cashNonCommissionable = 0;
                    decimal creditCardAmount = 0;
                    decimal creditCardNonCommissionable = 0;

                    TripLineCommon.SetCashAndCreditCardAmounts(
                        formOfPaymentClass: tripLineInsurance.FormOfPayment.FormOfPaymentClass,
                        isCreditCardDiscountApplicable: tripLineInsurance.SaleType.IsCreditCardDiscountApplicable,
                        isCreditCardMarkupApplicable: tripLineInsurance.Creditor.IncludeMarkupInCreditCardPayment,
                        amount: tripLineInsurance.PolicyValue + tripLineInsurance.TotalCommissionableSurcharge,
                        nonCommissionable: tripLineInsurance.TotalNonCommissionableSurcharge,
                        discount: tripLineInsurance.Discount,
                        markup: tripLineInsurance.Markup,
                        cashAmount: ref cashAmount,
                        cashNonCommissionable: ref cashNonCommissionable,
                        creditCardAmount: ref creditCardAmount,
                        creditCardNonCommissionable: ref creditCardNonCommissionable
                    );

                    if (!TripLineCommon.ValidateCashAndCreditCardAmounts(tripLineInsurance.FormOfPayment.FormOfPaymentClass, tripLineInsurance.FormOfPaymentId, cashAmount, cashNonCommissionable, creditCardAmount, creditCardNonCommissionable))
                        throw new UnreportedException("Form of Payment Type is invalid.");

                    tripLineInsurance.CashAmount = cashAmount;
                    tripLineInsurance.CashNonCommissionable = cashNonCommissionable;
                    tripLineInsurance.CreditCardAmount = creditCardAmount;
                    tripLineInsurance.CreditCardNonCommissionable = creditCardNonCommissionable;

                    lazyContext.Save(tripLineInsurance);
                }

                ts.Complete();
                return true;
            }
        }
    }

    public class TripLineForeignCurrencyCommon {
        private HttpContext HttpContext { get; }

        public TripLineForeignCurrencyCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public object CreateOrUpdate(TripLineForeignCurrencyViewModel model) {
            if (model.SaleTypeId <= 0)
                throw new UnreportedException("Type of Sale is required.");

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    new TripLineCommon(HttpContext).CreateOrUpdate(lazyContext, model.TripLineViewModel);
                    TripLineForeignCurrency q = null;

                    if (model.TripLineId <= 0) {
                        q = new TripLineForeignCurrency();
                    }
                    else {
                        q = lazyContext.TripLineForeignCurrency.Find(model.TripLineId);
                    }

                    q.TripLineId = model.TripLineViewModel.TripLineId;
                    q.TripLine = lazyContext.TripLine.Find(model.TripLineViewModel.TripLineId);
                    q.TripLine.Trip = lazyContext.Trip.Find(model.TripLineViewModel.TripId);
                    q.DocumentNo = model.DocumentNo.ToStringExt();
                    q.Description = model.Description.ToStringExt();
                    q.OfferedReasonId = model.TripLineViewModel.ClientAccountType == ClientAccountType.Client ? -1 : model.OfferedReasonId ?? 0;
                    q.AllowPassengerInvoicing = model.AllowPassengerInvoicing;

                    if (!q.TripLine.Trip.IsLocked) {
                        q.OfferedFare = model.TripLineViewModel.ClientAccountType == ClientAccountType.Client ? 0 : model.OfferedFare;
                        q.ForeignAmount = model.ForeignAmount;
                        q.ExchangeRate = model.ExchangeRate;
                        q.BankFee = model.BankFee;
                        q.ClientFee = model.ClientFee;

                        q.CreditorId = model.CreditorId ?? 0;
                        q.Creditor = lazyContext.Creditor.Find(q.CreditorId);

                        q.SupplierId = model.SupplierId ?? 0;
                        q.Supplier = lazyContext.Supplier.Find(q.SupplierId);

                        q.SaleTypeId = model.SaleTypeId ?? 0;
                        q.SaleType = lazyContext.SaleType.Find(q.SaleTypeId);

                        q.FormOfPaymentId = model.FormOfPaymentId ?? 0;
                        q.FormOfPayment = lazyContext.FormOfPayment.Find(q.FormOfPaymentId);

                        q.CurrencyId = model.CurrencyId ?? 0;
                        q.Currency = lazyContext.Currency.Find(q.CurrencyId);

                        q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;

                        q.Markup = model.Markup;
                        q.MarkupStrategyId = model.MarkupStrategyId ?? 0;

                        decimal cashAmount = 0;
                        decimal cashNonCommissionable = 0;
                        decimal creditCardAmount = 0;
                        decimal creditCardNonCommissionable = 0;

                        TripLineCommon.SetCashAndCreditCardAmounts(
                            formOfPaymentClass: q.FormOfPayment.FormOfPaymentClass,
                            isCreditCardDiscountApplicable: false,
                            isCreditCardMarkupApplicable: q.IncludeMarkupInCreditCardPayment,
                            amount: q.EquivalentValue + q.ClientFee,
                            nonCommissionable: 0,
                            discount: 0,
                            markup: q.Markup,
                            cashAmount: ref cashAmount,
                            cashNonCommissionable: ref cashNonCommissionable,
                            creditCardAmount: ref creditCardAmount,
                            creditCardNonCommissionable: ref creditCardNonCommissionable
                        );

                        if (!TripLineCommon.ValidateCashAndCreditCardAmounts(q.FormOfPayment.FormOfPaymentClass, q.FormOfPaymentId, cashAmount, cashNonCommissionable, creditCardAmount, creditCardNonCommissionable))
                            throw new UnreportedException("Form of Payment Type is invalid.");

                        q.CashAmount = cashAmount;
                        q.CashNonCommissionable = cashNonCommissionable;
                        q.CreditCardAmount = creditCardAmount;
                        q.CreditCardNonCommissionable = creditCardNonCommissionable;
                    }

                    decimal costToClient = q.CostToClient;

                    if ((costToClient > 0 && model.TripLineViewModel.PersonalTravelAmount > costToClient) || (costToClient < 0 && model.TripLineViewModel.PersonalTravelAmount < costToClient))
                        throw new UnreportedException("Personal Amount cannot be greater than Cost to Client.");

                    bool result;

                    if (model.TripLineId <= 0) {
                        result = lazyContext.Insert(q);
                    }
                    else {
                        result = lazyContext.Save(q);
                    }

                    model.TripLineId = q.TripLineId;

                    if (result)
                        q.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                    if (q.TripLine.Trip.IsBooking && !q.TripLine.IsBooking)
                        TripLineSelectionCommon.Add(lazyContext, HttpContext.User, HttpContext.CurrentCustomerId(), q.TripLine.TripId, new int[] { q.TripLineId }, 0);

                    TripCommon.UpdateDepartureReturnDates(lazyContext, q.TripLine.TripId);

                    var returnModel = new {
                        q.TripLineId,
                        q.Commission,
                        q.TripLine.Trip.IsLocked,
                        TripDepartureDate = q.TripLine.Trip.DepartureDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.DepartureDate,
                        TripReturnDate = q.TripLine.Trip.ReturnDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.ReturnDate
                    };

                    ts.Complete();
                    return returnModel;
                }
            }
        }
    }

    public class TripLineServiceFeeCommon {
        private HttpContext HttpContext { get; }

        public TripLineServiceFeeCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public object CreateOrUpdate(TripLineServiceFeeViewModel model) {
            if (model.SaleTypeId <= 0)
                throw new UnreportedException("Type of Sale is required.");

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    new TripLineCommon(HttpContext).CreateOrUpdate(lazyContext, model.TripLineViewModel);
                    TripLineServiceFee q = null;

                    if (model.TripLineId <= 0) {
                        q = new TripLineServiceFee();
                    }
                    else {
                        q = lazyContext.TripLineServiceFee.Find(model.TripLineId);
                    }

                    q.TripLineId = model.TripLineViewModel.TripLineId;
                    q.TripLine = lazyContext.TripLine.Find(model.TripLineViewModel.TripLineId);
                    q.TripLine.Trip = lazyContext.Trip.Find(model.TripLineViewModel.TripId);
                    q.ServiceFeePaymentType = model.ServiceFeePaymentType;
                    q.ServiceFeeTypeId = model.ServiceFeeTypeId ?? 0;
                    q.ServiceFeeType = lazyContext.ServiceFeeType.Find(model.ServiceFeeTypeId);
                    q.Crs = model.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? Crs.NotSpecified : model.TripLineServiceFeeCrs;
                    q.CrsPnrRef = model.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? string.Empty : model.TripLineServiceFeeCrsPnrRef.ToStringExt();
                    q.DocumentNo = model.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? string.Empty : model.DocumentNo.ToStringExt();
                    q.Description = model.Description.ToStringExt();
                    q.PassengerType = model.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? PassengerType.NotSpecified : model.PassengerType;
                    q.PaxNo = model.PaxNo;
                    q.OfferedReasonId = model.OfferedReasonId ?? 0;
                    q.AllowPassengerInvoicing = model.AllowPassengerInvoicing;

                    if (!q.TripLine.Trip.IsLocked) {
                        q.ItemCost = model.ItemCost;
                        q.Commission = model.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? Math.Round(q.Gross * q.GetCommissionRate() / 100, 2) : model.Commission;
                        q.OfferedFare = model.OfferedFare;

                        q.CreditorId = model.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? -1 : model.CreditorId ?? 0;
                        q.Creditor = lazyContext.Creditor.Find(q.CreditorId);

                        q.SupplierId = model.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? -1 : model.SupplierId ?? 0;
                        q.Supplier = lazyContext.Supplier.Find(q.SupplierId);

                        q.SaleTypeId = model.SaleTypeId ?? 0;
                        q.SaleType = lazyContext.SaleType.Find(q.SaleTypeId);

                        q.FormOfPaymentId = model.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? -1 : model.FormOfPaymentId ?? 0;
                        q.FormOfPayment = lazyContext.FormOfPayment.Find(q.FormOfPaymentId);

                        q.IncludeMarkupInCreditCardPayment = model.ServiceFeePaymentType == ServiceFeePaymentType.Supplier && model.IncludeMarkupInCreditCardPayment;

                        q.Markup = model.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? 0 : model.Markup;
                        q.MarkupStrategyId = model.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? -1 : model.MarkupStrategyId ?? 0;

                        decimal cashAmount = q.CashAmount;
                        decimal cashNonCommissionable = q.CashNonCommissionable;
                        decimal creditCardAmount = q.CreditCardAmount;
                        decimal creditCardNonCommissionable = q.CreditCardNonCommissionable;

                        TripLineCommon.SetCashAndCreditCardAmounts(
                            formOfPaymentClass: q.FormOfPayment.FormOfPaymentClass,
                            isCreditCardDiscountApplicable: false,
                            isCreditCardMarkupApplicable: q.IncludeMarkupInCreditCardPayment,
                            amount: q.ItemCost * q.PaxNo,
                            nonCommissionable: 0,
                            discount: 0,
                            markup: q.Markup,
                            cashAmount: ref cashAmount,
                            cashNonCommissionable: ref cashNonCommissionable,
                            creditCardAmount: ref creditCardAmount,
                            creditCardNonCommissionable: ref creditCardNonCommissionable
                        );

                        if (!TripLineCommon.ValidateCashAndCreditCardAmounts(q.FormOfPayment.FormOfPaymentClass, q.FormOfPaymentId, cashAmount, cashNonCommissionable, creditCardAmount, creditCardNonCommissionable))
                            throw new UnreportedException("Form of Payment Type is invalid.");

                        if (q.ServiceFeePaymentType == ServiceFeePaymentType.Agency) {
                            cashAmount += creditCardAmount;
                            cashNonCommissionable += creditCardNonCommissionable;
                            creditCardAmount = 0;
                            creditCardNonCommissionable = 0;
                        }

                        q.CashAmount = cashAmount;
                        q.CashNonCommissionable = cashNonCommissionable;
                        q.CreditCardAmount = creditCardAmount;
                        q.CreditCardNonCommissionable = creditCardNonCommissionable;
                    }

                    decimal costToClient = q.CostToClient;

                    if ((costToClient > 0 && model.TripLineViewModel.PersonalTravelAmount > costToClient) || (costToClient < 0 && model.TripLineViewModel.PersonalTravelAmount < costToClient))
                        throw new UnreportedException("Personal Amount cannot be greater than Cost to Client.");

                    bool result;

                    if (model.TripLineId <= 0) {
                        result = lazyContext.Insert(q);
                    }
                    else {
                        result = lazyContext.Save(q);
                    }

                    model.TripLineId = q.TripLineId;

                    if (q.TripLine.Trip.IsBooking && !q.TripLine.IsBooking)
                        TripLineSelectionCommon.Add(lazyContext, HttpContext.User, HttpContext.CurrentCustomerId(), q.TripLine.TripId, new int[] { q.TripLineId }, 0);

                    if (result)
                        q.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                    TripCommon.UpdateDepartureReturnDates(lazyContext, q.TripLine.TripId);

                    var returnModel = new {
                        q.TripLineId,
                        q.Commission,
                        q.TripLine.Trip.IsLocked,
                        TripDepartureDate = q.TripLine.Trip.DepartureDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.DepartureDate,
                        TripReturnDate = q.TripLine.Trip.ReturnDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.ReturnDate
                    };

                    ts.Complete();
                    return returnModel;
                }
            }
        }
    }

    public class TripLineOtherInclusionCommon {
        private HttpContext HttpContext { get; }

        public TripLineOtherInclusionCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public object CreateOrUpdate(TripLineOtherInclusionViewModel model) {
            if (model.SaleTypeId <= 0)
                throw new UnreportedException("Type of Sale is required.");

            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    new TripLineCommon(HttpContext).CreateOrUpdate(lazyContext, model.TripLineViewModel);
                    TripLineOtherInclusion q = null;

                    if (model.TripLineId <= 0) {
                        q = new TripLineOtherInclusion();
                    }
                    else {
                        q = lazyContext.TripLineOtherInclusion.Find(model.TripLineId);
                    }

                    q.TripLineId = model.TripLineViewModel.TripLineId;
                    q.TripLine = lazyContext.TripLine.Find(model.TripLineViewModel.TripLineId);
                    q.TripLine.Trip = lazyContext.Trip.Find(model.TripLineViewModel.TripId);
                    q.TripStatus = model.TripStatus;
                    q.StartDate = model.StartDate ?? DateTime.MinValue;
                    q.EndDate = model.EndDate ?? DateTime.MinValue;
                    q.Time = model.Time.ToStringExt();
                    q.DocumentNo = model.DocumentNo.ToStringExt();
                    q.Comments = model.Comments.ToStringExt();
                    q.PassengerType = model.PassengerType;
                    q.OfferedReasonId = model.OfferedReasonId ?? 0;
                    q.AllowPassengerInvoicing = model.AllowPassengerInvoicing;

                    if (!q.TripLine.Trip.IsLocked) {
                        q.PaxNo = model.PaxNo;
                        q.ItemCost = model.ItemCost;
                        q.Commission = model.Commission;
                        q.OfferedFare = model.OfferedFare;

                        q.Discount = model.Discount;
                        q.DiscountReasonId = model.DiscountReasonId ?? 0;

                        q.Markup = model.Markup;
                        q.MarkupStrategyId = model.MarkupStrategyId ?? 0;

                        q.CreditorId = model.CreditorId ?? 0;
                        q.Creditor = lazyContext.Creditor.Find(q.CreditorId);

                        q.SupplierId = model.SupplierId ?? 0;
                        q.Supplier = lazyContext.Supplier.Find(q.SupplierId);

                        q.SaleTypeId = model.SaleTypeId ?? 0;
                        q.SaleType = lazyContext.SaleType.Find(q.SaleTypeId);

                        q.FormOfPaymentId = model.FormOfPaymentId ?? 0;
                        q.FormOfPayment = lazyContext.FormOfPayment.Find(q.FormOfPaymentId);

                        q.IsCreditCardDiscountApplicable = model.IsCreditCardDiscountApplicable;
                        q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;

                        decimal cashAmount = 0;
                        decimal cashNonCommissionable = 0;
                        decimal creditCardAmount = 0;
                        decimal creditCardNonCommissionable = 0;

                        TripLineCommon.SetCashAndCreditCardAmounts(
                            formOfPaymentClass: q.FormOfPayment.FormOfPaymentClass,
                            isCreditCardDiscountApplicable: q.IsCreditCardDiscountApplicable,
                            isCreditCardMarkupApplicable: q.IncludeMarkupInCreditCardPayment,
                            amount: q.ItemCost * q.PaxNo,
                            nonCommissionable: 0,
                            discount: q.Discount,
                            markup: q.Markup,
                            cashAmount: ref cashAmount,
                            cashNonCommissionable: ref cashNonCommissionable,
                            creditCardAmount: ref creditCardAmount,
                            creditCardNonCommissionable: ref creditCardNonCommissionable
                        );

                        if (!TripLineCommon.ValidateCashAndCreditCardAmounts(q.FormOfPayment.FormOfPaymentClass, q.FormOfPaymentId, cashAmount, cashNonCommissionable, creditCardAmount, creditCardNonCommissionable))
                            throw new UnreportedException("Form of Payment Type is invalid.");

                        q.CashAmount = cashAmount;
                        q.CashNonCommissionable = cashNonCommissionable;
                        q.CreditCardAmount = creditCardAmount;
                        q.CreditCardNonCommissionable = creditCardNonCommissionable;
                    }

                    decimal costToClient = q.CostToClient;

                    if ((costToClient > 0 && model.TripLineViewModel.PersonalTravelAmount > costToClient) || (costToClient < 0 && model.TripLineViewModel.PersonalTravelAmount < costToClient))
                        throw new UnreportedException("Personal Amount cannot be greater than Cost to Client.");

                    bool result;

                    if (model.TripLineId <= 0) {
                        result = lazyContext.Insert(q);
                    }
                    else {
                        result = lazyContext.Save(q);
                    }

                    model.TripLineId = q.TripLineId;

                    if (result)
                        q.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                    if (q.TripLine.Trip.IsBooking && !q.TripLine.IsBooking)
                        TripLineSelectionCommon.Add(lazyContext, HttpContext.User, HttpContext.CurrentCustomerId(), q.TripLine.TripId, new int[] { q.TripLineId }, 0);

                    TripCommon.UpdateDepartureReturnDates(lazyContext, q.TripLine.TripId);

                    var returnModel = new {
                        q.TripLineId,
                        q.Commission,
                        q.TripLine.Trip.IsLocked,
                        TripDepartureDate = q.TripLine.Trip.DepartureDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.DepartureDate,
                        TripReturnDate = q.TripLine.Trip.ReturnDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.ReturnDate
                    };

                    ts.Complete();
                    return returnModel;
                }
            }
        }
    }

    public class TripLineRemarkCommon {
        private HttpContext HttpContext { get; }

        public TripLineRemarkCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public object CreateOrUpdate(TripLineRemarkViewModel model) {
            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    new TripLineCommon(HttpContext).CreateOrUpdate(lazyContext, model.TripLineViewModel);
                    TripLineRemark q = null;

                    if (model.TripLineId <= 0) {
                        q = new TripLineRemark();
                    }
                    else {
                        q = lazyContext.TripLineRemark.Find(model.TripLineId);
                    }

                    int relatedTripLineId = -1;
                    int relatedTripLineAirSegmentId = -1;

                    if (model.RelatedTripLineSegmentId != "-1") {
                        var array = model.RelatedTripLineSegmentId.Split('.');

                        if (model.RelatedTripLineSegmentId.StartsWith("1")) {
                            relatedTripLineId = array[1].ToInt();
                        }
                        else if (model.RelatedTripLineSegmentId.StartsWith("2")) {
                            relatedTripLineId = array[1].ToInt();
                            relatedTripLineAirSegmentId = array[2].ToInt();
                        }
                    }

                    q.TripLineId = model.TripLineViewModel.TripLineId;
                    q.Crs = model.TripLineRemarkCrs;
                    q.CrsPnrRef = model.TripLineRemarkCrsPnrRef.ToStringExt();
                    q.TripLine = lazyContext.TripLine.Find(model.TripLineViewModel.TripLineId);
                    q.TripLine.Trip = lazyContext.Trip.Find(model.TripLineViewModel.TripId);
                    q.StartDate = model.StartDate ?? DateTime.MinValue;
                    q.EndDate = model.EndDate ?? DateTime.MinValue;
                    q.Time = model.Time.ToStringExt();
                    q.RelatedTripLineId = relatedTripLineId;
                    q.RelatedTripLineAirSegmentId = relatedTripLineAirSegmentId;
                    q.PassengerId = model.PassengerId ?? 0;
                    q.Description = model.Description;
                    q.Remark = Utils.ValidateHtmlTags(model.Remark);
                    q.PrintAfterTotals = model.PrintAfterTotals;

                    bool result;

                    if (model.TripLineId <= 0) {
                        result = lazyContext.Insert(q);
                    }
                    else {
                        result = lazyContext.Save(q);
                    }

                    if (result)
                        q.TripLine.Update(HttpContext.User, HttpContext.CurrentCustomerId(), lazyContext);

                    model.TripLineId = q.TripLineId;

                    if (q.TripLine.Trip.IsBooking && !q.TripLine.IsBooking)
                        TripLineSelectionCommon.Add(lazyContext, HttpContext.User, HttpContext.CurrentCustomerId(), q.TripLine.TripId, new int[] { q.TripLineId }, 0);

                    if (relatedTripLineId > 0 || relatedTripLineAirSegmentId > 0) {
                        var tripLineSelection = lazyContext.TripLineSelection.Include(t => t.TripLine).ThenInclude(t => t.TripLineAir).AsQueryable();

                        if (relatedTripLineId > 0) {
                            tripLineSelection = tripLineSelection.Where(t1 => t1.TripLineId == relatedTripLineId);
                        }
                        else {
                            tripLineSelection = tripLineSelection.Where(t1 => lazyContext.TripLineAirSegment.Include(t => t.TripLineAir).Any(t2 => t2.Id == relatedTripLineAirSegmentId && t2.TripLineAir.TripLineId == t1.TripLineId));
                        }

                        foreach (var row in tripLineSelection.ToList()) {
                            TripLineSelectionCommon.Reorder(lazyContext, row.TripLine.TripId, row.QuoteNo, TripLineOrderType.None);
                        }
                    }

                    TripCommon.UpdateDepartureReturnDates(lazyContext, q.TripLine.TripId);

                    var returnModel = new {
                        q.TripLineId,
                        TripDepartureDate = q.TripLine.Trip.DepartureDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.DepartureDate,
                        TripReturnDate = q.TripLine.Trip.ReturnDate == DateTime.MinValue ? (DateTime?)null : q.TripLine.Trip.ReturnDate
                    };

                    ts.Complete();
                    return returnModel;
                }
            }
        }
    }

    public static class TripLineSelectionCommon {
        public static int Add(AppLazyContext lazyContext, IPrincipal principal, int customerId, int tripId, int[] tripLineIds, int quoteNo) {
            using (var ts = Utils.CreateTransactionScope()) {
                if (quoteNo == -1) {
                    var tripLineSelections = lazyContext.TripLineSelection.Where(t => t.TripLine.TripId == tripId && t.QuoteNo > 0).ToList();
                    quoteNo = tripLineSelections.Count == 0 ? 1 : tripLineSelections.Max(t => t.QuoteNo) + 1;
                }

                var tripLines = lazyContext.TripLine.Where(t => tripLineIds.Contains(t.Id)).OrderBy(t => t.Id).ToList();
                int seqNo = (lazyContext.TripLineSelection.Where(t => t.TripLine.TripId == tripId && t.QuoteNo == quoteNo).Max(t => (int?)t.SeqNo) ?? 0) + 1;

                foreach (var tripLine in tripLines) {
                    var tripLineSelection = lazyContext.TripLineSelection.SingleOrDefault(t => t.TripLineId == tripLine.Id && t.QuoteNo == quoteNo);

                    tripLineSelection ??= new TripLineSelection {
                        Id = 0,
                        TripLineId = tripLine.Id,
                        QuoteNo = quoteNo
                    };

                    tripLineSelection.SeqNo = seqNo;

                    if (tripLineSelection.Id <= 0) {
                        lazyContext.Insert(tripLineSelection, false);
                    }
                    else {
                        lazyContext.Save(tripLineSelection, false);
                    }

                    tripLine.Update(principal, customerId, lazyContext);
                    seqNo++;
                }

                if (quoteNo == 0) {
                    var trip = lazyContext.Trip.Find(tripId);

                    if (!trip.IsBooking) {
                        trip.IsBooking = true;
                        lazyContext.Save(trip, false);
                    }
                }

                ts.Complete();
                return quoteNo;
            }
        }

        public static bool Delete(AppLazyContext lazyContext, IPrincipal principal, int customerId, int tripId, int tripLineId, int quoteNo, int[] tripLineIds = null, bool validate = false) {
            if (tripLineIds == null || tripLineIds.Length == 0) {
                if (validate && quoteNo == 0 && tripLineId <= 0) {
                    if (lazyContext.TransactionDetail.Any(t => t.TripId == tripId))
                        throw new UnreportedException("This booking cannot been deleted because it has related transactions.");

                    if (lazyContext.Voucher.Any(t => t.TripId == tripId))
                        throw new UnreportedException("This booking cannot been deleted because it has vouchers assigned.");
                }

                if (tripLineId == -1) {
                    using (var ts = Utils.CreateTransactionScope()) {
                        foreach (var tripLineSelection in GetTripLineSelection(lazyContext, quoteNo, tripId).ToList()) {
                            lazyContext.Delete(tripLineSelection, false);
                        }

                        if (quoteNo == 0 && !lazyContext.TripLineSelection.Include(t => t.TripLine).Any(t => t.TripLine.TripId == tripId && t.QuoteNo == quoteNo)) {
                            var trip = lazyContext.Trip.Find(tripId);

                            if (trip != null) {
                                trip.IsBooking = false;
                                lazyContext.Save(trip, false);
                            }
                        }

                        ts.Complete();
                    }
                }
                else {
                    if (validate && quoteNo == 0) {
                        if (lazyContext.TripLine.Any(t => t.Id > 0 && t.Id == tripLineId && (t.AmountReceived != 0 || t.AmountPaid != 0 || t.AmountInvoiced != 0)))
                            throw new UnreportedException("This trip line cannot be removed from the booking because it has related transactions.");

                        if (lazyContext.Voucher.Any(t => t.TripLineId == tripLineId))
                            throw new UnreportedException("This trip line cannot be removed from the booking because it has a voucher assigned.");
                    }

                    var tripLineSelection = GetTripLineSelection(lazyContext, quoteNo, 0, tripLineId).SingleOrDefault();
                    var tripLine = tripLineSelection.TripLine;

                    lazyContext.Delete(tripLineSelection, false);
                    tripLine.Update(principal, customerId, lazyContext);
                }
            }
            else {
                if (validate && quoteNo == 0) {
                    if (lazyContext.TripLine.Any(t => t.Id > 0 && tripLineIds.Contains(t.Id) && (t.AmountReceived != 0 || t.AmountPaid != 0 || t.AmountInvoiced != 0)))
                        throw new UnreportedException("One or more trip lines cannot be removed from the booking because they have related transactions.");

                    if (lazyContext.Voucher.Any(t => tripLineIds.Contains(t.TripLineId)))
                        throw new UnreportedException("One or more trip lines cannot be removed from the booking because they have a voucher assigned.");
                }

                using (var ts = Utils.CreateTransactionScope()) {
                    var tripLines = lazyContext.TripLine.Where(t => tripLineIds.Contains(t.Id)).OrderBy(t => t.TripLineType == TripLineType.Remark ? 0 : 1);

                    foreach (var tripLine in tripLines) {
                        var tripLineSelection = GetTripLineSelection(lazyContext, quoteNo, 0, tripLine.Id).SingleOrDefault();

                        if (tripLineSelection != null)
                            lazyContext.Delete(tripLineSelection, false);

                        if (tripLine == null)
                            continue;

                        if (quoteNo == -1) {
                            var trip = tripLine.Trip;
                            lazyContext.Delete(tripLine, false);
                            trip.Update(principal, customerId, lazyContext);
                        }
                        else {
                            tripLine.Update(principal, customerId, lazyContext);
                        }
                    }

                    if (quoteNo == 0 && !lazyContext.TripLineSelection.Include(t => t.TripLine).Any(t => t.TripLine.TripId == tripId && t.QuoteNo == quoteNo)) {
                        var trip = lazyContext.Trip.Find(tripId);

                        if (trip != null) {
                            trip.IsBooking = false;
                            lazyContext.Save(trip, false);
                        }
                    }

                    ts.Complete();
                }
            }

            return true;
        }

        public static bool Reorder(AppLazyContext lazyContext, int tripId, int quoteNo, TripLineOrderType tripLineOrderType, int[] tripLineIds = null, bool isCrsImport = false) {
            var q = TripLineHelper.GetRows(lazyContext, tripId, quoteNo, 0, 0, 0, false, true);

            if (q.Count == 0)
                return false;

            if (tripLineOrderType == TripLineOrderType.StartDate)
                q = q.OrderBy(t => t.StartDate == DateTime.MinValue ? DateTime.MaxValue : t.StartDate).ThenByDescending(t => (t.EndDate - t.StartDate).Days).ToList();

            var tripLineIdList = new List<int>(q.Select(t => t.Id));

            if (tripLineIds != null && tripLineIds.Length > 0 && (tripLineOrderType == TripLineOrderType.Up || tripLineOrderType == TripLineOrderType.Down)) {
                if (tripLineOrderType == TripLineOrderType.Down) {
                    q.Reverse();
                    tripLineIdList.Reverse();
                }

                foreach (int tripLineId in q.Where(t => tripLineIds.Contains(t.Id)).Select(t => t.Id)) {
                    int index = q.FindIndex(t => t.Id == tripLineId);

                    if (index == 0)
                        return false;

                    var currentRow = q.ElementAt(index);
                    var newRow = q.ElementAt(index);

                    while (currentRow.TripLineType == TripLineType.Remark && currentRow.Id != currentRow.RelatedTripLineId && index > 0) {
                        index--;
                        currentRow = q.ElementAt(index);
                    }

                    tripLineIdList.Remove(currentRow.Id);

                    while ((newRow.RelatedTripLineId == currentRow.Id || (newRow.TripLineType == TripLineType.Remark && newRow.RelatedTripLineId > 0)) && index > 0) {
                        index--;
                        newRow = q.ElementAt(index);
                    }

                    tripLineIdList.Insert(index, currentRow.Id);
                }

                if (tripLineOrderType == TripLineOrderType.Down)
                    tripLineIdList.Reverse();
            }

            using (var ts = Utils.CreateTransactionScope()) {
                var tripLineSelections = lazyContext.TripLineSelection.Where(t => t.TripLine.TripId == tripId && t.QuoteNo == quoteNo).ToList();
                int seqNo = 1;

                foreach (int id in tripLineIdList) {
                    var tripLineSelection = lazyContext.TripLineSelection.Find(tripLineSelections.SingleOrDefault(t => t.TripLineId == id)?.Id ?? 0);

                    tripLineSelection ??= new TripLineSelection {
                        Id = 0,
                        TripLineId = id,
                        QuoteNo = quoteNo,
                        SeqNo = 0
                    };

                    if (tripLineSelection.SeqNo != seqNo) {
                        tripLineSelection.SeqNo = seqNo;

                        try {
                            if (tripLineSelection.Id <= 0) {
                                lazyContext.Insert(tripLineSelection);
                            }
                            else {
                                lazyContext.Save(tripLineSelection);
                            }
                        }
                        catch {
                            if (isCrsImport) {
                                ts.Complete();
                                throw new CrsException("CRS import failed.");
                            }

                            throw;
                        }
                    }

                    seqNo++;
                }

                ts.Complete();
                return true;
            }
        }

        public static bool Convert(AppMainContext context, int tripId, int quoteNo) {
            if (quoteNo == 0 && context.TransactionDetail.Any(t => t.TripId == tripId))
                throw new UnreportedException("This booking cannot be converted to a quote because it has related transactions.");

            using (var ts = Utils.CreateTransactionScope()) {
                var tripLineSelection = context.TripLineSelection.Include(t => t.TripLine).Where(t => t.TripLine.TripId == tripId).OrderBy(t => t.SeqNo).ToList();

                if (quoteNo == 0) {
                    int maxQuoteNo = (tripLineSelection.Count == 0 ? 0 : tripLineSelection.Max(t => t.QuoteNo)) + 1;

                    foreach (var row in tripLineSelection.Where(t => t.QuoteNo == 0)) {
                        var q = context.TripLineSelection.Find(row.Id);
                        q.QuoteNo = maxQuoteNo;
                        context.Save(q, false);
                    }
                }
                else if (quoteNo > 0) {
                    foreach (var row in tripLineSelection.Where(t => t.QuoteNo == quoteNo)) {
                        var q = context.TripLineSelection.Find(row.Id);
                        q.QuoteNo = 0;
                        context.Save(q, false);
                    }
                }

                var trip = context.Trip.Find(tripId);
                trip.IsBooking = quoteNo != 0;
                context.Save(trip);

                ts.Complete();
                return true;
            }
        }

        private static IQueryable<TripLineSelection> GetTripLineSelection(AppLazyContext lazyContext, int quoteNo, int tripId = 0, int tripLineId = 0) {
            var q = lazyContext.TripLineSelection.Include(t => t.TripLine).ThenInclude(t => t.Trip)
                .Include(t => t.TripLine).ThenInclude(t => t.TripLineAir).ThenInclude(t => t.TripLineAirSegments).ThenInclude(t => t.TripLineAirPassengerAirSegments)
                .Include(t => t.TripLine).ThenInclude(t => t.TripLineAir).ThenInclude(t => t.TripLineAirPassengers).ThenInclude(t => t.TripLineAirPassengerAirSegments)
                .Include(t => t.TripLine).ThenInclude(t => t.TripLineLand)
                .Include(t => t.TripLine).ThenInclude(t => t.TripLineInsurance).ThenInclude(t => t.TripLineInsurancePassengers)
                .Include(t => t.TripLine).ThenInclude(t => t.TripLineInsurance).ThenInclude(t => t.TripLineInsuranceSurcharges)
                .Include(t => t.TripLine).ThenInclude(t => t.TripLineForeignCurrency)
                .Include(t => t.TripLine).ThenInclude(t => t.TripLineServiceFee)
                .Include(t => t.TripLine).ThenInclude(t => t.TripLineOtherInclusion)
                .Include(t => t.TripLine).ThenInclude(t => t.TripLineRemark).AsQueryable();

            if (tripId == 0) {
                q = q.Where(t => t.TripLineId == tripLineId && t.QuoteNo == quoteNo);
            }
            else {
                q = q.Where(t => t.TripLine.TripId == tripId && t.QuoteNo == quoteNo);
            }

            return q.OrderBy(t => t.SeqNo);
        }
    }

    public class PassengerCommon {
        private HttpContext HttpContext { get; }

        public PassengerCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public object Create(AppMainContext context, int[] passengerIds, int profileId, int tripId) {
            using (var ts = Utils.CreateTransactionScope()) {
                foreach (int passengerId in passengerIds) {
                    int newProfileId = tripId > 0 ? -1 : profileId;
                    var passenger = context.Passenger.Find(passengerId);

                    var q = new Passenger {
                        Id = 0,
                        ProfileId = newProfileId,
                        TripId = tripId,
                        PassengerType = passenger.PassengerType,
                        Title = passenger.Title,
                        FirstName = passenger.FirstName,
                        LastName = passenger.LastName,
                        Alias = passenger.Alias,
                        DisplayName = passenger.DisplayName,
                        PhoneNo = passenger.PhoneNo,
                        Email = passenger.Email,
                        BirthDate = passenger.BirthDate,
                        Gender = passenger.Gender,
                        PassengerProfileId = newProfileId > 0 ? -1 : profileId,
                        ProfilePassengerId = -1,
                        CrsKey = string.Empty
                    };

                    q.Age = q.GetAge();
                    context.Insert(q);

                    foreach (var row in context.PassengerClubMembership.Where(t => t.Id > 0 && t.PassengerId == passengerId)) {
                        context.Insert(new PassengerClubMembership {
                            Id = 0,
                            PassengerId = q.Id,
                            ClubMembershipId = row.ClubMembershipId,
                            ClubMembershipNo = row.ClubMembershipNo,
                            AirlineId = row.AirlineId
                        });
                    }

                    foreach (var row in context.PassengerDocument.Where(t => t.Id > 0 && t.PassengerId == passengerId)) {
                        context.Insert(new PassengerDocument {
                            Id = 0,
                            PassengerId = q.Id,
                            DocumentType = row.DocumentType,
                            DocumentNo = row.DocumentNo,
                            IssueDate = row.IssueDate,
                            ExpiryDate = row.ExpiryDate,
                            PlaceOfIssue = row.PlaceOfIssue,
                            IssuingCountryId = row.IssuingCountryId,
                            NationalityId = row.NationalityId,
                            Comments = row.Comments
                        });
                    }

                    if (tripId > 0)
                        continue;

                    foreach (var row in context.ProfileAirline.Where(t => t.ProfileId == profileId && t.PassengerId == passengerId)) {
                        context.Insert(new ProfileAirline {
                            Id = 0,
                            ProfileId = row.ProfileId,
                            PassengerId = q.Id,
                            AirlineId = row.AirlineId,
                            AirlineSeating = row.AirlineSeating,
                            FlightClass = row.FlightClass,
                            TravelZone = row.TravelZone,
                            SeatNo = row.SeatNo,
                            Comments = row.Comments
                        });
                    }

                    foreach (var row in context.ProfileClubMembership.Where(t => t.ProfileId == profileId && t.PassengerId == passengerId)) {
                        context.Insert(new ProfileClubMembership {
                            Id = 0,
                            ProfileId = row.ProfileId,
                            PassengerId = q.Id,
                            ClubMembershipId = row.ClubMembershipId,
                            ClubMembershipNo = row.ClubMembershipNo,
                            ClubMembershipPin = row.ClubMembershipPin,
                            PointsEarned = row.PointsEarned,
                            Comments = row.Comments
                        });
                    }

                    foreach (var row in context.ProfileLeisureActivity.Where(t => t.ProfileId == profileId && t.PassengerId == passengerId)) {
                        context.Insert(new ProfileLeisureActivity {
                            Id = 0,
                            ProfileId = row.ProfileId,
                            PassengerId = q.Id,
                            LeisureActivityId = row.LeisureActivityId,
                            Comments = row.Comments
                        });
                    }

                    foreach (var row in context.ProfileSpecialRequest.Where(t => t.ProfileId == profileId && t.PassengerId == passengerId)) {
                        context.Insert(new ProfileSpecialRequest {
                            Id = 0,
                            ProfileId = row.ProfileId,
                            PassengerId = q.Id,
                            SpecialRequestId = row.SpecialRequestId,
                            Comments = row.Comments
                        });
                    }
                }

                int paxAdult = 0;
                int paxChild = 0;
                int paxInfant = 0;

                if (tripId > 0) {
                    var trip = context.Trip.Include(t => t.TripPassengers).Include(t => t.TripLines).ThenInclude(t => t.TripLineLand).ThenInclude(t => t.ServiceTypeRateBasis).Single(t => t.Id == tripId);
                    trip.UpdatePassengerCount(context);
                    paxAdult = trip.PaxAdult;
                    paxChild = trip.PaxChild;
                    paxInfant = trip.PaxInfant;
                }

                ts.Complete();
                return new { PaxAdult = paxAdult, PaxChild = paxChild, PaxInfant = paxInfant };
            }
        }

        public object CreateOrUpdate(PassengerViewModel model, bool updateRelatedProfilePassenger, bool isCrsImport = false) {
            using (var lazyContext = new AppLazyContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    Passenger q = null;

                    if (model.PassengerPassengerProfileId == 0)
                        model.PassengerPassengerProfileId = -1;

                    if (model.PassengerProfilePassengerId == 0)
                        model.PassengerProfilePassengerId = -1;

                    if (model.PassengerId <= 0) {
                        if (model.PassengerTripId > 0) {
                            q = new Passenger {
                                Id = 0,
                                ProfileId = -1,
                                TripId = model.PassengerTripId,
                                Trip = lazyContext.Trip.Find(model.PassengerTripId),
                                PassengerType = model.PassengerType,
                                BirthDate = model.PassengerBirthDate ?? DateTime.MinValue,
                                Age = model.PassengerAge,
                                ProfilePassengerId = model.PassengerProfilePassengerId
                            };
                        }
                        else {
                            q = new Passenger {
                                Id = 0,
                                ProfileId = model.PassengerProfileId,
                                TripId = -1,
                                Trip = lazyContext.Trip.Find(-1),
                                PassengerType = model.PassengerType,
                                BirthDate = model.PassengerBirthDate ?? DateTime.MinValue,
                                Age = model.PassengerAge,
                                ProfilePassengerId = -1
                            };
                        }

                        if (q.Age == 0) {
                            q.Age = q.GetAge();

                            if (q.PassengerType == PassengerType.NotSpecified)
                                q.PassengerType = q.GetPassengerType();

                            model.PassengerAge = q.Age;
                            model.PassengerType = q.PassengerType;
                        }
                    }
                    else {
                        q = lazyContext.Passenger.Find(model.PassengerId);

                        if ((model.PassengerBirthDate ?? DateTime.MinValue) != DateTime.MinValue && model.PassengerBirthDate != q.BirthDate) {
                            q.BirthDate = model.PassengerBirthDate ?? DateTime.MinValue;
                            q.Age = q.GetAge();
                            q.PassengerType = q.GetPassengerType();

                            model.PassengerBirthDate = q.BirthDate;
                            model.PassengerAge = q.Age;
                            model.PassengerType = q.PassengerType;
                        }
                        else {
                            q.Age = model.PassengerAge;
                        }
                    }

                    if (!isCrsImport) {
                        if (q.PassengerType == PassengerType.Infant && q.BirthDate == DateTime.MinValue)
                            throw new UnreportedException("Birth Date is required for Passenger Type 'Infant'.");

                        if (q.Trip.ProfileId > 0 && q.Trip.ProfileId == model.PassengerPassengerProfileId)
                            throw new UnreportedException("The trip's profile is the same as the profile you're linking to.");
                    }

                    if (q.ProfileId > 0 && model.PassengerPassengerProfileId > 0)
                        model.PassengerPassengerProfileId = -1;

                    q.PassengerType = model.PassengerType;
                    q.Alias = model.PassengerAlias.ToStringExt();
                    q.DisplayName = model.PassengerDisplayName.ToStringExt();
                    q.Gender = model.PassengerGender;
                    q.PassengerProfileId = model.PassengerPassengerProfileId == model.PassengerProfileId ? -1 : model.PassengerPassengerProfileId ?? 0;
                    q.CrsKey = model.CrsKey.ToStringExt();

                    if (!model.PassengerIsLocked) {
                        if (!lazyContext.ContactTitle.Any(t => t.Name == model.PassengerTitle))
                            model.PassengerTitle = string.Empty;

                        q.Title = model.PassengerTitle.ToStringExt();
                        q.FirstName = model.PassengerFirstName;
                        q.LastName = model.PassengerLastName;
                        q.PhoneNo = model.PassengerPhoneNo.ToStringExt();
                        q.Email = model.PassengerEmail.ToStringExt();
                        q.BirthDate = model.PassengerBirthDate ?? DateTime.MinValue;
                    }

                    if (q.Gender == Gender.NotSpecified && q.Title.Length > 0)
                        q.Gender = ContactTitle.GetContactTitle(lazyContext, q.Title, false).Gender;

                    bool result;

                    if (q.Id <= 0) {
                        result = lazyContext.Insert(q);
                    }
                    else {
                        result = lazyContext.Save(q);
                    }

                    model.PassengerId = q.Id;

                    if (result) {
                        if (q.TripId > 0)
                            q.Trip.UpdatePassengerCount(lazyContext);

                        if (updateRelatedProfilePassenger) {
                            var passenger = lazyContext.Passenger.Find(q.ProfilePassengerId);

                            passenger.PassengerType = model.PassengerType;
                            passenger.Title = q.Title;
                            passenger.FirstName = q.FirstName;
                            passenger.LastName = q.LastName;
                            passenger.Alias = q.Alias;
                            passenger.DisplayName = q.DisplayName;
                            passenger.PhoneNo = q.PhoneNo;
                            passenger.Email = q.Email;
                            passenger.BirthDate = q.BirthDate;
                            passenger.Age = q.Age;
                            passenger.Gender = q.Gender;

                            lazyContext.Save(passenger);
                        }
                    }

                    var returnModel = new {
                        PassengerId = q.Id,
                        q.PassengerType,
                        PassengerAge = q.Age,
                        q.Trip.PaxAdult,
                        q.Trip.PaxChild,
                        q.Trip.PaxInfant
                    };

                    ts.Complete();
                    return returnModel;
                }
            }
        }

        public Trip Delete(AppLazyContext lazyContext, PassengerViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q = lazyContext.Passenger.Include(t => t.PassengerDocuments).Include(t => t.PassengerClubMemberships).SingleOrDefault(t => t.Id == model.PassengerId);
                var trip = q.Trip;

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (q.ProfileId > 0) {
                    foreach (var row in q.Profile.Trips.SelectMany(t1 => t1.TripPassengers.Where(t2 => t2.ProfilePassengerId == q.Id))) {
                        row.ProfilePassengerId = -1;
                        lazyContext.Save(row, false);
                    }
                }

                if (lazyContext.Delete(q) && trip.Id > 0)
                    trip.UpdatePassengerCount(lazyContext);

                ts.Complete();
                return trip;
            }
        }

        public int CopyToProfile(AppMainContext context, int profileId, int[] passengerIds) {
            using (var ts = Utils.CreateTransactionScope()) {
                int count = 0;
                var profile = context.Profile.Include(t => t.ProfilePassengers).Single(t => t.Id == profileId);

                foreach (int passengerId in passengerIds) {
                    var passenger = context.Passenger.Find(passengerId);

                    if (passenger == null || profile.ProfilePassengers.Any(t => t.IsDuplicate(passenger)))
                        continue;

                    var q = new Passenger {
                        Id = 0,
                        PassengerType = passenger.PassengerType,
                        ProfileId = profileId,
                        TripId = -1,
                        Title = passenger.Title,
                        FirstName = passenger.FirstName,
                        LastName = passenger.LastName,
                        Alias = passenger.Alias,
                        DisplayName = passenger.DisplayName,
                        PhoneNo = passenger.PhoneNo,
                        Email = passenger.Email,
                        BirthDate = passenger.BirthDate,
                        Gender = passenger.Gender,
                        PassengerProfileId = -1,
                        ProfilePassengerId = -1,
                        CrsKey = string.Empty
                    };

                    q.Age = q.GetAge();
                    context.Insert(q);

                    passenger.PassengerProfileId = -1;
                    passenger.ProfilePassengerId = q.Id;
                    context.Save(passenger, false);

                    count++;
                }

                ts.Complete();
                return count;
            }
        }

        public bool Reorder(AppMainContext context, int tripId, int index, int direction) {
            using (var ts = Utils.CreateTransactionScope()) {
                int seqNo = 0;

                var q1 = context.Passenger.Where(t => t.TripId == tripId).OrderBy(t => t.SeqNo).ThenBy(t => t.Id).ToList().ConvertAll(row => new KeyValueModel {
                    Key = row.Id,
                    Value = seqNo++
                });

                seqNo = 0;

                foreach (var row in q1) {
                    if (seqNo == index) {
                        if (direction == 0) {
                            if (seqNo > 0) {
                                var q2 = q1.LastOrDefault(t => t.Value < seqNo);

                                if (q2 != null) {
                                    q2.Value = seqNo;
                                    row.Value = seqNo - 1;
                                }
                            }
                        }
                        else if (direction == 1) {
                            if (seqNo < q1.Count) {
                                var q2 = q1.Find(t => t.Value > seqNo);

                                if (q2 != null) {
                                    q2.Value = seqNo;
                                    row.Value = seqNo + 1;
                                }
                            }
                        }
                    }

                    seqNo++;
                }

                foreach (var row in q1) {
                    var q2 = context.Passenger.Find(row.Key);

                    if (q2.SeqNo != row.Value + 1) {
                        q2.SeqNo = row.Value + 1;
                        context.Save(q2, false);
                    }
                }

                ts.Complete();
                return true;
            }
        }
    }

    public class PassengerDocumentCommon {
        private HttpContext HttpContext { get; }

        public PassengerDocumentCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public PassengerDocumentViewModel CreateOrUpdate(PassengerDocumentViewModel model, bool isCrsImport = false) {
            if (!isCrsImport) {
                if (string.IsNullOrEmpty(model.PassengerDocumentNo))
                    throw new UnreportedException("Document No is required.");

                if (model.PassengerDocumentIssueDate == DateTime.MinValue)
                    throw new UnreportedException("Issue Date is required.");

                if (model.PassengerDocumentExpiryDate == DateTime.MinValue)
                    throw new UnreportedException("Expiry Date is required.");

                if (model.PassengerDocumentExpiryDate < model.PassengerDocumentIssueDate)
                    throw new UnreportedException("Expiry Date cannot be less than Issue Date.");

                if (!isCrsImport && model.PassengerDocumentIssuingCountryId <= 0)
                    throw new UnreportedException("Issuing Country is required.");

                if (!isCrsImport && model.PassengerDocumentNationalityId <= 0)
                    throw new UnreportedException("Nationality Country is required.");
            }

            using (var context = new AppMainContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                PassengerDocument q;

                if (model.PassengerDocumentId <= 0) {
                    q = new PassengerDocument {
                        Id = 0,
                        PassengerId = model.PassengerDocumentPassengerId,
                        Passenger = context.Passenger.Find(model.PassengerDocumentPassengerId)
                    };
                }
                else {
                    q = context.PassengerDocument.Include(t => t.Passenger).Single(t => t.Id == model.PassengerDocumentId);
                }

                if (!isCrsImport) {
                    if (q.Passenger.BirthDate == DateTime.MinValue)
                        throw new UnreportedException("Birth Date is required before a passenger document can be created or updated.");

                    if (q.Passenger.PassengerType == PassengerType.NotSpecified)
                        throw new UnreportedException("Passenger Type is required before a passenger document can be created or updated.");

                    if (q.Passenger.Gender == Gender.NotSpecified)
                        throw new UnreportedException("Gender is required before a passenger document can be created or updated.");
                }

                q.PassengerId = model.PassengerDocumentPassengerId;
                q.DocumentType = model.PassengerDocumentType;
                q.DocumentNo = model.PassengerDocumentNo;
                q.IssueDate = model.PassengerDocumentIssueDate ?? DateTime.MinValue;
                q.ExpiryDate = model.PassengerDocumentExpiryDate ?? DateTime.MinValue;
                q.PlaceOfIssue = model.PassengerDocumentPlaceOfIssue.ToStringExt();
                q.IssuingCountryId = model.PassengerDocumentIssuingCountryId ?? 0;
                q.NationalityId = model.PassengerDocumentNationalityId ?? 0;
                q.Comments = model.PassengerDocumentComments.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.PassengerDocumentId = q.Id;
                return model;
            }
        }
    }

    public class PassengerClubMembershipCommon {
        private HttpContext HttpContext { get; }

        public PassengerClubMembershipCommon(HttpContext httpContext) {
            HttpContext = httpContext;
        }

        public PassengerClubMembershipViewModel CreateOrUpdate(PassengerClubMembershipViewModel model) {
            using (var context = new AppMainContext(HttpContext.User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                PassengerClubMembership q;

                if (model.PassengerClubMembershipId <= 0) {
                    q = new PassengerClubMembership();
                }
                else {
                    q = context.PassengerClubMembership.Find(model.PassengerClubMembershipId);
                }

                q.PassengerId = model.PassengerClubMembershipPassengerId;
                q.ClubMembershipId = model.PassengerClubMembershipClubMembershipId ?? 0;
                q.ClubMembershipNo = model.PassengerClubMembershipClubMembershipNo;
                q.AirlineId = model.PassengerClubMembershipAirlineId ?? 0;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.PassengerClubMembershipId = q.Id;
                return model;
            }
        }
    }
}