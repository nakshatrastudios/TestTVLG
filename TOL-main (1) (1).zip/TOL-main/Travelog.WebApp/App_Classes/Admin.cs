using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.Admin;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.DebtorLedger;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Enums;
using Travelog.Ledger.Accounting;
using Travelog.PaymentGateway;
using Travelog.PaymentGateway.Enums;
using Travelog.Reports.Accounting;
using Travelog.WebApp.Models;
using AppSetting = Travelog.Biz.Dao.Admin.AppSetting;

namespace Travelog.WebApp.Admin {
    public enum CustomerTxnSource {
        Subscription = 0,
        RecurringPayment = 1,
        OnlinePayment = 2,
        ConcurrentUserChange = 3,
        ReceiptCreateOrUpdate = 4,
        InvoiceCreateOrUpdate = 5,
        UserUpdated = 6
    }

    public static class AspNetUsersCommon {
        public static async Task<IdentityResult> CreateOrUpdate(HttpContext httpContext, AppAdminContext adminContext, SignInManager<ApplicationUser> signInManager, UserManager<ApplicationUser> userManager, UserAccountViewModel model, int customerId) {
            if (httpContext.AppUserRole() != AppUserRole.SystemAdministrator && httpContext.AppUserRole() != AppUserRole.CompanyAdministrator)
                return null;

            if (httpContext.CurrentCustomerId() != customerId)
                throw new UnreportedException(AppConstants.UnauthorisedAccessAnotherCustomer);

            using (var ts = Utils.CreateTransactionScope()) {
                var role = adminContext.AspNetRoles.FirstOrDefault(t => t.Id == model.RoleId);

                if (role.Id == UserRole.SystemAdministrator.Id && customerId > (int)CustomerType.TravelogProd)
                    role = adminContext.AspNetRoles.FirstOrDefault(t => t.Id == UserRole.CompanyAdministrator.Id);

                if (model.IsSuperUser && !httpContext.IsAdministrator() && !httpContext.IsGlobalUser())
                    model.IsSuperUser = false;

                var appUser = await userManager.FindByIdAsync(model.UserId);

                if (appUser?.IsLocked() == false && httpContext.IsExternalUser() && customerId > (int)CustomerType.Customer && model.RoleId != UserRole.CompanyAdministrator.Id)
                    throw new UnreportedException(AppConstants.UnauthorisedAccessRemoteAssistanceUser);

                IdentityResult identityResult = null;

                bool addRoleOnly = false;
                bool result = false;

                if (string.IsNullOrEmpty(model.UserId)) {
                    if (appUser != null && adminContext.AspNetUsers.Include(t => t.AspNetUserRoles).Single(t => t.Id == appUser.Id).AspNetUserRoles.Any(t => t.CustomerId == customerId))
                        throw new UnreportedException("Email already exists.");

                    addRoleOnly = true;
                }

                if (appUser == null) {
                    var aspNetUser = new AspNetUsers {
                        Id = Guid.NewGuid().ToString(),
                        UserName = model.Email,
                        Email = model.Email,
                        FullName = model.FullName,
                        AgencyEmail = string.Empty,
                        Theme = model.Theme,
                        CurrentCustomerId = customerId,
                        CurrentConsultantId = model.ConsultantId,
                        CurrentDefaultAgencyId = -1,
                        TravelBankAccountId = -1,
                        AdminBankAccountId = -1,
                        SessionId = string.Empty,
                        GoogleAccountSecretKey = string.Empty,
                        LastSignInTime = DateTime.MinValue,
                        LastPasswordChangeDate = DateTime.MinValue,
                        OtherAgencies = model.OtherAgencies,
                        OtherConsultants = model.OtherConsultants,
                        IsExternalUser = false,
                        IsSupportUser = model.IsSupportUser,
                        IsSuperUser = model.IsSuperUser,
                        ForceSignOut = model.ForceSignOut,
                        EmailConfirmed = true,
                        LockoutEnabled = true,
                        SecurityStamp = Guid.NewGuid().ToString()
                    };

                    adminContext.Insert(aspNetUser);
                    appUser = await userManager.FindByIdAsync(aspNetUser.Id);

                    string password = Cryptography.GeneratePassword();
                    var token = await userManager.GeneratePasswordResetTokenAsync(appUser);

                    identityResult = await userManager.ResetPasswordAsync(appUser, token, password);
                    result = identityResult.Succeeded;

                    if (result) {
                        AspNetUserRolesCommon.CreateOrUpdate(httpContext, adminContext, appUser.Id, role.Id, customerId, model.ConsultantId, model.DefaultAgencyId, model.Inactive);

                        string body = string.Format(AppConstants.UserAccountCreated, string.Format("?message={0}", WebUtility.UrlEncode(Cryptography.Encrypt(string.Format("{0}password={1}", appUser.UserName, password)))), appUser.UserName, password);
                        Mail.Instance.SendMail(appUser.Email, "User Account Created", string.Format(AppConstants.MailBodyNoReply, body));

                        ts.Complete();
                        return null;
                    }

                    return identityResult;
                }
                else {
                    bool removeSupportUserRoles = customerId == (int)CustomerType.TravelogStaging && appUser.IsSupportUser && !model.IsSupportUser;

                    if (!addRoleOnly) {
                        var aspNetUser = adminContext.AspNetUsers.Include(t => t.AspNetUserRoles).Single(t => t.Id == appUser.Id);
                        addRoleOnly = aspNetUser.AspNetUserRoles.SingleOrDefault(t => t.CustomerId == customerId)?.RoleId != model.RoleId;

                        aspNetUser.UserName = model.Email;
                        aspNetUser.FullName = model.FullName;
                        aspNetUser.Email = model.Email;
                        aspNetUser.CurrentConsultantId = model.ConsultantId;
                        aspNetUser.OtherAgencies = model.OtherAgencies;
                        aspNetUser.OtherConsultants = model.OtherConsultants;
                        aspNetUser.IsTwoFactorEnabled = model.IsTwoFactorEnabled;
                        aspNetUser.IsSupportUser = model.IsSupportUser;
                        aspNetUser.IsSuperUser = model.IsSuperUser;
                        aspNetUser.ForceSignOut = model.ForceSignOut;

                        if (model.IsLocked) {
                            aspNetUser.IsLocked = true;
                        }
                        else if (appUser.IsLocked()) {
                            aspNetUser.IsLocked = false;
                        }

                        if (!aspNetUser.IsTwoFactorEnabled && aspNetUser.GoogleAccountSecretKey.Length > 0)
                            aspNetUser.GoogleAccountSecretKey = string.Empty;

                        result = adminContext.Save(aspNetUser);

                        if (model.ForceSignOut)
                            AppUsersOnline.ForceSignOut(appUser.Id);
                    }

                    if (addRoleOnly || result) {
                        AspNetUserRolesCommon.CreateOrUpdate(httpContext, adminContext, appUser.Id, role.Id, customerId, model.ConsultantId, model.DefaultAgencyId, model.Inactive, removeSupportUserRoles);

                        if (httpContext.UserId() == model.UserId) {
                            AppUserClaimsPrincipalFactory.UpdateUser(appUser, httpContext.User);
                            await signInManager.RefreshSignInAsync(appUser);
                        }

                        ts.Complete();
                        return null;
                    }

                    return identityResult;
                }
            }
        }

        public static bool Delete(HttpContext httpContext, AppAdminContext adminContext, AppMainContext context, UserAccountViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var aspNetUser = adminContext.AspNetUsers.Find(model.UserId);

                AspNetUserRolesCommon.Delete(adminContext, aspNetUser.Id, httpContext.CurrentCustomerId());

                if (!adminContext.AspNetUserRoles.Any(t => t.UserId == aspNetUser.Id)) {
                    if (adminContext.Delete(aspNetUser)) {
                        var agencyUserEmail = context.AgencyUserEmail.SingleOrDefault(t => t.UserId == aspNetUser.Id);

                        if (agencyUserEmail != null)
                            context.Delete(agencyUserEmail, false);
                    }
                }
                else if (!adminContext.AspNetUserRoles.Any(t => t.UserId == aspNetUser.Id && t.CustomerId == aspNetUser.CurrentCustomerId)) {
                    aspNetUser.CurrentCustomerId = adminContext.AspNetUserRoles.First(t => t.UserId == aspNetUser.Id).CustomerId;
                    adminContext.Save(aspNetUser);
                }

                ts.Complete();
                return true;
            }
        }

        public static bool UpdateDefaultAgency(IPrincipal principal, string userId, int customerId, int defaultAgencyId) {
            using (var adminContext = new AppAdminContext(principal)) {
                var aspNetUserRole = adminContext.AspNetUserRoles.SingleOrDefault(t => t.UserId == userId && t.CustomerId == customerId);

                if (aspNetUserRole == null)
                    return false;

                aspNetUserRole.DefaultAgencyId = defaultAgencyId;
                return adminContext.Save(aspNetUserRole, false);
            }
        }

        public static bool IsLocked(this ApplicationUser appUser, bool? value = null) {
            if (value == null)
                return appUser?.LockoutEnd > DateTime.UtcNow;

            appUser.LockoutEnd = (value ?? false) ? DateTime.MaxValue : (DateTime?)null;
            return value ?? false;
        }

        public static AspNetUsers GetUser(HttpContext httpContext, AppAdminContext adminContext) {
            return adminContext.AspNetUsers.Include(t => t.CurrentCustomer).ThenInclude(t => t.CustomerTransactions).Include(t => t.CurrentCustomer).ThenInclude(t => t.AspNetUserRoles).ThenInclude(t => t.AspNetRoles).SingleOrDefault(t => t.Id == httpContext.UserId());
        }
    }

    public static class AspNetUserRolesCommon {
        public static bool CreateOrUpdate(HttpContext httpContext, AppAdminContext adminContext, string userId, string roleId, int customerId, int consultantId, int defaultAgencyId = -1, bool inactive = false, bool removeSupportUserRoles = false, bool validateDevelopmentMode = false) {
            if (!httpContext.CustomerSettings().IsManagementCustomer && httpContext.IsExternalUser() && roleId != UserRole.CompanyAdministrator.Id)
                throw new UnreportedException(AppConstants.UnauthorisedAccessRemoteAssistanceUser);

            var aspNetUserRoles = adminContext.AspNetUserRoles.Where(t => t.UserId == userId).ToList();

            if (validateDevelopmentMode && aspNetUserRoles.Count > 0) {
                bool isDevelopmentMode = aspNetUserRoles.Any(t => t.CustomerId <= (int)CustomerType.Customer);

                if (isDevelopmentMode != AppSettings.IsDevelopmentMode)
                    throw new UnreportedException("Role cannot be assigned to the selected user for this company type.");
            }

            var aspNetUserRole = adminContext.AspNetUserRoles.Include(t => t.Customer).Include(t => t.AspNetUsers).ThenInclude(t => t.AspNetUserRoles).SingleOrDefault(t => t.UserId == userId && t.CustomerId == customerId);
            bool isNew = false;

            if (aspNetUserRole == null) {
                isNew = true;

                aspNetUserRole = new AspNetUserRoles {
                    UserId = userId,
                    CustomerId = customerId
                };
            }
            else if (validateDevelopmentMode && aspNetUserRole.Customer.IsManagementCustomer) {
                if (aspNetUserRole.AspNetUsers.IsSupportUser)
                    return false;

                throw new UnreportedException("Role cannot be assigned to the selected user for this company type.");
            }

            aspNetUserRole.RoleId = roleId;
            aspNetUserRole.ConsultantId = consultantId;
            aspNetUserRole.DefaultAgencyId = defaultAgencyId;
            aspNetUserRole.Inactive = inactive;

            bool result;

            if (isNew) {
                result = adminContext.Insert(aspNetUserRole);
            }
            else {
                result = adminContext.Save(aspNetUserRole);
            }

            if (removeSupportUserRoles) {
                foreach (var userRole in adminContext.AspNetUserRoles.Where(t => t.UserId == userId && t.CustomerId == customerId).ToList()) {
                    adminContext.Entry(userRole).State = EntityState.Deleted;
                    adminContext.Delete(userRole, false);
                }
            }

            if (result) {
                var aspNetUser = adminContext.AspNetUsers.Find(userId);
                aspNetUser.AppUserRole = UserRole.GetAppUserRole(roleId);
                adminContext.Save(aspNetUser, false);
            }

            return result;
        }

        public static bool Delete(AppAdminContext adminContext, string userId, int customerId) {
            var aspNetUserRole = adminContext.AspNetUserRoles.FirstOrDefault(t => t.UserId == userId && t.CustomerId == customerId);

            if (aspNetUserRole == null)
                return false;

            adminContext.Delete(aspNetUserRole);
            return true;
        }
    }

    public static class AdminSettings {
        public static string GetBillingLastRunTimeFormatted(AppAdminContext adminContext, Customer customer) {
            DateTime lastRunTime = BillingLastRunTime(adminContext, customer).ToLocalTime();
            return lastRunTime == DateTime.MinValue ? "Never" : lastRunTime.ToShortDateTimeStringExt();
        }

        public static DateTime BillingLastRunTime(AppAdminContext adminContext, Customer customer, DateTime? value = null) {
            if (value == null) {
                DateTime lastRunTime = adminContext.CustomerTransaction.Where(t => t.Id > 0 && t.CustomerId == customer.Id && t.CustomerTransactionType == CustomerTransactionType.Subscription).OrderByDescending(t => t.CreationTime).FirstOrDefault()?.CreationTime ?? DateTime.MinValue;

                if (lastRunTime > DateTime.MinValue)
                    return lastRunTime;

                DateTime.TryParse(adminContext.AppSetting.Find("BillingLastRunTime")?.Value, out lastRunTime);

                if (lastRunTime == DateTime.MinValue)
                    lastRunTime = customer.StartDate;

                return lastRunTime;
            }

            var q = adminContext.AppSetting.Find("BillingLastRunTime");

            if (q == null) {
                q = new AppSetting {
                    Id = "BillingLastRunTime",
                    Value = string.Format("{0:g}", value)
                };

                adminContext.Insert(q, false);
            }
            else {
                q.Value = string.Format("{0:g}", value);
                adminContext.Save(q, false);
            }

            return DateTime.MinValue;
        }

        public static DateTime TermsAndConditionsLastNotifiedTime(AppAdminContext adminContext, DateTime? value = null) {
            if (value == null) {
                DateTime.TryParse(adminContext.AppSetting.Find("TermsAndConditionsLastNotifiedTime")?.Value, out DateTime lastNotifiedTime);
                return lastNotifiedTime == DateTime.MinValue ? DateTime.MinValue : lastNotifiedTime.ToLocalTime();
            }

            var q = adminContext.AppSetting.Find("TermsAndConditionsLastNotifiedTime");

            if (q == null) {
                q = new AppSetting {
                    Id = "TermsAndConditionsLastNotifiedTime",
                    Value = string.Format("{0:g}", value)
                };

                adminContext.Insert(q, false);
            }
            else {
                q.Value = string.Format("{0:g}", value);
                adminContext.Save(q, false);
            }

            return DateTime.MinValue;
        }

        public static DateTime GetTermsAndConditionsLastWriteTime(string contentRootPath) {
            string filePath = Path.Combine(contentRootPath, "wwwroot/html/TermsAndConditions.html");
            DateTime lastWriteTime = File.GetLastWriteTime(filePath);
            return lastWriteTime == DateTime.MinValue ? DateTime.MinValue : lastWriteTime.ToLocalTime();
        }

        public static int SystemGenReceiptFormOfPaymentId(AppAdminContext adminContext, int? value = null) {
            var appSetting = adminContext.AppSetting.Find("SystemGenReceiptFormOfPaymentId");

            if (value == null)
                return int.Parse(appSetting.Value);

            appSetting.Value = (value ?? -1).ToString();
            return adminContext.Save(appSetting) ? 1 : 0;
        }

        public static int SystemGenInvoiceDiscountReasonId(AppAdminContext adminContext, int? value = null) {
            var appSetting = adminContext.AppSetting.Find("SystemGenInvoiceDiscountReasonId");

            if (value == null)
                return int.Parse(appSetting.Value);

            appSetting.Value = (value ?? -1).ToString();
            return adminContext.Save(appSetting) ? 1 : 0;
        }

        public static bool SystemGenDocRequiresApproval(AppAdminContext adminContext, bool? value = null) {
            var appSetting = adminContext.AppSetting.Find("SystemGenDocRequiresApproval");

            if (value == null)
                return bool.Parse(appSetting.Value);

            appSetting.Value = (value ?? false).ToString();
            return adminContext.Save(appSetting);
        }
    }

    public static class CustomerCommon {
        public static bool InitSettings(AppAdminContext adminContext, int customerId, bool validateCustomerStatus = false) {
            return InitSettings(adminContext, adminContext.Customer.Find(customerId), validateCustomerStatus);
        }

        public static bool InitSettings(AppAdminContext adminContext, Customer customer, bool validateCustomerStatus = false) {
            if (validateCustomerStatus) {
                var customerStatus = customer.CustomerStatus;

                switch (customer.CustomerTransactions.Where(t => t.Id > 0 && (t.CustomerTransactionType == CustomerTransactionType.AccountDeactivated || t.CustomerTransactionType == CustomerTransactionType.AccountSuspended || t.CustomerTransactionType == CustomerTransactionType.AccountReactivated || t.CustomerTransactionType == CustomerTransactionType.SuspensionLifted)).OrderByDescending(t => t.Id).FirstOrDefault()?.CustomerTransactionType) {
                    case CustomerTransactionType.AccountDeactivated:
                        customerStatus = CustomerStatus.Inactive;
                        break;
                    case CustomerTransactionType.AccountSuspended:
                        customerStatus = CustomerStatus.Suspended;
                        break;
                    case CustomerTransactionType.AccountReactivated:
                    case CustomerTransactionType.SuspensionLifted:
                        customerStatus = CustomerStatus.Active;
                        break;
                }

                if (customerStatus != customer.CustomerStatus) {
                    customer.CustomerStatus = customerStatus;
                    adminContext.Save(customer, false);
                }
            }

            CustomerSettings.InitSettings(adminContext, customer);
            return true;
        }

        public static void ValidateStatus(HttpContext httpContext, ref string message, ref MessageType messageType, ref int timeoutSeconds) {
            if (!httpContext.CustomerSettings().IsCustomerAccountActive) {
                message = AppConstants.CustomerAccountIsDeactivated;
                messageType = MessageType.Warning;
                timeoutSeconds = 0;
            }
            else if (httpContext.CustomerSettings().IsCustomerAccountSuspended) {
                message = AppConstants.CustomerAccountIsSuspended;
                messageType = MessageType.Error;
                timeoutSeconds = 0;
            }
            else {
                var customerAccountStatus = CustomerSettings.GetCustomerAccountStatus(httpContext.CurrentCustomerId());

                if (customerAccountStatus == CustomerAccountStatus.Overdue) {
                    message = AppConstants.CustomerAccountIsOverdue;
                    messageType = MessageType.Warning;
                    timeoutSeconds = 0;
                }
                else if (customerAccountStatus == CustomerAccountStatus.Locked) {
                    message = AppConstants.CustomerAccountIsPayableNow;
                    messageType = MessageType.Error;
                    timeoutSeconds = 0;
                }
            }
        }

        public static bool Update(HttpContext httpContext, AppAdminContext adminContext, AppMainContext context, CustomerViewModel model, bool updateReadOnlyFields = false) {
            if (httpContext.IsExternalUser())
                throw new UnreportedException(AppConstants.UnauthorisedAccessRemoteAssistanceUser);

            using (var ts = Utils.CreateTransactionScope()) {
                var customer = adminContext.Customer.Include(t => t.CustomerTransactions).Single(t => t.Id == model.CustomerId);

                bool result = false;
                bool insertConcurrentUserChangeTxn = false;

                if (httpContext.IsGlobalUser()) {
                    if (customer.IsManagementCustomer) {
                        model.SubscriptionChartOfAccountId = -1;
                        model.SabreEprChartOfAccountId = -1;
                        model.UserCount = 0;
                        model.ExcludeFromBilling = true;
                        model.AllowRemoteAssistance = false;

                        customer.SubscriptionChartOfAccountId = -1;
                        customer.SabreEprChartOfAccountId = -1;
                        customer.UserCount = 0;
                        customer.ExcludeFromBilling = true;
                        customer.AllowRemoteAssistance = false;
                    }
                    else {
                        insertConcurrentUserChangeTxn = customer.UserCount != model.UserCount;

                        if (updateReadOnlyFields) {
                            customer.LegalName = model.LegalName;
                            customer.BusinessName = model.BusinessName.ToStringExt();
                            customer.Location = model.Location.ToStringExt();
                            customer.AgencyType = model.AgencyType;
                            customer.CustomerContactType = model.CustomerContactType;
                        }

                        customer.SubscriptionChartOfAccountId = model.SubscriptionChartOfAccountId ?? 0;
                        customer.SabreEprChartOfAccountId = model.SabreEprChartOfAccountId ?? 0;
                        customer.ExcludeFromBilling = model.ExcludeFromBilling;
                        customer.UserCount = model.UserCount;

                        if (httpContext.IsExternalUser()) {
                            adminContext.Entry(customer).State = EntityState.Modified;
                            result = adminContext.SaveChanges() > 0;
                            ts.Complete();
                            return result;
                        }
                    }
                }
                else {
                    customer.AllowRemoteAssistance = model.AllowRemoteAssistance && customer.CustomerType == CustomerType.Customer;

                    customer.Address1 = model.Address1;
                    customer.Address2 = model.Address2.ToStringExt();
                    customer.Locality = model.Locality;
                    customer.Region = model.Region;
                    customer.PostCode = model.PostCode;
                    customer.CountryCode = model.CountryCode;

                    customer.BillingContactName = model.BillingContactName.ToStringExt();
                    customer.BillingContactPhone = model.BillingContactPhone.ToStringExt();
                    customer.BillingContactEmail = model.BillingContactEmail.ToStringExt();

                    customer.TechnicalContactName = model.TechnicalContactName.ToStringExt();
                    customer.TechnicalContactPhone = model.TechnicalContactPhone.ToStringExt();
                    customer.TechnicalContactEmail = model.TechnicalContactEmail.ToStringExt();
                }

                result = adminContext.Save(customer);

                if (result) {
                    if (insertConcurrentUserChangeTxn) {
                        var customerTransactionModel = new CustomerTransactionViewModel {
                            CustomerTransactionId = 0,
                            CustomerTransactionCustomerId = model.CustomerId,
                            CustomerTransactionType = CustomerTransactionType.ConcurrentUserChange,
                            CustomerTransactionApprovalStatus = CustomerTransactionApprovalStatus.Approved,
                            CustomerTransactionDateFrom = DateTime.UtcNow.Date,
                            CustomerTransactionDateTo = DateTime.UtcNow.Date,
                            CustomerTransactionDateDue = DateTime.MinValue,
                            CustomerTransactionUserCount = model.UserCount,
                            CustomerTransactionUserCharge = 0,
                            CustomerTransactionAmountGross = 0,
                            CustomerTransactionTax = 0,
                            CustomerTransactionDocumentNo = string.Empty,
                            PaymentTransactionId = 0,
                            CustomerTransactionDescription = string.Empty,
                            IsUserCreated = false
                        };

                        CustomerTransactionCommon.CreateOrUpdate(httpContext, adminContext, context, customerTransactionModel, CustomerTxnSource.ConcurrentUserChange, false);
                    }

                    if (model.CustomerId == httpContext.CurrentCustomerId())
                        InitSettings(adminContext, customer, true);
                }

                ts.Complete();
                return result;
            }
        }

        public static bool PrivacySettingsUpdate(HttpContext httpContext, AppAdminContext adminContext, PrivacySettingsViewModel model) {
            if (httpContext.IsExternalUser())
                throw new UnreportedException(AppConstants.UnauthorisedAccessRemoteAssistanceUser);

            if (httpContext.IsSupportUser())
                throw new UnreportedException(AppConstants.UnauthorisedAccessSupportProvider);

            if (!httpContext.IsAdministrator())
                throw new UnreportedException(AppConstants.UnauthorisedAccessNotAdministrator);

            if (httpContext.CustomerSettings().IsManagementCustomer)
                throw new UnreportedException(AppConstants.UnauthorisedAccessManagementCustomer);

            using (var ts = Utils.CreateTransactionScope()) {
                var customer = adminContext.Customer.Find(model.CustomerId);

                bool result = false;

                if (customer.AllowRemoteAssistance != model.AllowRemoteAssistance) {
                    customer.AllowRemoteAssistance = model.AllowRemoteAssistance;
                    result = adminContext.Save(customer);
                }

                foreach (var aspNetUser in adminContext.AspNetUsers.Where(t => t.IsSupportUser).ToList()) {
                    if (!aspNetUser.IsInRole(adminContext, model.SupportProviderRoleId, model.CustomerId)) {
                        if (model.SupportProviderRoleId == Guid.Empty.ToString()) {
                            if (AspNetUserRolesCommon.Delete(adminContext, aspNetUser.Id, model.CustomerId)) {
                                aspNetUser.AppUserRole = AppUserRole.None;
                                adminContext.Save(aspNetUser, false);
                            }
                        }
                        else if (AspNetUserRolesCommon.CreateOrUpdate(httpContext, adminContext, aspNetUser.Id, model.SupportProviderRoleId, model.CustomerId, aspNetUser.CurrentConsultantId, aspNetUser.CurrentDefaultAgencyId)) {
                            aspNetUser.AppUserRole = UserRole.GetAppUserRole(model.SupportProviderRoleId);
                            adminContext.Save(aspNetUser, false);
                        }
                    }
                }

                ts.Complete();
                return result;
            }
        }
    }

    public static class CustomerPaymentMethodCommon {
        public static bool CreateOrUpdate(HttpContext httpContext, AppAdminContext adminContext, CustomerPaymentMethodViewModel model, string encryptedCardNo, string encryptedCvn) {
            if (httpContext.IsGlobalUser() && httpContext.CurrentCustomerId() > (int)CustomerType.TravelogProd)
                throw new UnreportedException("Support providers are not authorised to perform this operation.");

            if (httpContext.AppUserRole() != AppUserRole.CompanyAdministrator)
                throw new UnreportedException("Only company administrators can manage payment methods.");

            if (httpContext.CurrentCustomerId() != model.CustomerPaymentMethodCustomerId)
                throw new UnreportedException("Payment methods can only be managed for the current customer.");

            using (var ts = Utils.CreateTransactionScope()) {
                int customerId = model.CustomerPaymentMethodCustomerId;

                CustomerPaymentMethod q = null;

                if (model.CustomerPaymentMethodId <= 0) {
                    q = new CustomerPaymentMethod {
                        Id = 0,
                        Customer = adminContext.Customer.Find(customerId)
                    };
                }
                else {
                    q = adminContext.CustomerPaymentMethod.Include(t => t.Customer).Single(t => t.Id == model.CustomerPaymentMethodId);
                }

                long tokenCustomerId = q.TokenCustomerId;
                var eWay = new Eway(httpContext.CurrentCustomerId(), PaymentGatewayClientType.Principal, AppSettings.IsDevelopmentMode);

                string expiryMonth = (model.CustomerPaymentMethodExpiryDate ?? DateTime.MinValue).Month.ToString("D2");
                string expiryYear = (model.CustomerPaymentMethodExpiryDate ?? DateTime.MinValue).Year.ToString();

                tokenCustomerId = eWay.CreateOrUpdateTokenCustomer(
                    cardNo: encryptedCardNo,
                    cardholderName: model.CustomerPaymentMethodCardholderName,
                    expiryMonth: expiryMonth,
                    expiryYear: expiryYear,
                    cvn: encryptedCvn,
                    countryIsoCode: q.Customer.CountryIsoCode,
                    tokenCustomerId: tokenCustomerId
                );

                var response = eWay.QueryCustomer(tokenCustomerId);

                tokenCustomerId = response.TokenCustomerID.ToLong();
                model.CustomerPaymentMethodCardNo = response.CardDetails.Number;

                q.TokenCustomerId = tokenCustomerId;
                q.CardNo = model.CustomerPaymentMethodCardNo;
                q.CardholderName = model.CustomerPaymentMethodCardholderName;
                q.ExpiryDate = model.CustomerPaymentMethodExpiryDate ?? DateTime.MinValue;
                q.IsActive = model.CustomerPaymentMethodIsActive;
                q.IsRecurringPayment = model.CustomerPaymentMethodIsRecurringPayment;

                if (model.CustomerPaymentMethodId <= 0) {
                    adminContext.Insert(q);
                }
                else {
                    adminContext.Save(q);
                }

                model.CustomerPaymentMethodId = q.Id;

                if (q.IsRecurringPayment) {
                    foreach (var row in adminContext.CustomerPaymentMethod.Where(t => t.Id != q.Id && t.CustomerId == customerId && t.IsRecurringPayment)) {
                        row.IsRecurringPayment = false;
                        adminContext.Save(row, false);
                    }
                }

                ts.Complete();
                return true;
            }
        }

        public static bool Delete(HttpContext httpContext, AppAdminContext adminContext, CustomerPaymentMethodViewModel model) {
            if (!httpContext.IsGlobalUser() && httpContext.AppUserRole() != AppUserRole.CompanyAdministrator)
                throw new UnreportedException("Only company administrators can delete payment methods.");

            var q = adminContext.CustomerPaymentMethod.Find(model.CustomerPaymentMethodId);

            if (q == null)
                throw new UnreportedException(AppConstants.RecordNotFound);

            adminContext.Delete(q);
            return true;
        }
    }

    public static class CustomerPricingCommon {
        public static bool CreateOrUpdate(HttpContext httpContext, AppAdminContext adminContext, CustomerPricingViewModel model) {
            if (!AppSettings.SuperAdminUsers.Contains(httpContext.User.Identity.Name))
                throw new UnreportedException("You are not authorsed to update this record.");

            if (!httpContext.IsGlobalUser())
                throw new UnreportedException("Only support providers can update this record.");

            using (var ts = Utils.CreateTransactionScope()) {
                int customerId = model.CustomerPricingCustomerId;

                CustomerPricing q = null;

                if (model.CustomerPricingId <= 0) {
                    q = new CustomerPricing();
                }
                else {
                    q = adminContext.CustomerPricing.Include(t => t.Customer).Single(t => t.Id == model.CustomerPricingId);
                }

                q.CustomerId = model.CustomerPricingCustomerId;
                q.DateFrom = model.CustomerPricingDateFrom;
                q.DateTo = model.CustomerPricingDateTo ?? DateTime.MinValue;
                q.BillingCycle = model.CustomerPricingBillingCycle;
                q.UserCount = model.CustomerPricingUserCount;
                q.UserCharge = model.CustomerPricingUserCharge;

                if (model.CustomerPricingId <= 0) {
                    adminContext.Insert(q);
                }
                else {
                    adminContext.Save(q);
                }

                model.CustomerPricingId = q.Id;

                ts.Complete();
                return true;
            }
        }

        public static bool Delete(HttpContext httpContext, AppAdminContext adminContext, CustomerPricingViewModel model) {
            if (!AppSettings.SuperAdminUsers.Contains(httpContext.User.Identity.Name))
                throw new UnreportedException("You are not authorsed to delete this record.");

            if (!httpContext.IsGlobalUser())
                throw new UnreportedException("Only support providers can delete this record.");

            var q = adminContext.CustomerPricing.SingleOrDefault(t => t.Id == model.CustomerPricingId);

            if (q == null)
                throw new UnreportedException(AppConstants.RecordNotFound);

            adminContext.Delete(q);
            return true;
        }
    }

    public static class CustomerTransactionCommon {
        public static bool CreateOrUpdate(HttpContext httpContext, AppAdminContext adminContext, AppMainContext context, CustomerTransactionViewModel model, CustomerTxnSource source, bool isNative = true, Receipt receipt = null, Invoice invoice = null) {
            if (isNative && httpContext.AppUserRole() != AppUserRole.SystemAdministrator)
                throw new UnreportedException("Only system administrators can edit company transactions.");

            if (model.CustomerTransactionType == CustomerTransactionType.ConcurrentUserChange) {
                if (model.CustomerTransactionUserCount <= 0)
                    throw new UnreportedException("Concurrent Users must be greater than zero.");

                if (model.CustomerTransactionUserCount > 99)
                    throw new UnreportedException("Concurrent Users must be less than 100.");
            }

            var managementCustomer = adminContext.Customer.Find(AppSettings.DbConnectionMode == DbConnectionMode.Development ? (int)CustomerType.TravelogDev : AppSettings.DbConnectionMode == DbConnectionMode.Staging ? (int)CustomerType.TravelogStaging : (int)CustomerType.TravelogProd);

            CustomerTransaction customerTxn = null;
            Customer customer = null;

            var billing = new Billing(httpContext, false);

            using (var lazyContext = new AppLazyContext(httpContext.User, httpContext.CurrentCustomerId(), httpContext.IsExternalUser(), httpContext.IsSuperUser())) {
                using (var ts = Utils.CreateTransactionScope()) {
                    if (model.CustomerTransactionId <= 0) {
                        customerTxn = new CustomerTransaction {
                            Id = 0,
                            CustomerId = model.CustomerTransactionCustomerId,
                            CustomerTransactionType = model.CustomerTransactionType,
                            DocumentNo = string.Empty,
                            IsUserCreated = model.IsUserCreated
                        };

                        customer = adminContext.Customer.Include(t => t.CustomerTransactions).Single(t => t.Id == customerTxn.CustomerId);
                    }
                    else {
                        customerTxn = adminContext.CustomerTransaction.Include(t => t.Customer).Single(t => t.Id == model.CustomerTransactionId);
                        customer = customerTxn.Customer;
                    }

                    if (customer.ExcludeFromBilling && source == CustomerTxnSource.InvoiceCreateOrUpdate)
                        throw new UnreportedException("This company is excluded from billing and does not support transactions.");

                    if (customerTxn.IsReceiptItem) {
                        model.CustomerTransactionUserCount = 0;
                        model.CustomerTransactionUserCharge = 0;
                    }

                    if (!customerTxn.IsInvoiceItem && !customerTxn.IsReceiptItem && !customerTxn.IsPaymentGatewayTxn && !customerTxn.IsSystemOwned) {
                        model.CustomerTransactionUserCount = 0;
                        model.CustomerTransactionUserCharge = 0;
                        model.CustomerTransactionAmountGross = 0;
                        model.CustomerTransactionTax = 0;
                    }

                    if (model.IsUserCreated) {
                        model.CustomerTransactionApprovalStatus = CustomerTransactionApprovalStatus.Approved;

                        if (model.IsInvoiceItem) {
                            if (model.CustomerTransactionInvoiceId <= 0) {
                                customerTxn.DocumentNo = string.Empty;
                                customerTxn.Document = null;
                            }
                            else {
                                invoice = context.Invoice.Include(t => t.Debtor).Include(t => t.InvoiceDetails).SingleOrDefault(t => t.Id == model.CustomerTransactionInvoiceId);

                                if (invoice != null) {
                                    var reportSource = AccountingDataSources.GetCustomerInvoiceReportSource(httpContext.CurrentCustomerId(), invoice);
                                    customerTxn.DocumentNo = invoice.DocumentNo;
                                    customerTxn.Document = Utils.ExportToPdf(reportSource).DocumentBytes;
                                }
                            }
                        }
                        else if (model.IsReceiptItem) {
                            if (model.CustomerTransactionReceiptId <= 0) {
                                customerTxn.DocumentNo = string.Empty;
                                customerTxn.Document = null;
                            }
                            else {
                                receipt = context.Receipt.Include(t => t.Agency).Include(t => t.ReceiptDetails).SingleOrDefault(t => t.Id == model.CustomerTransactionReceiptId);

                                if (receipt != null) {
                                    var reportSource = AccountingDataSources.GetCustomerReceiptReportSource(httpContext.CurrentCustomerId(), httpContext.User.Identity.Name, receipt);
                                    customerTxn.DocumentNo = receipt.DocumentNo;
                                    customerTxn.Document = Utils.ExportToPdf(reportSource).DocumentBytes;
                                }
                            }
                        }
                        else {
                            customerTxn.DocumentNo = string.Empty;
                        }
                    }
                    else {
                        customerTxn.DocumentNo = model.CustomerTransactionDocumentNo.ToStringExt();
                    }

                    if (!model.IsInvoiceItem)
                        model.CustomerTransactionDateDue = DateTime.MinValue;

                    customerTxn.CustomerTransactionType = model.CustomerTransactionType;
                    customerTxn.CustomerTransactionApprovalStatus = model.CustomerTransactionApprovalStatus;
                    customerTxn.DateFrom = model.CustomerTransactionDateFrom ?? DateTime.MinValue;
                    customerTxn.DateTo = model.CustomerTransactionDateTo ?? DateTime.MinValue;
                    customerTxn.DateDue = model.CustomerTransactionDateDue ?? DateTime.MinValue;
                    customerTxn.UserCount = model.CustomerTransactionUserCount;
                    customerTxn.UserCharge = model.CustomerTransactionUserCharge;
                    customerTxn.Amount = model.CustomerTransactionAmountGross - (customerTxn.IsReceiptItem ? 0 : model.CustomerTransactionTax);
                    customerTxn.Tax = customerTxn.IsReceiptItem ? 0 : model.CustomerTransactionTax;
                    customerTxn.PaymentTransactionId = model.IsReceiptItem || model.IsInvoiceItem ? model.PaymentTransactionId : 0;
                    customerTxn.Description = model.CustomerTransactionDescription.ToStringExt();

                    if (!CreateOrUpdateWithStatus(adminContext, customerTxn, source))
                        return false;

                    model.CustomerTransactionId = customerTxn.Id;

                    if (customerTxn.CustomerTransactionType == CustomerTransactionType.Subscription) {
                        var customerTxnDetail = adminContext.CustomerTransactionDetail.SingleOrDefault(t => t.CustomerTransactionId == customerTxn.Id && t.CustomerTransactionType == CustomerTransactionType.Subscription);

                        customerTxnDetail ??= new CustomerTransactionDetail {
                            Id = 0,
                            CustomerTransactionId = customerTxn.Id,
                            CustomerTransactionType = CustomerTransactionType.Subscription
                        };

                        customerTxnDetail.DateFrom = customerTxn.DateFrom;
                        customerTxnDetail.DateTo = customerTxn.DateTo;
                        customerTxnDetail.UserCount = customerTxn.UserCount;
                        customerTxnDetail.UserCharge = customerTxn.UserCharge;
                        customerTxnDetail.Amount = customerTxn.Amount;
                        customerTxnDetail.Tax = customerTxn.Tax;

                        if (customerTxnDetail.Id <= 0) {
                            adminContext.Insert(customerTxnDetail, false);
                        }
                        else {
                            adminContext.Save(customerTxnDetail, false);
                        }
                    }

                    if (model.IsUserCreated) {
                        if (invoice != null) {
                            foreach (var invoiceDetail in invoice.InvoiceDetails) {
                                invoiceDetail.CustomerTransactionId = customerTxn.Id;
                                context.Save(invoiceDetail, false);
                            }
                        }
                        else if (receipt != null) {
                            foreach (var receiptDetail in receipt.ReceiptDetails) {
                                receiptDetail.CustomerTransactionId = customerTxn.Id;
                                context.Save(receiptDetail, false);
                            }
                        }
                    }
                    else {
                        if (customerTxn.IsInvoiceItem) {
                            invoice ??= billing.CreateInvoice(adminContext, customerTxn.CustomerTransactionType == CustomerTransactionType.Invoice ? InvoiceType.Invoice : InvoiceType.CreditNote, httpContext.User, customer, managementCustomer.Id, new List<CustomerTransaction> { customerTxn }, false);

                            if (invoice != null) {
                                var reportSource = AccountingDataSources.GetCustomerInvoiceReportSource(httpContext.CurrentCustomerId(), invoice);

                                if (customerTxn.CustomerTransactionApprovalStatus == CustomerTransactionApprovalStatus.NotApproved)
                                    customerTxn.CustomerTransactionApprovalStatus = AdminSettings.SystemGenDocRequiresApproval(adminContext) ? CustomerTransactionApprovalStatus.NotApproved : CustomerTransactionApprovalStatus.Approved;

                                customerTxn.DocumentNo = invoice.DocumentNo;
                                customerTxn.Document = Utils.ExportToPdf(reportSource).DocumentBytes;

                                adminContext.Save(customerTxn, false);
                            }
                        }

                        var customerTransactions = customer.CustomerTransactions.Where(t => t.PaymentTransactionId == 0 && t.DocumentNo.Length > 0).AsEnumerable().Where(t => t.IsInvoiceItem).GroupBy(t => new { t.DocumentNo }).ToList();

                        if (customerTransactions.Sum(t1 => t1.Sum(t2 => (decimal?)t2.Amount + t2.Tax) ?? 0) == -(customerTxn.Amount + customerTxn.Tax)) {
                            foreach (var customerTransaction in customerTransactions) {
                                foreach (var row in customerTransaction.Where(t => t.PaymentTransactionId == 0)) {
                                    row.PaymentTransactionId = model.PaymentTransactionId;
                                    adminContext.Save(row, false);
                                }
                            }
                        }
                        else {
                            foreach (var customerTransaction in customerTransactions) {
                                if (customerTransaction.Sum(t => t.Amount + t.Tax) == -(customerTxn.Amount + customerTxn.Tax)) {
                                    foreach (var row in customerTransaction.Where(t => t.PaymentTransactionId == 0)) {
                                        row.PaymentTransactionId = model.PaymentTransactionId;
                                        adminContext.Save(row, false);
                                    }
                                }
                            }
                        }

                        if (customerTxn.IsReceiptItem) {
                            receipt ??= billing.CreateReceipt(adminContext, httpContext.User, managementCustomer.Id, source, new List<CustomerTransaction> { customerTxn }, false);

                            if (receipt != null) {
                                billing.MatchTransactions(adminContext, httpContext.User, managementCustomer.Id);
                                var reportSource = AccountingDataSources.GetCustomerReceiptReportSource(httpContext.CurrentCustomerId(), httpContext.User.Identity.Name, receipt);

                                customerTxn.DocumentNo = receipt.DocumentNo;
                                customerTxn.Document = Utils.ExportToPdf(reportSource).DocumentBytes;

                                adminContext.Save(customerTxn, false);
                            }
                        }
                    }

                    ts.Complete();
                }
            }

            if (customer.Id == httpContext.CurrentCustomerId())
                CustomerCommon.InitSettings(adminContext, customer);

            if ((receipt != null || invoice != null) && customerTxn.CustomerTransactionStatus == CustomerTransactionStatus.Open)
                new Billing(httpContext, false).ProcessNotifications(adminContext, managementCustomer.Id);

            return true;
        }

        public static bool CreateOrUpdateWithStatus(AppAdminContext adminContext, CustomerTransaction customerTxn, CustomerTxnSource source) {
            switch (source) {
                case CustomerTxnSource.Subscription:
                case CustomerTxnSource.ConcurrentUserChange:
                    customerTxn.CustomerTransactionStatus = CustomerTransactionStatus.Open;
                    break;
                case CustomerTxnSource.OnlinePayment:
                case CustomerTxnSource.ReceiptCreateOrUpdate:
                case CustomerTxnSource.InvoiceCreateOrUpdate:
                    customerTxn.CustomerTransactionStatus = CustomerTransactionStatus.Closed;
                    break;
                case CustomerTxnSource.RecurringPayment:
                    customerTxn.CustomerTransactionStatus = customerTxn.PaymentTransactionId > 0 ? CustomerTransactionStatus.Closed : CustomerTransactionStatus.Failed;
                    break;
                case CustomerTxnSource.UserUpdated:
                    if (customerTxn.Id <= 0)
                        customerTxn.CustomerTransactionStatus = CustomerTransactionStatus.Closed;

                    break;
            }

            if (customerTxn.Id <= 0) {
                return adminContext.Insert(customerTxn, false);
            }
            else {
                return adminContext.Save(customerTxn, false);
            }
        }

        public static bool Delete(HttpContext httpContext, AppAdminContext adminContext, AppMainContext context, CustomerTransactionViewModel model) {
            if (httpContext.AppUserRole() != AppUserRole.SystemAdministrator)
                throw new UnreportedException("Only system administrators can delete company transactions.");

            using (var ts = Utils.CreateTransactionScope()) {
                var q = adminContext.CustomerTransaction.Include(t => t.Customer).SingleOrDefault(t => t.Id == model.CustomerTransactionId) ?? throw new UnreportedException(AppConstants.RecordNotFound);
                adminContext.Delete(q);

                if (q.DocumentNo.Length > 0) {
                    if (q.CustomerTransactionType == CustomerTransactionType.OnlinePayment) {
                        var receipt = context.Receipt.Include(t => t.Transactions).ThenInclude(t => t.TransactionDetails).ThenInclude(t => t.TransactionDetailAllocations)
                            .Include(t => t.ReceiptDetails).ThenInclude(t => t.TransactionDetails).ThenInclude(t => t.TransactionDetailAllocations)
                            .Include(t => t.ReceiptDetails).ThenInclude(t => t.TransactionDetailAllocations)
                            .SingleOrDefault(t => t.DocumentNo == q.DocumentNo);

                        if (receipt == null) {
                            ts.Complete();
                            return false;
                        }

                        context.RemoveRange(receipt.Transactions.SelectMany(t => t.TransactionDetails.SelectMany(t => t.TransactionDetailAllocations)));
                        context.RemoveRange(receipt.ReceiptDetails.SelectMany(t => t.TransactionDetails.SelectMany(t => t.TransactionDetailAllocations)));
                        context.RemoveRange(receipt.ReceiptDetails.SelectMany(t => t.TransactionDetailAllocations));
                        context.SaveChanges();
                        context.Delete(receipt);
                    }
                    else if (q.CustomerTransactionType == CustomerTransactionType.Invoice || q.CustomerTransactionType == CustomerTransactionType.CreditNote) {
                        var invoice = context.Invoice.Include(t => t.Transactions).ThenInclude(t => t.TransactionDetails).ThenInclude(t => t.TransactionDetailAllocations)
                            .Include(t => t.InvoiceDetails).ThenInclude(t => t.TransactionDetails).ThenInclude(t => t.TransactionDetailAllocations)
                            .Include(t => t.InvoiceDetails).ThenInclude(t => t.TransactionDetailAllocations)
                            .SingleOrDefault(t => t.DocumentNo == q.DocumentNo);

                        if (invoice == null) {
                            ts.Complete();
                            return false;
                        }

                        context.RemoveRange(invoice.Transactions.SelectMany(t => t.TransactionDetails.SelectMany(t => t.TransactionDetailAllocations)));
                        context.RemoveRange(invoice.InvoiceDetails.SelectMany(t => t.TransactionDetails.SelectMany(t => t.TransactionDetailAllocations)));
                        context.RemoveRange(invoice.InvoiceDetails.SelectMany(t => t.TransactionDetailAllocations));
                        context.SaveChanges();
                        context.Delete(invoice);
                    }
                }

                ts.Complete();
                return true;
            }
        }

        public static bool Approve(HttpContext httpContext, AppAdminContext adminContext, int customerTransactionId, bool isApproved) {
            if (httpContext.AppUserRole() != AppUserRole.SystemAdministrator)
                throw new UnreportedException("Only system administrators can edit company transactions.");

            var q = adminContext.CustomerTransaction.Include(t => t.Customer).Single(t => t.Id == customerTransactionId);
            q.CustomerTransactionApprovalStatus = isApproved ? CustomerTransactionApprovalStatus.Approved : CustomerTransactionApprovalStatus.NotApproved;

            bool result = adminContext.Save(q);

            if (result && isApproved)
                new Billing(httpContext, false).SendNotification(adminContext, q);

            return result;
        }
    }

    public class Billing {
        private const string ClassName = "Travelog.WebApp.Billing";

        private HttpContext HttpContext { get; }
        private bool IsAutoRun { get; }

        public Billing(HttpContext httpContext, bool isAutoRun = true) {
            HttpContext = httpContext;
            IsAutoRun = isAutoRun;
        }

        public void ExecuteBillingRun(IPrincipal principal, string contentRootPath, int managementCustomerId) {
            using (var adminContext = new AppAdminContext(principal)) {
                CreateOrUpdateManagementDbDebtors(adminContext, principal, managementCustomerId);

                ProcessSubscriptions(adminContext, managementCustomerId);
                ProcessInvoices(adminContext, principal, managementCustomerId);
                ProcessRecurringPayments(adminContext, principal, managementCustomerId);

                MatchTransactions(adminContext, principal, managementCustomerId);
                ProcessNotifications(adminContext, managementCustomerId);
                NotifyTermsAndConditions(adminContext, contentRootPath, managementCustomerId);

                AdminSettings.BillingLastRunTime(adminContext, null, DateTime.UtcNow);
            }
        }

        private void ProcessSubscriptions(AppAdminContext adminContext, int managementCustomerId) {
            if (managementCustomerId != (int)CustomerType.TravelogDev && managementCustomerId != (int)CustomerType.TravelogStaging && managementCustomerId != (int)CustomerType.TravelogProd)
                throw new InvalidOperationException(AppConstants.UnauthorisedAccessNotManagementCustomer);

            var managementCustomer = adminContext.Customer.Find(managementCustomerId);
            var customers = GetCustomers(adminContext, managementCustomerId);

            if (IsAutoRun)
                customers = customers.Where(t => t.Id > (int)CustomerType.TravelogDev);

            bool systemGenDocRequiresApproval = AdminSettings.SystemGenDocRequiresApproval(adminContext);

            using (var lazyContext = new AppLazyContext(managementCustomerId, true)) {
                foreach (var customer in customers.ToList()) {
                    if (customer.StartDate > DateTime.Today.AddDays(AppSettings.CustomerPaymentTermsDays))
                        continue;

                    using (var ts = Utils.CreateTransactionScope()) {
                        DateTime lastRunTime = AdminSettings.BillingLastRunTime(adminContext, customer).Date;

                        for (int i = 0; i <= DateTime.Today.Subtract(lastRunTime).Days; i++) {
                            bool concurrentUserChangeApplies = false;

                            DateTime billingDate = lastRunTime.AddDays(i);
                            DateTime dateFrom = customer.GetBillingStartDate(ref concurrentUserChangeApplies);
                            DateTime dateTo = Utils.GetDayOfMonthDate(dateFrom.AddMonths(1).AddDays(-1), customer.StartDate.Day, -1);

                            if (i > 0 && billingDate.Day != dateFrom.Day)
                                continue;

                            CustomerTransaction customerTransaction = null;
                            CustomerTransactionDetail customerTransactionDetail1 = null;
                            CustomerTransactionDetail customerTransactionDetail2 = null;

                            decimal amount;
                            decimal tax;

                            var customerPricing = Customer.GetCustomerPricing(adminContext, customer.Id, customer.UserCount, dateFrom, dateTo);
                            int billingMonths = customerPricing.BillingMonths;

                            if (customerPricing.DateFrom < DateTime.Today.AddMonths(billingMonths).AddDays(-AppSettings.CustomerPaymentTermsDays)) {
                                amount = Math.Round(-customer.UserCount * customerPricing.UserCharge * billingMonths);
                                tax = 0;

                                var chartOfAccount = lazyContext.ChartOfAccount.Find(customer.SubscriptionChartOfAccountId);

                                if (chartOfAccount.IsTaxApplicable) {
                                    decimal taxRate = CustomerSettings.GetTaxRate(adminContext, customerPricing.DateFrom, customer.CountryCode);
                                    tax = Math.Round(amount * taxRate, 2);
                                }

                                customerTransactionDetail1 = new CustomerTransactionDetail {
                                    Id = 0,
                                    CustomerTransactionType = CustomerTransactionType.Subscription,
                                    DateFrom = customerPricing.DateFrom,
                                    DateTo = customerPricing.DateTo,
                                    UserCount = customer.UserCount,
                                    UserCharge = customerPricing.UserCharge,
                                    Amount = amount,
                                    Tax = tax
                                };
                            }

                            if (concurrentUserChangeApplies) {
                                var lastSubscription = customer.CustomerTransactions.Where(t => t.CustomerTransactionType == CustomerTransactionType.Subscription && t.DateFrom < dateFrom).OrderByDescending(t => t.DateFrom).FirstOrDefault();

                                if (lastSubscription != null) {
                                    foreach (var customerTxn in customer.CustomerTransactions.Where(t => t.CustomerTransactionType == CustomerTransactionType.ConcurrentUserChange && t.DateFrom >= lastSubscription.DateFrom && t.DateTo <= lastSubscription.DateTo).AsEnumerable().Where(t => !t.Customer.IsManagementCustomer).OrderBy(t => t.CustomerTransactionType == CustomerTransactionType.Subscription ? 0 : t.Id).ToList()) {
                                        int userCount = customerTxn.UserCount - lastSubscription.UserCount;

                                        int proRataDays = lastSubscription.DateTo.Subtract(customerTxn.DateFrom).Days + 1;
                                        int totalDays = lastSubscription.DateTo.Subtract(lastSubscription.DateFrom).Days + 1;

                                        decimal userCharge = Math.Round(proRataDays / (decimal)totalDays * lastSubscription.UserCharge, 2);
                                        amount = Math.Round(-userCount * userCharge * lastSubscription.BillingMonths, 2);
                                        tax = 0;

                                        var chartOfAccount = lazyContext.ChartOfAccount.Find(customer.SubscriptionChartOfAccountId);

                                        if (chartOfAccount.IsTaxApplicable) {
                                            decimal taxRate = CustomerSettings.GetTaxRate(adminContext, customerTxn.DateFrom, customer.CountryCode);
                                            tax = Math.Round(amount * taxRate, 2);
                                        }

                                        customerTransactionDetail2 = new CustomerTransactionDetail {
                                            Id = 0,
                                            CustomerTransactionType = CustomerTransactionType.ConcurrentUserChange,
                                            DateFrom = customerTxn.DateFrom,
                                            DateTo = lastSubscription.DateTo,
                                            UserCount = userCount,
                                            UserCharge = userCharge,
                                            Amount = amount,
                                            Tax = tax
                                        };
                                    }
                                }
                            }

                            if (customerTransactionDetail1 == null && customerTransactionDetail2 == null)
                                continue;

                            CustomerTransactionDetail customerTransactionDetail;

                            if (customerTransactionDetail1 != null && customerTransactionDetail2 != null) {
                                customerTransactionDetail = customerTransactionDetail1;
                                amount = customerTransactionDetail1.Amount + customerTransactionDetail2.Amount;
                                tax = customerTransactionDetail1.Tax + customerTransactionDetail2.Tax;
                            }
                            else if (customerTransactionDetail1 != null) {
                                customerTransactionDetail = customerTransactionDetail1;
                                amount = customerTransactionDetail1.Amount;
                                tax = customerTransactionDetail1.Tax;
                            }
                            else {
                                customerTransactionDetail = customerTransactionDetail2;
                                amount = customerTransactionDetail2.Amount;
                                tax = customerTransactionDetail2.Tax;
                            }

                            customerTransaction = new CustomerTransaction {
                                Id = 0,
                                CustomerId = customer.Id,
                                CustomerTransactionType = CustomerTransactionType.Subscription,
                                CustomerTransactionApprovalStatus = systemGenDocRequiresApproval ? CustomerTransactionApprovalStatus.NotApproved : CustomerTransactionApprovalStatus.Approved,
                                DateFrom = customerTransactionDetail.DateFrom,
                                DateTo = customerTransactionDetail.DateTo,
                                DateDue = DateTime.MinValue,
                                UserCount = customerTransactionDetail.UserCount,
                                UserCharge = customerTransactionDetail.UserCharge,
                                Amount = amount,
                                Tax = tax,
                                DocumentNo = string.Empty,
                                Document = null,
                                Description = string.Empty,
                                IsUserCreated = false
                            };

                            CustomerTransactionCommon.CreateOrUpdateWithStatus(adminContext, customerTransaction, CustomerTxnSource.Subscription);

                            if (customerTransactionDetail1 != null) {
                                customerTransactionDetail1.CustomerTransactionId = customerTransaction.Id;
                                adminContext.Insert(customerTransactionDetail1, false);
                            }

                            if (customerTransactionDetail2 != null) {
                                customerTransactionDetail2.CustomerTransactionId = customerTransaction.Id;
                                adminContext.Insert(customerTransactionDetail2, false);
                            }
                        }

                        ts.Complete();
                    }
                }
            }
        }

        private bool ProcessInvoices(AppAdminContext adminContext, IPrincipal principal, int managementCustomerId) {
            if (managementCustomerId != (int)CustomerType.TravelogDev && managementCustomerId != (int)CustomerType.TravelogStaging && managementCustomerId != (int)CustomerType.TravelogProd)
                throw new InvalidOperationException(AppConstants.UnauthorisedAccessNotManagementCustomer);

            var managementCustomer = adminContext.Customer.Find(managementCustomerId);
            var customers = GetCustomers(adminContext, managementCustomerId);

            if (IsAutoRun)
                customers = customers.Where(t => t.Id > (int)CustomerType.TravelogDev);

            foreach (var customer in customers.ToList()) {
                using (var lazyContext = new AppLazyContext(principal, customer.Id, HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                    using (var ts = Utils.CreateTransactionScope()) {
                        var customerTxns = customer.CustomerTransactions.Where(t => t.CustomerTransactionStatus == CustomerTransactionStatus.Open && t.DocumentNo.Length == 0).AsEnumerable().Where(t => t.CustomerTransactionType == CustomerTransactionType.Subscription && !t.Customer.IsManagementCustomer).OrderBy(t => t.CustomerTransactionType == CustomerTransactionType.Subscription ? 0 : t.Id).ToList();

                        if (customerTxns.Count == 0)
                            continue;

                        var invoiceType = customerTxns.Sum(t => t.Amount + t.Tax) > 0 ? InvoiceType.CreditNote : InvoiceType.Invoice;
                        var chartOfAccount = lazyContext.ChartOfAccount.Find(customer.SubscriptionChartOfAccountId);

                        foreach (var customerTxn in customerTxns) {
                            customerTxn.DateDue = DateTime.Today.AddDays(AppSettings.CustomerPaymentTermsDays);
                            adminContext.Save(customerTxn, false);
                        }

                        var invoice = CreateInvoice(adminContext, invoiceType, principal, customer, managementCustomerId, customerTxns, true);

                        if (invoice == null)
                            continue;

                        var reportSource = AccountingDataSources.GetCustomerInvoiceReportSource(managementCustomer.Id, invoice);
                        var invoiceReport = Utils.ExportToPdf(reportSource).DocumentBytes;

                        bool invoiceAdded = false;

                        foreach (var customerTxn in customerTxns) {
                            if (customerTxn.DocumentNo.Length == 0 || customerTxn.Document == null) {
                                if (customerTxn.DocumentNo.Length == 0)
                                    customerTxn.DocumentNo = invoice.DocumentNo;

                                if (!invoiceAdded) {
                                    customerTxn.Document = invoiceReport;
                                    invoiceAdded = true;
                                }

                                if (customerTxn.Id <= 0) {
                                    adminContext.Insert(customerTxn, false);
                                }
                                else {
                                    adminContext.Save(customerTxn, false);
                                }
                            }
                        }

                        ts.Complete();
                    }
                }
            }

            return true;
        }

        private bool ProcessRecurringPayments(AppAdminContext adminContext, IPrincipal principal, int managementCustomerId) {
            if (managementCustomerId != (int)CustomerType.TravelogDev && managementCustomerId != (int)CustomerType.TravelogStaging && managementCustomerId != (int)CustomerType.TravelogProd)
                throw new InvalidOperationException(AppConstants.UnauthorisedAccessNotManagementCustomer);

            var eWay = new Eway(managementCustomerId, PaymentGatewayClientType.Principal, managementCustomerId != (int)CustomerType.TravelogProd);

            var managementCustomer = adminContext.Customer.Find(managementCustomerId);
            var customerTxns = GetCustomerTransactions(adminContext, managementCustomerId).Where(t => t.PaymentTransactionId == 0 && t.DocumentNo.Length > 0 && (t.DateDue == DateTime.MinValue || t.DateDue <= DateTime.Today)).AsEnumerable().Where(t => t.IsInvoiceItem);

            if (IsAutoRun)
                customerTxns = customerTxns.Where(t => t.CustomerId > (int)CustomerType.TravelogDev);

            foreach (var row in customerTxns.GroupBy(t => new { t.Customer }).ToList()) {
                var customerTransactions = new List<CustomerTransaction>();

                using (var ts = Utils.CreateTransactionScope()) {
                    foreach (var customerTxn in row) {
                        decimal amount = -(customerTxn.Amount + customerTxn.Tax);
                        decimal tax = -customerTxn.Tax;

                        if (amount <= AppSettings.BalancePayableLimit)
                            continue;

                        long tokenCustomerId = adminContext.CustomerPaymentMethod.FirstOrDefault(t => t.CustomerId == customerTxn.CustomerId && t.ExpiryDate > DateTime.Today && t.IsRecurringPayment && t.IsActive)?.TokenCustomerId ?? 0;

                        if (tokenCustomerId == 0)
                            continue;

                        string errors = string.Empty;
                        int paymentTransactionId = 0;

                        try {
                            var companyAddress = new eWAY.Rapid.Models.Address {
                                Street1 = row.Key.Customer.Address1,
                                Street2 = row.Key.Customer.Address2,
                                City = row.Key.Customer.Locality,
                                State = row.Key.Customer.Region,
                                PostalCode = row.Key.Customer.PostCode,
                                Country = row.Key.Customer.CountryIsoCode
                            };

                            paymentTransactionId = eWay.MakeTokenPayment(
                                tokenCustomerId: tokenCustomerId,
                                amount: (int)(amount * 100),
                                currencyCode: row.Key.Customer.CurrencyCode,
                                transactionType: PaymentGatewayTransactionType.Recurring,
                                companyName: row.Key.Customer.GetBusinessName(),
                                companyAddress: companyAddress,
                                contactName: row.Key.Customer.BillingContactName,
                                contactPhone: row.Key.Customer.BillingContactPhone,
                                contactEmail: row.Key.Customer.BillingContactEmail,
                                invoiceNo: customerTxn.DocumentNo
                            );
                        }
                        catch (Exception ex) {
                            ExceptionManagerBiz.Instance.SendMailAsync(ClassName, "ProcessRecurringPayments", ex, null, AppSettings.ErrorNotificationEmail).Wait();
                        }

                        if (paymentTransactionId > 0 || !string.IsNullOrEmpty(errors)) {
                            if (paymentTransactionId > 0) {
                                customerTxn.PaymentTransactionId = paymentTransactionId;
                                adminContext.Save(customerTxn, false);
                            }

                            var customerTransaction = new CustomerTransaction {
                                Id = 0,
                                CustomerId = customerTxn.CustomerId,
                                CustomerTransactionType = CustomerTransactionType.RecurringPayment,
                                CustomerTransactionApprovalStatus = CustomerTransactionApprovalStatus.Approved,
                                DateFrom = customerTxn.DateFrom,
                                DateTo = customerTxn.DateTo,
                                DateDue = DateTime.Today,
                                UserCount = 0,
                                UserCharge = 0,
                                Amount = paymentTransactionId > 0 ? amount - tax : 0,
                                Tax = paymentTransactionId > 0 ? tax : 0,
                                DocumentNo = string.Empty,
                                Document = null,
                                PaymentTransactionId = paymentTransactionId,
                                Description = paymentTransactionId > 0 ? string.Empty : errors,
                                IsUserCreated = false
                            };

                            bool result = CustomerTransactionCommon.CreateOrUpdateWithStatus(adminContext, customerTransaction, CustomerTxnSource.RecurringPayment);

                            if (result && paymentTransactionId > 0) {
                                customerTransaction.UserCount = customerTxn.UserCount;
                                customerTransaction.UserCharge = customerTxn.UserCharge;
                                customerTransactions.Add(customerTransaction);
                            }
                        }
                    }

                    if (customerTransactions.Count == 0)
                        continue;

                    var receipt = CreateReceipt(adminContext, principal, managementCustomer.Id, CustomerTxnSource.RecurringPayment, customerTransactions, true);

                    if (receipt != null) {
                        MatchTransactions(adminContext, principal, managementCustomerId);
                        var reportSource = AccountingDataSources.GetCustomerReceiptReportSource(managementCustomer.Id, principal.Identity.Name, receipt);

                        customerTransactions[0].Document = Utils.ExportToPdf(reportSource).DocumentBytes;

                        foreach (var customerTransaction in customerTransactions) {
                            customerTransaction.DocumentNo = receipt.DocumentNo;
                            adminContext.Save(customerTransaction, false);
                        }
                    }

                    ts.Complete();
                }
            }

            return true;
        }

        public void ProcessNotifications(AppAdminContext adminContext, int managementCustomerId) {
            if (managementCustomerId != (int)CustomerType.TravelogDev && managementCustomerId != (int)CustomerType.TravelogStaging && managementCustomerId != (int)CustomerType.TravelogProd)
                throw new InvalidOperationException(AppConstants.UnauthorisedAccessNotManagementCustomer);

            var receipts = new List<string>();
            var invoices = new List<string>();

            var customerTxns = GetCustomerTransactions(adminContext, managementCustomerId).Where(t => t.CustomerTransactionApprovalStatus == CustomerTransactionApprovalStatus.Approved).AsEnumerable().Where(t => t.IsReceiptItem || t.IsInvoiceItem);

            if (IsAutoRun)
                customerTxns = customerTxns.Where(t => t.CustomerId > (int)CustomerType.TravelogDev);

            foreach (var customerTxn in customerTxns.Where(t => t.DocumentNo.Length > 0).ToList()) {
                if (customerTxn.IsReceiptItem) {
                    if (receipts.Contains(customerTxn.DocumentNo))
                        continue;

                    receipts.Add(customerTxn.DocumentNo);
                }
                else {
                    if (invoices.Contains(customerTxn.DocumentNo))
                        continue;

                    invoices.Add(customerTxn.DocumentNo);
                }

                SendNotification(adminContext, customerTxn);
            }
        }

        public void SendNotification(AppAdminContext adminContext, CustomerTransaction customerTxn) {
            int managementCustomerId = customerTxn.Customer.ManagementCustomerId;

            if (managementCustomerId != (int)CustomerType.TravelogDev && managementCustomerId != (int)CustomerType.TravelogStaging && managementCustomerId != (int)CustomerType.TravelogProd)
                throw new InvalidOperationException(AppConstants.UnauthorisedAccessNotManagementCustomer);

            if ((!customerTxn.IsReceiptItem && !customerTxn.IsInvoiceItem) || customerTxn.CustomerTransactionApprovalStatus != CustomerTransactionApprovalStatus.Approved)
                return;

            string subject;
            string body;

            List<CustomerTransaction> customerTxns;

            if (customerTxn.IsReceiptItem) {
                subject = string.Format("Receipt No {0}", customerTxn.DocumentNo);
                body = string.Format(AppConstants.MailBodyNoReply, string.Format(AppConstants.ReceiptAdvice, subject));
                customerTxns = GetCustomerTransactions(adminContext, managementCustomerId).Where(t => t.CustomerTransactionApprovalStatus == CustomerTransactionApprovalStatus.Approved && t.DocumentNo == customerTxn.DocumentNo).AsEnumerable().Where(t => t.IsReceiptItem).ToList();
            }
            else {
                subject = string.Format("{0} No {1}", customerTxn.CustomerTransactionType == CustomerTransactionType.CreditNote ? "Credit Note" : "Invoice", customerTxn.DocumentNo);
                body = string.Format(AppConstants.MailBodyNoReply, string.Format(AppConstants.InvoiceAdvice, subject));
                customerTxns = GetCustomerTransactions(adminContext, managementCustomerId).Where(t => t.CustomerTransactionApprovalStatus == CustomerTransactionApprovalStatus.Approved && t.DocumentNo == customerTxn.DocumentNo).AsEnumerable().Where(t => t.IsInvoiceItem).ToList();
            }

            Mail.Instance.SendMail(customerTxn.Customer.BillingContactEmail, subject, body);

            customerTxns.ForEach(t => t.CustomerTransactionApprovalStatus = CustomerTransactionApprovalStatus.ApprovedAndEmailed);
            adminContext.SaveChanges();
        }

        public Receipt CreateReceipt(AppAdminContext adminContext, IPrincipal principal, int managementCustomerId, CustomerTxnSource source, List<CustomerTransaction> customerTxns, bool isSystemGenerated) {
            if (customerTxns.Count == 0)
                return null;

            using (var lazyContext = new AppLazyContext(principal, managementCustomerId, HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                DateTime documentDate = DateTime.Today;

                if (!Setting.IsFiscalPeriodOpen(lazyContext, documentDate, true)) {
                    var ex = new InvalidOperationException("Customer receipt could not be created because the fiscal period is closed.");

                    if (isSystemGenerated) {
                        ExceptionManagerBiz.Instance.SendMailAsync(ClassName, "CreateReceipt", ex).Wait();
                        return null;
                    }
                    else {
                        throw ex;
                    }
                }

                var debtor = lazyContext.Debtor.SingleOrDefault(t => t.CustomerId == customerTxns[0].CustomerId);

                if (debtor == null) {
                    var ex = new InvalidOperationException(string.Format("Receipt could not be created because a debtor has not been assigned to {0}.", customerTxns[0].Customer.GetBusinessName()));
                    ExceptionManagerBiz.Instance.SendMailAsync(ClassName, "CreateReceipt", ex).Wait();
                    return null;
                }

                using (var ts = Utils.CreateTransactionScope()) {
                    var managementAgency = lazyContext.Agency.Single(t => t.IsHeadOffice);

                    var receipt = new Receipt {
                        Id = 0,
                        AccountType = AccountType.Debtor,
                        ReceiptType = ReceiptType.Debtor,
                        DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Receipt"),
                        DocumentDate = documentDate,
                        Payer = string.Empty,
                        BankAccountId = managementAgency.TravelBankAccountId,
                        TripId = -1,
                        DebtorId = debtor.Id,
                        CreditorId = -1,
                        SupplierId = -1,
                        ChartOfAccountId = -1,
                        SupplierCommissionType = SupplierCommissionType.None,
                        SaleTypeId = -1,
                        CategoryId = -1,
                        AgencyId = managementAgency.Id,
                        ChartOfAccountAgencyRefId = -1,
                        ConsultantId = -1,
                        SourceId = -1,
                        StandardCommentId = -1,
                        DiscountReasonId = -1,
                        CancellationSaleTypeId = -1,
                        ReverseTransferReceiptId = -1
                    };

                    LastDocumentNo.DocumentNo(lazyContext, "Receipt", receipt.DocumentNo);
                    lazyContext.Insert(receipt, false);

                    int formOfPaymentId = AdminSettings.SystemGenReceiptFormOfPaymentId(adminContext);

                    foreach (var customerTxn in customerTxns) {
                        string description;

                        if (source == CustomerTxnSource.RecurringPayment) {
                            description = string.Format("{0} Subscription: {1:d} to {2:d}: {3} {4} @ {5:c2} per user (plus GST)", customerTxn.BillingCycle, customerTxn.DateFrom, customerTxn.DateTo, customerTxn.UserCount, customerTxn.UserCount == 1 ? "user" : "users", customerTxn.UserCharge);
                        }
                        else {
                            description = "Online Payment";
                        }

                        var receiptDetail = new ReceiptDetail {
                            Id = 0,
                            ReceiptId = receipt.Id,
                            DocumentStatus = DocumentStatus.Closed,
                            ReversalStatus = ReversalStatus.None,
                            TripLineId = -1,
                            TripLineAirPassengerId = -1,
                            PassengerId = -1,
                            FormOfPaymentId = formOfPaymentId,
                            PaymentMethodId = -1,
                            LoyaltySchemeId = -1,
                            LoyaltySchemeReference = string.Empty,
                            VoucherId = -1,
                            Class = string.Empty,
                            OfferedReasonId = -1,
                            DepositDetailId = -1,
                            BankAccountStatementId = -1,
                            Comments = description,
                            Amount = customerTxn.Amount + customerTxn.Tax,
                            Tax = 0,
                            IsTaxApplicable = customerTxn.Tax != 0,
                            CustomerTransactionId = customerTxn.Id
                        };

                        lazyContext.Insert(receiptDetail, false);
                        lazyContext.Entry(receipt).State = EntityState.Detached;

                        receipt = lazyContext.Receipt.Include(t => t.ReceiptDetails).ThenInclude(t => t.TransactionDetailAllocations).Single(t => t.Id == receipt.Id);
                        receipt.UpdateTransactions(lazyContext, managementCustomerId);

                        foreach (var row in receipt.ReceiptDetails) {
                            row.CustomerTransactionId = customerTxn.Id;
                            lazyContext.Save(row, false);
                        }

                        CustomerTransactionCommon.CreateOrUpdateWithStatus(adminContext, customerTxn, CustomerTxnSource.ReceiptCreateOrUpdate);
                    }

                    ts.Complete();
                    return receipt;
                }
            }
        }

        public Invoice CreateInvoice(AppAdminContext adminContext, InvoiceType invoiceType, IPrincipal principal, Customer customer, int managementCustomerId, List<CustomerTransaction> customerTxns, bool isSystemGenerated) {
            if (customerTxns.Count == 0)
                return null;

            using (var lazyContext = new AppLazyContext(principal, managementCustomerId, HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                DateTime documentDate = DateTime.Today;

                if (!Setting.IsFiscalPeriodOpen(lazyContext, documentDate, true)) {
                    var ex = new InvalidOperationException("Customer invoice could not be created because the fiscal period is closed.");

                    if (isSystemGenerated) {
                        ExceptionManagerBiz.Instance.SendMailAsync(ClassName, "CreateInvoice", ex).Wait();
                        return null;
                    }
                    else {
                        throw ex;
                    }
                }

                var debtor = lazyContext.Debtor.SingleOrDefault(t => t.CustomerId == customer.Id);

                if (debtor == null) {
                    var ex = new InvalidOperationException(string.Format("Invoice could not be created because a debtor has not been assigned to {0}.", customerTxns[0].Customer.GetBusinessName()));
                    ExceptionManagerBiz.Instance.SendMailAsync(ClassName, "CreateInvoice", ex).Wait();
                    return null;
                }

                using (var ts = Utils.CreateTransactionScope()) {
                    var managementAgency = lazyContext.Agency.Single(t => t.IsHeadOffice);

                    var debtorAddress = lazyContext.DebtorAddress.FirstOrDefault(t => t.DebtorId == debtor.Id);
                    var debtorContact = lazyContext.DebtorContact.FirstOrDefault(t => t.DebtorId == debtor.Id);

                    var invoice = new Invoice {
                        Id = 0,
                        AgencyId = managementAgency.Id,
                        AccountType = AccountType.GeneralLedger,
                        InvoiceType = invoiceType,
                        DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Invoice"),
                        DocumentDate = documentDate,
                        DebtorId = debtor.Id,
                        DebtorName = debtor.Name,
                        DebtorAddress1 = debtorAddress?.Address1,
                        DebtorAddress2 = debtorAddress?.Address2,
                        DebtorLocality = debtorAddress?.Locality,
                        DebtorRegion = debtorAddress?.Region,
                        DebtorPostCode = debtorAddress?.PostCode,
                        DebtorCountryCode = debtorAddress?.CountryCode,
                        BalanceDueDate = documentDate.AddDays(debtor.PaymentTerm.Term),
                        SubDebtorId = -1,
                        DebtorContactId = debtorContact?.Id ?? -1,
                        DebtorCurrencyId = -1,
                        DebtorExchangeRate = 1,
                        DebtorOrderNo = string.Empty,
                        PaymentTerms = debtor.PaymentTerm.Name,
                        InvoiceLinkId = -1,
                        Comments = string.Empty
                    };

                    LastDocumentNo.DocumentNo(lazyContext, "Invoice", invoice.DocumentNo);
                    lazyContext.Insert(invoice, false);

                    int discountReasonId = AdminSettings.SystemGenInvoiceDiscountReasonId(adminContext);

                    foreach (var customerTxn in customerTxns) {
                        foreach (var customerTxnDetail in customerTxn.CustomerTransactionDetails) {
                            decimal amount = customerTxnDetail.Amount;
                            decimal tax = customerTxnDetail.Tax;

                            decimal discount = 0;
                            decimal discountTax = 0;

                            string description;

                            if (customerTxnDetail.CustomerTransactionType == CustomerTransactionType.Subscription) {
                                var customerPricing = Customer.GetCustomerPricing(adminContext, customer.Id, customerTxnDetail.UserCount, customerTxnDetail.DateFrom, customerTxnDetail.DateTo);
                                description = string.Format("{0} Subscription: {1:d} to {2:d}: {3} {4} @ {5:c2} per user (plus GST)", customerPricing.BillingCycle, customerTxnDetail.DateFrom, customerTxnDetail.DateTo, customerTxnDetail.UserCount, customerTxnDetail.UserCount == 1 ? "user" : "users", customerTxnDetail.UserCharge);

                                if (invoiceType != InvoiceType.CreditNote) {
                                    decimal taxRate = amount == 0 ? 0 : Math.Round(tax / amount, 3);
                                    decimal fullAmount = Math.Round(-Pricing.GetUserCharge(adminContext, customerTxnDetail.UserCount) * customerTxnDetail.UserCount * customerPricing.BillingMonths, 2);

                                    if (amount > fullAmount) {
                                        discount = amount - fullAmount;
                                        discountTax = Math.Round(discount * taxRate, 2);
                                        amount = fullAmount;
                                        tax = Math.Round(amount * taxRate, 2);
                                    }
                                }
                            }
                            else if (customerTxnDetail.CustomerTransactionType == CustomerTransactionType.ConcurrentUserChange) {
                                description = string.Format("Pro-Rata Adjustment: {0:d} to {1:d}: {2} {3} @ {4:c2} per user (plus GST)", customerTxnDetail.DateFrom, customerTxnDetail.DateTo, customerTxnDetail.UserCount, customerTxnDetail.UserCount == 1 ? "user" : "users", customerTxnDetail.UserCharge);
                            }
                            else {
                                continue;
                            }

                            var invoiceDetail = new InvoiceDetail {
                                Id = 0,
                                InvoiceId = invoice.Id,
                                AgencyId = managementAgency.Id,
                                DocumentStatus = DocumentStatus.Closed,
                                TripId = -1,
                                TripLineId = -1,
                                TripLineAirPassengerId = -1,
                                SaleTypeId = -1,
                                CreditorId = -1,
                                SupplierId = -1,
                                AirlineId = -1,
                                ChartOfAccountId = customer.SubscriptionChartOfAccountId,
                                Amount = invoiceType == InvoiceType.CreditNote ? amount : -amount,
                                Tax = invoiceType == InvoiceType.CreditNote ? tax : -tax,
                                Discount = discount,
                                DiscountTax = discountTax,
                                DiscountReasonId = discount == 0 ? -1 : discountReasonId,
                                DocumentNo = string.Empty,
                                ConfirmationNo = string.Empty,
                                Description = description,
                                IsPayment = false,
                                CustomerTransactionId = customerTxn.Id
                            };

                            lazyContext.Insert(invoiceDetail, false);
                            lazyContext.Entry(invoiceDetail).State = EntityState.Detached;
                        }

                        foreach (var row in invoice.InvoiceDetails) {
                            row.CustomerTransactionId = customerTxn.Id;
                            lazyContext.Save(row, false);
                        }

                        CustomerTransactionCommon.CreateOrUpdateWithStatus(adminContext, customerTxn, CustomerTxnSource.InvoiceCreateOrUpdate);
                    }

                    invoice = lazyContext.Invoice.Find(invoice.Id);

                    if ((invoice.InvoiceType == InvoiceType.Invoice && invoice.TotalAmount < 0) || (invoice.InvoiceType == InvoiceType.CreditNote && invoice.TotalAmount > 0)) {
                        invoice.InvoiceType = invoiceType == InvoiceType.Invoice ? InvoiceType.CreditNote : InvoiceType.Invoice;
                        lazyContext.Save(invoice, false);

                        foreach (var invoiceDetail in invoice.InvoiceDetails) {
                            invoiceDetail.Amount = -invoiceDetail.Amount;
                            invoiceDetail.Tax = -invoiceDetail.Tax;
                            invoiceDetail.Discount = -invoiceDetail.Discount;
                            invoiceDetail.DiscountTax = -invoiceDetail.DiscountTax;
                            lazyContext.Save(invoiceDetail, false);
                        }
                    }

                    lazyContext.Entry(invoice).State = EntityState.Detached;

                    invoice = lazyContext.Invoice.Include(t => t.Debtor).Include(t => t.Agency).Include(t => t.DebtorContact).Include(t => t.InvoiceDetails).ThenInclude(t => t.TransactionDetailAllocations).Single(t => t.Id == invoice.Id);
                    invoice.UpdateTransactions(lazyContext, managementCustomerId);

                    ts.Complete();
                    return invoice;
                }
            }
        }

        public bool MatchTransactions(AppAdminContext adminContext, IPrincipal principal, int managementCustomerId) {
            if (managementCustomerId != (int)CustomerType.TravelogDev && managementCustomerId != (int)CustomerType.TravelogStaging && managementCustomerId != (int)CustomerType.TravelogProd)
                throw new InvalidOperationException(AppConstants.UnauthorisedAccessNotManagementCustomer);

            var managementCustomer = adminContext.Customer.Find(managementCustomerId);
            var customerTxns = GetCustomerTransactions(adminContext, managementCustomerId).Where(t => t.PaymentTransactionId > 0 && t.DocumentNo.Length > 0).AsEnumerable().Where(t => t.IsReceiptItem || t.IsInvoiceItem);

            if (IsAutoRun)
                customerTxns = customerTxns.Where(t => t.CustomerId > (int)CustomerType.TravelogDev);

            using (var lazyContext = new AppLazyContext(principal, managementCustomerId, HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                foreach (var customerTxn in customerTxns.GroupBy(t => new { t.CustomerId, t.PaymentTransactionId }).ToList()) {
                    int customerTxnId = adminContext.CustomerTransaction.Where(t => t.CustomerId == customerTxn.Key.CustomerId && t.PaymentTransactionId == customerTxn.Key.PaymentTransactionId).AsEnumerable().SingleOrDefault(t => t.IsReceiptItem)?.Id ?? 0;

                    if (customerTxnId == 0)
                        continue;

                    var receiptDetails = lazyContext.ReceiptDetail.Where(t => t.Receipt.Debtor.CustomerId == customerTxn.Key.CustomerId && t.CustomerTransactionId == customerTxnId).ToList();

                    if (receiptDetails.Count == 0)
                        continue;

                    foreach (var row in customerTxn.Where(t => t.PaymentTransactionId == customerTxn.Key.PaymentTransactionId).AsEnumerable().Where(t => t.IsInvoiceItem).ToList()) {
                        var invoiceDetails = lazyContext.InvoiceDetail.Where(t => t.Invoice.Debtor.CustomerId == row.CustomerId && t.CustomerTransactionId == row.Id).ToList();

                        if (invoiceDetails.Count == 0 || invoiceDetails.Sum(t => t.Amount + t.Tax - t.Discount - t.DiscountTax) != receiptDetails.Sum(t => t.Amount + t.Tax))
                            continue;

                        TransactionDetailAllocation txnDetailAllocation = null;

                        decimal receiptAmount = receiptDetails.Sum(t => t.Amount + t.Tax);
                        decimal invoiceAmount = invoiceDetails.Sum(t => t.Amount + t.Tax - t.Discount - t.DiscountTax);

                        decimal receiptAllocationAmount = 0;
                        decimal invoiceAllocationAmount = 0;

                        int groupNo = (lazyContext.TransactionDetailAllocation.Max(t => (int?)t.GroupNo) ?? 0) + 1;

                        foreach (var invoiceDetail in invoiceDetails) {
                            foreach (var receiptDetail in receiptDetails) {
                                var transactionDetail = lazyContext.TransactionDetail.SingleOrDefault(t1 => t1.Transaction.TransactionType == TransactionType.Invoice && t1.TransactionDetailType == TransactionDetailType.Normal && t1.LedgerType == LedgerType.DebtorLedger && t1.DebtorId == receiptDetail.Receipt.DebtorId && t1.InvoiceDetailId == invoiceDetail.Id && !t1.TransactionDetailAllocations.Any(t2 => t2.ReceiptDetailId == receiptDetail.Id));

                                if (transactionDetail?.TransactionDetailAllocations.Any(t => t.ReceiptDetailId == receiptDetail.Id || t.InvoiceDetailId == invoiceDetail.Id) ?? true)
                                    continue;

                                if (receiptAllocationAmount != receiptAmount) {
                                    txnDetailAllocation = new TransactionDetailAllocation {
                                        Id = 0,
                                        TransactionDetailId = transactionDetail.Id,
                                        ReceiptDetailId = receiptDetail.Id,
                                        NonBspDetailId = -1,
                                        PaymentDetailId = -1,
                                        InvoiceDetailId = -1,
                                        JournalDetailId = -1,
                                        AdjustmentId = -1,
                                        Amount = -(receiptDetail.Amount + receiptDetail.Tax),
                                        Reference = string.Format("Invoice No {0}", invoiceDetail.Invoice.DocumentNo),
                                        TransactionMatchStatus = TransactionMatchStatus.Matched,
                                        GroupNo = groupNo
                                    };

                                    lazyContext.Insert(txnDetailAllocation, false);
                                }

                                if (invoiceAllocationAmount != invoiceAmount) {
                                    if (!lazyContext.TransactionDetailAllocation.Any(t => t.TransactionDetailId == transactionDetail.Id && t.InvoiceDetailId == invoiceDetail.Id)) {
                                        txnDetailAllocation = txnDetailAllocation.Clone() as TransactionDetailAllocation;
                                        txnDetailAllocation.Id = 0;
                                        txnDetailAllocation.ReceiptDetailId = -1;
                                        txnDetailAllocation.InvoiceDetailId = invoiceDetail.Id;
                                        txnDetailAllocation.Amount = invoiceDetail.Amount + invoiceDetail.Tax - invoiceDetail.Discount - invoiceDetail.DiscountTax;
                                        txnDetailAllocation.Reference = string.Format("Receipt No {0}", receiptDetail.Receipt.DocumentNo);

                                        lazyContext.Insert(txnDetailAllocation, false);
                                    }

                                    if ((receiptDetail.Comments.Length == 0 || receiptDetail.Comments == "Online Payment" || receiptDetail.Comments == "Direct Deposit") && invoiceDetail.Description.Length > 0) {
                                        receiptDetail.Comments = invoiceDetail.Description;
                                        lazyContext.Save(receiptDetail, false);
                                    }

                                    receiptAllocationAmount += receiptDetail.Amount + receiptDetail.Tax;
                                    invoiceAllocationAmount += invoiceDetail.Amount + invoiceDetail.Tax - invoiceDetail.Discount - invoiceDetail.DiscountTax;
                                }
                            }
                        }
                    }
                }

                return true;
            }
        }

        private void NotifyTermsAndConditions(AppAdminContext adminContext, string contentRootPath, int managementCustomerId) {
            if (managementCustomerId != (int)CustomerType.TravelogDev && managementCustomerId != (int)CustomerType.TravelogStaging && managementCustomerId != (int)CustomerType.TravelogProd)
                throw new InvalidOperationException(AppConstants.UnauthorisedAccessNotManagementCustomer);

            DateTime lastWriteTime = AdminSettings.GetTermsAndConditionsLastWriteTime(contentRootPath);
            DateTime lastNotifiedTime = AdminSettings.TermsAndConditionsLastNotifiedTime(adminContext);

            if (lastWriteTime == DateTime.MinValue || lastWriteTime <= lastNotifiedTime)
                return;

            var customers = GetCustomers(adminContext, managementCustomerId);

            if (IsAutoRun)
                customers = customers.Where(t => t.Id > (int)CustomerType.TravelogDev);

            foreach (var customer in customers.ToList()) {
                Mail.Instance.SendMail(customer.BillingContactEmail, "Changes to our Terms & Conditions", string.Format(AppConstants.MailBodyNoReply, AppConstants.TermsAndConditionsChanged));
            }

            AdminSettings.TermsAndConditionsLastNotifiedTime(adminContext, DateTime.UtcNow);
        }

        private bool CreateOrUpdateManagementDbDebtors(AppAdminContext adminContext, IPrincipal principal, int managementCustomerId) {
            var managementCustomer = adminContext.Customer.Find(AppSettings.DbConnectionMode == DbConnectionMode.Development ? (int)CustomerType.TravelogDev : AppSettings.DbConnectionMode == DbConnectionMode.Staging ? (int)CustomerType.TravelogStaging : (int)CustomerType.TravelogProd);

            using (var lazyContext = new AppLazyContext(principal, managementCustomerId, HttpContext.IsExternalUser(), HttpContext.IsSuperUser())) {
                var managementAgency = lazyContext.Agency.Single(t => t.IsHeadOffice);

                foreach (var customer in GetCustomers(adminContext, managementCustomerId)) {
                    using (var ts = Utils.CreateTransactionScope()) {
                        var debtor = lazyContext.Debtor.SingleOrDefault(t => t.CustomerId == customer.Id) ?? lazyContext.Debtor.SingleOrDefault(t => t.Name.ToLower() == customer.LegalName.ToLower());

                        debtor ??= new Debtor {
                            Id = 0,
                            Code = Debtor.GetNewCode(lazyContext, customer.LegalName),
                            AgencyId = managementAgency.Id,
                            ReportingParentId = -1,
                            BillingParentId = -1,
                            AmadeusCid = string.Empty,
                            GalileoCid = string.Empty,
                            SabreCid = string.Empty,
                            CurrencyId = Currency.GetCurrency(lazyContext, customer.CurrencyCode).Id,
                            ClassId = -1,
                            LocationId = -1,
                            AgingCycle = AgingCycle.SevenDay,
                            AgingCycleStartDay = DayOfWeekExt.Monday,
                            PaymentTermId = 1,
                            MatchedTxnsReportOption = MatchedTxnsReportOption.ExcludeAll,
                            ItineraryPricingOption = ItineraryPricingOption.No,
                            PrismReportingTripId = -1,
                            Rules = string.Empty,
                            Remarks = string.Empty,
                            InvoiceValidationType = InvoiceValidationType.None
                        };

                        debtor.CustomerId = customer.Id;
                        debtor.Name = Debtor.GetUniqueName(lazyContext, debtor.Id, customer.LegalName);

                        if (debtor.Id <= 0) {
                            lazyContext.Insert(debtor, false);
                        }
                        else {
                            lazyContext.Save(debtor, false);
                        }

                        var debtorAddress = lazyContext.DebtorAddress.FirstOrDefault(t => t.DebtorId == debtor.Id);

                        debtorAddress ??= new DebtorAddress {
                            Id = 0,
                            DebtorId = debtor.Id,
                            AddressType = AddressType.Street,
                            IsDefault = true,
                            Address1 = customer.Address1,
                            Address2 = customer.Address2,
                            Locality = customer.Locality,
                            Region = customer.Region,
                            PostCode = customer.PostCode,
                            CountryCode = customer.CountryCode
                        };

                        if (debtorAddress.Id <= 0) {
                            lazyContext.Insert(debtorAddress, false);
                        }
                        else {
                            lazyContext.Save(debtorAddress, false);
                        }

                        var debtorContact = lazyContext.DebtorContact.FirstOrDefault(t => t.DebtorId == debtor.Id);

                        debtorContact ??= new DebtorContact {
                            Id = 0,
                            DebtorId = debtor.Id,
                            Title = string.Empty,
                            Name = customer.BillingContactName,
                            PhoneHome = string.Empty,
                            PhoneWork = customer.BillingContactPhone,
                            Mobile = string.Empty,
                            Fax = string.Empty,
                            Email = customer.BillingContactEmail,
                            IsDefault = true
                        };

                        if (debtorContact.Id <= 0) {
                            lazyContext.Insert(debtorContact, false);
                        }
                        else {
                            lazyContext.Save(debtorContact, false);
                        }

                        ts.Complete();
                    }
                }

                return true;
            }
        }

        private IQueryable<Customer> GetCustomers(AppAdminContext adminContext, int managementCustomerId) {
            if (managementCustomerId == (int)CustomerType.TravelogProd) {
                return adminContext.Customer.Include(t => t.CustomerTransactions).Where(t => t.Id > (int)CustomerType.TravelogProd && !t.ExcludeFromBilling);
            }
            else if (managementCustomerId == (int)CustomerType.TravelogStaging) {
                return adminContext.Customer.Include(t => t.CustomerTransactions).Where(t => t.Id < (int)CustomerType.TravelogStaging && t.Id >= (int)CustomerType.TravelogStagingTest9 && !t.ExcludeFromBilling);
            }
            else {
                return adminContext.Customer.Include(t => t.CustomerTransactions).Where(t => t.Id < (int)CustomerType.TravelogDev && t.Id >= (int)CustomerType.TravelogDevTest9 && !t.ExcludeFromBilling);
            }
        }

        private IQueryable<CustomerTransaction> GetCustomerTransactions(AppAdminContext adminContext, int managementCustomerId) {
            if (managementCustomerId == (int)CustomerType.TravelogProd) {
                return adminContext.CustomerTransaction.Include(t => t.Customer).Where(t => t.CustomerId > (int)CustomerType.TravelogProd && !t.Customer.ExcludeFromBilling);
            }
            else if (managementCustomerId == (int)CustomerType.TravelogStaging) {
                return adminContext.CustomerTransaction.Include(t => t.Customer).Where(t => t.CustomerId < (int)CustomerType.TravelogStaging && t.CustomerId >= (int)CustomerType.TravelogStagingTest9 && !t.Customer.ExcludeFromBilling);
            }
            else {
                return adminContext.CustomerTransaction.Include(t => t.Customer).Where(t => t.CustomerId < (int)CustomerType.TravelogDev && t.CustomerId >= (int)CustomerType.TravelogDevTest9 && !t.Customer.ExcludeFromBilling);
            }
        }
    }
}