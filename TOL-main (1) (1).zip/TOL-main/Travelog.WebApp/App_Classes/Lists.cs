using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Kendo.Mvc.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Dao.StaticMethods;
using Travelog.Biz.Enums;
using Travelog.WebApp.Models;

namespace Travelog.WebApp {
    public static class Lists {
        #region Lists
        public static List<SelectListItem> GetEnumList<T>(EnumOrderByType orderByType = EnumOrderByType.None, bool includeDefault = true) {
            var q = new List<SelectListItem>();

            foreach (var item in Enum.GetValues(typeof(T))) {
                if (!includeDefault && ((int)item == -1 || (int)item == 0 && item.ToString() == "All" || item.ToString() == "None" || item.ToString() == "NotSpecified"))
                    continue;

                var fi = item.GetType().GetField(item.ToString());
                var attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

                q.Add(new SelectListItem {
                    Value = ((int)item).ToString(),
                    Text = attributes.Length > 0 ? attributes[0].Description : item.ToString()
                });
            }

            switch (orderByType) {
                default:
                    return q;
                case EnumOrderByType.Value:
                    return q.OrderBy(t => t.Value.ToInt()).ToList();
                case EnumOrderByType.Text:
                    return q.OrderBy(t => t.Value.ToInt() == -1 || t.Text == "Not Specified" ? string.Empty : t.Text).ToList();
            }
        }

        public static IQueryable<object> GetAdjustmentTypeList(AppMainContext context, bool includeDefault) {
            var q = context.AdjustmentType.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new {
                    AdjustmentTypeId = row.Id,
                    Name = row.Id == -1 ? "Not Specified" : row.Name,
                    row.Description,
                    row.DebitType,
                    row.DebitTripId,
                    row.DebitDebtorId,
                    row.DebitCreditorId,
                    row.DebitChartOfAccountId,
                    row.CreditType,
                    row.CreditTripId,
                    row.CreditDebtorId,
                    row.CreditCreditorId,
                    row.CreditChartOfAccountId,
                    row.DebitDisableTypesNotSelected,
                    row.CreditDisableTypesNotSelected
                });
        }

        public static IQueryable<AgencyListModel> GetAgencyList(HttpContext httpContext, AppMainContext context, bool validateOtherAgencies = false, bool includeDefault = false) {
            var q = context.Agency.Include(t => t.ConsultantAgencies).AsQueryable();

            if (validateOtherAgencies && !httpContext.OtherAgencies())
                q = q.Where(t => t.Id == httpContext.CurrentDefaultAgencyId(null));

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return GetAgencyList(q);
        }

        public static IQueryable<AgencyListModel> GetAgencyList(AppMainContext context) {
            var q = context.Agency.Include(t => t.ConsultantAgencies).Where(t => t.Id > 0);
            return GetAgencyList(q);
        }

        private static IQueryable<AgencyListModel> GetAgencyList(IQueryable<Agency> agencies) {
            return agencies.OrderBy(t => t.Id == -1 ? 0 : t.IsHeadOffice ? 1 : 2).ThenBy(t => t.Name).Select(row => new AgencyListModel {
                Id = row.Id,
                Name = row.Id == -1 ? "Not Specified" : string.Format("{0}{1}", row.Name, row.IsHeadOffice ? " [HO]" : string.Empty),
                TaxAuditReportPeriod = row.TaxAuditReportPeriod,
                TravelDocumentTimeFormat = row.TravelDocumentTimeFormat,
                PayIdType = row.PayIdType,
                PayId = row.PayId,
                TravelPayUrl = row.TravelPayUrl,
                MintUrl = row.MintUrl,
                AccentColor = row.AccentColor,
                HighlightColor = row.HighlightColor,
                IsHeadOffice = row.IsHeadOffice,
                IsAccentColorPageHeaderFooterOnly = row.IsAccentColorPageHeaderFooterOnly
            });
        }

        public static IQueryable<SelectListItem> GetAgencyPseudoCityCodeList(AppMainContext context, int agencyId, Crs crs) {
            var q = context.AgencyPseudoCityCode.Include(t => t.Agency).Where(t => t.Crs == crs);

            if (agencyId > 0)
                q = q.Where(t => t.AgencyId == agencyId);

            return q.OrderBy(t => t.Agency.Name).ThenBy(t => t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = string.Format("{0}: {1}", row.Agency.Name, row.Name)
            });
        }

        public static IQueryable<SelectListItem> GetAgentList(AppMainContext context, bool includeDefault) {
            var q = context.Agent.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? "Not Specified" : row.Name
            });
        }

        public static IQueryable<SelectListItem> GetAircraftList(AppMainContext context) {
            return context.Aircraft
                .OrderBy(t => t.Id == -1 ? string.Empty : t.Name)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Id <= 0 ? row.Name : row.Code + ": " + row.Name
                });
        }

        public static IQueryable<SelectListItem> GetBankAccountList(AppMainContext context, bool includeDefault) {
            var q = context.BankAccount.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.AccountDescription).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? "Not Specified" : row.AccountDescription
            });
        }

        public static IQueryable<object> GetBankAccountListExt(AppMainContext context, DateTime documentDate, bool includeDefault) {
            var q = context.BankAccount.OrderBy(t => t.Id == -1 ? string.Empty : t.AccountDescription).AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.Select(row => new {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? "Not Specified" : row.AccountDescription,
                WithdrawalLimit = row.DailyWithdrawalLimit == 0 ? 0 : row.DailyWithdrawalLimit - (context.Payment.Where(t => t.DocumentDate == documentDate && t.BankAccountId == row.Id).Sum(t => (decimal?)(t.AmountPayable + t.AmountPayableTax)) ?? 0)
            });
        }

        public static IQueryable<object> GetBankAccountStatementList(AppMainContext context, int bankAccountId, bool includeDefault, bool isCompactView = false) {
            var q = BankAccountStatement.GetBankAccountStatementQuery(context, bankAccountId, includeDefault);

            if (isCompactView) {
                return q.Select(row => new {
                    BankAccountStatementId = row.Id,
                    Name = row.Id == -1 ? "All Bank Statements" : string.Concat("#", row.StatementNo, ": ", row.ClosingDate == DateTime.MinValue ? "Not Specified" : row.ClosingDate.ToShortDateStringExt()),
                    row.StatementNo,
                    OpeningDate = row.OpeningDate == DateTime.MinValue ? row.ClosingDate : row.OpeningDate,
                    row.ClosingDate,
                    row.OpeningBalance,
                    row.ClosingBalance
                });
            }

            return q.Select(row => new {
                BankAccountStatementId = row.Id,
                Name = row.Id == -1 ? "All Bank Statements" : string.Concat("#", row.StatementNo, ": ", row.OpeningDate == DateTime.MinValue && row.ClosingDate == DateTime.MinValue ? "Not Specified"
                    : row.OpeningDate == row.ClosingDate ? row.OpeningDate.ToShortDateStringExt()
                    : row.OpeningDate == DateTime.MinValue ? row.ClosingDate.ToShortDateStringExt()
                    : row.ClosingDate == DateTime.MinValue ? row.OpeningDate.ToShortDateStringExt()
                    : string.Concat(row.OpeningDate.ToShortDateStringExt(), " - ", row.ClosingDate.ToShortDateStringExt())),
                row.StatementNo,
                OpeningDate = row.OpeningDate == DateTime.MinValue ? row.ClosingDate : row.OpeningDate,
                row.ClosingDate,
                row.OpeningBalance,
                row.ClosingBalance
            });
        }

        public static IQueryable<SelectListItem> GetBspPaymentList(AppMainContext context) {
            return context.Bsp.Where(t => t.PaymentId > 0)
                .GroupBy(t => new { t.PaymentId, t.Payment.DocumentNo, t.Payment.ReturnDate })
                .Select(t1 => new { t1.Key.PaymentId, t1.Key.DocumentNo, t1.Key.ReturnDate, AmountPayable = t1.Sum(t2 => t2.AmountPayable) })
                .OrderByDescending(t => t.ReturnDate).ThenByDescending(t => t.PaymentId)
                .Select(row => new SelectListItem {
                    Value = row.PaymentId.ToString(),
                    Text = string.Format("{0:d}: {1} [{2:c2}]", row.ReturnDate, row.DocumentNo, row.AmountPayable)
                });
        }

        public static IQueryable<SelectListItem> GetCategoryList(AppMainContext context, bool includeDefault) {
            var q = context.Category.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<object> GetCalypsoCompanyList(AppMainContext context) {
            var q = context.CalypsoCompany;

            return q.OrderBy(t => t.Code).Select(row => new {
                Value = row.Code,
                Text = row.Id == -1 ? row.Name : row.Code + ": " + row.Name,
                row.CreditorAirId,
                row.SupplierAirId,
                row.CreditorLandId
            });
        }

        public static IQueryable<SelectListItem> GetChartOfAccountList(AppMainContext context, int agencyId, bool includeDefault, RowType rowType = RowType.Normal, bool excludeBankAccount = false, bool excludeRetainedProfits = false, ChartOfAccountType? chartOfAccountType = null) {
            var q = context.ChartOfAccount.Include(t => t.BankAccount).Include(t => t.ChartOfAccountRoles).AsQueryable();

            if (agencyId > 0)
                q = q.Where(t => t.Id <= 0 || t.AgencyId == agencyId);

            if (chartOfAccountType != null)
                q = q.Where(t => t.Id <= 0 || t.ChartOfAccountType == chartOfAccountType);

            if (rowType == RowType.Normal) {
                q = q.Where(t => t.Id <= 0 || t.RowType == RowType.Normal || t.RowType == RowType.UndistributedProfits || (!excludeRetainedProfits && t.RowType == RowType.RetainedProfits));
            }
            else {
                q = q.Where(t => t.Id <= 0 || t.RowType == rowType);
            }

            if (excludeBankAccount)
                q = q.Where(t1 => t1.Id <= 0 || !context.BankAccount.Any(t2 => t2.ChartOfAccountId == t1.Id));

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Code).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? "None" : row.Code + ": " + row.Name
            });
        }

        public static IQueryable<SelectListItem> GetClassList(AppMainContext context, string classCategory, bool includeDefault) {
            var q = context.Class.AsQueryable();

            ClassType[] classType = null;

            switch (classCategory) {
                default:
                    classType = new ClassType[] { ClassType.NotSpecified };
                    break;
                case "Client":
                    classType = new ClassType[] { ClassType.Client };
                    break;
                case "Debtor":
                    classType = new ClassType[] { ClassType.Debtor };
                    break;
                case "Creditor":
                    classType = new ClassType[] { ClassType.Creditor };
                    break;
                case "Supplier":
                    classType = new ClassType[] { ClassType.SupplierAccommodation, ClassType.SupplierAir, ClassType.SupplierCruise, ClassType.SupplierInsurance, ClassType.SupplierOther, ClassType.SupplierTour, ClassType.SupplierTransport };
                    break;
            }

            if (includeDefault) {
                q = context.Class.Where(t => t.Id <= 0 || classType.Contains(t.ClassType));
            }
            else {
                q = context.Class.Where(t => t.Id > 0 && classType.Contains(t.ClassType));
            }

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<SelectListItem> GetClubMembershipList(AppMainContext context, bool includeDefault) {
            var q = context.ClubMembership.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<SelectListItem> GetConditionList(AppMainContext context) {
            return context.Condition
                .OrderBy(t => t.Id == -1 ? string.Empty : t.Name)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Name
                });
        }

		public static IQueryable<SelectListItem> GetConsultantList(HttpContext httpContext, AppMainContext context, bool validateOtherConsultants = false, bool includeDefault = false) {
			var q = context.Consultant.Include(t => t.ConsultantAgencies).AsQueryable();

			if (validateOtherConsultants && !httpContext.OtherConsultants() && httpContext.CurrentConsultantId() > 0)
				q = q.Where(t => t.Id == httpContext.CurrentConsultantId(null));

			if (!includeDefault)
				q = q.Where(t => t.Id > 0);

			return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
				Value = row.Id.ToString(),
				Text = row.Id == -1 ? "Not Specified" : row.Name
			});
		}

		public static IQueryable<object> GetContactTitleList(AppMainContext context) {
            return context.ContactTitle.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new {
                row.Id,
                Value = row.Id == -1 ? string.Empty : row.Name,
                Text = row.Name,
                row.Gender
            });
        }

        public static IQueryable<object> GetCurrencyList(AppMainContext context, bool includeDefault) {
            var q = context.Currency.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? row.Name : row.Code + ": " + row.Name,
                row.Rate,
                row.OfficialRate
            });
        }

        public static IQueryable<CustomerListModel> GetCustomerList(AppAdminContext adminContext, string userId) {
            var q = adminContext.Customer.Include(t1 => t1.AspNetUserRoles).Where(t1 => t1.AspNetUserRoles.Any(t2 => t2.UserId == userId && t2.RoleId != UserRole.ReadOnly.Id && !t2.Inactive));

            switch (AppSettings.DbConnectionMode) {
                case DbConnectionMode.Production:
                    q = q.Where(t => t.Id >= (int)CustomerType.TravelogProd).OrderBy(t => t.Id == (int)CustomerType.TravelogProd ? 0 : 1).ThenBy(t => t.BusinessName);
                    break;
                case DbConnectionMode.Staging:
                    q = q.Where(t => t.Id <= (int)CustomerType.TravelogStaging && t.Id >= (int)CustomerType.TravelogStagingTest9).OrderByDescending(t => t.Id);
                    break;
                case DbConnectionMode.Development:
                    q = q.Where(t => t.Id <= (int)CustomerType.TravelogDev && t.Id >= (int)CustomerType.TravelogDevTest9).OrderByDescending(t => t.Id);
                    break;
            }

            return q.Select(row => new CustomerListModel {
                Id = row.Id,
                LegalName = row.LegalName,
                BusinessName = row.BusinessName.Length == 0 ? row.LegalName : row.BusinessName,
                Location = row.Location,
                IsManagementCustomer = row.IsManagementCustomer
            });
        }

        public static IQueryable<SelectListItem> GetDebtorAddressList(AppLazyContext lazyContext, int debtorId) {
            if (debtorId == 0)
                return new List<SelectListItem> { new SelectListItem { Value = "0", Text = string.Empty } }.AsQueryable();

            var debtor = lazyContext.Debtor.Find(debtorId);

            var debtorIds = new List<int> { debtorId };
            var billingParent = debtor.BillingParent;

            while (billingParent.Id > 0) {
                debtorIds.Add(billingParent.Id);
                billingParent = billingParent.BillingParent;
            }

            var q = lazyContext.DebtorAddress.Where(t => debtorIds.Contains(t.DebtorId)).OrderBy(t => t.IsDefault ? 0 : 1);

            return q.Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = string.Concat(row.Address1.Length == 0 ? string.Empty : string.Concat(row.Address1, " "), row.Address2.Length == 0 ? string.Empty : string.Concat(row.Address2, " "), row.Locality.Length == 0 ? string.Empty : string.Concat(row.Locality, " "), row.Region.Length == 0 ? string.Empty : string.Concat(row.Region, " "), row.CountryCode.Length == 0 ? string.Empty : row.CountryCode).Trim()
            });
        }

        public static IQueryable<object> GetDebtorContactList(AppMainContext lazyContext, int debtorId, bool canBook, bool canAuthorise, bool includeDefault) {
            if (debtorId == 0)
                return new List<object> { new { Id = 0, Name = string.Empty, CanAddContact = false } }.AsQueryable();

            var debtor = lazyContext.Debtor.Find(debtorId);

            var debtorIds = new List<int> { debtorId };
            var billingParent = debtor.BillingParent;

            while (billingParent.Id > 0) {
                debtorIds.Add(billingParent.Id);
                billingParent = billingParent.BillingParent;
            }

            var q = lazyContext.DebtorContact.Where(t => t.Id == -1 || debtorIds.Contains(t.DebtorId)).OrderBy(t => t.Name).AsQueryable();

            if (canBook)
                q = q.Where(t => t.Id == -1 || t.CanBook);

            if (canAuthorise)
                q = q.Where(t => t.Id == -1 || t.CanAuthorise);

            bool canAddContact = false;

            if (debtorId > 0 && canBook)
                canAddContact = canBook && !debtor.IsContactLimitedToCurrentList;

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? 0 : 1).Select(row => new {
                row.Id,
                row.Name,
                CanAddContact = canAddContact
            });
        }

        public static IQueryable<SelectListItem> GetDebtorCustomerList(AppAdminContext adminContext, bool excludeManagementCustomers) {
            var q = adminContext.Customer.AsQueryable();

            if (excludeManagementCustomers)
                q = q.Where(t => t.Id != (int)CustomerType.TravelogDev && t.Id != (int)CustomerType.TravelogStaging && t.Id != (int)CustomerType.TravelogProd);

            if (AppSettings.IsLocal) {
                q = q.OrderByDescending(t => t.Id);
            }
            else {
                switch (AppSettings.DbConnectionMode) {
                    case DbConnectionMode.Production:
                        q = q.Where(t => t.Id >= (int)CustomerType.TravelogProd).OrderBy(t => t.Id == (int)CustomerType.TravelogProd ? 0 : 1).ThenBy(t => t.BusinessName.Length == 0 ? t.LegalName : t.BusinessName);
                        break;
                    case DbConnectionMode.Staging:
                        q = q.Where(t => t.Id <= (int)CustomerType.TravelogStaging && t.Id >= (int)CustomerType.TravelogStagingTest9).OrderByDescending(t => t.Id);
                        break;
                    case DbConnectionMode.Development:
                        q = q.Where(t => t.Id <= (int)CustomerType.TravelogDev && t.Id >= (int)CustomerType.TravelogDevTest9).OrderByDescending(t => t.Id);
                        break;
                }
            }

            return q.Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.BusinessName.Length == 0 ? row.LegalName : row.BusinessName,
            });
        }

        public static IQueryable<SelectListItem> GetDestinationList(AppMainContext context, bool includeDefault) {
            var q = context.Destination.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<SelectListItem> GetDiscountReasonList(AppMainContext context) {
            return context.DiscountReason
                .OrderBy(t => t.Id == -1 ? string.Empty : t.Name)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Name
                });
        }

        public static IQueryable<CustomerListModel> GetExternalUserCustomerList(HttpContext httpContext, AppAdminContext adminContext) {
            if (!httpContext.IsGlobalUser() && !httpContext.IsExternalUser())
                return new List<CustomerListModel>().AsQueryable();

            var q = adminContext.Customer.Include(t => t.AspNetUsers).Include(t => t.AspNetUserRoles).ThenInclude(t => t.AspNetRoles).AsQueryable();

            switch (AppSettings.DbConnectionMode) {
                case DbConnectionMode.Production:
                    q = q.Where(t => t.Id >= (int)CustomerType.TravelogProd).OrderBy(t => t.Id == (int)CustomerType.TravelogProd ? 0 : 1).ThenBy(t => t.BusinessName);
                    break;
                case DbConnectionMode.Staging:
                    q = q.Where(t => t.Id <= (int)CustomerType.TravelogStaging && t.Id >= (int)CustomerType.TravelogStagingTest9).OrderByDescending(t => t.Id);
                    break;
                case DbConnectionMode.Development:
                    q = q.Where(t => t.Id <= (int)CustomerType.TravelogDev && t.Id >= (int)CustomerType.TravelogDevTest9).OrderByDescending(t => t.Id);
                    break;
            }

            return q.Select(row => new CustomerListModel {
                Id = row.Id,
                LegalName = row.LegalName,
                BusinessName = string.Concat(row.BusinessName.Length == 0 ? row.LegalName : row.BusinessName, row.Id == CustomerSettings.Setting(httpContext.CurrentCustomerId(null)).CustomerId ? " [Connected]" : string.Empty),
                Location = row.Location,
                IsManagementCustomer = row.IsManagementCustomer,
                CanConnectAsExternalUser = httpContext.IsSupportUser(null) && (row.AllowRemoteAssistance || !row.AspNetUserRoles.Any(t => t.AspNetRoles.Id == UserRole.CompanyAdministrator.Id) || row.AspNetUsers.Any(t => t.LockoutEnd > DateTime.UtcNow))
            });
        }

        public static List<SelectListItem> GetFiscalPeriodBudgetList(HttpContext httpContext, int settingId, FiscalPeriod fiscalPeriod) {
            var q = GeneralLedgerSettings.GetFiscalPeriodList(httpContext.CurrentCustomerId()).Where(t => t.SettingId == settingId).OrderBy(t => t.FiscalPeriodEndDate).ToList();

            var list = new List<SelectListItem>();
            int lastIndex = 0;

            switch (fiscalPeriod) {
                case FiscalPeriod.ThreePeriods:
                case FiscalPeriod.SixPeriods:
                    int j = 0;

                    if (fiscalPeriod == FiscalPeriod.ThreePeriods) {
                        j = 3;
                    }
                    else if (fiscalPeriod == FiscalPeriod.SixPeriods) {
                        j = 6;
                    }

                    for (int i = 0; i < q.Count; i += j) {
                        lastIndex = i + j - 1;

                        if (lastIndex > q.Count - 1)
                            lastIndex = q.Count - 1;

                        if (lastIndex >= 0) {
                            list.Add(new SelectListItem {
                                Value = q[i].SettingDetailId.ToString(),
                                Text = string.Format("{0:d} to {1:d}", q[i].FiscalPeriodStartDate, q[lastIndex].FiscalPeriodEndDate)
                            });
                        }
                    }

                    break;
                case FiscalPeriod.AllPeriods:
                    lastIndex = q.Count - 1;

                    if (lastIndex >= 0) {
                        list.Add(new SelectListItem {
                            Value = q[0].SettingDetailId.ToString(),
                            Text = string.Format("{0:d} to {1:d}", q[0].FiscalPeriodStartDate, q[lastIndex].FiscalPeriodEndDate)
                        });
                    }

                    break;
            }

            return list;
        }

        public static IEnumerable<object> GetFiscalPeriodList(HttpContext httpContext, DateTime fiscalYearStartDate) {
            return GeneralLedgerSettings.GetFiscalPeriodList(httpContext.CurrentCustomerId()).Where(t => t.FiscalYearStartDate == fiscalYearStartDate).OrderBy(t => t.FiscalPeriodEndDate).Select(row => new {
                Value = row.FiscalPeriodEndDate,
                Text = row.FiscalPeriodEndDateName,
                PeriodCurrentYearFrom = row.FiscalPeriodStartDate.ToShortDateStringExt(),
                PeriodCurrentYearTo = row.FiscalPeriodEndDate.ToShortDateStringExt(),
                PeriodCurrentYear = row.FiscalPeriodEndDate.ToString("MMM-yyyy"),
                PeriodPreviousYear = row.FiscalPeriodPreviousEndDate.ToString("MMM-yyyy"),
                PeriodCurrentYearName = row.FiscalPeriodEndDateName,
                PeriodPreviousYearName = row.FiscalPeriodPreviousEndDateName
            }).ToList();
        }

        public static List<object> GetFiscalYearList(HttpContext httpContext) {
            var q = new List<object>();

            foreach (var row in GeneralLedgerSettings.GetFiscalYearList(httpContext.CurrentCustomerId())) {
                DateTime month = row.FiscalYearStartDate.AddMonths(DateTime.Today.Month - row.FiscalYearStartDate.Month);

                if (month < row.FiscalYearStartDate)
                    month = month.AddYears(1);

                var period = Setting.GetRow(httpContext.CurrentCustomerId(), month);

                q.Add(new {
                    Value = row.FiscalYearStartDate.ToShortDateStringExt(),
                    Text = row.FiscalYearStartDateName,
                    PeriodCurrentYearFrom = period.FiscalPeriodStartDate.ToShortDateStringExt(),
                    PeriodCurrentYearTo = period.FiscalPeriodEndDate.ToShortDateStringExt(),
                    PeriodPreviousYearFrom = period.FiscalPeriodPreviousStartDate.ToShortDateStringExt(),
                    PeriodPreviousYearTo = period.FiscalPeriodPreviousEndDate.ToShortDateStringExt(),
                    PeriodCurrentYearName = period.FiscalPeriodEndDateName,
                    PeriodPreviousYearName = period.FiscalPeriodPreviousEndDateName,
                    YtdCurrentYearFrom = period.FiscalYearStartDate.ToShortDateStringExt(),
                    YtdCurrentYearTo = period.FiscalYearEndDate.ToShortDateStringExt(),
                    YtdPreviousYearFrom = period.FiscalYearPreviousStartDate.ToShortDateStringExt(),
                    YtdPreviousYearTo = period.FiscalYearPreviousEndDate.ToShortDateStringExt(),
                    YtdCurrentYearName = row.FiscalYearStartDateName,
                    YtdPreviousYearName = period.FiscalYearPreviousStartDateName
                });
            }

            return q;
        }

        public static IQueryable<SelectListItem> GetFormOfPaymentList(AppMainContext context, bool useFullDescription, bool excludeCash, bool includeDefault, bool excludeCreditCard = false, bool excludeAgencyCc = false, bool excludePaySupplierGross = false, bool excludeLoyaltyScheme = false) {
            var q = context.FormOfPayment.Where(FormOfPayment.PaymentWhereClause).OrderBy(t => t.Id == -1 ? string.Empty : t.Name).AsQueryable();

            if (excludeCash)
                q = q.Where(t => t.FormOfPaymentType != FormOfPaymentType.Cash);

            if (excludeCreditCard)
                q = q.Where(t => t.FormOfPaymentType != FormOfPaymentType.CreditCard && t.FormOfPaymentType != FormOfPaymentType.TravelCard);

            if (excludeAgencyCc)
                q = q.Where(t => t.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardNet && t.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardGross);

            if (excludePaySupplierGross)
                q = q.Where(t => t.FormOfPaymentType != FormOfPaymentType.PaySupplierGross);

            if (excludeLoyaltyScheme)
                q = q.Where(t => t.FormOfPaymentType != FormOfPaymentType.LoyaltyScheme);

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = useFullDescription ? row.PaySupplierDescription : row.Name
            });
        }

        public static IQueryable<object> GetFormOfPaymentListExt(AppMainContext context, bool excludeCash, bool includeDefault) {
            var q = context.FormOfPayment.Where(FormOfPayment.PaymentWhereClause).OrderBy(t => t.Id == -1 ? string.Empty : t.Name).AsQueryable();

            if (excludeCash)
                q = q.Where(t => t.FormOfPaymentType != FormOfPaymentType.Cash);

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.Select(row => new {
                FormOfPaymentId = row.Id,
                row.FormOfPaymentType,
                Name = row.PaySupplierDescription,
                row.LoyaltySchemePointValue,
                row.LoyaltySchemePointCost1,
                row.LoyaltySchemePointCost2,
                LoyaltySchemeIsTaxApplicable = row.LoyaltySchemeSaleType1.IsTaxApplicable || row.LoyaltySchemeSaleType2.IsTaxApplicable
            });
        }

        public static IQueryable<object> GetFormOfPaymentReceiptList(AppMainContext context, bool excludeCash, bool includeDefault) {
            var q = context.FormOfPayment.Where(FormOfPayment.ReceiptWhereClause).OrderBy(t => t.Id == -1 ? string.Empty : t.Name).AsQueryable();

            if (excludeCash)
                q = q.Where(t => t.FormOfPaymentType != FormOfPaymentType.Cash);

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.Select(row => new {
                Value = row.Id.ToString(),
                Text = row.Name,
                FormOfPaymentTypeId = (int)row.FormOfPaymentType,
                row.CreditCardLoyaltySchemeId,
                row.LoyaltySchemeValueIsReceiptAmount,
                row.LoyaltySchemeValueIsLocked,
                row.LoyaltySchemeCostIsLocked,
                LoyaltySchemeIsTaxApplicable = row.LoyaltySchemeSaleType1.IsTaxApplicable || row.LoyaltySchemeSaleType2.IsTaxApplicable
            });
        }

        public static IQueryable<object> GetFormOfPaymentListByFormOfPaymentType(AppMainContext context, FormOfPaymentType formOfPaymentType, bool includeDefault) {
            var q = context.FormOfPayment.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).AsQueryable();

            if (includeDefault)
                q = q.Where(t => t.Id == -1 || t.FormOfPaymentType == formOfPaymentType);
            else
                q = q.Where(t => t.Id > 0);

            return q.Select(row => new {
                Value = row.Id.ToString(),
                Text = row.Name,
                row.LoyaltySchemeValueIsReceiptAmount,
                row.LoyaltySchemeValueIsLocked,
                row.LoyaltySchemeCostIsLocked,
                LoyaltySchemeIsTaxApplicable = row.LoyaltySchemeSaleType1.IsTaxApplicable || row.LoyaltySchemeSaleType2.IsTaxApplicable
            });
        }

        public static IQueryable<SelectListItem> GetGroupList(AppMainContext context, bool includeDefault) {
            var q = context.Group.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<SelectListItem> GetInsurancePassengerList(AppMainContext context, int tripLineId) {
            var q = context.TripLineInsurancePassenger
                .Where(t => t.TripLineId == tripLineId)
                .OrderBy(t => t.Passenger.Id == -1 ? string.Empty : t.Passenger.LastName)
                .ThenBy(t => t.Passenger.Id == -1 ? string.Empty : t.Passenger.FirstName)
                ;

            return q.Select(row => new SelectListItem {
                Value = row.Passenger.Id.ToString(),
                Text = row.Passenger.FullName
            });
        }

        public static IQueryable<SelectListItem> GetInsurancePolicyList(AppMainContext context, int supplierId) {
            return context.InsurancePolicy.OrderBy(t => t.Name).Where(t => t.SupplierId == supplierId)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Name
                });
        }

        public static IQueryable<SelectListItem> GetInsurancePolicyPlanList(AppMainContext context, int insurancePolicyId) {
            return context.InsurancePolicyPlan.OrderBy(t => t.Name).Where(t => t.InsurancePolicyId == insurancePolicyId)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Name
                });
        }

        public static IQueryable<SelectListItem> GetInvoiceList(AppMainContext context, int tripId, int debtorId, bool includeDefault) {
            var q = context.Invoice.Include(t => t.InvoiceDetails).OrderBy(t => t.Id == -1 ? string.Empty : t.DocumentNo).AsQueryable();

            if (tripId <= 0 && debtorId <= 0) {
                if (includeDefault) {
                    q = q.Where(t => t.Id == -1);
                }
                else {
                    q = q.Take(0);
                }
            }
            else {
                if (tripId > 0) {
                    if (includeDefault) {
                        q = q.Where(t1 => t1.Id == -1 || t1.InvoiceDetails.Any(t2 => t2.TripId == tripId));
                    }
                    else {
                        q = q.Where(t1 => t1.InvoiceDetails.Any(t2 => t2.TripId == tripId));
                    }
                }

                if (debtorId > 0) {
                    if (includeDefault) {
                        q = q.Where(t => t.Id == -1 || t.DebtorId == debtorId);
                    }
                    else {
                        q = q.Where(t => t.DebtorId == debtorId);
                    }
                }
            }

            return q.Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? "Not Specified" : row.DocumentNo
            });
        }

        public static IQueryable<SelectListItem> GetLeisureActivityList(AppMainContext context) {
            return context.LeisureActivity.OrderBy(t => t.Name)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Name
                });
        }

        public static IQueryable<SelectListItem> GetLocationList(AppMainContext context, bool includeDefault) {
            var q = context.Location.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Name
                });
        }

        public static IQueryable<SelectListItem> GetMarkupStrategyList(AppMainContext context) {
            return context.MarkupStrategy
                .OrderBy(t => t.Id == -1 ? string.Empty : t.Name)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Name
                });
        }

        public static IQueryable<SelectListItem> GetMealServedList(AppMainContext context) {
            return context.MealServed.OrderBy(t => t.Id).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<SelectListItem> GetNonBspPaymentList(AppMainContext context) {
            return context.NonBsp.Where(t => t.PaymentId > 0)
                .GroupBy(t => new { t.PaymentId, t.Payment.DocumentNo, t.Payment.ReturnDate })
                .Select(t1 => new { t1.Key.PaymentId, t1.Key.DocumentNo, t1.Key.ReturnDate, AmountPayable = t1.Sum(t2 => t2.AmountPayable) })
                .OrderByDescending(t => t.ReturnDate).ThenByDescending(t => t.PaymentId)
                .Select(row => new SelectListItem {
                    Value = row.PaymentId.ToString(),
                    Text = string.Format("{0:d}: {1} [{2:c2}]", row.ReturnDate, row.DocumentNo, row.AmountPayable)
                });
        }

        public static IQueryable<SelectListItem> GetOfferedReasonList(AppMainContext context) {
            return context.OfferedReason
                .OrderBy(t => t.Id == -1 ? string.Empty : t.Name)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Name
                });
        }

        public static IQueryable<SelectListItem> GetPassengerListByProfileId(AppMainContext context, int profileId) {
            var q = context.Passenger.AsQueryable();

            if (profileId <= 0) {
                q = q.Take(0);
            }
            else {
                q = q.Where(t1 => t1.ProfileId == profileId);
            }

            return q.GroupBy(t => new { t.Title, t.FirstName, t.LastName }).OrderBy(t1 => t1.Min(t2 => t2.Id) == -1 ? string.Empty : t1.Key.LastName).ThenBy(t => t.Key.FirstName).Select(row => new SelectListItem {
                Value = row.Max(t => t.Id).ToString(),
                Text = string.Concat(row.Key.Title, " ", row.Key.FirstName, " ", row.Key.LastName).Trim()
            });
        }

        public static IQueryable<SelectListItem> GetPassengerListByTripId(AppMainContext context, int tripId, bool includeDefault, int excludePassengerId = -1) {
            var q = context.Passenger.Include(t => t.Profile).ThenInclude(t => t.ProfilePassengers).AsQueryable();

            if (includeDefault) {
                if (tripId <= 0) {
                    q = q.Where(t1 => t1.Id == -1);
                }
                else {
                    q = q.Where(t1 => t1.Id == -1 || t1.TripId == tripId || t1.Profile.ProfilePassengers.Any(t2 => t2.TripId == t1.TripId && t2.TripId == tripId));
                }
            }
            else if (tripId <= 0) {
                q = q.Take(0);
            }
            else {
                q = q.Where(t1 => t1.TripId == tripId || t1.Profile.ProfilePassengers.Any(t2 => t2.TripId == t1.TripId && t2.TripId == tripId));
            }

            if (excludePassengerId != -1)
                q = q.Where(t => t.Id != excludePassengerId);

            return q.GroupBy(t => new { t.Title, t.FirstName, t.LastName }).OrderBy(t1 => t1.Min(t2 => t2.Id) == -1 ? string.Empty : t1.Key.LastName).ThenBy(t => t.Key.FirstName).Select(row => new SelectListItem {
                Value = row.Max(t => t.Id).ToString(),
                Text = string.Concat(row.Key.Title, " ", row.Key.FirstName, " ", row.Key.LastName).Trim()
            });
        }

        public static IQueryable<SelectListItem> GetPassengerListByTripIdOrDebtorIdOrCreditorId(AppMainContext context, int tripId, int debtorId, int creditorId, bool includeDefault, int excludePassengerId = -1) {
            var q = context.Passenger.Include(t => t.Profile).ThenInclude(t => t.ProfilePassengers).AsQueryable();

            if (includeDefault) {
                if (tripId <= 0 && debtorId <= 0 && creditorId <= 0) {
                    q = q.Where(t1 => t1.Id == -1);
                }
                else {
                    if (tripId > 0)
                        q = q.Where(t1 => t1.Id == -1 || t1.TripId == tripId || t1.Profile.ProfilePassengers.Any(t2 => t2.TripId == t1.TripId && t2.TripId == tripId));

                    if (debtorId > 0)
                        q = q.Where(t => t.Id == -1 || t.Trip.DebtorId == debtorId || t.Profile.DebtorId == debtorId);

                    if (creditorId > 0)
                        q = q.Where(t1 => t1.Id == -1 || t1.TripLineAirPassengers.Any(t2 => t2.CreditorId == creditorId));
                }
            }
            else if (tripId <= 0 && debtorId <= 0 && creditorId <= 0) {
                q = q.Take(0);
            }
            else {
                if (tripId > 0)
                    q = q.Where(t1 => t1.TripId == tripId || t1.Profile.ProfilePassengers.Any(t2 => t2.TripId == t1.TripId && t2.TripId == tripId));

                if (debtorId > 0)
                    q = q.Where(t => t.Trip.DebtorId == debtorId || t.Profile.DebtorId == debtorId);

                if (creditorId > 0)
                    q = q.Where(t1 => t1.TripLineAirPassengers.Any(t2 => t2.CreditorId == creditorId));
            }

            if (excludePassengerId != -1)
                q = q.Where(t => t.Id != excludePassengerId);

            return q.GroupBy(t => new { t.Title, t.FirstName, t.LastName }).OrderBy(t1 => t1.Min(t2 => t2.Id) == -1 ? string.Empty : t1.Key.LastName).ThenBy(t => t.Key.FirstName).Select(row => new SelectListItem {
                Value = row.Max(t => t.Id).ToString(),
                Text = string.Concat(row.Key.Title, " ", row.Key.FirstName, " ", row.Key.LastName).Trim()
            });
        }

        public static IQueryable<object> GetPassengerNameList(AppMainContext context, bool includeTitle) {
            var q = context.Passenger
                    .Where(t => t.Id > 0)
                    .Select(t => new { Title = includeTitle ? t.Title : string.Empty, t.FirstName, t.LastName })
                    .Distinct().OrderBy(t => t.LastName).ThenBy(t => t.FirstName);

            return q.Select(row => new {
                Text = (row.Title + " " + row.FirstName + " " + row.LastName).Trim()
            });
        }

        public static IQueryable<object> GetPaymentMethodList(AppMainContext context, AccountType accountType, FormOfPaymentType formOfPaymentType, int formOfPaymentId, int tripId, int debtorId, int creditorId, int chartOfAccountId, bool includeDefault, bool? isActive = null, int? id = null) {
            var q = context.PaymentMethod.OrderBy(t => t.Id == -1 ? string.Empty : t.FormOfPayment.Name).ThenBy(t => t.AccountNo).AsQueryable();

            if (formOfPaymentType != FormOfPaymentType.NotSpecified)
                q = q.Where(t => t.Id == -1 || t.FormOfPayment.FormOfPaymentType == formOfPaymentType);

            if (formOfPaymentId != -1)
                q = q.Where(t => t.Id == -1 || t.FormOfPaymentId == formOfPaymentId);

            switch (accountType) {
                default:
                    if (id == null && (tripId > 0 || debtorId > 0 || creditorId > 0 || chartOfAccountId > 0))
                        q = q.Where(t => t.Id == -1 || (t.TripId > 0 && t.TripId == tripId) || (t.DebtorId > 0 && t.DebtorId == debtorId) || (t.CreditorId > 0 && t.CreditorId == creditorId) || (t.ChartOfAccountId > 0 && t.ChartOfAccountId == chartOfAccountId));

                    break;
                case AccountType.Client:
                    q = q.Where(t => t.Id == -1 || t.TripId == tripId);
                    break;
                case AccountType.Debtor:
                    q = q.Where(t => t.Id == -1 || t.DebtorId == debtorId);
                    break;
                case AccountType.Creditor:
                    q = q.Where(t => t.Id == -1 || t.CreditorId == creditorId);
                    break;
                case AccountType.GeneralLedger:
                    q = q.Where(t => t.Id == -1 || t.ChartOfAccountId == chartOfAccountId);
                    break;
            }

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (isActive != null)
                q = q.Where(t => t.IsActive == isActive);

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.Select(row => new {
                Value = row.Id.ToString(),
                Text = string.Concat(row.FormOfPayment.Name, row.AccountNo.Length == 0 ? string.Empty : string.Concat(": ", row.AccountNo)),
                row.AccountNo,
                AccountName = row.PaymentDetails1,
                ExpiryDate = string.Format("{0:d2}/{1}", row.ExpiryDate.Month, row.ExpiryDate.Year)
            });
        }

        public static IQueryable<object> GetPaymentMethodCreditCardList(AppMainContext context, AccountType accountType, int formOfPaymentId, int profileId, int tripId, int debtorId, int creditorId, int chartOfAccountId, bool includeDefault, bool? isActive = null) {
            var q = context.PaymentMethod.Include(t => t.FormOfPayment)
                .Where(t => t.Id == -1 || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.CreditCard)
                .OrderBy(t => t.Id == -1 ? string.Empty : t.FormOfPayment.Name)
                .ThenBy(t => t.AccountNo)
                .AsQueryable();

            if (formOfPaymentId != -1)
                q = q.Where(t => t.Id == -1 || t.FormOfPaymentId == formOfPaymentId);

            switch (accountType) {
                default:
                    if (profileId > 0 || tripId > 0 || debtorId > 0 || creditorId > 0 || chartOfAccountId > 0)
                        q = q.Where(t => t.Id == -1 || (t.ProfileId > 0 && t.ProfileId == profileId) || (t.TripId > 0 && t.TripId == tripId) || (t.DebtorId > 0 && t.DebtorId == debtorId) || (t.CreditorId > 0 && t.CreditorId == creditorId) || (t.ChartOfAccountId > 0 && t.ChartOfAccountId == chartOfAccountId));

                    break;
                case AccountType.Client:
                    q = q.Where(t => t.Id == -1 || t.ProfileId == profileId || t.TripId == tripId);
                    break;
                case AccountType.Debtor:
                    q = q.Where(t => t.Id == -1 || t.DebtorId == debtorId);
                    break;
                case AccountType.Creditor:
                    q = q.Where(t => t.Id == -1 || t.CreditorId == creditorId);
                    break;
                case AccountType.GeneralLedger:
                    q = q.Where(t => t.Id == -1 || t.ChartOfAccountId == chartOfAccountId);
                    break;
            }

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (isActive != null)
                q = q.Where(t => t.IsActive == isActive);

            return q.Select(row => new {
                Value = row.Id.ToString(),
                Text = string.Concat(row.AccountNo, row.AccountNo.Length == 0 ? string.Empty : ": ", row.PaymentDetails1),
                row.AccountNo,
                AccountName = row.PaymentDetails1,
                ExpiryDate = string.Format("{0:d2}/{1}", row.ExpiryDate.Month, row.ExpiryDate.Year),
                IsRecurringPayment = false
            });
        }

        public static IQueryable<SelectListItem> GetPaymentPayeeList(AppMainContext context, AccountType accountType, int accountId) {
            var q = context.Payment.Where(t => t.Payee.Length > 0);

            switch (accountType) {
                case AccountType.Client:
                    q = q.Where(t => t.TripId == accountId);
                    break;
                case AccountType.Debtor:
                    q = q.Where(t => t.DebtorId == accountId);
                    break;
                case AccountType.Creditor:
                    q = q.Where(t => t.CreditorId == accountId);
                    break;
                case AccountType.GeneralLedger:
                    q = q.Where(t => t.ChartOfAccountId == accountId);
                    break;
            }

            return q.Select(t => new { t.Payee }).Distinct().OrderBy(t => t.Payee).Select(row => new SelectListItem {
                Text = row.Payee
            });
        }

        public static IQueryable<SelectListItem> GetPaymentTermList(AppMainContext context) {
            return context.PaymentTerm.OrderBy(t => t.Term)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Name
                });
        }

        public static IQueryable<object> GetPrincipalPaymentMethodList(AppAdminContext adminContext, int customerId, bool? isActive = null) {
            var q = adminContext.CustomerPaymentMethod.Where(t => t.CustomerId == customerId);

            if (isActive != null)
                q = q.Where(t => t.IsActive == isActive);

            return q.OrderBy(t => t.CardNo).Select(row => new {
                Value = row.Id.ToString(),
                Text = string.Concat(row.CardNo, ": ", row.CardholderName),
                AccountNo = row.CardNo,
                AccountName = row.CardholderName,
                ExpiryDate = string.Format("{0:D2}/{1}", row.ExpiryDate.Month, row.ExpiryDate.Year),
                row.IsRecurringPayment
            });
        }

        public static List<SelectListItem> GetReceiptBankDepositList(AppMainContext context, int bankAccountId, bool includeDefault) {
            var q1 = context.Receipt.Where(t => t.Id == -1 || t.IsDeposit);

            if (bankAccountId > 0)
                q1 = q1.Where(t => t.BankAccountId == bankAccountId);

            if (!includeDefault)
                q1 = q1.Where(t => t.Id > 0);

            var q2 = q1.OrderBy(t => t.Id < 0 ? 0 : 1).ThenByDescending(t => t.DocumentDate).AsEnumerable()
                .Select(row => new SelectListItem {
                    Value = row.Id == -1 ? ((int)ReceiptBankDepositType.BankDeposits).ToString() : row.Id.ToString(),
                    Text = row.Id == -1 ? ReceiptBankDepositType.BankDeposits.GetEnumDescription() : string.Format("{0:g} [{1:c2}]", row.DocumentDate, row.GetTotalAmountGross(false))
                }).ToList();

            q2.Insert(0, new SelectListItem {
                Value = ((int)ReceiptBankDepositType.NotDeposited).ToString(),
                Text = ReceiptBankDepositType.NotDeposited.GetEnumDescription()
            });

            return q2;
        }

        public static IQueryable<SelectListItem> GetReceiptDetailLoyaltySchemeReferenceList(AppMainContext context, int tripId) {
            var q = context.ReceiptDetail
                .Where(t1 => t1.Id > 0 && t1.LoyaltySchemeReference.Length > 0 && ((t1.Receipt.TripId > 0 && t1.Receipt.TripId == tripId) || (t1.Receipt.Trip.ProfileId > 0 && t1.Receipt.Trip.Profile.Trips.Any(t2 => t2.Id == tripId))))
                .OrderBy(t => t.LoyaltySchemeReference).Select(t => new { t.LoyaltySchemeReference }).Distinct();

            return q.Select(row => new SelectListItem {
                Value = row.LoyaltySchemeReference,
                Text = row.LoyaltySchemeReference
            });
        }

        public static IQueryable<SelectListItem> GetReceiptList(HttpContext httpContext, AppMainContext context, int tripId, int debtorId, int creditorId, bool includeDefault) {
            int agencyId = httpContext.CurrentDefaultAgencyId();

            var q = context.Receipt.OrderBy(t => t.Id == -1 ? string.Empty : t.DocumentNo).AsQueryable();

            if (tripId > 0) {
                if (includeDefault) {
                    q = q.Where(t => t.Id == -1 || t.TripId == tripId);
                }
                else {
                    q = q.Where(t => t.TripId == tripId);
                }
            }

            if (debtorId > 0) {
                if (includeDefault) {
                    q = q.Where(t => t.Id == -1 || t.DebtorId == debtorId);
                }
                else {
                    q = q.Where(t => t.DebtorId == debtorId);
                }
            }

            if (creditorId > 0) {
                if (includeDefault) {
                    q = q.Where(t => t.Id == -1 || t.CreditorId == creditorId);
                }
                else {
                    q = q.Where(t => t.CreditorId == creditorId);
                }
            }

            return q.Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? "Not Specified" : row.DocumentNo
            });
        }

        public static IQueryable<SelectListItem> GetReceiptPayerList(AppMainContext context, AccountType accountType, int accountId) {
            var q = context.Receipt.Where(t => t.Payer.Length > 0);

            switch (accountType) {
                case AccountType.Client:
                    q = q.Where(t => t.TripId == accountId);
                    break;
                case AccountType.Debtor:
                    q = q.Where(t => t.DebtorId == accountId);
                    break;
                case AccountType.Creditor:
                    q = q.Where(t => t.CreditorId == accountId);
                    break;
                case AccountType.GeneralLedger:
                    q = q.Where(t => t.ChartOfAccountId == accountId);
                    break;
            }

            return q.Select(t => new { t.Payer }).Distinct().Select(row => new SelectListItem {
                Text = row.Payer
            });
        }

        public static IQueryable<SelectListItem> GetRegionList(AppMainContext context, bool includeDefault) {
            var q = context.Region.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Name
                });
        }

        public static List<SelectListItem> GetRolesList(AppAdminContext adminContext, bool includeSystemAdministrator = false, bool includeDefault = false) {
            List<SelectListItem> q = null;

            if (includeSystemAdministrator) {
                q = adminContext.AspNetRoles.Where(t => t.Id != UserRole.ReadOnly.Id).OrderBy(t => t.SeqNo).Select(row => new SelectListItem {
                    Value = row.Id,
                    Text = row.Name
                }).ToList();
            }
            else {
                q = adminContext.AspNetRoles.Where(t => t.Id != UserRole.ReadOnly.Id && t.Id != UserRole.SystemAdministrator.Id).OrderBy(t => t.SeqNo).Select(row => new SelectListItem {
                    Value = row.Id,
                    Text = row.Name
                }).ToList();
            }

            if (includeDefault)
                q.Insert(0, new SelectListItem { Value = Guid.Empty.ToString(), Text = "No Access" });

            return q;
        }

        public static IEnumerable<object> GetSalesAnalysisPeriodList(AppMainContext context, SalesAnalysisPeriodType salesAnalysisPeriodType) {
            IEnumerable<object> q = null;

            DateTime documentDate = DateTime.Today;
            documentDate = new DateTime(documentDate.Year, documentDate.Month, 1).AddMonths(1).AddDays(-1);

            switch (salesAnalysisPeriodType) {
                case SalesAnalysisPeriodType.CurrentMonth:
                case SalesAnalysisPeriodType.PreviousMonth:
                    q = context.Transaction.Where(t => t.Id > 0 && t.DocumentDate <= documentDate).Select(t => string.Format("{0:MMM-yyyy}", t.DocumentDate)).AsEnumerable().Distinct().Select(row => new {
                        Value = string.Format("{0:d}", DateTime.Parse(string.Format("01-{0}", row))),
                        Text = string.Format("{0:d} to {1:d}", DateTime.Parse(string.Format("01-{0}", row)), DateTime.Parse(string.Format("01-{0}", row)).AddMonths(1).AddDays(-1)),
                        StartDate = DateTime.Parse(string.Format("01-{0}", row)),
                        EndDate = DateTime.Parse(string.Format("01-{0}", row)).AddMonths(1).AddDays(-1)
                    }).OrderByDescending(t => t.StartDate);

                    break;
                case SalesAnalysisPeriodType.CalendarYear:
                    q = context.Transaction.Where(t => t.Id > 0).Select(t => string.Format("{0:yyyy}", t.DocumentDate)).AsEnumerable().Distinct().Select(row => new {
                        Value = string.Format("{0:d}", DateTime.Parse(string.Format("01-Jan-{0}", row))),
                        Text = string.Format("{0:d} to {1:d}", DateTime.Parse(string.Format("01-Jan-{0}", row)), DateTime.Parse(string.Format("31-Dec-{0}", row))),
                        StartDate = DateTime.Parse(string.Format("01-Jan-{0}", row)),
                        EndDate = DateTime.Parse(string.Format("31-Dec-{0}", row))
                    }).OrderByDescending(t => t.StartDate);

                    break;
                case SalesAnalysisPeriodType.FiscalYear:
                    q = context.Setting.Include(t => t.SettingDetails).Where(t => t.Id > 0).OrderByDescending(t => t.FiscalYearStartDate).Select(t => new { t.FiscalYearStartDate, t.FiscalYearEndDate }).AsEnumerable().Select(row => new {
                        Value = string.Format("{0:d}", row.FiscalYearStartDate),
                        Text = string.Format("{0:d} to {1:d}", row.FiscalYearStartDate, row.FiscalYearEndDate),
                        StartDate = row.FiscalYearStartDate,
                        EndDate = row.FiscalYearEndDate
                    });

                    break;
                case SalesAnalysisPeriodType.CustomView:
                    q = context.SalesAnalysisView.OrderByDescending(t => t.Id).Select(row => new {
                        Value = row.Id.ToString(),
                        Text = row.Name,
                        row.StartDate,
                        row.EndDate,
                        row.State
                    });

                    break;
            }

            return q;
        }

        public static IQueryable<SelectListItem> GetSaleTypeList(AppMainContext context, bool includeDefault) {
            var q = context.SaleType.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<object> GetSaleTypeListExt(AppMainContext context, bool includeDefault) {
            var q = context.SaleType.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new {
                row.Id,
                row.Name,
                row.IsTaxApplicable
            });

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q;
        }

        public static IQueryable<SelectListItem> GetSaleTypeGroupingList(AppMainContext context) {
            return context.SaleTypeGrouping
                .OrderBy(t => t.Id == -1 ? string.Empty : t.Name)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Name
                });
        }

        public static IQueryable<SelectListItem> GetServiceFeeTypeList(AppMainContext context, DebitCreditType? debitCreditType = null, bool includeDefault = false) {
            var q = context.ServiceFeeType.AsQueryable();

            if (debitCreditType != null)
                q = q.Where(t => t.AdjustmentType.DebitType == debitCreditType || t.AdjustmentType.CreditType == debitCreditType);

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id <= 0 ? "Not Specified" : row.Name
            });
        }

        public static IQueryable<SelectListItem> GetServiceTypeList(AppMainContext context, bool includeDefault) {
            var q = context.ServiceType.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<object> GetServiceTypeListExt(AppMainContext context, bool landTripLinesOnly, bool includeDefault) {
            var q = context.ServiceType.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).AsQueryable();

            if (landTripLinesOnly)
                q = q.Where(t => t.TripLineType == TripLineType.Accommodation || t.TripLineType == TripLineType.Transport || t.TripLineType == TripLineType.Cruise || t.TripLineType == TripLineType.Tour || t.TripLineType == TripLineType.OtherLand);

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.Select(row => new {
                ServiceTypeId = row.Id,
                row.Name,
                row.TripLineType
            });
        }

        public static IQueryable<SelectListItem> GetServiceTypeRateBasisListByTripLineType(AppMainContext context, TripLineType tripLineType) {
            var q = context.ServiceType.FirstOrDefault(t => t.TripLineType == tripLineType);

            int serviceTypeId = -1;

            if (q != null)
                serviceTypeId = q.Id;

            return GetServiceTypeRateBasisListByServiceTypeId(context, serviceTypeId, false);
        }

        public static IQueryable<SelectListItem> GetServiceTypeRateBasisListByServiceTypeId(AppMainContext context, int serviceTypeId, bool includeDefault) {
            var q = context.ServiceTypeRateBasis.OrderBy(t => t.Id).AsQueryable();

            if (includeDefault) {
                q = q.Where(t => t.Id == -1 || t.ServiceTypeId == serviceTypeId);
            }
            else {
                q = q.Where(t => t.ServiceTypeId == serviceTypeId);
            }

            return q.Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<SelectListItem> GetSourceList(AppMainContext context, bool includeDefault) {
            var q = context.Source.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<SelectListItem> GetSpecialRequestList(AppMainContext context) {
            return context.SpecialRequest
                .OrderBy(t => t.Code)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Code + ": " + row.Description
                });
        }

        public static IQueryable<SelectListItem> GetStandardCommentList(AppMainContext context, bool includeDefault, StandardCommentType standardCommentType = StandardCommentType.NotSpecified) {
            var q = context.StandardComment.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (standardCommentType != StandardCommentType.NotSpecified) {
                if (includeDefault) {
                    q = q.Where(t => t.Id <= 0 || t.StandardCommentType == standardCommentType);
                }
                else {
                    q = q.Where(t => t.StandardCommentType == standardCommentType);
                }
            }

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Code)
                .Select(row => new SelectListItem {
                    Value = row.Id.ToString(),
                    Text = row.Id == -1 ? "Not Specified" : row.Code
                });
        }

        public static IQueryable<SelectListItem> GetSupplierChainList(AppMainContext context, bool includeDefault, bool supplierServiceRateExistsOnly = false) {
            var q = context.SupplierChain.Include(t => t.Suppliers).ThenInclude(t => t.SupplierServiceRates).AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (supplierServiceRateExistsOnly)
                q = q.Where(t1 => t1.Suppliers.Any(t2 => t2.Id > 0 && t2.SupplierServiceRates.Count > 0));

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name)
            .Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<object> GetSupplierServiceList(AppMainContext context, bool includeDefault) {
            var q = context.SupplierService.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new {
                SupplierServiceId = row.Id,
                row.Name,
                row.ServiceTypeId,
                row.ServiceType.TripLineType
            });
        }

        public static IEnumerable<SelectListItem> GetTimeZoneIdList() {
            return TimeZoneInfo.GetSystemTimeZones().Select(t => new SelectListItem { Value = t.Id, Text = t.DisplayName });
        }

        public static IEnumerable<SelectListItem> GetTripLineAirPassengerList(AppLazyContext lazyContext, int customerId, int tripLineId, bool includeDefault, bool isNew, TransactionType transactionType = TransactionType.All) {
            var q1 = lazyContext.TripLineAirPassenger.OrderBy(t => t.Id == -1 ? 0 : 1).ThenBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName).AsQueryable();

            if (includeDefault) {
                q1 = q1.Where(t => t.Id == -1 || t.TripLineId == tripLineId);
            }
            else {
                q1 = q1.Where(t => t.TripLineId == tripLineId);
            }

            var q2 = q1.AsEnumerable();

            if (isNew) {
                switch (transactionType) {
                    default:
                        q2 = q2.Where(t => t.GetAmountPayable(customerId) != t.GetAmountPaid(lazyContext));
                        break;
                    case TransactionType.Receipt:
                        q2 = q2.Where(t => t.GetAmountReceivable(customerId) != t.GetAmountReceived(lazyContext));
                        break;
                    case TransactionType.Invoice:
                        q2 = q2.Where(t => t.GetAmountInvoiceable(customerId) != t.GetAmountInvoiced(lazyContext));
                        break;
                }
            }

            return q2.Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id <= 0 ? row.Passenger.FullName : string.Format("{0}{1}", string.Concat(row.Passenger.FullName, row.TripLineAir.TripLine.TripLineSelections.Any(t => t.QuoteNo == 0) ? string.Empty : " [Quote Only]", string.IsNullOrEmpty(row.Routing) ? string.Empty : string.Concat(" [", row.Routing, "]")), string.IsNullOrEmpty(row.TicketNo) ? string.Empty : string.Format(" | Ticket No {0}", row.TicketNo))
            });
        }

        public static IEnumerable<SelectListItem> GetTripItineraryListByTripId(AppMainContext context, int tripId, bool includePassengers = false) {
            var q = context.TripItinerary.Include(t => t.TripItineraryPassengers).ThenInclude(t => t.Passenger).Where(t => t.TripId == tripId);

            if (includePassengers)
                q = q.Where(t => t.TripItineraryDetails.Count > 0);

            return q.OrderBy(t => t.Name).AsEnumerable().Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name + (includePassengers && row.TripItineraryPassengers.Count > 0 ? " [" + string.Join(", ", row.TripItineraryPassengers.Select(t => t.Passenger.FullName)) + "]" : string.Empty)
            });
        }

        public static List<TripLineAirSegmentListModel> GetTripLineAirSegmentList(AppMainContext context, int tripId, int quoteNo) {
            var q = new List<TripLineAirSegmentListModel>();

            foreach (var row1 in context.TripLineAir.Include(t => t.TripLine).ThenInclude(t => t.TripLineSelections).Include(t => t.TripLineAirSegments).ThenInclude(t => t.DepartureCity).Include(t => t.TripLineAirSegments).ThenInclude(t => t.ArrivalCity).Where(t1 => t1.TripLine.TripId == tripId && (quoteNo < 0 || t1.TripLine.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo))).OrderBy(t => t.TripLineId)) {
                foreach (var row2 in row1.TripLineAirSegments.OrderBy(t => t.SeqNo).ThenBy(t => t.Id)) {
                    string route = string.Format("{0}/{1}", row2.DepartureCity.Code, row2.ArrivalCity.Code);

                    q.Add(new TripLineAirSegmentListModel {
                        TripLineId = row1.TripLineId,
                        RelatedTripLineId = row2.Id,
                        TripId = -2,
                        Description = string.IsNullOrEmpty(row2.FlightNo) && row2.DepartureDate <= context.VoidDate ? route
                            : !string.IsNullOrEmpty(row2.FlightNo) && row2.DepartureDate <= context.VoidDate ? string.Format("{0} - {1}", row2.FlightNo, route)
                            : string.IsNullOrEmpty(row2.FlightNo) && row2.DepartureDate > context.VoidDate ? string.Format("{0} - {1}", row2.DepartureDate.ToShortDateStringExt(), route)
                            : string.Format("{0} - {1} - {2}", row2.FlightNo, row2.DepartureDate.ToShortDateStringExt(), route)
                    });
                }
            }

            return q;
        }

        public static List<object> GetTripLineLandList(AppLazyContext lazyContext, int tripId, bool includeDefault) {
            var q = TripLineHelper.GetRows(lazyContext, tripId, -1)
                .Where(t => t.Id > 0 && (t.TripLineType == TripLineType.Accommodation || t.TripLineType == TripLineType.Transport || t.TripLineType == TripLineType.Cruise || t.TripLineType == TripLineType.Tour || t.TripLineType == TripLineType.OtherLand))
                .Select(row => new {
                    Value = row.Id,
                    Text = string.Format("{0}{1} | {2:c2}", string.IsNullOrEmpty(row.Description) ? row.TripLineType.GetEnumDescription() : row.Description, row.StartDate > lazyContext.VoidDate ? string.Format(" | {0:d}", row.StartDate) : string.Empty, row.AmountPayable),
                    row.TripLineType
                }).ToList<object>();

            if (includeDefault)
                q.Insert(0, new { Value = -1, Text = "Not Specified", TripLineType = TripLineType.All });

            return q;
        }

        public static List<object> GetTripLineList(AppLazyContext lazyContext, int tripId, bool includeDefault, bool isNew, int creditorId = 0, int supplierId = 0, int saleTypeId = 0) {
            var q = TripLineHelper.GetRows(lazyContext, tripId, -1, creditorId, supplierId, saleTypeId)
                .Where(t1 => t1.Id > 0 && t1.TripLineType != TripLineType.Remark && t1.TripLineSelections.Any(t2 => t2.QuoteNo == 0) && (!isNew || t1.AmountPayable != t1.AmountPaid))
                .Select(row => new {
                    Value = row.Id,
                    Text = string.Format("{0}{1} | {2:c2}", string.IsNullOrEmpty(row.Description) ? row.TripLineType.GetEnumDescription() : row.Description, row.StartDate > lazyContext.VoidDate ? string.Format(" | {0:d}", row.StartDate) : string.Empty, row.AmountPayable),
                    row.TripLineType
                }).ToList<object>();

            if (includeDefault)
                q.Insert(0, new { Value = -1, Text = "Not Specified", TripLineType = TripLineType.All });

            return q;
        }

        public static List<object> GetTripLineReceiptList(AppLazyContext lazyContext, int tripId, bool includeDefault, bool isNew) {
            var q = TripLineHelper.GetRows(lazyContext, tripId, -1)
                .Where(t1 => t1.Id > 0 && t1.TripLineType != TripLineType.Remark && t1.TripLineSelections.Any(t2 => t2.QuoteNo == 0) && (!isNew || t1.AmountReceivable != t1.AmountReceived))
                .Select(row => new {
                    Value = row.Id,
                    Text = string.Format("{0}{1} | {2:c2}", string.IsNullOrEmpty(row.Description) ? row.TripLineType.GetEnumDescription() : row.Description, row.StartDate > lazyContext.VoidDate ? string.Format(" | {0:d}", row.StartDate) : string.Empty, row.AmountReceivable),
                    row.TripLineType
                }).ToList<object>();

            if (includeDefault)
                q.Insert(0, new { Value = -1, Text = "Not Specified", TripLineType = TripLineType.All });

            return q;
        }

        public static List<SelectListItem> GetTripLineQuoteList(AppMainContext context, int tripId, int quoteNo = -2) {
            var quoteList = context.TripLineSelection.Include(t => t.TripLine).ThenInclude(t => t.Trip)
                .Where(t => t.TripLine.TripId == tripId && t.QuoteNo >= 0)
                .Select(t => new { t.TripLine.Trip, t.QuoteNo }).Distinct();

            if (quoteNo != -2)
                quoteList = quoteList.Where(t => t.QuoteNo != quoteNo);

            bool isBooking = quoteList.Any(t => t.QuoteNo == 0 || t.Trip.IsBooking);

            var q = quoteList.Select(row => new SelectListItem {
                Value = row.QuoteNo.ToString(),
                Text = row.QuoteNo == 0 ? "Booking" : string.Concat("Quote No ", row.QuoteNo)
            }).ToList();

            if (quoteNo == -2) {
                if (!q.Any(t => t.Value == "0") && isBooking)
                    q.Insert(0, new SelectListItem { Value = "0", Text = "Booking" });

                q.Add(new SelectListItem { Value = "-1", Text = "All Records" });
            }
            else {
                q.Add(new SelectListItem { Value = "-1", Text = "New Quote" });

                if (!q.Any(t => t.Value == "0")) {
                    if (isBooking) {
                        q.Add(new SelectListItem { Value = "0", Text = "Booking" });
                    }
                    else {
                        q.Add(new SelectListItem { Value = "0", Text = "New Booking" });
                    }
                }
            }

            return q;
        }

        public static List<SelectListItem> GetTripLineSegmentList(AppLazyContext lazyContext, int tripId, int quoteNo = -1) {
            var q1 = TripLineHelper.GetRows(lazyContext, tripId, quoteNo).Where(t => t.TripLineType != TripLineType.Remark);
            var q2 = GetTripLineAirSegmentList(lazyContext, tripId, quoteNo);
            var q3 = new List<TripLineAirSegmentListModel>();

            foreach (var row in q1) {
                q3.Add(new TripLineAirSegmentListModel {
                    TripLineId = row.Id,
                    RelatedTripLineId = row.RelatedTripLineId,
                    TripId = row.TripId,
                    Description = row.Description
                });

                if (row.TripLineType == TripLineType.Air && q2.Any(t => t.TripLineId == row.Id))
                    q3.AddRange(q2.Where(t => t.TripLineId == row.Id));
            }

            var q4 = q3.ConvertAll(row => new SelectListItem {
                Value = row.TripId == -2 ? string.Concat("2.", row.TripLineId, ".", row.RelatedTripLineId) : string.Concat("1.", row.TripLineId, ".", row.TripLineId),
                Text = row.Description,
                Disabled = row.TripId == -2
            });

            q4.Insert(0, new SelectListItem { Value = "-1", Text = "Not Specified" });

            return q4;
        }

        public static IQueryable<SelectListItem> GetUserList(AppAdminContext adminContext, int customerId) {
            return adminContext.AspNetUsers.Include(t => t.AspNetUserRoles).Where(t1 => t1.AspNetUserRoles.Any(t2 => t2.CustomerId == customerId) && !t1.Inactive).OrderBy(t => t.FullName).Select(row => new SelectListItem {
                Value = row.Id,
                Text = row.FullName
            });
        }

        public static IQueryable<object> GetVoucherDetailPassengerNameList(AppMainContext context, bool includeTitle) {
            var q = context.VoucherDetail
                    .Where(t => t.Id > 0)
                    .Select(row => new {
                        Title = includeTitle ? row.Passenger.Title : string.Empty,
                        row.Passenger.FirstName,
                        row.Passenger.LastName
                    }).Distinct().OrderBy(t => t.LastName).ThenBy(t => t.FirstName);

            return q.Select(row => new {
                Text = (row.Title + " " + row.FirstName + " " + row.LastName).Trim()
            });
        }

        public static IQueryable<SelectListItem> GetVoucherList(AppMainContext context, int tripId, bool includeDefault) {
            var q = context.Voucher.OrderBy(t => t.Id == -1 ? string.Empty : t.DocumentNo).AsQueryable();

            if (includeDefault) {
                q = q.Where(t => t.Id == -1 || t.TripId == tripId);
            }
            else {
                q = q.Where(t => t.TripId == tripId);
            }

            return q.Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? "Not Specified" : row.DocumentNo
            });
        }

        public static IQueryable<object> GetVoucherListExt(AppMainContext context, int creditorId, int supplierId, bool includeDefault) {
            var q = context.Voucher.Include(t => t.ReceiptDetails).OrderBy(t => t.Id == -1 ? string.Empty : t.DocumentNo).AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (creditorId > 0) {
                if (includeDefault) {
                    q = q.Where(t => t.Id == -1 || t.CreditorId == creditorId);
                }
                else {
                    q = q.Where(t => t.CreditorId == creditorId);
                }
            }

            if (supplierId > 0) {
                if (includeDefault) {
                    q = q.Where(t => t.Id == -1 || t.SupplierId == supplierId);
                }
                else {
                    q = q.Where(t => t.SupplierId == supplierId);
                }
            }

            return q.Select(row => new {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? "Not Specified" : string.Concat(row.DocumentNo, ": ", row.TripLineId == -1 ? string.Format("Trip No {0}: {1} {2} {3}", row.DocumentNo, row.Trip.Title, row.Trip.FirstName, row.Trip.LastName).Trim() : row.TripLine.Description),
                Amount = row.Commission - (row.ReceiptDetails.Where(t => t.VoucherId == row.Id && t.VoucherIsPartiallyReceipted).Sum(t => (decimal?)t.Amount) ?? 0),
                DaysAway = (row.Trip.ReturnDate - row.Trip.DepartureDate).Days,
                TicketedFare = row.TripLine.Gross
            });
        }
        #endregion

        #region Paged Lists
        public static IQueryable<SelectListItem> GetAirlineList(AppMainContext context, bool includeDefault, int? supplierId = null, int? id = null) {
            var q = context.Airline.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).AsQueryable();

            if (includeDefault) {
                if (supplierId > 0) {
                    var supplier = context.Supplier.Include(t => t.SupplierServiceTypes).ThenInclude(t => t.ServiceType).SingleOrDefault(t => t.Id == supplierId);

                    if (supplier?.SupplierServiceTypes.Any(t => t.ServiceType.TripLineType == TripLineType.Air) == true)
                        q = q.Where(t => t.Id > 0);
                }
            }
            else {
                q = q.Where(t => t.Id > 0);
            }

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? row.Name : row.Code + ": " + row.Name
            });
        }

        public static SelectListItem GetAirlineListValue(AppMainContext context, int? id) {
            return id == null ? new SelectListItem { Value = string.Empty, Text = string.Empty } : GetAirlineList(context, true, null, id).FirstOrDefault() ?? new SelectListItem { Value = string.Empty, Text = string.Empty };
        }

        public static IEnumerable<object> GetBookingList(AppMainContext context, Crs crs, bool isExport, int? tripId = null, int? id = null) {
            var q1 = context.TripLineAir.Include(t => t.TripLine).ThenInclude(t => t.Trip).ThenInclude(t => t.TripLines).Where(t => t.CrsPnrRef.Length > 0 && (t.TripLineId <= 0 || !(t.TripLine.Trip.CategoryId <= 0 || t.TripLine.Trip.DestinationId <= 0 || t.TripLine.Trip.ConsultantId <= 0 || t.TripLine.Trip.SourceId <= 0 || t.TripLine.Trip.DepartureDate == DateTime.MinValue || t.TripLine.Trip.FirstName.Length == 0 || t.TripLine.Trip.LastName.Length == 0)));
            var q2 = context.TripLineLand.Include(t => t.TripLine).ThenInclude(t => t.Trip).ThenInclude(t => t.TripLines).Where(t => t.CrsPnrRef.Length > 0 && (t.TripLineId <= 0 || !(t.TripLine.Trip.CategoryId <= 0 || t.TripLine.Trip.DestinationId <= 0 || t.TripLine.Trip.ConsultantId <= 0 || t.TripLine.Trip.SourceId <= 0 || t.TripLine.Trip.DepartureDate == DateTime.MinValue || t.TripLine.Trip.FirstName.Length == 0 || t.TripLine.Trip.LastName.Length == 0)));
            var q3 = context.TripLineServiceFee.Include(t => t.TripLine).ThenInclude(t => t.Trip).ThenInclude(t => t.TripLines).Where(t => t.CrsPnrRef.Length > 0 && (t.TripLineId <= 0 || !(t.TripLine.Trip.CategoryId <= 0 || t.TripLine.Trip.DestinationId <= 0 || t.TripLine.Trip.ConsultantId <= 0 || t.TripLine.Trip.SourceId <= 0 || t.TripLine.Trip.DepartureDate == DateTime.MinValue || t.TripLine.Trip.FirstName.Length == 0 || t.TripLine.Trip.LastName.Length == 0)));

            if (crs != Crs.NotSpecified) {
                q1 = q1.Where(t => t.TripLineId == -1 || t.Crs == crs);
                q2 = q2.Where(t => t.Crs == crs);
                q3 = q3.Where(t => t.Crs == crs);
            }

            q2 = q2.Where(t1 => !q1.Any(t2 => t2.TripLineId == t1.TripLineId));
            q3 = q3.Where(t1 => !q2.Any(t2 => t2.TripLineId == t1.TripLineId));

            var q4 = q1.Select(t => new TripLineListModel { TripLineId = t.TripLine.Trip.TripLines.First().Id, Trip = t.TripLine.Trip, Crs = t.Crs, CrsPnrRef = t.CrsPnrRef }).Distinct().AsEnumerable()
                .Concat(q2.Select(t => new TripLineListModel { TripLineId = t.TripLine.Trip.TripLines.First().Id, Trip = t.TripLine.Trip, Crs = t.Crs, CrsPnrRef = t.CrsPnrRef }).Distinct())
                .Concat(q3.Select(t => new TripLineListModel { TripLineId = t.TripLine.Trip.TripLines.First().Id, Trip = t.TripLine.Trip, Crs = t.Crs, CrsPnrRef = t.CrsPnrRef }).Distinct());

            if (id != null)
                q4 = q4.Where(t => t.TripLineId == id);

            return q4.Select(row => new {
                Value = row.TripLineId.ToString(),
                Text = row.Trip.Id == -1 ? isExport ? string.Concat("Current Quote/Booking ", tripId == null ? string.Empty : row.DocumentNo).Trim() : "New PNR" : string.Concat(row.CrsPnrRef.Length <= 2 ? string.Empty : string.Concat(row.Crs == Crs.Calypso ? row.CrsPnrRef.Substring(2) : row.CrsPnrRef, ": "), row.Trip.TripNo, ": ", string.Concat(row.Trip.Title, " ", row.Trip.FirstName, " ", row.Trip.LastName).Trim()),
                CrsPnrRef = row.Trip.Id == -1 || row.CrsPnrRef.Length <= 2 ? string.Empty : row.Crs == Crs.Calypso ? row.CrsPnrRef.Substring(2) : row.CrsPnrRef,
                LastName = row.Trip.Id == -1 ? string.Empty : row.Trip.LastName,
                CalypsoCompany = row.Trip.Id == -1 || row.CrsPnrRef.Length <= 2 ? string.Empty : row.CrsPnrRef.Substring(0, 2),
                TripId = row.Trip.Id,
                row.Trip.ProfileId
            }).Distinct().OrderBy(t => t.TripId == -1 ? 0 : 1).ThenByDescending(t => t.TripId).ThenBy(t => t.CrsPnrRef.Length == 0 ? 1 : 0).ThenBy(t => t.CrsPnrRef);
        }

        public static object GetBookingListValue(AppMainContext context, Crs crs, bool isExport, int? tripId, int? id) {
            return id == null ? new { Value = string.Empty, Text = string.Empty, CrsPnrRef = string.Empty, LastName = string.Empty, CalypsoCompany = string.Empty, ProfileId = -1 } : GetBookingList(context, crs, isExport, tripId, id).FirstOrDefault() ?? new { Value = string.Empty, Text = string.Empty, CrsPnrRef = string.Empty, LastName = string.Empty, CalypsoCompany = string.Empty, ProfileId = -1 };
        }

        public static IQueryable<SelectListItem> GetCityList(AppMainContext context, bool hasSupplierServiceRate = false, string idOrCode = null, bool codeIsId = false) {
            var q = context.City.Include(t => t.Country).AsQueryable();

            if (hasSupplierServiceRate)
                q = q.Where(t1 => context.SupplierServiceRate.Include(t => t.Supplier).Any(t2 => t1.Id > 0 && t2.Supplier.CityId == t1.Id));

            if (idOrCode != null) {
                if (codeIsId) {
                    q = q.Where(t => t.Code == idOrCode);
                }
                else {
                    q = q.Where(t => t.Id == int.Parse(idOrCode));
                }
            }

            return q.OrderBy(t => t.Id == -1 ? 0 : 1).ThenBy(t => t.Name).Select(row => new SelectListItem {
                Value = codeIsId ? row.Code : row.Id.ToString(),
                Text = row.Id <= 0 ? row.Name : row.Code + ": " + row.Name + (row.CountryId > 0 ? ", " + row.Country.Name : string.Empty)
            });
        }

        public static SelectListItem GetCityListValue(AppMainContext context, string idOrCode, bool codeIsId = false) {
            return idOrCode == null ? new SelectListItem { Value = string.Empty, Text = string.Empty } : GetCityList(context, false, idOrCode, codeIsId).FirstOrDefault() ?? new SelectListItem { Value = string.Empty, Text = string.Empty };
        }

        public static IQueryable<SelectListItem> GetCityCodeList(AppMainContext context, string idOrCode = null, bool codeIsId = true) {
            var q = context.City.Where(t => t.Id > 0);

            if (idOrCode != null) {
                if (codeIsId) {
                    q = q.Where(t => t.Code == idOrCode);
                }
                else {
                    q = q.Where(t => t.Id == int.Parse(idOrCode));
                }
            }

            return q.OrderBy(t => t.Code).Select(row => new SelectListItem {
                Value = codeIsId ? row.Code : row.Id.ToString(),
                Text = row.Code
            });
        }

        public static SelectListItem GetCityCodeListValue(AppMainContext context, string idOrCode, bool codeIsId = true) {
            return idOrCode == null ? new SelectListItem { Value = string.Empty, Text = string.Empty } : GetCityCodeList(context, idOrCode, codeIsId).FirstOrDefault() ?? new SelectListItem { Value = string.Empty, Text = string.Empty };
        }

        public static IQueryable<SelectListItem> GetCountryList(AppMainContext context, bool useCountryCode, bool includeDefault, string code = null, int? id = null) {
            var q = context.Country.AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (code != null) {
                q = q.Where(t => t.Code == code);
            }
            else if (id != null) {
                q = q.Where(t => t.Id == id);
            }

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = useCountryCode ? row.Code : row.Id.ToString(),
                Text = row.Id == -1 ? "Not Specified" : row.Code + ": " + row.Name
            });
        }

        public static SelectListItem GetCountryListValue(AppMainContext context, bool useCountryCode, string code, int? id) {
            return code == null && id == null ? new SelectListItem { Value = string.Empty, Text = string.Empty } : GetCountryList(context, useCountryCode, true, code, id).FirstOrDefault() ?? new SelectListItem { Value = string.Empty, Text = string.Empty };
        }

        public static IQueryable<SelectListItem> GetCreditorList(HttpContext httpContext, AppMainContext context, int agencyId, bool includeDefault, BspAgentType bspAgentType = BspAgentType.All, bool outstandingVouchers = false, int? id = null) {
            var q = context.Creditor.Include(t => t.Vouchers).ThenInclude(t => t.ReceiptDetails).AsQueryable();

            if (agencyId > 0 && CustomerSettings.Setting(httpContext.CurrentCustomerId()).AgencyType == AgencyType.MultiAgencyGLIndividual)
                q = q.Where(t => t.AgencyId == agencyId);

            if (outstandingVouchers)
                q = q.Where(t1 => context.Voucher.Include(t => t.ReceiptDetails).Any(t2 => t2.CreditorId == t1.Id && (t2.VoucherType == VoucherType.PaidDirect || t2.VoucherType == VoucherType.BillbackClientDirect) && t2.ReversalStatus == ReversalStatus.None && (!t2.ReceiptDetails.Any(t3 => t3.VoucherId == t2.Id) || t2.ReceiptDetails.Any(t3 => t3.VoucherId == t2.Id && t3.VoucherIsPartiallyReceipted))));

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            switch (bspAgentType) {
                case BspAgentType.Bsp:
                    if (includeDefault) {
                        q = q.Where(t => t.IsBspAgent || t.Id < 0);
                    }
                    else {
                        q = q.Where(t => t.IsBspAgent);
                    }

                    break;
                case BspAgentType.NonBsp:
                    if (includeDefault) {
                        q = q.Where(t => t.IsNonBspAgent || t.Id < 0);
                    }
                    else {
                        q = q.Where(t => t.IsNonBspAgent);
                    }

                    break;
                case BspAgentType.BspOrNonBsp:
                    if (includeDefault) {
                        q = q.Where(t => t.IsBspAgent || t.IsNonBspAgent || t.Id < 0);
                    }
                    else {
                        q = q.Where(t => t.IsBspAgent || t.IsNonBspAgent);
                    }

                    break;
                case BspAgentType.NeitherBspNorNonBsp:
                    if (includeDefault) {
                        q = q.Where(t => (!t.IsBspAgent && !t.IsNonBspAgent) || t.Id < 0);
                    }
                    else {
                        q = q.Where(t => !t.IsBspAgent && !t.IsNonBspAgent);
                    }

                    break;
            }

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static IQueryable<SelectListItem> GetCreditorListByTripLineType(HttpContext httpContext, AppMainContext context, TripLineType tripLineType, int agencyId, bool includeDefault, int? id = null) {
            var q = context.Creditor.Where(t1 => context.SupplierServiceType.Include(t => t.Supplier.SupplierCreditors).Any(t2 => t2.Supplier.SupplierCreditors.Any(t3 => t3.CreditorId == t1.Id) && t2.ServiceType.TripLineType != tripLineType));

            if (agencyId > 0 && CustomerSettings.Setting(httpContext.CurrentCustomerId()).AgencyType == AgencyType.MultiAgencyGLIndividual)
                q = q.Where(t => t.AgencyId == agencyId);

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            }).ToList().AsQueryable();
        }

        public static IQueryable<SelectListItem> GetCreditorListByServiceTypeId(HttpContext httpContext, AppMainContext context, int serviceTypeId, int agencyId, bool includeDefault, int? id = null) {
            var q = context.Creditor.Include(t => t.SupplierCreditors).ThenInclude(t => t.Supplier).ThenInclude(t => t.SupplierServiceTypes).AsQueryable();

            if (agencyId > 0 && CustomerSettings.Setting(httpContext.CurrentCustomerId()).AgencyType == AgencyType.MultiAgencyGLIndividual)
                q = q.Where(t => t.AgencyId == agencyId);

            if (serviceTypeId > 0)
                q = q.Where(t1 => t1.Id == -1 || t1.SupplierCreditors.Any(t2 => t2.CreditorId == t1.Id && t2.Supplier.SupplierServiceTypes.Any(t3 => t3.ServiceTypeId == serviceTypeId)));

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Name).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Name
            });
        }

        public static SelectListItem GetCreditorListValue(HttpContext httpContext, AppMainContext context, int? id) {
            return id == null ? new SelectListItem { Value = string.Empty, Text = string.Empty } : GetCreditorList(httpContext, context, 0, true, BspAgentType.All, false, id).FirstOrDefault() ?? new SelectListItem { Value = string.Empty, Text = string.Empty };
        }

        public static int GetCreditorListIndex(HttpContext httpContext, AppMainContext context, bool includeDefault, int? id) {
            return GetCreditorList(httpContext, context, 0, includeDefault).FindIndex(t => t.Value == id.ToStringExt());
        }

        public static IQueryable<SelectListItem> GetDebtorList(HttpContext httpContext, AppMainContext context, int agencyId, bool includeDefault, bool isSubDebtor = false, int billingParentId = 0, int? id = null) {
            var q = context.Debtor.AsQueryable();

            if (agencyId > 0 && CustomerSettings.Setting(httpContext.CurrentCustomerId()).AgencyType == AgencyType.MultiAgencyGLIndividual)
                q = q.Where(t => t.AgencyId == agencyId);

            if (isSubDebtor) {
                if (billingParentId == -1)
                    billingParentId = 0;

                if (includeDefault) {
                    q = q.Where(t => t.Id <= 0 || t.BillingParentId == billingParentId);
                }
                else {
                    q = q.Where(t => t.BillingParentId == billingParentId);
                }
            }

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Code).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? isSubDebtor ? "None" : row.Name : row.Code + ": " + row.Name
            });
        }

        public static SelectListItem GetDebtorListValue(HttpContext httpContext, AppMainContext context, int? id) {
            return id == null ? new SelectListItem { Value = string.Empty, Text = string.Empty } : GetDebtorList(httpContext, context, 0, true, false, 0, id).FirstOrDefault() ?? new SelectListItem { Value = string.Empty, Text = string.Empty };
        }

        public static IQueryable<DebtorListModel> GetDebtorListExt(HttpContext httpContext, AppLazyContext lazyContext, int agencyId, bool includeDefault, int? id = null) {
            var q = lazyContext.Debtor.AsQueryable();

            if (agencyId > 0 && CustomerSettings.Setting(httpContext.CurrentCustomerId()).AgencyType == AgencyType.MultiAgencyGLIndividual)
                q = q.Where(t => t.AgencyId == agencyId);

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.Code).Select(row => new DebtorListModel {
                DebtorId = row.Id,
                Name = row.Id == -1 ? row.Name : row.Code + ": " + row.Name,
                IsOrderNoMandatory = row.BillingHeadDebtor.IsOrderNoMandatory,
                IsContactMandatory = row.BillingHeadDebtor.IsContactMandatory,
                IsTravelReasonMandatory = row.BillingHeadDebtor.IsTravelReasonMandatory,
                IsAuthorisationMandatory = row.BillingHeadDebtor.IsAuthorisationMandatory,
                IsContactLimitedToCurrentList = row.BillingHeadDebtor.IsContactLimitedToCurrentList,
                OrderNoMinLength = row.BillingHeadDebtor.OrderNoMinLength
            });
        }

        public static DebtorListModel GetDebtorListExtValue(HttpContext httpContext, AppLazyContext lazyContext, int? id) {
            return id == null ? new DebtorListModel { DebtorId = null, Name = string.Empty } : GetDebtorListExt(httpContext, lazyContext, 0, true, id).FirstOrDefault() ?? new DebtorListModel { DebtorId = null, Name = string.Empty };
        }

        public static int GetDebtorListIndex(HttpContext httpContext, AppMainContext context, bool includeDefault, int? id) {
            return GetDebtorList(httpContext, context, 0, includeDefault).FindIndex(t => t.Value == id.ToStringExt());
        }

        public static object GetPaymentMethodPagedListValue(AppMainContext context, int? id) {
            return id == null ? new { Value = string.Empty, Text = string.Empty } : GetPaymentMethodList(context, AccountType.None, FormOfPaymentType.NotSpecified, -1, -1, -1, -1, -1, true, null, id).FirstOrDefault() ?? new { Value = string.Empty, Text = string.Empty };
        }

        public static IQueryable<ProfileListModel> GetProfileList(HttpContext httpContext, AppMainContext context, IDistributedCache cache, bool includeDefault, string defaultText = "Not Specified", int? id = null) {
            var q = context.Profile.AsQueryable();

            if (!httpContext.OtherAgencies())
                q = q.Where(t => httpContext.AgencyIds(cache).Contains(t.AgencyId));

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.OrderBy(t => t.Id == -1 ? string.Empty : t.LastName).ThenBy(t => t.FirstName).Select(row => new ProfileListModel {
                ProfileId = row.Id,
                Code = row.Code,
                AccountName = row.Id <= 0 ? defaultText : (row.Code + ": " + row.Title + " " + row.FirstName + " " + row.LastName).Trim(),
                FullName = row.FullName,
                Title = row.Title,
                FirstName = row.FirstName,
                LastName = row.LastName,
                PhoneNo = row.PhoneNo,
                Email = row.Email,
                BirthDate = row.BirthDate == DateTime.MinValue ? null : row.BirthDate
            });
        }

        public static ProfileListModel GetProfileListValue(HttpContext httpContext, AppMainContext context, IDistributedCache cache, string defaultText, int? id) {
            return id == null ? new ProfileListModel { ProfileId = null, Code = string.Empty, AccountName = string.Empty, Title = string.Empty, FirstName = string.Empty, LastName = string.Empty } : GetProfileList(httpContext, context, cache, true, defaultText, id).FirstOrDefault() ?? new ProfileListModel { ProfileId = null, Code = string.Empty, AccountName = defaultText, Title = string.Empty, FirstName = string.Empty, LastName = string.Empty };
        }

        public static IQueryable<object> GetSupplierList(AppMainContext context, bool includeDefault, BspAgentType bspAgentType = BspAgentType.All, bool supplierServiceRateExistsOnly = false, int[] nonBspIds = null, int? id = null) {
            IQueryable<Supplier> q = null;

            if (nonBspIds == null || nonBspIds.Length == 0)
                q = context.Supplier.Include(t => t.SupplierCreditors).Include(t => t.SupplierServiceRates).OrderBy(t => t.Id == -1 ? string.Empty : t.Name).AsQueryable();

            if (id == null) {
                if (nonBspIds == null || nonBspIds.Length == 0) {
                    if (!includeDefault)
                        q = q.Where(t => t.Id > 0);

                    if (supplierServiceRateExistsOnly)
                        q = q.Where(t => t.SupplierServiceRates.Count > 0);

                    switch (bspAgentType) {
                        case BspAgentType.Bsp:
                            if (includeDefault) {
                                q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.Creditor.IsBspAgent) || t1.Id < 0);
                            }
                            else {
                                q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.Creditor.IsBspAgent));
                            }

                            break;
                        case BspAgentType.NonBsp:
                            if (includeDefault) {
                                q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.Creditor.IsNonBspAgent) || t1.Id < 0);
                            }
                            else {
                                q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.Creditor.IsNonBspAgent));
                            }

                            break;
                        case BspAgentType.BspOrNonBsp:
                            if (includeDefault) {
                                q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.Creditor.IsBspAgent || t2.Creditor.IsNonBspAgent) || t1.Id < 0);
                            }
                            else {
                                q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.Creditor.IsBspAgent || t2.Creditor.IsNonBspAgent));
                            }

                            break;
                        case BspAgentType.NeitherBspNorNonBsp:
                            if (includeDefault) {
                                q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => !t2.Creditor.IsBspAgent && !t2.Creditor.IsNonBspAgent) || t1.Id < 0);
                            }
                            else {
                                q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => !t2.Creditor.IsBspAgent && !t2.Creditor.IsNonBspAgent));
                            }

                            break;
                    }
                }
                else {
                    return context.NonBsp.Include(t => t.Supplier).ThenInclude(t => t.SupplierCreditors).Where(t => nonBspIds.Contains(t.Id)).OrderBy(t => t.SupplierId == -1 ? string.Empty : t.Supplier.Name).Select(t => t.Supplier).Distinct().Select(row => new {
                        SupplierId = row.Id,
                        (row.SupplierCreditors.OrderByDescending(t => t.IsDefault).FirstOrDefault() ?? new SupplierCreditor { CreditorId = -1 }).CreditorId,
                        row.SaleTypeId,
                        Name = row.Id == -1 ? "Not Specified" : row.Name
                    });
                }
            }
            else {
                q = q.Where(t => t.Id == id);
            }

            return q.Select(row => new {
                SupplierId = row.Id,
                (row.SupplierCreditors.OrderByDescending(t => t.IsDefault).FirstOrDefault() ?? new SupplierCreditor { CreditorId = -1 }).CreditorId,
                row.SaleTypeId,
                Name = row.Id == -1 ? "Not Specified" : row.Name
            });
        }

        public static IQueryable<object> GetSupplierListByCreditorId(AppMainContext context, int creditorId, bool includeDefault, int? id = null) {
            var q = context.Supplier.Include(t => t.SupplierCreditors).OrderBy(t => t.Id == -1 ? string.Empty : t.Name).AsQueryable();

            if (creditorId > 0)
                q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.CreditorId == creditorId) || (includeDefault && t1.Id == -1));

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (id != null) {
                if (id == 0)
                    return q.Select(t => (object)t.Id);

                q = q.Where(t => t.Id == id);
            }

            return q.Select(row => new {
                SupplierId = row.Id,
                (row.SupplierCreditors.OrderByDescending(t => t.IsDefault).FirstOrDefault() ?? new SupplierCreditor { CreditorId = -1 }).CreditorId,
                row.SaleTypeId,
                Name = row.Id == -1 ? "Not Specified" : row.Name
            });
        }

        public static IQueryable<object> GetSupplierListByTripLineType(AppMainContext context, TripLineType tripLineType, bool includeDefault, bool supplierServiceRateExistsOnly = false, int? id = null) {
            var q = context.Supplier.Include(t => t.SupplierCreditors).Include(t => t.SupplierServiceRates).ThenInclude(t => t.SupplierService).ThenInclude(t => t.ServiceType).OrderBy(t => t.Id == -1 ? string.Empty : t.Name).AsQueryable();

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (supplierServiceRateExistsOnly) {
                if (tripLineType == TripLineType.All) {
                    q = q.Where(t => t.Id <= 0 || t.SupplierServiceRates.Count > 0);
                }
                else {
                    q = q.Where(t1 => t1.Id <= 0 || t1.SupplierServiceRates.Any(t2 => t2.SupplierService.ServiceType.TripLineType == tripLineType));
                }
            }

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.Select(row => new {
                SupplierId = row.Id,
                (row.SupplierCreditors.OrderByDescending(t => t.IsDefault).FirstOrDefault() ?? new SupplierCreditor { CreditorId = -1 }).CreditorId,
                row.SaleTypeId,
                row.Name
            });
        }

        public static object GetSupplierListValue(AppMainContext context, int[] nonBspIds, int? id) {
            return id == null ? new { SupplierId = (int?)null, CreditorId = (int?)null, Name = string.Empty } : GetSupplierList(context, true, BspAgentType.All, false, nonBspIds, id).FirstOrDefault() ?? new { SupplierId = (int?)null, CreditorId = (int?)null, Name = string.Empty };
        }

        public static int GetSupplierListByCreditorIdIndex(AppMainContext context, int creditorId, bool includeDefault, int? id) {
            return GetSupplierListByCreditorId(context, creditorId, includeDefault, 0).Cast<int>().FindIndex(t => t == id);
        }

        public static IQueryable<SelectListItem> GetTripLineAirPassengerTicketList(AppMainContext context, int? id = null) {
            var q1 = from t1 in context.TripLineAirPassenger
                     where t1.TicketNo.Length > 0
                     && !context.Bsp.Any(t2 => t2.DocumentNo == t1.TicketNo)
                     group t1 by new { t1.TicketNo } into t3
                     select t3;

            var q2 = q1.Select(row => new SelectListItem {
                Value = row.Max(t => t.Id).ToString(),
                Text = row.Key.TicketNo
            });

            if (id != null)
                q2 = q2.Where(t => t.Value == id.ToString());

            return q2;
        }

        public static SelectListItem GetTripLineAirPassengerTicketListValue(AppMainContext context, int? id) {
            return id == null ? new SelectListItem { Value = string.Empty, Text = string.Empty } : GetTripLineAirPassengerTicketList(context, id).FirstOrDefault() ?? new SelectListItem { Value = string.Empty, Text = string.Empty };
        }

        public static IQueryable<SelectListItem> GetTripList(HttpContext httpContext, AppMainContext context, IDistributedCache cache, bool bookingsOnly, bool includeDefault, bool nullIsNew, bool landOnly = false, int? id = null) {
            var q = context.Trip.Include(t => t.TripLines).AsQueryable();

            if (!httpContext.OtherAgencies())
                q = q.Where(t => httpContext.AgencyIds(cache).Contains(t.AgencyId));

            if (bookingsOnly)
                q = q.Where(t => t.IsBooking);

            if (landOnly)
                q = q.Where(t1 => t1.TripLines.Any(t2 => t2.TripLineType == TripLineType.Accommodation || t2.TripLineType == TripLineType.Transport || t2.TripLineType == TripLineType.Cruise || t2.TripLineType == TripLineType.Tour || t2.TripLineType == TripLineType.OtherLand));

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.OrderBy(t => t.Id <= 0 ? 0 : 1).ThenByDescending(t => t.Id).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? (nullIsNew ? "New Trip" : "Not Specified") : row.TripNo + ": " + (row.CategoryId <= 0 || row.DestinationId <= 0 || row.ConsultantId <= 0 || row.SourceId <= 0 || row.DepartureDate == DateTime.MinValue || row.FirstName.Length == 0 || row.LastName.Length == 0 ? "Incomplete" : (row.Title + " " + row.FirstName + " " + row.LastName).Trim())
            });
        }

        public static SelectListItem GetTripListValue(HttpContext httpContext, AppMainContext context, IDistributedCache cache, bool nullIsNew, int? id) {
            return id == null ? new SelectListItem { Value = string.Empty, Text = string.Empty } : GetTripList(httpContext, context, cache, false, true, nullIsNew, false, id).FirstOrDefault() ?? new SelectListItem { Value = string.Empty, Text = string.Empty };
        }

        public static int GetTripListIndex(HttpContext httpContext, AppMainContext context, IDistributedCache cache, bool bookingsOnly, bool includeDefault, bool nullIsNew, int? id) {
            return GetTripList(httpContext, context, cache, bookingsOnly, includeDefault, nullIsNew).FindIndex(t => t.Value == id.ToStringExt());
        }

        public static IQueryable<object> GetTripListExt(HttpContext httpContext, AppMainContext context, IDistributedCache cache, int consultantId, bool includeDefault, bool nullIsNew, int? id = null) {
            var q = context.Trip.AsQueryable();

            if (!httpContext.OtherAgencies())
                q = q.Where(t => httpContext.AgencyIds(cache).Contains(t.AgencyId));

            if (consultantId > 0)
                q = q.Where(t => t.ConsultantId == consultantId);

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.OrderBy(t => t.Id <= 0 ? 0 : 1).ThenByDescending(t => t.Id).Select(row => new {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? (nullIsNew ? "New Trip" : "Not Specified") : row.TripNo + ": " + (row.CategoryId <= 0 || row.DestinationId <= 0 || row.ConsultantId <= 0 || row.SourceId <= 0 || row.DepartureDate == DateTime.MinValue || row.FirstName.Length == 0 || row.LastName.Length == 0 ? "Incomplete" : (row.Title + " " + row.FirstName + " " + row.LastName).Trim()),
                row.ProfileId,
                TripId = row.Id,
                row.TripNo,
                row.ConsultantId,
                row.ChecklistContactMethod,
                row.ChecklistContactById,
                row.ChecklistFollowUpDate,
                row.ChecklistComments
            });
        }

        public static object GetTripListExtValue(HttpContext httpContext, AppMainContext context, IDistributedCache cache, bool nullIsNew, int? id) {
            return id == null ? new { Value = string.Empty, Text = string.Empty, ConsultantId = 1, ChecklistContactMethod = ContactMethod.NotSpecified, ChecklistContactById = -1, ChecklistFollowUpDate = DateTime.MinValue, ChecklistComments = string.Empty } : GetTripListExt(httpContext, context, cache, -1, true, nullIsNew, id).FirstOrDefault() ?? new { Value = string.Empty, Text = string.Empty, ConsultantId = -1, ChecklistContactMethod = ContactMethod.NotSpecified, ChecklistContactById = -1, ChecklistFollowUpDate = DateTime.MinValue, ChecklistComments = string.Empty };
        }

        public static IQueryable<SelectListItem> GetTripListByDebtorId(HttpContext httpContext, AppMainContext context, IDistributedCache cache, int debtorId, int subDebtorId, bool includeDefault, int? id = null) {
            var q = context.Trip.AsQueryable();

            if (!httpContext.OtherAgencies())
                q = q.Where(t => httpContext.AgencyIds(cache).Contains(t.AgencyId));

            if (debtorId <= 0 && subDebtorId <= 0) {
                if (!includeDefault)
                    q = q.Where(t => t.Id > 0);
            }
            else {
                if (includeDefault) {
                    q = q.Where(t => t.Id == -1 || t.DebtorId == debtorId || t.DebtorId == subDebtorId);
                }
                else {
                    q = q.Where(t => t.DebtorId == debtorId || t.DebtorId == subDebtorId);
                }
            }

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.OrderBy(t => t.Id == -1 ? 0 : 1).ThenByDescending(t => t.Id).Select(row => new SelectListItem {
                Value = row.Id.ToString(),
                Text = row.Id == -1 ? "Not Specified" : row.TripNo + ": " + (row.Title + " " + row.FirstName + " " + row.LastName).Trim()
            });
        }

        public static SelectListItem GetTripListByDebtorIdValue(HttpContext httpContext, AppMainContext context, IDistributedCache cache, int? id) {
            return id == null ? new SelectListItem { Value = string.Empty, Text = string.Empty } : GetTripListByDebtorId(httpContext, context, cache, -1, -1, false, id).FirstOrDefault() ?? new SelectListItem { Value = string.Empty, Text = string.Empty };
        }
        #endregion
    }
}