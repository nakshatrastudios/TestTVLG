﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Options;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Enums;
using Travelog.WebApp.Admin;
using Travelog.WebApp.Models;
using static Travelog.Biz.AppSettings;

namespace Travelog.WebApp {
    public static class AppUserSettings {
        public static AppSettingModel AppSettings(this HttpContext httpContext) {
            return Setting(httpContext?.CurrentCustomerId() ?? 0);
        }

        public static CustomerModel CustomerSettings(this HttpContext httpContext) {
            return Biz.CustomerSettings.Setting(httpContext?.CurrentCustomerId() ?? 0);
        }

        public static string UserId(this HttpContext httpContext) {
            return httpContext.User?.GetId() ?? string.Empty;
        }

        public static string UserFullName(this HttpContext httpContext, string value = null) {
            if (value == null)
                return httpContext.User?.GetFullName() ?? string.Empty;

            httpContext.User?.SetFullName(value);
            return string.Empty;
        }

        public static string AgencyEmail(this HttpContext httpContext, string value = null) {
            if (value == null) {
                string email = httpContext.User?.GetAgencyEmail();

                if (string.IsNullOrEmpty(email))
                    email = httpContext.User.Identity.Name;

                return email;
            }

            httpContext.User?.SetAgencyEmail(value);
            return string.Empty;
        }

        public static string Theme(this HttpContext httpContext, string value = null) {
            var options = new CookieOptions {
                Expires = DateTime.Today.AddDays(30)
            };

            if (value == null) {
                if (string.IsNullOrEmpty(httpContext.Request.Cookies["TravelogOnline.Theme"])) {
                    httpContext.Response.Cookies.Delete("TravelogOnline.Theme");
                    httpContext.Response.Cookies.Append("TravelogOnline.Theme", httpContext.User?.GetTheme() ?? "light", options);
                }

                return httpContext.Request.Cookies["TravelogOnline.Theme"];
            }

            httpContext.User?.SetTheme(value);

            httpContext.Response.Cookies.Delete("TravelogOnline.Theme");
            httpContext.Response.Cookies.Append("TravelogOnline.Theme", value, options);

            return string.Empty;
        }

        public static FormValidationMethod FormValidationMethod(this HttpContext httpContext, FormValidationMethod? value = null) {
            if (value == null)
                return httpContext.User?.GetFormValidationMethod() ?? Biz.Enums.FormValidationMethod.ValidateOnSubmit;

            httpContext.User?.SetFormValidationMethod(value ?? Biz.Enums.FormValidationMethod.ValidateOnSubmit);
            return Biz.Enums.FormValidationMethod.ValidateOnSubmit;
        }

        public static int CurrentCustomerId(this HttpContext httpContext, int? value = null) {
            if (value == null)
                return httpContext.User?.GetCurrentCustomerId() ?? 0;

            httpContext.User?.SetCurrentCustomerId(value ?? 0);
            return 0;
        }

        public static int CurrentConsultantId(this HttpContext httpContext, int? value = null) {
            if (value == null)
                return httpContext.User?.GetCurrentConsultantId() ?? -1;

            httpContext.User?.SetCurrentConsultantId(value ?? -1);
            return 0;
        }

        public static int CurrentDefaultAgencyId(this HttpContext httpContext, int? value = null) {
            if (value == null)
                return httpContext.User?.GetCurrentDefaultAgencyId() ?? -1;

            httpContext.User?.SetCurrentDefaultAgencyId(value ?? -1);
            AspNetUsersCommon.UpdateDefaultAgency(httpContext.User, httpContext.UserId(), httpContext.CurrentCustomerId(), value ?? -1);
            return 0;
        }

        public static int ChartOfAccountAgencyId(this HttpContext httpContext) {
            return Biz.CustomerSettings.Setting(httpContext.CurrentCustomerId()).AgencyType == AgencyType.ConsolidatedGL ? 0 : (httpContext.User?.GetCurrentDefaultAgencyId() ?? -1);
        }

        public static AppUserRole AppUserRole(this HttpContext httpContext, AppUserRole? value = null) {
            if (value == null)
                return httpContext.User?.GetAppUserRole() ?? Biz.Enums.AppUserRole.None;

            httpContext.User?.SetAppUserRole(value ?? Biz.Enums.AppUserRole.None);
            return Biz.Enums.AppUserRole.None;
        }

        public static int TravelBankAccountId(this HttpContext httpContext, int? value = null) {
            if (value == null)
                return httpContext.User?.GetTravelBankAccountId() ?? -1;

            httpContext.User?.SetTravelBankAccountId(value ?? -1);
            return 0;
        }

        public static int AdminBankAccountId(this HttpContext httpContext, int? value = null) {
            if (value == null)
                return httpContext.User?.GetAdminBankAccountId() ?? -1;

            httpContext.User?.SetAdminBankAccountId(value ?? -1);
            return 0;
        }

        public static int TimeZoneOffsetMinutes(this HttpContext httpContext, int? value = null) {
            if (value == null)
                return httpContext.User?.GetTimeZoneOffsetMinutes() ?? 0;

            httpContext.User?.SetTimeZoneOffsetMinutes(value ?? 0);
            return 0;
        }

        public static string SessionId(this HttpContext httpContext, string value = null) {
            if (value == null)
                return httpContext.User?.GetSessionId() ?? string.Empty;

            httpContext.User?.SetSessionId(value);
            return string.Empty;
        }

        public static DateTime LastSignInTime(this HttpContext httpContext, DateTime? value = null) {
            if (value == null)
                return httpContext.User?.GetLastSignInTime() ?? DateTime.MinValue;

            httpContext.User?.SetLastSignInTime(value ?? DateTime.MinValue);
            return DateTime.MinValue;
        }

        public static DateTime LastPasswordChangeDate(this HttpContext httpContext, DateTime? value = null) {
            if (value == null)
                return httpContext.User?.GetLastPasswordChangeDate() ?? DateTime.Today;

            httpContext.User?.SetLastPasswordChangeDate(value ?? DateTime.MinValue);
            return DateTime.MinValue;
        }

        public static bool OtherAgencies(this HttpContext httpContext, bool? value = null) {
            if (value == null)
                return httpContext.User?.GetOtherAgencies() ?? false;

            httpContext.User?.SetOtherAgencies(value ?? false);
            return false;
        }

        public static bool OtherConsultants(this HttpContext httpContext, bool? value = null) {
            if (value == null)
                return httpContext.User?.GetOtherConsultants() ?? false;

            httpContext.User?.SetOtherConsultants(value ?? false);
            return false;
        }

        public static bool IsExternalUser(this HttpContext httpContext, bool? value = null) {
            if (value == null)
                return httpContext.User?.GetIsExternalUser() ?? false;

            httpContext.User?.SetIsExternalUser(value ?? false);
            return false;
        }

        public static bool IsGlobalUser(this HttpContext httpContext, bool? value = null) {
            if (value == null)
                return httpContext.User?.GetIsGlobalUser() ?? false;

            httpContext.User?.SetIsGlobalUser(value ?? false);
            return false;
        }

        public static bool IsSupportUser(this HttpContext httpContext, bool? value = null) {
            if (value == null)
                return httpContext.User?.GetIsSupportUser() ?? false;

            httpContext.User?.SetIsSupportUser(value ?? false);
            return false;
        }

        public static bool IsSuperUser(this HttpContext httpContext, bool? value = null) {
            if (value == null)
                return (httpContext.User?.GetIsSuperUser() ?? false) && httpContext.IsGlobalUser();

            value = (value ?? false) && httpContext.IsGlobalUser();
            httpContext.User?.SetIsSuperUser(value ?? false);

            return false;
        }

        public static bool ForceSignOut(this HttpContext httpContext, bool? value = null) {
            if (value == null)
                return httpContext.User?.GetForceSignOut() ?? false;

            httpContext.User?.SetForceSignOut(value ?? false);
            return false;
        }

        public static bool Inactive(this HttpContext httpContext, bool? value = null) {
            if (value == null)
                return httpContext.User?.GetInactive() ?? false;

            httpContext.User?.SetInactive(value ?? false);
            return false;
        }

        public static string RoleId(this HttpContext httpContext) {
            return UserRole.GetUserRole(httpContext.AppUserRole()).Id;
        }

        public static string RoleName(this HttpContext httpContext) {
            return UserRole.GetUserRole(httpContext.AppUserRole()).Name;
        }

        public static string RequiredFieldBackgroundColor(this HttpContext httpContext) {
            return httpContext.Theme() == "dark" ? "#4a4a4a" : "#f2f2f2";
        }

        public static decimal PlaceholderOpacity(this HttpContext httpContext) {
            return httpContext.Theme() == "dark" ? .5m : .85m;
        }

        public static bool IsAdministrator(this HttpContext httpContext) {
            return httpContext.AppUserRole() == Biz.Enums.AppUserRole.SystemAdministrator || httpContext.AppUserRole() == Biz.Enums.AppUserRole.CompanyAdministrator;
        }

        public static bool IsAccounts(this HttpContext httpContext) {
            return httpContext.AppUserRole() == Biz.Enums.AppUserRole.Accounts;
        }

        public static int[] AgencyIds(this HttpContext httpContext, IDistributedCache cache) {
            return httpContext.AgencyList(cache).Result.Select(t => t.Id).ToArray();
        }

        public static int[] ConsultantIds(this HttpContext httpContext) {
            return new List<int> { -1, httpContext.CurrentConsultantId() }.ToArray();
        }

        public static DateTime Today(this HttpContext httpContext) {
            return httpContext.Now().Date;
        }

        public static DateTime Now(this HttpContext httpContext) {
            return DateTime.UtcNow.AddMinutes(httpContext.TimeZoneOffsetMinutes());
        }

        public static async Task<TimeFormat> TravelDocumentTimeFormat(this HttpContext httpContext, IDistributedCache cache) {
            return (await httpContext.AgencyList(cache)).SingleOrDefault(t => t.Id == httpContext.CurrentDefaultAgencyId())?.TravelDocumentTimeFormat ?? TimeFormat.Military;
        }

        public static async Task<PayIdType> PayIdType(this HttpContext httpContext, IDistributedCache cache) {
            return (await httpContext.AgencyList(cache)).SingleOrDefault(t => t.Id == httpContext.CurrentDefaultAgencyId())?.PayIdType ?? Biz.Enums.PayIdType.Phone;
        }

        public static async Task<string> PayId(this HttpContext httpContext, IDistributedCache cache) {
            return (await httpContext.AgencyList(cache)).SingleOrDefault(t => t.Id == httpContext.CurrentDefaultAgencyId())?.PayId ?? string.Empty;
        }

        public static async Task<string> TravelPayUrl(this HttpContext httpContext, IDistributedCache cache) {
            return (await httpContext.AgencyList(cache)).SingleOrDefault(t => t.Id == httpContext.CurrentDefaultAgencyId())?.TravelPayUrl ?? string.Empty;
        }

        public static async Task<string> MintUrl(this HttpContext httpContext, IDistributedCache cache) {
            return (await httpContext.AgencyList(cache)).SingleOrDefault(t => t.Id == httpContext.CurrentDefaultAgencyId())?.MintUrl ?? string.Empty;
        }

        public static async Task<string> CurrentDefaultAgencyName(this HttpContext httpContext, IDistributedCache cache) {
            return CurrentDefaultAgencyName(await httpContext.AgencyList(cache), httpContext.CurrentDefaultAgencyId());
        }

        public static string CurrentDefaultAgencyName(List<AgencyListModel> agencyList, int agencyId) {
            return agencyList.SingleOrDefault(t => t.Id == agencyId)?.Name ?? "No Agency";
        }

        public static async Task<int> HeadOfficeAgencyId(this HttpContext httpContext, IDistributedCache cache) {
            return HeadOfficeAgencyId(await httpContext.AgencyList(cache));
        }

        public static int HeadOfficeAgencyId(List<AgencyListModel> agencyList) {
            return agencyList.SingleOrDefault(t => t.IsHeadOffice)?.Id ?? 0;
        }

        public static async Task<int> AgencyCount(this HttpContext httpContext, IDistributedCache cache) {
            return AgencyCount(await httpContext.AgencyList(cache));
        }

        public static int AgencyCount(List<AgencyListModel> agencyList) {
            return agencyList.Count;
        }

        public static async Task<string> AccentColor(this HttpContext httpContext, IDistributedCache cache) {
            return AccentColor(await httpContext.AgencyList(cache), httpContext.CurrentDefaultAgencyId());
        }

        public static string AccentColor(List<AgencyListModel> agencyList, int agencyId) {
            return agencyList.SingleOrDefault(t => t.Id == agencyId)?.AccentColor ?? AppConstants.DefaultAccentColor;
        }

        public static async Task<string> HighlightColor(this HttpContext httpContext, IDistributedCache cache) {
            return HighlightColor(await httpContext.AgencyList(cache), httpContext.CurrentDefaultAgencyId());
        }

        public static string HighlightColor(List<AgencyListModel> agencyList, int agencyId) {
            return agencyList.SingleOrDefault(t => t.Id == agencyId)?.HighlightColor ?? AppConstants.DefaultHighlightColor;
        }

        public static async Task<bool> IsAccentColorPageHeaderFooterOnly(this HttpContext httpContext, IDistributedCache cache) {
            return IsAccentColorPageHeaderFooterOnly(await httpContext.AgencyList(cache), httpContext.CurrentDefaultAgencyId());
        }

        public static bool IsAccentColorPageHeaderFooterOnly(List<AgencyListModel> agencyList, int agencyId) {
            return agencyList.SingleOrDefault(t => t.Id == agencyId)?.IsAccentColorPageHeaderFooterOnly ?? true;
        }

        public static async Task<List<AgencyListModel>> AgencyList(this HttpContext httpContext, IDistributedCache cache) {
            if (string.IsNullOrEmpty(httpContext.User.Identity.Name))
                return new List<AgencyListModel> { new AgencyListModel { IsHeadOffice = true } };

            var agencyList = await cache.GetAsync<List<AgencyListModel>>(httpContext.User.Identity.Name, CacheKey.AgencyList);

            if (agencyList == null) {
                using (var context = new AppMainContext(httpContext.User, httpContext.CurrentCustomerId(), httpContext.IsExternalUser(), httpContext.IsSuperUser())) {
                    agencyList = await Lists.GetAgencyList(httpContext, context).ToListAsync();
                    await cache.SetAsync(httpContext.User.Identity.Name, CacheKey.AgencyList, agencyList);
                }
            }

            return agencyList;
        }

        public static UserStatus ValidateUserStatus(this HttpContext httpContext, int agencyCount) {
            var principal = httpContext.User;
            int customerId = httpContext.CurrentCustomerId();
            string sessionId = httpContext.Session.Id;

            AppUsersOnline.UpdateLastActivity(httpContext.UserId(), customerId, sessionId, principal.GetIsExternalUser(), principal.GetIsGlobalUser(), principal.GetIsSupportUser());

            if (principal?.Identity.IsAuthenticated != true || customerId == 0 || string.IsNullOrEmpty(sessionId))
                return UserStatus.Ok;

            if (!IsLocal) {
                switch (Biz.AppSettings.DbConnectionMode) {
                    case Biz.Enums.DbConnectionMode.Production:
                        if (customerId < (int)CustomerType.TravelogProd)
                            return UserStatus.CustomerNotAuthorised;

                        break;
                    case Biz.Enums.DbConnectionMode.Staging:
                        if (!(customerId <= (int)CustomerType.TravelogStaging && customerId >= (int)CustomerType.TravelogStagingTest9))
                            return UserStatus.CustomerNotAuthorised;

                        break;
                    case Biz.Enums.DbConnectionMode.Development:
                        if (!(customerId <= (int)CustomerType.TravelogDev && customerId >= (int)CustomerType.TravelogDevTest9))
                            return UserStatus.CustomerNotAuthorised;

                        break;
                }
            }

            if (DateTime.UtcNow.AddDays(-PasswordExpirationDays) >= httpContext.LastPasswordChangeDate())
                return UserStatus.PasswordChangeReqd;

            if (AppUsersOnline.IsUserOnlineAnotherSession(httpContext.UserId(), sessionId))
                return UserStatus.MultipleSignIns;

            if (principal.GetForceSignOut() || AppUsersOnline.IsUserForcedSignOut(httpContext.UserId()))
                return UserStatus.ForceSignOut;

            if (principal.GetCurrentDefaultAgencyId() <= 0 && !httpContext.IsExternalUser() && agencyCount > 0)
                return UserStatus.NoAgencySelected;

            return UserStatus.Ok;
        }

        public static async Task SignOutAsync(this HttpContext httpContext, IDistributedCache cache) {
            await cache.RemoveUserAsync(httpContext.User.Identity.Name);
            await httpContext.ClearSessionAsync();
            AppUsersOnline.RemoveUser(httpContext.UserId());
        }
    }

    public class AppUserClaimsPrincipalFactory : UserClaimsPrincipalFactory<ApplicationUser> {
        public AppUserClaimsPrincipalFactory(UserManager<ApplicationUser> userManager, IOptions<IdentityOptions> optionsAccessor) : base(userManager, optionsAccessor) {
        }

        protected override async Task<ClaimsIdentity> GenerateClaimsAsync(ApplicationUser appUser) {
            UpdateUser(appUser);
            var ci = await base.GenerateClaimsAsync(appUser);
            return AddClaims(appUser, ci);
        }

        public static void UpdateUser(ApplicationUser appUser, ClaimsPrincipal principal = null) {
            using (var adminContext = new AppAdminContext(false)) {
                var aspNetUser = adminContext.AspNetUsers.Include(t => t.CurrentCustomer).ThenInclude(t => t.CustomerTransactions).Include(t => t.AspNetUserRoles).ThenInclude(t => t.AspNetRoles).Single(t => t.Id == appUser.Id);
                var aspNetUserRole = aspNetUser.GetRole();

                int currentCustomerId = CustomerSettings.GetValidatedCustomerId(aspNetUser.CurrentCustomerId);

                appUser.AppUserRoleId = (int)(aspNetUser.IsInRole(adminContext, UserRole.SystemAdministrator.Id, currentCustomerId) ? AppUserRole.SystemAdministrator
                    : aspNetUser.IsInRole(adminContext, UserRole.CompanyAdministrator.Id, currentCustomerId) ? AppUserRole.CompanyAdministrator
                    : aspNetUser.IsInRole(adminContext, UserRole.Accounts.Id, currentCustomerId) ? AppUserRole.Accounts
                    : aspNetUser.IsInRole(adminContext, UserRole.UserTeamLeader.Id, currentCustomerId) ? AppUserRole.UserTeamLeader
                    : aspNetUser.IsInRole(adminContext, UserRole.UserSenior.Id, currentCustomerId) ? AppUserRole.UserSenior
                    : aspNetUser.IsInRole(adminContext, UserRole.User.Id, currentCustomerId) ? AppUserRole.User
                    : AppUserRole.None);

                appUser.CurrentCustomerId = currentCustomerId;
                appUser.Theme = aspNetUser.Theme;
                appUser.FormValidationMethodId = (int)aspNetUser.FormValidationMethod;
                appUser.IsExternalUser = aspNetUser.IsExternalUser && currentCustomerId != (int)CustomerType.TravelogProd && currentCustomerId != (int)CustomerType.TravelogStaging && currentCustomerId != (int)CustomerType.TravelogDev;
                appUser.IsGlobalUser = aspNetUser.AspNetUserRoles.Any(t => t.CustomerId == (int)CustomerType.TravelogProd || t.CustomerId == (int)CustomerType.TravelogStaging || t.CustomerId == (int)CustomerType.TravelogDev);
                appUser.IsSuperUser = aspNetUser.IsSuperUser && appUser.IsGlobalUser;

                if (appUser.IsExternalUser) {
                    appUser.AppUserRoleId = (int)AppUserRole.SystemAdministrator;

                    if (appUser.CurrentCustomerId == (int)CustomerType.TravelogDev || appUser.CurrentCustomerId == (int)CustomerType.TravelogStaging || appUser.CurrentCustomerId == (int)CustomerType.TravelogProd)
                        appUser.IsExternalUser = false;
                }
                else {
                    appUser.AppUserRoleId = (int)UserRole.GetAppUserRole(aspNetUserRole.RoleId);

                    if (aspNetUserRole.Inactive || appUser.AppUserRoleId == (int)AppUserRole.None) {
                        aspNetUserRole = aspNetUser.AspNetUserRoles.FirstOrDefault(t => !t.Inactive);

                        if (aspNetUserRole != null) {
                            appUser.CurrentCustomerId = aspNetUserRole.CustomerId;
                            appUser.AppUserRoleId = (int)UserRole.GetAppUserRole(aspNetUserRole.RoleId);
                        }
                    }
                }

                appUser.CurrentConsultantId = aspNetUserRole.ConsultantId;
                appUser.CurrentDefaultAgencyId = aspNetUserRole.DefaultAgencyId;

                if (aspNetUser.AppUserRole != (AppUserRole)appUser.AppUserRoleId || aspNetUser.CurrentCustomerId != appUser.CurrentCustomerId || aspNetUser.CurrentConsultantId != appUser.CurrentConsultantId || aspNetUser.CurrentDefaultAgencyId != appUser.CurrentDefaultAgencyId || aspNetUser.IsExternalUser != appUser.IsExternalUser || aspNetUser.IsGlobalUser != appUser.IsGlobalUser || aspNetUser.IsSuperUser != appUser.IsSuperUser) {
                    aspNetUser.AppUserRole = (AppUserRole)appUser.AppUserRoleId;
                    aspNetUser.CurrentCustomerId = appUser.CurrentCustomerId;
                    aspNetUser.CurrentConsultantId = appUser.CurrentConsultantId;
                    aspNetUser.CurrentDefaultAgencyId = appUser.CurrentDefaultAgencyId;
                    aspNetUser.IsExternalUser = appUser.IsExternalUser;
                    aspNetUser.IsGlobalUser = appUser.IsGlobalUser;
                    aspNetUser.IsSuperUser = appUser.IsSuperUser;
                    adminContext.Save(aspNetUser, false);
                    aspNetUser = adminContext.AspNetUsers.Include(t => t.CurrentCustomer).ThenInclude(t => t.CustomerTransactions).Include(t => t.AspNetUserRoles).ThenInclude(t => t.AspNetRoles).Single(t => t.Id == appUser.Id);
                }

                using (var context = new AppMainContext(aspNetUser.CurrentCustomer.Id, true)) {
                    var agency = context.Agency.Find(appUser.CurrentDefaultAgencyId) ?? context.Agency.Single(t => t.IsHeadOffice);

                    appUser.CurrentDefaultAgencyId = agency.Id;
                    aspNetUser.CurrentDefaultAgencyId = appUser.CurrentDefaultAgencyId;

                    appUser.TravelBankAccountId = agency.TravelBankAccountId;
                    appUser.AdminBankAccountId = agency.AdminBankAccountId;

                    aspNetUser.TravelBankAccountId = appUser.TravelBankAccountId;
                    aspNetUser.AdminBankAccountId = appUser.AdminBankAccountId;

                    appUser.AgencyEmail = context.AgencyUserEmail.SingleOrDefault(t => t.AgencyId == agency.Id && t.UserId == aspNetUser.Id)?.Email ?? string.Empty;
                    aspNetUser.AgencyEmail = appUser.AgencyEmail;

                    adminContext.Save(aspNetUser, false);
                }

                AppUsersOnline.RemoveUser(appUser.Id);
                CustomerCommon.InitSettings(adminContext, appUser.CurrentCustomerId);
            }

            if (principal == null) {
                AddClaims(appUser, new ClaimsIdentity());
            }
            else {
                UpdateClaims(appUser, principal);
            }
        }

        private static ClaimsIdentity AddClaims(ApplicationUser appUser, ClaimsIdentity ci) {
            ci.AddClaims(new Claim[] {
                new Claim("Id", appUser.Id),
                new Claim("FullName", appUser.FullName),
                new Claim("AgencyEmail", appUser.AgencyEmail),
                new Claim("Theme", appUser.Theme),
                new Claim("FormValidationMethodId", appUser.FormValidationMethodId.ToString()),
                new Claim("AppUserRoleId", appUser.AppUserRoleId.ToString()),
                new Claim("CurrentCustomerId", appUser.CurrentCustomerId.ToString()),
                new Claim("CurrentConsultantId", appUser.CurrentConsultantId.ToString()),
                new Claim("CurrentDefaultAgencyId", appUser.CurrentDefaultAgencyId.ToString()),
                new Claim("TravelBankAccountId", appUser.TravelBankAccountId.ToString()),
                new Claim("AdminBankAccountId", appUser.AdminBankAccountId.ToString()),
                new Claim("TimeZoneOffsetMinutes", appUser.TimeZoneOffsetMinutes.ToString()),
                new Claim("SessionId", appUser.SessionId),
                new Claim("GoogleAccountSecretKey", appUser.GoogleAccountSecretKey),
                new Claim("LastSignInTime", appUser.LastSignInTime.ToString()),
                new Claim("LastPasswordChangeDate", appUser.LastPasswordChangeDate.ToString()),
                new Claim("IsTwoFactorEnabled", appUser.IsTwoFactorEnabled.ToString()),
                new Claim("OtherAgencies", appUser.OtherAgencies.ToString()),
                new Claim("OtherConsultants", appUser.OtherConsultants.ToString()),
                new Claim("IsExternalUser", appUser.IsExternalUser.ToString()),
                new Claim("IsGlobalUser", appUser.IsGlobalUser.ToString()),
                new Claim("IsSupportUser", appUser.IsSupportUser.ToString()),
                new Claim("IsSuperUser", appUser.IsSuperUser.ToString()),
                new Claim("ForceSignOut", appUser.ForceSignOut.ToString()),
                new Claim("Inactive", appUser.Inactive.ToString())
            });

            return ci;
        }

        private static void UpdateClaims(ApplicationUser appUser, ClaimsPrincipal principal) {
            principal.SetFullName(appUser.FullName);
            principal.SetAgencyEmail(appUser.AgencyEmail);
            principal.SetTheme(appUser.Theme);
            principal.SetFormValidationMethod((FormValidationMethod)appUser.FormValidationMethodId);
            principal.SetAppUserRole((AppUserRole)appUser.AppUserRoleId);

            principal.SetCurrentCustomerId(appUser.CurrentCustomerId);
            principal.SetCurrentConsultantId(appUser.CurrentConsultantId);
            principal.SetCurrentDefaultAgencyId(appUser.CurrentDefaultAgencyId);
            principal.SetTravelBankAccountId(appUser.TravelBankAccountId);
            principal.SetAdminBankAccountId(appUser.AdminBankAccountId);

            principal.SetLastPasswordChangeDate(appUser.LastPasswordChangeDate);
            principal.SetIsTwoFactorEnabled(appUser.IsTwoFactorEnabled);

            principal.SetOtherAgencies(appUser.OtherAgencies);
            principal.SetOtherConsultants(appUser.OtherConsultants);
            principal.SetIsExternalUser(appUser.IsExternalUser);
            principal.SetIsGlobalUser(appUser.IsGlobalUser);
            principal.SetIsSupportUser(appUser.IsSupportUser);
            principal.SetIsSuperUser(appUser.IsSuperUser);
            principal.SetInactive(appUser.Inactive);
        }
    }

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser> {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) {
        }
    }

    public class ApplicationUser : IdentityUser {
        public string FullName { get; set; }
        public string AgencyEmail { get; set; }
        public string Theme { get; set; }
        public int FormValidationMethodId { get; set; }
        public int CurrentCustomerId { get; set; }
        public int CurrentConsultantId { get; set; }
        public int CurrentDefaultAgencyId { get; set; }
        public int AppUserRoleId { get; set; }
        public int TravelBankAccountId { get; set; }
        public int AdminBankAccountId { get; set; }
        public int TimeZoneOffsetMinutes { get; set; }
        public string SessionId { get; set; }
        public string GoogleAccountSecretKey { get; set; }
        public DateTime LastSignInTime { get; set; }
        public DateTime LastPasswordChangeDate { get; set; }
        public bool IsTwoFactorEnabled { get; set; }
        public bool OtherAgencies { get; set; }
        public bool OtherConsultants { get; set; }
        public bool IsExternalUser { get; set; }
        public bool IsGlobalUser { get; set; }
        public bool IsSupportUser { get; set; }
        public bool IsSuperUser { get; set; }
        public bool ForceSignOut { get; set; }
        public bool Inactive { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }
    }
}