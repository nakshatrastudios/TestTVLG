﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace Travelog.WebApp {
    public static class RobotsTxtExtensions {
        public static IApplicationBuilder UseRobotsTxt(this IApplicationBuilder builder) {
            return builder.MapWhen(httpContext => httpContext.Request.Path.StartsWithSegments("/robots.txt"), t => t.UseMiddleware<RobotsTxt>());
        }
    }

    public class RobotsTxt {
        private readonly RequestDelegate Next;

        public RobotsTxt(RequestDelegate next) {
            Next = next;
        }

        public async Task InvokeAsync(HttpContext context) {
            if (context.Request.Path.StartsWithSegments("/robots.txt")) {
                string output = string.Format("User-Agent: *{0}Disallow: /", Environment.NewLine);
                context.Response.ContentType = "text/plain";
                await context.Response.WriteAsync(output);
            }
            else {
                await Next(context);
            }
        }
    }
}