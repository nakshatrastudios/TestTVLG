﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Binders;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Travelog.Biz;

namespace Travelog.WebApp {
    public class ModelBinderProvider : IModelBinderProvider {
        public IModelBinder GetBinder(ModelBinderProviderContext context) {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            if (!context.Metadata.IsComplexType) {
                var loggerFactory = context.Services.GetRequiredService<ILoggerFactory>();

                if (context.Metadata.ModelType == typeof(string)) {
                    return new TrimStringModelBinder(new SimpleTypeModelBinder(context.Metadata.ModelType, loggerFactory));
                }
                else if (context.Metadata.ModelType == typeof(DateTime) || context.Metadata.ModelType == typeof(DateTime?)) {
                    return new DateTimeModelBinder(new SimpleTypeModelBinder(context.Metadata.ModelType, loggerFactory));
                }
            }

            return null;
        }
    }

    public class TrimStringModelBinder : IModelBinder {
        private readonly IModelBinder FallbackBinder;

        public TrimStringModelBinder(IModelBinder fallbackBinder) {
            FallbackBinder = fallbackBinder ?? throw new ArgumentNullException(nameof(fallbackBinder));
        }

        public Task BindModelAsync(ModelBindingContext bindingContext) {
            ArgumentNullException.ThrowIfNull(bindingContext);

            var result = bindingContext.ValueProvider.GetValue(bindingContext.ModelName);

            if (result.FirstValue is string value && !string.IsNullOrEmpty(value)) {
                bindingContext.Result = ModelBindingResult.Success(value.Trim());
                return Task.CompletedTask;
            }

            return FallbackBinder.BindModelAsync(bindingContext);
        }
    }

    public class DateTimeModelBinder : IModelBinder {
        private readonly IModelBinder FallbackBinder;

        public DateTimeModelBinder(IModelBinder fallbackBinder = null) {
            FallbackBinder = fallbackBinder;
        }

        public Task BindModelAsync(ModelBindingContext bindingContext) {
            ArgumentNullException.ThrowIfNull(bindingContext);

            var result = bindingContext.ValueProvider.GetValue(bindingContext.ModelName);

            if (result != ValueProviderResult.None && result.FirstValue != null) {
                bindingContext.ModelState.SetModelValue(bindingContext.ModelName, result);

                try {
                    DateTime dateTime = DateTime.Parse(result.FirstValue);
                    bindingContext.Result = ModelBindingResult.Success(dateTime);
                    return Task.CompletedTask;
                }
                catch {
                    if (result.FirstValue.Contains("GMT", StringComparison.OrdinalIgnoreCase)) {
                        string value = result.FirstValue.Left(result.FirstValue.IndexOf("GMT", StringComparison.OrdinalIgnoreCase));
                        DateTime.TryParse(value, out DateTime dateTime);

                        if (dateTime > DateTime.MinValue) {
                            bindingContext.Result = ModelBindingResult.Success(dateTime);
                            return Task.CompletedTask;
                        }
                    }
                }
            }

            if (FallbackBinder == null)
                return Task.CompletedTask;

            return FallbackBinder.BindModelAsync(bindingContext);
        }
    }
}