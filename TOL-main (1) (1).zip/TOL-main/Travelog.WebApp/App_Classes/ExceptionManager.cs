﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Net.Http.Headers;
using Travelog.Biz;

namespace Travelog.WebApp {
    public static class ExceptionManager {
        public static string HandleException(HttpContext httpContext, string className, string method, Exception ex) {
            return HandleExceptionAsync(httpContext, className, method, ex).Result;
        }

        public static async Task<string> HandleExceptionAsync(HttpContext httpContext, string className, string method, Exception ex, string url = null, string source = null, string stack = null) {
            if (ex is UnreportedException || ex is EwayException)
                return ex.Message;

            if (string.IsNullOrEmpty(url))
                url = httpContext.Request.Path.Value;

            return await ExceptionManagerBiz.Instance.HandleExceptionAsync(
                className: className,
                method: method,
                ex: ex,
                customerId: httpContext.CurrentCustomerId(),
                userName: httpContext.User.Identity.Name,
                url: url,
                ipAddress: httpContext.Connection.RemoteIpAddress,
                userAgent: httpContext.Request.Headers[HeaderNames.UserAgent],
                source: source,
                stack: stack
            );
        }
    }
}