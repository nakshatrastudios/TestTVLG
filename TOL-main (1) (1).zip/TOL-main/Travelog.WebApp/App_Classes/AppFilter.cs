﻿using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Travelog.Biz;
using Travelog.Biz.Resources;
using Travelog.WebApp.Controllers;

namespace Travelog.WebApp {
    public class AppFilter : IActionFilter {
        public async void OnActionExecuting(ActionExecutingContext context) {
            string cultureName = AppSettings.Setting(context.HttpContext.CurrentCustomerId()).CultureName;
            var ci = new CultureInfo(cultureName);

            Resource.Culture = ci;

            ci.DateTimeFormat.LongDatePattern = Resource.LongDatePattern;
            ci.DateTimeFormat.LongTimePattern = Resource.LongTimePattern;
            ci.DateTimeFormat.ShortDatePattern = Resource.ShortDatePattern;
            ci.DateTimeFormat.ShortTimePattern = Resource.ShortTimePattern;
            ci.DateTimeFormat.DateSeparator = Resource.DateSeparator;
            ci.DateTimeFormat.TimeSeparator = Resource.TimeSeparator;

            if (cultureName == "en-AU") {
                ci.DateTimeFormat.AbbreviatedMonthNames = new string[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", string.Empty };
                ci.DateTimeFormat.AbbreviatedMonthGenitiveNames = ci.DateTimeFormat.AbbreviatedMonthNames;
            }

            CultureInfo.DefaultThreadCurrentCulture = ci;
            CultureInfo.DefaultThreadCurrentUICulture = ci;

            if (context.Controller is not BaseController controller)
                return;

            var menuList = context.HttpContext.MenuList(controller.Cache).Result;
            var agencyList = context.HttpContext.AgencyList(controller.Cache).Result;

            int agencyId = context.HttpContext.CurrentDefaultAgencyId();
            int agencyCount = AppUserSettings.AgencyCount(agencyList);

            controller.ViewBag.MenuList = menuList;
            controller.ViewBag.AgencyList = agencyList;

            controller.ViewBag.AgencyName = AppUserSettings.CurrentDefaultAgencyName(agencyList, agencyId).ToUpper();
            controller.ViewBag.AgencyCount = AppUserSettings.AgencyCount(agencyList);
            controller.ViewBag.AccentColor = AppUserSettings.AccentColor(agencyList, agencyId);
            controller.ViewBag.HighlightColor = AppUserSettings.HighlightColor(agencyList, agencyId);
            controller.ViewBag.IsAccentColorPageHeaderFooterOnly = AppUserSettings.IsAccentColorPageHeaderFooterOnly(agencyList, agencyId);

            await new HttpValidation(menuList).InvokeAsync(context.HttpContext, agencyCount);

            if (context.HttpContext.Response.StatusCode == 998)
                context.Result = new UnauthorizedObjectResult("The content of this page is read-only and cannot be altered.");
        }

        public void OnActionExecuted(ActionExecutedContext context) {
        }
    }
}