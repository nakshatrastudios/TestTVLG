﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Admin;
using Travelog.Biz.Enums;
using Travelog.WebApp.Models;

namespace Travelog.WebApp {
    public static class AppMenu {
        public static async Task<List<MenuViewModel>> MenuList(this HttpContext httpContext, IDistributedCache cache) {
            if (string.IsNullOrEmpty(httpContext.User.Identity.Name))
                return new List<MenuViewModel>();

            var menuList = await cache.GetAsync<List<MenuViewModel>>(httpContext.User.Identity.Name, CacheKey.MenuList);

            if (menuList == null) {
                using (var adminContext = new AppAdminContext(httpContext.User)) {
                    menuList = GetMenuList(adminContext, httpContext.CurrentCustomerId(), httpContext.RoleId());
                    await cache.SetAsync(httpContext.User.Identity.Name, CacheKey.MenuList, menuList);
                }
            }

            return menuList;
        }

        private static List<MenuViewModel> GetMenuList(AppAdminContext adminContext, int customerId, string roleId) {
            var menuList = new List<MenuViewModel>();
            bool useDefaults = !adminContext.MenuBaseRole.Any(t => t.CustomerId == customerId);

            Configure(adminContext, menuList, 0, customerId, roleId, useDefaults);
            Configure(menuList);

            foreach (var row in menuList.Where(t => t.ParentId == 0).ToList()) {
                if (!menuList.Any(t => t.ParentId == row.MenuBaseId && t.IsVisible) && adminContext.MenuBase.Any(t => t.ParentId == row.MenuBaseId))
                    menuList.Remove(row);
            }

            return menuList;
        }

        private static void Configure(AppAdminContext adminContext, IList<MenuViewModel> menuList, int parentId, int customerId, string roleId, bool useDefaults) {
            foreach (var row in adminContext.MenuBase.Include(t => t.MenuBaseRoleDefaults).Include(t => t.MenuBaseRoles).ThenInclude(t => t.Customer).Where(t => t.ParentId == parentId)) {
                AccessLevel accessLevel;

                if (useDefaults) {
                    accessLevel = row.MenuBaseRoleDefaults.SingleOrDefault(t => t.RoleId == roleId)?.DefaultAccessLevel ?? AccessLevel.ReadWrite;
                }
                else {
                    var q = row.MenuBaseRoles.Where(t => t.CustomerId == customerId).OrderBy(t => t.Id).ToList();
                    accessLevel = q.Count == 0 ? AccessLevel.ReadWrite : q.SingleOrDefault(t => t.RoleId == roleId)?.AccessLevel ?? AccessLevel.ReadWrite;
                }

                bool isVisible = accessLevel != AccessLevel.NotAuthorised && row.IsVisible;

                menuList.Add(new MenuViewModel {
                    MenuBaseId = row.Id,
                    ParentId = row.ParentId,
                    Item = string.Format("{0}{1}", row.Item, accessLevel == AccessLevel.ReadOnly ? " [Read-Only]" : string.Empty),
                    NavigateUrl = row.NavigateUrl,
                    MenuPageType = row.MenuPageType,
                    ValidateItem = row.ValidateItem,
                    ExcludeFromHistory = row.ExcludeFromHistory,
                    IsExpanded = row.IsExpanded,
                    IsNewWindow = row.IsNewWindow,
                    IsVisible = isVisible,
                    AccessLevel = accessLevel
                });

                Configure(adminContext, menuList, row.Id, customerId, roleId, useDefaults);
            }
        }

        private static void Configure(IList<MenuViewModel> menuList) {
            foreach (var row in menuList.Where(t => string.IsNullOrEmpty(t.NavigateUrl) && t.IsVisible)) {
                if (!menuList.Any(t => t.ParentId == row.MenuBaseId && t.IsVisible))
                    row.IsVisible = false;
            }
        }

        public static async Task<bool> IsAuthorised(this HttpContext httpContext, IDistributedCache cache, MenuPageType menuPageType) {
            return (await httpContext.MenuList(cache)).Find(t => t.MenuPageType == menuPageType).AccessLevel == AccessLevel.ReadWrite;
        }

        public static async Task UpdateNavigateUrl(this HttpContext httpContext, IDistributedCache cache, string item, string navigateUrl) {
            var menuList = await httpContext.MenuList(cache);

            if (menuList.Any(t => t.Item.TrimEnd(" [Read-Only]") == item))
                menuList.Find(t => t.Item.TrimEnd(" [Read-Only]") == item).NavigateUrl = navigateUrl;
        }

        public static bool UpdateMenuBaseRole(this HttpContext httpContext, AppAdminContext adminContext, MenuRoleViewModel model) {
            using (var ts = Utils.CreateTransactionScope()) {
                var q1 = adminContext.MenuBaseRole.Include(t => t.MenuBase).Single(t => t.Id == model.MenuBaseRoleId);
                var q2 = adminContext.MenuBaseRoleDefault.Single(t => t.MenuBaseId == q1.MenuBaseId && t.RoleId == q1.RoleId);

                if (q1.RoleId == UserRole.SystemAdministrator.Id)
                    return false;

                if (q1.MenuBase.Item == "User Roles" || q1.MenuBase.NavigateUrl.Contains("UserRoles") || q1.RoleId == UserRole.SystemAdministrator.Id)
                    throw new UnreportedException("This role cannot be altered.");

                if ((q1.MenuBase.Item == "User Accounts" || q1.MenuBase.NavigateUrl.Contains("UserAccounts")) && (model.AccessLevel == AccessLevel.ReadWrite || model.DefaultAccessLevel == AccessLevel.ReadWrite))
                    throw new UnreportedException("This role is not permitted to have read/write access.");

                if (q1.RoleId == UserRole.CompanyAdministrator.Id && (q1.AccessLevel != model.AccessLevel || q2.DefaultAccessLevel != model.DefaultAccessLevel)) {
                    foreach (var row in adminContext.MenuBaseRole.Where(t => t.MenuBaseId == q1.MenuBaseId && t.RoleId == UserRole.CompanyAdministrator.Id).ToList()) {
                        if (row.AccessLevel != model.DefaultAccessLevel) {
                            row.AccessLevel = model.DefaultAccessLevel;
                            adminContext.Save(row);
                        }
                    }

                    if (q2.DefaultAccessLevel != model.DefaultAccessLevel) {
                        q2.DefaultAccessLevel = model.DefaultAccessLevel;
                        adminContext.Save(q2);
                    }
                }
                else {
                    if ((httpContext.AppUserRole() == AppUserRole.SystemAdministrator || httpContext.AppUserRole() == AppUserRole.CompanyAdministrator) && q1.AccessLevel != model.AccessLevel) {
                        q1.AccessLevel = model.AccessLevel;
                        adminContext.Save(q1);
                    }

                    if (httpContext.AppUserRole() == AppUserRole.SystemAdministrator && q2.DefaultAccessLevel != model.DefaultAccessLevel) {
                        q2.DefaultAccessLevel = model.DefaultAccessLevel;
                        adminContext.Save(q2);
                    }
                }

                ts.Complete();
                return true;
            }
        }

        public static bool ResetMenuAccessLevels(this HttpContext httpContext, AppAdminContext adminContext, string roleId) {
            if (httpContext.AppUserRole() != AppUserRole.SystemAdministrator && httpContext.AppUserRole() != AppUserRole.CompanyAdministrator)
                throw new UnreportedException("You are not authorised to peform this function.");

            using (var ts = Utils.CreateTransactionScope()) {
                int customerId = httpContext.CurrentCustomerId();

                if (!adminContext.MenuBaseRole.Any(t => t.CustomerId == customerId)) {
                    adminContext.AddRange(adminContext.MenuBaseRoleDefault.Select(row => new MenuBaseRole {
                        MenuBaseId = row.MenuBaseId,
                        CustomerId = customerId,
                        RoleId = row.RoleId,
                        AccessLevel = row.DefaultAccessLevel
                    }));

                    adminContext.SaveChanges();
                }
                else {
                    foreach (var row in adminContext.MenuBaseRole.Where(t => t.CustomerId == customerId && t.RoleId == roleId).ToList()) {
                        var q = adminContext.MenuBaseRoleDefault.Single(t => t.MenuBaseId == row.MenuBaseId && t.RoleId == row.RoleId);

                        if (row.AccessLevel != q.DefaultAccessLevel) {
                            row.AccessLevel = q.DefaultAccessLevel;
                            adminContext.Save(row);
                        }
                    }
                }

                ts.Complete();
                return true;
            }
        }
    }
}