﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Enums;

namespace Travelog.WebApp {
    public static class ExchangeRate {
        public static bool UpdateExchangeRates() {
            var currencyList = new List<CurrencyModel>();
            var httpClient = new HttpClient();

            using (var adminContext = new AppAdminContext(true)) {
                foreach (var customer in adminContext.Customer.OrderByDescending(t => t.Id).ToList()) {
                    using (var context = new AppMainContext(customer.Id, true)) {
                        string currencyCode = context.AppSetting.Find("CurrencyCode").Value;

                        if (!currencyList.Any(t => t.CountryCode == customer.CountryCode))
                            GetExchangeRates(httpClient, currencyList, customer.CountryCode, currencyCode);
                    }
                }

                foreach (var customer in adminContext.Customer.OrderByDescending(t => t.Id).ToList()) {
                    using (var context = new AppMainContext(customer.Id, false)) {
                        UpdateExchangeRates(context, currencyList.Where(t => t.CountryCode == customer.CountryCode).ToList());
                    }
                }
            }

            return true;
        }

        private static void GetExchangeRates(HttpClient httpClient, List<CurrencyModel> currencyList, string countryCode, string baseCurrencyCode) {
            string endpoint = string.Format("https://v6.exchangerate-api.com/v6/867a45b454ba5b498fa3f26e/latest/{0}", baseCurrencyCode);

            string json = httpClient.GetStringAsync(endpoint).Result;
            var model = JsonSerializer.Deserialize<ExchangeRateModel>(json, JsonExtensionsBiz.JsonSerializerOptions());

            foreach (var pi in model.conversion_rates.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)) {
                currencyList.Add(new CurrencyModel {
                    CountryCode = countryCode,
                    CurrencyCode = pi.Name,
                    ExchangeRate = (decimal)pi.GetValue(model.conversion_rates)
                });
            }
        }

        private static bool UpdateExchangeRates(AppMainContext context, List<CurrencyModel> currencyList) {
            string[] currencyCodes = currencyList.Select(t => t.CurrencyCode).ToArray();

            foreach (var row in context.Currency.Where(t => !currencyCodes.Contains(t.Code)).ToList()) {
                try {
                    context.Database.ExecuteSqlRaw(string.Format("delete Common.Currency where Id={0}", row.Id));
                }
                catch {
                }
            }

            DateTime date = DateTime.UtcNow;

            foreach (var row in Currency.CurrencyList.Where(t1 => currencyList.Any(t2 => t2.CurrencyCode == t1.Key) && !context.Currency.Any(t2 => t2.Code == t1.Key || t2.Name == t1.Value)).ToList()) {
                context.Insert(new Currency {
                    Id = 0,
                    Code = row.Key,
                    Name = row.Value,
                    Rate = 0,
                    OfficialRate = 0,
                    ExchangeRateType = ExchangeRateType.Fixed,
                    LastWriteTime = date,
                    CreationTime = date,
                    LastWriteUser = AppSettings.SystemAccountEmail,
                    CreationUser = AppSettings.SystemAccountEmail
                }, false);
            }

            decimal margin = decimal.Parse(context.AppSetting.Find("ExchangeRateMargin").Value) / 100;

            foreach (var row in context.Currency.Where(t => currencyCodes.Contains(t.Code)).ToList()) {
                decimal officialRate = currencyList.Single(t => t.CurrencyCode == row.Code).ExchangeRate;
                bool update = false;

                if (row.ExchangeRateType == ExchangeRateType.Relative && margin != 0 && row.Rate != 0 && row.OfficialRate != 0) {
                    row.Rate = officialRate * row.Rate / row.OfficialRate;

                    if (row.Rate * (1 + margin) > officialRate) {
                        row.Rate = officialRate * (1 + margin);
                        update = true;
                    }
                    else if (row.Rate * (1 - margin) < officialRate) {
                        row.Rate = officialRate * (1 - margin);
                        update = true;
                    }
                }

                if (row.OfficialRate != officialRate) {
                    row.OfficialRate = officialRate;
                    update = true;
                }

                if (update)
                    context.Save(row, false);
            }

            return true;
        }

        private class CurrencyModel {
            public string CountryCode { get; set; }
            public string CurrencyCode { get; set; }
            public decimal ExchangeRate { get; set; }
        }

        private class ExchangeRateModel {
            public string result { get; set; }
            public string documentation { get; set; }
            public string terms_of_use { get; set; }
            public string time_zone { get; set; }
            public string time_last_update { get; set; }
            public string time_next_update { get; set; }
            public ConversionRate conversion_rates { get; set; }
        }

        private class ConversionRate {
            public decimal AED { get; set; }
            public decimal ARS { get; set; }
            public decimal AUD { get; set; }
            public decimal BGN { get; set; }
            public decimal BRL { get; set; }
            public decimal BSD { get; set; }
            public decimal CAD { get; set; }
            public decimal CHF { get; set; }
            public decimal CLP { get; set; }
            public decimal CNY { get; set; }
            public decimal COP { get; set; }
            public decimal CZK { get; set; }
            public decimal DKK { get; set; }
            public decimal DOP { get; set; }
            public decimal EGP { get; set; }
            public decimal EUR { get; set; }
            public decimal FJD { get; set; }
            public decimal GBP { get; set; }
            public decimal GTQ { get; set; }
            public decimal HKD { get; set; }
            public decimal HRK { get; set; }
            public decimal HUF { get; set; }
            public decimal IDR { get; set; }
            public decimal ILS { get; set; }
            public decimal INR { get; set; }
            public decimal ISK { get; set; }
            public decimal JPY { get; set; }
            public decimal KRW { get; set; }
            public decimal KZT { get; set; }
            public decimal MXN { get; set; }
            public decimal MYR { get; set; }
            public decimal NOK { get; set; }
            public decimal NZD { get; set; }
            public decimal PAB { get; set; }
            public decimal PEN { get; set; }
            public decimal PHP { get; set; }
            public decimal PKR { get; set; }
            public decimal PLN { get; set; }
            public decimal PYG { get; set; }
            public decimal RON { get; set; }
            public decimal RUB { get; set; }
            public decimal SAR { get; set; }
            public decimal SBD { get; set; }
            public decimal SEK { get; set; }
            public decimal SGD { get; set; }
            public decimal THB { get; set; }
            public decimal TRY { get; set; }
            public decimal TWD { get; set; }
            public decimal UAH { get; set; }
            public decimal USD { get; set; }
            public decimal UYU { get; set; }
            public decimal ZAR { get; set; }
        }
    }
}