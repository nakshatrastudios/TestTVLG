﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Dao.StaticMethods;
using Travelog.Biz.Enums;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.GeneralLedger {
    public class ChartOfAccountCommon {
		private HttpContext HttpContext { get; }

		public ChartOfAccountCommon(HttpContext httpContext) {
			HttpContext = httpContext;
		}

		public bool CreateOrUpdate(AppMainContext context, AppAdminContext adminContext, ChartOfAccountViewModel model, int headOfficeAgencyId) {
			if (model.RowType == RowType.UndistributedProfits && context.ChartOfAccount.Any(t => t.Id > 0 && t.Id != model.ChartOfAccountId && t.RowType == RowType.UndistributedProfits))
				throw new UnreportedException("Row Type cannot be set to Undistributed Profits because another record already contains this value.");

			if (model.RowType == RowType.RetainedProfits && context.ChartOfAccount.Any(t => t.Id > 0 && t.Id != model.ChartOfAccountId && t.RowType == RowType.RetainedProfits))
				throw new UnreportedException("Row Type cannot be set to Retained Profits because another record already contains this value.");

			if (model.ChartOfAccountType == ChartOfAccountType.BalanceSheet && context.ChartOfAccount.OrderBy(t => t.Code).Any(t => t.Id > 0 && t.AgencyId == model.AgencyId && t.ChartOfAccountType == ChartOfAccountType.ProfitLoss && string.Compare(model.Code, t.Code) <= 0))
				throw new UnreportedException("Code is invalid because it falls within the range of Profit & Loss accounts.");

			if (model.ChartOfAccountType == ChartOfAccountType.ProfitLoss && context.ChartOfAccount.OrderBy(t => t.Code).Any(t => t.Id > 0 && t.AgencyId == model.AgencyId && t.ChartOfAccountType == ChartOfAccountType.BalanceSheet && string.Compare(model.Code, t.Code) >= 0))
				throw new UnreportedException("Code is invalid because it falls within the range of Balance Sheet accounts.");

			ChartOfAccount q = null;
			bool isNew = model.ChartOfAccountId <= 0;

			if (model.ChartOfAccountId <= 0) {
				q = new ChartOfAccount {
					Id = 0,
                    AgencyId = headOfficeAgencyId
                };
			}
			else {
				q = context.ChartOfAccount.Include(t => t.ChartOfAccountRoles).Single(t => t.Id == model.ChartOfAccountId);

				if (!q.IsInRole(HttpContext.RoleId()))
					throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

				if (q.RowType == RowType.Normal && model.RowType != RowType.Normal && context.TransactionDetail.Any(t => t.ChartOfAccountId == q.Id && t.ChartOfAccount.RowType == RowType.Normal))
					throw new UnreportedException(string.Format("Row Type cannot be set to {0} because transactions already exist with a different Row Type.", model.RowType.GetEnumDescription()));

				if (q.RowType == RowType.RetainedProfits && model.RowType != RowType.RetainedProfits && context.TransactionDetail.Any(t => t.ChartOfAccountId == q.Id && t.ChartOfAccount.RowType == RowType.RetainedProfits))
					throw new UnreportedException(string.Format("Row Type cannot be set to {0} because transactions already exist with a different Row Type.", model.RowType.GetEnumDescription()));
			}

			q.Code = Utils.RemoveExtraSpaces(model.Code).Replace(" ", string.Empty).ToUpper();
			q.Name = model.Name;
			q.ChartOfAccountType = model.ChartOfAccountType;
			q.RowType = model.RowType;
			q.AccountCategory = model.AccountCategory;
			q.ChartOfAccountTransactionType = model.ChartOfAccountTransactionType;
			q.TotalLevel = model.TotalLevel;
			q.AltReportingCode = string.IsNullOrEmpty(model.AltReportingCode) ? model.Code : model.AltReportingCode;
			q.IsTaxApplicable = model.IsTaxApplicable;

			if (q.Id <= 0) {
				context.Insert(q);
			}
			else {
				context.Save(q);
			}

			model.ChartOfAccountId = q.Id;

			if (model.UserRoleIds == null) {
				if (q.ChartOfAccountRoles.Count > 0) {
					foreach (var row in q.ChartOfAccountRoles.ToList()) {
						context.Delete(row);
					}
				}
			}
			else {
				foreach (var row in Lists.GetRolesList(adminContext)) {
					string roleId = row.Value;
					var chartOfAccountRole = context.ChartOfAccountRole.SingleOrDefault(t => t.ChartOfAccountId == model.ChartOfAccountId && t.RoleId == roleId);

					if (model.UserRoleIds.Any(t => t == roleId)) {
						if (chartOfAccountRole == null) {
							chartOfAccountRole = new ChartOfAccountRole { Id = 0, ChartOfAccountId = model.ChartOfAccountId, RoleId = roleId };
							context.Insert(chartOfAccountRole);
						}
					}
					else if (chartOfAccountRole != null) {
						context.Delete(chartOfAccountRole);
					}
				}
			}

			return true;
		}

		public bool Delete(AppMainContext context, ChartOfAccountViewModel model) {
			var q = context.ChartOfAccount.Include(t => t.ChartOfAccountRoles).Include(t => t.ChartOfAccountBudgets).SingleOrDefault(t => t.Id == model.ChartOfAccountId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			if (!q.IsInRole(HttpContext.RoleId()))
				throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

			using (var ts = Utils.CreateTransactionScope()) {
				foreach (var row in context.ChartOfAccountBudget.Where(t => t.ChartOfAccountId == model.ChartOfAccountId)) {
					context.Delete(row);
				}

				context.Delete(q);
				ts.Complete();
			}

			return true;
		}
	}

	public class ChartOfAccountBudgetCommon {
		public bool Update(AppMainContext context, [Bind(Prefix = "models")] IEnumerable<ChartOfAccountBudgetViewModel> models) {
			if (models == null)
				return false;

			using (var ts = Utils.CreateTransactionScope()) {
				foreach (var model in models) {
					int i = 0;

					foreach (var row in context.SettingDetail.Where(t => t.SettingId == model.SettingId).OrderBy(t => t.FiscalPeriodEndDate).ToList()) {
						i++;
						var q = context.ChartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == model.ChartOfAccountId && t.SettingDetailId == row.Id);

						if (q == null) {
							q = new ChartOfAccountBudget {
								Id = 0,
								ChartOfAccountId = model.ChartOfAccountId,
								SettingDetailId = row.Id
							};
						}

						switch (i) {
							case 1:
								q.Amount = model.Amount01;
								break;
							case 2:
								q.Amount = model.Amount02;
								break;
							case 3:
								q.Amount = model.Amount03;
								break;
							case 4:
								q.Amount = model.Amount04;
								break;
							case 5:
								q.Amount = model.Amount05;
								break;
							case 6:
								q.Amount = model.Amount06;
								break;
							case 7:
								q.Amount = model.Amount07;
								break;
							case 8:
								q.Amount = model.Amount08;
								break;
							case 9:
								q.Amount = model.Amount09;
								break;
							case 10:
								q.Amount = model.Amount10;
								break;
							case 11:
								q.Amount = model.Amount11;
								break;
							case 12:
								q.Amount = model.Amount12;
								break;
							case 13:
								q.Amount = model.Amount13;
								break;
						}

						if (q.Id <= 0) {
							context.Insert(q);
						}
						else {
							context.Save(q);
						}
					}
				}

				ts.Complete();
			}

			return true;
		}

		public static ChartOfAccountBudgetViewModel ApportionAmounts(AppMainContext context, string budgetModel, ChartOfAccountBudgetViewModel model, FiscalPeriod fiscalPeriod, int settingDetailId, decimal amount) {
			var q1 = context.SettingDetail.Where(t => t.SettingId == model.SettingId).OrderBy(t => t.FiscalPeriodEndDate).ToList();
			var q2 = context.ChartOfAccountBudget.Where(t => t.ChartOfAccountId == model.ChartOfAccountId && t.SettingDetail.SettingId == model.SettingId).OrderBy(t => t.SettingDetail.FiscalPeriodEndDate).ToList();

			int startIndex = q1.FindIndex(t => t.Id == settingDetailId);
			int periodCount = 0;

			switch (fiscalPeriod) {
				default:
					periodCount = q1.Count;
					break;
				case FiscalPeriod.ThreePeriods:
					periodCount = 3;
					break;
				case FiscalPeriod.SixPeriods:
					periodCount = 6;
					break;
			}

			if (periodCount == 0) {
				amount = 0;
			}
			else {
				amount = Math.Round(amount / periodCount, 2);
			}

            var chartOfAccountBudgetModel = JsonSerializer.Deserialize<ChartOfAccountBudgetViewModel>(budgetModel, JsonExtensionsBiz.JsonSerializerOptions());
            int i = 0;

			if (startIndex <= 0 && q1.Count >= 1) {
				chartOfAccountBudgetModel.Amount01 = amount;
				i++;

				if (i == periodCount)
					startIndex = 100;
			}

			if (startIndex <= 1 && q1.Count >= 2) {
				chartOfAccountBudgetModel.Amount02 = amount;
				i++;

				if (i == periodCount)
					startIndex = 100;
			}

			if (startIndex <= 2 && q1.Count >= 3) {
				chartOfAccountBudgetModel.Amount03 = amount;
				i++;

				if (i == periodCount)
					startIndex = 100;
			}

			if (startIndex <= 3 && q1.Count >= 1) {
				chartOfAccountBudgetModel.Amount04 = amount;
				i++;

				if (i == periodCount)
					startIndex = 100;
			}

			if (startIndex <= 4 && q1.Count >= 2) {
				chartOfAccountBudgetModel.Amount05 = amount;
				i++;

				if (i == periodCount)
					startIndex = 100;
			}

			if (startIndex <= 5 && q1.Count >= 3) {
				chartOfAccountBudgetModel.Amount06 = amount;
				i++;

				if (i == periodCount)
					startIndex = 100;
			}

			if (startIndex <= 6 && q1.Count >= 1) {
				chartOfAccountBudgetModel.Amount07 = amount;
				i++;

				if (i == periodCount)
					startIndex = 100;
			}

			if (startIndex <= 7 && q1.Count >= 2) {
				chartOfAccountBudgetModel.Amount08 = amount;
				i++;

				if (i == periodCount)
					startIndex = 100;
			}

			if (startIndex <= 8 && q1.Count >= 3) {
				chartOfAccountBudgetModel.Amount09 = amount;
				i++;

				if (i == periodCount)
					startIndex = 100;
			}

			if (startIndex <= 9 && q1.Count >= 1) {
				chartOfAccountBudgetModel.Amount10 = amount;
				i++;

				if (i == periodCount)
					startIndex = 100;
			}

			if (startIndex <= 10 && q1.Count >= 2) {
				chartOfAccountBudgetModel.Amount11 = amount;
				i++;

				if (i == periodCount)
					startIndex = 100;
			}

			if (startIndex <= 11 && q1.Count >= 3)
				chartOfAccountBudgetModel.Amount12 = amount;

			return chartOfAccountBudgetModel;
		}
	}

	public class ChartOfAccountAgencyCommon {
		private HttpContext HttpContext { get; }

		public ChartOfAccountAgencyCommon(HttpContext httpContext) {
			HttpContext = httpContext;
		}

		public bool Create(AppMainContext context, ChartOfAccountAgencyViewModel model) {
			if (context.ChartOfAccount.Any(t => t.Id == model.ChartOfAccountAgencyChartOfAccountId && t.AgencyId == model.ChartOfAccountAgencyAgencyId))
				throw new UnreportedException("Account already exists for this Agency.");

			var q = context.ChartOfAccount.Find(model.ChartOfAccountAgencyChartOfAccountId);

			q.Id = 0;
			q.AgencyId = model.ChartOfAccountAgencyAgencyId;

			context.Insert(q);
			model.ChartOfAccountAgencyChartOfAccountId = q.Id;

			return true;
		}

		public bool Delete(AppMainContext context, ChartOfAccountAgencyViewModel model) {
			var q = context.ChartOfAccount.Find(model.ChartOfAccountAgencyChartOfAccountId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			if (!q.IsInRole(HttpContext.RoleId()))
				throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

			using (var ts = Utils.CreateTransactionScope()) {
				foreach (var row in context.ChartOfAccountBudget.Where(t => t.ChartOfAccountId == model.ChartOfAccountAgencyChartOfAccountId)) {
					context.Delete(row);
				}

				context.Delete(q);
				ts.Complete();
			}

			return true;
		}
	}

	public class GeneralLedgerSettingCommon {
		private HttpContext HttpContext { get; }

		public GeneralLedgerSettingCommon(HttpContext httpContext) {
			HttpContext = httpContext;
		}

		public bool CreateOrUpdate(AppMainContext context, AppAdminContext adminContext, GeneralLedgerSettingViewModel model) {
			using (var ts = Utils.CreateTransactionScope()) {
				Setting setting = null;

				if (model.SettingId <= 0) {
					setting = context.Setting.OrderByDescending(t => t.FiscalYearStartDate).FirstOrDefault();
					DateTime fiscalYearStartDate = DateTime.MinValue;

					if (setting == null) {
						fiscalYearStartDate = adminContext.Customer.Find(HttpContext.CurrentCustomerId()).StartDate;
						setting = new Setting();
					}
					else {
						fiscalYearStartDate = setting.FiscalYearStartDate.AddYears(1);

						setting = new Setting {
							Id = 0,
							ClientControlAccountId = setting.ClientControlAccountId,
							DebtorControlAccountId = setting.DebtorControlAccountId,
							CreditorControlAccountId = setting.CreditorControlAccountId,
							BspAccrualAccountId = setting.BspAccrualAccountId,
							SupplierReturnsAccountId = setting.SupplierReturnsAccountId,
							CreditCardChargeAccountId = setting.CreditCardChargeAccountId,
							CommissionAccountId = setting.CommissionAccountId,
							OverrideCommissionAccountId = setting.OverrideCommissionAccountId,
							OtherCommissionAccountId = setting.OtherCommissionAccountId,
							SalesTaxAccountId = setting.SalesTaxAccountId,
							PurchasesTaxAccountId = setting.PurchasesTaxAccountId
						};
					}

					model.FiscalYearStartDate = fiscalYearStartDate;
					model.FiscalYearStartDateName = string.Format("{0}-{1}", fiscalYearStartDate.Year, fiscalYearStartDate.AddYears(1).Year);
				}
				else {
					setting = context.Setting.Find(model.SettingId);

					setting.ClientControlAccountId = model.ClientControlAccountId ?? 0;
					setting.DebtorControlAccountId = model.DebtorControlAccountId ?? 0;
					setting.CreditorControlAccountId = model.CreditorControlAccountId ?? 0;
					setting.BspAccrualAccountId = model.BspAccrualAccountId ?? 0;
					setting.SupplierReturnsAccountId = model.SupplierReturnsAccountId ?? 0;
					setting.CreditCardChargeAccountId = model.CreditCardChargeAccountId ?? 0;
					setting.CommissionAccountId = model.CommissionAccountId ?? 0;
					setting.OverrideCommissionAccountId = model.OverrideCommissionAccountId ?? 0;
					setting.OtherCommissionAccountId = model.OtherCommissionAccountId ?? 0;
					setting.SalesTaxAccountId = model.SalesTaxAccountId ?? 0;
					setting.PurchasesTaxAccountId = model.PurchasesTaxAccountId ?? 0;
				}

				setting.GeneralLedgerDivision = model.GeneralLedgerDivision;
				setting.FiscalYearStartDate = model.FiscalYearStartDate ?? DateTime.MinValue;
				setting.FiscalYearStartDateName = model.FiscalYearStartDateName;

				bool result;

				if (setting.Id <= 0) {
					result = context.Insert(setting);
				}
				else {
					result = context.Save(setting);
				}

				if (result)
					GeneralLedgerSettings.ClearFiscalPeriodLists(HttpContext.CurrentCustomerId());

				if (model.SettingId <= 0) {
					for (int i = 1; i <= 12; i++) {
						var settingDetail = new SettingDetail {
							Id = 0,
							SettingId = setting.Id,
							FiscalPeriodEndDate = setting.FiscalYearStartDate.AddMonths(i).AddDays(-1),
							FiscalPeriodEndDateName = setting.FiscalYearStartDate.AddMonths(i).AddDays(-1).ToString("MMMM yyyy"),
							IsAdminClosed = false,
							IsUserClosed = false
						};

						if (context.Insert(settingDetail))
							GeneralLedgerSettings.ClearFiscalPeriodLists(HttpContext.CurrentCustomerId());
					}
				}

				ts.Complete();
				return result;
			}
		}

		public bool Delete(AppMainContext context, int settingId) {
			var q = context.Setting.Include(t => t.SettingDetails).SingleOrDefault(t => t.Id == settingId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			if (context.Delete(q))
				GeneralLedgerSettings.ClearFiscalPeriodLists(HttpContext.CurrentCustomerId());

			return true;
		}
	}

	public class GeneralLedgerSettingDetailCommon {
		private HttpContext HttpContext { get; }

		public GeneralLedgerSettingDetailCommon(HttpContext httpContext) {
			HttpContext = httpContext;
		}

		public bool CreateOrUpdate(AppMainContext context, GeneralLedgerSettingDetailViewModel model) {
			var setting = context.Setting.Find(model.SettingId);

			if (setting == null)
				throw new UnreportedException("Either the parent record has not been created or was lost in this update. Press 'Update' below the grid or try reloading the page.");

			if (context.SettingDetail.Count(t => t.SettingId == model.SettingId) >= 13)
				throw new UnreportedException("A maximum of 13 periods are permitted.");

			SettingDetail q = null;

			if (model.SettingDetailId <= 0) {
				q = new SettingDetail {
					Id = 0,
					Setting = setting
				};
			}
			else {
				q = context.SettingDetail.Include(t => t.Setting).Single(t => t.Id == model.SettingDetailId);
			}

			if (model.FiscalPeriodEndDate < q.Setting.FiscalYearStartDate)
				throw new UnreportedException("End Date is outside the date range for this fiscal year.");

			q.SettingId = model.SettingId;
			q.FiscalPeriodEndDate = model.FiscalPeriodEndDate ?? DateTime.MinValue;
			q.FiscalPeriodEndDateName = model.FiscalPeriodEndDateName;
			q.IsAdminClosed = model.IsAdminClosed;
			q.IsUserClosed = model.IsUserClosed;

			bool result;

			if (q.Id <= 0) {
				result = context.Insert(q);
			}
			else {
				result = context.Save(q);
			}

			if (result)
				GeneralLedgerSettings.ClearFiscalPeriodLists(HttpContext.CurrentCustomerId());

			model.SettingDetailId = q.Id;
			return true;
		}

		public bool Delete(AppMainContext context, GeneralLedgerSettingDetailViewModel model) {
			var q = context.SettingDetail.Find(model.SettingDetailId);

			if (q == null)
				throw new UnreportedException(AppConstants.RecordNotFound);

			if (context.Delete(q))
				GeneralLedgerSettings.ClearFiscalPeriodLists(HttpContext.CurrentCustomerId());

			return true;
		}
	}
}