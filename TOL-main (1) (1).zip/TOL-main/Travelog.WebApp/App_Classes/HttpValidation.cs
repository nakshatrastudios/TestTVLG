using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Travelog.Biz;
using Travelog.Biz.Enums;
using Travelog.WebApp.Models;

namespace Travelog.WebApp {
    public class HttpValidation {
        private List<MenuViewModel> MenuList { get; }

        public HttpValidation(List<MenuViewModel> menuList) {
            MenuList = menuList;
        }

        public async Task InvokeAsync(HttpContext httpContext, int agencyCount) {
            if (IsSystemUrl(httpContext.Request.GetEncodedPathAndQuery()))
                return;

            string url = WebUtils.GetBaseUrl(httpContext);

            if (httpContext.Session == null || !httpContext.User.Identity.IsAuthenticated) {
                SetNavNext(httpContext, url, false);
                return;
            }

            if (httpContext.Request.Method != "POST") {
                string path = httpContext.Request.Path;

                switch (httpContext.ValidateUserStatus(agencyCount)) {
                    case UserStatus.CustomerNotAuthorised:
                        if (!path.Equals(AppSettings.HomePage, StringComparison.OrdinalIgnoreCase))
                            httpContext.Response.Redirect(string.Format("{0}?message={1}&messageType=warning&timeoutSeconds=0", AppSettings.HomePage, AppConstants.UnauthorisedAccessCurrentUrl));

                        return;
                    case UserStatus.NoAgencySelected:
                        if (!path.Equals(AppSettings.HomePage, StringComparison.OrdinalIgnoreCase))
                            httpContext.Response.Redirect(string.Format("{0}?message=Please select an agency to enable access to the application.&messageType=warning&timeoutSeconds=0", AppSettings.HomePage));

                        return;
                    case UserStatus.ForceSignOut:
                        if (!path.Equals(AppSettings.SignInPage, StringComparison.OrdinalIgnoreCase))
                            httpContext.Response.Redirect(string.Format("{0}?message=You have been signed out by an Administrator.&timeoutSeconds=0", AppSettings.SignOutPage));

                        return;
                    case UserStatus.MultipleSignIns:
                        if (!path.Equals(AppSettings.SignInPage, StringComparison.OrdinalIgnoreCase))
                            httpContext.Response.Redirect(string.Format("{0}?message=You have been signed out because you have another session active. Please sign in here again if you wish to make this the active session.&timeoutSeconds=0", AppSettings.SignOutPage));

                        return;
                    case UserStatus.PasswordChangeReqd:
                        if (!path.Equals(AppSettings.ChangePasswordPage, StringComparison.OrdinalIgnoreCase))
                            httpContext.Response.Redirect(string.Format("{0}?message={1}.&timeoutSeconds=0", AppSettings.ChangePasswordPage, AppConstants.PasswordExpired));

                        return;
                }

                if (CustomerSettings.GetCustomerAccountStatus(httpContext.CurrentCustomerId()) == CustomerAccountStatus.Locked || !CustomerSettings.Setting(httpContext.CurrentCustomerId()).IsCustomerAccountActive || CustomerSettings.Setting(httpContext.CurrentCustomerId()).IsCustomerAccountSuspended) {
                    if (!url.Equals(AppSettings.HomePage, StringComparison.OrdinalIgnoreCase) && !url.Equals(AppSettings.MyAccountPage, StringComparison.OrdinalIgnoreCase) && !url.StartsWith(AppSettings.CustomerAccountPage, StringComparison.OrdinalIgnoreCase))
                        httpContext.Response.Redirect(AppSettings.CustomerAccountPage);

                    return;
                }
            }

            if (!MenuList.Any(t => url.StartsWith(t.NavigateUrl, StringComparison.OrdinalIgnoreCase) && t.ValidateItem))
                return;

            switch (GetAccessLevel(httpContext, url)) {
                case AccessLevel.NotAuthorised:
                    httpContext.Response.Redirect(AppSettings.NotAuthorisedPage);
                    break;
                case AccessLevel.ReadOnly:
                    url = httpContext.Request.GetEncodedPathAndQuery();

                    if (IsUpdateUrl(url) && !url.Contains("Customer_Connect", StringComparison.OrdinalIgnoreCase) && !url.Contains("MenuNodeState_Update", StringComparison.OrdinalIgnoreCase)) {
                        httpContext.Response.Clear();
                        httpContext.Response.StatusCode = 998;
                        await httpContext.Response.CompleteAsync();
                    }

                    break;
            }
        }

        private AccessLevel GetAccessLevel(HttpContext httpContext, string url) {
            var q = MenuList.Where(t => t.ValidateItem && url.Equals(t.NavigateUrl, StringComparison.OrdinalIgnoreCase));
            var accessLevel = q.Any() ? (AccessLevel)q.Min(t => (int)t.AccessLevel) : AccessLevel.ReadWrite;

            if (accessLevel != AccessLevel.NotAuthorised)
                SetNavNext(httpContext, url, true);

            return accessLevel;
        }

        private void SetNavNext(HttpContext httpContext, string url, bool validateWithMenu) {
            bool result = httpContext.Request.Method != "POST" && Uri.IsWellFormedUriString(url, UriKind.RelativeOrAbsolute) && !IsSystemUrl(url) && !IsUpdateUrl(url);

            if (validateWithMenu)
                result = result && !MenuList.Any(t => t.NavigateUrl.Length > 0 && url.StartsWith(t.NavigateUrl, StringComparison.OrdinalIgnoreCase) && t.ExcludeFromHistory);

            if (result)
                httpContext.NavNext(httpContext.Request.GetEncodedPathAndQuery());
        }

        private bool IsSystemUrl(string url) {
            return url.Contains("_Read", StringComparison.OrdinalIgnoreCase)
                || url.Contains("_Export", StringComparison.OrdinalIgnoreCase)
                || url.Contains("_Report", StringComparison.OrdinalIgnoreCase)
                || url.Contains("_Download", StringComparison.OrdinalIgnoreCase)
                || url.Contains("/css/", StringComparison.OrdinalIgnoreCase)
                || url.Contains("/js/", StringComparison.OrdinalIgnoreCase)
                || url.Contains("/api/reports/", StringComparison.OrdinalIgnoreCase)
                || url.Contains("/Account/Login", StringComparison.OrdinalIgnoreCase)
                || url.Contains("&isExport=true", StringComparison.OrdinalIgnoreCase)
                || url.Contains("%5Bobject%20Object%5D", StringComparison.OrdinalIgnoreCase)
                || url.StartsWith(AppSettings.SignInPage, StringComparison.OrdinalIgnoreCase)
                || url.StartsWith(AppSettings.SignOutPage, StringComparison.OrdinalIgnoreCase)
                || url.StartsWith(AppSettings.ProcessSignInPage, StringComparison.OrdinalIgnoreCase)
                || url.StartsWith(AppSettings.RecoverPasswordPage, StringComparison.OrdinalIgnoreCase)
                || url.StartsWith(AppSettings.ResetPasswordPage, StringComparison.OrdinalIgnoreCase)
                || url.StartsWith(AppSettings.RequestSupportPage, StringComparison.OrdinalIgnoreCase)
                || url.StartsWith(AppSettings.ErrorPage, StringComparison.OrdinalIgnoreCase)
                || url.StartsWith(AppSettings.ResourceNotFoundPage, StringComparison.OrdinalIgnoreCase)
                || url.StartsWith(AppSettings.NotAuthorisedPage, StringComparison.OrdinalIgnoreCase);
        }

        private bool IsUpdateUrl(string url) {
            return url.Contains("_Create", StringComparison.OrdinalIgnoreCase)
                || url.Contains("_Update", StringComparison.OrdinalIgnoreCase)
                || url.Contains("_Delete", StringComparison.OrdinalIgnoreCase)
                || url.Contains("_Undo", StringComparison.OrdinalIgnoreCase)
                || url.Contains("_Reverse", StringComparison.OrdinalIgnoreCase)
                || url.Contains("_Execute", StringComparison.OrdinalIgnoreCase)
                || url.Contains("_ProcessSelections", StringComparison.OrdinalIgnoreCase)
                || url.Contains("_IssueDocument", StringComparison.OrdinalIgnoreCase);
        }
    }
}