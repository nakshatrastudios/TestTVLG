﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Travelog.WebApp {
    public static class AppUsersOnline {
        private static readonly object padlock = new();
        private static readonly List<UserOnlineModel> UsersOnline = new();

        public static void UpdateLastActivity(string userId, int customerId, string sessionId, bool isExternalUser, bool isGlobalUser, bool isSupportUser) {
            if (string.IsNullOrEmpty(userId) || customerId == 0)
                return;

            lock (padlock) {
                foreach (var user in UsersOnline.Where(t => (t.UserId == userId && t.CustomerId != customerId) || t.LastActivity <= DateTime.UtcNow.AddHours(-1)).ToList()) {
                    UsersOnline.Remove(user);
                }

                var userOnline = UsersOnline.Find(t => t.UserId == userId && t.CustomerId == customerId);

                if (userOnline == null) {
                    UsersOnline.Add(new UserOnlineModel {
                        UserId = userId,
                        CustomerId = customerId,
                        SessionId = sessionId,
                        LastActivity = DateTime.UtcNow,
                        IsExternal = isExternalUser || isGlobalUser || isSupportUser
                    });
                }
                else {
                    userOnline.LastActivity = DateTime.UtcNow;
                }
            }
        }

        public static void RemoveUser(string userId) {
            if (string.IsNullOrEmpty(userId))
                return;

            lock (padlock) {
                foreach (var userOnline in UsersOnline.Where(t => t.UserId == userId).ToList()) {
                    UsersOnline.Remove(userOnline);
                }
            }
        }

        public static void ForceSignOut(string userId) {
            if (string.IsNullOrEmpty(userId))
                return;

            lock (padlock) {
                foreach (var userOnline in UsersOnline.Where(t => t.UserId == userId)) {
                    userOnline.ForceSignOut = true;
                }
            }
        }

        public static int GetConcurrentUserCount(string userId, int customerId) {
            return UsersOnline.Count(t => t.UserId != userId && t.CustomerId == customerId && t.LastActivity > DateTime.UtcNow.AddHours(-1) && !t.IsExternal);
        }

        public static bool IsUserOnline(string userId, int customerId) {
            if (string.IsNullOrEmpty(userId) || customerId == 0)
                return false;

            return UsersOnline.Any(t => t.UserId == userId && t.CustomerId == customerId && t.LastActivity > DateTime.UtcNow.AddHours(-1));
        }

        public static bool IsUserOnlineAnotherSession(string userId, string sessionId) {
            if (string.IsNullOrEmpty(userId))
                return false;

            return UsersOnline.Any(t => t.UserId == userId && t.SessionId != sessionId && t.LastActivity > DateTime.UtcNow.AddHours(-1));
        }

        public static bool IsUserForcedSignOut(string userId) {
            if (string.IsNullOrEmpty(userId))
                return false;

            return UsersOnline.Any(t => t.UserId == userId && t.ForceSignOut);
        }

        private class UserOnlineModel {
            public string UserId { get; set; }
            public int CustomerId { get; set; }
            public string SessionId { get; set; }
            public DateTime LastActivity { get; set; }
            public bool IsExternal { get; set; }
            public bool ForceSignOut { get; set; }
        }
    }
}