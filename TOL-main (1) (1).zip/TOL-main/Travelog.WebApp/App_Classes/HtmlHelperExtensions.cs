﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using Kendo.Mvc.UI;
using Kendo.Mvc.UI.Fluent;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Routing;
using Travelog.Biz.Resources;

namespace Travelog.WebApp {
    public static class HtmlHelperExtensions {
        public static TextBoxBuilder<TProperty> CustomTextBoxFor<TModel, TProperty>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            return htmlHelper.Kendo().TextBoxFor(expression).HtmlAttributes(attributes);
        }

        public static MaskedTextBoxBuilder CustomMaskedTextBoxFor<TModel, TProperty>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            return htmlHelper.Kendo().MaskedTextBoxFor(expression).HtmlAttributes(attributes);
        }

        public static TextAreaBuilder CustomTextAreaFor<TModel, TProperty>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            return htmlHelper.Kendo().TextAreaFor(expression).HtmlAttributes(attributes);
        }

        public static NumericTextBoxBuilder<decimal> CustomNumericTextBoxFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, decimal?>> expression, object htmlAttributes = null, int decimals = 2, decimal? min = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            bool isReadOnly = false;

            if (evaluateAttributes)
                isReadOnly = SetReadOnlyAttributes(metadata, attributes);

            var textBox = htmlHelper.Kendo().NumericTextBoxFor(expression)
                .HtmlAttributes(attributes)
                .Format(string.Format("n{0}", decimals))
                .Decimals(decimals)
                .Step(1);

            if (!isReadOnly && min != null)
                textBox = textBox.Min(min);

            return textBox;
        }

        public static NumericTextBoxBuilder<decimal> CustomNumericTextBoxFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, decimal>> expression, object htmlAttributes = null, int decimals = 2, decimal? min = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            bool isReadOnly = false;

            if (evaluateAttributes)
                isReadOnly = SetReadOnlyAttributes(metadata, attributes);

            var textBox = htmlHelper.Kendo().NumericTextBoxFor(expression)
                .HtmlAttributes(attributes)
                .Format(string.Format("n{0}", decimals))
                .Decimals(decimals)
                .Step(1);

            if (!isReadOnly && min != null)
                textBox = textBox.Min(min);

            return textBox;
        }

        public static NumericTextBoxBuilder<decimal> CustomCurrencyTextBox<TModel>(this IHtmlHelper<TModel> htmlHelper, object htmlAttributes = null, int decimals = 2, decimal? min = null) {
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            var textBox = htmlHelper.Kendo().CurrencyTextBox()
                .HtmlAttributes(attributes)
                .Format(string.Format("c{0}", decimals))
                .Decimals(decimals)
                .Step(1);

            if (min != null)
                textBox = textBox.Min(min);

            return textBox;
        }

        public static NumericTextBoxBuilder<decimal> CustomCurrencyTextBoxFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, decimal?>> expression, object htmlAttributes = null, int decimals = 2, decimal? min = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            bool isReadOnly = false;

            if (evaluateAttributes)
                isReadOnly = SetReadOnlyAttributes(metadata, attributes);

            var textBox = htmlHelper.Kendo().CurrencyTextBoxFor(expression)
                .HtmlAttributes(attributes)
                .Format(string.Format("c{0}", decimals))
                .Decimals(decimals)
                .Step(1);

            if (min != null && !isReadOnly)
                textBox = textBox.Min(min);

            return textBox;
        }

        public static NumericTextBoxBuilder<decimal> CustomCurrencyTextBoxFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, decimal>> expression, object htmlAttributes = null, int decimals = 2, decimal? min = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            bool isReadOnly = false;

            if (evaluateAttributes)
                isReadOnly = SetReadOnlyAttributes(metadata, attributes);

            var textBox = htmlHelper.Kendo().CurrencyTextBoxFor(expression)
                .HtmlAttributes(attributes)
                .Format(string.Format("c{0}", decimals))
                .Decimals(decimals)
                .Step(1);

            if (min != null && !isReadOnly)
                textBox = textBox.Min(min);

            return textBox;
        }

        public static NumericTextBoxBuilder<decimal> CustomPercentTextBoxFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, decimal>> expression, object htmlAttributes = null, int decimals = 3, decimal? min = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            bool isReadOnly = false;

            if (evaluateAttributes)
                isReadOnly = SetReadOnlyAttributes(metadata, attributes);

            var textBox = htmlHelper.Kendo().NumericTextBoxFor(expression)
                .HtmlAttributes(attributes)
                .Factor(100)
                .Format(string.Format("p{0}", decimals))
                .Decimals(decimals + 2)
                .Step(.01m);

            if (!isReadOnly && min != null)
                textBox = textBox.Min(min);

            return textBox;
        }

        public static NumericTextBoxBuilder<int> CustomIntegerTextBoxFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, int?>> expression, object htmlAttributes = null, int? min = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            bool isReadOnly = false;

            if (evaluateAttributes)
                isReadOnly = SetReadOnlyAttributes(metadata, attributes);

            var textBox = htmlHelper.Kendo().IntegerTextBoxFor(expression)
                .HtmlAttributes(attributes);

            if (!isReadOnly && min != null)
                textBox = textBox.Min(min);

            return textBox;
        }

        public static NumericTextBoxBuilder<int> CustomIntegerTextBoxFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, int>> expression, object htmlAttributes = null, int? min = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            bool isReadOnly = false;

            if (evaluateAttributes)
                isReadOnly = SetReadOnlyAttributes(metadata, attributes);

            var textBox = htmlHelper.Kendo().IntegerTextBoxFor(expression)
                .HtmlAttributes(attributes);

            if (!isReadOnly && min != null)
                textBox = textBox.Min(min);

            return textBox;
        }

        public static CheckBoxBuilder CustomCheckBoxFor<TModel, TProperty>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            if (evaluateAttributes)
                SetReadOnlyAttributes(metadata, attributes);

            return htmlHelper.Kendo().CheckBoxFor(expression).HtmlAttributes(attributes);
        }

        public static ComboBoxBuilder CustomComboBox<TModel>(this IHtmlHelper<TModel> htmlHelper, object htmlAttributes = null) {
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            return htmlHelper.Kendo().ComboBox()
                .HtmlAttributes(attributes)
                .DataValueField("Value")
                .DataTextField("Text")
                .Placeholder("Please select...")
                .Filter(FilterType.Contains)
                .Height(226)
                .MinLength(1)
                .Suggest(false)
                .HighlightFirst(true)
                .IgnoreCase(true)
                .ValuePrimitive(true);
        }

        public static ComboBoxBuilder CustomComboBoxFor<TModel, TProperty>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes = null, bool evaluateAttributes = true, bool isValueNumeric = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            if (isValueNumeric)
                attributes.Add("data-val-number", string.Format("{0} is invalid.", metadata.Metadata.DisplayName));

            return htmlHelper.Kendo().ComboBoxFor(expression)
                .HtmlAttributes(attributes)
                .DataValueField("Value")
                .DataTextField("Text")
                .Placeholder("Please select...")
                .Filter(FilterType.Contains)
                .Height(226)
                .MinLength(1)
                .Suggest(false)
                .HighlightFirst(true)
                .IgnoreCase(true)
                .ValuePrimitive(true);
        }

        public static MultiColumnComboBoxBuilder CustomMultiColumnComboBox<TModel>(this IHtmlHelper<TModel> htmlHelper, object htmlAttributes = null) {
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            return htmlHelper.Kendo().MultiColumnComboBox()
                .HtmlAttributes(attributes)
                .DataValueField("Value")
                .DataTextField("Text")
                .Placeholder("Please select...")
                .Filter(FilterType.Contains)
                .Height(226)
                .MinLength(1)
                .Suggest(false)
                .HighlightFirst(true)
                .IgnoreCase(true)
                .ValuePrimitive(true);
        }

        public static MultiColumnComboBoxBuilder CustomMultiColumnComboBoxFor<TModel, TProperty>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes = null, bool evaluateAttributes = true, bool isValueNumeric = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            if (isValueNumeric)
                attributes.Add("data-val-number", string.Format("{0} is invalid.", metadata.Metadata.DisplayName));

            return htmlHelper.Kendo().MultiColumnComboBoxFor(expression)
                .HtmlAttributes(attributes)
                .DataValueField("Value")
                .DataTextField("Text")
                .Placeholder("Please select...")
                .Filter(FilterType.Contains)
                .Height(226)
                .MinLength(1)
                .Suggest(false)
                .HighlightFirst(true)
                .IgnoreCase(true)
                .ValuePrimitive(true);
        }

        public static DropDownListBuilder CustomDropDownList<TModel>(this IHtmlHelper<TModel> htmlHelper, object htmlAttributes = null, bool includePlaceholder = false, string placeholder = null) {
            var attributes = new RouteValueDictionary(htmlAttributes);

            return htmlHelper.Kendo().DropDownList()
                .HtmlAttributes(attributes)
                .DataValueField("Value")
                .DataTextField("Text")
                .OptionLabel(includePlaceholder ? (string.IsNullOrEmpty(placeholder) ? "Please select..." : placeholder) : null)
                .OptionLabelTemplate(includePlaceholder ? string.Format("<span style='opacity: {0}'>{1}</span>", htmlHelper.ViewContext.HttpContext.PlaceholderOpacity(), string.IsNullOrEmpty(placeholder) ? "Please select..." : placeholder) : null)
                .Filter(FilterType.Contains)
                .Height(217)
                .MinLength(1)
                .IgnoreCase(true)
                .Animation(false)
                .ValuePrimitive(true);
        }

        public static DropDownListBuilder CustomDropDownListFor<TModel, TProperty>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes = null, bool includePlaceholder = false, string placeholder = null, bool evaluateAttributes = true, bool isValueNumeric = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = new RouteValueDictionary(htmlAttributes);

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            if (isValueNumeric)
                attributes.Add("data-val-number", string.Format("{0} is invalid.", metadata.Metadata.DisplayName));

            return htmlHelper.Kendo().DropDownListFor(expression)
                .HtmlAttributes(attributes)
                .DataValueField("Value")
                .DataTextField("Text")
                .OptionLabel(includePlaceholder ? (string.IsNullOrEmpty(placeholder) ? "Please select..." : placeholder) : null)
                .OptionLabelTemplate(includePlaceholder ? string.Format("<span style='opacity: {0}'>{1}</span>", htmlHelper.ViewContext.HttpContext.PlaceholderOpacity(), string.IsNullOrEmpty(placeholder) ? "Please select..." : placeholder) : null)
                .Filter(FilterType.Contains)
                .Height(217)
                .MinLength(1)
                .IgnoreCase(true)
                .Animation(false)
                .ValuePrimitive(true);
        }

        public static MultiSelectBuilder CustomMultiSelect<TModel>(this IHtmlHelper<TModel> htmlHelper, object htmlAttributes = null, bool includePlaceholder = false, string placeholder = null) {
            var attributes = new RouteValueDictionary(htmlAttributes);

            return htmlHelper.Kendo().MultiSelect()
                .HtmlAttributes(attributes)
                .DataValueField("Value")
                .DataTextField("Text")
                .Placeholder(includePlaceholder ? (string.IsNullOrEmpty(placeholder) ? "Please select..." : placeholder) : null)
                .Filter(FilterType.Contains)
                .Height(220)
                .MinLength(1)
                .AutoClose(false)
                .ClearButton(false)
                .IgnoreCase(true)
                .Animation(false)
                .ValuePrimitive(true);
        }

        public static MultiSelectBuilder CustomMultiSelectFor<TModel, TProperty>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes = null, bool includePlaceholder = false, string placeholder = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = new RouteValueDictionary(htmlAttributes);

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            return htmlHelper.Kendo().MultiSelectFor(expression)
                .HtmlAttributes(attributes)
                .DataValueField("Value")
                .DataTextField("Text")
                .Placeholder(includePlaceholder ? (string.IsNullOrEmpty(placeholder) ? "Please select..." : placeholder) : null)
                .Filter(FilterType.Contains)
                .Height(220)
                .MinLength(1)
                .AutoClose(false)
                .ClearButton(false)
                .IgnoreCase(true)
                .Animation(false)
                .ValuePrimitive(true);
        }

        public static AutoCompleteBuilder CustomAutoComplete<TModel>(this IHtmlHelper<TModel> htmlHelper, object htmlAttributes = null) {
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            return htmlHelper.Kendo().AutoComplete()
                .HtmlAttributes(attributes)
                .Filter(FilterType.Contains)
                .MinLength(2)
                .Suggest(false)
                .HighlightFirst(false)
                .ValuePrimitive(true);
        }

        public static AutoCompleteBuilder CustomAutoCompleteFor<TModel, TProperty>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            return htmlHelper.Kendo().AutoCompleteFor(expression)
                .HtmlAttributes(attributes)
                .Filter(FilterType.Contains)
                .MinLength(2)
                .Suggest(false)
                .HighlightFirst(false)
                .ValuePrimitive(true);
        }

        public static DatePickerBuilder CustomDatePicker<TModel>(this IHtmlHelper<TModel> htmlHelper, object htmlAttributes = null) {
            return htmlHelper.Kendo().DatePicker()
                .HtmlAttributes(htmlAttributes)
                .Culture(CultureInfo.CurrentCulture.Name)
                .Min(new DateTime(1900, 1, 1))
                .Format(Resource.ShortDatePattern)
                .ParseFormats(new[] { "dd-MMM-yyyy", "dd/MMM/yyyy", "dd-MM-yyyy", "dd/MM/yyyy", "dd-MM-yy", "dd/MM/yy", "dd-MM", "dd/MM", "dd" });
        }

        public static DatePickerBuilder CustomDatePickerFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, DateTime>> expression, object htmlAttributes = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);

            var attributes = new RouteValueDictionary(htmlAttributes);

            if (attributes.Any(t => t.Key == "data-val-date")) {
                attributes["data-val-date"] = string.Format("{0} is invalid.", metadata.Metadata.DisplayName);
            }
            else {
                attributes.Add("data-val-date", string.Format("{0} is invalid.", metadata.Metadata.DisplayName));
            }

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            return htmlHelper.Kendo().DatePickerFor(expression)
                .HtmlAttributes(attributes)
                .Culture(CultureInfo.CurrentCulture.Name)
                .Min(new DateTime(1900, 1, 1))
                .Format(Resource.ShortDatePattern)
                .ParseFormats(new[] { "dd-MMM-yyyy", "dd/MMM/yyyy", "dd-MM-yyyy", "dd/MM/yyyy", "dd-MM-yy", "dd/MM/yy", "dd-MM", "dd/MM", "dd" });
        }

        public static DatePickerBuilder CustomDatePickerFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, DateTime?>> expression, object htmlAttributes = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);

            var attributes = new RouteValueDictionary(htmlAttributes);

            if (attributes.Any(t => t.Key == "data-val-date")) {
                attributes["data-val-date"] = string.Format("{0} is invalid.", metadata.Metadata.DisplayName);
            }
            else {
                attributes.Add("data-val-date", string.Format("{0} is invalid.", metadata.Metadata.DisplayName));
            }

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            return htmlHelper.Kendo().DatePickerFor(expression)
                .HtmlAttributes(attributes)
                .Culture(CultureInfo.CurrentCulture.Name)
                .Min(new DateTime(1900, 1, 1))
                .Format(Resource.ShortDatePattern)
                .ParseFormats(new[] { "dd-MMM-yyyy", "dd/MMM/yyyy", "dd-MM-yyyy", "dd/MM/yyyy", "dd-MM-yy", "dd/MM/yy", "dd-MM", "dd/MM", "dd" });
        }

        public static DateTimePickerBuilder CustomDateTimePicker<TModel>(this IHtmlHelper<TModel> htmlHelper, object htmlAttributes = null) {
            return htmlHelper.Kendo().DateTimePicker()
                .HtmlAttributes(htmlAttributes)
                .Culture(CultureInfo.CurrentCulture.Name)
                .Min(new DateTime(1900, 1, 1))
                .Format(string.Format("{0} {1}", Resource.ShortDatePattern, Resource.ShortTimePattern))
                .TimeFormat(Resource.ShortTimePattern)
                .ParseFormats(new[] { "dd-MMM-yyyy HH:mm", "dd/MMM/yyyy HH:mm", "dd-MM-yyyy HH:mm", "dd/MM/yyyy HH:mm", "dd-MM-yy HH:mm", "dd/MM/yy HH:mm", "dd-MM HH:mm", "dd/MM HH:mm", "dd HH:mm", "dd-MMM-yyyy", "dd/MMM/yyyy", "dd-MM-yyyy", "dd/MM/yyyy", "dd-MM-yy", "dd/MM/yy", "dd-MM", "dd/MM", "dd" });
        }

        public static DateRangePickerBuilder CustomDateRangePicker<TModel>(this IHtmlHelper<TModel> htmlHelper, object htmlAttributes = null) {
            return htmlHelper.Kendo().DateRangePicker()
                .HtmlAttributes(htmlAttributes)
                .Culture(CultureInfo.CurrentCulture.Name)
                .Min(new DateTime(1900, 1, 1))
                .Format(Resource.ShortDatePattern)
                .Labels(false);
        }

        public static DateTimePickerBuilder CustomDateTimePickerFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, DateTime>> expression, object htmlAttributes = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);

            var attributes = new RouteValueDictionary(htmlAttributes);

            if (attributes.Any(t => t.Key == "data-val-date")) {
                attributes["data-val-date"] = string.Format("{0} is invalid.", metadata.Metadata.DisplayName);
            }
            else {
                attributes.Add("data-val-date", string.Format("{0} is invalid.", metadata.Metadata.DisplayName));
            }

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            return htmlHelper.Kendo().DateTimePickerFor(expression)
                .HtmlAttributes(htmlAttributes)
                .Culture(CultureInfo.CurrentCulture.Name)
                .Min(new DateTime(1900, 1, 1))
                .Format(string.Format("{0} {1}", Resource.ShortDatePattern, Resource.ShortTimePattern))
                .TimeFormat(Resource.ShortTimePattern)
                .ParseFormats(new[] { "dd-MMM-yyyy", "dd/MMM/yyyy", "dd-MM-yyyy", "dd/MM/yyyy", "dd-MM-yy", "dd/MM/yy", "dd-MM", "dd/MM", "dd", "dd-MMM-yyyy HH:mm", "dd/MMM/yyyy HH:mm", "dd-MM-yyyy HH:mm", "dd/MM/yyyy HH:mm", "dd-MM-yy HH:mm", "dd/MM/yy HH:mm" });
        }

        public static DateTimePickerBuilder CustomDateTimePickerFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, DateTime?>> expression, object htmlAttributes = null, bool evaluateAttributes = true) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);

            var attributes = new RouteValueDictionary(htmlAttributes);

            if (attributes.Any(t => t.Key == "data-val-date")) {
                attributes["data-val-date"] = string.Format("{0} is invalid.", metadata.Metadata.DisplayName);
            }
            else {
                attributes.Add("data-val-date", string.Format("{0} is invalid.", metadata.Metadata.DisplayName));
            }

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            return htmlHelper.Kendo().DateTimePickerFor(expression)
                .HtmlAttributes(htmlAttributes)
                .Culture(CultureInfo.CurrentCulture.Name)
                .Min(new DateTime(1900, 1, 1))
                .Format(string.Format("{0} {1}", Resource.ShortDatePattern, Resource.ShortTimePattern))
                .TimeFormat(Resource.ShortTimePattern)
                .ParseFormats(new[] { "dd-MMM-yyyy", "dd/MMM/yyyy", "dd-MM-yyyy", "dd/MM/yyyy", "dd-MM-yy", "dd/MM/yy", "dd-MM", "dd/MM", "dd", "dd-MMM-yyyy HH:mm", "dd/MMM/yyyy HH:mm", "dd-MM-yyyy HH:mm", "dd/MM/yyyy HH:mm", "dd-MM-yy HH:mm", "dd/MM/yy HH:mm" });
        }

        public static EditorBuilder CustomEditor<TModel>(this IHtmlHelper<TModel> htmlHelper, object htmlAttributes = null, bool fullToolbar = false) {
            var helper = htmlHelper.Kendo().Editor().HtmlAttributes(htmlAttributes).Encoded(false);

            if (fullToolbar) {
                return helper.Tools(tools => tools
                    .Clear()
                    .Bold().Italic().Underline()
                    .ForeColor().BackColor()
                    .JustifyLeft().JustifyCenter().JustifyRight()
                    .InsertUnorderedList().InsertOrderedList()
                    .Indent().Outdent()
                    .CreateLink().Unlink()
                    .TableEditing()
                    .FontName().FontSize()
                );
            }

            return helper.Tools(tools => tools
                    .Clear()
                    .Bold().Italic().Underline()
                    .JustifyLeft().JustifyCenter().JustifyRight()
                    .InsertUnorderedList().InsertOrderedList()
                    .Indent().Outdent()
                    .CreateLink().Unlink()
                );
        }

        public static EditorBuilder CustomEditorFor<TModel>(this IHtmlHelper<TModel> htmlHelper, Expression<Func<TModel, string>> expression, object htmlAttributes = null, bool evaluateAttributes = true, bool fullToolbar = false) {
            var expressionProvider = new ModelExpressionProvider(htmlHelper.MetadataProvider);
            var metadata = expressionProvider.CreateModelExpression(htmlHelper.ViewData, expression);

            var attributes = new RouteValueDictionary(htmlAttributes);

            if (evaluateAttributes) {
                SetReadOnlyAttributes(metadata, attributes);
                htmlHelper.SetIsRequiredAttributes(metadata, attributes);
            }

            var helper = htmlHelper.Kendo().EditorFor(expression)
                .HtmlAttributes(attributes)
                .Encoded(false);

            if (fullToolbar) {
                return helper.Tools(tools => tools
                    .Clear()
                    .Bold().Italic().Underline()
                    .ForeColor().BackColor()
                    .JustifyLeft().JustifyCenter().JustifyRight()
                    .InsertUnorderedList().InsertOrderedList()
                    .Indent().Outdent()
                    .CreateLink().Unlink()
                    .TableEditing()
                    .FontName().FontSize()
                );
            }

            return helper.Tools(tools => tools
                    .Clear()
                    .Bold().Italic().Underline()
                    .JustifyLeft().JustifyCenter().JustifyRight()
                    .InsertUnorderedList().InsertOrderedList()
                    .Indent().Outdent()
                    .CreateLink().Unlink()
                );
        }

        public static WindowBuilder CustomWindow<TModel>(this IHtmlHelper<TModel> htmlHelper) {
            return htmlHelper.Kendo().Window()
                .Modal(true)
                .Draggable(false)
                .Resizable(resizable => resizable.Enabled(false))
                .Visible(false)
                .Animation(animation => {
                    animation.Open(open => {
                        open.Expand(ExpandDirection.Vertical);
                        open.Zoom(ZoomDirection.In);
                        open.Fade(FadeDirection.In);
                    });

                    animation.Close(close => {
                        close.Reverse(true);
                        close.Expand(ExpandDirection.Vertical);
                        close.Zoom(ZoomDirection.Out);
                        close.Reverse(false);
                        close.Fade(FadeDirection.In);
                    });
                });
        }

        public static DialogBuilder CustomDialog<TModel>(this IHtmlHelper<TModel> htmlHelper, string action, string title = "Delete Record", string message = "Delete this record?") {
            return htmlHelper.Kendo().Dialog()
                .Title(title)
                .Content(string.Format("<p>{0}</p>", message))
                .Width(300)
                .Closable(false)
                .Modal(true)
                .Visible(false)
                .Animation(animation => {
                    animation.Open(open => {
                        open.Fade(FadeDirection.In);
                        open.Duration(500);
                    });

                    animation.Close(close => {
                        close.Fade(FadeDirection.Out);
                        close.Duration(500);
                    });
                })
                .Actions(actions => {
                    actions.Add().Text("OK").Action(action);
                    actions.Add().Text("Cancel").Primary(true);
                });
        }

        public static GridBuilder<T> CustomGrid<T>(this IHtmlHelper htmlHelper, bool isSortable = false, bool isFilterable = false) where T : class {
            var widget = new GridBuilder<T>(new Grid<T>(htmlHelper.ViewContext))
                .Sortable(sortable => sortable.Enabled(isSortable))
                .Filterable(filterable => filterable.Extra(false).Messages(m => m.Info(string.Empty)).Operators(o => o.ForString(s => s.Clear().Contains("Contains"))).Enabled(isFilterable))
                .Pageable(pageable => pageable.Responsive(false).ButtonCount(15).Refresh(true))
                .NoRecords();

            if (isFilterable)
                widget.Events(events => events.FilterMenuInit("Global.GridHideFilterOperators"));

            return widget;
        }

        public static GridBuilder<T> CustomGrid<T>(this IHtmlHelper<dynamic> htmlHelper, bool isSortable = false, bool isFilterable = false) where T : class {
            var widget = htmlHelper.Kendo().Grid<T>()
                .Sortable(sortable => sortable.Enabled(isSortable))
                .Filterable(filterable => filterable.Extra(false).Messages(m => m.Info(string.Empty)).Operators(o => o.ForString(s => s.Clear().Contains("Contains"))).Enabled(isFilterable))
                .Pageable(pageable => pageable.Responsive(false).ButtonCount(15).Refresh(true))
                .NoRecords();

            if (isFilterable)
                widget.Events(events => events.FilterMenuInit("Global.GridHideFilterOperators"));

            return widget;
        }

        public static TooltipBuilder CustomGridInfoTooltip<TModel>(this IHtmlHelper<TModel> htmlHelper, string gridId, string filter = null, string content = null) {
            return htmlHelper.Kendo().Tooltip()
              .For(string.Format("#{0}", gridId))
              .Filter(filter ?? ".k-command-cell")
              .ContentHandler(content ?? string.Format(@"function (e) {{ return Global.GridGetTooltip(""{0}"", e); }}", gridId))
              .Position(TooltipPosition.Left)
              .AutoHide(true)
              .Events(events => events.Show(@"function(e) { if (this.content.text().length > 0) { this.content.parent().css(""visibility"", ""visible""); } else { this.content.parent().css(""visibility"", ""hidden""); }}").Hide(@"function(e) { this.content.parent().css(""visibility"", ""hidden""); }"));
        }

        public static ButtonBuilder CustomButton<TModel>(this IHtmlHelper<TModel> htmlHelper, string name, string content, string icon) {
            return htmlHelper.Kendo().Button()
              .Name(name)
              .HtmlAttributes(new { type = "button" })
              .Content(content)
              .Icon(icon);
        }

        public static ButtonBuilder CustomSmallButton<TModel>(this IHtmlHelper<TModel> htmlHelper, string name, string title, string icon) {
            return htmlHelper.Kendo().Button()
              .Name(name)
              .HtmlAttributes(new { type = "button", title, style = "min-width: unset !important; width: 100% !important; height: 22px !important" })
              .Icon(icon);
        }

        public static ButtonBuilder CustomSubmitButton<TModel>(this IHtmlHelper<TModel> htmlHelper, string name = "SubmitButton", string content = "Update") {
            return htmlHelper.Kendo().Button()
              .Name(name)
              .HtmlAttributes(new { type = "submit", @class = "k-primary" })
              .Content(content)
              .Icon("k-icon k-i-check");
        }

        public static ButtonBuilder CustomAddButton<TModel>(this IHtmlHelper<TModel> htmlHelper, string name = "AddButton", string content = "Add") {
            return htmlHelper.Kendo().Button()
              .Name(name)
              .HtmlAttributes(new { type = "button" })
              .Content(content)
              .Icon("k-icon k-i-plus");
        }

        public static ButtonBuilder CustomUpdateButton<TModel>(this IHtmlHelper<TModel> htmlHelper, string name = "UpdateButton", string content = "Update") {
            return htmlHelper.Kendo().Button()
              .Name(name)
              .HtmlAttributes(new { type = "button", @class = "k-primary" })
              .Content(content)
              .Icon("k-icon k-i-check");
        }

        public static ButtonBuilder CustomDeleteButton<TModel>(this IHtmlHelper<TModel> htmlHelper, string name = "DeleteButton", string content = "Delete") {
            return htmlHelper.Kendo().Button()
              .Name(name)
              .HtmlAttributes(new { type = "button" })
              .Content(content)
              .Icon("k-icon k-i-close");
        }

        public static ButtonBuilder CustomCancelButton<TModel>(this IHtmlHelper<TModel> htmlHelper, string name = "CancelButton", string content = "Cancel") {
            return htmlHelper.Kendo().Button()
              .Name(name)
              .HtmlAttributes(new { type = "button" })
              .Content(content)
              .Icon("k-icon k-i-cancel");
        }

        public static ButtonBuilder CustomReportButton<TModel>(this IHtmlHelper<TModel> htmlHelper, string name = "ReportButton", string content = "Print Preview") {
            return htmlHelper.Kendo().Button()
              .Name(name)
              .HtmlAttributes(new { type = "button" })
              .Content(content)
              .Icon("k-icon k-i-file");
        }

        private static bool SetIsRequiredAttributes(this IHtmlHelper htmlHelper, ModelExpression expression, IDictionary<string, object> attributes) {
            if (expression.Metadata.IsRequired) {
                if (expression.Metadata.IsReadOnly || attributes.Any(t => t.Key == "readonly") || attributes.Any(t => t.Key == "disabled"))
                    return false;

                string style = string.Format("background-color: {0}", htmlHelper.ViewContext.HttpContext.RequiredFieldBackgroundColor());

                if (attributes.Any(t => t.Key == "style")) {
                    var attribute = attributes.FirstOrDefault(t => t.Key == "style");
                    style = string.Format("{0};{1}", attribute.Value, style);
                    attributes.Remove("style");
                }

                attributes.Add("style", style);
            }

            return expression.Metadata.IsRequired;
        }

        private static bool SetReadOnlyAttributes(ModelExpression expression, IDictionary<string, object> attributes) {
            if (expression.Metadata.IsReadOnly) {
                if (!attributes.Any(t => t.Key == "readonly"))
                    attributes.Add("readonly", "readonly");

                if (!attributes.Any(t => t.Key == "disabled"))
                    attributes.Add("disabled", "disabled");
            }

            return expression.Metadata.IsReadOnly;
        }
    }
}