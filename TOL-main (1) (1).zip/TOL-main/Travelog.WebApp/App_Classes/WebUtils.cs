using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Kendo.Mvc;
using Kendo.Mvc.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Net.Http.Headers;
using Telerik.Windows.Documents.Common.FormatProviders;
using Telerik.Windows.Documents.Flow.FormatProviders.Docx;
using Telerik.Windows.Documents.Flow.FormatProviders.Html;
using Telerik.Windows.Documents.Flow.FormatProviders.Pdf;
using Telerik.Windows.Documents.Flow.FormatProviders.Rtf;
using Telerik.Windows.Documents.Flow.FormatProviders.Txt;
using Telerik.Windows.Documents.Flow.Model;
using Travelog.Biz;
using Travelog.Biz.Enums;
using ListSortDirection = Kendo.Mvc.ListSortDirection;

namespace Travelog.WebApp {
    public static class WebUtils {
        public static string GetModelStateErrors(ModelStateDictionary modelState) {
            string errors = null;

            if (modelState.Any(t => t.Value.Errors.Count > 0))
                errors = string.Join(" ", modelState.Where(t1 => t1.Value.Errors.Count > 0).Select(t1 => string.Join(" ", t1.Value.Errors.Select(t2 => t2.ErrorMessage))).Distinct()).Trim();

            return string.IsNullOrEmpty(errors) ? "There is a problem with the data. Please check all values." : errors;
        }

        public static string GetMessageScript(string message, Exception ex, int timeoutSeconds = 30) {
            var messageType = MessageType.Error;

            if (ex is CrsException || ex is EwayException || ex is ReportedException || ex is UnreportedException || ExceptionManagerBiz.Instance.IsSqlDuplicateException(ex) || ExceptionManagerBiz.Instance.IsSqlDuplicateAirPassengerException(ex) || ExceptionManagerBiz.Instance.IsSqlReferenceConstraintConflict(ex) || ExceptionManagerBiz.Instance.IsSqlRequestLimitReachedException(ex) || ExceptionManagerBiz.Instance.IsConnectionStringException(ex) || ExceptionManagerBiz.Instance.IsSqlArchiveDatabaseNotAvailable(ex))
                messageType = MessageType.Warning;

            return GetMessageScript(message, messageType, timeoutSeconds);
        }

        public static string GetMessageScript(string message, MessageType messageType = MessageType.Error, int timeoutSeconds = 30) {
            return string.Format(@"Global.DisplayMessage(""{0}"", ""{1}"", ""{2}"", ""[PlaceholderId]"");", message.Replace("\"", "&quot;").Replace(Environment.NewLine, " "), messageType.ToString().ToLower(), timeoutSeconds);
        }

        public static string GetBaseUrl(HttpContext httpContext) {
            string url;

            if (httpContext.Request.Method == "POST") {
                url = httpContext.Request.Headers[HeaderNames.Referer].ToString().TrimStart(string.Format("{0}://{1}", httpContext.Request.Scheme, httpContext.Request.Host));
            }
            else {
                url = httpContext.Request.GetEncodedPathAndQuery();
            }

            return url == "/" ? "/" : url.TrimEnd('/');
        }

        public static bool IsAjaxRequest(HttpRequest request) {
            return string.Equals(request.Query[HeaderNames.XRequestedWith], "XMLHttpRequest", StringComparison.Ordinal) ||
                string.Equals(request.Headers[HeaderNames.XRequestedWith], "XMLHttpRequest", StringComparison.Ordinal) ||
                string.Equals(request.Headers[HeaderNames.XRequestedWith], "Fetch", StringComparison.Ordinal);
        }

        public static IList<IFilterDescriptor> GetFilterDescriptors(string member) {
            IList<IFilterDescriptor> filterDescriptors = null;

            if (!string.IsNullOrEmpty(member)) {
                filterDescriptors = new List<IFilterDescriptor> {
                    new FilterDescriptor {
                        Member = member
                    }
                };
            }

            return filterDescriptors;
        }

        public static List<SortDescriptor> GetSortDescriptors(string member, string sortDirection) {
            List<SortDescriptor> sortDescriptors = null;

            if (!string.IsNullOrEmpty(member)) {
                sortDescriptors = new List<SortDescriptor> {
                    new SortDescriptor {
                        Member = member,
                        SortDirection = sortDirection == "asc" ? ListSortDirection.Ascending : ListSortDirection.Descending
                    }
                };
            }

            return sortDescriptors;
        }

        public static string GetAmadeusFilePath(HttpContext httpContext, string contentRootPath) {
            return Path.Combine(contentRootPath, AppSettings.AmadeusDataFilePath, httpContext.CustomerSettings().DbName);
        }

        public static byte[] ConvertToPdf(IFormFile file) {
            if (file == null)
                return null;

            string fileExtension = Path.GetExtension(file.FileName);

            if (!Regex.IsMatch(fileExtension, ".docx|.rtf|.html|.txt"))
                throw new InvalidOperationException("File type cannot be converted to PDF.");

            IFormatProvider<RadFlowDocument> documentProvider = null;
            RadFlowDocument document = null;

            switch (fileExtension) {
                case ".docx":
                    documentProvider = new DocxFormatProvider();
                    break;
                case ".rtf":
                    documentProvider = new RtfFormatProvider();
                    break;
                case ".html":
                    documentProvider = new HtmlFormatProvider();
                    break;
                case ".txt":
                    documentProvider = new TxtFormatProvider();
                    break;
            }

            using (var ms = new MemoryStream()) {
                file.CopyTo(ms);
                document = documentProvider.Import(ms);
            }

            var pdfProvider = new PdfFormatProvider();
            return pdfProvider.Export(document);
        }
    }
}