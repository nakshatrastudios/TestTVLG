﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Travelog.Biz;
using Travelog.Biz.Enums;
using Travelog.Biz.Resources;

namespace Travelog.WebApp.Models {
	public class ReceiptViewModel {
		public int ReceiptViewId { get; set; }
		public int ReceiptId { get; set; }
		public int ReceiptAgencyId { get; set; }
		public int ReceiptProfileId { get; set; }
		public string ReceiptAccountName { get; set; }
		public DocumentStatus ReceiptDocumentStatus { get; set; }
		public ReversalStatus ReceiptReversalStatus { get; set; }
		public AccountType ReceiptAccountType { get; set; }
		public string ReceiptFormOfPayment { get; set; }
		public string ReceiptNewDocumentNo { get; set; }
		public string ReceiptEmail { get; set; }
        public string ReceiptAgencyEmail { get; set; }
        public bool ReceiptIsDeposit { get; set; }
		public bool ReceiptIsIssued { get; set; }
		public bool ReceiptIsTaxApplicable { get; set; }
		public bool ReceiptIsClientAccountLocked { get; set; }
		public bool ReceiptCanEdit { get; set; }
		public bool ReceiptCanDelete { get; set; }
		public bool ReceiptCanUndo { get; set; }
		public bool ReceiptCanReverse { get; set; }
		public string ReceiptEditText {
			get {
				return ReceiptCanEdit ? "Edit" : "View";
			}
		}
		public string ReceiptDeleteText {
			get {
				return ReceiptCanDelete ? "Delete" : ReceiptCanUndo ? "Undo" : ReceiptCanReverse ? "Reverse" : "None";
			}
		}
		public string ReceiptCreateOption { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string ReceiptDocumentDateString { get { return ReceiptDocumentDate == null ? string.Empty : ((DateTime)ReceiptDocumentDate).Date.ToShortDateStringExt(); } }
		public string ReceiptDocumentStatusDescription { get { return string.Concat(ReceiptDocumentStatus == DocumentStatus.DepositedPaid ? "Deposited" : ReceiptDocumentStatus.GetEnumDescription(), ReceiptIsIssued ? "/Issued" : string.Empty); } }
		public string ReceiptReversalStatusDescription { get { return ReceiptReversalStatus.GetEnumDescription(); } }
		[Display(Name = "Status")]
		public string ReceiptCombinedStatusDescription { get { return string.Concat(ReceiptDocumentStatusDescription, ReceiptReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", ReceiptReversalStatusDescription)); } }
		public string ReceiptAccountTypeDescription { get { return ReceiptAccountType == AccountType.None ? "Bank Deposit" : ReceiptAccountType.GetEnumDescription(); } }
		public string ReceiptEffectiveAccountTypeDescription { get { return ReceiptEffectiveAccountType == AccountType.None ? "Bank Deposit" : ReceiptEffectiveAccountType.GetEnumDescription(); } }
		public string ReceiptTypeDescription { get { return ReceiptType.GetEnumDescription(); } }

		public string ReceiptAccountNameLink { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Account Type")]
		public AccountType ReceiptEffectiveAccountType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document Type")]
		public ReceiptType ReceiptType { get; set; }

		[Editable(false)]
		[Display(Name = "Document No")]
		public string ReceiptDocumentNo { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Date")]
		public DateTime? ReceiptDocumentDate { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Payer")]
		public string ReceiptPayer { get; set; }

		[Display(Name = "Trip")]
		public int? ReceiptTripId { get; set; }

		[Display(Name = "Debtor")]
		public int? ReceiptDebtorId { get; set; }

		[Display(Name = "Creditor")]
		public int? ReceiptCreditorId { get; set; }

		[Display(Name = "GL Account")]
		public int? ReceiptChartOfAccountId { get; set; }

		[Display(Name = "Supplier")]
		public int? ReceiptSupplierId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "From Account")]
		public int? ReceiptBankAccountFromId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Bank Account")]
		public int? ReceiptBankAccountToId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Update Non-BSP")]
		public SupplierCommissionType ReceiptSupplierCommissionType { get; set; }

		[Display(Name = "Type of Sale")]
		public int? ReceiptSaleTypeId { get; set; }

		[Display(Name = "Category")]
		public int? ReceiptCategoryId { get; set; }

		[Display(Name = "Consultant")]
		public int? ReceiptConsultantId { get; set; }

		[Display(Name = "Source")]
		public int? ReceiptSourceId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission")]
		public decimal ReceiptCommission { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission Rate")]
		public decimal ReceiptCommissionRate { get; set; }

		[Editable(false)]
		[Display(Name = "CommissionTaxLabel", ResourceType = typeof(Resource))]
		public decimal ReceiptCommissionTax { get; set; }

		[Editable(false)]
		[Display(Name = "CommissionTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal ReceiptCommissionTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Taxes/Non-Comm")]
		public decimal ReceiptNonCommissionable { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier Cancel Fee")]
		public decimal ReceiptSupplierCancellationFee { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount")]
		public decimal ReceiptDiscount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Rate")]
		public decimal ReceiptDiscountRate { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxLabel", ResourceType = typeof(Resource))]
		public decimal ReceiptDiscountTax { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal ReceiptDiscountTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Reason")]
		public int? ReceiptDiscountReasonId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Cancellation Fee")]
		public decimal ReceiptCancellationFee { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Cancel Type of Sale")]
		public int? ReceiptCancellationSaleTypeId { get; set; }

		[Editable(false)]
		[Display(Name = "Amount to Bank")]
		public decimal ReceiptAmountToBank { get; set; }

		[Display(Name = "Split Receipt")]
		public bool ReceiptIsSplit { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Standard Comment")]
		public int? ReceiptStandardCommentId { get; set; }

		[Display(Name = "Comment")]
		public string ReceiptStandardComment { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Original Sale Total")]
		public decimal ReceiptOriginalSaleTotal { get; set; }

		[Editable(false)]
		[Display(Name = "Points Collected")]
		public decimal ReceiptTotalLoyaltySchemePointsCollected { get; set; }

		[Editable(false)]
		[Display(Name = "Points Cost")]
		public decimal ReceiptTotalLoyaltySchemePointsCost { get; set; }

		[Editable(false)]
		[Display(Name = "Loyalty Value")]
		public decimal ReceiptTotalLoyaltySchemeValue { get; set; }

		[Editable(false)]
		[Display(Name = "LoyaltySchemeTaxAppliesLabel", ResourceType = typeof(Resource))]
		public bool ReceiptTotalLoyaltySchemeIsTaxApplicable { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Total Amount")]
		public decimal ReceiptTotalAmount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Total Merchant Fee")]
		public decimal ReceiptTotalMerchantFee { get; set; }

		[Editable(false)]
		[Display(Name = "Total Net Amount")]
		public decimal ReceiptTotalAmountNet { get; set; }

		[Editable(false)]
		[Display(Name = "TaxTotalLabel", ResourceType = typeof(Resource))]
		public decimal ReceiptTotalTax { get; set; }

		[Editable(false)]
		[Display(Name = "TaxRateLabel", ResourceType = typeof(Resource))]
		public decimal ReceiptTotalTaxRate { get; set; }

		[Editable(false)]
		[Display(Name = "Document Total")]
		public decimal ReceiptDocumentTotal { get; set; }

		[Display(Name = "IsTaxIncludedLabel", ResourceType = typeof(Resource))]
		public bool ReceiptIsTaxIncluded { get; set; }

		[Editable(false)]
		[Display(Name = "Deposit Date")]
		public DateTime? ReceiptDepositDate { get; set; }

		[Editable(false)]
		[Display(Name = "Bank Statement")]
		public string ReceiptBankAccountStatementName { get; set; }
	}

	public class ReceiptDetailViewModel {
		public int ReceiptDetailId { get; set; }
		public int ReceiptId { get; set; }
		public TripLineType ReceiptDetailTripLineType { get; set; }
		public DocumentStatus ReceiptDetailDocumentStatus { get; set; }
		public ReversalStatus ReceiptDetailReversalStatus { get; set; }
		public string ReceiptDetailDocumentNo { get; set; }
		public string ReceiptDetailAccountNameLink { get; set; }
		public string ReceiptDetailPassenger { get; set; }
		public string ReceiptDetailVoucherNo { get; set; }
		public string ReceiptDetailFormOfPayment { get; set; }
		public string ReceiptDetailPaymentMethod { get; set; }
		public DateTime? ReceiptDetailDepositDate { get; set; }
		public string ReceiptDetailBankAccountStatementName { get; set; }
		public bool ReceiptDetailIsCreditCardDebtor { get; set; }
		public bool ReceiptDetailCanEdit { get; set; }
		public bool ReceiptDetailCanDelete { get; set; }
		public bool ReceiptDetailCanUndo { get; set; }
		public bool ReceiptDetailCanReverse { get; set; }
		public string ReceiptDetailEditText {
			get {
				return ReceiptDetailCanEdit ? "Edit" : "View";
			}
		}
		public string ReceiptDetailDeleteText {
			get {
				return ReceiptDetailCanDelete ? "Delete" : ReceiptDetailCanUndo ? "Undo" : ReceiptDetailCanReverse ? "Reverse" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string ReceiptDetailDepositDateString { get { return ReceiptDetailDepositDate == null ? string.Empty : string.Format("{0:g}", (DateTime)ReceiptDetailDepositDate); } }
		public string ReceiptDetailDocumentStatusDescription { get { return ReceiptDetailDocumentStatus == DocumentStatus.DepositedPaid ? "Deposited" : ReceiptDetailDocumentStatus.GetEnumDescription(); } }
		public string ReceiptDetailReversalStatusDescription { get { return ReceiptDetailReversalStatus.GetEnumDescription(); } }
		public string ReceiptDetailCombinedStatusDescription { get { return string.Concat(ReceiptDetailDocumentStatusDescription, ReceiptDetailReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", ReceiptDetailReversalStatusDescription)); } }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip Line")]
		public int? ReceiptDetailTripLineId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Air Passenger")]
		public int? ReceiptDetailTripLineAirPassengerId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Passenger")]
		public int? ReceiptDetailPassengerId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Form of Payment")]
		public int? ReceiptDetailFormOfPaymentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Payment Method")]
		public int? ReceiptDetailPaymentMethodId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Loyalty Scheme")]
		public int? ReceiptDetailLoyaltySchemeId { get; set; }

		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Reference")]
		public string ReceiptDetailLoyaltySchemeReference { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Points Collected")]
		public decimal ReceiptDetailLoyaltySchemePointsCollected { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Points Cost")]
		public decimal ReceiptDetailLoyaltySchemePointsCost { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Loyalty Value")]
		public decimal ReceiptDetailLoyaltySchemeValue { get; set; }

		[Display(Name = "Points Only")]
		public bool ReceiptDetailLoyaltySchemeIsPointsOnly { get; set; }

		[Editable(false)]
		[Display(Name = "LoyaltySchemeTaxAppliesLabel", ResourceType = typeof(Resource))]
		public bool ReceiptDetailLoyaltySchemeIsTaxApplicable { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal ReceiptDetailAmount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "TaxLabel", ResourceType = typeof(Resource))]
		public decimal ReceiptDetailTax { get; set; }

		[Editable(false)]
		[Display(Name = "TaxRateLabel", ResourceType = typeof(Resource))]
		public decimal ReceiptDetailTaxRate { get; set; }

		[Display(Name = "TaxAppliesLabel", ResourceType = typeof(Resource))]
		public bool ReceiptDetailIsTaxApplicable { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Voucher No")]
		public int? ReceiptDetailVoucherId { get; set; }

		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Class")]
		public string ReceiptDetailClass { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Days Away")]
		public int ReceiptDetailDaysAway { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Ticketed Fare")]
		public decimal ReceiptDetailTicketedFare { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Offered Fare")]
		public decimal ReceiptDetailOfferedFare { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Reason Rejected")]
		public int? ReceiptDetailOfferedReasonId { get; set; }

		[Display(Name = "Partially Paid")]
		public bool ReceiptDetailVoucherIsPartiallyReceipted { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Comments")]
		public string ReceiptDetailComments { get; set; }
	}

	public class ReceiptVoucherCommissionViewModel {
		public int VoucherId { get; set; }
		public int TripId { get; set; }
		public string TripNo { get; set; }
		public int CreditorId { get; set; }
		public int SupplierId { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public DateTime DepartureDate { get; set; }
		public string Supplier { get; set; }
		public decimal OriginalAmount { get { return Amount; } }
		public string DocumentDateString { get { return DocumentDate.ToShortDateStringExt(); } }
		public string DepartureDateString { get { return DepartureDate.ToShortDateStringExt(); } }

		[Required(ErrorMessage = "{0} is required.")]
		public int? SaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		public int? CategoryId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		public int? ConsultantId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		public int? SourceId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		public decimal Amount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		public bool IsFullyPaid { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		public decimal TicketedFare { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		public decimal OfferedFare { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		public int? OfferedReasonId { get; set; }

		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		public string Class { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		public int DaysAway { get; set; }
	}

	public class ReceiptAddViewModel {
		public int ReceiptAddId { get; set; }
		public int ReceiptAddTripLineId { get; set; }
		public int ReceiptAddTripLineAirPassengerId { get; set; }

		public TripLineType ReceiptAddTripLineType { get; set; }
		public string ReceiptAddDescription { get; set; }
		public decimal ReceiptAddAmountOriginal { get; set; }
		public bool ReceiptAddIsTaxApplicable { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Date")]
		public DateTime? ReceiptAddDocumentDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Passenger")]
		public int ReceiptAddPassengerId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Form of Payment")]
		public int? ReceiptAddFormOfPaymentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Payment Method")]
		public int ReceiptAddPaymentMethodId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal ReceiptAddAmount { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Comments")]
		public string ReceiptAddComments { get; set; }
	}

	public class BspViewModel {
		public int[] BspIds { get; set; }
		public int BspId { get; set; }
		public TripLineType BspTripLineType { get; set; }
		public DocumentStatus BspDocumentStatus { get; set; }
		public ReversalStatus BspReversalStatus { get; set; }
		public int BspAgencyId { get; set; }
		public string BspDocumentType { get; set; }
		public string BspAccountName { get; set; }
		public string BspCreditor { get; set; }
		public string BspSupplier { get; set; }
		public string BspSaleType { get; set; }
		public string BspFormOfPayment { get; set; }
		public decimal BspTotalCash { get; set; }
		public decimal BspTotalCashNonCommissionable { get; set; }
		public decimal BspTotalCreditCard { get; set; }
		public decimal BspTotalCreditCardNonCommissionable { get; set; }
		public string BspPaymentDocumentNo { get; set; }
		public DateTime BspReturnDate { get; set; }
		public bool BspIsCommissionPermitted { get; set; }
		public bool BspIsDiscountPermitted { get; set; }
		public bool BspIsMarkupPermitted { get; set; }
		public bool BspIsCancellationPermitted { get; set; }
		public bool BspIsTaxApplicable { get; set; }
		public bool BspHasChildren { get; set; }
		public int BspChildCount { get; set; }
		public bool BspIsClientAccountLocked { get; set; }
		public bool BspCanEdit { get; set; }
		public bool BspCanDelete { get; set; }
		public bool BspCanUndo { get; set; }
		public bool BspCanReverse { get; set; }
		public string BspEditText {
			get {
				return BspCanEdit ? "Edit" : "View";
			}
		}
		public string BspDeleteText {
			get {
				return BspCanDelete ? "Delete" : BspCanUndo ? "Undo" : BspCanReverse ? "Reverse" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string BspDocumentDateString { get { return BspDocumentDate == null ? string.Empty : ((DateTime)BspDocumentDate).ToShortDateStringExt(); } }
		public string BspDepartureDateString { get { return BspDepartureDate == null ? string.Empty : ((DateTime)BspDepartureDate).ToShortDateStringExt(); } }
		public string BspDocumentStatusDescription { get { return BspDocumentStatus == DocumentStatus.DepositedPaid ? "Paid" : BspDocumentStatus.GetEnumDescription(); } }
		public string BspReversalStatusDescription { get { return BspReversalStatus.GetEnumDescription(); } }
		[Display(Name = "Status")]
		public string BspCombinedStatusDescription { get { return string.Concat(BspDocumentStatusDescription, BspReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", BspReversalStatusDescription)); } }
		public string BspTypeDescription { get { return BspType.GetEnumDescription(); } }
		public string BspAccountNameLink { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document Type")]
		public BspType BspType { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document No")]
		public string BspDocumentNo { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document Date")]
		public DateTime? BspDocumentDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Purchase From")]
		public int? BspCreditorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier")]
		public int? BspSupplierId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip")]
		public int? BspTripId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip Line")]
		public int? BspTripLineId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Airline")]
		public int? BspAirlineId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Departure Status")]
		public DepartureDateStatus BspDepartureDateStatus { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Departure Date")]
		public DateTime? BspDepartureDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Offered Fare")]
		public decimal BspOfferedFare { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Reason Rejected")]
		public int? BspOfferedReasonId { get; set; }

		[Display(Name = "Type of Sale")]
		public int? BspSaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Category")]
		public int? BspCategoryId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Destination")]
		public int? BspDestinationId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Consultant")]
		public int? BspConsultantId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Agent")]
		public int? BspAgentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Source")]
		public int? BspSourceId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier Cancel Fee")]
		public decimal BspSupplierCancellationFee { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission")]
		public decimal BspCommission { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission Rate")]
		public decimal BspCommissionRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "CommissionTaxLabel", ResourceType = typeof(Resource))]
		public decimal BspCommissionTax { get; set; }

		[Editable(false)]
		[Display(Name = "CommissionTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal BspCommissionTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount")]
		public decimal BspDiscount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Rate")]
		public decimal BspDiscountRate { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxLabel", ResourceType = typeof(Resource))]
		public decimal BspDiscountTax { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal BspDiscountTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Reason")]
		public int? BspDiscountReasonId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Mark-Up")]
		public decimal BspMarkup { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Mark-Up Rate")]
		public decimal BspMarkupRate { get; set; }

		[Editable(false)]
		[Display(Name = "MarkupTaxLabel", ResourceType = typeof(Resource))]
		public decimal BspMarkupTax { get; set; }

		[Editable(false)]
		[Display(Name = "MarkupTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal BspMarkupTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Mark-Up Strategy")]
		public int? BspMarkupStrategyId { get; set; }

		[Display(Name = "Auto-Invoice")]
		public bool BspIsAutoInvoiced { get; set; }

		[Editable(false)]
		[Display(Name = "Total Amount")]
		public decimal BspTotalAmount { get; set; }

		[Editable(false)]
		[Display(Name = "TaxTotalLabel", ResourceType = typeof(Resource))]
		public decimal BspTotalTax { get; set; }

		[Editable(false)]
		[Display(Name = "TaxRateLabel", ResourceType = typeof(Resource))]
		public decimal BspTotalTaxRate { get; set; }

		[Editable(false)]
		[Display(Name = "Total Non-Comm")]
		public decimal BspTotalNonCommissionable { get; set; }

		[Editable(false)]
		[Display(Name = "Amount Payable")]
		public decimal BspAmountPayable { get; set; }

		[Display(Name = "IsTaxIncludedLabel", ResourceType = typeof(Resource))]
		public bool BspIsTaxIncluded { get; set; }

		[Display(Name = "Credit Card Discount Applies")]
		public bool BspIsCreditCardDiscountApplicable { get; set; }

		[Display(Name = "Include Mark-Up in Credit Card Payment")]
		public bool BspIncludeMarkupInCreditCardPayment { get; set; }

		[Editable(false)]
		[Display(Name = "Payment")]
		public string BspPaymentLink { get; set; }

		[Editable(false)]
		[Display(Name = "Payment Date")]
		public DateTime? BspPaymentDate { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string BspComments { get; set; }
    }

    public class BspDetailViewModel {
		public int BspDetailId { get; set; }
		public int BspId { get; set; }
		public DocumentStatus BspDetailDocumentStatus { get; set; }
		public ReversalStatus BspDetailReversalStatus { get; set; }
		public string BspDetailPassenger { get; set; }
		public string BspDetailFormOfPayment { get; set; }
		public string BspDetailPaymentLink { get; set; }
		public DateTime? BspDetailPaymentDate { get; set; }
		public bool BspDetailIsBspAgent { get; set; }
		public bool BspDetailCanEdit { get; set; }
		public bool BspDetailCanDelete { get; set; }
		public bool BspDetailCanUndo { get; set; }
		public bool BspDetailCanReverse { get; set; }
		public string BspDetailEditText {
			get {
				return BspDetailCanEdit ? "Edit" : "View";
			}
		}
		public string BspDetailDeleteText {
			get {
				return BspDetailCanDelete ? "Delete" : BspDetailCanUndo ? "Undo" : BspDetailCanReverse ? "Reverse" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string BspDetailDocumentStatusDescription { get { return BspDetailDocumentStatus == DocumentStatus.DepositedPaid ? "Paid" : BspDetailDocumentStatus.GetEnumDescription(); } }
		public string BspDetailReversalStatusDescription { get { return BspDetailReversalStatus.GetEnumDescription(); } }
		public string BspDetailCombinedStatusDescription { get { return string.Concat(BspDetailDocumentStatusDescription, BspDetailReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", BspDetailReversalStatusDescription)); } }
		public string BspDetailPaymentDateString { get { return BspDetailPaymentDate == null ? string.Empty : ((DateTime)BspDetailPaymentDate).ToShortDateStringExt(); } }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Air Passenger")]
		public int? BspDetailTripLineAirPassengerId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Passenger")]
		public int? BspDetailPassengerId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Form of Payment")]
		public int? BspDetailFormOfPaymentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal BspDetailAmount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "TaxLabel", ResourceType = typeof(Resource))]
		public decimal BspDetailTax { get; set; }

		[Editable(false)]
		[Display(Name = "TaxRateLabel", ResourceType = typeof(Resource))]
		public decimal BspDetailTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Taxes/Non-Comm")]
		public decimal BspDetailNonCommissionable { get; set; }
	}

	public class NonBspViewModel {
		public int[] NonBspIds { get; set; }
		public int NonBspId { get; set; }
		public TripLineType NonBspTripLineType { get; set; }
		public DocumentStatus NonBspDocumentStatus { get; set; }
		public ReversalStatus NonBspReversalStatus { get; set; }
		public int AgencyCreditCardBspId { get; set; }
		public int AgencyCreditCardNonBspId { get; set; }
		public int NonBspAgencyId { get; set; }
		public string NonBspAccountName { get; set; }
		public string NonBspCreditor { get; set; }
		public string NonBspSupplier { get; set; }
		public string NonBspSaleType { get; set; }
		public string NonBspFormOfPayment { get; set; }
		public decimal NonBspTotalCash { get; set; }
		public decimal NonBspTotalCashNonCommissionable { get; set; }
		public decimal NonBspTotalCreditCard { get; set; }
		public decimal NonBspTotalCreditCardNonCommissionable { get; set; }
		public string NonBspPaymentDocumentNo { get; set; }
		public DateTime NonBspPaymentDate { get; set; }
		public DateTime NonBspReturnDate { get; set; }
		public bool NonBspIsCommissionPermitted { get; set; }
		public bool NonBspIsDiscountPermitted { get; set; }
		public bool NonBspIsMarkupPermitted { get; set; }
		public bool NonBspIsCancellationPermitted { get; set; }
		public bool NonBspIsTaxApplicable { get; set; }
		public bool NonBspHasChildren { get; set; }
		public int NonBspChildCount { get; set; }
		public bool NonBspIsClientAccountLocked { get; set; }
		public bool NonBspCanEdit { get; set; }
		public bool NonBspCanDelete { get; set; }
		public bool NonBspCanUndo { get; set; }
		public bool NonBspCanReverse { get; set; }
		public string NonBspEditText {
			get {
				return NonBspCanEdit ? "Edit" : "View";
			}
		}
		public string NonBspDeleteText {
			get {
				return NonBspCanDelete ? "Delete" : NonBspCanUndo ? "Undo" : NonBspCanReverse ? "Reverse" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string NonBspDocumentDateString { get { return NonBspDocumentDate == null ? string.Empty : ((DateTime)NonBspDocumentDate).ToShortDateStringExt(); } }
		public string NonBspDocumentStatusDescription { get { return NonBspDocumentStatus == DocumentStatus.DepositedPaid ? "Paid" : NonBspDocumentStatus.GetEnumDescription(); } }
		public string NonBspReversalStatusDescription { get { return NonBspReversalStatus.GetEnumDescription(); } }
		public string NonBspCombinedStatusDescription { get { return string.Concat(NonBspDocumentStatusDescription, NonBspReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", NonBspReversalStatusDescription)); } }
		public string NonBspTypeDescription { get { return string.Concat(NonBspType.GetEnumDescription(), AgencyCreditCardBspId > 0 ? " [BSP]" : AgencyCreditCardNonBspId > 0 ? " [Non-BSP]" : string.Empty); } }
		public string NonBspAccountNameLink { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document Type")]
		public NonBspType NonBspType { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document No")]
		public string NonBspDocumentNo { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document Date")]
		public DateTime? NonBspDocumentDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Purchase From")]
		public int? NonBspCreditorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier")]
		public int? NonBspSupplierId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip")]
		public int? NonBspTripId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip Line")]
		public int? NonBspTripLineId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "GL Account")]
		public int? NonBspChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Airline")]
		public int? NonBspAirlineId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Departure Status")]
		public DepartureDateStatus NonBspDepartureDateStatus { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Departure Date")]
		public DateTime? NonBspDepartureDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Offered Fare")]
		public decimal NonBspOfferedFare { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Reason Rejected")]
		public int? NonBspOfferedReasonId { get; set; }

		[Display(Name = "Type of Sale")]
		public int? NonBspSaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Category")]
		public int? NonBspCategoryId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Destination")]
		public int? NonBspDestinationId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Consultant")]
		public int? NonBspConsultantId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Agent")]
		public int? NonBspAgentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Source")]
		public int? NonBspSourceId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier Cancel Fee")]
		public decimal NonBspSupplierCancellationFee { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission")]
		public decimal NonBspCommission { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission Rate")]
		public decimal NonBspCommissionRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "CommissionTaxLabel", ResourceType = typeof(Resource))]
		public decimal NonBspCommissionTax { get; set; }

		[Editable(false)]
		[Display(Name = "CommissionTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal NonBspCommissionTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount")]
		public decimal NonBspDiscount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Rate")]
		public decimal NonBspDiscountRate { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxLabel", ResourceType = typeof(Resource))]
		public decimal NonBspDiscountTax { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal NonBspDiscountTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Reason")]
		public int? NonBspDiscountReasonId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Mark-Up")]
		public decimal NonBspMarkup { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Mark-Up Rate")]
		public decimal NonBspMarkupRate { get; set; }

		[Editable(false)]
		[Display(Name = "MarkupTaxLabel", ResourceType = typeof(Resource))]
		public decimal NonBspMarkupTax { get; set; }

		[Editable(false)]
		[Display(Name = "MarkupTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal NonBspMarkupTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Mark-Up Strategy")]
		public int? NonBspMarkupStrategyId { get; set; }

		[Display(Name = "Auto-Invoice")]
		public bool NonBspIsAutoInvoiced { get; set; }

		[Editable(false)]
		[Display(Name = "Total Amount")]
		public decimal NonBspTotalAmount { get; set; }

		[Editable(false)]
		[Display(Name = "TaxTotalLabel", ResourceType = typeof(Resource))]
		public decimal NonBspTotalTax { get; set; }

		[Editable(false)]
		[Display(Name = "TaxRateLabel", ResourceType = typeof(Resource))]
		public decimal NonBspTotalTaxRate { get; set; }

		[Editable(false)]
		[Display(Name = "Total Non-Comm")]
		public decimal NonBspTotalNonCommissionable { get; set; }

		[Editable(false)]
		[Display(Name = "Amount Payable")]
		public decimal NonBspAmountPayable { get; set; }

		[Display(Name = "Credit Card Discount Applies")]
		public bool NonBspIsCreditCardDiscountApplicable { get; set; }

		[Display(Name = "Include Mark-Up in Credit Card Payment")]
		public bool NonBspIncludeMarkupInCreditCardPayment { get; set; }

		[Display(Name = "IsTaxIncludedLabel", ResourceType = typeof(Resource))]
		public bool NonBspIsTaxIncluded { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string NonBspComments { get; set; }
    }

    public class NonBspDetailViewModel {
		public int NonBspDetailId { get; set; }
		public int NonBspId { get; set; }
		public DocumentStatus NonBspDetailDocumentStatus { get; set; }
		public ReversalStatus NonBspDetailReversalStatus { get; set; }
		public NonBspType NonBspDetailNonBspType { get; set; }
		public string NonBspDetailPassenger { get; set; }
		public string NonBspDetailFormOfPayment { get; set; }
		public string NonBspDetailPaymentLink { get; set; }
		public DateTime? NonBspDetailPaymentDate { get; set; }
		public bool NonBspDetailIsBspAgent { get; set; }
		public bool NonBspDetailCanEdit { get; set; }
		public bool NonBspDetailCanDelete { get; set; }
		public bool NonBspDetailCanUndo { get; set; }
		public bool NonBspDetailCanReverse { get; set; }
		public string NonBspDetailEditText {
			get {
				return NonBspDetailCanEdit ? "Edit" : "View";
			}
		}
		public string NonBspDetailDeleteText {
			get {
				return NonBspDetailCanDelete ? "Delete" : NonBspDetailCanUndo ? "Undo" : NonBspDetailCanReverse ? "Reverse" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string NonBspDetailDocumentStatusDescription { get { return NonBspDetailDocumentStatus == DocumentStatus.DepositedPaid ? "Paid" : NonBspDetailDocumentStatus.GetEnumDescription(); } }
		public string NonBspDetailReversalStatusDescription { get { return NonBspDetailReversalStatus.GetEnumDescription(); } }
		public string NonBspDetailCombinedStatusDescription { get { return string.Concat(NonBspDetailDocumentStatusDescription, NonBspDetailReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", NonBspDetailReversalStatusDescription)); } }
		public string NonBspDetailPaymentDateString { get { return NonBspDetailPaymentDate == null ? string.Empty : ((DateTime)NonBspDetailPaymentDate).ToShortDateStringExt(); } }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Air Passenger")]
		public int? NonBspDetailTripLineAirPassengerId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Passenger")]
		public int? NonBspDetailPassengerId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Form of Payment")]
		public int? NonBspDetailFormOfPaymentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal NonBspDetailAmount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "TaxLabel", ResourceType = typeof(Resource))]
		public decimal NonBspDetailTax { get; set; }

		[Editable(false)]
		[Display(Name = "TaxRateLabel", ResourceType = typeof(Resource))]
		public decimal NonBspDetailTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Taxes/Non-Comm")]
		public decimal NonBspDetailNonCommissionable { get; set; }

		[Display(Name = "TaxAppliesLabel", ResourceType = typeof(Resource))]
		public bool NonBspDetailIsTaxApplicable { get; set; }
	}

	public class PaymentViewModel {
		public int PaymentId { get; set; }
		public DocumentStatus PaymentDocumentStatus { get; set; }
		public ReversalStatus PaymentReversalStatus { get; set; }
		public int PaymentAgencyId { get; set; }
		public string PaymentAccountName { get; set; }
		public string PaymentSaleType { get; set; }
		public bool PaymentIsDebtor { get; set; }
		public decimal PaymentTotalCash { get; set; }
		public decimal PaymentTotalCashNonCommissionable { get; set; }
		public decimal PaymentTotalCreditCard { get; set; }
		public decimal PaymentTotalCreditCardNonCommissionable { get; set; }
		public bool PaymentIsTaxApplicable { get; set; }
		public bool PaymentIsClientAccountLocked { get; set; }
		public bool PaymentCanEdit { get; set; }
		public bool PaymentCanDelete { get; set; }
		public bool PaymentCanUndo { get; set; }
		public bool PaymentCanReverse { get; set; }
		public string PaymentEditText {
			get {
				return PaymentCanEdit ? "Edit" : "View";
			}
		}
		public string PaymentDeleteText {
			get {
				return PaymentCanDelete ? "Delete" : PaymentCanUndo ? "Undo" : PaymentCanReverse ? "Reverse" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string PaymentDocumentDateString { get { return PaymentDocumentDate == null ? string.Empty : ((DateTime)PaymentDocumentDate).ToShortDateStringExt(); } }
		public string PaymentDocumentStatusDescription { get { return PaymentDocumentStatus == DocumentStatus.DepositedPaid ? "Paid" : PaymentDocumentStatus.GetEnumDescription(); } }
		public string PaymentReversalStatusDescription { get { return PaymentReversalStatus.GetEnumDescription(); } }
		public string PaymentCombinedStatusDescription { get { return string.Concat(PaymentDocumentStatusDescription, PaymentReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", PaymentReversalStatusDescription)); } }
		public string PaymentTypeDescription { get { return PaymentType.GetEnumDescription().Replace(" Payment", string.Empty).Replace(" Return", string.Empty); } }
		public string PaymentAccountNameLink { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Payment Type")]
		public PaymentType PaymentType { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document No")]
		public string PaymentDocumentNo { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Date")]
		public DateTime? PaymentDocumentDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Account Type")]
		public AccountType PaymentAccountType { get; set; }

		[Display(Name = "Trip")]
		public int? PaymentTripId { get; set; }

		[Display(Name = "Debtor")]
		public int? PaymentDebtorId { get; set; }

		[Display(Name = "Creditor")]
		public int? PaymentCreditorId { get; set; }

		[Display(Name = "GL Account")]
		public int? PaymentChartOfAccountId { get; set; }

		[Display(Name = "Supplier")]
		public int? PaymentSupplierId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Bank Account")]
		public int? PaymentBankAccountId { get; set; }

		[Editable(false)]
		[Display(Name = "Bank Statement")]
		public string PaymentBankAccountStatementName { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Payee")]
		public string PaymentPayee { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale")]
		public int? PaymentSaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Category")]
		public int? PaymentCategoryId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Consultant")]
		public int? PaymentConsultantId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Source")]
		public int? PaymentSourceId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Airline")]
		public int? PaymentAirlineId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission")]
		public decimal PaymentCommission { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission Rate")]
		public decimal PaymentCommissionRate { get; set; }

		[Editable(false)]
		[Display(Name = "CommissionTaxLabel", ResourceType = typeof(Resource))]
		public decimal PaymentCommissionTax { get; set; }

		[Editable(false)]
		[Display(Name = "CommissionTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal PaymentCommissionTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount")]
		public decimal PaymentDiscount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Rate")]
		public decimal PaymentDiscountRate { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxLabel", ResourceType = typeof(Resource))]
		public decimal PaymentDiscountTax { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal PaymentDiscountTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Reason")]
		public int? PaymentDiscountReasonId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Mark-Up")]
		public decimal PaymentMarkup { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Mark-Up Rate")]
		public decimal PaymentMarkupRate { get; set; }

		[Editable(false)]
		[Display(Name = "MarkupTaxLabel", ResourceType = typeof(Resource))]
		public decimal PaymentMarkupTax { get; set; }

		[Editable(false)]
		[Display(Name = "MarkupTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal PaymentMarkupTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Mark-Up Strategy")]
		public int? PaymentMarkupStrategyId { get; set; }

		[Display(Name = "Is Deposit")]
		public bool PaymentIsDeposit { get; set; }

		[Display(Name = "IsTaxIncludedLabel", ResourceType = typeof(Resource))]
		public bool PaymentIsTaxIncluded { get; set; }

		[Display(Name = "Auto-Invoice")]
		public bool PaymentIsAutoInvoiced { get; set; }

		[Display(Name = "Split Payment")]
		public bool PaymentIsSplit { get; set; }

		[Display(Name = "Credit Card Discount Applies")]
		public bool PaymentIsCreditCardDiscountApplicable { get; set; }

		[Display(Name = "Include Mark-Up in Credit Card Payment")]
		public bool PaymentIncludeMarkupInCreditCardPayment { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Comments")]
		public string PaymentComments { get; set; }

		[Editable(false)]
		[Display(Name = "Total Amount")]
		public decimal PaymentTotalAmount { get; set; }

		[Editable(false)]
		[Display(Name = "TaxTotalLabel", ResourceType = typeof(Resource))]
		public decimal PaymentTotalTax { get; set; }

		[Editable(false)]
		[Display(Name = "TaxRateLabel", ResourceType = typeof(Resource))]
		public decimal PaymentTotalTaxRate { get; set; }

		[Editable(false)]
		[Display(Name = "Total Non-Comm")]
		public decimal PaymentTotalNonCommissionable { get; set; }

		[Editable(false)]
		[Display(Name = "Amount Payable")]
		public decimal PaymentAmountPayable { get; set; }

		[Editable(false)]
		[Display(Name = "TaxTotalLabel", ResourceType = typeof(Resource))]
		public decimal PaymentAmountPayableTax { get; set; }

		[Editable(false)]
		[Display(Name = "Document Total")]
		public decimal PaymentDocumentTotal { get; set; }
	}

	public class PaymentDetailViewModel {
		public int PaymentDetailId { get; set; }
		public int PaymentId { get; set; }
		public PaymentType PaymentDetailPaymentType { get; set; }
		public TripLineType PaymentDetailTripLineType { get; set; }
		public DocumentStatus PaymentDetailDocumentStatus { get; set; }
		public ReversalStatus PaymentDetailReversalStatus { get; set; }
		public string PaymentDetailPassenger { get; set; }
		public string PaymentDetailFormOfPayment { get; set; }
		public string PaymentDetailBankAccountStatementName { get; set; }
		public string PaymentDetailLinkedDocumentNo { get; set; }
		public DateTime PaymentDetailLinkedDocumentDate { get; set; }
		public string PaymentDetailLinkedAccountName { get; set; }
		public decimal PaymentDetailLinkedAmountPayable { get; set; }
		public bool PaymentDetailCanEdit { get; set; }
		public bool PaymentDetailCanDelete { get; set; }
		public bool PaymentDetailCanUndo { get; set; }
		public bool PaymentDetailCanReverse { get; set; }

		public string PaymentDetailEditText {
			get {
				return PaymentDetailCanEdit ? "Edit" : "View";
			}
		}

		public string PaymentDetailDeleteText {
			get {
				return PaymentDetailCanDelete ? "Delete" : PaymentDetailCanUndo ? "Undo" : PaymentDetailCanReverse ? "Reverse" : "None";
			}
		}

		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string PaymentDetailDocumentStatusDescription { get { return PaymentDetailDocumentStatus == DocumentStatus.DepositedPaid ? "Paid" : PaymentDetailDocumentStatus.GetEnumDescription(); } }
		public string PaymentDetailReversalStatusDescription { get { return PaymentDetailReversalStatus.GetEnumDescription(); } }
		public string PaymentDetailCombinedStatusDescription { get { return string.Concat(PaymentDetailDocumentStatusDescription, PaymentDetailReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", PaymentDetailReversalStatusDescription)); } }
		public string PaymentDetailLinkedDocumentDateString { get { return PaymentDetailLinkedDocumentDate.ToShortDateStringExt(); } }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip Line")]
		public int? PaymentDetailTripLineId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Air Passenger")]
		public int? PaymentDetailTripLineAirPassengerId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Passenger")]
		public int? PaymentDetailPassengerId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Form of Payment")]
		public int? PaymentDetailFormOfPaymentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Offered Fare")]
		public decimal PaymentDetailOfferedFare { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Reason Rejected")]
		public int? PaymentDetailOfferedReasonId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal PaymentDetailAmount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "TaxLabel", ResourceType = typeof(Resource))]
		public decimal PaymentDetailTax { get; set; }

		[Editable(false)]
		[Display(Name = "TaxRateLabel", ResourceType = typeof(Resource))]
		public decimal PaymentDetailTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Taxes/Non-Comm")]
		public decimal PaymentDetailNonCommissionable { get; set; }

		[Display(Name = "TaxAppliesLabel", ResourceType = typeof(Resource))]
		public bool PaymentDetailIsTaxApplicable { get; set; }
	}

	public class PaymentAddViewModel {
		public int PaymentAddId { get; set; }
		public int PaymentAddTripLineId { get; set; }
		public int PaymentAddTripLineAirPassengerId { get; set; }
		public TripLineType PaymentAddTripLineType { get; set; }
		public string PaymentAddDescription { get; set; }
		public string PaymentAddTooltip { get; set; }
		public bool PaymentAddDatePaidIsIssueDate { get; set; }
		public decimal PaymentAddAmountPayable { get; set; }
		public decimal PaymentAddNonCommissionableMax { get; set; }
		public decimal PaymentAddCommissionMax { get; set; }
		public decimal PaymentAddDiscountMax { get; set; }
		public decimal PaymentAddMarkupMax { get; set; }
		public bool PaymentAddIsBsp { get; set; }
		public bool PaymentAddIsParent { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document No")]
		public string PaymentAddDocumentNo { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Date Paid")]
		public DateTime? PaymentAddDocumentDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Passenger")]
		public int PaymentAddPassengerId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Form of Payment")]
		public int PaymentAddFormOfPaymentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type")]
		public PaymentType PaymentAddPaymentType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal PaymentAddAmount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Non-Comm")]
		public decimal PaymentAddNonCommissionable { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission")]
		public decimal PaymentAddCommission { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount")]
		public decimal PaymentAddDiscount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Mark-Up")]
		public decimal PaymentAddMarkup { get; set; }
	}

	public class InvoiceViewModel {
		public int InvoiceId { get; set; }
		public int InvoiceAgencyId { get; set; }
		public string InvoiceAccountName { get; set; }
		public DocumentStatus InvoiceDocumentStatus { get; set; }
		public bool InvoiceIsIssued { get; set; }
		public bool InvoiceHasAutoClosed { get; set; }
		public string InvoiceEmail { get; set; }
        public string InvoiceAgencyEmail { get; set; }
        public bool InvoiceIsNew { get; set; }
		public bool InvoiceCanEdit { get; set; }
		public bool InvoiceCanDelete { get; set; }
		public bool InvoiceCanUndo { get; set; }
		public bool InvoiceCanReissue { get; set; }
		public string InvoiceEditText {
			get {
				return InvoiceCanEdit ? "Edit" : "View";
			}
		}
		public string InvoiceDeleteText {
			get {
				return InvoiceCanDelete ? "Delete" : InvoiceCanUndo ? "Undo" : InvoiceCanReissue ? "Reissue" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string InvoiceDocumentStatusDescription { get { return string.Concat(InvoiceDocumentStatus.GetEnumDescription(), InvoiceIsIssued ? "/Issued" : string.Empty); } }
		public string InvoiceAccountTypeDescription { get { return InvoiceAccountType.GetEnumDescription(); } }
		public string InvoiceTypeDescription { get { return InvoiceType.GetEnumDescription(); } }
		public string InvoiceDocumentDateString { get { return InvoiceDocumentDate == null ? string.Empty : ((DateTime)InvoiceDocumentDate).ToShortDateStringExt(); } }
		public string InvoiceAccountNameLink { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Account Type")]
		public AccountType InvoiceAccountType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document Type")]
		public InvoiceType InvoiceType { get; set; }

		[Editable(false)]
		[Display(Name = "Document No")]
		public string InvoiceDocumentNo { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Date")]
		public DateTime? InvoiceDocumentDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Debtor")]
		public int? InvoiceDebtorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Cost Centre")]
		public int? InvoiceSubDebtorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Contact")]
		public int? InvoiceDebtorContactId { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Debtor Name")]
		public string InvoiceDebtorName { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Address")]
		public string InvoiceDebtorAddress1 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Address is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		public string InvoiceDebtorAddress2 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "City")]
		public string InvoiceDebtorLocality { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "State")]
		public string InvoiceDebtorRegion { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Post Code")]
		public string InvoiceDebtorPostCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Country")]
		public string InvoiceDebtorCountryCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Order No")]
		public string InvoiceDebtorOrderNo { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Currency")]
		public int? InvoiceDebtorCurrencyId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Exchange Rate")]
		public decimal InvoiceDebtorExchangeRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Deposit")]
		public decimal InvoiceDeposit { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Balance")]
		public decimal InvoiceBalance { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Deposit Due")]
		public DateTime? InvoiceDepositDueDate { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Deposit Paid")]
		public DateTime? InvoiceDepositPaidDate { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Balance Due")]
		public DateTime? InvoiceBalanceDueDate { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Payment Terms")]
		public string InvoicePaymentTerms { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Statement Comments")]
		public string InvoiceComments { get; set; }

		[Editable(false)]
		[Display(Name = "Invoice Value")]
		public decimal InvoiceTotalAmount { get; set; }

		[Editable(false)]
		[Display(Name = "TaxTotalLabel", ResourceType = typeof(Resource))]
		public decimal InvoiceTotalTax { get; set; }

		[Editable(false)]
		[Display(Name = "TaxRateLabel", ResourceType = typeof(Resource))]
		public decimal InvoiceTotalTaxRate { get; set; }

		[Editable(false)]
		[Display(Name = "Total Discount")]
		public decimal InvoiceTotalDiscount { get; set; }

		[Editable(false)]
		[Display(Name = "Discount Rate")]
		public decimal InvoiceTotalDiscountRate { get; set; }

		[Display(Name = "IsTaxIncludedLabel", ResourceType = typeof(Resource))]
		public bool InvoiceIsTaxIncluded { get; set; }

		[Display(Name = "Invoiced Passengers")]
		public string InvoicedPassengers { get; set; }
	}

	public class InvoiceDetailViewModel {
		public int InvoiceDetailId { get; set; }
		public int InvoiceId { get; set; }
		public AccountType InvoiceDetailAccountType { get; set; }
		public DocumentStatus InvoiceDetailDocumentStatus { get; set; }
		public TripLineType InvoiceDetailTripLineType { get; set; }
		public decimal InvoiceDetailAvailableCredit { get; set; }
		public decimal InvoiceDetailPaymentTax { get; set; }
		public bool InvoiceDetailIsNew { get; set; }
		public bool InvoiceDetailIsPayment { get; set; }
		public bool InvoiceDetailIsTaxApplicable { get; set; }
		public bool InvoiceDetailCanEdit { get; set; }
		public bool InvoiceDetailCanDelete { get; set; }
		public bool InvoiceDetailCanUndo { get; set; }
		public bool InvoiceDetailCanReissue { get; set; }

		public string InvoiceDetailEditText {
			get {
				return InvoiceDetailCanEdit ? "Edit" : "View";
			}
		}
		public string InvoiceDetailDeleteText {
			get {
				return InvoiceDetailCanDelete ? "Delete" : InvoiceDetailCanUndo ? "Undo" : InvoiceDetailCanReissue ? "Reissue" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string InvoiceDetailDocumentStatusDescription { get { return InvoiceDetailDocumentStatus.GetEnumDescription(); } }
		public string InvoiceDetailAccountNameLink { get; set; }
		public string InvoiceDetailSaleType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip")]
		public int? InvoiceDetailTripId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip Line")]
		public int? InvoiceDetailTripLineId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Air Passenger")]
		public int? InvoiceDetailTripLineAirPassengerId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "GL Account")]
		public int? InvoiceDetailChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale")]
		public int? InvoiceDetailSaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal InvoiceDetailAmount { get; set; }

		[Editable(false)]
		[Display(Name = "TaxLabel", ResourceType = typeof(Resource))]
		public decimal InvoiceDetailTax { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount")]
		public decimal InvoiceDetailDiscount { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxLabel", ResourceType = typeof(Resource))]
		public decimal InvoiceDetailDiscountTax { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal InvoiceDetailDiscountTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Reason")]
		public int? InvoiceDetailDiscountReasonId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Creditor")]
		public int? InvoiceDetailCreditorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier")]
		public int? InvoiceDetailSupplierId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Airline")]
		public int? InvoiceDetailAirlineId { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(30, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Document No")]
		public string InvoiceDetailDocumentNo { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(30, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Confirmation No")]
		public string InvoiceDetailConfirmationNo { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Description")]
		public string InvoiceDetailDescription { get; set; }

		[Editable(false)]
		[Display(Name = "TaxRateLabel", ResourceType = typeof(Resource))]
		public decimal InvoiceDetailTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Rate")]
		public decimal InvoiceDetailDiscountRate { get; set; }

		[Editable(false)]
		[Display(Name = "Line Value")]
		public decimal InvoiceDetailTotalAmount { get; set; }
	}

	public class JournalViewModel {
		public int JournalId { get; set; }
		public DocumentStatus JournalDocumentStatus { get; set; }
		public ReversalStatus JournalReversalStatus { get; set; }
		public decimal? JournalTotalDebit { get; set; }
		public decimal? JournalTotalCredit { get; set; }
		public string JournalComments { get; set; }
		public bool JournalCanEdit { get; set; }
		public bool JournalCanDelete { get; set; }
		public bool JournalCanUndo { get; set; }
		public bool JournalCanReverse { get; set; }

		public string JournalEditText {
			get {
				return JournalCanEdit ? "Edit" : "View";
			}
		}

		public string JournalDeleteText {
			get {
				return JournalCanDelete ? "Delete" : JournalCanUndo ? "Undo" : JournalCanReverse ? "Reverse" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string JournalDocumentDateString { get { return JournalDocumentDate == null ? string.Empty : ((DateTime)JournalDocumentDate).ToShortDateStringExt(); } }
		public string JournalDocumentStatusDescription { get { return JournalDocumentStatus.GetEnumDescription(); } }
		public string JournalReversalStatusDescription { get { return JournalReversalStatus.GetEnumDescription(); } }
		[Display(Name = "Status")]
		public string JournalCombinedStatusDescription { get { return string.Concat(JournalDocumentStatusDescription, JournalReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", JournalReversalStatusDescription)); } }

		[Editable(false)]
		[Display(Name = "Document No")]
		public string JournalDocumentNo { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document Date")]
		public DateTime? JournalDocumentDate { get; set; }

		[Editable(false)]
		[Display(Name = "Balance")]
		public decimal JournalBalance { get; set; }
	}

	public class JournalDetailViewModel {
		public int JournalDetailId { get; set; }
		public int JournalId { get; set; }
		public decimal? JournalDetailDebit { get; set; }
		public decimal? JournalDetailCredit { get; set; }
		public decimal JournalDetailListAmount { get; set; }
		public bool JournalDetailCanEdit { get; set; }
		public bool JournalDetailCanDelete { get; set; }
		public bool JournalDetailCanUndo { get; set; }
		public bool JournalDetailCanReverse { get; set; }
		public string JournalDetailEditText {
			get {
				return JournalDetailCanEdit ? "Edit" : "View";
			}
		}
		public string JournalDetailDeleteText {
			get {
				return JournalDetailCanDelete ? "Delete" : JournalDetailCanUndo ? "Undo" : JournalDetailCanReverse ? "Reverse" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string JournalDetailAccountTypeDescription { get { return JournalDetailAccountType.GetEnumDescription(); } }
		public string JournalDetailAccountNameLink { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Account Type")]
		public AccountType JournalDetailAccountType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip")]
		public int? JournalDetailTripId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Debtor")]
		public int? JournalDetailDebtorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Creditor")]
		public int? JournalDetailCreditorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "GL Account")]
		public int? JournalDetailChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Sign Type")]
		public SignType JournalDetailSignType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal JournalDetailAmount { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Comments")]
		public string JournalDetailComments { get; set; }
	}

	public class AdjustmentViewModel {
		public int AdjustmentId { get; set; }
		public DocumentStatus AdjustmentDocumentStatus { get; set; }
		public ReversalStatus AdjustmentReversalStatus { get; set; }
		public string AdjustmentDebitAccountName { get; set; }
		public string AdjustmentCreditAccountName { get; set; }
		public string AdjustmentType { get; set; }
		public bool AdjustmentIsTaxApplicable { get; set; }
		public bool AdjustmentCanEdit { get; set; }
		public bool AdjustmentCanDelete { get; set; }
		public bool AdjustmentCanUndo { get; set; }
		public bool AdjustmentCanReverse { get; set; }
		public string AdjustmentEditText {
			get {
				return AdjustmentCanEdit ? "Edit" : "View";
			}
		}
		public string AdjustmentDeleteText {
			get {
				return AdjustmentCanDelete ? "Delete" : AdjustmentCanUndo ? "Undo" : AdjustmentCanReverse ? "Reverse" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string AdjustmentDocumentDateString { get { return AdjustmentDocumentDate == null ? string.Empty : ((DateTime)AdjustmentDocumentDate).ToShortDateStringExt(); } }
		public string AdjustmentDocumentStatusDescription { get { return AdjustmentDocumentStatus.GetEnumDescription(); } }
		public string AdjustmentReversalStatusDescription { get { return AdjustmentReversalStatus.GetEnumDescription(); } }
		public string AdjustmentCombinedStatusDescription { get { return string.Concat(AdjustmentDocumentStatusDescription, AdjustmentReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", AdjustmentReversalStatusDescription)); } }
		public string AdjustmentDebitTypeDescription { get { return AdjustmentDebitType.GetEnumDescription(); } }
		public string AdjustmentCreditTypeDescription { get { return AdjustmentCreditType.GetEnumDescription(); } }
		public string AdjustmentDebitAccountNameLink { get; set; }
		public string AdjustmentCreditAccountNameLink { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Adjustment Type")]
		public int? AdjustmentTypeId { get; set; }

		[Editable(false)]
		[Display(Name = "Document No")]
		public string AdjustmentDocumentNo { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Date")]
		public DateTime? AdjustmentDocumentDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Debit Type")]
		public DebitCreditType AdjustmentDebitType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip")]
		public int? AdjustmentDebitTripId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip Line")]
		public int? AdjustmentDebitTripLineId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Debtor")]
		public int? AdjustmentDebitDebtorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Creditor")]
		public int? AdjustmentDebitCreditorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "GL Account")]
		public int? AdjustmentDebitChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Credit Type")]
		public DebitCreditType AdjustmentCreditType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip")]
		public int? AdjustmentCreditTripId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip Line")]
		public int? AdjustmentCreditTripLineId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Debtor")]
		public int? AdjustmentCreditDebtorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Creditor")]
		public int? AdjustmentCreditCreditorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "GL Account")]
		public int? AdjustmentCreditChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier")]
		public int? AdjustmentSupplierId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale")]
		public int? AdjustmentSaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Group")]
		public int? AdjustmentGroupId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Category")]
		public int? AdjustmentCategoryId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Destination")]
		public int? AdjustmentDestinationId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Consultant")]
		public int? AdjustmentConsultantId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Agent")]
		public int? AdjustmentAgentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Source")]
		public int? AdjustmentSourceId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal AdjustmentAmount { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Comments")]
		public string AdjustmentComments { get; set; }
	}

	public class VoucherViewModel {
		public int VoucherId { get; set; }
		public int VoucherAgencyId { get; set; }
		public string VoucherAccountName { get; set; }
		public DocumentStatus VoucherDocumentStatus { get; set; }
		public ReversalStatus VoucherReversalStatus { get; set; }
		public string VoucherSupplierAddress { get; set; }
		public string VoucherSupplierContactFullName { get; set; }
		public string VoucherSupplierContactPhoneNo { get; set; }
		public bool VoucherIsPaxNoApplicable { get; set; }
		public bool VoucherIsIssued { get; set; }
		public string VoucherEmail { get; set; }
        public string VoucherAgencyEmail { get; set; }
        public bool VoucherIsTaxApplicable { get; set; }
		public bool VoucherCanEdit { get; set; }
		public bool VoucherCanDelete { get; set; }
		public bool VoucherCanUndo { get; set; }
		public bool VoucherCanReverse { get; set; }
		public string VoucherEditText {
			get {
				return VoucherCanEdit ? "Edit" : "View";
			}
		}
		public string VoucherDeleteText {
			get {
				return VoucherCanDelete ? "Delete" : VoucherCanUndo ? "Undo" : VoucherCanReverse ? "Reverse" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string VoucherDocumentDateString { get { return VoucherDocumentDate == null ? string.Empty : ((DateTime)VoucherDocumentDate).ToShortDateStringExt(); } }
		public string VoucherDocumentStatusDescription { get { return string.Concat(VoucherDocumentStatus.GetEnumDescription(), VoucherIsIssued ? "/Issued" : string.Empty); } }
		public string VoucherReversalStatusDescription { get { return VoucherReversalStatus.GetEnumDescription(); } }
		public string VoucherCombinedStatusDescription { get { return string.Concat(VoucherDocumentStatusDescription, VoucherReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", VoucherReversalStatusDescription)); } }
		public string VoucherTypeDescription { get { return VoucherType.GetEnumDescription(); } }

		public string VoucherAccountNameLink { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Voucher Type")]
		public VoucherType VoucherType { get; set; }

		[Editable(false)]
		[Display(Name = "Document No")]
		public string VoucherDocumentNo { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Date")]
		public DateTime? VoucherDocumentDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip")]
		public int? VoucherTripId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip Line")]
		public int? VoucherTripLineId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Creditor")]
		public int? VoucherCreditorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier")]
		public int? VoucherSupplierId { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Confirmation No")]
		public string VoucherConfirmationNo { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Service Type")]
		public int? VoucherServiceTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Rate Basis")]
		public int? VoucherServiceTypeRateBasisId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Service")]
		public int? VoucherSupplierServiceId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Duration")]
		public int VoucherDuration { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Coverage Type")]
		public DurationCoverageType VoucherDurationCoverageType { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier")]
		public string VoucherSupplierName { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Address")]
		public string VoucherSupplierAddress1 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Address is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		public string VoucherSupplierAddress2 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "City")]
		public string VoucherSupplierLocality { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "State")]
		public string VoucherSupplierRegion { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Post Code")]
		public string VoucherSupplierPostCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Country")]
		public string VoucherSupplierCountryCode { get; set; }

		[Display(Name = "Title")]
		public string VoucherSupplierContactTitle { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.All, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string VoucherSupplierContactName { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Phone Home")]
		public string VoucherSupplierContactPhoneHome { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Phone Work")]
		public string VoucherSupplierContactPhoneWork { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Mobile")]
		public string VoucherSupplierContactMobile { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Fax")]
		public string VoucherSupplierContactFax { get; set; }

		[DataType(DataType.EmailAddress, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Email")]
		public string VoucherSupplierContactEmail { get; set; }

		[Display(Name = "Open-Dated")]
		public bool VoucherIsOpenDated { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Arrival Date")]
		public DateTime? VoucherStartDate { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
		[StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Time")]
		public string VoucherStartTime { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Details")]
		public string VoucherStartDetails { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Departure Date")]
		public DateTime? VoucherEndDate { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
		[StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Time")]
		public string VoucherEndTime { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Details")]
		public string VoucherEndDetails { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Classification")]
		public PassengerClassification VoucherPassengerClassification { get; set; }

		[Required(ErrorMessage = "Value is required.")]
		[Display(Name = "Adults")]
		public int VoucherPaxAdultNo { get; set; }

		[Required(ErrorMessage = "Value is required.")]
		[Display(Name = "Rate")]
		public decimal VoucherPaxAdultRate { get; set; }

		[Required(ErrorMessage = "Value is required.")]
		[Display(Name = "Qty")]
		public int VoucherPaxAdultQty { get; set; }

		[Required(ErrorMessage = "Value is required.")]
		[Display(Name = "Children")]
		public int VoucherPaxChildNo { get; set; }

		[Required(ErrorMessage = "Value is required.")]
		[Display(Name = "Rate")]
		public decimal VoucherPaxChildRate { get; set; }

		[Required(ErrorMessage = "Value is required.")]
		[Display(Name = "Qty")]
		public int VoucherPaxChildQty { get; set; }

		[Required(ErrorMessage = "Value is required.")]
		[Display(Name = "Infants")]
		public int VoucherPaxInfantNo { get; set; }

		[Required(ErrorMessage = "Value is required.")]
		[Display(Name = "Rate")]
		public decimal VoucherPaxInfantRate { get; set; }

		[Required(ErrorMessage = "Value is required.")]
		[Display(Name = "Qty")]
		public int VoucherPaxInfantQty { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Service Comments")]
		public string VoucherServiceComments { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale")]
		public int? VoucherSaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Currency")]
		public int? VoucherCurrencyId { get; set; }

		[Editable(false)]
		[Display(Name = "Gross")]
		public decimal VoucherAmount { get; set; }

		[Editable(false)]
		[Display(Name = "TaxLabel", ResourceType = typeof(Resource))]
		public decimal VoucherTax { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission")]
		public decimal VoucherCommission { get; set; }

		[Editable(false)]
		[Display(Name = "CommissionTaxLabel", ResourceType = typeof(Resource))]
		public decimal VoucherCommissionTax { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount")]
		public decimal VoucherDiscount { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxLabel", ResourceType = typeof(Resource))]
		public decimal VoucherDiscountTax { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Reason")]
		public int? VoucherDiscountReasonId { get; set; }

		[Display(Name = "Include Pricing")]
		public bool VoucherIncludePricing { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(4000, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Comments")]
		public string VoucherComments { get; set; }

		[Editable(false)]
		[Display(Name = "Net Value")]
		public decimal VoucherNetValue { get; set; }

		[Editable(false)]
		[Display(Name = "TaxRateLabel", ResourceType = typeof(Resource))]
		public decimal VoucherTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission Rate")]
		public decimal VoucherCommissionRate { get; set; }

		[Editable(false)]
		[Display(Name = "CommissionTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal VoucherCommissionTaxRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Discount Rate")]
		public decimal VoucherDiscountRate { get; set; }

		[Editable(false)]
		[Display(Name = "DiscountTaxRateLabel", ResourceType = typeof(Resource))]
		public decimal VoucherDiscountTaxRate { get; set; }

		[Display(Name = "IsTaxIncludedLabel", ResourceType = typeof(Resource))]
		public bool VoucherIsTaxIncluded { get; set; }
	}

	public class VoucherDetailViewModel {
		public int VoucherDetailId { get; set; }
		public int VoucherId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Passenger")]
		public int? VoucherDetailPassengerId { get; set; }
	}

	public class BankReconciliationViewModel {
		public string TransactionDetailBaseRefIds { get; set; }
		public int[] TransactionDetailRefIds { get { return TransactionDetailBaseRefIds.Split(',').Select(int.Parse).Distinct().ToArray(); } }
		public int TransactionDetailRefId { get; set; }
		public int TransactionRefId { get; set; }
		public string AccountName { get; set; }
		public TransactionType TransactionType { get; set; }
		public string DocumentType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public DocumentStatus DocumentStatus { get; set; }
		public StatementDocumentStatus StatementDocumentStatus { get; set; }
		public string FormOfPayment { get; set; }
		public int? BankAccountId { get; set; }
		public string BankAccountName { get; set; }
		public decimal TotalClosed { get; set; }
		public decimal? Debit { get; set; }
		public decimal? Credit { get; set; }
		public decimal RunningTotal { get; set; }
		public bool IsDeposit { get; set; }
		public bool CanEdit { get; set; }
		public bool CanDelete { get; set; }
		public bool CanUndo { get; set; }
		public bool CanReverse { get; set; }
		public string EditText {
			get {
				return CanEdit ? "Edit" : "View";
			}
		}
		public string DeleteText {
			get {
				return CanDelete ? "Delete" : CanUndo ? "Undo" : CanReverse ? "Reverse" : "None";
			}
		}
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }
		public string AccountNameLink { get; set; }
		public string DocumentStatusDescription { get { return DocumentStatus.GetEnumDescription(); } }
		public string DocumentDateString { get { return DocumentDate.ToShortDateStringExt(); } }
	}

	public class BankReconciliationDetailViewModel {
		public long TransactionDetailRefId { get; set; }
		public int TransactionRefId { get; set; }
		public TransactionType TransactionType { get; set; }
		public string TransactionTypeDescription { get { return TransactionType.GetEnumDescription(); } }
		public DocumentStatus DocumentStatus { get; set; }
		public ReversalStatus ReversalStatus { get; set; }
		public string AccountName { get; set; }
		public string DocumentNo { get; set; }
		public DateTime? DocumentDate { get; set; }
		public string PassengerName { get; set; }
		public string FormOfPayment { get; set; }
		public DateTime? DepositDate { get; set; }
		public string BankAccountStatementName { get; set; }
		public decimal? Debit { get; set; }
		public decimal? Credit { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string DepositDateString { get { return DepositDate == null ? string.Empty : string.Format("{0:g}", (DateTime)DepositDate); } }
		public string DocumentDateString { get { return DocumentDate == null ? string.Empty : ((DateTime)DocumentDate).ToShortDateStringExt(); } }
		public string DocumentStatusDescription {
			get {
				if (DocumentStatus == DocumentStatus.DepositedPaid) {
					return TransactionType == TransactionType.Receipt ? "Deposited"
						: TransactionType == TransactionType.Bsp || TransactionType == TransactionType.NonBsp || TransactionType == TransactionType.Payment ? "Paid"
						: DocumentStatus.GetEnumDescription();
				}

				return DocumentStatus.GetEnumDescription();
			}
		}
		public string ReversalStatusDescription { get { return ReversalStatus.GetEnumDescription(); } }
		public string CombinedStatusDescription { get { return string.Concat(DocumentStatusDescription, ReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", ReversalStatusDescription)); } }
		public string AccountNameLink { get; set; }
		public string DocumentNoLink { get { return string.Format(@"<a href=""#"" onclick=""BankReconciliations.Edit(event, {0}, {1}); return false;"">{2}</a>", TransactionRefId, (int)TransactionType, DocumentNo); } }
	}

	public class PaymentMethodViewModel {
		public int PaymentMethodId { get; set; }
		public string PaymentMethodAccountName { get; set; }
		public string PaymentMethodFormOfPayment { get; set; }
		public bool PaymentMethodIsProfile { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }
		public string PaymentMethodAccountTypeDescription { get { return PaymentMethodAccountType.GetEnumDescription(); } }
		public string PaymentMethodAccountNameLink { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Account Type")]
		public AccountType PaymentMethodAccountType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Profile")]
		public int? PaymentMethodProfileId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip")]
		public int? PaymentMethodTripId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Debtor")]
		public int? PaymentMethodDebtorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Creditor")]
		public int? PaymentMethodCreditorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "GL Account")]
		public int? PaymentMethodChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Form of Payment")]
		public int? PaymentMethodFormOfPaymentId { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Account No")]
		public string PaymentMethodAccountNo { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.IntegerPositive, ErrorMessage = "{0} is invalid.")]
		[StringLength(4, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "CVN")]
		public string PaymentMethodCvn { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(130, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Payment Details 1")]
		public string PaymentMethodPaymentDetails1 { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(130, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Payment Details 2")]
		public string PaymentMethodPaymentDetails2 { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(130, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Payment Details 3")]
		public string PaymentMethodPaymentDetails3 { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Credit Limit")]
		public decimal PaymentMethodCreditLimit { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Expiry Date")]
		public DateTime? PaymentMethodExpiryDate { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Comments")]
		public string PaymentMethodComments { get; set; }

		[Display(Name = "Active")]
		public bool PaymentMethodIsActive { get; set; }
	}

	public class ReceiptExportModel {
		public string AccountName { get; set; }
		public string AccountType { get; set; }
		public string DocumentType { get; set; }
		public string SupplierCommissionType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string DocumentStatus { get; set; }
		public string ReversalStatus { get; set; }
		public string BankAccountFrom { get; set; }
		public string BankAccountTo { get; set; }
		public string Payer { get; set; }
		public string Supplier { get; set; }
		public string SaleType { get; set; }
		public string Category { get; set; }
		public string Source { get; set; }
		public string Consultant { get; set; }
		public decimal AmountToBank { get; set; }
		public decimal AmountToBankTax { get; set; }
		public decimal ClientRefund { get; set; }
		public decimal OriginalSaleTotal { get; set; }
		public decimal OriginalSaleTotalTax { get; set; }
		public decimal Commission { get; set; }
		public decimal CommissionTax { get; set; }
		public decimal NonCommissionable { get; set; }
		public decimal NonCommissionableTax { get; set; }
		public decimal Discount { get; set; }
		public decimal DiscountTax { get; set; }
		public string DiscountReason { get; set; }
		public decimal CancellationFee { get; set; }
		public decimal CancellationFeeTax { get; set; }
		public string CancellationSaleType { get; set; }
		public decimal SupplierCancellationFee { get; set; }
		public decimal SupplierCancellationFeeTax { get; set; }
		public decimal TotalAmount { get; set; }
		public string Comments { get; set; }
	}

	public class BspExportModel {
		public string AccountName { get; set; }
		public string Type { get; set; }
		public string DocumentNo { get; set; }
		public DateTime? DocumentDate { get; set; }
		public string DocumentStatus { get; set; }
		public string ReversalStatus { get; set; }
		public DateTime? DepartureDate { get; set; }
		public string Creditor { get; set; }
		public string Supplier { get; set; }
		public string SaleType { get; set; }
		public decimal Commission { get; set; }
		public decimal CommissionTax { get; set; }
		public decimal Cash { get; set; }
		public decimal CashNonCommissionable { get; set; }
		public decimal CreditCard { get; set; }
		public decimal CreditCardNonCommissionable { get; set; }
		public decimal Tax { get; set; }
		public decimal TotalAmount { get; set; }
		public decimal AmountPayable { get; set; }
		public string PaymentNo { get; set; }
		public DateTime? PaymentDate { get; set; }
		public DateTime? ReturnDate { get; set; }
	}

	public class NonBspExportModel {
		public string AccountName { get; set; }
		public string Type { get; set; }
		public string DocumentNo { get; set; }
		public DateTime? DocumentDate { get; set; }
		public string DocumentStatus { get; set; }
		public string ReversalStatus { get; set; }
		public DateTime? DepartureDate { get; set; }
		public string Creditor { get; set; }
		public string Supplier { get; set; }
		public string SaleType { get; set; }
		public decimal Commission { get; set; }
		public decimal CommissionTax { get; set; }
		public decimal Cash { get; set; }
		public decimal CashNonCommissionable { get; set; }
		public decimal CreditCard { get; set; }
		public decimal CreditCardNonCommissionable { get; set; }
		public decimal Tax { get; set; }
		public decimal TotalAmount { get; set; }
		public decimal AmountPayable { get; set; }
		public string PaymentNo { get; set; }
		public DateTime? PaymentDate { get; set; }
		public DateTime? ReturnDate { get; set; }
	}

	public class PaymentExportModel {
		public string AccountName { get; set; }
		public string PaymentType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime? DocumentDate { get; set; }
		public DateTime? ReturnDate { get; set; }
		public string DocumentStatus { get; set; }
		public string ReversalStatus { get; set; }
		public string BankAccount { get; set; }
		public string Payee { get; set; }
		public string SaleType { get; set; }
		public bool IsDeposit { get; set; }
		public decimal Commission { get; set; }
		public decimal CommissionTax { get; set; }
		public decimal Cash { get; set; }
		public decimal CashNonCommissionable { get; set; }
		public decimal CreditCard { get; set; }
		public decimal CreditCardNonCommissionable { get; set; }
		public decimal Tax { get; set; }
		public decimal AmountPayable { get; set; }
	}

	public class InvoiceExportModel {
		public string Debtor { get; set; }
		public string AccountName { get; set; }
		public string AccountType { get; set; }
		public string DocumentType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string DocumentStatus { get; set; }
		public decimal TotalAmount { get; set; }
		public decimal TotalTax { get; set; }
		public decimal TotalDiscount { get; set; }
		public string Comments { get; set; }
	}

	public class JournalExportModel {
		public string DocumentNo { get; set; }
		public DateTime? DocumentDate { get; set; }
		public string DocumentStatus { get; set; }
		public string ReversalStatus { get; set; }
		public string AccountType { get; set; }
		public string AccountName { get; set; }
		public decimal? Debit { get; set; }
		public decimal? Credit { get; set; }
		public string Comments { get; set; }
	}

	public class AdjustmentExportModel {
		public string DebitAccountName { get; set; }
		public string CreditAccountName { get; set; }
		public string AdjustmentType { get; set; }
		public string DebitType { get; set; }
		public string CreditType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string DocumentStatus { get; set; }
		public string ReversalStatus { get; set; }
		public string Supplier { get; set; }
		public string SaleType { get; set; }
		public string Group { get; set; }
		public string Category { get; set; }
		public string Destination { get; set; }
		public string Consultant { get; set; }
		public string Agent { get; set; }
		public string Source { get; set; }
		public decimal Amount { get; set; }
		public string Comments { get; set; }
	}

	public class VoucherExportModel {
		public string AccountName { get; set; }
		public string DocumentType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string DocumentStatus { get; set; }
		public string ReversalStatus { get; set; }

		public string ConfirmationNo { get; set; }
		public string ServiceType { get; set; }
		public string ServiceTypeRateBasis { get; set; }
		public string SupplierService { get; set; }
		public int Duration { get; set; }
		public string DurationCoverageType { get; set; }
		public string PassengerClassification { get; set; }

		public string Supplier { get; set; }
		public string SupplierAddress1 { get; set; }
		public string SupplierAddress2 { get; set; }
		public string SupplierLocality { get; set; }
		public string SupplierRegion { get; set; }
		public string SupplierPostCode { get; set; }
		public string SupplierCountryCode { get; set; }

		public string SupplierContactTitle { get; set; }
		public string SupplierContactName { get; set; }
		public string SupplierContactPhoneHome { get; set; }
		public string SupplierContactPhoneWork { get; set; }
		public string SupplierContactMobile { get; set; }
		public string SupplierContactFax { get; set; }
		public string SupplierContactEmail { get; set; }

		public DateTime? StartDate { get; set; }
		public string StartTime { get; set; }
		public string StartDetails { get; set; }
		public DateTime? EndDate { get; set; }
		public string EndTime { get; set; }
		public string EndDetails { get; set; }

		public int PaxAdultNo { get; set; }
		public decimal PaxAdultRate { get; set; }
		public int PaxAdultQty { get; set; }
		public int PaxChildNo { get; set; }
		public decimal PaxChildRate { get; set; }
		public int PaxChildQty { get; set; }
		public int PaxInfantNo { get; set; }
		public decimal PaxInfantRate { get; set; }
		public int PaxInfantQty { get; set; }

		public string ServiceComments { get; set; }
		public string SaleType { get; set; }
		public string Currency { get; set; }
		public decimal Amount { get; set; }
		public decimal Tax { get; set; }
		public decimal Commission { get; set; }
		public decimal CommissionTax { get; set; }
		public decimal Discount { get; set; }
		public decimal DiscountTax { get; set; }
		public string DiscountReason { get; set; }
		public string Comments { get; set; }
		public decimal AmountNet { get; set; }
	}

	public class BankReconciliationExportModel {
		public string AccountName { get; set; }
		public string DocumentType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string DocumentStatus { get; set; }
		public string BankAccount { get; set; }
		public decimal? Debit { get; set; }
		public decimal? Credit { get; set; }
	}

	public class TransactionDetailAllocationErrorViewModel {
		public int Id { get; set; }
		public string AccountNameLink { get; set; }
		public decimal Imbalance { get; set; }
	}

	public class GeneralLedgerSettingErrorViewModel {
		public int SettingId { get; set; }
		public DateTime PreviousFiscalYearEndDate { get; set; }
		public DateTime CurrentFiscalYearStartDate { get; set; }
		public string PreviousFiscalYearEndDateString { get { return PreviousFiscalYearEndDate.ToShortDateStringExt(); } }
		public string CurrentFiscalYearStartDateString { get { return CurrentFiscalYearStartDate.ToShortDateStringExt(); } }
	}

	public class MissingTransactionsViewModel {
		public int Id { get; set; }
		public string DocumentType { get; set; }
		public string AccountName { get; set; }
		public string AccountNameLink { get; set; }
		public DateTime DocumentDate { get; set; }
		public string DocumentNo { get; set; }
		public string DocumentNoLink { get; set; }
		public string DocumentDateString { get { return DocumentDate.ToShortDateStringExt(); } }
	}

	public class TaxRateConflictViewModel {
		public int Id { get; set; }
		public string DocumentType { get; set; }
		public string AccountName { get; set; }
		public string AccountNameLink { get; set; }
		public DateTime DocumentDate { get; set; }
		public string DocumentNo { get; set; }
		public string DocumentNoLink { get; set; }
		public string DocumentDateString { get { return DocumentDate.ToShortDateStringExt(); } }
	}

	public class MissingAutoGeneratedDocumentViewModel {
		public int Id { get; set; }
		public string Description { get; set; }
		public int Value { get; set; }
	}
}