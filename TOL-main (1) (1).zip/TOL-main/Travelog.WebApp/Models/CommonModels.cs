﻿using System;
using System.ComponentModel.DataAnnotations;
using Travelog.Biz;
using Travelog.Biz.Enums;
using Travelog.Biz.Resources;

namespace Travelog.WebApp.Models {
	public class AdjustmentTypeViewModel {
		public int AdjustmentTypeId { get; set; }
		public string DebitAccountName { get; set; }
		public string CreditAccountName { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Adjustment Type")]
		public string Name { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Explanation")]
		public string Description { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Debit Type")]
		public DebitCreditType DebitType { get; set; }

		[Display(Name = "Debit Account is Unlocked")]
		public bool IsDebitAccountUnlocked { get; set; }

		[Display(Name = "Disable Types Not Selected")]
		public bool DebitDisableTypesNotSelected { get; set; }

		[Display(Name = "Trip")]
		public int? DebitTripId { get; set; }

		[Display(Name = "Debtor")]
		public int? DebitDebtorId { get; set; }

        [Display(Name = "Creditor")]
        public int? DebitCreditorId { get; set; }

		[Display(Name = "GL Account")]
		public int? DebitChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Credit Type")]
		public DebitCreditType CreditType { get; set; }

		[Display(Name = "Credit Account is Unlocked")]
		public bool IsCreditAccountUnlocked { get; set; }

		[Display(Name = "Disable Types Not Selected")]
		public bool CreditDisableTypesNotSelected { get; set; }

		[Display(Name = "Trip")]
		public int? CreditTripId { get; set; }

		[Display(Name = "Debtor")]
		public int? CreditDebtorId { get; set; }

        [Display(Name = "Creditor")]
        public int? CreditCreditorId { get; set; }

		[Display(Name = "GL Account")]
		public int? CreditChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Sales Transactions")]
		public AdjustmentTransactionType AdjustmentTransactionType { get; set; }
	}

    [Serializable]
    public class AgencyListModel {
        public int Id { get; set; }
        public string Name { get; set; }
        public ReportPeriod TaxAuditReportPeriod { get; set; }
        public TimeFormat TravelDocumentTimeFormat { get; set; }
        public PayIdType PayIdType { get; set; }
        public string PayId { get; set; }
        public string TravelPayUrl { get; set; }
        public string MintUrl { get; set; }
        public string AgencyEmail { get; set; }
        public string AccentColor { get; set; }
        public string HighlightColor { get; set; }
        public bool IsHeadOffice { get; set; }
        public bool IsAccentColorPageHeaderFooterOnly { get; set; }
    }

    public class AgencyViewModel {
		public AddressViewModel AddressViewModel { get; set; }
		public ContactViewModel ContactViewModel { get; set; }

		public int AgencyId { get; set; }
		public string TravelBankAccount { get; set; }
		public string AdminBankAccount { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Agency")]
		public string Name { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Abbreviation")]
        public string Abbreviation { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
		[Range(0, 9, ErrorMessage = "{0} must be between {1} and {2}.")]
		[Display(Name = "BSP Register")]
		public int BspRegister { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "TaxNoLabel", ResourceType = typeof(Resource))]
		public string TaxNo { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Travel Bank Account")]
		public int? TravelBankAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Admin Bank Account")]
		public int? AdminBankAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "TaxAuditReportPeriodLabel", ResourceType = typeof(Resource))]
		public ReportPeriod TaxAuditReportPeriod { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Travel Doc Time Format")]
		public TimeFormat TravelDocumentTimeFormat { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Accent Colour")]
		public string AccentColor { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Highlight Colour")]
		public string HighlightColor { get; set; }

		[Display(Name = "Page Header/Footer Only")]
		public bool IsAccentColorPageHeaderFooterOnly { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Pay ID Type")]
        public PayIdType PayIdType { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Pay ID")]
        public string PayId { get; set; }

        [DataType(DataType.Url, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Url, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "TravelPay URL")]
        public string TravelPayUrl { get; set; }

        [DataType(DataType.Url, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Url, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Mint URL")]
        public string MintUrl { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [StringLength(500, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Payment Options")]
        public string PaymentOptions { get; set; }

        [Display(Name = "Head Office")]
		public bool IsHeadOffice { get; set; }

		[DataType(DataType.Text, ErrorMessage = "Billing Address is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Billing Address is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Address")]
		public string BillingAddress1 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "Billing Address is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Billing Address is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		public string BillingAddress2 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "City")]
		public string BillingLocality { get; set; }

		[DataType(DataType.Text, ErrorMessage = "State/Province/Region is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "State/Province/Region is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "State")]
		public string BillingRegion { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Post Code")]
		public string BillingPostCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Country")]
		public string BillingCountryCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string BillingContactName { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Phone")]
		public string BillingContactPhone { get; set; }

		[DataType(DataType.EmailAddress)]
		[RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Email")]
		public string BillingContactEmail { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string TechnicalContactName { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Phone")]
		public string TechnicalContactPhone { get; set; }

		[DataType(DataType.EmailAddress)]
		[RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Email")]
		public string TechnicalContactEmail { get; set; }
	}

	public class AgencyHeaderViewModel {
		public int AgencyHeaderId { get; set; }
		public int AgencyId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Header Type")]
		public IssuedDocumentType IssuedDocumentType { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[StringLength(1000, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Header Content")]
		public string AgencyHeaderContent { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Header Comment")]
		public int? AgencyHeaderStandardCommentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Footer Comment")]
		public int? AgencyFooterStandardCommentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Logo Position")]
		public Position AgencyHeaderLogoPosition { get; set; }

        public bool AgencyHeaderIncludeTaxNo { get; set; }
	}

	public class AgencyPseudoCityCodeViewModel {
		public int AgencyPseudoCityCodeId { get; set; }
		public int AgencyId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "CRS")]
		public Crs Crs { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "PCC")]
		public string PccName { get; set; }
	}

    public class AgencyUserEmailViewModel {
        public int AgencyUserEmailId { get; set; }
        public int AgencyId { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "User Name")]
        public string UserId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }

    public class AgentViewModel {
		public int AgentId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Agent")]
		public string Name { get; set; }
	}

	public class AircraftViewModel {
		public int AircraftId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(6, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string Code { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Aircraft")]
		public string Name { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(1000, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Comments")]
		public string Comments { get; set; }
	}

	public class AirlineViewModel {
		public int AirlineId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string Code { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Airline")]
		public string Name { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "IATA Code")]
		public string IataCode { get; set; }
	}

	public class AirlineClassViewModel {
		public int AirlineClassId { get; set; }
		public int AirlineId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string AirlineClassCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		//[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Class")]
		public string AirlineClassName { get; set; }
	}

	public class AirlineStandardCommentViewModel {
		public int AirlineStandardCommentId { get; set; }
		public int AirlineId { get; set; }
		public string StandardComment { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type")]
		public AirlineStandardCommentType AirlineStandardCommentType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Standard Comment")]
		public int? StandardCommentId { get; set; }
	}

	public class AirlineCommissionViewModel {
		public int AirlineCommissionId { get; set; }
		public int AirlineId { get; set; }
		public string SaleType { get; set; }
		public string CountryZoneDescription { get { return CountryZone.GetEnumDescription(); } }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale")]
		public int? SaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Zone")]
		public CountryZone CountryZone { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission Rate")]
		public decimal CommissionRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Override Rate")]
		public decimal OverrideRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Override Basis")]
		public OverrideBasis OverrideBasis { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Commissionable Taxes")]
		public string CommissionableTaxes { get; set; }
	}

	public class ApplicationSettingGeneralViewModel {
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Default BSP Returns Creditor")]
		public int? BspCreditorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Agent Commission Account")]
		public int? AgentCommissionDiscountReasonId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "General Ledger Report Sign")]
		public ReportSign GeneralLedgerReportSign { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "TaxAuditReportPeriodLabel", ResourceType = typeof(Resource))]
		public ReportPeriod TaxAuditReportPeriod { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Fiscal Period Close-Off Months")]
        public int FiscalPeriodAutoCloseOffMonths { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Maximum Exchange Rate Margin")]
		public decimal ExchangeRateMargin { get; set; }
	}

	public class ApplicationSettingFormOfPaymentViewModel {
        [Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amex Form of Payment")]
		public int? AmexFormOfPaymentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Diners Club Form of Payment")]
		public int? DinersClubFormOfPaymentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Mastercard Form of Payment")]
		public int? MastercardFormOfPaymentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Visa Form of Payment")]
		public int? VisaFormOfPaymentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Default Loyalty Scheme")]
		public int? LoyaltySchemeFormOfPaymentId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "System Receipts Form of Payment")]
        public int? SystemGenReceiptFormOfPaymentId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "System Invoices Discount Reason")]
        public int? SystemGenInvoiceDiscountReasonId { get; set; }

        [Display(Name = "System Docs Require Approval")]
        public bool SystemGenDocRequiresApproval { get; set; }
    }

    public class ApplicationSettingCrsViewModel {
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Creditor (Air)")]
        public int? CrsAmadeusCreditorAirId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier (Air)")]
        public int? CrsAmadeusSupplierAirId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Creditor (Land)")]
        public int? CrsAmadeusCreditorLandId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier (Land)")]
        public int? CrsAmadeusSupplierLandId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Domestic Service Fee Type*")]
        public int? CrsAmadeusDomesticServiceFeeTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "International Service Fee Type*")]
        public int? CrsAmadeusInternationalServiceFeeTypeId { get; set; }

        [Display(Name = "Calypso Sandbox URL")]
        public string CrsCalypsoSandboxUrl { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Creditor (Air)")]
        public int? CrsEtgCreditorAirId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier (Air)")]
        public int? CrsEtgSupplierAirId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Creditor (Land)")]
        public int? CrsEtgCreditorLandId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier (Land)")]
        public int? CrsEtgSupplierLandId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Domestic Service Fee Type*")]
        public int? CrsEtgDomesticServiceFeeTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "International Service Fee Type*")]
        public int? CrsEtgInternationalServiceFeeTypeId { get; set; }

        [Editable(false)]
        [Display(Name = "ETG Refresh Token")]
        public string CrsEtgRefreshToken { get; set; }

        [Editable(false)]
        [Display(Name = "ETG Access Token")]
        public string CrsEtgAccessToken { get; set; }

        [Editable(false)]
        [Display(Name = "ETG Access Token Expiration")]
        public string CrsEtgAccessTokenExpiration { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Creditor (Air)")]
        public int? CrsGalileoCreditorAirId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier (Air)")]
        public int? CrsGalileoSupplierAirId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Creditor (Land)")]
        public int? CrsGalileoCreditorLandId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier (Land)")]
        public int? CrsGalileoSupplierLandId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Domestic Service Fee Type*")]
        public int? CrsGalileoDomesticServiceFeeTypeId { get; set; }

        [Display(Name = "Always use production environment")]
        public bool CrsGalileoUseProduction { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "International Service Fee Type*")]
        public int? CrsGalileoInternationalServiceFeeTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Default Provider")]
        public int? CrsDefaultProviderId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale (Domestic Air)")]
        public int? CrsDomesticAirSaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale (International Air)")]
        public int? CrsInternationalAirSaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale (Dom Accommodation)")]
        public int? CrsDomesticAccommodationSaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale (Int Accommodation)")]
        public int? CrsInternationalAccommodationSaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale (Dom Transport)")]
        public int? CrsDomesticTransportSaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale (Int Transport)")]
        public int? CrsInternationalTransportSaleTypeId { get; set; }
    }

    public class ApplicationSettingPaymentGatewayViewModel {
		[Display(Name = "API Key")]
		public string EwayCustomerApiKey { get; set; }

		[Display(Name = "Client Key")]
		public string EwayCustomerClientKey { get; set; }

		[Display(Name = "Password")]
		public string EwayCustomerPassword { get; set; }

		[Display(Name = "Sandbox API Key")]
		public string EwaySandboxCustomerApiKey { get; set; }

		[Display(Name = "Sandbox Client Key")]
		public string EwaySandboxCustomerClientKey { get; set; }

		[Display(Name = "Sandbox Password")]
		public string EwaySandboxCustomerPassword { get; set; }
	}

	public class BankAccountViewModel {
		public AddressViewModel AddressViewModel { get; set; }

		public int BankAccountId { get; set; }
		public string ChartOfAccount { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Bank Name")]
		public string Name { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Branch")]
		public string Branch { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(25, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Account No")]
		public string AccountNo { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Account Description")]
		public string AccountDescription { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "GL Account")]
		public int? ChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Daily Withdrawal Limit")]
		public decimal DailyWithdrawalLimit { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Opening Balance")]
		public decimal BankAccountOpeningBalance { get; set; }
	}

	public class BankAccountStatementViewModel {
		public int BankAccountStatementId { get; set; }
		public int BankAccountId { get; set; }
		public DateTime? OpeningDate { get; set; }
		public string Name { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Editable(false)]
		[Display(Name = "Statement No")]
		public int StatementNo { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Opening Balance")]
		public decimal OpeningBalance { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Closing Balance")]
		public decimal ClosingBalance { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Closing Date")]
		public DateTime? ClosingDate { get; set; }
	}

	public class CalypsoCompanyViewModel {
		public int CalypsoCompanyId { get; set; }
		public string CreditorAir { get; set; }
		public string SupplierAir { get; set; }
		public string CreditorLand { get; set; }
		public string SupplierLand { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(2, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string Code { get; set; }
		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Default Creditor (Air)")]
		public int? CreditorAirId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Default Supplier (Air)")]
		public int? SupplierAirId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Default Creditor (Land)")]
		public int? CreditorLandId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Default Supplier (Land)")]
		public int? SupplierLandId { get; set; }
	}

	public class CancelReasonViewModel {
		public int CancelReasonId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Cancel Reason")]
		public string Name { get; set; }
	}

	public class CategoryViewModel {
		public int CategoryId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Category")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Document Comment")]
		public DocumentComment DocumentComment { get; set; }
	}

	public class CityViewModel {
		public int CityId { get; set; }
		public int CountryId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Alpha, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string CityCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "City")]
		public string Name { get; set; }

		[Display(Name = "Has Airport")]
		public bool HasAirport { get; set; }
	}

	public class ClassViewModel {
		public int ClassId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Class")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type")]
		public ClassType ClassType { get; set; }
	}

	public class ClubMembershipViewModel {
		public int ClubMembershipId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Club Membership")]
		public string Name { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "CRS Code")]
		public string CrsCode { get; set; }
	}

	public class ConditionViewModel {
		public int ConditionId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Condition")]
		public string Name { get; set; }
	}

	public class ConsultantViewModel {
		public int ConsultantId { get; set; }
		public bool Inactive { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string ConsultantName { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Job Title")]
		public string JobTitle { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(2, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Amadeus Code")]
		public string AmadeusCode { get; set; }
	}

	public class ConsultantAgencyViewModel {
		public int ConsultantAgencyId { get; set; }
		public string ConsultantName { get; set; }
		public bool IsDefault { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Consultant")]
		public int? ConsultantId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Agency")]
		public int? AgencyId { get; set; }
	}

	public class ConsultantMarginViewModel {
		public int ConsultantMarginId { get; set; }
		public int ConsultantId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale")]
		public int? SaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Range(0, 100, ErrorMessage = "{0} must be between {1} and {2}.")]
		[Display(Name = "Min Sell Margin")]
		public decimal SellMarginMin { get; set; }
	}

	public class ContactTitleViewModel {
		public int ContactTitleId { get; set; }
		public string GenderDescription { get { return Gender == Gender.NotSpecified ? string.Empty : Gender.GetEnumDescription(); } }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Contact Title")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Gender")]
		public Gender Gender { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "CRS Code")]
		public string CrsCode { get; set; }
	}

	public class CountryViewModel {
		public int CountryId { get; set; }
		public string Currency { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string Code { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Country")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Zone")]
		public CountryZone CountryZone { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Currency")]
		public int? CurrencyId { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(2, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "ISO Code")]
		public string IsoCode { get; set; }
	}

	public class CrsRemarkViewModel {
		public int CrsRemarkId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "CRS Remark")]
		public string Name { get; set; }
	}

	public class CurrencyViewModel {
		public int CurrencyId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string Code { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Currency")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Rate")]
		public decimal Rate { get; set; }

		[Editable(false)]
		[Display(Name = "Official Rate")]
		public decimal OfficialRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Rate Type")]
		public ExchangeRateType ExchangeRateType { get; set; }
	}

	public class DestinationViewModel {
		public int DestinationId { get; set; }
		public string StandardComment { get; set; }
		public string Region { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Destination")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Standard Comment")]
		public int? StandardCommentId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Region")]
		public int? RegionId { get; set; }
	}

	public class DiscountReasonViewModel {
		public int DiscountReasonId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Discount Reason")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "General Ledger Account")]
		public int? ChartOfAccountId { get; set; }
	}

	public class EmbassyViewModel {
		public int EmbassyId { get; set; }
		public string Address { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Embassy")]
		public string Name { get; set; }

		[DataType(DataType.Text, ErrorMessage = "Address is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Address is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Address")]
		public string Address1 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "Address is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Address is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		public string Address2 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "City")]
		public string Locality { get; set; }

		[DataType(DataType.Text, ErrorMessage = "State/Province/Region is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "State/Province/Region is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "State")]
		public string Region { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Post Code")]
		public string PostCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Country")]
		public string CountryCode { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Phone")]
		public string PhoneWork { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Fax")]
		public string Fax { get; set; }

		[DataType(DataType.EmailAddress, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Email")]
		public string Email { get; set; }
	}

	public class FormOfPaymentViewModel {
		public int FormOfPaymentId { get; set; }
		public string Creditor { get; set; }
		public string Debtor { get; set; }
		public string DefaultSupplier { get; set; }
		public string CreditCardChartOfAccount { get; set; }
		public string CreditCardSaleType { get; set; }
		public string CreditCardLoyaltyScheme { get; set; }
		public string LoyaltySchemeSaleType1 { get; set; }
		public string LoyaltySchemeSaleType2 { get; set; }
		public string LoyaltySchemeCategory { get; set; }
		public string LoyaltySchemeDestination { get; set; }
		public string LoyaltySchemeConsultant { get; set; }
		public string LoyaltySchemeSource { get; set; }
		public string FormOfPaymentTypeDescription { get { return FormOfPaymentType.GetEnumDescription(); } }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Form of Payment")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Form of Payment Type")]
		public FormOfPaymentType FormOfPaymentType { get; set; }

		[Display(Name = "Include in Deposit")]
		public bool IncludeInDeposit { get; set; }

		[Display(Name = "Do Not Generate Invoice Line")]
		public bool DoNotGenerateInvoiceLine { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Creditor")]
		public int? CreditorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Debtor")]
		public int? DebtorId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Default Supplier")]
		public int? DefaultSupplierId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Merchant Fee Rate")]
		public decimal MerchantFeeRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "GL Account")]
		public int? CreditCardChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale")]
		public int? CreditCardSaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Loyalty Scheme")]
		public int? CreditCardLoyaltySchemeId { get; set; }

		[Display(Name = "Merchant Fee Reduces Commission on Trip")]
		public bool MerchantFeeReducesCommission { get; set; }

		[Display(Name = "User Cannot Change Scheme")]
		public bool CreditCardLoyaltySchemeIsLocked { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Value of a Point")]
		public decimal LoyaltySchemePointValue { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Points Rounding")]
		public LoyaltySchemePointsRoundingMethod LoyaltySchemePointsRoundingMethod { get; set; }

		[Display(Name = "Type of Sale 1")]
		public int? LoyaltySchemeSaleType1Id { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Cost per Point")]
		public decimal LoyaltySchemePointCost1 { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale 2")]
		public int? LoyaltySchemeSaleType2Id { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Cost per Point")]
		public decimal LoyaltySchemePointCost2 { get; set; }

        [Display(Name = "Source")]
        public int? LoyaltySchemeSourceId { get; set; }

		[Display(Name = "Category")]
		public int? LoyaltySchemeCategoryId { get; set; }

		[Display(Name = "Destination")]
		public int? LoyaltySchemeDestinationId { get; set; }

		[Display(Name = "Consultant")]
		public int? LoyaltySchemeConsultantId { get; set; }

		[Display(Name = "Exclude on Receipt")]
		public bool LoyaltySchemeExcludeOnReceipt { get; set; }

		[Display(Name = "Loyalty Value is Receipt Amount")]
		public bool LoyaltySchemeValueIsReceiptAmount { get; set; }

		[Display(Name = "User Cannot Change Loyalty Value")]
		public bool LoyaltySchemeValueIsLocked { get; set; }

		[Display(Name = "User Cannot Change Loyalty Cost")]
		public bool LoyaltySchemeCostIsLocked { get; set; }
	}

	public class FormOfPaymentCrsViewModel {
		public int FormOfPaymentCrsId { get; set; }
		public int FormOfPaymentId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "CRS")]
		public Crs Crs { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "CRS Code")]
		public string CrsCode { get; set; }
	}

	public class GroupViewModel {
		public int GroupId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Group")]
		public string Name { get; set; }
	}

	public class InsurancePolicyPlanViewModel {
		public int InsurancePolicyPlanId { get; set; }
		public int InsurancePolicyId { get; set; }
		public string SaleType { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Insurance Plan")]
		public string InsurancePlanName { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale")]
		public int? SaleTypeId { get; set; }
	}

	public class InsurancePolicyViewModel {
		public int InsurancePolicyId { get; set; }
		public string SupplierName { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Insurance Policy")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Provider")]
		public int? SupplierId { get; set; }
	}

	public class IssuedDocumentViewModel {
		public int IssuedDocumentId { get; set; }
		public IssuedDocumentType IssuedDocumentType { get; set; }
		public DocumentStatus IssuedDocumentStatus { get; set; }
		public string IssuedDocumentName { get; set; }
		public int IssuedDocumentTripId { get; set; }
		public int IssuedDocumentDebtorId { get; set; }
		public int IssuedDocumentCreditorId { get; set; }
		public int IssuedDocumentReceiptId { get; set; }
		public int IssuedDocumentInvoiceId { get; set; }
		public int IssuedDocumentVoucherId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string LastWriteTimeString { get { return string.Format("{0:g}", LastWriteTime); } }
		public string IssuedDocumentTypeDescription { get { return IssuedDocumentType.GetEnumDescription(); } }
		public string IssuedDocumentStatusDescription { get { return IssuedDocumentStatus == DocumentStatus.None ? "None" : IssuedDocumentStatus.GetEnumDescription(); } }
	}

	public class LeisureActivityViewModel {
		public int LeisureActivityId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Leisure Activity")]
		public string Name { get; set; }
	}

	public class LocationViewModel {
		public int LocationId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Location")]
		public string Name { get; set; }
	}

	public class MarkupStrategyViewModel {
		public int MarkupStrategyId { get; set; }
		public string SaleType { get; set; }
		public string ChartOfAccount { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Mark-Up Strategy")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Default Type of Sale")]
		public int? SaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Rem Comm Account")]
		public int? ChartOfAccountId { get; set; }

		[Display(Name = "Allow Inverse Remainder Commission")]
		public bool AllowInverseRemainderCommission { get; set; }
	}

	public class MarkupStrategyElementViewModel {
		public int MarkupStrategyElementId { get; set; }
		public int MarkupStrategyId { get; set; }
		public string MarkupStrategyElementChartOfAccount { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Account")]
		public int? MarkupStrategyElementChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Apportion Method")]
		public ApportionMethod ApportionMethod { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Value")]
		public decimal Amount { get; set; }
	}

	public class MealServedViewModel {
		public int MealServedId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Meal Served")]
		public string Name { get; set; }
	}

	public class MealServedCrsViewModel {
		public int MealServedCrsId { get; set; }
		public int MealServedId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "CRS")]
		public Crs Crs { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "CRS Code")]
		public string CrsCode { get; set; }
	}

	public class OfferedReasonViewModel {
		public int OfferedReasonId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Reason Rejected")]
		public string Name { get; set; }
	}

	public class PaymentTermViewModel {
		public int PaymentTermId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Payment Term")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Term")]
		public int Term { get; set; }
	}

	public class RateViewModel {
		public int RateId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Rate")]
		public string Name { get; set; }
	}

	public class RegionViewModel {
		public int RegionId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Region")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Travel Zone")]
		public TravelZone TravelZone { get; set; }
	}

	public class SaleTypeGroupingViewModel {
		public int SaleTypeGroupingId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string Name { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Description")]
		public string Description { get; set; }
	}

	public class SaleTypeViewModel {
		public int SaleTypeId { get; set; }
		public string TravelTypeDescription { get { return TravelType.GetEnumDescription(); } }
		public string SaleTypeReportingTypeDescription { get { return SaleTypeReportingType.GetEnumDescription(); } }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Type of Sale")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Travel Type")]
		public TravelType TravelType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Reporting Type")]
		public SaleTypeReportingType SaleTypeReportingType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale Grouping")]
		public int? SaleTypeGroupingId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission Rate")]
		public decimal CommissionRate { get; set; }

		[Display(Name = "TaxAppliesLabel", ResourceType = typeof(Resource))]
		public bool IsTaxApplicable { get; set; }

		[Display(Name = "Credit Card Discount Applies")]
		public bool IsCreditCardDiscountApplicable { get; set; }
	}

	public class ServiceFeeTypeViewModel {
		public int ServiceFeeTypeId { get; set; }
		public string SaleType { get; set; }
		public string AdjustmentType { get; set; }
		public string Supplier { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Service Fee Type")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale")]
		public int? SaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Adjustment Type")]
		public int? AdjustmentTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier")]
		public int? SupplierId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal Amount { get; set; }
	}

	public class SourceViewModel {
		public int SourceId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Source")]
		public string Name { get; set; }
	}

	public class SpecialRequestViewModel {
		public int SpecialRequestId { get; set; }
		public bool ImportFromCrs { get; set; }
        public string SpecialRequestTypeDescription { get { return SpecialRequestType == SpecialRequestType.NotSpecified ? string.Empty : SpecialRequestType.GetEnumDescription(); } }
        public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string Code { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Special Request")]
		public string Description { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Request Type")]
		public SpecialRequestType SpecialRequestType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Free Format")]
		public SpecialRequestFreeFormat SpecialRequestFreeFormat { get; set; }
	}

	public class StandardCommentViewModel {
		public int StandardCommentId { get; set; }
		public string StandardCommentTypeDescription { get { return StandardCommentType.GetEnumDescription(); } }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string Code { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Description")]
		public string Description { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Comment")]
		public string Comment { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type")]
		public StandardCommentType StandardCommentType { get; set; }
	}

	public class TaxCodeViewModel {
		public int TaxCodeId { get; set; }
		public string City { get; set; }
		public string SaleType { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string Code { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal Amount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "City")]
		public int? CityId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale")]
		public int? SaleTypeId { get; set; }
	}

	public class TaxRateViewModel {
		public int TaxRateId { get; set; }
		public string Country { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Country")]
		public string CountryCode { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Date Effective")]
		public DateTime DateEffective { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Rate")]
		public decimal Rate { get; set; }

		public string DateEffectiveString { get { return DateEffective.ToShortDateStringExt(); } }
	}

	public class TravelClassDefaultViewModel {
		public int TravelClassDefaultId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string Code { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Travel Class Default")]
		public string Name { get; set; }
	}

	public class TripChecklistDefaultViewModel {
		public int TripChecklistDefaultId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Checklist Item")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Seq No")]
		public int SeqNo { get; set; }
	}

	public class AdjustmentTypeExportModel {
		public string AdjustmentType { get; set; }
		public string Explanation { get; set; }
		public bool IsDebitAccountUnlocked { get; set; }
		public bool DebitDisableTypesNotSelected { get; set; }
		public string DebitAccountNameLink { get; set; }
		public bool IsCreditAccountUnlocked { get; set; }
		public bool CreditDisableTypesNotSelected { get; set; }
		public string CreditAccountNameLink { get; set; }
		public string AdjustmentTransactionType { get; set; }
	}

	public class AgencyExportModel {
		public string Agency { get; set; }
		public string Address { get; set; }
		public string Contact { get; set; }
		public string PhoneHome { get; set; }
		public string PhoneWork { get; set; }
		public string Mobile { get; set; }
		public string Fax { get; set; }
		public string Email { get; set; }
		public int BspRegister { get; set; }
		public string TaxNo { get; set; }
		public string TravelBankAccount { get; set; }
		public string AdminBankAccount { get; set; }
        public string PaymentOptions { get; set; }
        public string TravelPayUrl { get; set; }
        public string MintUrl { get; set; }
        public string PayId { get; set; }
        public bool IsHeadOffice { get; set; }
	}

	public class AirlineClassExportModel {
		public string Airline { get; set; }
		public string ClassCode { get; set; }
		public string ClassName { get; set; }
	}

	public class AirlineCommissionExportModel {
		public string Airline { get; set; }
		public string SaleType { get; set; }
		public string CountryZone { get; set; }
		public decimal CommissionRate { get; set; }
		public decimal OverrideRate { get; set; }
		public string OverrideBasis { get; set; }
		public string CommissionableTaxes { get; set; }
	}

	public class AirlineStandardCommentExportModel {
		public string Airline { get; set; }
		public string StandardCommentType { get; set; }
		public string StandardComment { get; set; }
	}

	public class BankAccountExportModel {
		public string AccountName { get; set; }
		public string Branch { get; set; }
		public string AccountNo { get; set; }
		public string AccountDescription { get; set; }
		public string Address { get; set; }
		public string GeneralLedgerAccount { get; set; }
	}

	public class CityExportModel {
		public string Country { get; set; }
		public string CityCode { get; set; }
		public string CityName { get; set; }
		public bool HasAirport { get; set; }
	}

	public class ConsultantAgencyExportModel {
		public string Consultant { get; set; }
		public string Agency { get; set; }
	}

	public class ConsultantMarginExportModel {
		public string Consultant { get; set; }
		public string SaleType { get; set; }
		public decimal SellMarginMin { get; set; }
	}

	public class FormOfPaymentExportModel {
		public string FormOfPayment { get; set; }
		public string FormOfPaymentType { get; set; }
		public bool IncludeInDeposit { get; set; }
		public bool DoNotGenerateInvoiceLine { get; set; }
		public string Creditor { get; set; }
		public string Debtor { get; set; }
		public string DefaultSupplier { get; set; }
		public decimal MerchantFeeRate { get; set; }
		public string CreditCardGLAccount { get; set; }
		public string CreditCardSaleType { get; set; }
		public string CreditCardLoyaltyScheme { get; set; }
		public bool MerchantFeeReducesCommission { get; set; }
		public bool CreditCardLoyaltySchemeIsLocked { get; set; }
		public decimal LoyaltySchemePointValue { get; set; }
		public string LoyaltySchemePointsRoundingMethod { get; set; }
		public string LoyaltySchemeSaleType1 { get; set; }
		public decimal LoyaltySchemePointCost1 { get; set; }
		public string LoyaltySchemeSaleType2 { get; set; }
		public decimal LoyaltySchemePointCost2 { get; set; }
		public string LoyaltySchemeCategory { get; set; }
		public string LoyaltySchemeDestination { get; set; }
		public string LoyaltySchemeConsultant { get; set; }
		public string LoyaltySchemeSource { get; set; }
		public bool LoyaltySchemeExcludeOnReceipt { get; set; }
		public bool LoyaltySchemeValueIsReceiptAmount { get; set; }
		public bool LoyaltySchemeValueIsLocked { get; set; }
		public bool LoyaltySchemeCostIsLocked { get; set; }
	}

	public class InsurancePolicyPlanExportModel {
		public string InsurancePolicy { get; set; }
		public string InsurancePlan { get; set; }
		public string SaleType { get; set; }
	}

	public class MarkupStrategyExportModel {
		public string MarkupStrategy { get; set; }
		public string SaleType { get; set; }
		public string RemainderCommissionAcct { get; set; }
		public bool AllowInverseRemainderCommission { get; set; }
	}

	public class SaleTypeExportModel {
		public string SaleType { get; set; }
		public string TravelType { get; set; }
		public string ReportingType { get; set; }
		public string Grouping { get; set; }
		public decimal CommissionRate { get; set; }
		public bool IsTaxApplicable { get; set; }
		public bool IsCreditCardDiscountApplicable { get; set; }
	}

	public class ServiceFeeExportModel {
		public string ServiceFee { get; set; }
		public decimal Amount { get; set; }
		public string SaleType { get; set; }
		public string AdjustmentType { get; set; }
		public string Supplier { get; set; }
	}

	public class TaxCodeExportModel {
		public string Code { get; set; }
		public string TaxCode { get; set; }
		public string ListItemType { get; set; }
		public decimal Amount { get; set; }
		public string City { get; set; }
		public string SaleType { get; set; }
	}
}