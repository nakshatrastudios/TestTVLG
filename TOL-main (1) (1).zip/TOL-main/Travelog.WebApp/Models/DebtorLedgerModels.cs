﻿using System;
using System.ComponentModel.DataAnnotations;
using Travelog.Biz;
using Travelog.Biz.Enums;
using Travelog.Biz.Resources;

namespace Travelog.WebApp.Models {
	public class DebtorListModel {
		public int? DebtorId { get; set; }
		public string Name { get; set; }
		public bool IsAuthorisationMandatory { get; set; }
		public bool IsContactMandatory { get; set; }
		public bool IsOrderNoMandatory { get; set; }
		public bool IsTravelReasonMandatory { get; set; }
		public bool IsContactLimitedToCurrentList { get; set; }
		public int OrderNoMinLength { get; set; }
	}

	public class DebtorViewModel {
		public ContactViewModel ContactViewModel;

		public int DebtorId { get; set; }
		public string AgingCycleDescription { get { return AgingCycle == AgingCycle.NotSpecified ? string.Empty : AgingCycle.GetEnumDescription(); } }
		public string ItineraryPricingOptionDescription { get { return ItineraryPricingOption.GetEnumDescription(); } }
		public string Currency { get; set; }
		public string Class { get; set; }
		public string Agency { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(10, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string Code { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Debtor")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Reporting Parent")]
		public int? ReportingParentId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Billing Parent")]
		public int? BillingParentId { get; set; }

        [Display(Name = "Customer")]
        public int? CustomerId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Amadeus CID")]
		public string AmadeusCid { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Galileo CID")]
		public string GalileoCid { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Sabre CID")]
		public string SabreCid { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Range(0, 20, ErrorMessage = "{0} must be between {1} and {2}.")]
		[Display(Name = "Order No Min Length")]
		public int OrderNoMinLength { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Aging Cycle")]
		public AgingCycle AgingCycle { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Start Day")]
		public DayOfWeekExt AgingCycleStartDay { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Matched Txns")]
		public MatchedTxnsReportOption MatchedTxnsReportOption { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Itinerary Pricing")]
		public ItineraryPricingOption ItineraryPricingOption { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Currency")]
		public int? CurrencyId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Class")]
		public int? ClassId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Location")]
		public int? LocationId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Agency")]
		public int? AgencyId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Payment Terms")]
		public int? PaymentTermId { get; set; }

		[Display(Name = "PRISM Reporting")]
		public bool PrismReporting { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Tickets Issued From")]
		public DateTime? PrismReportingStartDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip Nos From")]
		public int? PrismReportingTripId { get; set; }

		[Display(Name = "Domestic")]
		public bool VideoConferencingDomestic { get; set; }

		[Display(Name = "Short Haul International")]
		public bool VideoConferencingShortHaul { get; set; }

		[Display(Name = "International")]
		public bool VideoConferencingInternational { get; set; }

		[Display(Name = "Auto-Invoice")]
		public bool IsAutoInvoice { get; set; }

		[Display(Name = "Authorisation is Mandatory")]
		public bool IsAuthorisationMandatory { get; set; }

		[Display(Name = "Contact is Mandatory")]
		public bool IsContactMandatory { get; set; }

		[Display(Name = "Order No is Mandatory")]
		public bool IsOrderNoMandatory { get; set; }

		[Display(Name = "Travel Reason is Mandatory")]
		public bool IsTravelReasonMandatory { get; set; }

		[Display(Name = "IsTaxInInvoiceLineAmountLabel", ResourceType = typeof(Resource))]
		public bool IsTaxInInvoiceLineAmount { get; set; }

		[Display(Name = "Only Known Contacts are Permitted")]
		public bool IsContactLimitedToCurrentList { get; set; }

		[Display(Name = "Profile Changes are Prevented")]
		public bool IsProfileChangesPrevented { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Credit Limit")]
		public decimal CreditLimit { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Invoice Validation")]
		public InvoiceValidationType InvoiceValidationType { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Rules & Regulations")]
		public string Rules { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Remarks")]
		public string Remarks { get; set; }
	}

	public class DebtorLinkViewModel {
		public int DebtorId { get; set; }
		public string DebtorName { get; set; }
		public bool HasChildren { get; set; }
	}

	public class DebtorExportModel {
		public string Code { get; set; }
		public string Debtor { get; set; }
		public string ReportingParentDebtor { get; set; }
		public string BillingParentDebtor { get; set; }
		public string AgingCycle { get; set; }
		public string AgingCycleStartDay { get; set; }
		public string PaymentTerm { get; set; }
		public string ItineraryPricingOption { get; set; }
		public string Currency { get; set; }
		public string Class { get; set; }
		public string Location { get; set; }
		public string Agency { get; set; }
		public bool PrismReporting { get; set; }
		public DateTime PrismReportingStartDate { get; set; }
		public string PrismReportingTrip { get; set; }
		public string AmadeusCid { get; set; }
		public string GalileoCid { get; set; }
		public string SabreCid { get; set; }
		public int OrderNoMinLength { get; set; }
		public string Address { get; set; }
		public string Contact { get; set; }
		public string PhoneHome { get; set; }
		public string PhoneWork { get; set; }
		public string Mobile { get; set; }
		public string Fax { get; set; }
		public string Email { get; set; }
		public bool VideoConferencingDomestic { get; set; }
		public bool VideoConferencingShortHaul { get; set; }
		public bool VideoConferencingInternational { get; set; }
		public bool IsAutoInvoice { get; set; }
		public bool IsTaxInInvoiceLineAmount { get; set; }
		public bool IsContactLimitedToCurrentList { get; set; }
		public bool IsAuthorisationMandatory { get; set; }
		public bool IsContactMandatory { get; set; }
		public bool IsOrderNoMandatory { get; set; }
		public bool IsProfileChangesPrevented { get; set; }
		public bool IsTravelReasonMandatory { get; set; }
		public string Rules { get; set; }
		public string Remarks { get; set; }
		public decimal CreditLimit { get; set; }
		public string InvoiceValidation { get; set; }
	}
}
