﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Enums;
using Travelog.PaymentGateway.Enums;

namespace Travelog.WebApp.Models {
	public class NotificationViewModel {
		public string Message { get; set; }
		public string MessageType { get; set; }
		public int Timeout { get; set; }
	}

	public class AddressViewModel {
		public AddressViewModel() {
			Address1 = string.Empty;
			Address2 = string.Empty;
			Locality = string.Empty;
			Region = string.Empty;
			PostCode = string.Empty;
			CountryCode = string.Empty;
		}

		public int AddressId { get; set; }
		public int ParentId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string Address { get { return Utils.RemoveExtraSpaces(string.Format("{0} {1} {2} {3} {4} {5}", Address1, Address2, Locality, Region, PostCode, CountryCode)); } }

		[Display(Name = "Address Type")]
		public AddressType AddressType { get; set; }

		[DataType(DataType.Text, ErrorMessage = "Address is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Address is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Address")]
		public string Address1 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "Address is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Address is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		public string Address2 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "City")]
		public string Locality { get; set; }

		[DataType(DataType.Text, ErrorMessage = "State/Province/Region is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "State/Province/Region is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "State")]
		public string Region { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Post Code")]
		public string PostCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Country")]
		public string CountryCode { get; set; }

		[Display(Name = "Default")]
		public bool IsDefaultAddress { get; set; }
	}

	public class ContactViewModel {
		public ContactViewModel() {
			Name = string.Empty;
			PhoneHome = string.Empty;
			PhoneWork = string.Empty;
			Mobile = string.Empty;
			Fax = string.Empty;
			Email = string.Empty;
		}

		public int ContactId { get; set; }
		public int ParentId { get; set; }
		public string PhoneNo { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string Contact { get { return string.Format("{0} {1}", Title, Name).Trim(); } }
		public string ContactLink { get { return string.IsNullOrEmpty(Email) ? Contact : string.Concat(@"<a href=""mailto:", Email, @""">", Contact, "</a>"); } }

		[Display(Name = "Title")]
		public string Title { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string Name { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Phone Home")]
		public string PhoneHome { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Phone Work")]
		public string PhoneWork { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Mobile")]
		public string Mobile { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Fax")]
		public string Fax { get; set; }

		[DataType(DataType.EmailAddress, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Email")]
		public string Email { get; set; }

		[Display(Name = "Default")]
		public bool IsDefaultContact { get; set; }

		public bool? Option1 { get; set; }

		public bool? Option2 { get; set; }
	}

	public class ProcessPaymentViewModel {
		public PaymentGatewayClientType ProcessPaymentClientType { get; set; }
        public int ProcessPaymentCustomerId { get; set; }
        public int ProcessPaymentProfileId { get; set; }
		public int ProcessPaymentTripId { get; set; }
		public int ProcessPaymentDebtorId { get; set; }
		public int ProcessPaymentCreditorId { get; set; }
		public int ProcessPaymentChartOfAccountId { get; set; }
        public bool ProcessPaymentIsRefund { get { return ProcessPaymentTypeId == 1; } }

        [Display(Name = "Cards on File")]
		public int? ProcessPaymentPaymentMethodId { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericWithSpace, ErrorMessage = "{0} is invalid.")]
		[StringLength(19, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Card No")]
		public string ProcessPaymentCardNo { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Cardholder Name")]
		public string ProcessPaymentCardholderName { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.IntegerPositiveWithForwardSlash, ErrorMessage = "{0} is invalid.")]
		[StringLength(7, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Expiry Date")]
		public string ProcessPaymentExpiryDate { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.IntegerPositive, ErrorMessage = "{0} is invalid.")]
		[StringLength(4, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "CVN")]
		public string ProcessPaymentCvn { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Amount")]
		public decimal ProcessPaymentAmount { get; set; }

        [Display(Name = "Payment Type")]
        public int ProcessPaymentTypeId { get; set; }

        [Display(Name = "Save card on file for future payments")]
		public bool ProcessPaymentIsCardOnFile { get; set; }

        [Display(Name = "Recurring payment")]
        public bool ProcessPaymentIsRecurringPayment { get; set; }
    }

    public class ProductEnquiryViewModel {
		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string Name { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Phone")]
		public string Phone { get; set; }

		[DataType(DataType.EmailAddress, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Email")]
		public string Email { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(1000, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Message")]
		public string Message { get; set; }
	}

    public class ReportSourceViewModel {
        public TypeReportSource ReportSource { get; set; }
        public string Parameters { get { return ReportSource == null ? string.Empty : string.Join(",", ReportSource.Parameters.Select(t => string.Concat(t.Name, @": """, t.Value, @""""))); } }
    }
}