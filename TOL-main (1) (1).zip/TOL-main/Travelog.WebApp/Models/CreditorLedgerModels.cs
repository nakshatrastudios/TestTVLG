﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Travelog.Biz;
using Travelog.Biz.Enums;
using Travelog.Biz.Resources;

namespace Travelog.WebApp.Models {
    public class CreditorViewModel {
		public ContactViewModel ContactViewModel;

		public int CreditorId { get; set; }
		public string AgingCycleDescription { get { return AgingCycle == AgingCycle.NotSpecified ? string.Empty : AgingCycle.GetEnumDescription(); } }
		public string Suppliers { get; set; }
		public string Currency { get; set; }
		public string Class { get; set; }
		public string Agency { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Creditor")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Aging Cycle")]
		public AgingCycle AgingCycle { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Currency")]
		public int? CurrencyId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Class")]
		public int? ClassId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Location")]
		public int? LocationId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Agency")]
		public int? AgencyId { get; set; }

		[Display(Name = "Payment by BSP")]
		public bool IsBspAgent { get; set; }

		[Display(Name = "Payment by Non-BSP")]
		public bool IsNonBspAgent { get; set; }

		[Display(Name = "CommissionTaxLabel", ResourceType = typeof(Resource))]
		public bool IsTaxOnCommission { get; set; }

		[Display(Name = "RCTI")]
		public bool IsRcti { get; set; }

		[Display(Name = "Include Mark-Up in Credit Card Payment")]
		public bool IncludeMarkupInCreditCardPayment { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission Rate")]
		public decimal CommissionRate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Credit Limit")]
		public decimal CreditLimit { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Rules & Regulations")]
		public string Rules { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Remarks")]
		public string Remarks { get; set; }
	}

	public class CreditorSupplierViewModel {
		public int CreditorSupplierId { get; set; }
		public int CreditorId { get; set; }
		public string SupplierName { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier")]
		public int? SupplierId { get; set; }

		public bool IsDefault { get; set; }
	}

	public class CreditorCrsViewModel {
		public int CreditorCrsId { get; set; }
		public int CreditorId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "CRS")]
		public Crs Crs { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "CRS Code")]
		public string CrsCode { get; set; }
	}

	public class SupplierViewModel {
		public ContactViewModel ContactViewModel;

		public int SupplierId { get; set; }
		public string Creditors { get; set; }
		public string Class { get; set; }
		public string SaleType { get; set; }
		public string SupplierChain { get; set; }
		public string CityCode { get; set; }
		public IEnumerable<int> ServiceTypeIds { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Supplier")]
		public string Name { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(10, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "IATA Code")]
		public string IataCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "DX No")]
		public string DxNo { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Print Option")]
		public AddressPrintOption AddressPrintOption { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Voucher Type")]
		public VoucherType DefaultVoucherType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "City")]
		public int? CityId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Class")]
		public int? ClassId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Type of Sale")]
		public int? SaleTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Chain")]
		public int? SupplierChainId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission Rate")]
		public decimal CommissionRate { get; set; }

		[Display(Name = "Reminder Letter")]
		public bool ReminderLetter { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Pickup Comments")]
		public string PickupComments { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Dropoff Comments")]
		public string DropoffComments { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(4000, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Comments")]
		public string Comments { get; set; }
	}

	public class SupplierCreditorViewModel {
		public int SupplierCreditorId { get; set; }
		public int SupplierId { get; set; }
		public string CreditorName { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Creditor")]
		public int? CreditorId { get; set; }

		public bool IsDefault { get; set; }
	}

	public class SupplierServiceRateViewModel {
		public int SupplierServiceRateId { get; set; }
		public int SupplierId { get; set; }
		public string EffectiveFromDateString { get { return EffectiveFromDate == null ? string.Empty : ((DateTime)EffectiveFromDate).ToShortDateStringExt(); } }
		public string EffectiveToDateString { get { return EffectiveToDate == null ? string.Empty : ((DateTime)EffectiveToDate).ToShortDateStringExt(); } }
		public string SupplierService { get; set; }
		public string ServiceTypeRateBasis { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Supplier Rate")]
		public string SupplierServiceRateName { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(25, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Season")]
		public string TravelSeason { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Effective From")]
		public DateTime? EffectiveFromDate { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Effective To")]
		public DateTime? EffectiveToDate { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Creditor")]
		public int? SupplierServiceRateCreditorId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale")]
        public int? SupplierServiceRateSaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Service")]
		public int? SupplierServiceId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Rate Basis")]
		public int? ServiceTypeRateBasisId { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(255, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Comments")]
		public string ServiceTypeRateComments { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Rules")]
        public string Rules { get; set; }

        [Display(Name = "Inactive")]
		public bool Inactive { get; set; }
	}

	public class SupplierServiceRateDetailViewModel {
		public int SupplierServiceRateDetailId { get; set; }
		public int SupplierServiceRateId { get; set; }
        public string CurrencyName { get; set; }
        public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Service Rate")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Currency")]
		public int? CurrencyId { get; set; }

		[Display(Name = "Exchange Rate")]
		public decimal ExchangeRate { get; set; }

        [Display(Name = "Cost")]
        public decimal Cost { get; set; }

        [Display(Name = "Rate")]
        public decimal Amount { get; set; }
    }

    public class SupplierServiceRateSelectionViewModel {
		public int SupplierServiceRateDetailId { get; set; }
        public int SupplierServiceTypeRateBasisId { get; set; }
        public int SupplierChainId { get; set; }
		public int CreditorId { get; set; }
		public int SupplierId { get; set; }
		public string SupplierName { get; set; }
        public string SupplierCityCode { get; set; }
        public string TravelSeason { get; set; }
		public DateTime? EffectiveFromDate { get; set; }
		public DateTime? EffectiveToDate { get; set; }
        public int SupplierServiceRateSaleTypeId { get; set; }
        public int SupplierServiceId { get; set; }
        public string SupplierRateName { get; set; }
        public string SupplierServiceName { get; set; }
		public string SupplierServiceRateName { get; set; }
        public string SupplierServiceComments { get; set; }
        public string SupplierPickupComments { get; set; }
        public string SupplierDropoffComments { get; set; }
        public decimal SupplierServiceRateCost { get; set; }
        public decimal SupplierServiceRateAmount { get; set; }
        public string EffectiveFromDateString { get { return EffectiveFromDate == null ? string.Empty : ((DateTime)EffectiveFromDate).ToShortDateStringExt(); } }
		public string EffectiveToDateString { get { return EffectiveToDate == null ? string.Empty : ((DateTime)EffectiveToDate).ToShortDateStringExt(); } }

        [Display(Name = "Creditor")]
        public string CreditorName { get; set; }

        [Display(Name = "Rate Basis")]
        public string SupplierServiceTypeRateBasisName { get; set; }

        [Display(Name = "Type of Sale")]
        public string SupplierServiceRateSaleTypeName { get; set; }

        [Display(Name = "Class")]
        public string SupplierClassName { get; set; }

        [Display(Name = "Currency")]
        public string SupplierServiceRateCurrencyName { get; set; }

        [Display(Name = "Exchange Rate")]
        public decimal SupplierServiceRateExchangeRate { get; set; }

        [Display(Name = "Supplier Comments")]
        public string SupplierComments { get; set; }

        [Display(Name = "Service Rate Comments")]
        public string SupplierServiceRateComments { get; set; }

		[Editable(false)]
        [Display(Name = "Rules")]
        public string SupplierServiceRules { get; set; }
    }

    public class SupplierCrsViewModel {
		public int SupplierCrsId { get; set; }
		public int SupplierId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "CRS")]
		public Crs Crs { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "CRS Code")]
		public string CrsCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Alpha, ErrorMessage = "{0} is invalid.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "City Code")]
		public string CityCode { get; set; }
	}

	public class SupplierUrlViewModel {
		public int SupplierUrlId { get; set; }
		public int SupplierId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string UrlName { get; set; }

		[DataType(DataType.Url, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Url, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Web Address")]
		public string Url { get; set; }
	}

	public class SupplierChainViewModel {
		public int SupplierChainId { get; set; }
		public string Creditor { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Supplier Chain")]
		public string Name { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(10, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "IATA Code")]
		public string IataCode { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Service Type")]
		public int? ServiceTypeId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Creditor")]
		public int? CreditorId { get; set; }
	}

	public class SupplierChainCrsViewModel {
		public int SupplierChainCrsId { get; set; }
		public int SupplierChainId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "CRS")]
		public Crs Crs { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "CRS Code")]
		public string CrsCode { get; set; }
	}

	public class SupplierServiceViewModel {
		public int SupplierServiceId { get; set; }
		public string ServiceType { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Supplier Service")]
		public string Name { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Comments")]
		public string Comments { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(1000, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Related Remarks")]
		public string RelatedRemarks { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Unit of Service")]
		public string UnitOfService { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Service Charged")]
		public string ServiceCharged { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Service Type")]
		public int? ServiceTypeId { get; set; }
	}

	public class ServiceTypeViewModel {
		public int ServiceTypeId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Service Type")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Trip Line Type")]
		public TripLineType TripLineType { get; set; }
	}

	public class ServiceTypeRateBasisViewModel {
		public int ServiceTypeRateBasisId { get; set; }
		public int ServiceTypeId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Rate Basis")]
		public string Name { get; set; }

		[Display(Name = "Pax No Applies")]
		public bool IsPaxNoApplicable { get; set; }
	}

    public class SupplierServiceRateExportModel {
        public string Supplier { get; set; }
        public string SupplierRate { get; set; }
        public string TravelSeason { get; set; }
        public DateTime? EffectiveFromDate { get; set; }
        public DateTime? EffectiveToDate { get; set; }
        public string Creditor { get; set; }
        public string SaleType { get; set; }
        public string Service { get; set; }
        public string RateBasis { get; set; }
        public string ServiceRate { get; set; }
        public string Currency { get; set; }
        public decimal ExchangeRate { get; set; }
        public decimal Cost { get; set; }
        public decimal Rate { get; set; }
        public string Comments { get; set; }
        public string Inactive { get; set; }
    }

    public class CreditorExportModel {
		public string Creditor { get; set; }
		public string AgingCycle { get; set; }
		public string Currency { get; set; }
		public string Class { get; set; }
		public string Agency { get; set; }
		public string Address { get; set; }
		public string Contact { get; set; }
		public string PhoneHome { get; set; }
		public string PhoneWork { get; set; }
		public string Mobile { get; set; }
		public string Fax { get; set; }
		public string Email { get; set; }
		public decimal CommissionRate { get; set; }
		public decimal CreditLimit { get; set; }
		public bool IsBspAgent { get; set; }
		public bool IsNonBspAgent { get; set; }
		public bool IsTaxOnCommission { get; set; }
		public bool IsRcti { get; set; }
	}

	public class SupplierExportModel {
		public string Supplier { get; set; }
		public string AddressPrintOption { get; set; }
		public string DefaultVoucherType { get; set; }
		public string Class { get; set; }
		public string SaleType { get; set; }
		public string SupplierChain { get; set; }
		public string CityCode { get; set; }
		public decimal CommissionRate { get; set; }
		public bool IsReminderLetter { get; set; }
		public string IataCode { get; set; }
		public string DxNo { get; set; }
		public string Address { get; set; }
		public string Contact { get; set; }
		public string PhoneHome { get; set; }
		public string PhoneWork { get; set; }
		public string Mobile { get; set; }
		public string Fax { get; set; }
		public string Email { get; set; }
		public string PickupComments { get; set; }
		public string DropoffComments { get; set; }
		public string Comments { get; set; }
	}
}