﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Travelog.Biz;
using Travelog.Biz.Enums;
using Travelog.Biz.Resources;

namespace Travelog.WebApp.Models {
	public class GeneralLedgerViewModel {
		public int ChartOfAccountId { get; set; }
		public AccountCategory AccountCategory { get; set; }
		public RowType RowType { get; set; }
		public string Code { get; set; }
		public string Name { get; set; }
		public decimal PeriodCurrentYear { get; set; }
		public decimal PeriodPreviousYear { get; set; }
		public decimal YtdBudget { get; set; }
		public decimal YtdCurrentYear { get; set; }
		public decimal YtdPreviousYear { get; set; }
		public decimal PeriodVariance { get { return PeriodCurrentYear - PeriodPreviousYear; } }
		public decimal YtdVariance { get { return YtdCurrentYear - YtdPreviousYear; } }
		public decimal PeriodBudgetVariance { get { return PeriodCurrentYear - PeriodBudget; } }
		public decimal YtdBudgetVariance { get { return YtdCurrentYear - YtdBudget; } }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Budget Amount")]
		public decimal PeriodBudget { get; set; }

		[Display(Name = "Annual amount apportioned across all periods")]
		public bool IsBudgetAnnual { get; set; }
	}

	public class ChartOfAccountViewModel {
		public int ChartOfAccountId { get; set; }
		public int AgencyId { get; set; }
		public IEnumerable<string> UserRoleIds { get; set; }
		public string ChartOfAccountTypeDescription { get { return ChartOfAccountType.GetEnumDescription(); } }
		public string AccountCategoryDescription { get { return AccountCategory.GetEnumDescription(); } }
		public string RowTypeDescription { get { return RowType.GetEnumDescription(); } }
		public string TransactionTypeDescription { get { return ChartOfAccountTransactionType.GetEnumDescription(); } }
		public string TotalLevelDescription { get { return TotalLevel.GetEnumDescription(); } }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(10, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Code")]
		public string Code { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Account")]
		public string Name { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Account Type")]
		public ChartOfAccountType ChartOfAccountType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Account Category")]
		public AccountCategory AccountCategory { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Row Type")]
		public RowType RowType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Transaction Type")]
		public ChartOfAccountTransactionType ChartOfAccountTransactionType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Total Level")]
		public TotalLevel TotalLevel { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(10, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Alt Code")]
		public string AltReportingCode { get; set; }

		[Display(Name = "TaxAppliesLabel", ResourceType = typeof(Resource))]
		public bool IsTaxApplicable { get; set; }
	}

	public class ChartOfAccountAgencyViewModel {
		public int ChartOfAccountAgencyChartOfAccountId { get; set; }
		public string ChartOfAccountAgencyAltReportingCode { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Agency")]
		public int ChartOfAccountAgencyAgencyId { get; set; }
	}

	public class ChartOfAccountBudgetViewModel {
		public int ChartOfAccountId { get; set; }
		public int SettingId { get; set; }
		public string Code { get; set; }
		public string Name { get; set; }
		public decimal Amount01 { get; set; }
		public decimal Amount02 { get; set; }
		public decimal Amount03 { get; set; }
		public decimal Amount04 { get; set; }
		public decimal Amount05 { get; set; }
		public decimal Amount06 { get; set; }
		public decimal Amount07 { get; set; }
		public decimal Amount08 { get; set; }
		public decimal Amount09 { get; set; }
		public decimal Amount10 { get; set; }
		public decimal Amount11 { get; set; }
		public decimal Amount12 { get; set; }
		public decimal Amount13 { get; set; }
		public decimal TotalAmount { get { return Amount01 + Amount02 + Amount03 + Amount04 + Amount05 + Amount06 + Amount07 + Amount08 + Amount09 + Amount10 + Amount11 + Amount12 + Amount13; } }
	}

	public class GeneralLedgerSettingViewModel {
		public int SettingId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Division")]
		public GeneralLedgerDivision GeneralLedgerDivision { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Client Control Account")]
		public int? ClientControlAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Debtor Control Account")]
		public int? DebtorControlAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Creditor Control Account")]
		public int? CreditorControlAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "BSP Accrual Account")]
		public int? BspAccrualAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Supplier Returns Account")]
		public int? SupplierReturnsAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Credit Card Charge Account")]
		public int? CreditCardChargeAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Commission Account")]
		public int? CommissionAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Override Commission Account")]
		public int? OverrideCommissionAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Other Commission Account")]
		public int? OtherCommissionAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "SalesAccountTaxLabel", ResourceType = typeof(Resource))]
		public int? SalesTaxAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "PurchasesAccountTaxLabel", ResourceType = typeof(Resource))]
		public int? PurchasesTaxAccountId { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Fiscal Year Start Date")]
		public DateTime? FiscalYearStartDate { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Fiscal Year Description")]
		public string FiscalYearStartDateName { get; set; }
	}

	public class GeneralLedgerSettingDetailViewModel {
		public int SettingDetailId { get; set; }
		public int SettingId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "End Date")]
		public DateTime? FiscalPeriodEndDate { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Description")]
		public string FiscalPeriodEndDateName { get; set; }

		[Display(Name = "Admin Closed")]
		public bool IsAdminClosed { get; set; }

		[Display(Name = "User Closed")]
		public bool IsUserClosed { get; set; }
	}

	public class ChartOfAccountExportModel {
		public string Agency { get; set; }
		public string Code { get; set; }
		public string AltReportingCode { get; set; }
		public string Account { get; set; }
		public string ChartOfAccountType { get; set; }
		public string AccountCategory { get; set; }
		public string RowType { get; set; }
		public string ChartOfAccountTransactionType { get; set; }
		public string TotalLevel { get; set; }
		public bool IsTaxApplicable { get; set; }
		public string UserRoles { get; set; }
	}

	public class GeneralLedgerExportModel {
		public string Agency { get; set; }
		public string Code { get; set; }
		public string AltReportingCode { get; set; }
		public string Account { get; set; }
		public string ChartOfAccountType { get; set; }
		public string AccountCategory { get; set; }
		public string RowType { get; set; }
		public string ChartOfAccountTransactionType { get; set; }
		public string TotalLevel { get; set; }
		public bool IsTaxApplicable { get; set; }
		public string UserRoles { get; set; }
		public decimal PeriodCurrentYear { get; set; }
		public decimal PeriodPreviousYear { get; set; }
		public decimal YtdBudget { get; set; }
		public decimal YtdCurrentYear { get; set; }
		public decimal YtdPreviousYear { get; set; }
		public decimal PeriodVariance { get { return PeriodCurrentYear - PeriodPreviousYear; } }
		public decimal YtdVariance { get { return YtdCurrentYear - YtdPreviousYear; } }
		public decimal PeriodBudgetVariance { get { return PeriodCurrentYear - PeriodBudget; } }
		public decimal YtdBudgetVariance { get { return YtdCurrentYear - YtdBudget; } }
		public decimal PeriodBudget { get; set; }
	}
}
