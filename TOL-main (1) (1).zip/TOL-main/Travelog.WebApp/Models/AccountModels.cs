﻿using System;
using System.ComponentModel.DataAnnotations;
using Travelog.Biz;
using Travelog.Biz.Dao.Admin;
using Travelog.Biz.Enums;
using Travelog.Biz.Resources;

namespace Travelog.WebApp.Models {
	public class CustomerViewModel {
		public int CustomerId { get; set; }
		public CustomerStatus CustomerStatus { get; set; }
		public CustomerAccountStatus CustomerAccountStatus { get { return Customer.GetCustomerAccountStatus(OverdueAccountBalance, PayableNowAccountBalance); } }
		public bool SystemGenDocRequiresApproval { get; set; }
        public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Editable(false)]
		[Display(Name = "Legal Name")]
		public string LegalName { get; set; }

		[Editable(false)]
		[Display(Name = "Business Name")]
		public string BusinessName { get; set; }

		[Editable(false)]
		[Display(Name = "Location")]
		public string Location { get; set; }

		[Editable(false)]
		[Display(Name = "TaxNoExtLabel", ResourceType = typeof(Resource))]
		public string TaxNo { get; set; }

        [Editable(false)]
        [Display(Name = "Agency Type")]
		public AgencyType AgencyType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Concurrent Users")]
        public int UserCount { get; set; }

        [Editable(false)]
        [Display(Name = "Contact Type")]
		public CustomerContactType CustomerContactType { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Subscription Account")]
		public int? SubscriptionChartOfAccountId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Sabre EPR Account")]
		public int? SabreEprChartOfAccountId { get; set; }

		[Editable(false)]
		[Display(Name = "Status")]
		public string CustomerStatusDescription { get { return CustomerStatus.GetEnumDescription(); } }

        [Display(Name = "Exclude from billing")]
        public bool ExcludeFromBilling { get; set; }

        [Display(Name = "Allow remote assistance connections by Travelog support")]
		public bool AllowRemoteAssistance { get; set; }

		[DataType(DataType.Text, ErrorMessage = "Address is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Address is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Address")]
		public string Address1 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "Address is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Address is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		public string Address2 { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "City")]
		public string Locality { get; set; }

		[DataType(DataType.Text, ErrorMessage = "State/Province/Region is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "State/Province/Region is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "State")]
		public string Region { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Post Code")]
		public string PostCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Country")]
		public string CountryCode { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string BillingContactName { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Phone")]
		public string BillingContactPhone { get; set; }

		[DataType(DataType.EmailAddress)]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Email")]
		public string BillingContactEmail { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string TechnicalContactName { get; set; }

		[DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Phone")]
		public string TechnicalContactPhone { get; set; }

		[DataType(DataType.EmailAddress)]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Email")]
		public string TechnicalContactEmail { get; set; }

        [Editable(false)]
		[Display(Name = "Commencement Date")]
		public DateTime? StartDate { get; set; }

		[Editable(false)]
		[Display(Name = "Current Balance")]
		public decimal CurrentAccountBalance { get; set; }

		[Editable(false)]
		[Display(Name = "Overdue Balance")]
		public decimal OverdueAccountBalance { get; set; }

		[Editable(false)]
		[Display(Name = "Payable Now")]
		public decimal PayableNowAccountBalance { get; set; }

		[Editable(false)]
		[Display(Name = "Account Status")]
		public string CustomerAccountStatusDescription { get { return CustomerAccountStatus.GetEnumDescription(); } }
	}

	public class CustomerPaymentMethodViewModel {
		public int CustomerPaymentMethodId { get; set; }
		public int CustomerPaymentMethodCustomerId { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Card No")]
		public string CustomerPaymentMethodCardNo { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Cardholder Name")]
		public string CustomerPaymentMethodCardholderName { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Expiry Date")]
		public DateTime? CustomerPaymentMethodExpiryDate { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.IntegerPositive, ErrorMessage = "{0} is invalid.")]
		[StringLength(4, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "CVN")]
		public string CustomerPaymentMethodCvn { get; set; }

		[Display(Name = "Active")]
		public bool CustomerPaymentMethodIsActive { get; set; }

		[Display(Name = "Recurring Payment")]
		public bool CustomerPaymentMethodIsRecurringPayment { get; set; }
	}

    public class CustomerPricingViewModel {
        public int CustomerPricingId { get; set; }
        public int CustomerPricingCustomerId { get; set; }
        public string CustomerPricingBillingCycleDescription { get { return CustomerPricingBillingCycle.GetEnumDescription(); } }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Date From")]
        public DateTime CustomerPricingDateFrom { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Date To")]
        public DateTime? CustomerPricingDateTo { get; set; }

        [Display(Name = "Billing Cycle")]
        public BillingCycle CustomerPricingBillingCycle { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Users")]
        public int CustomerPricingUserCount { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Amount")]
        public decimal CustomerPricingUserCharge { get; set; }
    }

    public class CustomerTransactionViewModel {
		public int CustomerTransactionId { get; set; }
		public int CustomerTransactionCustomerId { get; set; }
		public CustomerTransactionStatus CustomerTransactionStatus { get; set; }
        public CustomerTransactionApprovalStatus CustomerTransactionApprovalStatus { get; set; }
        public string CustomerTransactionStatusDescription { get { return CustomerTransactionStatus.GetEnumDescription(); } }
        public string CustomerTransactionTypeDescription { get { return CustomerTransactionType.GetEnumDescription(); } }
        public string CustomerTransactionNo { get { return CustomerTransactionId.ToString("D8"); } }
        public int CustomerTransactionDebtorId { get; set; }
        public bool IsReceiptItem { get; set; }
        public bool IsInvoiceItem { get; set; }
        public bool IsDebit { get; set; }
		public decimal? Debit { get; set; }
		public decimal? Credit { get; set; }
        public bool IsUserCreated { get; set; }
        public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Transaction Type")]
		public CustomerTransactionType CustomerTransactionType { get; set; }

        [Display(Name = "Receipt No")]
        public int? CustomerTransactionReceiptId { get; set; }

        [Display(Name = "Invoice No")]
        public int? CustomerTransactionInvoiceId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Date From")]
		public DateTime? CustomerTransactionDateFrom { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Date To")]
		public DateTime? CustomerTransactionDateTo { get; set; }

		[DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Date Due")]
		public DateTime? CustomerTransactionDateDue { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Users")]
		public int CustomerTransactionUserCount { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "User Charge")]
		public decimal CustomerTransactionUserCharge { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Gross Amount")]
		public decimal CustomerTransactionAmountGross { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "TaxLabel", ResourceType = typeof(Resource))]
		public decimal CustomerTransactionTax { get; set; }

		[Editable(false)]
		[Display(Name = "Balance")]
		public decimal Balance { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(8, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Invoice No")]
		public string CustomerTransactionDocumentNo { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Invoice Description")]
		public string CustomerTransactionDescription { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Payment Txn ID")]
        public int PaymentTransactionId { get; set; }
    }

    public class PricingViewModel {
        public int PricingId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Users")]
        public int PricingUserCount { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Amount")]
        public decimal PricingUserCharge { get; set; }
    }

    public class UserAccountViewModel {
		private string theme;

		public string UserId { get; set; }
		public string UserName { get; set; }
		public string RoleName { get; set; }
		public string ConsultantName { get; set; }
		public string DefaultAgencyName { get; set; }
        public bool IsGlobalUser { get; set; }
        public bool IsOnline { get; set; }
		public string FullNameWithEmail { get; set; }

		[Editable(false)]
		public DateTime? LastSignInTime { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Name")]
		public string FullName { get; set; }

		[DataType(DataType.EmailAddress)]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
		[StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Email")]
		public string Email { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Role")]
		public string RoleId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Consultant")]
		public int ConsultantId { get; set; }

		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Default Agency")]
		public int DefaultAgencyId { get; set; }

		[DataType(DataType.Text)]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Theme")]
		public string Theme { get { return theme ?? "light"; } set { theme = value; } }

		[Display(Name = "Form Validation Method")]
		public FormValidationMethod FormValidationMethod { get; set; }

		[Display(Name = "Other Agencies")]
		public bool OtherAgencies { get; set; }

		[Display(Name = "Other Consultants")]
		public bool OtherConsultants { get; set; }

        [Display(Name = "Two-Factor Enabled")]
        public bool IsTwoFactorEnabled { get; set; }

        [Display(Name = "Support Provider")]
		public bool IsSupportUser { get; set; }

		[Display(Name = "Super User")]
		public bool IsSuperUser { get; set; }

		[Display(Name = "Inactive")]
		public bool Inactive { get; set; }

		[Display(Name = "Locked")]
		public bool IsLocked { get; set; }

		[Display(Name = "Force Sign-Out")]
		public bool ForceSignOut { get; set; }
	}

	public class UserAccountRoleViewModel {
		public string UserId { get; set; }
		public int CustomerId { get; set; }
		public string RoleId { get; set; }
		public string CustomerName { get; set; }
		public string RoleName { get; set; }
		public bool Inactive { get; set; }
	}

	public class SignInViewModel {
		public string UserId { get; set; }
		public TwoFactorAuthenticationMethod TwoFactorAuthenticationMethod { get; set; }
		public int CustomerCount { get; set; }

		[DataType(DataType.Text)]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "User Name")]
		public string UserName { get; set; }

		[DataType(DataType.Password)]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Password")]
		public string Password { get; set; }

		[Display(Name = "Remember User Name")]
		public bool IsPersistent { get; set; }

		[DataType(DataType.Text)]
		[Display(Name = "Code")]
		public string AuthenticationCodeGoogle { get; set; }

		[DataType(DataType.Text)]
		[Display(Name = "Code")]
		public string AuthenticationCodeEmail { get; set; }
	}

    public class PrivacySettingsViewModel {
        public int CustomerId { get; set; }

        [Display(Name = "Allow Remote Assistance")]
        public bool AllowRemoteAssistance { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Role")]
        public string SupportProviderRoleId { get; set; }
    }

    public class ChangePasswordViewModel {
		[DataType(DataType.Password)]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Current Password")]
		public string OldPassword { get; set; }

		[DataType(DataType.Password)]
		[Required(ErrorMessage = "{0} is required.")]
		[StringLength(AppConstants.PasswordMaxLength, ErrorMessage = "{0} must be between {2} and {1} characters in length.", MinimumLength = AppConstants.PasswordMinLength)]
		[Display(Name = "New Password")]
		public string NewPassword { get; set; }

		[DataType(DataType.Password)]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Confirm New Password")]
		[Compare("NewPassword", ErrorMessage = "New Password and Confirm New Password do not match.")]
		public string ConfirmPassword { get; set; }
	}

	public class RecoverPasswordViewModel {
		[DataType(DataType.EmailAddress)]
		[Required(ErrorMessage = "{0} is required.")]
		[EmailAddress(ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Email")]
		public string Email { get; set; }
	}

	public class ResetPasswordViewModel {
		[DataType(DataType.EmailAddress)]
		[Required(ErrorMessage = "{0} is required.")]
		[EmailAddress(ErrorMessage = "{0} is invalid.")]
		[Display(Name = "Email")]
		public string Email { get; set; }

		[DataType(DataType.Password)]
		[Required(ErrorMessage = "{0} is required.")]
		[StringLength(AppConstants.PasswordMaxLength, ErrorMessage = "{0} must be between {2} and {1} characters in length.", MinimumLength = AppConstants.PasswordMinLength)]
		[Display(Name = "New Password")]
		public string NewPassword { get; set; }

		[DataType(DataType.Password)]
		[Required(ErrorMessage = "{0} is required.")]
		[Display(Name = "Confirm New Password")]
		[Compare("NewPassword", ErrorMessage = "New Password and Confirm New Password do not match.")]
		public string ConfirmPassword { get; set; }

		public string Token { get; set; }
	}

    [Serializable]
	public class MenuViewModel {
		public int MenuBaseId { get; set; }
		public int ParentId { get; set; }
		public string Item { get; set; }
		public string NavigateUrl { get; set; }
		public MenuPageType MenuPageType { get; set; }
		public bool ValidateItem { get; set; }
		public bool ExcludeFromHistory { get; set; }
		public bool IsExpanded { get; set; }
		public bool IsNewWindow { get; set; }
		public bool IsVisible { get; set; }
		public AccessLevel AccessLevel { get; set; }
	}

	public class MenuRoleViewModel {
		public int MenuBaseRoleId { get; set; }
		public int ParentId { get; set; }
		public string Item { get; set; }
		public string NavigateUrl { get; set; }
		public AccessLevel DefaultAccessLevel { get; set; }
		public AccessLevel AccessLevel { get; set; }
	}

	public class AuditLogViewModel {
		public int AuditLogId { get; set; }
		public int AuditLogDetailId { get; set; }
		public string Entity { get; set; }
		public string Type { get; set; }
		public bool SuperUser { get; set; }
		public string OriginalValues { get; set; }
		public string CurrentValues { get; set; }
		public DateTime CreationTime { get; set; }
		public string CreationUser { get; set; }
		public string CreationTimeString { get { return string.Format("{0:g}", CreationTime); } }
	}

	public class RequestSupportViewModel {
		[DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Summary")]
		public string RequestSupportIssueSummary { get; set; }

		[DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
		[Required(ErrorMessage = "{0} is required.")]
		[RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
		[StringLength(1000, ErrorMessage = "{0} can be no longer than {1} characters.")]
		[Display(Name = "Description")]
		public string RequestSupportIssueDescription { get; set; }

		[Display(Name = "Include Screenshot")]
		public bool RequestSupportIncludeScreenshot { get; set; }
	}

	public class CustomerTransactionExportModel {
		public string TransactionType { get; set; }
		public string Status { get; set; }
		public DateTime DateFrom { get; set; }
		public DateTime DateTo { get; set; }
		public DateTime? DateDue { get; set; }
		public int UserCount { get; set; }
		public decimal UserCharge { get; set; }
		public decimal Debit { get; set; }
		public decimal Credit { get; set; }
		public decimal Balance { get; set; }
		public string DocumentNo { get; set; }
		public string IsUserCreated { get; set; }
	}

	public class AuditLogExportModel {
		public string Entity { get; set; }
		public string Type { get; set; }
		public string OriginalValues { get; set; }
		public string CurrentValues { get; set; }
		public DateTime ModifiedDate { get; set; }
		public string ModifiedBy { get; set; }
	}
}