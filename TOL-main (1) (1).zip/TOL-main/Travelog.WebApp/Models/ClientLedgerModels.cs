﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Kendo.Mvc.UI;
using Travelog.Biz;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Resources;

namespace Travelog.WebApp.Models {
    public class ProfileListModel {
        public int? ProfileId { get; set; }
        public string Code { get; set; }
        public string AccountName { get; set; }
        public string FullName { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNo { get; set; }
        public string Email { get; set; }
        public DateTime? BirthDate { get; set; }
    }

    public class TripLineListModel {
        public int TripLineId { get; set; }
        public string DocumentNo { get; set; }
        public Trip Trip { get; set; }
        public Crs Crs { get; set; }
        public string CrsPnrRef { get; set; }
    }

    public class ProfileViewModel {
        public int ProfileId { get; set; }
        public string FullName { get; set; }
        public string FullNameWithEmail { get; set; }
        public string AccountName { get; set; }
        public string PhoneNo { get; set; }
        public string MaritalStatusDescription { get { return MaritalStatus.GetEnumDescription(); } }
        public string BirthDateString { get { return BirthDate == null ? string.Empty : ((DateTime)BirthDate).ToShortDateStringExt(); } }
        public string BirthCountry { get; set; }
        public string Nationality { get; set; }
        public string Debtor { get; set; }
        public string Consultant { get; set; }
        public string Agency { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Display(Name = "Title")]
        public string Title { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(10, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Code")]
        public string Code { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "First Name(s)")]
        public string FirstName { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Phone Home")]
        public string PhoneHome { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Phone Work")]
        public string PhoneWork { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Mobile")]
        public string Mobile { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Fax")]
        public string Fax { get; set; }

        [DataType(DataType.EmailAddress, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Marital Status")]
        public MaritalStatus MaritalStatus { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Birth Date")]
        public DateTime? BirthDate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Birth Country")]
        public int? BirthCountryId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Nationality Country")]
        public int? NationalityId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(30, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Occupation")]
        public string Occupation { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(30, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Business Type")]
        public string BusinessType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Debtor")]
        public int? DebtorId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Consultant")]
        public int? ConsultantId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Agency")]
        public int? AgencyId { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Rules & Regulations")]
        public string Rules { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Remarks")]
        public string Remarks { get; set; }
    }

    public class ProfileAirlineViewModel {
        public int ProfileAirlineId { get; set; }
        public int ProfileId { get; set; }
        public string Passenger { get; set; }
        public string Airline { get; set; }
        public string AirlineSeatingDescription { get { return AirlineSeating.GetEnumDescription(); } }
        public string FlightClassDescription { get { return FlightClass.GetEnumDescription(); } }
        public string TravelZoneDescription { get { return TravelZone.GetEnumDescription(); } }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger")]
        public int? PassengerId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Airline")]
        public int? AirlineId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Seating")]
        public AirlineSeating AirlineSeating { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Class")]
        public FlightClass FlightClass { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Travel Zone")]
        public TravelZone TravelZone { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(10, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Seat No")]
        public string SeatNo { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string Comments { get; set; }
    }

    public class ProfileClubMembershipViewModel {
        public int ProfileClubMembershipId { get; set; }
        public int ProfileId { get; set; }
        public string Passenger { get; set; }
        public string ClubMembership { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger")]
        public int? PassengerId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Club Membership")]
        public int? ClubMembershipId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Membership No")]
        public string ClubMembershipNo { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(10, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "PIN")]
        public string ClubMembershipPin { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Points Earned")]
        public int PointsEarned { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string Comments { get; set; }
    }

    public class ProfileFutureDestinationViewModel {
        public int ProfileFutureDestinationId { get; set; }
        public int ProfileId { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger")]
        public int? PassengerId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Destination")]
        public int? DestinationId { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string FutureDestinationComments { get; set; }
    }

    public class ProfileLeisureActivityViewModel {
        public int ProfileLeisureActivityId { get; set; }
        public int ProfileId { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger")]
        public int? PassengerId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Leisure Activity")]
        public int? LeisureActivityId { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string LeisureActivityComments { get; set; }
    }

    public class ProfileSpecialRequestViewModel {
        public int ProfileSpecialRequestId { get; set; }
        public int ProfileId { get; set; }
        public string Passenger { get; set; }
        public string SpecialRequest { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger")]
        public int? PassengerId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Special Request")]
        public int? SpecialRequestId { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string SpecialRequestComments { get; set; }
    }

    public class ProfileSupplierViewModel {
        public int ProfileSupplierId { get; set; }
        public int ProfileId { get; set; }
        public string Passenger { get; set; }
        public string SupplierChain { get; set; }
        public string Supplier { get; set; }
        public string SupplierService { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger")]
        public int? PassengerId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier Chain")]
        public int? SupplierChainId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier")]
        public int? SupplierId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Service")]
        public int? SupplierServiceId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(25, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Reference No")]
        public string ReferenceNo { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal Rate { get; set; }

        [Display(Name = "Smoking")]
        public bool IsSmoking { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string Comments { get; set; }
    }

    public class TripViewModel {
        public TripViewModel() {
            AddressViewModel = new AddressViewModel();
        }

        public AddressViewModel AddressViewModel { get; set; }
        public int TripId { get; set; }
        public int ProfileId { get; set; }
        public string TripNo { get; set; }
        public string ProfileCode { get; set; }
        public string FullName { get; set; }
        public string FullNameWithEmail { get; set; }
        public string PhoneNo { get; set; }
        public string Consultant { get; set; }
        public string Agency { get; set; }
        public string Debtor { get; set; }
        public string ClientAccountTypeDescription { get { return string.Format("{0}{1}", ClientAccountType.GetEnumDescription(), IsIncomplete ? @"&nbsp;<span class=""k-icon k-i-close-circle"" style=""font-size: 1em"" title=""Incomplete""></span>" : IsCancellation ? @"&nbsp;<span class=""k-icon k-i-cancel"" style=""font-size: 1em"" title=""Cancellation""></span>" : IsBooking ? @"&nbsp;<span class=""k-icon k-i-check-circle"" style=""font-size: 1em"" title=""Booking""></span>" : string.Empty); } }
        public string BookingTypeDescription { get { return BookingType.GetEnumDescription(); } }
        public string SerkoOnlineBookingStatusDescription { get { return SerkoOnlineBookingStatus.GetEnumDescription(); } }
        public string TripDepartureDateString { get { return TripDepartureDate == null ? string.Empty : ((DateTime)TripDepartureDate).ToShortDateStringExt(); } }
        public Crs TripCrs { get; set; }
        public bool IsBooking { get; set; }
        public bool IsCancellation { get; set; }
        public bool IsIncomplete { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(10, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Client Code")]
        public string Code { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Account Type")]
        public ClientAccountType ClientAccountType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Booking Type")]
        public BookingType BookingType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Booking Status")]
        public SerkoOnlineBookingStatus SerkoOnlineBookingStatus { get; set; }

        [Display(Name = "Title")]
        public string Title { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "First Name(s)")]
        public string FirstName { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Phone Home")]
        public string PhoneHome { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Phone Work")]
        public string PhoneWork { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Mobile")]
        public string Mobile { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Fax")]
        public string Fax { get; set; }

        [DataType(DataType.EmailAddress, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Marital Status")]
        public MaritalStatus MaritalStatus { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(10, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "User Ref No")]
        public string UserReferenceNo { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(30, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Occupation")]
        public string Occupation { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(30, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Business Type")]
        public string BusinessType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Consultant")]
        public int? ConsultantId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Agency")]
        public int? AgencyId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Agent")]
        public int? AgentId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Source")]
        public int? SourceId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Currency")]
        public int? TripCurrencyId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Group")]
        public int? GroupId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Class")]
        public int? ClassId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Category")]
        public int? CategoryId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Destination")]
        public int? DestinationId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Main City")]
        public int? MainCityId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Location")]
        public int? LocationId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Debtor")]
        public int? DebtorId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Contact")]
        public int? DebtorBookedById { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Authorised By")]
        public int? DebtorAuthorisedById { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Order No")]
        public string DebtorOrderNo { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Travel Reason")]
        public string DebtorTravelReason { get; set; }

        [Display(Name = "Video Conferencing Considered")]
        public bool DebtorVideoConferencingConsidered { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Reason Rejected")]
        public string DebtorVideoConferencingReasonRejected { get; set; }

        [Editable(false)]
        [Display(Name = "Adults")]
        public int PaxAdult { get; set; }

        [Editable(false)]
        [Display(Name = "Children")]
        public int PaxChild { get; set; }

        [Editable(false)]
        [Display(Name = "Infants")]
        public int PaxInfant { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Departure")]
        public DateTime? TripDepartureDate { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Return")]
        public DateTime? TripReturnDate { get; set; }

        [Display(Name = "Monetary Values are Locked")]
        public bool TripIsLocked { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Date Due")]
        public DateTime? BalanceDueDate { get; set; }

        [Editable(false)]
        [Display(Name = "Balance Due")]
        public decimal BalanceDue { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal TripExchangeRate { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Rules & Regulations")]
        public string Rules { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Remarks")]
        public string Remarks { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Notes")]
        public string Notes { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Comments")]
        public string ChecklistComments { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Contact Method")]
        public ContactMethod ChecklistContactMethod { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Contact By")]
        public int? ChecklistContactById { get; set; }

        [Display(Name = "Follow-Up Date")]
        public DateTime? ChecklistFollowUpDate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Contact Method")]
        public ContactMethod CancellationContactMethod { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Cancelled By")]
        public int? CancellationById { get; set; }
    }

    public class TripPaymentScheduleViewModel {
        public int TripPaymentScheduleId { get; set; }
        public int TripPaymentScheduleTripId { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Date")]
        public DateTime? TripPaymentScheduleTransactionDate { get; set; }

        [Display(Name = "Amount")]
        public decimal TripPaymentScheduleAmount { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Description")]
        public string TripPaymentScheduleDescription { get; set; }

        [Display(Name = "Completed")]
        public bool TripPaymentScheduleIsCompleted { get; set; }
    }

    public class TripChecklistViewModel {
        public int TripChecklistId { get; set; }
        public int TripId { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Editable(false)]
        [Display(Name = "Item")]
        public string Name { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Date")]
        public DateTime? ActionDate { get; set; }
    }

    public class TripChecklistCalendarViewModel : ISchedulerEvent {
        public int TripId { get; set; }
        public string TripNo { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public ContactMethod ContactMethod { get; set; }
        public int ContactById { get; set; }
        public DateTime? FollowUpDate { get; set; }
        public string Comments { get; set; }
        public string BackgroundColor { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public bool IsAllDay { get; set; }
        public string StartTimezone { get; set; }
        public string EndTimezone { get; set; }
        public string RecurrenceRule { get; set; }
        public string RecurrenceException { get; set; }
    }

    public class TripItineraryViewModel {
        public int TripItineraryId { get; set; }
        public int TripItineraryTripId { get; set; }
        public string TripItineraryPassengerIds { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Name")]
        public string TripItineraryName { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }
    }

    public class TripItineraryDetailViewModel {
        public int TripItineraryDetailId { get; set; }
        public int TripItineraryId { get; set; }
        public int TripItineraryDetailTripLineId { get; set; }
        public int TripItineraryDetailTripLineAirSegmentId { get; set; }
        public TripLineType TripItineraryDetailTripLineType { get; set; }
        public string TripItineraryDetailStartDateString { get { return TripItineraryDetailStartDate == null ? string.Empty : ((DateTime)TripItineraryDetailStartDate).ToShortDateStringExt(); } }
        public string TripItineraryDetailEndDateString { get { return TripItineraryDetailEndDate == null ? string.Empty : ((DateTime)TripItineraryDetailEndDate).ToShortDateStringExt(); } }
        public string TripItineraryDetailTripLineTypeDescription { get { return TripItineraryDetailTripLineType.GetEnumDescription(); } }
        public DateTime? TripItineraryDetailStartDate { get; set; }
        public DateTime? TripItineraryDetailEndDate { get; set; }
        public string TripItineraryDetailTime { get; set; }
        public string TripItineraryDetailDescription { get; set; }
        public int TripItineraryDetailSeqNo { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }
    }

    public class TripItineraryPassengerViewModel {
        public int TripItineraryPassengerId { get; set; }
        public int TripItineraryId { get; set; }
        public int TripItineraryPassengerPassengerId { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }
    }

    public class TripLineViewModel {
        public int TripLineId { get; set; }
        public int TripId { get; set; }
        public ClientAccountType ClientAccountType { get; set; }
        public string TripLineTypeDescription { get { return TripLineType.GetEnumDescription(); } }
        public string TripLineStatusDescription { get { return TripLineStatus.GetEnumDescription(); } }
        public decimal AmountPaid { get; set; }
        public bool IsLocked { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type")]
        public TripLineType TripLineType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Status")]
        public TripLineStatus TripLineStatus { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Personal Amount")]
        public decimal PersonalTravelAmount { get; set; }

        [Display(Name = "Print on Quote")]
        public bool PrintOnQuote { get; set; }

        [Display(Name = "Print on Confirmation")]
        public bool PrintOnConfirmation { get; set; }

        [Display(Name = "Print on Itinerary")]
        public bool PrintOnItinerary { get; set; }

        [Display(Name = "Print on Statement")]
        public bool PrintOnStatement { get; set; }
    }

    public class TripLineInformationViewModel {
        public int TripLineId { get; set; }
        public int TripId { get; set; }
        public TripLineType TripLineType { get; set; }
        public ClientAccountType ClientAccountType { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Creditors { get; set; }
        public string Description { get; set; }
        public string ReceiptInfo { get; set; }
        public string PaymentInfo { get; set; }
        public string InvoiceInfo { get; set; }
        public int PaxNo { get; set; }
        public int? PackageNo { get; set; }
        public decimal Commission { get; set; }
        public decimal Discount { get; set; }
        public decimal Markup { get; set; }
        public decimal Gross { get; set; }
        public decimal SupplierNet { get; set; }
        public decimal SellingPrice { get; set; }
        public decimal CostToClient { get; set; }
        public decimal ClientToAgencyReceivable { get; set; }
        public decimal ClientToAgencyReceived { get; set; }
        public decimal AmountReceivable { get; set; }
        public decimal AmountReceived { get; set; }
        public decimal AmountPayable { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal AmountInvoiceable { get; set; }
        public decimal AmountInvoiced { get; set; }
        public decimal AmountInvoicedWithPayment { get; set; }
        public decimal PersonalTravelAmount { get; set; }
        public decimal EffectiveAmountReceivable { get { return AmountReceivable == 0 ? ClientToAgencyReceivable : AmountReceivable; } }
        public decimal EffectiveAmountReceived { get { return AmountReceived == 0 ? ClientToAgencyReceived : AmountReceived; } }
        public int VoucherId { get; set; }
        public VoucherType VoucherType { get; set; }
        public PaymentClass VoucherPaymentClass { get; set; }
        public string VoucherDocumentNo { get; set; }
        public decimal VoucherAmount { get; set; }
        public decimal Yield { get; set; }
        public bool IsAllCreditCardPayment { get; set; }
        public bool CreditCardNotPaid { get; set; }
        public bool DoNotGenerateInvoiceLine { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        public string StartDateString { get { return StartDate == null ? string.Empty : ((DateTime)StartDate).ToShortDateStringExt(); } }
        public string EndDateString { get { return EndDate == null ? string.Empty : ((DateTime)EndDate).ToShortDateStringExt(); } }
        public string TripLineTypeDescription { get { return TripLineType.GetEnumDescription(); } }

        public string ReceiptStatus { get { return AmountReceivable == 0 || ((AmountReceivable - AmountReceived - AmountInvoicedWithPayment == 0) && AmountReceivable != 0) || VoucherPaymentClass == PaymentClass.PaidDirect ? "F" : AmountReceived + AmountInvoicedWithPayment != 0 ? "P" : "N"; } }
        public string PaymentStatus { get { return (AmountPaid != 0 || PaymentInfo.Contains("Amount:")) && (AmountPaid - AmountPayable == 0 || VoucherPaymentClass == PaymentClass.PaidDirect) ? "F" : (AmountPaid != 0 || PaymentInfo.Contains("Amount:")) ? "P" : "N"; } }
        public string InvoiceStatus { get { return (AmountInvoiced != 0 || InvoiceInfo.Contains("Amount:")) && AmountInvoiced - AmountInvoiceable == 0 ? "F" : AmountInvoiced != 0 || InvoiceInfo.Contains("Amount:") ? "P" : (AmountInvoiceable != 0 || InvoiceInfo.Contains("Amount:")) && DoNotGenerateInvoiceLine ? "D" : "N"; } }
        public string VoucherStatus { get { return VoucherId > 0 ? "Y" : "N"; } }

        private string ReceiptStatusDescription { get { return string.Format("{1}{0}{2}", Environment.NewLine, ReceiptInfo, ReceiptStatus == "N" ? string.Format("Amount Receivable: {0:c2}", AmountReceivable) : ReceiptStatus == "P" ? string.Format("Amount Received: {0:c2} Balance Due: {1:c2}", AmountReceived, AmountReceivable - AmountReceived - AmountInvoicedWithPayment) : string.Format("Amount Received: {0:c2}", AmountReceived)); } }
        private string PaymentStatusDescription { get { return string.Format("{1}{0}{2}", Environment.NewLine, PaymentInfo, PaymentStatus == "N" ? string.Format("Amount Payable: {0:c2}", AmountPayable) : PaymentStatus == "P" ? string.Format("Amount Paid: {0:c2} Balance Due: {1:c2}", AmountPaid, AmountPayable - AmountPaid) : string.Format("Amount Paid: {0:c2}", VoucherPaymentClass == PaymentClass.PaidDirect ? VoucherAmount : AmountPaid)); } }
        private string InvoiceStatusDescription { get { return string.Format("{1}{0}{2}", Environment.NewLine, InvoiceInfo, InvoiceStatus == "N" ? string.Format("Amount Invoiceable: {0:c2}", AmountInvoiceable) : InvoiceStatus == "D" ? "Do Not Invoice" : InvoiceStatus == "P" ? string.Format("Amount Invoiced: {0:c2} Amount Remaining: {1:c2}", AmountInvoiced, AmountInvoiceable - AmountInvoiced - PersonalTravelAmount) : string.Format("Amount Invoiced: {0:c2}", AmountInvoiced)); } }
        private string VoucherStatusDescription { get { return VoucherStatus == "N" ? "No Voucher" : string.Format("Voucher No: {1}{0}Type: {2}{0}Value: {3:c2}", Environment.NewLine, VoucherDocumentNo, VoucherType.GetEnumDescription(), VoucherAmount); } }

        private string ReceiptCss { get { return ReceiptStatus == "N" ? "tl-receipt-none" : ReceiptStatus == "P" ? "tl-receipt-partial" : "tl-receipt-full"; } }
        private string PaymentCss { get { return PaymentStatus == "N" ? "tl-payment-none" : PaymentStatus == "P" ? "tl-payment-partial" : "tl-payment-full"; } }
        private string InvoiceCss { get { return InvoiceStatus == "N" ? "tl-invoice-none" : InvoiceStatus == "D" || InvoiceStatus == "P" ? "tl-invoice-partial" : "tl-invoice-full"; } }
        private string VoucherCss { get { return VoucherStatus == "N" ? "tl-voucher-none" : "tl-voucher-full"; } }

        public string DescriptionWithStatus { get { return string.Format("<div class='tl-trip-line'><div class='tl-text' title='Creditors: {0}'>{1}</div><div class='tl-receipt {2}' title='{3}'>{4}</div><div class='tl-payment {5}' title='{6}'>{7}</div>{8}<div class='tl-voucher {9}' title='{10}' {12}>{11}</div></div>", Creditors, Description, ReceiptCss, ReceiptStatusDescription, ReceiptStatus, PaymentCss, PaymentStatusDescription, PaymentStatus, InvoiceStatus == null ? string.Empty : string.Format("<div class='tl-invoice {0}' title='{1}'>{2}</div>", InvoiceCss, InvoiceStatusDescription, InvoiceStatus), VoucherCss, VoucherStatusDescription, VoucherStatus, VoucherId <= 0 ? string.Empty : string.Format(" onclick='Trip.VoucherEdit({0});'", VoucherId)); } }
    }

    public class TripLineDuplicateViewModel {
        public int ProfileId { get; set; }
        public int TripId { get; set; }
        public int[] TripLineIds { get; set; }
        public string SourceGridId { get; set; }
        public bool IsTripDuplication { get { return TripLineIds == Array.Empty<int>(); } }
    }

    public class TripLineAirViewModel {
        public TripLineViewModel TripLineViewModel { get; set; }

        public int TripLineId { get; set; }
        public string Airline { get; set; }
        public string Condition { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Airline")]
        public int? AirlineId { get; set; }

        [Editable(false)]
        [Display(Name = "Departure Date")]
        public DateTime? DepartureDate { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Ticketing Time Limit")]
        public DateTime? ValidUntilDate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "CRS")]
        public Crs TripLineAirCrs { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "PNR Ref")]
        public string TripLineAirCrsPnrRef { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Ref No")]
        public string ReferenceNo { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Condition")]
        public int? ConditionId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Service Description")]
        public string ServiceDescription { get; set; }

        [Editable(false)]
        [Display(Name = "Gross")]
        public decimal Gross { get; set; }

        [Editable(false)]
        [Display(Name = "Supplier Net")]
        public decimal SupplierNet { get; set; }

        [Editable(false)]
        [Display(Name = "Cost to Client")]
        public decimal CostToClient { get; set; }
    }

    public class TripLineAirSegmentListModel {
        public int TripLineId { get; set; }
        public int RelatedTripLineId { get; set; }
        public int TripId { get; set; }
        public string Description { get; set; }
    }

    public class TripLineAirSegmentViewModel {
        public int TripLineAirSegmentId { get; set; }
        public int TripLineId { get; set; }
        public string TripLineAirSegmentDepartureDateString { get { return TripLineAirSegmentDepartureDate == null ? string.Empty : ((DateTime)TripLineAirSegmentDepartureDate).ToShortDateStringExt(); } }
        public string DepartureDateStatusDescription { get { return DepartureDateStatus.GetEnumDescription(); } }
        public string TripStatusDescription { get { return DepartureDateStatus == DepartureDateStatus.ARNK ? "ARNK" : TripStatus == TripStatus.NotSpecified ? string.Empty : TripStatus.GetEnumDescription(); } }
        public string InternationalDateOffsetDescription { get { return InternationalDateOffset.GetEnumDescription(); } }
        public string AirportTypeDescription { get { return AirportType.GetEnumDescription(); } }
        public string DepartureCity { get; set; }
        public string ArrivalCity { get; set; }
        public string Aircraft { get; set; }
        public string AirPassengers { get; set; }
        public int SeqNo { get; set; }
        public string CrsKey { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Status")]
        public TripStatus TripStatus { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "From")]
        public int? DepartureCityId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "To")]
        public int? ArrivalCityId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Class")]
        public string Class { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(8, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Flight No")]
        public string FlightNo { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Departure Status")]
        public DepartureDateStatus DepartureDateStatus { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Departure Date")]
        public DateTime? TripLineAirSegmentDepartureDate { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
        [StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Check-In Time")]
        public string CheckInTime { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
        [StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Departure Time")]
        public string DepartureTime { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
        [StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Arrival Time")]
        public string ArrivalTime { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
        [StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Flight Time")]
        public string FlightTime { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "International Date")]
        public InternationalDateOffset InternationalDateOffset { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Distance Flown (km)")]
        public int DistanceFlownKm { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "CO2 Emissions (kg)")]
        public decimal CO2Emissions { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Airport Type")]
        public AirportType AirportType { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(2, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Departure Terminal")]
        public string DepartureTerminal { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(2, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Arrival Terminal")]
        public string ArrivalTerminal { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Airline PNR/Reloc")]
        public string TripLineAirSegmentAirlinePnr { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Aircraft")]
        public int? AircraftId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Operator")]
        public string Operator { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Meals Served")]
        public string Meals { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(512, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Transit Stops")]
        public string TransitStops { get; set; }

        //[Display(Name = "Meals Served")]
        //public IEnumerable<int> MealServedIds { get; set; }
    }

    public class TripLineAirSegmentQuickCompletionViewModel {
        public int TripLineAirSegmentId { get; set; }
        public int TripLineId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Alpha, ErrorMessage = "{0} is invalid.")]
        [StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "From")]
        public string DepartureCityCode { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Alpha, ErrorMessage = "{0} is invalid.")]
        [StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "To")]
        public string ArrivalCityCode { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Class")]
        public string Class { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(8, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Flight No")]
        public string FlightNo { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Departure Status")]
        public DepartureDateStatus DepartureDateStatus { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Departure Date")]
        public DateTime? TripLineAirSegmentDepartureDate { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
        [StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Departure Time")]
        public string DepartureTime { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
        [StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Arrival Time")]
        public string ArrivalTime { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "International Date")]
        public InternationalDateOffset InternationalDateOffset { get; set; }
    }

    public class TripLineAirPassengerViewModel {
        public int TripLineAirPassengerId { get; set; }
        public int TripLineId { get; set; }
        public int TripId { get; set; }
        public ClientAccountType ClientAccountType { get; set; }
        public string Creditor { get; set; }
        public string Supplier { get; set; }
        public string Passenger { get; set; }
        public string TripLineAirPassengerAirline { get; set; }
        public string FormOfPayment { get; set; }
        public string SaleType { get; set; }
        public string DiscountReason { get; set; }
        public string OfferedReason { get; set; }
        public string MarkupStrategy { get; set; }
        public decimal TripLineAirPassengerAmountPayable { get; set; }
        public bool IsBspAgent { get; set; }
        public bool TripLineAirPassengerIsLocked { get; set; }
        public string AirSegments { get; set; }
        public string OverrideBasisDescription { get { return OverrideBasis.GetEnumDescription(); } }
        public string BspEntryTypeDescription { get { return BspEntryType.GetEnumDescription(); } }
        public string TicketMethodDescription { get { return TicketMethod.GetEnumDescription(); } }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        public string TripLineAirPassengerAmountPaidLabelString {
            get {
                string cssClass;

                if (TripLineAirPassengerAmountPaid == 0 && TripLineAirPassengerAmountPayable != 0) {
                    cssClass = "tl-error-text";
                }
                else if (TripLineAirPassengerAmountPaid != 0 && TripLineAirPassengerAmountPaid != TripLineAirPassengerAmountPayable) {
                    cssClass = "tl-warning-text";
                }
                else {
                    cssClass = "tl-success-text";
                }

                return string.Format(@"<span class=""{0}"">Amount Paid:</span>", cssClass);
            }
        }

        public string TripLineAirPassengerAmountPaidString {
            get {
                string cssClass;

                if (TripLineAirPassengerAmountPaid == 0 && TripLineAirPassengerAmountPayable != 0) {
                    cssClass = "tl-error-text";
                }
                else if (TripLineAirPassengerAmountPaid != 0 && TripLineAirPassengerAmountPaid != TripLineAirPassengerAmountPayable) {
                    cssClass = "tl-warning-text";
                }
                else {
                    cssClass = "tl-success-text";
                }

                return string.Format(@"<span class=""{0}"">{1:c2}</span>", cssClass, TripLineAirPassengerAmountPaid);
            }
        }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Creditor")]
        public int? CreditorId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier")]
        public int? SupplierId { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Issue Date")]
        public DateTime? IssueDate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger")]
        public int? PassengerId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Airline")]
        public int? TripLineAirPassengerAirlineId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Form of Payment")]
        public int? FormOfPaymentId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale")]
        public int? SaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Personal Amount")]
        public decimal PersonalTravelAmount { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Full Fare")]
        public decimal FullFare { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Ticketed Fare")]
        public decimal TicketedFare { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Taxes/Non-Comm")]
        public decimal NonCommissionable { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Commission")]
        public decimal Commission { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Commission Rate")]
        public decimal CommissionRate { get; set; }

        [Editable(false)]
        [Display(Name = "Remainder Comm")]
        public decimal RemainderCommission { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Offered Fare")]
        public decimal OfferedFare { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Reason Rejected")]
        public int? OfferedReasonId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Discount")]
        public decimal Discount { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal DiscountRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Discount Reason")]
        public int? DiscountReasonId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Override Amount")]
        public decimal OverrideAmount { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal OverrideRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Override Basis")]
        public OverrideBasis OverrideBasis { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up")]
        public decimal Markup { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal MarkupRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up Strategy")]
        public int? MarkupStrategyId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(22, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Ticket No(s)")]
        public string TicketNo { get; set; }

        [StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Conjunction")]
        public string TicketNoConjunction { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(22, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Original Ticket No(s)")]
        public string OriginalTicketNo { get; set; }

        [StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Conjunction")]
        public string OriginalTicketNoConjunction { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(25, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Connecting Ticket No(s)")]
        public string ConnectingTicketNos { get; set; }

        [Display(Name = "Credit Card Discount Applies")]
        public bool IsCreditCardDiscountApplicable { get; set; }

        [Display(Name = "Include Mark-Up in Credit Card Payment")]
        public bool IncludeMarkupInCreditCardPayment { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Entry Type")]
        public BspEntryType BspEntryType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Ticket Method")]
        public TicketMethod TicketMethod { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(1000, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string Comments { get; set; }

        [Editable(false)]
        [Display(Name = "Gross")]
        public decimal TripLineAirPassengerGross { get; set; }

        [Editable(false)]
        [Display(Name = "Supplier Net")]
        public decimal TripLineAirPassengerSupplierNet { get; set; }

        [Editable(false)]
        [Display(Name = "Selling Price")]
        public decimal TripLineAirPassengerSellingPrice { get; set; }

        [Editable(false)]
        [Display(Name = "Cost to Client")]
        public decimal TripLineAirPassengerCostToClient { get; set; }

        [Editable(false)]
        [Display(Name = "Amount Paid")]
        public decimal TripLineAirPassengerAmountPaid { get; set; }
    }

    public class TripLineAirPassengerAirSegmentViewModel {
        public int TripLineAirPassengerAirSegmentId { get; set; }
        public int TripLineAirPassengerId { get; set; }
        public int TripLineAirSegmentId { get; set; }
        public string TripLineAirPassengerTicketNo { get; set; }
        public string SeatStatusDescription { get { return SeatStatus == SeatStatus.NotSpecified ? string.Empty : SeatStatus.GetEnumDescription(); } }
        public string BaggageAllowanceDescription { get { return BaggageAllowance == 0 ? string.Empty : string.Concat(BaggageAllowance, " ", BaggageUnit.GetEnumDescription()); } }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Fare Basis")]
        public string FareBasis { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Ticket Designator")]
        public string TicketDesignator { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Tour Code")]
        public string TourCode { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Class")]
        public string Class { get; set; }

        [Display(Name = "Group")]
        public int? GroupNo { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(10, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Seat No")]
        public string SeatNo { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Seat Status")]
        public SeatStatus SeatStatus { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Baggage Allowance")]
        public int BaggageAllowance { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Baggage Unit")]
        public BaggageUnit BaggageUnit { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "AmountLessTaxLabel", ResourceType = typeof(Resource))]
        public decimal TripLineAirPassengerAirSegmentAmount { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "TaxLabel", ResourceType = typeof(Resource))]
        public decimal TripLineAirPassengerAirSegmentTax { get; set; }

        [Editable(false)]
        [Display(Name = "Passenger")]
        public string TripLineAirPassenger { get; set; }

        [Editable(false)]
        [Display(Name = "Air Segment")]
        public string TripLineAirSegment { get; set; }
    }

    public class TripLineLandViewModel {
        public TripLineViewModel TripLineViewModel { get; set; }

        public int TripLineId { get; set; }
        public string TripStatusDescription { get { return TripStatus.GetEnumDescription(); } }
        public int SupplierServiceId { get; set; }
        public int SupplierServiceRateDetailId { get; set; }
        public string SupplierAddress { get; set; }
        public string SupplierContactFullName { get; set; }
        public string SupplierContactPhoneNo { get; set; }
        public string PassengerClassificationDescription { get { return PassengerClassification.GetEnumDescription(); } }
        public bool IsPaxNoApplicable { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Status")]
        public TripStatus TripStatus { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Purchase From")]
        public int? CreditorId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier")]
        public int? SupplierId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier Chain")]
        public int? SupplierChainId { get; set; }

        [Display(Name = "City Code")]
        public string SupplierCityCode { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Supplier CRS Code")]
        public string SupplierCrsCode { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(30, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Confirmation No")]
        public string ConfirmationNo { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Document No")]
        public string DocumentNo { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "CRS")]
        public Crs TripLineLandCrs { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "PNR Ref")]
        public string TripLineLandCrsPnrRef { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Booking PNR")]
        public string BookingPnr { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Duration/Pay For")]
        public int Duration { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Coverage Type")]
        public DurationCoverageType DurationCoverageType { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier")]
        public string SupplierName { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Address")]
        public string SupplierAddress1 { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Address is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        public string SupplierAddress2 { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "City")]
        public string SupplierLocality { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "State")]
        public string SupplierRegion { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Post Code")]
        public string SupplierPostCode { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Country")]
        public string SupplierCountryCode { get; set; }

        [Display(Name = "Title")]
        public string SupplierContactTitle { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.All, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Name")]
        public string SupplierContactName { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Phone Home")]
        public string SupplierContactPhoneHome { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Phone Work")]
        public string SupplierContactPhoneWork { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Mobile")]
        public string SupplierContactMobile { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Fax")]
        public string SupplierContactFax { get; set; }

        [DataType(DataType.EmailAddress, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Email")]
        public string SupplierContactEmail { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Arrival Date")]
        public DateTime? StartDate { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
        [StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Time")]
        public string StartTime { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Details")]
        public string StartDetails { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Address")]
        public string StartAddress1 { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Address is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        public string StartAddress2 { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "City")]
        public string StartLocality { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "State")]
        public string StartRegion { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Post Code")]
        public string StartPostCode { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Country")]
        public string StartCountryCode { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Departure Date")]
        public DateTime? EndDate { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
        [StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Time")]
        public string EndTime { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Details")]
        public string EndDetails { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Address")]
        public string EndAddress1 { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Address is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        public string EndAddress2 { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "City")]
        public string EndLocality { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "State")]
        public string EndRegion { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Post Code")]
        public string EndPostCode { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(3, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Country")]
        public string EndCountryCode { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate Basis")]
        public int? ServiceTypeRateBasisId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Classification")]
        public PassengerClassification PassengerClassification { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Pay for Duration")]
        public int PayForDuration { get; set; }

        [Required(ErrorMessage = "Value is required.")]
        [Display(Name = "Adults")]
        public int PaxAdultNo { get; set; }

        [Required(ErrorMessage = "Value is required.")]
        [Display(Name = "Rate")]
        public decimal PaxAdultRate { get; set; }

        [Required(ErrorMessage = "Value is required.")]
        [Display(Name = "Qty")]
        public int PaxAdultQty { get; set; }

        [Required(ErrorMessage = "Value is required.")]
        [Display(Name = "Children")]
        public int PaxChildNo { get; set; }

        [Required(ErrorMessage = "Value is required.")]
        [Display(Name = "Rate")]
        public decimal PaxChildRate { get; set; }

        [Required(ErrorMessage = "Value is required.")]
        [Display(Name = "Qty")]
        public int PaxChildQty { get; set; }

        [Required(ErrorMessage = "Value is required.")]
        [Display(Name = "Infants")]
        public int PaxInfantNo { get; set; }

        [Required(ErrorMessage = "Value is required.")]
        [Display(Name = "Rate")]
        public decimal PaxInfantRate { get; set; }

        [Required(ErrorMessage = "Value is required.")]
        [Display(Name = "Qty")]
        public int PaxInfantQty { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "Value is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Value is invalid.")]
        [StringLength(50, ErrorMessage = "Value can be no longer than {1} characters.")]
        [Display(Name = "Service Description")]
        public string ServiceDescription { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "Value is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "Value is invalid.")]
        [StringLength(50, ErrorMessage = "Value can be no longer than {1} characters.")]
        [Display(Name = "Service")]
        public string SupplierServiceDescription { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Service Rate")]
        public string SupplierServiceRateDetailDescription { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Currency")]
        public int? CurrencyId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Foreign Amount")]
        public decimal ForeignAmount { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Exchange Rate")]
        public decimal ExchangeRate { get; set; }

        [Editable(false)]
        [Display(Name = "Equivalent Amount")]
        public decimal EquivalentAmount { get { return ExchangeRate == 0 ? 0 : ForeignAmount / ExchangeRate; } }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Form of Payment")]
        public int? FormOfPaymentId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale")]
        public int? SaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Commission")]
        public decimal Commission { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Commission Rate")]
        public decimal CommissionRate { get; set; }

        [Editable(false)]
        [Display(Name = "Remainder Comm")]
        public decimal RemainderCommission { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Taxes/Non-Comm")]
        public decimal NonCommissionable { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Discount")]
        public decimal Discount { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal DiscountRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Discount Reason")]
        public int? DiscountReasonId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up")]
        public decimal Markup { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal MarkupRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up Strategy")]
        public int? MarkupStrategyId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Offered Fare")]
        public decimal OfferedFare { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Reason Rejected")]
        public int? OfferedReasonId { get; set; }

        [Display(Name = "Payment Date Due")]
        public DateTime? PaymentDueDate { get; set; }

        [Display(Name = "Credit Card Discount Applies")]
        public bool IsCreditCardDiscountApplicable { get; set; }

        [Display(Name = "Include Mark-Up in Credit Card Payment")]
        public bool IncludeMarkupInCreditCardPayment { get; set; }

        [Display(Name = "Allow Passenger Invoicing")]
        public bool AllowPassengerInvoicing { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Inclusions")]
        public string Inclusions { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "Value can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string Comments { get; set; }

        [Editable(false)]
        [Display(Name = "Gross")]
        public decimal Gross { get; set; }

        [Editable(false)]
        [Display(Name = "Supplier Net")]
        public decimal SupplierNet { get; set; }

        [Editable(false)]
        [Display(Name = "Selling Price")]
        public decimal SellingPrice { get; set; }

        [Editable(false)]
        [Display(Name = "Cost to Client")]
        public decimal CostToClient { get; set; }

        [Editable(false)]
        [Display(Name = "Commissionable Value")]
        public decimal CommissionableValue { get; set; }

        [Editable(false)]
        [Display(Name = "Cost")]
        public decimal RateCost { get; set; }
    }

    public class TripLineInsuranceViewModel {
        public TripLineViewModel TripLineViewModel { get; set; }

        public int TripLineId { get; set; }
        public string TripTypeDescription { get { return TripType.GetEnumDescription(); } }
        public string InsurancePolicyCoverageDescription { get { return InsurancePolicyCoverage.GetEnumDescription(); } }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type")]
        public TripType TripType { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Policy No")]
        public string PolicyNo { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "End Date")]
        public DateTime EndDate { get; set; }

        [Editable(false)]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Week(s)")]
        public int DurationWeeks { get; set; }

        [Editable(false)]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Day(s)")]
        public int DurationDays { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Purchase From")]
        public int? CreditorId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Provider")]
        public int? SupplierId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Policy Type")]
        public int? InsurancePolicyId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Plan")]
        public int? InsurancePolicyPlanId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Coverage")]
        public InsurancePolicyCoverage InsurancePolicyCoverage { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Form of Payment")]
        public int? FormOfPaymentId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale")]
        public int? SaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Policy Value")]
        public decimal PolicyValue { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Already Paid")]
        public decimal AmountAlreadyPaid { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Commission")]
        public decimal Commission { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Commission Rate")]
        public decimal CommissionRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Discount")]
        public decimal Discount { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal DiscountRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Discount Reason")]
        public int? DiscountReasonId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up")]
        public decimal Markup { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal MarkupRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up Strategy")]
        public int? MarkupStrategyId { get; set; }

        [Display(Name = "Credit Card Discount Applies")]
        public bool IsCreditCardDiscountApplicable { get; set; }

        [Display(Name = "Include Mark-Up in Credit Card Payment")]
        public bool IncludeMarkupInCreditCardPayment { get; set; }

        [Display(Name = "Allow Passenger Invoicing")]
        public bool AllowPassengerInvoicing { get; set; }

        [Editable(false)]
        [Display(Name = "Gross")]
        public decimal Gross { get; set; }

        [Editable(false)]
        [Display(Name = "Supplier Net")]
        public decimal SupplierNet { get; set; }

        [Editable(false)]
        [Display(Name = "Selling Price")]
        public decimal SellingPrice { get; set; }

        [Editable(false)]
        [Display(Name = "Cost to Client")]
        public decimal CostToClient { get; set; }

        [Editable(false)]
        [Display(Name = "Total Surcharges")]
        public decimal TotalSurcharge { get; set; }
    }

    public class TripLineInsurancePassengerViewModel {
        public int TripLineInsurancePassengerId { get; set; }
        public int TripLineId { get; set; }
        public int PassengerId { get; set; }
        public string PassengerFullName { get; set; }
        public PassengerType PassengerType { get; set; }
        public int PassengerAge { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }
        public string PassengerTypeDescription { get { return PassengerType == PassengerType.NotSpecified ? string.Empty : PassengerType.GetEnumDescription(); } }
        public string PassengerAgeDescription { get { return PassengerAge == 0 ? string.Empty : string.Concat(PassengerAge, PassengerType == PassengerType.Infant ? " months" : " years"); } }
    }

    public class TripLineInsuranceSurchargeViewModel {
        public int TripLineInsuranceSurchargeId { get; set; }
        public int TripLineId { get; set; }
        public string Passenger { get; set; }
        public string SurchargeTypeDescription { get { return SurchargeType.GetEnumDescription(); } }
        public string SurchargeRateTypeDescription { get { return SurchargeRateType.GetEnumDescription(); } }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger")]
        public int? PassengerId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Surcharge")]
        public string Name { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type")]
        public SurchargeType SurchargeType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate Type")]
        public SurchargeRateType SurchargeRateType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal SurchargeRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Amount")]
        public decimal SurchargeAmount { get; set; }

        [Display(Name = "Commissionable")]
        public bool IsCommissionable { get; set; }

        [Editable(false)]
        [Display(Name = "Total")]
        public decimal SurchargeTotal { get { return SurchargeRateType == SurchargeRateType.FixedAmount ? SurchargeAmount : SurchargeRate * SurchargeAmount; } }
    }

    public class TripLineForeignCurrencyViewModel {
        public TripLineViewModel TripLineViewModel { get; set; }

        public int TripLineId { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Purchase From")]
        public int? CreditorId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier")]
        public int? SupplierId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Currency")]
        public int? CurrencyId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Document No")]
        public string DocumentNo { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Form of Payment")]
        public int? FormOfPaymentId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale")]
        public int? SaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Foreign Amount")]
        public decimal ForeignAmount { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Exchange Rate")]
        public decimal ExchangeRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Equivalent Value")]
        public decimal EquivalentValue { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Bank Fee")]
        public decimal BankFee { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Bank Fee Rate")]
        public decimal BankFeeRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Client Fee")]
        public decimal ClientFee { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Client Fee Rate")]
        public decimal ClientFeeRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Offered Fare")]
        public decimal OfferedFare { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Reason Rejected")]
        public int? OfferedReasonId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up")]
        public decimal Markup { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up Rate")]
        public decimal MarkupRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up Strategy")]
        public int? MarkupStrategyId { get; set; }

        [Display(Name = "Include Mark-Up in Credit Card Payment")]
        public bool IncludeMarkupInCreditCardPayment { get; set; }

        [Display(Name = "Allow Passenger Invoicing")]
        public bool AllowPassengerInvoicing { get; set; }

        [Editable(false)]
        [Display(Name = "Official Rate")]
        public decimal OfficialRate { get; set; }

        [Editable(false)]
        [Display(Name = "Commission")]
        public decimal Commission { get; set; }

        [Editable(false)]
        [Display(Name = "Commission Rate")]
        public decimal CommissionRate { get; set; }

        [Editable(false)]
        [Display(Name = "Gross")]
        public decimal Gross { get; set; }

        [Editable(false)]
        [Display(Name = "Supplier Net")]
        public decimal SupplierNet { get; set; }

        [Editable(false)]
        [Display(Name = "Selling Price")]
        public decimal SellingPrice { get; set; }

        [Editable(false)]
        [Display(Name = "Cost to Client")]
        public decimal CostToClient { get; set; }
    }

    public class TripLineServiceFeeViewModel {
        public TripLineViewModel TripLineViewModel { get; set; }

        public int TripLineId { get; set; }
        public string ServiceFeePaymentTypeDescription { get { return ServiceFeePaymentType.GetEnumDescription(); } }
        public string PassengerTypeDescription { get { return PassengerType.GetEnumDescription(); } }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Payment Type")]
        public ServiceFeePaymentType ServiceFeePaymentType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Service Fee Type")]
        public int? ServiceFeeTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "CRS")]
        public Crs TripLineServiceFeeCrs { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "PNR Ref")]
        public string TripLineServiceFeeCrsPnrRef { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Document No")]
        public string DocumentNo { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Purchase From")]
        public int? CreditorId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier")]
        public int? SupplierId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger Type")]
        public PassengerType PassengerType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Pax No")]
        public int PaxNo { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Form of Payment")]
        public int? FormOfPaymentId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale")]
        public int? SaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Item Cost")]
        public decimal ItemCost { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Commission")]
        public decimal Commission { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Commission Rate")]
        public decimal CommissionRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Offered Fare")]
        public decimal OfferedFare { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Reason Rejected")]
        public int? OfferedReasonId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up")]
        public decimal Markup { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up Rate")]
        public decimal MarkupRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up Strategy")]
        public int? MarkupStrategyId { get; set; }

        [Display(Name = "Include Mark-Up in Credit Card Payment")]
        public bool IncludeMarkupInCreditCardPayment { get; set; }

        [Display(Name = "Allow Passenger Invoicing")]
        public bool AllowPassengerInvoicing { get; set; }

        [Editable(false)]
        [Display(Name = "Gross")]
        public decimal Gross { get; set; }

        [Editable(false)]
        [Display(Name = "Supplier Net")]
        public decimal SupplierNet { get; set; }

        [Editable(false)]
        [Display(Name = "Selling Price")]
        public decimal SellingPrice { get; set; }

        [Editable(false)]
        [Display(Name = "Cost to Client")]
        public decimal CostToClient { get; set; }
    }

    public class TripLineOtherInclusionViewModel {
        public TripLineViewModel TripLineViewModel { get; set; }

        public int TripLineId { get; set; }
        public string TripStatusDescription { get { return TripStatus.GetEnumDescription(); } }
        public string PassengerTypeDescription { get { return PassengerType.GetEnumDescription(); } }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Status")]
        public TripStatus TripStatus { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Start Date")]
        public DateTime? StartDate { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "End Date")]
        public DateTime? EndDate { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
        [StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Time")]
        public string Time { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Purchase From")]
        public int? CreditorId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier")]
        public int? SupplierId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(15, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "DocumentNo")]
        public string DocumentNo { get; set; }

        [Display(Name = "Standard Comment")]
        public int? StandardCommentId { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(4000, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string Comments { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger Type")]
        public PassengerType PassengerType { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Pax No")]
        public int PaxNo { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Form of Payment")]
        public int? FormOfPaymentId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Type of Sale")]
        public int? SaleTypeId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Item Cost")]
        public decimal ItemCost { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Offered Fare")]
        public decimal OfferedFare { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Reason Rejected")]
        public int? OfferedReasonId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Commission")]
        public decimal Commission { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal CommissionRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Discount")]
        public decimal Discount { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal DiscountRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Discount Reason")]
        public int? DiscountReasonId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up")]
        public decimal Markup { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Rate")]
        public decimal MarkupRate { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Mark-Up Strategy")]
        public int? MarkupStrategyId { get; set; }

        [Display(Name = "Credit Card Discount Applies")]
        public bool IsCreditCardDiscountApplicable { get; set; }

        [Display(Name = "Include Mark-Up in Credit Card Payment")]
        public bool IncludeMarkupInCreditCardPayment { get; set; }

        [Display(Name = "Allow Passenger Invoicing")]
        public bool AllowPassengerInvoicing { get; set; }

        [Editable(false)]
        [Display(Name = "Gross")]
        public decimal Gross { get; set; }

        [Editable(false)]
        [Display(Name = "Supplier Net")]
        public decimal SupplierNet { get; set; }

        [Editable(false)]
        [Display(Name = "Selling Price")]
        public decimal SellingPrice { get; set; }

        [Editable(false)]
        [Display(Name = "Cost to Client")]
        public decimal CostToClient { get; set; }
    }

    public class TripLineRemarkViewModel {
        public TripLineViewModel TripLineViewModel { get; set; }

        public int TripLineId { get; set; }
        public string StandardCommentTypeDescription { get { return StandardCommentType.GetEnumDescription(); } }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "CRS")]
        public Crs TripLineRemarkCrs { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumeric, ErrorMessage = "{0} is invalid.")]
        [StringLength(12, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "PNR Ref")]
        public string TripLineRemarkCrsPnrRef { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Start Date")]
        public DateTime? StartDate { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "End Date")]
        public DateTime? EndDate { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Time, ErrorMessage = "{0} is invalid.")]
        [StringLength(5, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Time")]
        public string Time { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Related Segment")]
        public string RelatedTripLineSegmentId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger")]
        public int? PassengerId { get; set; }

        [Display(Name = "Comment Type")]
        public StandardCommentType StandardCommentType { get; set; }

        [Display(Name = "Standard Comment")]
        public int? StandardCommentId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Remark")]
        public string Remark { get; set; }

        [Display(Name = "Print After Totals")]
        public bool PrintAfterTotals { get; set; }
    }

    public class PassengerViewModel {
        public int PassengerId { get; set; }
        public int PassengerProfileId { get; set; }
        public int PassengerTripId { get; set; }
        public int PassengerProfilePassengerId { get; set; }
        public string PassengerProfileCode { get; set; }
        public string PassengerFullName { get; set; }
        public string PassengerFullNameWithEmail { get; set; }
        public string PassengerBirthDateString { get { return PassengerBirthDate == null ? string.Empty : ((DateTime)PassengerBirthDate).ToShortDateStringExt(); } }
        public string PassengerGenderDescription { get { return PassengerGender == Gender.NotSpecified ? string.Empty : PassengerGender.GetEnumDescription(); } }
        public string PassengerTypeDescription { get { return PassengerType == PassengerType.NotSpecified ? string.Empty : PassengerType.GetEnumDescription(); } }
        public string PassengerAgeDescription { get { return PassengerAge == 0 ? string.Empty : string.Concat(PassengerAge, PassengerType == PassengerType.Infant ? " months" : " years"); } }
        public bool PassengerIsProfileUpdateable { get; set; }
        public bool PassengerIsLocked { get; set; }
        public string CrsKey { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Passenger Type")]
        public PassengerType PassengerType { get; set; }

        [Display(Name = "Title")]
        public string PassengerTitle { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "First Name(s)")]
        public string PassengerFirstName { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Last Name")]
        public string PassengerLastName { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Alias")]
        public string PassengerAlias { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Name, ErrorMessage = "{0} is invalid.")]
        [StringLength(100, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Display Name")]
        public string PassengerDisplayName { get; set; }

        [DataType(DataType.PhoneNumber, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Phone, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Phone No")]
        public string PassengerPhoneNo { get; set; }

        [DataType(DataType.EmailAddress, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.Email, ErrorMessage = "{0} is invalid.")]
        [StringLength(256, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Email")]
        public string PassengerEmail { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Display(Name = "Birth Date")]
        public DateTime? PassengerBirthDate { get; set; }

        [Display(Name = "Age")]
        public int PassengerAge { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Gender")]
        public Gender PassengerGender { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Linked Profile")]
        public int? PassengerPassengerProfileId { get; set; }
    }

    public class PassengerDocumentViewModel {
        public int PassengerDocumentId { get; set; }
        public int PassengerDocumentPassengerId { get; set; }
        public string PassengerDocumentFullName { get; set; }
        public string PassengerDocumentIssueDateString { get { return PassengerDocumentIssueDate == null ? string.Empty : ((DateTime)PassengerDocumentIssueDate).ToShortDateStringExt(); } }
        public string PassengerDocumentExpiryDateString { get { return PassengerDocumentExpiryDate == null ? string.Empty : ((DateTime)PassengerDocumentExpiryDate).ToShortDateStringExt(); } }
        public string PassengerDocumentTypeDescription { get { return PassengerDocumentType.GetEnumDescription(); } }
        public string PassengerDocumentIssuingCountry { get; set; }
        public string PassengerDocumentNationality { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Document Type")]
        public DocumentType PassengerDocumentType { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Document No")]
        public string PassengerDocumentNo { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Issue Date")]
        public DateTime? PassengerDocumentIssueDate { get; set; }

        [DataType(DataType.Date, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Expiry Date")]
        public DateTime? PassengerDocumentExpiryDate { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Place of Issue")]
        public string PassengerDocumentPlaceOfIssue { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Issuing Country")]
        public int? PassengerDocumentIssuingCountryId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Nationality Country")]
        public int? PassengerDocumentNationalityId { get; set; }

        [DataType(DataType.MultilineText, ErrorMessage = "{0} is invalid.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Comments")]
        public string PassengerDocumentComments { get; set; }
    }

    public class PassengerClubMembershipViewModel {
        public int PassengerClubMembershipId { get; set; }
        public int PassengerClubMembershipPassengerId { get; set; }
        public string PassengerClubMembershipAirlineName { get; set; }
        public string PassengerClubMembershipClubMembership { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Club Membership")]
        public int? PassengerClubMembershipClubMembershipId { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(20, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Membership No")]
        public string PassengerClubMembershipClubMembershipNo { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Airline")]
        public int? PassengerClubMembershipAirlineId { get; set; }
    }

    public class PassengerSelectionViewModel {
        public int ProfileId { get; set; }
        public int TripId { get; set; }
        public bool ExcludeCurrent { get; set; }
        public bool DisplayItinerarySelector { get; set; }
        public PassengerSelectionType PassengerSelectionType { get; set; }
        public string SourceGridId { get; set; }
        public int RowCount { get; set; }
        public string UpdateButtonText { get; set; }
    }

    public class PassengerGridSelectionViewModel {
        public int PassengerId { get; set; }
        public int PassengerProfileId { get; set; }
        public int PassengerTripId { get; set; }
        public string PassengerTripNo { get; set; }
        public PassengerType PassengerType { get; set; }
        public string PassengerProfileCode { get; set; }
        public DateTime? PassengerDepartureDate { get; set; }
        public string PassengerFullName { get; set; }
        public string PassengerPhoneNo { get; set; }
        public DateTime? PassengerBirthDate { get; set; }
        public int PassengerAge { get; set; }
        public Gender PassengerGender { get; set; }
        public string PassengerGenderDescription { get { return PassengerGender == Gender.NotSpecified ? string.Empty : PassengerGender.GetEnumDescription(); } }
        public string PassengerTypeDescription { get { return PassengerType == PassengerType.NotSpecified ? string.Empty : PassengerType.GetEnumDescription(); } }
        public string PassengerBirthDateString { get { return PassengerBirthDate == null ? string.Empty : ((DateTime)PassengerBirthDate).ToShortDateStringExt(); } }
        public string PassengerDepartureDateString { get { return PassengerDepartureDate == null ? string.Empty : ((DateTime)PassengerDepartureDate).ToShortDateStringExt(); } }
        public string PassengerAgeDescription { get { return PassengerAge == 0 ? string.Empty : string.Concat(PassengerAge, PassengerType == PassengerType.Infant ? " months" : " years"); } }
    }

    public class CrsAmadeusViewModel {
        public string FileName { get; set; }
        public string CrsPnrRef { get; set; }
        public DateTime CrsPnrDate { get; set; }
        public string RouteInfo { get; set; }
        public string Passengers { get; set; }
        public bool IsTicketed { get; set; }
        public bool IsValid { get; set; }
        public string CrsStatus { get { return !IsValid ? "I" : IsTicketed ? "T" : "B"; } }
    }

    public class CrsGalileoExportModel {
        public List<PassengerViewModel> PassengerModel { get; set; }
        public List<PassengerDocumentViewModel> PassengerDocumentModel { get; set; }
        public List<ProfileAirlineViewModel> ProfileAirlineModel { get; set; }
        public List<ProfileClubMembershipViewModel> ProfileClubMembershipModel { get; set; }
        public List<ProfileSpecialRequestViewModel> ProfileSpecialRequestModel { get; set; }
    }

    public class ProfileExportModel {
        public string Code { get; set; }
        public string FullName { get; set; }
        public string PhoneHome { get; set; }
        public string PhoneWork { get; set; }
        public string Mobile { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string MaritalStatus { get; set; }
        public DateTime BirthDate { get; set; }
        public string BirthCountry { get; set; }
        public string Nationality { get; set; }
        public string Occupation { get; set; }
        public string BusinessType { get; set; }
        public string Debtor { get; set; }
        public string Consultant { get; set; }
        public string Agency { get; set; }
    }
}