﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Telerik.Reporting.Processing;
using Travelog.Biz;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;
using Travelog.Reports.GeneralLedger;
using Travelog.WebApp.GeneralLedger;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.Controllers {
    [Authorize]
	public class GeneralLedgerController : BaseController {
		private const string ClassName = "Travelog.WebApp.Controllers.GeneralLedgerController";

        public GeneralLedgerController(IWebHostEnvironment webHostEnvironment, IDistributedCache cache) : base(webHostEnvironment, cache) {
        }

		#region Chart Of Accounts
        public IActionResult ChartOfAccounts() {
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ChartOfAccount_Edit(int chartOfAccountId, int agencyId) {
			try {
				if (CustomerSettings.Setting(HttpContext.CurrentCustomerId()).AgencyType == AgencyType.MultiAgencyGLIndividual) {
                    if (agencyId <= 0)
                        agencyId = await HttpContext.HeadOfficeAgencyId(Cache);

                    if (agencyId <= 0)
                        throw new UnreportedException(AppConstants.AgencyNotSpecified);
                }
				else {
                    agencyId = -1;
                }

                ChartOfAccount q = null;

				if (chartOfAccountId <= 0) {
					q = new ChartOfAccount {
						Id = 0,
                        AgencyId = agencyId,
                        Code = string.Empty,
						Name = string.Empty,
						ChartOfAccountType = ChartOfAccountType.BalanceSheet,
						AccountCategory = AccountCategory.Asset,
						ChartOfAccountTransactionType = ChartOfAccountTransactionType.Detailed,
						RowType = RowType.Normal,
						TotalLevel = TotalLevel.Normal,
						AltReportingCode = string.Empty,
						IsTaxApplicable = false
					};
				}
				else {
					q = Context.ChartOfAccount.Include(t => t.ChartOfAccountRoles).Single(t => t.Id == chartOfAccountId);

					if (!q.IsInRole(HttpContext.RoleId()))
						throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));
				}

				var model = new ChartOfAccountViewModel {
					ChartOfAccountId = q.Id,
					AgencyId = q.AgencyId,
					Code = q.Code,
					Name = q.Name,
					ChartOfAccountType = q.ChartOfAccountType,
					AccountCategory = q.AccountCategory,
					RowType = q.RowType,
					ChartOfAccountTransactionType = q.ChartOfAccountTransactionType,
					TotalLevel = q.TotalLevel,
					AltReportingCode = q.AltReportingCode,
					IsTaxApplicable = q.IsTaxApplicable,
					UserRoleIds = q.Id <= 0 ? new List<string>() : q.ChartOfAccountRoles.Select(t => t.RoleId),
					LastWriteTime = q.LastWriteTime.ToLocalTime(),
					CreationTime = q.CreationTime.ToLocalTime(),
					LastWriteUser = q.LastWriteUser,
					CreationUser = q.CreationUser
				};

				return PartialView("~/Views/GeneralLedger/EditorTemplates/ChartOfAccountEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccount_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> ChartOfAccount_Read([DataSourceRequest] DataSourceRequest request, int agencyId, int accountCategoryId, bool isExport, string text = null, int? id = null) {
			try {
				var q = ChartOfAccount.GetChartOfAccountQuery(Context, HttpContext.CurrentCustomerId(), agencyId, HttpContext.OtherAgencies(), HttpContext.OtherConsultants(), HttpContext.AgencyIds(Cache), HttpContext.ConsultantIds(), HttpContext.RoleId());

				if (accountCategoryId != (int)AccountCategory.None)
					q = q.Where(t => (int)t.AccountCategory == accountCategoryId);

				if (!string.IsNullOrEmpty(text)) {
					text = text.ToLower();
					q = q.Where(t => t.Code.ToLower().Contains(text) || t.Name.ToLower().Contains(text));
				}

				if (id != null)
					q = q.Where(t => t.Id == id);

				if (isExport) {
					if (!HttpContext.IsAdministrator())
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var userRoles = Lists.GetRolesList(AdminContext);

					var export = q.OrderBy(t => t.Code).AsEnumerable().Select(row => new ChartOfAccountExportModel {
						Agency = row.Agency.Name,
						Code = row.Code,
						AltReportingCode = row.AltReportingCode,
						Account = row.Name,
						ChartOfAccountType = row.ChartOfAccountType.GetEnumDescription(),
						AccountCategory = row.AccountCategory.GetEnumDescription(),
						RowType = row.RowType.GetEnumDescription(),
						ChartOfAccountTransactionType = row.ChartOfAccountTransactionType.GetEnumDescription(),
						TotalLevel = row.TotalLevel.GetEnumDescription(),
						IsTaxApplicable = row.IsTaxApplicable,
						UserRoles = string.Join("; ", userRoles.Where(t1 => row.ChartOfAccountRoles.Any(t2 => t2.RoleId == t1.Value)).OrderBy(t => t.Text).Select(t => t.Text))
					}).ToList();

					var xlsx = new ExportToExcel<ChartOfAccountExportModel>(export);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Chart of Accounts.xlsx");
				}

				var result = await q.Select(row => new ChartOfAccountViewModel {
					ChartOfAccountId = row.Id,
					AgencyId = row.AgencyId,
					Code = row.Code,
					Name = row.Name,
					ChartOfAccountType = row.ChartOfAccountType,
					AccountCategory = row.AccountCategory,
					RowType = row.RowType,
					ChartOfAccountTransactionType = row.ChartOfAccountTransactionType,
					TotalLevel = row.TotalLevel,
					AltReportingCode = row.AltReportingCode,
					IsTaxApplicable = row.IsTaxApplicable,
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccount_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ChartOfAccount_CreateOrUpdate(ChartOfAccountViewModel model) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				new ChartOfAccountCommon(HttpContext).CreateOrUpdate(Context, AdminContext, model, await HttpContext.HeadOfficeAgencyId(Cache));
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccount_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ChartOfAccount_Delete([DataSourceRequest] DataSourceRequest request, ChartOfAccountViewModel model) {
			try {
				new ChartOfAccountCommon(HttpContext).Delete(Context, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccount_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ChartOfAccountBudget_Edit(int chartOfAccountId, int settingId) {
			try {
				var model = new ChartOfAccountBudgetViewModel {
					ChartOfAccountId = chartOfAccountId,
					SettingId = settingId
				};

				return PartialView("~/Views/Admin/EditorTemplates/ChartOfAccountBudgetEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccountBudget_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> ChartOfAccountBudget_Read([DataSourceRequest] DataSourceRequest request, int parentId, bool excludeZeroBalances) {
			try {
				var context = Context;

				var chartOfAccountBudget = context.ChartOfAccountBudget.Where(t => t.SettingDetail.SettingId == parentId).OrderBy(t => t.SettingDetail.FiscalPeriodEndDate);
				var settingDetailIds = new int[13];
				string roleId = HttpContext.RoleId();
				int i = 0;

				foreach (var settingDetail in context.SettingDetail.Where(t => t.SettingId == parentId).ToList()) {
					settingDetailIds[i] = settingDetail.Id;
					i++;
				}

				var q1 = context.ChartOfAccount.Where(t1 => t1.Id > 0 && t1.RowType != RowType.Header && t1.RowType != RowType.UndistributedProfits && t1.RowType != RowType.Total && (roleId == UserRole.SystemAdministrator.Id || t1.ChartOfAccountRoles.Count == 0 || t1.ChartOfAccountRoles.Any(t2 => t2.RoleId == roleId))).OrderBy(t => t.Code);

				var q2 = q1.Select(row => new ChartOfAccountBudgetViewModel {
					ChartOfAccountId = row.Id,
					SettingId = parentId,
					Code = row.Code,
					Name = row.Name,
					Amount01 = i < 1 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[0]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[0]).Amount,
					Amount02 = i < 2 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[1]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[1]).Amount,
					Amount03 = i < 3 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[2]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[2]).Amount,
					Amount04 = i < 4 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[3]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[3]).Amount,
					Amount05 = i < 5 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[4]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[4]).Amount,
					Amount06 = i < 6 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[5]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[5]).Amount,
					Amount07 = i < 7 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[6]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[6]).Amount,
					Amount08 = i < 8 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[7]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[7]).Amount,
					Amount09 = i < 9 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[8]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[8]).Amount,
					Amount10 = i < 10 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[9]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[9]).Amount,
					Amount11 = i < 11 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[10]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[10]).Amount,
					Amount12 = i < 12 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[11]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[11]).Amount,
					Amount13 = i < 13 ? 0 : chartOfAccountBudget.SingleOrDefault(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[12]) == null ? 0 : chartOfAccountBudget.Single(t => t.ChartOfAccountId == row.Id && t.SettingDetailId == settingDetailIds[12]).Amount
				});

				if (excludeZeroBalances)
					q2 = q2.Where(t => t.Amount01 != 0 || t.Amount02 != 0 || t.Amount03 != 0 || t.Amount04 != 0 || t.Amount05 != 0 || t.Amount06 != 0 || t.Amount07 != 0 || t.Amount08 != 0 || t.Amount09 != 0 || t.Amount10 != 0 || t.Amount11 != 0 || t.Amount12 != 0 || t.Amount13 != 0);

				var result = await q2.ToDataSourceResultAsync(request);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccountBudget_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ChartOfAccountBudget_Update([DataSourceRequest] DataSourceRequest request, [Bind(Prefix = "models")] IEnumerable<ChartOfAccountBudgetViewModel> models) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				new ChartOfAccountBudgetCommon().Update(Context, models);
				return Json(models.ToDataSourceResult(request, ModelState));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccountBudget_Update", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ChartOfAccountBudget_ApportionAmounts(string budgetModel, ChartOfAccountBudgetViewModel model, FiscalPeriod fiscalPeriod, int settingDetailId, decimal amount) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				model = ChartOfAccountBudgetCommon.ApportionAmounts(Context, budgetModel, model, fiscalPeriod, settingDetailId, amount);
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccountBudget_ApportionAmounts", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ChartOfAccountAgency_Edit(int chartOfAccountId) {
			try {
				if (CustomerSettings.Setting(HttpContext.CurrentCustomerId()).AgencyType != AgencyType.MultiAgencyGLIndividual)
					throw new InvalidOperationException(string.Format("This function is not applicable to agency type {0}.", CustomerSettings.Setting(HttpContext.CurrentCustomerId()).AgencyType.GetEnumDescription()));

                ViewData["ChartOfAccountAgencyChartOfAccountId"] = chartOfAccountId;
				return PartialView("~/Views/GeneralLedger/EditorTemplates/ChartOfAccountAgencyEdit.cshtml");
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccountAgency_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> ChartOfAccountAgency_Read([DataSourceRequest] DataSourceRequest request, int chartOfAccountId, string code) {
			try {
				var q = Context.ChartOfAccount.Where(t => t.Id != chartOfAccountId && t.Code.ToLower() == code.ToLower()).OrderBy(t => t.Agency.Name);

				var result = await q.Select(row => new ChartOfAccountAgencyViewModel {
					ChartOfAccountAgencyChartOfAccountId = row.Id,
					ChartOfAccountAgencyAgencyId = row.AgencyId,
					ChartOfAccountAgencyAltReportingCode = row.AltReportingCode
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccountAgency_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ChartOfAccountAgency_Create(ChartOfAccountAgencyViewModel model) {
			try {
				new ChartOfAccountAgencyCommon(HttpContext).Create(Context, model);
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccountAgency_Create", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ChartOfAccountAgency_Delete([DataSourceRequest] DataSourceRequest request, ChartOfAccountAgencyViewModel model) {
			try {
				new ChartOfAccountAgencyCommon(HttpContext).Delete(Context, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChartOfAccountAgency_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region General Ledger
		public IActionResult Index() {
			return View();
		}

		public async Task<IActionResult> GeneralLedger_Read([DataSourceRequest] DataSourceRequest request, int agencyId, int accountCategoryId, DateTime fiscalYearStartDate, DateTime period, TransactionViewOption transactionViewOption, bool excludeZeroBalances, bool useAltReportingCode, string text, bool isExport) {
			try {
				int currentDefaultAgencyId = HttpContext.OtherAgencies() ? 0 : HttpContext.CurrentDefaultAgencyId();
				var q = Biz.Dao.GeneralLedger.GeneralLedger.GetGeneralLedgerQuery(LazyContext, HttpContext.CurrentCustomerId(), agencyId, currentDefaultAgencyId, HttpContext.RoleId(), -2, (AccountCategory)accountCategoryId, fiscalYearStartDate, period, DateTime.MinValue, DateTime.MinValue, ReportSourceGeneralLedger.ProfitLoss, transactionViewOption, excludeZeroBalances, useAltReportingCode, false, true, text);

				if (isExport) {
					if (!HttpContext.IsAdministrator())
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var userRoles = Lists.GetRolesList(AdminContext);

					var export = q.ConvertAll(row => new GeneralLedgerExportModel {
						Agency = row.ChartOfAccount.Agency.Name,
						Code = row.Code,
						AltReportingCode = row.ChartOfAccount.AltReportingCode,
						Account = row.Name,
						ChartOfAccountType = row.ChartOfAccount.ChartOfAccountType.GetEnumDescription(),
						AccountCategory = row.ChartOfAccount.AccountCategory.GetEnumDescription(),
						RowType = row.ChartOfAccount.RowType.GetEnumDescription(),
						ChartOfAccountTransactionType = row.ChartOfAccount.ChartOfAccountTransactionType.GetEnumDescription(),
						TotalLevel = row.ChartOfAccount.TotalLevel.GetEnumDescription(),
						IsTaxApplicable = row.ChartOfAccount.IsTaxApplicable,
						UserRoles = string.Join(", ", userRoles.Where(t1 => row.ChartOfAccount.ChartOfAccountRoles.Any(t2 => t2.RoleId == t1.Value)).OrderBy(t => t.Text).Select(t => t.Text)),
						PeriodBudget = row.PeriodBudget,
						PeriodCurrentYear = row.PeriodCurrentYear,
						PeriodPreviousYear = row.PeriodPreviousYear,
						YtdBudget = row.YtdBudget,
						YtdCurrentYear = row.YtdCurrentYear,
						YtdPreviousYear = row.YtdPreviousYear
					});

					var xlsx = new ExportToExcel<GeneralLedgerExportModel>(export);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "General Ledger.xlsx");
				}

				var result = await q.ConvertAll(row => new GeneralLedgerViewModel {
					ChartOfAccountId = row.ChartOfAccount.Id,
					Code = row.Code,
					Name = row.Name,
					AccountCategory = row.ChartOfAccount.AccountCategory,
					RowType = row.ChartOfAccount.RowType,
					PeriodBudget = row.PeriodBudget,
					PeriodCurrentYear = row.PeriodCurrentYear,
					PeriodPreviousYear = row.PeriodPreviousYear,
					YtdBudget = row.YtdBudget,
					YtdCurrentYear = row.YtdCurrentYear,
					YtdPreviousYear = row.YtdPreviousYear
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GeneralLedger_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}
		#endregion

		#region General Ledger Settings
		public IActionResult GeneralLedgerSettings(DateTime? fiscalYearStartDate = null, string message = null, MessageType messageType = MessageType.Warning) {
			var context = Context;
			int i = 0;

			Setting glSetting = null;

			for (i = 1; i <= 13; i++) {
				ViewData[string.Format("Column{0}Title", i.ToString("d2"))] = string.Empty;
			}

			if (fiscalYearStartDate == null) {
				glSetting = context.Setting.OrderByDescending(t => t.FiscalYearStartDate).FirstOrDefault();
			}
			else {
				glSetting = context.Setting.SingleOrDefault(t => t.FiscalYearStartDate == fiscalYearStartDate);
			}

			if (glSetting == null) {
				glSetting = new Setting {
					Id = 0,
					FiscalYearStartDate = DateTime.MinValue
				};
			}

			i = 0;

			foreach (var settingDetail in context.SettingDetail.Where(t => t.Setting.FiscalYearStartDate == glSetting.FiscalYearStartDate).OrderBy(t => t.FiscalPeriodEndDate).ToList()) {
				i++;
				ViewData[string.Format("Column{0:D2}Title", i)] = settingDetail.FiscalPeriodEndDate.ToString("MMM-yyyy");
			}

			var model = new GeneralLedgerSettingViewModel {
				SettingId = glSetting.Id,
				GeneralLedgerDivision = glSetting.GeneralLedgerDivision,
				ClientControlAccountId = glSetting.ClientControlAccountId,
				DebtorControlAccountId = glSetting.DebtorControlAccountId,
				CreditorControlAccountId = glSetting.CreditorControlAccountId,
				BspAccrualAccountId = glSetting.BspAccrualAccountId,
				SupplierReturnsAccountId = glSetting.SupplierReturnsAccountId,
				CreditCardChargeAccountId = glSetting.CreditCardChargeAccountId,
				CommissionAccountId = glSetting.CommissionAccountId,
				OverrideCommissionAccountId = glSetting.OverrideCommissionAccountId,
				OtherCommissionAccountId = glSetting.OtherCommissionAccountId,
				SalesTaxAccountId = glSetting.SalesTaxAccountId,
				PurchasesTaxAccountId = glSetting.PurchasesTaxAccountId,
				FiscalYearStartDate = glSetting.FiscalYearStartDate == DateTime.MinValue ? null : glSetting.FiscalYearStartDate,
				FiscalYearStartDateName = glSetting.FiscalYearStartDateName,
				LastWriteTime = glSetting.LastWriteTime.ToLocalTime(),
				CreationTime = glSetting.CreationTime.ToLocalTime(),
				LastWriteUser = glSetting.LastWriteUser,
				CreationUser = glSetting.CreationUser
			};

			ViewBag.Message = message;
			ViewBag.MessageType = messageType;

			return View("~/Views/Admin/GeneralLedgerSettings.cshtml", model);
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> GeneralLedgerSetting_CreateOrUpdate(GeneralLedgerSettingViewModel model) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				new GeneralLedgerSettingCommon(HttpContext).CreateOrUpdate(Context, AdminContext, model);
				return Json(true);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GeneralLedgerSetting_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> GeneralLedgerSetting_Delete(int settingId) {
			try {
				new GeneralLedgerSettingCommon(HttpContext).Delete(Context, settingId);
				return Json(Url.Action("GeneralLedgerSettings", new { message = "Settings have been deleted.", messageType = MessageType.Success }));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GeneralLedgerSetting_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> GeneralLedgerSettingDetail_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
			try {
				var q = Context.SettingDetail.Where(t => t.SettingId == parentId).OrderBy(t => t.FiscalPeriodEndDate);

				var result = await q.Select(row => new GeneralLedgerSettingDetailViewModel {
					SettingDetailId = row.Id,
					SettingId = row.SettingId,
					FiscalPeriodEndDate = row.FiscalPeriodEndDate == DateTime.MinValue ? null : row.FiscalPeriodEndDate,
					FiscalPeriodEndDateName = row.FiscalPeriodEndDateName,
					IsAdminClosed = row.IsAdminClosed,
					IsUserClosed = row.IsUserClosed,
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GeneralLedgerSettingDetail_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> GeneralLedgerSettingDetail_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, GeneralLedgerSettingDetailViewModel model) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				new GeneralLedgerSettingDetailCommon(HttpContext).CreateOrUpdate(Context, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GeneralLedgerSettingDetail_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> GeneralLedgerSettingDetail_Delete([DataSourceRequest] DataSourceRequest request, GeneralLedgerSettingDetailViewModel model) {
			try {
				new GeneralLedgerSettingDetailCommon(HttpContext).Delete(Context, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GeneralLedgerSettingDetail_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region Reports
		public IActionResult Reports() {
			return View();
		}

		public async Task<IActionResult> GeneralLedger_Report(GeneralLedgerReportSourceModel model) {
			try {
				model.CustomerId = HttpContext.CurrentCustomerId();
				model.DefaultAgency = await HttpContext.CurrentDefaultAgencyName(Cache);
				model.UserRoleId = HttpContext.RoleId();
				model.CreationUser = HttpContext.UserFullName();
				model.CreationTime = HttpContext.Now();

				if (model.ReportSource == ReportSourceGeneralLedger.Budget)
					model.AgencyId = HttpContext.CurrentDefaultAgencyId();

				int currentDefaultAgencyId = HttpContext.OtherAgencies() ? 0 : HttpContext.CurrentDefaultAgencyId();
				var reportSource = GeneralLedgerDataSources.GetReportSource(Context, User, model, currentDefaultAgencyId);

				RenderingResult result = null;
				string fileName = null;

				switch (model.OutputType) {
					default:
						return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
					case "ExportPdf":
						result = Utils.ExportToPdf(reportSource);
						fileName = string.Format("{0}.pdf", GeneralLedgerDataSources.GetReportFileName(model.ReportSource));
						break;
					case "ExportWord":
						result = Utils.ExportToWord(reportSource);
						fileName = string.Format("{0}.docx", GeneralLedgerDataSources.GetReportFileName(model.ReportSource));
						break;
					case "ExportExcel":
						result = Utils.ExportToExcel(reportSource);
						fileName = string.Format("{0}.xlsx", GeneralLedgerDataSources.GetReportFileName(model.ReportSource));
						break;
				}

				return File(result.DocumentBytes, result.MimeType, fileName);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GeneralLedger_Report", ex);

				if (model.OutputType == "Report") {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
				else {
					return Redirect("/Shared/Error");
				}
			}
		}
		#endregion
	}
}