﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Travelog.Biz;
using Travelog.Biz.Dao;

namespace Travelog.WebApp.Controllers {
    public class BaseController : Controller {
        public IDistributedCache Cache { get; set; }
        protected IWebHostEnvironment WebHostEnvironment { get; set; }
        protected SignInManager<ApplicationUser> SignInManager { get; set; }
        protected UserManager<ApplicationUser> UserManager { get; set; }

        public BaseController(IWebHostEnvironment webHostEnvironment, IDistributedCache cache) {
            WebHostEnvironment = webHostEnvironment;
            Cache = cache;
        }

        public BaseController(SignInManager<ApplicationUser> signInManager, UserManager<ApplicationUser> userManager, IWebHostEnvironment webHostEnvironment, IDistributedCache cache) {
            userManager.RegisterTokenProvider(TokenOptions.DefaultProvider, new EmailTokenProvider<ApplicationUser>());
            UserManager = userManager;
            SignInManager = signInManager;
            WebHostEnvironment = webHostEnvironment;
            Cache = cache;
        }

        protected AppAdminContext AdminContext {
            get {
                if (HttpContext.Items?["TravelogOnline.AdminContext"] == null)
                    HttpContext.Items["TravelogOnline.AdminContext"] = new AppAdminContext(User);

                return HttpContext.Items["TravelogOnline.AdminContext"] as AppAdminContext;
            }
        }

        protected AppAdminContext ArchiveContext {
            get {
                if (HttpContext.Items?["TravelogOnline.ArchiveContext"] == null)
                    HttpContext.Items["TravelogOnline.ArchiveContext"] = new AppAdminContext(User, AppSettings.Configuration.GetConnectionString("travelogonline-archive"));

                return HttpContext.Items["TravelogOnline.ArchiveContext"] as AppAdminContext;
            }
        }

        protected AppMainContext Context {
            get {
                if (HttpContext.Items?["TravelogOnline.Context"] == null)
                    HttpContext.Items["TravelogOnline.Context"] = new AppMainContext(User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser());

                return HttpContext.Items["TravelogOnline.Context"] as AppMainContext;
            }
        }

        protected AppLazyContext LazyContext {
            get {
                if (HttpContext.Items?["TravelogOnline.LazyContext"] == null)
                    HttpContext.Items["TravelogOnline.LazyContext"] = new AppLazyContext(User, HttpContext.CurrentCustomerId(), HttpContext.IsExternalUser(), HttpContext.IsSuperUser());

                return HttpContext.Items["TravelogOnline.LazyContext"] as AppLazyContext;
            }
        }

        protected AppMainContext ManagementContext {
            get {
                if (HttpContext.Items?["TravelogOnline.ManagementContext"] == null)
                    HttpContext.Items["TravelogOnline.ManagementContext"] = new AppMainContext(User, AppSettings.ManagementDatabaseId, HttpContext.IsExternalUser(), HttpContext.IsSuperUser());

                return HttpContext.Items["TravelogOnline.ManagementContext"] as AppMainContext;
            }
        }

        protected override void Dispose(bool disposing) {
            if (disposing) {
                if (HttpContext.Items["TravelogOnline.AdminContext"] != null) {
                    var context = HttpContext.Items["TravelogOnline.AdminContext"] as AppAdminContext;
                    context.Dispose();
                }

                if (HttpContext.Items["TravelogOnline.ArchiveContext"] != null) {
                    var context = HttpContext.Items["TravelogOnline.ArchiveContext"] as AppAdminContext;
                    context.Dispose();
                }

                if (HttpContext.Items["TravelogOnline.Context"] != null) {
                    var context = HttpContext.Items["TravelogOnline.Context"] as AppMainContext;
                    context.Dispose();
                }

                if (HttpContext.Items["TravelogOnline.LazyContext"] != null) {
                    var context = HttpContext.Items["TravelogOnline.LazyContext"] as AppLazyContext;
                    context.Dispose();
                }

                if (HttpContext.Items["TravelogOnline.ManagementContext"] != null) {
                    var context = HttpContext.Items["TravelogOnline.ManagementContext"] as AppMainContext;
                    context.Dispose();
                }
            }

            base.Dispose(disposing);
        }

        public class JavaScriptResult : ContentResult {
            public JavaScriptResult(string script) {
                Content = script;
                ContentType = "application/javascript";
            }
        }
    }
}