using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Admin;
using Travelog.Biz.Enums;
using Travelog.Gds;
using Travelog.PaymentGateway.Enums;
using Travelog.WebApp.Accounting;
using Travelog.WebApp.Admin;
using Travelog.WebApp.Common;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.Controllers {
    [Authorize]
    public class SharedController : BaseController {
        private const string ClassName = "Travelog.WebApp.Controllers.SharedController";

        public SharedController(IWebHostEnvironment webHostEnvironment, IDistributedCache cache) : base(webHostEnvironment, cache) {
        }

        [AllowAnonymous]
        public IActionResult ResourceNotFound(bool isPartial = true) {
            if (isPartial)
                return PartialView("~/Views/Shared/ResourceNotFound.cshtml");

            return View();
        }

        [AllowAnonymous]
        public IActionResult Error(string message = null, MessageType messageType = MessageType.Warning, int timeoutSeconds = 30, bool isPartial = true) {
            if (Request.GetTypedHeaders().Referer?.AbsolutePath.Contains("/Error", StringComparison.OrdinalIgnoreCase) ?? false) {
                Response.Clear();
            }
            else {
                if (message != null) {
                    ViewBag.Message = message;
                    ViewBag.MessageType = messageType.ToString().ToLower();
                    ViewBag.TimeoutSeconds = timeoutSeconds;
                }

                if (isPartial)
                    return PartialView("~/Views/Shared/Error.cshtml");
            }

            return View();
        }

        [AllowAnonymous]
        public IActionResult NotAuthorised() {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SendEnquiry(ProductEnquiryViewModel model) {
            if (!ModelState.IsValid)
                throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

            string message = string.Format("From: {0}", model.Name);

            if (!string.IsNullOrEmpty(model.Phone))
                message = string.Format("{0}{1}Phone: {2}", message, AppConstants.HtmlLineBreak, model.Phone);

            message = string.Format("{0}{1}Email: {2}", message, AppConstants.HtmlLineBreak, model.Email);

            if (!string.IsNullOrEmpty(model.Message))
                message = string.Format("{0}{1}{1}{2}", message, AppConstants.HtmlLineBreak, model.Message);

            await Mail.Instance.SendMailAsync(AppSettings.EmailEnquiries, "Travelog Online - Enquiry", message.Replace(Environment.NewLine, AppConstants.HtmlLineBreak), model.Email);
            return Json(true);
        }

        [HttpPost]
        public async Task SendMail(string emailFrom, string to, string cc, string bcc, string subject, string body, IEnumerable<IFormFile> attachments) {
            try {
                var mailAttachments = new List<MailAttachment>();

                if (attachments != null) {
                    foreach (var attachment in attachments) {
                        mailAttachments.Add(new MailAttachment(attachment.OpenReadStream().StreamToBytes(), attachment.FileName, attachment.ContentType));
                    }
                }

                await Mail.Instance.SendMailAsync(to, cc, bcc, subject, body.Replace(Environment.NewLine, AppConstants.HtmlLineBreak), mailAttachments.ToArray(), emailFrom);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SendMail", ex);
            }
        }

        [HttpPost]
        public async Task HandleException(string className, string method, string error, string url, string source, string stack) {
            if (string.IsNullOrEmpty(error))
                return;

            var ex = new Exception(error);
            await ExceptionManager.HandleExceptionAsync(HttpContext, className, method, ex, url, source, stack);
        }

        [HttpPost]
        public async Task<IActionResult> ExportExcel(string contentType, string base64, string fileName) {
            try {
                var fileContents = Convert.FromBase64String(base64);
                return File(fileContents, contentType, fileName);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ExportExcel", ex);
                return Redirect("/Shared/Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SaveGridSelections(string gridId, int selectionOptionId, string selectedIds) {
            try {
                var context = Context;
                var selectionOption = (SelectionOption)selectionOptionId;
                int count = 0;

                int[] gridIds = null;
                int[] ids = null;

                if (!string.IsNullOrEmpty(selectedIds))
                    ids = selectedIds.Split(',').Select(int.Parse).ToArray();

                switch (gridId) {
                    case "Receipt":
                        switch (selectionOption) {
                            case SelectionOption.Matched:
                                if (!string.IsNullOrEmpty(selectedIds))
                                    gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionReceiptDetailIds.Where(t => !ids.Contains(t)).ToArray();

                                break;
                            case SelectionOption.Unmatched:
                                gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionReceiptDetailIds.Concat(ids).Distinct().ToArray();
                                break;
                            case SelectionOption.MatchZeros:
                                ids = context.ReceiptDetail.Where(t => t.DocumentStatus == DocumentStatus.Open && t.Amount + t.Tax == 0).Select(t => t.Id).ToArray();
                                gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionReceiptDetailIds.Concat(ids).Distinct().ToArray();
                                break;
                            default:
                                gridIds = ids;
                                break;
                        }

                        count = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionReceiptDetailIds.Length;
                        AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionReceiptDetailIds = gridIds;
                        break;
                    case "Bsp":
                        switch (selectionOption) {
                            case SelectionOption.Matched:
                                if (!string.IsNullOrEmpty(selectedIds))
                                    gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionBspIds.Where(t => !ids.Contains(t)).ToArray();

                                break;
                            case SelectionOption.Unmatched:
                                gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionBspIds.Concat(ids).Distinct().ToArray();
                                break;
                            case SelectionOption.MatchZeros:
                                ids = context.Bsp.Include(t => t.BspDetails).Where(t1 => t1.BspDetails.Any(t2 => t2.DocumentStatus == DocumentStatus.Open)).AsEnumerable().Where(t => t.AmountPayable == 0).Select(t => t.Id).ToArray();
                                gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionBspIds.Concat(ids).Distinct().ToArray();
                                break;
                            default:
                                gridIds = ids;
                                break;
                        }

                        count = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionBspIds.Length;
                        AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionBspIds = gridIds;
                        break;
                    case "NonBsp":
                        switch (selectionOption) {
                            case SelectionOption.Matched:
                                if (!string.IsNullOrEmpty(selectedIds))
                                    gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionNonBspIds.Where(t => !ids.Contains(t)).ToArray();

                                break;
                            case SelectionOption.Unmatched:
                                gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionNonBspIds.Concat(ids).Distinct().ToArray();
                                break;
                            case SelectionOption.MatchZeros:
                                ids = context.NonBsp.Include(t => t.NonBspDetails).Where(t1 => t1.NonBspDetails.Any(t2 => t2.DocumentStatus == DocumentStatus.Open)).AsEnumerable().Where(t => t.AmountPayable == 0).Select(t => t.Id).ToArray();
                                gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionNonBspIds.Concat(ids).Distinct().ToArray();
                                break;
                            default:
                                gridIds = ids;
                                break;
                        }

                        count = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionNonBspIds.Length;
                        AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionNonBspIds = gridIds;
                        break;
                    case "Payment":
                        switch (selectionOption) {
                            case SelectionOption.Matched:
                                if (!string.IsNullOrEmpty(selectedIds))
                                    gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionPaymentDetailIds.Where(t => !ids.Contains(t)).ToArray();

                                break;
                            case SelectionOption.Unmatched:
                                gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionPaymentDetailIds.Concat(ids).Distinct().ToArray();
                                break;
                            case SelectionOption.MatchZeros:
                                ids = context.Payment.Include(t => t.PaymentDetails).Where(t1 => t1.PaymentDetails.Any(t2 => t2.DocumentStatus == DocumentStatus.Open)).AsEnumerable().Where(t => t.AmountPayable == 0).Select(t => t.Id).ToArray();
                                gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionPaymentDetailIds.Concat(ids).Distinct().ToArray();
                                break;
                            default:
                                gridIds = ids;
                                break;
                        }

                        count = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionPaymentDetailIds.Length;
                        AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionPaymentDetailIds = gridIds;
                        break;
                    case "Invoice":
                        switch (selectionOption) {
                            case SelectionOption.Matched:
                                if (!string.IsNullOrEmpty(selectedIds))
                                    gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionInvoiceDetailIds.Where(t => !ids.Contains(t)).ToArray();

                                break;
                            case SelectionOption.Unmatched:
                                gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionInvoiceDetailIds.Concat(ids).Distinct().ToArray();
                                break;
                            case SelectionOption.MatchZeros:
                                ids = context.InvoiceDetail.Where(t => t.DocumentStatus == DocumentStatus.Open && t.Amount + t.Tax == 0).Select(t => t.Id).ToArray();
                                gridIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionInvoiceDetailIds.Concat(ids).Distinct().ToArray();
                                break;
                            default:
                                gridIds = ids;
                                break;
                        }

                        count = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionInvoiceDetailIds.Length;
                        AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionInvoiceDetailIds = gridIds;
                        break;
                }

                AppSettings.UpdateAll(context, HttpContext.CurrentCustomerId());

                if (selectionOption == SelectionOption.All) {
                    count = gridIds.Length;
                }
                else if (gridIds != null && gridIds.Length > 0) {
                    count = gridIds.Length - count;
                }

                return Json(Math.Abs(count));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SaveGridSelections", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        #region Grid Selection
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GridSelection() {
            try {
                return PartialView("~/Views/Shared/_GridSelectionPartial.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GridSelection", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Payments
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProcessPayment_Edit(PaymentGatewayClientType clientType, int paymentMethodId, int profileId, int tripId, int debtorId, int creditorId, int chartOfAccountId, decimal amount) {
            try {
                bool isCardOnFile = false;
                bool isRecurringPayment = false;

                if (clientType == PaymentGatewayClientType.Principal) {
                    var paymentMethod = AdminContext.CustomerPaymentMethod.Find(paymentMethodId);

                    isCardOnFile = paymentMethod != null;

                    if (isCardOnFile)
                        isRecurringPayment = paymentMethod.IsRecurringPayment;
                }
                else {
                    var paymentMethod = Context.PaymentMethod.Find(paymentMethodId);
                    isCardOnFile = paymentMethod != null;
                }

                var model = new ProcessPaymentViewModel {
                    ProcessPaymentClientType = clientType,
                    ProcessPaymentCustomerId = HttpContext.CurrentCustomerId(),
                    ProcessPaymentPaymentMethodId = paymentMethodId,
                    ProcessPaymentProfileId = profileId,
                    ProcessPaymentTripId = tripId,
                    ProcessPaymentDebtorId = debtorId,
                    ProcessPaymentCreditorId = creditorId,
                    ProcessPaymentChartOfAccountId = chartOfAccountId,
                    ProcessPaymentExpiryDate = string.Empty,
                    ProcessPaymentIsCardOnFile = isCardOnFile,
                    ProcessPaymentIsRecurringPayment = isRecurringPayment,
                    ProcessPaymentAmount = amount
                };

                return PartialView("~/Views/Shared/EditorTemplates/ProcessPaymentEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProcessPayment_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProcessPayment_CreateOrUpdate(ProcessPaymentViewModel model, int customerId, bool isCardOnFile, string encryptedCardNo, string encryptedCvn) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                ProcessPaymentCommon.CreateOrUpdate(HttpContext, AdminContext, Context, model, customerId, isCardOnFile, encryptedCardNo, encryptedCvn);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProcessPayment_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Scheduled Tasks
        [HttpPost]
        [AllowAnonymous]
        [BasicAuthentication(AppSettings.SystemAccountName, AppSettings.SystemAccountPassword, BasicRealm = "travelog")]
        public async Task<IActionResult> ExecuteBillingRun(CustomerType customerType) {
            try {
                new Billing(HttpContext).ExecuteBillingRun(Utils.GetGenericIdentity(), WebHostEnvironment.ContentRootPath, (int)customerType);
                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ExecuteBillingRun", ex);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [BasicAuthentication(AppSettings.SystemAccountName, AppSettings.SystemAccountPassword, BasicRealm = "travelog")]
        public async Task<IActionResult> RunFinancialIntegrityCheck(CustomerType customerType) {
            try {
                List<Customer> customers;

                using (var adminContext = new AppAdminContext(true)) {
                    switch (customerType) {
                        default:
                            customers = new List<Customer>();
                            break;
                        case CustomerType.TravelogProd:
                            customers = adminContext.Customer.Where(t => t.Id >= (int)CustomerType.TravelogProd).OrderBy(t => t.Id).ToList();
                            break;
                        case CustomerType.TravelogStaging:
                            customers = adminContext.Customer.Where(t => t.Id >= (int)CustomerType.TravelogStagingTest9 && t.Id <= (int)CustomerType.TravelogStaging).OrderBy(t => t.Id).ToList();
                            break;
                    }

                    foreach (var customer in customers) {
						using (var lazyContext = new AppLazyContext(customer.Id, false)) {
							FinancialIntegrityCommon.InsertMissingTransactions(lazyContext, customer.Id);
                            FinancialIntegrityCommon.CloseOffFiscalPeriods(lazyContext);

                            foreach (var agency in lazyContext.Agency.Where(t => t.Id > 0).ToList()) {
                                FinancialIntegrityCommon.RunFinancialIntegrityCheck(adminContext, lazyContext, customer.CountryCode, customer.Id, agency.Id);
                            }
                        }
                    }
                }

                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "RunFinancialIntegrityCheck", ex);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [BasicAuthentication(AppSettings.SystemAccountName, AppSettings.SystemAccountPassword, BasicRealm = "travelog")]
        public async Task<IActionResult> UpdateExchangeRates() {
            try {
                ExchangeRate.UpdateExchangeRates();
                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "UpdateExchangeRates", ex);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [BasicAuthentication(AppSettings.SystemAccountName, AppSettings.SystemAccountPassword, BasicRealm = "travelog")]
        public async Task<IActionResult> RefreshEtgAccessToken() {
            try {
                await ExpressTravelGroup.RefreshAccessTokenAsync();
                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "RefreshEtgAccessToken", ex);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [BasicAuthentication(AppSettings.SystemAccountName, AppSettings.SystemAccountPassword, BasicRealm = "travelog")]
        public async Task<IActionResult> ArchiveAuditLog() {
            try {
                await Biz.Dao.AuditLog.ArchiveAuditLog();
                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ArchiveAuditLog", ex);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        #endregion
    }
}