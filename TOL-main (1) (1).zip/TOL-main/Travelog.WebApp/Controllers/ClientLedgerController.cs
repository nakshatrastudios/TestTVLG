﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kendo.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.Infrastructure;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Telerik.Reporting.Processing;
using Travelog.Biz;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;
using Travelog.Gds;
using Travelog.Reports.ClientLedger;
using Travelog.WebApp.ClientLedger;
using Travelog.WebApp.Models;
using DocumentType = Travelog.Biz.Enums.DocumentType;

namespace Travelog.WebApp.Controllers {
    [Authorize]
    public class ClientLedgerController : BaseController {
        private const string ClassName = "Travelog.WebApp.Controllers.ClientLedgerController";

        public ClientLedgerController(IWebHostEnvironment webHostEnvironment, IDistributedCache cache) : base(webHostEnvironment, cache) {
        }

        #region Profiles
        public IActionResult Index() {
            return View();
        }

        public async Task<IActionResult> Profile(int profileId, int baseTripId = -1, string message = null, MessageType messageType = MessageType.Warning) {
            if (profileId == -1 && (Request.GetTypedHeaders().Referer?.AbsolutePath.TrimEnd('/').Equals("/ClientLedger/Trip", StringComparison.OrdinalIgnoreCase) ?? false))
                return Redirect(Request.GetTypedHeaders().Referer.PathAndQuery);

            var lazyContext = LazyContext;
            Profile q;

            if (profileId <= 0) {
                if (baseTripId > 0) {
                    var trip = lazyContext.Trip.Find(baseTripId);

                    q = new Profile {
                        Id = 0,
                        Code = Biz.Dao.ClientLedger.Profile.GetNewCode(lazyContext, trip.LastName),
                        Title = trip.Title,
                        FirstName = trip.FirstName,
                        LastName = trip.LastName,
                        PhoneHome = trip.PhoneHome,
                        PhoneWork = trip.PhoneWork,
                        Mobile = trip.Mobile,
                        Fax = trip.Fax,
                        Email = trip.Email,
                        MaritalStatus = trip.MaritalStatus,
                        BirthDate = DateTime.MinValue,
                        BirthCountryId = -1,
                        BirthCountry = lazyContext.Country.Find(-1),
                        NationalityId = -1,
                        Nationality = lazyContext.Country.Find(-1),
                        Occupation = trip.Occupation,
                        BusinessType = trip.BusinessType,
                        DebtorId = trip.DebtorId,
                        Debtor = trip.Debtor,
                        AgencyId = HttpContext.CurrentDefaultAgencyId(),
                        Agency = lazyContext.Agency.Find(HttpContext.CurrentDefaultAgencyId()),
                        ConsultantId = HttpContext.CurrentConsultantId(),
                        Consultant = lazyContext.Consultant.Find(HttpContext.CurrentConsultantId())
                    };
                }
                else {
                    q = new Profile {
                        Id = 0,
                        BirthDate = DateTime.MinValue,
                        BirthCountryId = -1,
                        BirthCountry = lazyContext.Country.Find(-1),
                        NationalityId = -1,
                        Nationality = lazyContext.Country.Find(-1),
                        DebtorId = -1,
                        Debtor = lazyContext.Debtor.Find(-1),
                        AgencyId = HttpContext.CurrentDefaultAgencyId(),
                        Agency = lazyContext.Agency.Find(HttpContext.CurrentDefaultAgencyId()),
                        ConsultantId = HttpContext.CurrentConsultantId(),
                        Consultant = lazyContext.Consultant.Find(HttpContext.CurrentConsultantId())
                    };
                }
            }
            else {
                q = lazyContext.Profile.Include(t => t.ProfilePassengers).SingleOrDefault(t => t.Id == profileId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);
            }

            var model = new ProfileViewModel {
                ProfileId = q.Id,
                Code = q.Code,
                FullName = q.FullName,
                AccountName = q.AccountName,
                Title = q.Title,
                FirstName = q.FirstName,
                LastName = q.LastName,
                PhoneHome = q.PhoneHome,
                PhoneWork = q.PhoneWork,
                Mobile = q.Mobile,
                Fax = q.Fax,
                Email = q.Email,
                MaritalStatus = q.MaritalStatus,
                BirthDate = q.BirthDate == DateTime.MinValue ? null : q.BirthDate,
                BirthCountryId = q.BirthCountryId,
                BirthCountry = q.BirthCountry.Name,
                NationalityId = q.NationalityId,
                Nationality = q.Nationality.Name,
                Occupation = q.Occupation,
                BusinessType = q.BusinessType,
                DebtorId = q.DebtorId,
                Debtor = q.Debtor.Name,
                AgencyId = q.AgencyId <= 0 ? null : q.AgencyId,
                Agency = q.Agency?.Name,
                ConsultantId = q.ConsultantId <= 0 ? null : q.ConsultantId,
                Consultant = q.Consultant?.Name,
                Rules = string.Concat(q.Rules, q.Debtor?.Rules.Length > 0 ? string.Concat(Environment.NewLine, Environment.NewLine, "Debtor Rules & Regulations:", Environment.NewLine, q.Debtor.Rules).Trim(Environment.NewLine.ToCharArray()) : string.Empty),
                Remarks = string.Concat(q.Remarks, q.Debtor?.Remarks.Length > 0 ? string.Concat(Environment.NewLine, Environment.NewLine, "Debtor Remarks:", Environment.NewLine, q.Debtor.Remarks).Trim(Environment.NewLine.ToCharArray()) : string.Empty),
                LastWriteTime = q.LastWriteTime.ToLocalTime(),
                CreationTime = q.CreationTime.ToLocalTime(),
                LastWriteUser = q.LastWriteUser,
                CreationUser = q.CreationUser
            };

            if (baseTripId > 0) {
                await HttpContext.UpdateNavigateUrl(Cache, "Profile", string.Format("/ClientLedger/Profile/?profileId={0}&baseTripId={1}", profileId, baseTripId));
            }
            else {
                await HttpContext.UpdateNavigateUrl(Cache, "Profile", string.Format("/ClientLedger/Profile/?profileId={0}", profileId));
            }

            ViewBag.Message = message;
            ViewBag.MessageType = messageType;

            return View(model);
        }

        public async Task<IActionResult> Profile_Read([DataSourceRequest] DataSourceRequest request, string text, int viewOptionId, int debtorId, string orderNo, string tripId, string userRefNo, string pnr, string airlinePnr, DateTime departureDate, DateTime creationTimeFrom, DateTime creationTimeTo, int consultantId, bool isExport) {
            try {
                var context = Context;
                bool tripFilter = false;

                var q = context.Profile.Include(t => t.ProfileAddresses).Include(t => t.Debtor).Include(t => t.BirthCountry).Include(t => t.Nationality).Include(t => t.Agency).Include(t => t.Consultant).ThenInclude(t => t.ConsultantAgencies).Where(t => t.Id > 0);
                var trip = context.Trip.Include(t => t.TripLines).ThenInclude(t => t.TripLineSelections).Include(t => t.Agency).Include(t => t.Consultant).ThenInclude(t => t.ConsultantAgencies).Where(t => t.Id > 0);

                if (!HttpContext.OtherAgencies()) {
                    var agencyIds = HttpContext.AgencyIds(Cache);
                    q = q.Where(t => agencyIds.Contains(t.AgencyId));
                    trip = trip.Where(t => agencyIds.Contains(t.AgencyId));
                }

                if (!HttpContext.OtherConsultants()) {
                    var consultantIds = HttpContext.ConsultantIds();
                    q = q.Where(t => consultantIds.Contains(t.ConsultantId));
                    trip = trip.Where(t => consultantIds.Contains(t.ConsultantId));
                }

                if (viewOptionId == 1) {
                    trip = trip.Where(t1 => !t1.TripLines.Any(t2 => t2.TripLineSelections.Any(t3 => t3.QuoteNo == 0)));
                    tripFilter = true;
                }
                else if (viewOptionId == 2) {
                    trip = trip.Where(t1 => t1.TripLines.Any(t2 => t2.TripLineSelections.Any(t3 => t3.QuoteNo == 0)));
                    tripFilter = true;
                }

                if (debtorId > 0) {
                    trip = trip.Where(t => t.DebtorId == debtorId);
                    tripFilter = true;
                }

                if (!string.IsNullOrEmpty(orderNo)) {
                    trip = trip.Where(t => t.DebtorOrderNo.ToLower().Contains(orderNo.ToLower()));
                    tripFilter = true;
                }

                if (!string.IsNullOrEmpty(tripId)) {
                    trip = trip.Where(t => t.Id.ToString().Contains(tripId.TrimStart('0')));
                    tripFilter = true;
                }

                if (!string.IsNullOrEmpty(userRefNo)) {
                    trip = trip.Where(t => t.UserReferenceNo.ToLower().Contains(userRefNo.ToLower()));
                    tripFilter = true;
                }

                if (!string.IsNullOrEmpty(pnr)) {
                    pnr = pnr.ToLower();
                    trip = trip.Where(t1 => context.TripLineAir.Include(t => t.TripLine).Any(t3 => t3.TripLine.TripId == t1.Id && t3.CrsPnrRef.ToLower().Contains(pnr))
                        || context.TripLineLand.Include(t => t.TripLine).Any(t3 => t3.TripLine.TripId == t1.Id && t3.CrsPnrRef.ToLower().Contains(pnr)));

                    tripFilter = true;
                }

                if (!string.IsNullOrEmpty(airlinePnr)) {
                    trip = trip.Where(t1 => context.TripLineAirSegment.Include(t => t.TripLineAir).ThenInclude(t => t.TripLine).Any(t3 => t3.TripLineAir.TripLine.TripId == t1.Id && t3.AirlinePnr.ToLower().Contains(airlinePnr.ToLower())));
                    tripFilter = true;
                }

                if (departureDate != DateTime.MinValue) {
                    trip = trip.Where(t => t.DepartureDate == departureDate);
                    tripFilter = true;
                }

                if (creationTimeFrom != DateTime.MinValue)
                    q = q.Where(t => t.CreationTime >= creationTimeFrom.Date);

                if (creationTimeTo != DateTime.MinValue)
                    q = q.Where(t => t.CreationTime <= creationTimeTo.Date);

                if (consultantId > 0)
                    q = q.Where(t => t.ConsultantId == consultantId);

                if (!string.IsNullOrEmpty(text)) {
                    text = text.Trim().ToLower();

                    bool isStrictSearch = text.Count(t => t == '\'') > 1 || text.Count(t => t == '"') > 1;
                    string[] textArray = null;

                    if (isStrictSearch) {
                        textArray = text.Split(new string[] { "'", "\"" }, StringSplitOptions.RemoveEmptyEntries);
                    }
                    else {
                        textArray = text.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                    }

                    text = text.Replace("'", string.Empty).Replace("\"", string.Empty);

                    if (DataValidation.IsPhone(text)) {
                        text = text.Replace(" ", string.Empty);

                        if (isStrictSearch) {
                            q = q.Where(t => t.PhoneHome.ToLower().Replace(" ", string.Empty) == text
                                || t.PhoneWork.ToLower().Replace(" ", string.Empty) == text
                                || t.Mobile.ToLower().Replace(" ", string.Empty) == text
                                || t.Fax.ToLower().Replace(" ", string.Empty) == text);
                        }
                        else {
                            q = q.Where(t => t.PhoneHome.ToLower().Replace(" ", string.Empty).Contains(text)
                                || t.PhoneWork.ToLower().Replace(" ", string.Empty).Contains(text)
                                || t.Mobile.ToLower().Replace(" ", string.Empty).Contains(text)
                                || t.Fax.ToLower().Replace(" ", string.Empty).Contains(text));
                        }
                    }
                    else if (text.Contains('@')) {
                        if (isStrictSearch) {
                            q = q.Where(t => t.Email.ToLower() == text);
                        }
                        else {
                            q = q.Where(t => t.Email.ToLower().Contains(text));
                        }
                    }
                    else if (isStrictSearch) {
                        foreach (var row1 in textArray) {
                            foreach (var row2 in row1.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
                                q = q.Where(t1 => t1.Code.ToLower().Contains(text)
                                    || (t1.Title + " " + t1.FirstName + " " + t1.LastName).Trim().ToLower().Contains(row2)
                                    || t1.ProfileAddresses.Any(t2 => (t2.Address1 + " " + t2.Address2 + " " + t2.Locality + " " + t2.Region + " " + t2.PostCode + " " + t2.CountryCode).Trim().ToLower().Contains(row1)));
                            }
                        }
                    }
                    else {
                        var predicate = PredicateBuilder.False<Profile>().Or(t => t.Code.ToLower().Contains(text));

                        foreach (var row in textArray) {
                            predicate = predicate.Or(t1 => (t1.Title + " " + t1.FirstName + " " + t1.LastName).Trim().ToLower().Contains(row)
                                || t1.ProfileAddresses.Any(t2 => (t2.Address1 + " " + t2.Address2 + " " + t2.Locality + " " + t2.Region + " " + t2.PostCode + " " + t2.CountryCode).Trim().ToLower().Contains(row)));
                        }

                        q = q.Where(predicate);
                    }
                }

                if (tripFilter)
                    q = q.Where(t1 => trip.Any(t2 => t2.ProfileId == t1.Id));

                if (isExport) {
                    if (!HttpContext.IsAdministrator())
                        throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

                    var export = q.AsEnumerable().Select(row => new ProfileExportModel {
                        Code = row.Code,
                        FullName = row.FullName,
                        PhoneHome = row.PhoneHome,
                        PhoneWork = row.PhoneWork,
                        Mobile = row.Mobile,
                        Fax = row.Fax,
                        Email = row.Email,
                        Address = string.Join(Environment.NewLine, row.ProfileAddresses.Select(t => t.Address)),
                        MaritalStatus = row.MaritalStatus.GetEnumDescription(),
                        BirthDate = row.BirthDate,
                        BirthCountry = row.BirthCountry.Name,
                        Nationality = row.Nationality.Name,
                        Occupation = row.Occupation,
                        BusinessType = row.BusinessType,
                        Debtor = row.Debtor.Name,
                        Consultant = row.Consultant.Name,
                        Agency = row.Agency.Name
                    }).ToList();

                    var xlsx = new ExportToExcel<ProfileExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Profiles.xlsx");
                }

                var result = await q.OrderBy(t => t.LastName).ThenBy(t => t.FirstName).Select(row => new ProfileViewModel {
                    ProfileId = row.Id,
                    Code = row.Code,
                    FullName = row.FullName,
                    FullNameWithEmail = row.FullNameWithEmail,
                    PhoneNo = row.PhoneNo,
                    Debtor = row.DebtorId <= 0 ? string.Empty : row.Debtor.Name,
                    Consultant = row.ConsultantId <= 0 ? string.Empty : row.Consultant.Name,
                    Agency = row.Agency.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Profile_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile_CreateOrUpdate(ProfileViewModel model, int baseTripId = -1) {
            try {
                var context = Context;

                if (model.ProfileId <= 0) {
                    model.Code = Biz.Dao.ClientLedger.Profile.GetNewCode(context, model.LastName);
                    ModelState.Clear();
                    TryValidateModel(model);
                }

                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                int profileId = new ProfileCommon(HttpContext).CreateOrUpdate(Context, model, baseTripId);
                return Json(profileId);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Profile_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile_Delete([DataSourceRequest] DataSourceRequest request, ProfileViewModel model) {
            try {
                new ProfileCommon(HttpContext).Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Profile_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile_AssignToTrip(int profileId, int tripId, int[] passengerIds, int methodId) {
            try {
                var lazyContext = LazyContext;
                bool result = false;

                var q = lazyContext.Trip.Find(tripId);
                q.ProfileId = profileId;

                if (methodId == 0 || profileId <= 0) {
                    result = lazyContext.Save(q);
                    return Json(result);
                }

                var profile = lazyContext.Profile.Find(profileId);

                if (string.IsNullOrEmpty(q.Title))
                    q.Title = profile.Title;

                if (string.IsNullOrEmpty(q.FirstName))
                    q.FirstName = profile.FirstName;

                if (string.IsNullOrEmpty(q.LastName))
                    q.LastName = profile.LastName;

                if (string.IsNullOrEmpty(q.PhoneHome))
                    q.PhoneHome = profile.PhoneHome;

                if (string.IsNullOrEmpty(q.PhoneWork))
                    q.PhoneWork = profile.PhoneWork;

                if (string.IsNullOrEmpty(q.Mobile))
                    q.Mobile = profile.Mobile;

                if (string.IsNullOrEmpty(q.Fax))
                    q.Fax = profile.Fax;

                result = lazyContext.Save(q);

                if (methodId == 1)
                    return Json(result);

                new TripCommon(HttpContext).CreateTripFromProfile(lazyContext, profileId, passengerIds, tripId);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Profile_AssignToTrip", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile_CreateTrip(int profileId, int[] passengerIds) {
            try {
                int tripId = new TripCommon(HttpContext).CreateTripFromProfile(LazyContext, profileId, passengerIds);
                return Json(new { TripId = tripId });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Profile_CreateTrip", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Profile_GetMatchingRows([DataSourceRequest] DataSourceRequest request, int profileId, string firstName, string lastName, string phoneHome, string phoneWork, string mobile, string fax, string email, DateTime? birthDate) {
            try {
                var q = Biz.Dao.ClientLedger.Profile.GetMatchingRows(Context, profileId, firstName, lastName, phoneHome, phoneWork, mobile, fax, email, birthDate);

                var result = await q.Select(row => new ProfileViewModel {
                    ProfileId = row.Id,
                    Code = row.Code,
                    FullName = row.FullName,
                    AccountName = row.AccountName,
                    Title = row.Title,
                    FirstName = row.FirstName,
                    LastName = row.LastName,
                    PhoneHome = row.PhoneHome,
                    PhoneWork = row.PhoneWork,
                    Mobile = row.Mobile,
                    Fax = row.Fax,
                    Email = row.Email,
                    BirthDate = row.BirthDate == DateTime.MinValue ? null : row.BirthDate
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Profile_GetMatchingRows", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile_GetMatchingRowCount(int profileId, string firstName, string lastName, string phoneHome, string phoneWork, string mobile, string fax, string email, DateTime? birthDate) {
            try {
                var q = Biz.Dao.ClientLedger.Profile.GetMatchingRows(Context, profileId, firstName, lastName, phoneHome, phoneWork, mobile, fax, email, birthDate);
                return Json(q.Count());
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Profile_GetMatchingRowCount", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileDuplicate_Edit() {
            try {
                return PartialView("~/Views/ClientLedger/EditorTemplates/ProfileDuplicateEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileDuplicate_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile_GetSelectedRows(int[] profileIds) {
            try {
                var profileRows = new string[profileIds.Length * 2];
                int i = 0;

                foreach (var row in Context.Profile.Where(t => profileIds.Contains(t.Id)).ToList()) {
                    profileRows[i] = row.Id.ToString();
                    profileRows[i + 1] = string.Format("{0}: {1}", row.Code, row.FullName);
                    i += 2;
                }

                return Json(profileRows);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Profile_GetSelectedRows", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile_Merge(int primaryProfileId, int[] profileIds) {
            try {
                new ProfileCommon(HttpContext).MergeProfile(Context, primaryProfileId, profileIds);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Profile_Merge", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile_GetNewCode(string lastName) {
            try {
                return Json(Biz.Dao.ClientLedger.Profile.GetNewCode(Context, lastName));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Profile_GetNewCode", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> ProfileAddress(int? parentId) {
            try {
                ViewBag.AddressParentId = parentId ?? 0;
                ViewBag.AddressReadUrl = Url.Action("ProfileAddress_Read", "ClientLedger", new { parentId = parentId ?? 0 });
                ViewBag.AddressUpdateUrl = Url.Action("ProfileAddress_CreateOrUpdate", "ClientLedger");
                ViewBag.AddressDeleteUrl = Url.Action("ProfileAddress_Delete", "ClientLedger");

                return PartialView("~/Views/Shared/EditorTemplates/AddressForm.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileAddress", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ProfileAddress_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.ProfileAddress.Where(t => t.ProfileId == parentId);

                if (!q.Any())
                    q = new List<ProfileAddress> { new ProfileAddress() }.AsQueryable();

                var result = await q.OrderByDescending(t => t.IsDefault).Select(row => new AddressViewModel {
                    AddressId = row.Id,
                    AddressType = row.AddressType,
                    ParentId = row.ProfileId,
                    Address1 = row.Address1,
                    Address2 = row.Address2,
                    Locality = row.Locality,
                    Region = row.Region,
                    PostCode = row.PostCode,
                    CountryCode = row.CountryCode,
                    IsDefaultAddress = row.IsDefault,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileAddress_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileAddress_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                ProfileAddressCommon.CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileAddress_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileAddress_Delete([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                var context = Context;
                var q = context.ProfileAddress.Find(model.AddressId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileAddress_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ProfileAirline_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.ProfileAirline.Include(t => t.Passenger).Include(t => t.Airline).Where(t => t.Id > 0 && t.ProfileId == parentId).OrderBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName).ThenBy(t => t.Airline.Name);

                var result = await q.Select(row => new ProfileAirlineViewModel {
                    ProfileAirlineId = row.Id,
                    ProfileId = row.ProfileId,
                    PassengerId = row.PassengerId,
                    Passenger = row.PassengerId <= 0 ? string.Empty : row.Passenger.FullName,
                    AirlineId = row.AirlineId,
                    Airline = row.AirlineId <= 0 ? string.Empty : row.Airline.Name,
                    AirlineSeating = row.AirlineSeating,
                    FlightClass = row.FlightClass,
                    TravelZone = row.TravelZone,
                    SeatNo = row.SeatNo,
                    Comments = row.Comments,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileAirline_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileAirline_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ProfileAirlineViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                ProfileAirline q = null;

                if (model.ProfileAirlineId <= 0) {
                    q = new ProfileAirline();
                }
                else {
                    q = context.ProfileAirline.Find(model.ProfileAirlineId);
                }

                q.ProfileId = model.ProfileId;
                q.PassengerId = model.PassengerId ?? 0;
                q.AirlineId = model.AirlineId ?? 0;
                q.AirlineSeating = model.AirlineSeating;
                q.FlightClass = model.FlightClass;
                q.TravelZone = model.TravelZone;
                q.SeatNo = model.SeatNo.ToStringExt();
                q.Comments = model.Comments.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ProfileAirlineId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileAirline_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileAirline_Delete([DataSourceRequest] DataSourceRequest request, ProfileAirlineViewModel model) {
            try {
                var context = Context;
                var q = context.ProfileAirline.Find(model.ProfileAirlineId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileAirline_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ProfileClubMembership_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.ProfileClubMembership.Include(t => t.Passenger).Include(t => t.ClubMembership).Where(t => t.Id > 0 && t.ProfileId == parentId).OrderBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName).ThenBy(t => t.ClubMembership.Name);

                var result = await q.Select(row => new ProfileClubMembershipViewModel {
                    ProfileClubMembershipId = row.Id,
                    ProfileId = row.ProfileId,
                    PassengerId = row.PassengerId,
                    Passenger = row.PassengerId <= 0 ? string.Empty : row.Passenger.FullName,
                    ClubMembershipId = row.ClubMembershipId,
                    ClubMembership = row.ClubMembershipId <= 0 ? string.Empty : row.ClubMembership.Name,
                    ClubMembershipNo = row.ClubMembershipNo,
                    ClubMembershipPin = row.ClubMembershipPin,
                    PointsEarned = row.PointsEarned,
                    Comments = row.Comments,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileClubMembership_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileClubMembership_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ProfileClubMembershipViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                ProfileClubMembership q = null;

                if (model.ProfileClubMembershipId <= 0) {
                    q = new ProfileClubMembership();
                }
                else {
                    q = context.ProfileClubMembership.Find(model.ProfileClubMembershipId);
                }

                q.ProfileId = model.ProfileId;
                q.PassengerId = model.PassengerId ?? 0;
                q.ClubMembershipId = model.ClubMembershipId ?? 0;
                q.ClubMembershipNo = model.ClubMembershipNo.ToStringExt();
                q.ClubMembershipPin = model.ClubMembershipPin.ToStringExt();
                q.PointsEarned = model.PointsEarned;
                q.Comments = model.Comments.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ProfileClubMembershipId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileClubMembership_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileClubMembership_Delete([DataSourceRequest] DataSourceRequest request, ProfileClubMembershipViewModel model) {
            try {
                var context = Context;
                var q = context.ProfileClubMembership.Find(model.ProfileClubMembershipId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileClubMembership_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ProfileFutureDestination_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.ProfileFutureDestination.Include(t => t.Passenger).Include(t => t.Destination).Where(t => t.Id > 0 && t.ProfileId == parentId).OrderBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName).ThenBy(t => t.Destination.Name);

                var result = await q.Select(row => new ProfileFutureDestinationViewModel {
                    ProfileFutureDestinationId = row.Id,
                    ProfileId = row.ProfileId,
                    PassengerId = row.PassengerId,
                    DestinationId = row.DestinationId,
                    FutureDestinationComments = row.Comments,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileFutureDestination_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileFutureDestination_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ProfileFutureDestinationViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                ProfileFutureDestination q = null;

                if (model.ProfileFutureDestinationId <= 0) {
                    q = new ProfileFutureDestination();
                }
                else {
                    q = context.ProfileFutureDestination.Find(model.ProfileFutureDestinationId);
                }

                q.ProfileId = model.ProfileId;
                q.PassengerId = model.PassengerId ?? 0;
                q.DestinationId = model.DestinationId ?? 0;
                q.Comments = model.FutureDestinationComments.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ProfileFutureDestinationId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileFutureDestination_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileFutureDestination_Delete([DataSourceRequest] DataSourceRequest request, ProfileFutureDestinationViewModel model) {
            try {
                var context = Context;
                var q = context.ProfileFutureDestination.Find(model.ProfileFutureDestinationId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileFutureDestination_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ProfileLeisureActivity_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.ProfileLeisureActivity.Include(t => t.Passenger).Include(t => t.LeisureActivity).Where(t => t.Id > 0 && t.ProfileId == parentId).OrderBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName).ThenBy(t => t.LeisureActivity.Name);

                var result = await q.Select(row => new ProfileLeisureActivityViewModel {
                    ProfileLeisureActivityId = row.Id,
                    ProfileId = row.ProfileId,
                    PassengerId = row.PassengerId,
                    LeisureActivityId = row.LeisureActivityId,
                    LeisureActivityComments = row.Comments,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileLeisureActivity_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileLeisureActivity_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ProfileLeisureActivityViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                ProfileLeisureActivity q = null;

                if (model.ProfileLeisureActivityId <= 0) {
                    q = new ProfileLeisureActivity();
                }
                else {
                    q = context.ProfileLeisureActivity.Find(model.ProfileLeisureActivityId);
                }

                q.ProfileId = model.ProfileId;
                q.PassengerId = model.PassengerId ?? 0;
                q.LeisureActivityId = model.LeisureActivityId ?? 0;
                q.Comments = model.LeisureActivityComments.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ProfileLeisureActivityId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileLeisureActivity_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileLeisureActivity_Delete([DataSourceRequest] DataSourceRequest request, ProfileLeisureActivityViewModel model) {
            try {
                var context = Context;
                var q = context.ProfileLeisureActivity.Find(model.ProfileLeisureActivityId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileLeisureActivity_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ProfileSpecialRequest_Read([DataSourceRequest] DataSourceRequest request, int parentId, SpecialRequestType specialRequestType) {
            try {
                var q = Context.ProfileSpecialRequest.Include(t => t.Passenger).Include(t => t.SpecialRequest).Where(t => t.Id > 0 && t.ProfileId == parentId);

                if (specialRequestType != SpecialRequestType.NotSpecified)
                    q = q.Where(t => t.SpecialRequest.SpecialRequestType == specialRequestType);

                var result = await q.OrderBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName).ThenBy(t => t.SpecialRequest.Description).Select(row => new ProfileSpecialRequestViewModel {
                    ProfileSpecialRequestId = row.Id,
                    ProfileId = row.ProfileId,
                    PassengerId = row.PassengerId,
                    Passenger = row.Passenger.FullName,
                    SpecialRequestId = row.SpecialRequestId,
                    SpecialRequest = row.SpecialRequest.Description,
                    SpecialRequestComments = row.Comments,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileSpecialRequest_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileSpecialRequest_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ProfileSpecialRequestViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                ProfileSpecialRequest q = null;

                if (model.ProfileSpecialRequestId <= 0) {
                    q = new ProfileSpecialRequest();
                }
                else {
                    q = context.ProfileSpecialRequest.Find(model.ProfileSpecialRequestId);
                }

                q.ProfileId = model.ProfileId;
                q.PassengerId = model.PassengerId ?? 0;
                q.SpecialRequestId = model.SpecialRequestId ?? 0;
                q.Comments = model.SpecialRequestComments.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ProfileSpecialRequestId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileSpecialRequest_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileSpecialRequest_Delete([DataSourceRequest] DataSourceRequest request, ProfileSpecialRequestViewModel model) {
            try {
                var context = Context;
                var q = context.ProfileSpecialRequest.Find(model.ProfileSpecialRequestId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileSpecialRequest_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ProfileSupplier_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.ProfileSupplier.Include(t => t.Passenger).Include(t => t.SupplierChain).Include(t => t.Supplier).Where(t => t.Id > 0 && t.ProfileId == parentId).OrderBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName).ThenBy(t => t.Supplier.Name);

                var result = await q.Select(row => new ProfileSupplierViewModel {
                    ProfileSupplierId = row.Id,
                    ProfileId = row.ProfileId,
                    PassengerId = row.PassengerId,
                    Passenger = row.PassengerId <= 0 ? string.Empty : row.Passenger.FullName,
                    SupplierChainId = row.SupplierChainId,
                    SupplierChain = row.SupplierChainId <= 0 ? string.Empty : row.SupplierChain.Name,
                    SupplierId = row.SupplierId,
                    Supplier = row.SupplierId <= 0 ? string.Empty : row.Supplier.Name,
                    SupplierServiceId = row.SupplierServiceId,
                    SupplierService = row.SupplierServiceId <= 0 ? string.Empty : row.SupplierService.Name,
                    ReferenceNo = row.ReferenceNo,
                    Rate = row.Rate,
                    IsSmoking = row.IsSmoking,
                    Comments = row.Comments,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileSupplier_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileSupplier_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ProfileSupplierViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                ProfileSupplier q = null;

                if (model.ProfileSupplierId <= 0) {
                    q = new ProfileSupplier();
                }
                else {
                    q = context.ProfileSupplier.Find(model.ProfileSupplierId);
                }

                if (model.SupplierChainId > 0)
                    model.SupplierId = -1;

                q.ProfileId = model.ProfileId;
                q.PassengerId = model.PassengerId ?? 0;
                q.SupplierChainId = model.SupplierChainId ?? 0;
                q.SupplierId = model.SupplierId ?? 0;
                q.SupplierServiceId = model.SupplierServiceId ?? 0;
                q.ReferenceNo = model.ReferenceNo.ToStringExt();
                q.Rate = model.Rate;
                q.IsSmoking = model.IsSmoking;
                q.Comments = model.Comments.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ProfileSupplierId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileSupplier_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProfileSupplier_Delete([DataSourceRequest] DataSourceRequest request, ProfileSupplierViewModel model) {
            try {
                var context = Context;
                var q = context.ProfileSupplier.Find(model.ProfileSupplierId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileSupplier_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Trips
        public IActionResult QuotesAndBookings() {
            ViewBag.DefaultCurrencyId = AppSettings.Setting(HttpContext.CurrentCustomerId()).CurrencyId;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ClientDetails_CreateOrUpdate(TripViewModel model, bool createPassengerFromClientDetails) {
            try {
                if (model.ClientAccountType == ClientAccountType.Client) {
                    model.DebtorId = -1;
                    model.DebtorBookedById = -1;
                    model.DebtorAuthorisedById = -1;
                    model.DebtorOrderNo = string.Empty;
                    model.DebtorTravelReason = string.Empty;
                    model.DebtorVideoConferencingConsidered = false;
                    model.DebtorVideoConferencingReasonRejected = string.Empty;

                    ModelState.Clear();
                    TryValidateModel(model);
                }

                if ((model.ChecklistContactById ?? 0) == 0 || (model.CancellationById ?? 0) == 0) {
                    model.ChecklistContactById = (model.ChecklistContactById ?? 0) == 0 ? -1 : model.ChecklistContactById;
                    model.CancellationById = (model.CancellationById ?? 0) == 0 ? -1 : model.CancellationById;
                    ModelState.Clear();
                    TryValidateModel(model);
                }

                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                if (model.TripDepartureDate != DateTime.MinValue && model.TripReturnDate != DateTime.MinValue && model.TripDepartureDate > model.TripReturnDate)
                    throw new UnreportedException("Departure Date cannot be greater than Return Date.");

                if (model.ConsultantId <= 0)
                    throw new UnreportedException("Consultant is required.");

                if (model.SourceId <= 0)
                    throw new UnreportedException("Source is required.");

                if (model.CategoryId <= 0)
                    throw new UnreportedException("Category is required.");

                if (model.DestinationId <= 0)
                    throw new UnreportedException("Destination is required.");

                new TripCommon(HttpContext).CreateOrUpdate(Context, model, createPassengerFromClientDetails);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ClientDetails_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ClientDetails_Delete(int tripId) {
            try {
                new TripCommon(HttpContext).Delete(LazyContext, tripId);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ClientDetails_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ClientDetails_CreateBooking(int tripId, int quoteNo) {
            try {
                new TripCommon(HttpContext).CreateBooking(Context, tripId, quoteNo);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ClientDetails_CreateBooking", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ClientDetails_CancelOrRestoreQuote(int tripId, int contactMethodId, int? cancellationById, string comments) {
            try {
                var context = Context;
                var contactMethod = (ContactMethod)contactMethodId;
                var q = context.Trip.Include(t => t.CancellationBy).Single(t => t.Id == tripId);

                string message = null;

                if (q.IsCancellation) {
                    q.CancellationContactMethod = ContactMethod.NotSpecified;
                    q.CancellationById = -1;
                    q.IsCancellation = false;
                    message = "Restored";
                }
                else {
                    if (cancellationById == null)
                        throw new UnreportedException("Cancelled By is required.");

                    q.CancellationContactMethod = contactMethod;
                    q.CancellationById = cancellationById ?? -1;
                    q.CancellationBy = context.Passenger.Find(cancellationById);
                    q.IsCancellation = true;
                    message = "Cancelled";
                }

                var sb = new StringBuilder();

                if (!string.IsNullOrEmpty(q.Notes))
                    sb.AppendFormat("{0}{0}", Environment.NewLine);

                sb.AppendFormat("{0:g}: {1}{2}", HttpContext.Now(), User.Identity.Name, Environment.NewLine);
                sb.AppendFormat("{0} Quote{1}", message, Environment.NewLine);

                if (contactMethod != ContactMethod.NotSpecified && q.CancellationById > 0) {
                    sb.AppendFormat("{0} by {1} via {2}{3}", message, q.CancellationBy.FullName, contactMethod.GetEnumDescription(), Environment.NewLine);
                }
                else if (contactMethod != ContactMethod.NotSpecified) {
                    sb.AppendFormat("{0} via {1}{2}", message, contactMethod.GetEnumDescription(), Environment.NewLine);
                }
                else if (q.CancellationById > 0) {
                    sb.AppendFormat("{0} by {1}{2}", message, q.CancellationBy, Environment.NewLine);
                }

                if (!string.IsNullOrEmpty(comments))
                    sb.AppendFormat("Comments: {0}", comments);

                q.Notes += sb.ToString().TrimEnd(Environment.NewLine);

                bool result = context.Save(q);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ClientDetails_CancelOrRestoreQuote", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Trip_Open(string tripNo) {
            try {
                tripNo = string.Format("00000000{0}", tripNo).Right(8);
                var q = Context.Trip.SingleOrDefault(t => t.TripNo == tripNo);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                return Json(new { q.ProfileId, TripId = q.Id });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Trip_Open", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Trip(int profileId, int tripId, int baseTripId = -1, string message = null, MessageType messageType = MessageType.Warning) {
            var context = Context;

            Trip trip = null;
            AddressViewModel address = null;

            if (tripId <= 0) {
                var profile = context.Profile.Include(t => t.Debtor).Single(t => t.Id == profileId);

                if (profileId > 0) {
                    trip = new Trip {
                        Id = 0,
                        TripNo = string.Empty,
                        Code = string.Empty,
                        ProfileId = profileId,
                        Profile = profile,
                        ClientAccountType = profile.DebtorId > 0 ? ClientAccountType.Debtor : ClientAccountType.Client,
                        BookingType = BookingType.NotSpecified,
                        SerkoOnlineBookingStatus = SerkoOnlineBookingStatus.NotSpecified,
                        Title = profile.Title,
                        FirstName = profile.FirstName,
                        LastName = profile.LastName,
                        PhoneHome = profile.PhoneHome,
                        PhoneWork = profile.PhoneWork,
                        Mobile = profile.Mobile,
                        Fax = profile.Fax,
                        Email = profile.Email,
                        MaritalStatus = profile.MaritalStatus,
                        Occupation = profile.Occupation,
                        BusinessType = profile.BusinessType,
                        AgencyId = HttpContext.CurrentDefaultAgencyId(),
                        ConsultantId = HttpContext.CurrentConsultantId(),
                        AgentId = -1,
                        SourceId = -1,
                        CurrencyId = AppSettings.Setting(HttpContext.CurrentCustomerId()).CurrencyId,
                        GroupId = -1,
                        ClassId = -1,
                        CategoryId = -1,
                        DestinationId = -1,
                        LocationId = -1,
                        MainCityId = -1,
                        DepartureDate = DateTime.Today,
                        DebtorId = profile.DebtorId,
                        Debtor = profile.Debtor,
                        ChecklistContactMethod = ContactMethod.NotSpecified,
                        ChecklistContactById = -1,
                        CancellationContactMethod = ContactMethod.NotSpecified,
                        CancellationById = -1,
                        ChecklistFollowUpDate = DateTime.MinValue
                    };
                }
                else {
                    Trip baseTrip = null;

                    if (baseTripId > 0) {
                        baseTrip = context.Trip.Include(t => t.Profile).Include(t => t.Debtor).Include(t => t.Agency).Include(t => t.Consultant).Single(t => t.Id == baseTripId);
                    }
                    else {
                        baseTrip = new Trip {
                            Id = 0,
                            TripNo = string.Empty,
                            Code = string.Empty,
                            ProfileId = profileId,
                            Profile = profile,
                            BookingType = BookingType.NotSpecified,
                            SerkoOnlineBookingStatus = SerkoOnlineBookingStatus.NotSpecified,
                            AgencyId = HttpContext.CurrentDefaultAgencyId(),
                            ConsultantId = HttpContext.CurrentConsultantId(),
                            AgentId = -1,
                            SourceId = -1,
                            CurrencyId = AppSettings.Setting(HttpContext.CurrentCustomerId()).CurrencyId,
                            GroupId = -1,
                            ClassId = -1,
                            CategoryId = -1,
                            DestinationId = -1,
                            LocationId = -1,
                            MainCityId = -1,
                            DepartureDate = DateTime.Today,
                            DebtorId = profile.DebtorId,
                            Debtor = profile.Debtor,
                            ChecklistContactMethod = ContactMethod.NotSpecified,
                            ChecklistContactById = -1,
                            CancellationContactMethod = ContactMethod.NotSpecified,
                            CancellationById = -1,
                            ChecklistFollowUpDate = DateTime.MinValue
                        };
                    }

                    trip = new Trip {
                        Id = 0,
                        TripNo = string.Empty,
                        Code = string.Empty,
                        ProfileId = profileId,
                        Profile = profile,
                        ClientAccountType = baseTrip.ClientAccountType,
                        BookingType = baseTrip.BookingType,
                        SerkoOnlineBookingStatus = baseTrip.SerkoOnlineBookingStatus,
                        Title = baseTrip.Title,
                        FirstName = baseTrip.FirstName,
                        LastName = baseTrip.LastName,
                        PhoneHome = baseTrip.PhoneHome,
                        PhoneWork = baseTrip.PhoneWork,
                        Mobile = baseTrip.Mobile,
                        Fax = baseTrip.Fax,
                        Email = baseTrip.Email,
                        MaritalStatus = baseTrip.MaritalStatus,
                        Occupation = baseTrip.Occupation,
                        UserReferenceNo = baseTrip.UserReferenceNo,
                        BusinessType = baseTrip.BusinessType,
                        AgencyId = HttpContext.CurrentDefaultAgencyId(),
                        ConsultantId = HttpContext.CurrentConsultantId(),
                        AgentId = baseTrip.AgentId,
                        SourceId = baseTrip.SourceId,
                        CurrencyId = baseTrip.CurrencyId,
                        GroupId = baseTrip.GroupId,
                        ClassId = baseTrip.ClassId,
                        CategoryId = baseTrip.CategoryId,
                        DestinationId = baseTrip.DestinationId,
                        LocationId = baseTrip.LocationId,
                        MainCityId = baseTrip.MainCityId,
                        DebtorId = baseTrip.DebtorId,
                        Debtor = baseTrip.Debtor,
                        DebtorBookedById = baseTrip.DebtorBookedById,
                        DebtorAuthorisedById = baseTrip.DebtorAuthorisedById,
                        DebtorOrderNo = baseTrip.DebtorOrderNo,
                        DebtorTravelReason = baseTrip.DebtorTravelReason,
                        DebtorVideoConferencingConsidered = baseTrip.DebtorVideoConferencingConsidered,
                        DebtorVideoConferencingReasonRejected = baseTrip.DebtorVideoConferencingReasonRejected,
                        PaxAdult = 0,
                        PaxChild = 0,
                        PaxInfant = 0,
                        DepartureDate = baseTrip.DepartureDate,
                        ReturnDate = baseTrip.ReturnDate,
                        BalanceDueDate = baseTrip.BalanceDueDate,
                        ExchangeRate = baseTrip.ExchangeRate,
                        ChecklistContactMethod = ContactMethod.NotSpecified,
                        ChecklistContactById = -1,
                        CancellationContactMethod = ContactMethod.NotSpecified,
                        CancellationById = -1,
                        ChecklistFollowUpDate = DateTime.MinValue
                    };
                }

                if (baseTripId > 0) {
                    address = context.TripAddress.Where(t => t.TripId == baseTripId).OrderByDescending(t => t.IsDefault).Select(t => new AddressViewModel {
                        AddressId = t.Id,
                        AddressType = t.AddressType,
                        Address1 = t.Address1,
                        Address2 = t.Address2,
                        Locality = t.Locality,
                        Region = t.Region,
                        PostCode = t.PostCode,
                        CountryCode = t.CountryCode,
                        IsDefaultAddress = true
                    }).FirstOrDefault();
                }
                else {
                    address = context.ProfileAddress.Where(t => t.ProfileId == profileId).OrderByDescending(t => t.IsDefault).Select(t => new AddressViewModel {
                        AddressId = t.Id,
                        AddressType = t.AddressType,
                        Address1 = t.Address1,
                        Address2 = t.Address2,
                        Locality = t.Locality,
                        Region = t.Region,
                        PostCode = t.PostCode,
                        CountryCode = t.CountryCode,
                        IsDefaultAddress = true
                    }).FirstOrDefault();
                }
            }
            else {
                trip = context.Trip.Include(t => t.Profile).Include(t => t.Debtor).Include(t => t.Agency).Include(t => t.Consultant).Include(t => t.TripPassengers).SingleOrDefault(t => t.Id == tripId);

                if (trip == null || trip.ProfileId != profileId)
                    Response.Redirect(AppSettings.ResourceNotFoundPage);

                address = new AddressViewModel();
            }

            var model = new TripViewModel {
                TripId = trip.Id,
                TripNo = trip.TripNo,
                Code = trip.Code,
                ProfileId = profileId,
                ProfileCode = trip.Profile?.Code,
                ClientAccountType = trip.ClientAccountType,
                BookingType = trip.BookingType,
                SerkoOnlineBookingStatus = trip.SerkoOnlineBookingStatus,
                FullName = trip.FullName,
                FullNameWithEmail = trip.FullNameWithEmail,
                Title = trip.Title,
                FirstName = trip.FirstName,
                LastName = trip.LastName,
                PhoneNo = trip.PhoneNo,
                PhoneHome = trip.PhoneHome,
                PhoneWork = trip.PhoneWork,
                Mobile = trip.Mobile,
                Fax = trip.Fax,
                Email = trip.Email,
                MaritalStatus = trip.MaritalStatus,
                Occupation = trip.Occupation,
                UserReferenceNo = trip.UserReferenceNo,
                BusinessType = trip.BusinessType,
                AgencyId = trip.AgencyId <= 0 ? null : trip.AgencyId,
                Agency = trip.Agency?.Name,
                GroupId = trip.GroupId,
                ClassId = trip.ClassId,
                SourceId = trip.SourceId <= 0 ? null : trip.SourceId,
                CategoryId = trip.CategoryId <= 0 ? null : trip.CategoryId,
                DestinationId = trip.DestinationId <= 0 ? null : trip.DestinationId,
                LocationId = trip.LocationId,
                MainCityId = trip.MainCityId,
                ConsultantId = trip.ConsultantId <= 0 ? null : trip.ConsultantId,
                Consultant = trip.Consultant?.Name,
                AgentId = trip.AgentId,
                TripCurrencyId = trip.CurrencyId,
                DebtorId = trip.DebtorId,
                Debtor = trip.Debtor?.Name,
                DebtorBookedById = trip.DebtorBookedById,
                DebtorAuthorisedById = trip.DebtorAuthorisedById,
                DebtorOrderNo = trip.DebtorOrderNo,
                DebtorTravelReason = trip.DebtorTravelReason,
                DebtorVideoConferencingConsidered = trip.DebtorVideoConferencingConsidered,
                DebtorVideoConferencingReasonRejected = trip.DebtorVideoConferencingReasonRejected,
                PaxAdult = trip.PaxAdult,
                PaxChild = trip.PaxChild,
                PaxInfant = trip.PaxInfant,
                TripDepartureDate = trip.DepartureDate <= context.VoidDate ? null : trip.DepartureDate,
                TripReturnDate = trip.ReturnDate == DateTime.MinValue ? null : trip.ReturnDate,
                BalanceDueDate = trip.BalanceDueDate == DateTime.MinValue ? null : trip.BalanceDueDate,
                BalanceDue = trip.BalanceDue,
                TripExchangeRate = trip.ExchangeRate,
                TripCrs = trip.GetCrs(HttpContext.CurrentCustomerId()),
                ChecklistContactMethod = trip.ChecklistContactMethod,
                ChecklistContactById = trip.ChecklistContactById,
                ChecklistFollowUpDate = trip.ChecklistFollowUpDate == DateTime.MinValue ? null : trip.ChecklistFollowUpDate,
                ChecklistComments = trip.ChecklistComments,
                CancellationContactMethod = trip.CancellationContactMethod,
                CancellationById = trip.CancellationById,
                IsBooking = trip.IsBooking,
                IsCancellation = trip.IsCancellation,
                IsIncomplete = trip.IsIncomplete,
                TripIsLocked = trip.IsLocked,
                Rules = string.Concat(trip.Rules, trip.Profile?.Rules.Length > 0 ? string.Concat(Environment.NewLine, Environment.NewLine, "Profile Rules & Regulations:", Environment.NewLine, trip.Profile.Rules) : string.Empty, trip.Debtor.Rules.Length > 0 ? string.Concat(Environment.NewLine, Environment.NewLine, "Debtor Rules & Regulations:", Environment.NewLine, trip.Debtor.Rules).Trim(Environment.NewLine.ToCharArray()) : string.Empty),
                Remarks = string.Concat(trip.Remarks, trip.Profile?.Remarks.Length > 0 ? string.Concat(Environment.NewLine, Environment.NewLine, "Profile Remarks:", Environment.NewLine, trip.Profile.Remarks) : string.Empty, trip.Debtor.Remarks.Length > 0 ? string.Concat(Environment.NewLine, Environment.NewLine, "Debtor Remarks:", Environment.NewLine, trip.Debtor.Remarks).Trim(Environment.NewLine.ToCharArray()) : string.Empty),
                Notes = trip.Notes,
                LastWriteTime = trip.LastWriteTime.ToLocalTime(),
                CreationTime = trip.CreationTime.ToLocalTime(),
                LastWriteUser = trip.LastWriteUser,
                CreationUser = trip.CreationUser,
                AddressViewModel = address
            };

            await HttpContext.UpdateNavigateUrl(Cache, "Profile", string.Format("/ClientLedger/Profile/?profileId={0}", profileId));

            if (baseTripId > 0) {
                await HttpContext.UpdateNavigateUrl(Cache, "Quote/Booking", string.Format("/ClientLedger/Trip/?profileId={0}&tripId={1}&baseTripId={2}", profileId, tripId, baseTripId));
            }
            else {
                await HttpContext.UpdateNavigateUrl(Cache, "Quote/Booking", string.Format("/ClientLedger/Trip/?profileId={0}&tripId={1}", profileId, tripId));
            }

            ViewBag.Message = message;
            ViewBag.MessageType = messageType;

            return View(model);
        }

        public async Task<IActionResult> ProfileTrip_Read([DataSourceRequest] DataSourceRequest request, int profileId) {
            try {
                var q = Context.Trip.Include(t => t.Profile).Include(t => t.Debtor).Include(t => t.Agency).Include(t => t.Consultant).ThenInclude(t => t.ConsultantAgencies).Include(t => t.TripLines).ThenInclude(t => t.TripLineAir).Include(t => t.TripLines).ThenInclude(t => t.TripLineLand).Where(t => t.Id > 0 && t.ProfileId == profileId).OrderByDescending(t => t.Id).AsQueryable();

                if (!HttpContext.OtherAgencies()) {
                    var agencyIds = HttpContext.AgencyIds(Cache);
                    q = q.Where(t => agencyIds.Contains(t.AgencyId));
                }

                if (!HttpContext.OtherConsultants()) {
                    var consultantIds = HttpContext.ConsultantIds();
                    q = q.Where(t => consultantIds.Contains(t.ConsultantId));
                }

                var result = await q.Select(row => new TripViewModel {
                    TripId = row.Id,
                    TripNo = row.TripNo,
                    Code = row.Code,
                    ProfileId = row.ProfileId,
                    ProfileCode = row.ProfileId == -1 ? string.Empty : row.Profile.Code,
                    ClientAccountType = row.ClientAccountType,
                    BookingType = row.BookingType,
                    SerkoOnlineBookingStatus = row.SerkoOnlineBookingStatus,
                    FullName = row.FullName,
                    FullNameWithEmail = row.FullNameWithEmail,
                    Title = row.Title,
                    FirstName = row.FirstName,
                    LastName = row.LastName,
                    PhoneNo = row.PhoneNo,
                    PhoneHome = row.PhoneHome,
                    PhoneWork = row.PhoneWork,
                    Mobile = row.Mobile,
                    Fax = row.Fax,
                    Email = row.Email,
                    MaritalStatus = row.MaritalStatus,
                    Occupation = row.Occupation,
                    BusinessType = row.BusinessType,
                    UserReferenceNo = row.UserReferenceNo,
                    ConsultantId = row.ConsultantId,
                    Consultant = row.Consultant.Name,
                    AgencyId = row.AgencyId,
                    Agency = row.Agency.Name,
                    AgentId = row.AgentId,
                    SourceId = row.SourceId,
                    TripCurrencyId = row.CurrencyId,
                    GroupId = row.GroupId,
                    ClassId = row.ClassId,
                    CategoryId = row.CategoryId,
                    LocationId = row.LocationId,
                    DestinationId = row.DestinationId,
                    MainCityId = row.MainCityId,
                    DebtorId = row.DebtorId,
                    Debtor = row.Debtor.Name,
                    DebtorBookedById = row.DebtorBookedById,
                    DebtorAuthorisedById = row.DebtorAuthorisedById,
                    DebtorOrderNo = row.DebtorOrderNo,
                    DebtorTravelReason = row.DebtorTravelReason,
                    DebtorVideoConferencingConsidered = row.DebtorVideoConferencingConsidered,
                    DebtorVideoConferencingReasonRejected = row.DebtorVideoConferencingReasonRejected,
                    PaxAdult = row.PaxAdult,
                    PaxChild = row.PaxChild,
                    PaxInfant = row.PaxInfant,
                    TripDepartureDate = row.DepartureDate <= AppConstants.VoidDate ? null : row.DepartureDate,
                    TripReturnDate = row.ReturnDate == DateTime.MinValue ? null : row.ReturnDate,
                    BalanceDueDate = row.BalanceDueDate == DateTime.MinValue ? null : row.BalanceDueDate,
                    BalanceDue = row.BalanceDue,
                    TripExchangeRate = row.ExchangeRate,
                    TripCrs = row.GetCrs(HttpContext.CurrentCustomerId(null)),
                    ChecklistContactMethod = row.ChecklistContactMethod,
                    ChecklistContactById = row.ChecklistContactById,
                    ChecklistFollowUpDate = row.ChecklistFollowUpDate == DateTime.MinValue ? null : row.ChecklistFollowUpDate,
                    ChecklistComments = row.ChecklistComments,
                    CancellationContactMethod = row.CancellationContactMethod,
                    CancellationById = row.CancellationById,
                    IsBooking = row.IsBooking,
                    IsCancellation = row.IsCancellation,
                    IsIncomplete = row.IsIncomplete,
                    TripIsLocked = row.IsLocked,
                    Rules = row.Rules,
                    Remarks = row.Remarks,
                    Notes = row.Notes,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProfileTrip_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Trip_Read([DataSourceRequest] DataSourceRequest request, string text, int viewOptionId, int debtorId, string orderNoTicketNo, string tripNo, string userRefNo,
            string pnr, DateTime departureDateFrom, DateTime departureDateTo, DateTime creationTimeFrom, DateTime creationTimeTo, int destinationId, int consultantId, bool includePassengers) {

            try {
                var context = Context;
                var q = context.Trip.Include(t => t.Profile).Include(t => t.Agency).Include(t => t.Consultant).ThenInclude(t => t.ConsultantAgencies).Include(t => t.TripAddresses).Include(t => t.TripPassengers).Where(t => t.Id > 0);

                if (!HttpContext.OtherAgencies())
                    q = q.Where(t => t.AgencyId == HttpContext.CurrentDefaultAgencyId(null));

                if (viewOptionId == 1) {
                    q = q.Where(t => !t.IsBooking);
                }
                else if (viewOptionId == 2) {
                    q = q.Where(t => t.IsBooking);
                }
                else if (viewOptionId == 3) {
                    q = q.Where(t => t.IsCancellation);
                }
                else if (viewOptionId == 4) {
                    q = q.Where(t => t.Id > 0 && (t.CategoryId <= 0 || t.DestinationId <= 0 || t.ConsultantId <= 0 || t.SourceId <= 0 || t.DepartureDate == DateTime.MinValue || t.FirstName.Length == 0 || t.LastName.Length == 0));
                }

                if (debtorId > 0)
                    q = q.Where(t => t.DebtorId == debtorId);

                if (!string.IsNullOrEmpty(orderNoTicketNo)) {
                    orderNoTicketNo = orderNoTicketNo.ToLower();
                    q = q.Where(t1 => t1.DebtorOrderNo.ToLower().Contains(orderNoTicketNo) || context.TripLineAirPassenger.Include(t => t.TripLineAir).ThenInclude(t => t.TripLine).Any(t2 => t2.TripLineAir.TripLine.TripId == t1.Id && t2.TicketNo.ToLower().Contains(orderNoTicketNo)));
                }

                if (!string.IsNullOrEmpty(tripNo)) {
                    tripNo = string.Format("00000000{0}", tripNo).Right(8);
                    q = q.Where(t => t.TripNo == tripNo);
                }

                if (!string.IsNullOrEmpty(userRefNo))
                    q = q.Where(t => t.UserReferenceNo.ToLower().Contains(userRefNo.ToLower()));

                if (!string.IsNullOrEmpty(pnr)) {
                    pnr = pnr.ToLower();

                    q = q.Where(t1 => context.TripLineAir.Include(t => t.TripLine).Any(t2 => t2.TripLine.TripId == t1.Id && t2.CrsPnrRef.ToLower().Contains(pnr))
                        || context.TripLineLand.Include(t => t.TripLine).Any(t2 => t2.TripLine.TripId == t1.Id && t2.CrsPnrRef.ToLower().Contains(pnr))
                        || context.TripLineAirSegment.Include(t => t.TripLineAir).ThenInclude(t => t.TripLine).Any(t2 => t2.TripLineAir.TripLine.TripId == t1.Id && t2.AirlinePnr.ToLower().Contains(pnr)));
                }

                if (departureDateFrom != DateTime.MinValue)
                    q = q.Where(t => t.DepartureDate >= departureDateFrom);

                if (departureDateTo != DateTime.MinValue)
                    q = q.Where(t => t.DepartureDate <= departureDateTo);

                if (creationTimeFrom != DateTime.MinValue)
                    q = q.Where(t => t.CreationTime >= creationTimeFrom.Date);

                if (creationTimeTo != DateTime.MinValue)
                    q = q.Where(t => t.CreationTime <= creationTimeTo.Date);

                if (destinationId > 0)
                    q = q.Where(t => t.DestinationId == destinationId);

                if (consultantId > 0)
                    q = q.Where(t => t.ConsultantId == consultantId);

                if (!string.IsNullOrEmpty(text)) {
                    text = text.Trim().ToLower();

                    bool isStrictSearch = text.Count(t => t == '\'') > 1 || text.Count(t => t == '"') > 1;
                    string[] textArray = null;

                    if (isStrictSearch) {
                        textArray = text.Split(new string[] { "'", "\"" }, StringSplitOptions.RemoveEmptyEntries);
                    }
                    else {
                        textArray = text.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                    }

                    text = text.Replace("'", string.Empty).Replace("\"", string.Empty);

                    if (text.Contains('@')) {
                        if (isStrictSearch) {
                            q = q.Where(t => t.Email.ToLower() == text);
                        }
                        else {
                            q = q.Where(t => t.Email.ToLower().Contains(text));
                        }
                    }
                    else if (text.Contains('/')) {
                        if (isStrictSearch) {
                            q = q.Where(t1 => context.TripLine.Any(t2 => t2.TripId == t1.Id && t2.Description.ToLower() == text));
                        }
                        else {
                            q = q.Where(t1 => context.TripLine.Any(t2 => t2.TripId == t1.Id && t2.Description.ToLower().Contains(text)));
                        }
                    }
                    else if (isStrictSearch) {
                        foreach (var row1 in textArray) {
                            foreach (var row2 in row1.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
                                q = q.Where(t1 => t1.Profile.Code.ToLower().Contains(text)
                                    || t1.Code.ToLower().Contains(text)
                                    || (t1.Title + " " + t1.FirstName + " " + t1.LastName).Trim().ToLower().Contains(row2)
                                    || t1.PhoneHome.ToLower().Contains(text)
                                    || t1.PhoneWork.ToLower().Contains(text)
                                    || t1.Mobile.ToLower().Contains(text)
                                    || t1.Fax.ToLower().Contains(text)
                                    || t1.TripAddresses.Any(t2 => (t2.Address1 + " " + t2.Address2 + " " + t2.Locality + " " + t2.Region + " " + t2.PostCode + " " + t2.CountryCode).Trim().ToLower().Contains(row1))
                                    || (includePassengers && t1.TripPassengers.Any(t2 => (t2.Title + " " + t2.FirstName + " " + t2.LastName).Trim().ToLower().Contains(row2))));
                            }
                        }
                    }
                    else {
                        var predicate = PredicateBuilder.False<Trip>().Or(t => t.Profile.Code.ToLower().Contains(text) || t.Code.ToLower().Contains(text));

                        foreach (var row in textArray) {
                            predicate = predicate.Or(t1 => (t1.Title + " " + t1.FirstName + " " + t1.LastName).Trim().ToLower().Contains(row)
                                || t1.PhoneHome.ToLower().Contains(text)
                                || t1.PhoneWork.ToLower().Contains(text)
                                || t1.Mobile.ToLower().Contains(text)
                                || t1.Fax.ToLower().Contains(text)
                                || t1.TripAddresses.Any(t2 => (t2.Address1 + " " + t2.Address2 + " " + t2.Locality + " " + t2.Region + " " + t2.PostCode + " " + t2.CountryCode).Trim().ToLower().Contains(row))
                                || (includePassengers && t1.TripPassengers.Any(t2 => (t2.Title + " " + t2.FirstName + " " + t2.LastName).Trim().ToLower().Contains(row))));
                        }

                        q = q.Where(predicate);
                    }
                }

                int total = q.Count();
                q = q.OrderByDescending(t => t.Id).ApplySorting(request.Groups, request.Sorts).ApplyPaging(request.Page, request.PageSize);

                var data = q.ToList().Select(row => new TripViewModel {
                    TripId = row.Id,
                    TripNo = row.TripNo,
                    Code = row.Code,
                    ProfileId = row.ProfileId,
                    ProfileCode = row.ProfileId == -1 ? string.Empty : row.Profile.Code,
                    ClientAccountType = row.ClientAccountType,
                    FullName = row.FullName,
                    FullNameWithEmail = row.FullNameWithEmail,
                    PhoneNo = row.PhoneNo,
                    Consultant = row.Consultant.Name,
                    TripDepartureDate = row.DepartureDate <= context.VoidDate ? (DateTime?)null : row.DepartureDate,
                    IsBooking = row.IsBooking,
                    IsCancellation = row.IsCancellation,
                    IsIncomplete = row.IsIncomplete,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                });

                var result = await Task.Run(() => new DataSourceResult {
                    Data = data,
                    Total = total
                });

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Trip_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Trip_Delete([DataSourceRequest] DataSourceRequest request, TripViewModel model) {
            try {
                new TripCommon(HttpContext).Delete(LazyContext, model.TripId);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Trip_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripPaymentSchedule_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.TripPaymentSchedule.Where(t => t.TripId == parentId).OrderBy(t => t.TransactionDate).Select(row => new TripPaymentScheduleViewModel {
                    TripPaymentScheduleId = row.Id,
                    TripPaymentScheduleTripId = row.TripId,
                    TripPaymentScheduleTransactionDate = row.TransactionDate == DateTime.MinValue ? null : row.TransactionDate,
                    TripPaymentScheduleAmount = row.Amount,
                    TripPaymentScheduleDescription = row.Description,
                    TripPaymentScheduleIsCompleted = row.IsCompleted,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                });

                var aggregateResults = new List<AggregateResult> {
                    new AggregateResult(q.Sum(t => (decimal?)t.TripPaymentScheduleAmount) ?? 0, new SumFunction { FunctionName = "Sum", SourceField = "TripPaymentScheduleAmount", MemberType = typeof(decimal) }),
                };

                var result = await Task.Run(() => new DataSourceResult {
                    Data = q.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize),
                    Total = q.Count(),
                    AggregateResults = aggregateResults
                });

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripPaymentSchedule_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripPaymentSchedule_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, TripPaymentScheduleViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                TripPaymentScheduleCommon.CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripPaymentSchedule_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripPaymentSchedule_Delete([DataSourceRequest] DataSourceRequest request, TripPaymentScheduleViewModel model) {
            try {
                var context = Context;
                var q = context.TripPaymentSchedule.Find(model.TripPaymentScheduleId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripPaymentSchedule_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripQuickCompletion_Edit(int tripId, int clientAccountTypeId, string sourceGridId) {
            try {
                var context = Context;

                ViewBag.TripId = tripId;
                ViewBag.ClientAccountTypeId = clientAccountTypeId;
                ViewBag.SourceGridId = sourceGridId;

                var trip = context.Trip.Find(tripId);
                ViewBag.AgencyId = trip.AgencyId;

                var tripLines = context.TripLine.Where(t => t.TripId == tripId);
                decimal amount = tripLines.Sum(t => (decimal?)(t.CostToClient - t.AmountInvoiced)) ?? 0;

                ViewBag.IsInvoiced = amount == 0;
                return PartialView("~/Views/ClientLedger/EditorTemplates/TripQuickCompletionEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripQuickCompletion_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripChecklist_Edit(int tripId) {
            try {
                var trip = Context.Trip.Find(tripId);

                if (trip == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                return PartialView("~/Views/ClientLedger/EditorTemplates/TripChecklistEdit.cshtml", new TripViewModel {
                    TripId = trip.Id,
                    TripNo = trip.TripNo,
                    ChecklistContactMethod = trip.ChecklistContactMethod,
                    ChecklistContactById = trip.ChecklistContactById,
                    ChecklistFollowUpDate = trip.ChecklistFollowUpDate == DateTime.MinValue ? null : trip.ChecklistFollowUpDate,
                    ChecklistComments = trip.ChecklistComments
                });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripChecklist_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripChecklist_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var context = Context;
                var q = context.TripChecklist.Where(t => t.TripId == parentId).OrderBy(t => t.Id);

                if (!q.Any())
                    TripChecklistCommon.Create(context, parentId);

                var result = await q.Select(row => new TripChecklistViewModel {
                    TripChecklistId = row.Id,
                    TripId = row.TripId,
                    Name = row.Name,
                    ActionDate = row.ActionDate == DateTime.MinValue ? null : row.ActionDate,
                    IsCompleted = row.IsCompleted,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripChecklist_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripChecklist_Update(int tripId, int contactMethodId, int? contactById, DateTime? followUpDate, string comments, string tripChecklistDetailModels) {
            try {
                TripChecklistCommon.Update(Context, tripId, contactMethodId, contactById, followUpDate, comments, tripChecklistDetailModels);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripChecklist_Update", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripChecklistCalendar_Read([DataSourceRequest] DataSourceRequest request, int consultantId) {
            try {
                var context = Context;
                DateTime minDate = DateTime.Today.AddYears(-1);

                var q1 = context.Trip.Where(t => t.ConsultantId == consultantId && t.ChecklistFollowUpDate > minDate);
                var q2 = context.TripChecklist.Include(t => t.Trip).Where(t => t.Trip.ConsultantId == consultantId && t.ActionDate > minDate);

                var result = await q1.Select(row => new TripChecklistCalendarViewModel {
                    TripId = row.Id,
                    TripNo = row.TripNo,
                    Title = "Follow-Up Required",
                    Description = row.ChecklistComments,
                    ContactMethod = row.ChecklistContactMethod,
                    ContactById = row.ChecklistContactById,
                    FollowUpDate = row.ChecklistFollowUpDate == DateTime.MinValue ? null : row.ChecklistFollowUpDate,
                    Comments = row.ChecklistComments,
                    BackgroundColor = AppConstants.Red,
                    Start = row.ChecklistFollowUpDate,
                    End = row.ChecklistFollowUpDate,
                    IsAllDay = true
                }).AsEnumerable().Concat(q2.Select(row => new TripChecklistCalendarViewModel {
                    TripId = row.TripId,
                    TripNo = row.Trip.TripNo,
                    Title = row.Name,
                    Description = row.Trip.ChecklistComments,
                    ContactMethod = row.Trip.ChecklistContactMethod,
                    ContactById = row.Trip.ChecklistContactById,
                    FollowUpDate = row.Trip.ChecklistFollowUpDate == DateTime.MinValue ? null : row.Trip.ChecklistFollowUpDate,
                    Comments = row.Trip.ChecklistComments,
                    BackgroundColor = row.IsCompleted ? AppConstants.Green : AppConstants.Blue,
                    Start = row.ActionDate,
                    End = row.ActionDate,
                    IsAllDay = true
                })).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripChecklistCalendar_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> TripAddress(int? parentId) {
            try {
                ViewBag.AddressParentId = parentId ?? 0;
                ViewBag.AddressReadUrl = Url.Action("TripAddress_Read", "ClientLedger", new { parentId = parentId ?? 0 });
                ViewBag.AddressUpdateUrl = Url.Action("TripAddress_CreateOrUpdate", "ClientLedger");
                ViewBag.AddressDeleteUrl = Url.Action("TripAddress_Delete", "ClientLedger");
                ViewBag.AddressAllowNewRowInsert = true;

                return PartialView("~/Views/Shared/EditorTemplates/AddressForm.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripAddress", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripAddress_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.TripAddress.Where(t => t.TripId == parentId);

                if (!q.Any())
                    q = new List<TripAddress> { new TripAddress() }.AsQueryable();

                var result = await q.OrderByDescending(t => t.IsDefault).Select(row => new AddressViewModel {
                    AddressType = row.AddressType,
                    AddressId = row.Id,
                    ParentId = row.TripId,
                    Address1 = row.Address1,
                    Address2 = row.Address2,
                    Locality = row.Locality,
                    Region = row.Region,
                    PostCode = row.PostCode,
                    CountryCode = row.CountryCode,
                    IsDefaultAddress = row.IsDefault,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripAddress_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripAddress_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                TripAddressCommon.CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripAddress_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripAddress_Delete([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                var context = Context;
                var q = context.TripAddress.Find(model.AddressId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripAddress_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripItinerary_Edit(int tripId) {
            try {
                var context = Context;
                var q = context.TripItinerary.Where(t => t.TripId == tripId).OrderBy(t => t.Name).FirstOrDefault();

                var model = new TripItineraryViewModel {
                    TripItineraryId = q?.Id ?? 0,
                    TripItineraryTripId = tripId,
                    TripItineraryName = q?.Name,
                    TripItineraryPassengerIds = string.Join(",", context.TripItineraryPassenger.Where(t => t.TripItinerary.TripId == tripId).Select(t => t.PassengerId))
                };

                return PartialView("~/Views/ClientLedger/EditorTemplates/TripItineraryEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripItinerary_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripItinerary_Update(int tripItineraryId, string name, int[] passengerIds) {
            try {
                bool result = TripItineraryCommon.Update(Context, tripItineraryId, name.Trim(), passengerIds);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripItinerary_Update", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripItinerary_Delete(int tripItineraryId) {
            try {
                bool result = TripItineraryCommon.Delete(Context, tripItineraryId);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripItinerary_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripItinerary_Build(int tripId, int tripItineraryId, int quoteNo) {
            try {
                int result = TripItineraryCommon.Build(LazyContext, tripId, tripItineraryId, quoteNo);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripItinerary_Build", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripItinerary_Reorder(int tripItineraryId, TripLineOrderType tripLineOrderType, int[] itineraryDetailIds = null) {
            try {
                bool result = TripItineraryCommon.Reorder(LazyContext, tripItineraryId, tripLineOrderType, itineraryDetailIds);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripItinerary_Reorder", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripItineraryDetail_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var lazyContext = LazyContext;

                var q = lazyContext.TripItineraryDetail.Where(t => t.TripItineraryId == parentId).OrderBy(t => t.SeqNo).AsEnumerable().Select(row => new TripItineraryDetailViewModel {
                    TripItineraryDetailId = row.Id,
                    TripItineraryId = row.TripItineraryId,
                    TripItineraryDetailTripLineId = row.TripLineId,
                    TripItineraryDetailTripLineAirSegmentId = row.TripLineAirSegmentId,
                    TripItineraryDetailTripLineType = row.TripLine.TripLineType,
                    TripItineraryDetailStartDate = row.TripLineAirSegmentId > 0 ? (row.TripLineAirSegment.DepartureDate <= lazyContext.VoidDate ? null : row.TripLineAirSegment.DepartureDate) : (row.TripLine.StartDate <= lazyContext.VoidDate ? null : row.TripLine.StartDate),
                    TripItineraryDetailEndDate = row.TripLineAirSegmentId > 0 ? (row.TripLineAirSegment.ArrivalDate <= lazyContext.VoidDate ? null : row.TripLineAirSegment.ArrivalDate) : (row.TripLine.EndDate <= lazyContext.VoidDate ? null : row.TripLine.EndDate),
                    TripItineraryDetailTime = row.TripLineAirSegmentId > 0 ? row.TripLineAirSegment.DepartureTime : string.Empty,
                    TripItineraryDetailDescription = row.TripLineAirSegmentId > 0 ? string.Concat(row.TripLineAirSegment.TripLineAir.Airline.Code.Length == 0 ? string.Empty : string.Concat(row.TripLineAirSegment.TripLineAir.Airline.Code, " - "), row.TripLineAirSegment.DepartureCity.Code, "/", row.TripLineAirSegment.ArrivalCity.Code, row.TripLine.TripLineAir.ServiceDescription.Length == 0 ? string.Empty : string.Concat(" [", row.TripLine.TripLineAir.ServiceDescription, "]")) : row.TripLine.Description,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                });

                var result = await q.ToDataSourceResultAsync(request);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripItineraryDetail_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripItineraryDetail_Delete([DataSourceRequest] DataSourceRequest request, TripItineraryDetailViewModel model) {
            try {
                var context = Context;
                var q = context.TripItineraryDetail.Find(model.TripItineraryDetailId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripItineraryDetail_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripItineraryDetail_DeleteSelections(int[] itineraryDetailIds) {
            try {
                TripItineraryCommon.DeleteSelections(Context, itineraryDetailIds);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripItineraryDetail_DeleteSelections", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineSelection_Convert(int tripId, int quoteNo) {
            try {
                TripLineSelectionCommon.Convert(Context, tripId, quoteNo);
                return Json(quoteNo);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineSelection_Convert", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineSelection_Add(int tripId, int[] tripLineIds, int quoteNo) {
            try {
                int result = TripLineSelectionCommon.Add(LazyContext, User, HttpContext.CurrentCustomerId(), tripId, tripLineIds, quoteNo);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineSelection_Add", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineSelection_Delete(int tripId, int tripLineId, int quoteNo, int[] tripLineIds = null) {
            try {
                TripLineSelectionCommon.Delete(LazyContext, User, HttpContext.CurrentCustomerId(), tripId, tripLineId, quoteNo, tripLineIds);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineSelection_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineSelection_Reorder(int tripId, int quoteNo, TripLineOrderType tripLineOrderType, int[] tripLineIds = null) {
            try {
                TripLineSelectionCommon.Reorder(LazyContext, tripId, quoteNo, tripLineOrderType, tripLineIds);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineSelection_Reorder", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripLine_Read([DataSourceRequest] DataSourceRequest request, int tripId, int quoteNo = -1, bool outstandingVouchers = false) {
            try {
                var lazyContext = LazyContext;
                var trip = lazyContext.Trip.Find(tripId) ?? new Trip();

                var tripLines = TripLineHelper.GetTripLineInformationQuery(lazyContext, HttpContext.CurrentCustomerId(), tripId, quoteNo, outstandingVouchers).ConvertAll(row => new TripLineInformationViewModel {
                    TripLineId = row.TripLineId,
                    TripId = row.TripId,
                    TripLineType = row.TripLineType,
                    ClientAccountType = row.ClientAccountType,
                    StartDate = row.StartDate == DateTime.MinValue ? null : row.StartDate,
                    EndDate = row.EndDate == DateTime.MinValue ? null : row.EndDate,
                    Creditors = row.Creditors,
                    Description = row.Description,
                    ReceiptInfo = row.ReceiptInfo,
                    PaymentInfo = row.PaymentInfo,
                    InvoiceInfo = row.InvoiceInfo,
                    PaxNo = row.PaxNo,
                    PackageNo = row.PackageNo == 0 ? null : row.PackageNo,
                    SellingPrice = row.SellingPrice,
                    Gross = row.Gross,
                    Commission = row.Commission,
                    SupplierNet = row.SupplierNet,
                    Discount = row.Discount,
                    Markup = row.Markup,
                    CostToClient = row.CostToClient,
                    Yield = row.Yield,
                    ClientToAgencyReceivable = row.ClientToAgencyReceivable,
                    ClientToAgencyReceived = row.ClientToAgencyReceived,
                    AmountReceivable = row.AmountReceivable,
                    AmountReceived = row.AmountReceived,
                    AmountPayable = row.AmountPayable,
                    AmountPaid = row.AmountPaid,
                    AmountInvoiceable = row.AmountInvoiceable,
                    AmountInvoiced = row.AmountInvoiced,
                    AmountInvoicedWithPayment = row.AmountInvoicedWithPayment,
                    PersonalTravelAmount = row.PersonalTravelAmount,
                    VoucherId = row.Voucher.Id,
                    VoucherType = row.Voucher.VoucherType,
                    VoucherPaymentClass = row.Voucher.PaymentClass,
                    VoucherDocumentNo = row.Voucher.DocumentNo,
                    VoucherAmount = row.Voucher.Amount + row.Voucher.Tax,
                    IsAllCreditCardPayment = row.IsAllCreditCardPayment,
                    CreditCardNotPaid = row.CreditCardNotPaid,
                    DoNotGenerateInvoiceLine = row.DoNotGenerateInvoiceLine,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                });

                var gridRows = tripLines.ConvertAll(t => new { Id = t.TripLineId, Amount = t.Gross });
                bool gridRowCountExceeded = false;

                if (gridRows.Count > 500) {
                    gridRows = gridRows.Take(500).ToList();
                    gridRowCountExceeded = true;
                }

                bool isAdministrator = HttpContext.AppUserRole() == AppUserRole.SystemAdministrator || HttpContext.IsGlobalUser();

                var aggregateResults = new List<AggregateResult> {
                    new AggregateResult(gridRows, new MinFunction { FunctionName = "Min", SourceField = "GridRows", MemberType = typeof(object[,]) }),
                    new AggregateResult(gridRowCountExceeded, new MinFunction { FunctionName = "Min", SourceField = "GridRowCountExceeded", MemberType = typeof(bool) }),
                    new AggregateResult(tripLines.Sum(t => (decimal?)t.Gross), new SumFunction { FunctionName = "Min", SourceField = "Gross", MemberType = typeof(decimal) }),
                    new AggregateResult(tripLines.Sum(t => (decimal?)t.Commission), new SumFunction { FunctionName = "Sum", SourceField = "Commission", MemberType = typeof(decimal) }),
                    new AggregateResult(tripLines.Sum(t => (decimal?)t.SupplierNet), new SumFunction { FunctionName = "Sum", SourceField = "SupplierNet", MemberType = typeof(decimal) }),
                    new AggregateResult(tripLines.Sum(t => (decimal?)t.Discount), new SumFunction { FunctionName = "Sum", SourceField = "Discount", MemberType = typeof(decimal) }),
                    new AggregateResult(tripLines.Sum(t => (decimal?)t.Markup), new SumFunction { FunctionName = "Sum", SourceField = "Markup", MemberType = typeof(decimal) }),
                    new AggregateResult(tripLines.Sum(t => (decimal?)t.CostToClient), new SumFunction { FunctionName = "Sum", SourceField = "CostToClient", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.Yield, new MinFunction { FunctionName = "Min", SourceField = "Yield", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.BalanceDue, new MinFunction { FunctionName = "Min", SourceField = "BalanceDue", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.ClientToAgencyReceivable, new MinFunction { FunctionName = "Min", SourceField = "ClientToAgencyReceivable", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.ClientToAgencyReceived, new MinFunction { FunctionName = "Min", SourceField = "ClientToAgencyReceived", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.ClientToAgencyReceivable - trip.ClientToAgencyReceived, new MinFunction { FunctionName = "Min", SourceField = "ClientToAgencyOutstanding", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.ClientToSupplierPayable, new MinFunction { FunctionName = "Min", SourceField = "ClientToSupplierPayable", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.ClientToSupplierPaid, new MinFunction { FunctionName = "Min", SourceField = "ClientToSupplierPaid", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.ClientToSupplierPayable - trip.ClientToSupplierPaid, new MinFunction { FunctionName = "Min", SourceField = "ClientToSupplierOutstanding", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.AgencyToSupplierPayable, new MinFunction { FunctionName = "Min", SourceField = "AgencyToSupplierPayable", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.AgencyToSupplierPaid, new MinFunction { FunctionName = "Min", SourceField = "AgencyToSupplierPaid", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.AgencyToSupplierPayable - trip.AgencyToSupplierPaid, new MinFunction { FunctionName = "Sum", SourceField = "AgencyToSupplierOutstanding", MemberType = typeof(decimal) }),
                    new AggregateResult(trip.VouchersPaidDirect, new MinFunction { FunctionName = "Min", SourceField = "VouchersPaidDirect", MemberType = typeof(decimal) }),
                    new AggregateResult(isAdministrator ? "Client to Agency Receivable + Client to Supplier Payable + Direct Paid Vouchers = Cost to Client" : string.Empty, new MinFunction { FunctionName = "Min", SourceField = "CostToClientCalculation", MemberType = typeof(string) }),
                    new AggregateResult(isAdministrator ? "Client to Supplier Payable + Direct Paid Vouchers + Agency to Supplier Payable = Gross" : string.Empty, new MinFunction { FunctionName = "Min", SourceField = "GrossCalculation", MemberType = typeof(string) }),
                    new AggregateResult(isAdministrator ? "Client to Agency Receipts/Invoices Outstanding = Balance Due" : string.Empty, new MinFunction { FunctionName = "Min", SourceField = "BalanceDueCalculation", MemberType = typeof(string) })
                };

                var result = await Task.Run(() => new DataSourceResult {
                    Data = tripLines.Skip(request.Page - 1).Take(request.PageSize),
                    Total = tripLines.Count,
                    AggregateResults = aggregateResults
                });

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLine_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLine_Delete([DataSourceRequest] DataSourceRequest request, TripLineViewModel model) {
            try {
                var lazyContext = LazyContext;

                var trip = TripLineCommon.Delete(lazyContext, model);
                trip.Update(User, HttpContext.CurrentCustomerId(), lazyContext);

                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLine_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLine_Recalculate(int tripId) {
            try {
                var lazyContext = LazyContext;
                var tripLines = lazyContext.TripLine.Where(t => t.TripId == tripId).ToList();

                if (tripLines.Count == 0) {
                    var trip = lazyContext.Trip.Find(tripId);
                    trip.Update(User, HttpContext.CurrentCustomerId(), lazyContext);
                }
                else {
                    foreach (var tripLine in tripLines) {
                        tripLine.Update(User, HttpContext.CurrentCustomerId(), lazyContext);
                    }
                }

                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLine_Recalculate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLine_SetPackageNo(int[] tripLineIds, bool clearPackage) {
            try {
                TripLineCommon.SetPackageNo(Context, tripLineIds, clearPackage);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLine_SetPackageNo", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineDuplicate_Edit(int profileId, int tripId, int[] tripLineIds, string sourceGridId) {
            try {
                var model = new TripLineDuplicateViewModel {
                    ProfileId = profileId,
                    TripId = tripId,
                    TripLineIds = tripLineIds ?? Array.Empty<int>(),
                    SourceGridId = sourceGridId
                };

                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineDuplicateEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineDuplicate_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineDuplicate_Create(int profileId, int tripId, int baseTripId, string tripLineIds, int[] sourcePassengerIds, int[] targetPassengerIds, bool includeProfile, bool includeClientDetails, bool includeTripInformation, bool includePassengerDetails) {
            try {
                tripId = new TripLineCommon(HttpContext).Duplicate(LazyContext, ref profileId, tripId, baseTripId, tripLineIds, sourcePassengerIds, targetPassengerIds, includeProfile, includeClientDetails, includeTripInformation, includePassengerDetails);
                return Json(Url.Action("Trip", "ClientLedger", new { profileId, tripId }));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineDuplicate_Create", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAir_Edit(int agencyId, int tripLineId, int tripId) {
            try {
                var lazyContext = LazyContext;

                TripLineAir q = null;
                TripLineViewModel tripLineViewModel = null;

                if (tripLineId <= 0) {
                    q = new TripLineAir {
                        TripLineId = 0,
                        TripLine = new TripLine {
                            Id = -1,
                            TripId = tripId,
                            Trip = new Trip { Id = tripId },
                        },
                        Crs = Crs.NotSpecified,
                        AirlineId = -1,
                        Airline = new Airline { Id = -1 },
                        ConditionId = -1,
                        Condition = new Condition { Id = -1 }
                    };

                    var trip = lazyContext.Trip.Find(tripId);

                    if (trip == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = 0,
                        TripId = tripId,
                        ClientAccountType = trip.ClientAccountType,
                        TripLineType = TripLineType.Air,
                        TripLineStatus = TripLineStatus.Entry,
                        PrintOnQuote = true,
                        PrintOnConfirmation = true,
                        PrintOnItinerary = true,
                        PrintOnStatement = true,
                        IsLocked = trip.IsLocked
                    };
                }
                else {
                    q = lazyContext.TripLineAir.Find(tripLineId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = q.TripLine.Id,
                        TripId = q.TripLine.TripId,
                        ClientAccountType = q.TripLine.Trip.ClientAccountType,
                        TripLineType = q.TripLine.TripLineType,
                        TripLineStatus = q.TripLine.TripLineStatus,
                        PersonalTravelAmount = q.TripLine.PersonalTravelAmount,
                        PrintOnQuote = q.TripLine.PrintOnQuote,
                        PrintOnConfirmation = q.TripLine.PrintOnConfirmation,
                        PrintOnItinerary = q.TripLine.PrintOnItinerary,
                        PrintOnStatement = q.TripLine.PrintOnStatement,
                        LastWriteTime = q.TripLine.LastWriteTime.ToLocalTime(),
                        CreationTime = q.TripLine.CreationTime.ToLocalTime(),
                        LastWriteUser = q.TripLine.LastWriteUser,
                        CreationUser = q.TripLine.CreationUser
                    };
                }

                var model = new TripLineAirViewModel {
                    TripLineId = q.TripLineId,
                    AirlineId = q.AirlineId,
                    Airline = q.Airline.Name,
                    DepartureDate = q.DepartureDate <= AppConstants.VoidDate ? (DateTime?)null : q.DepartureDate,
                    ValidUntilDate = q.ValidUntilDate == DateTime.MinValue ? null : q.ValidUntilDate,
                    TripLineAirCrs = q.Crs,
                    TripLineAirCrsPnrRef = q.CrsPnrRef,
                    ReferenceNo = q.ReferenceNo,
                    ConditionId = q.ConditionId,
                    Condition = q.Condition.Name,
                    ServiceDescription = q.ServiceDescription,
                    Gross = q.Gross,
                    SupplierNet = q.SupplierNet,
                    CostToClient = q.GetCostToClient(HttpContext.CurrentCustomerId()),
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser,
                    TripLineViewModel = tripLineViewModel
                };

                ViewBag.AgencyId = agencyId;
                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineAirEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAir_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAir_CreateOrUpdate(TripLineAirViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var result = new TripLineAirCommon(HttpContext).CreateOrUpdate(model);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAir_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAir_UpdateModel(TripLineAirViewModel model) {
            try {
                var q = Context.TripLineAir.Find(model.TripLineId == 0 ? -1 : model.TripLineId);

                model.Gross = q.Gross;
                model.SupplierNet = q.SupplierNet;
                model.CostToClient = q.GetCostToClient(HttpContext.CurrentCustomerId());

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAir_UpdateModel", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirSegment_Edit(int tripLineAirSegmentId, int tripLineId, bool duplicateRow) {
            try {
                var context = Context;

                TripLineAirSegment q = null;

                if (tripLineAirSegmentId <= 0) {
                    q = new TripLineAirSegment {
                        Id = 0,
                        TripLineId = tripLineId,
                        TripStatus = TripStatus.OnRequest,
                        DepartureCityId = -1,
                        ArrivalCityId = -1,
                        DepartureDate = DateTime.MinValue,
                        InternationalDateOffset = InternationalDateOffset.None,
                        AirportType = AirportType.International,
                        AircraftId = -1,
                        Aircraft = context.Aircraft.Find(-1)
                    };
                }
                else {
                    q = context.TripLineAirSegment.Find(tripLineAirSegmentId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);
                }

                var model = new TripLineAirSegmentViewModel {
                    TripLineAirSegmentId = q.Id,
                    TripLineId = q.TripLineId,
                    TripStatus = q.TripStatus,
                    DepartureCityId = q.DepartureCityId,
                    ArrivalCityId = q.ArrivalCityId,
                    Class = q.Class,
                    FlightNo = q.FlightNo,
                    DepartureDateStatus = q.DepartureDate == DateTime.MinValue ? DepartureDateStatus.Open : q.DepartureDate == AppConstants.VoidDate ? DepartureDateStatus.ARNK : DepartureDateStatus.Normal,
                    TripLineAirSegmentDepartureDate = q.DepartureDate <= AppConstants.VoidDate ? (DateTime?)null : q.DepartureDate,
                    CheckInTime = q.CheckInTime,
                    DepartureTime = q.DepartureTime,
                    ArrivalTime = q.ArrivalTime,
                    FlightTime = q.FlightTime,
                    InternationalDateOffset = q.InternationalDateOffset,
                    AirportType = q.AirportType,
                    DepartureTerminal = q.DepartureTerminal,
                    ArrivalTerminal = q.ArrivalTerminal,
                    TripLineAirSegmentAirlinePnr = q.AirlinePnr,
                    AircraftId = q.AircraftId,
                    Operator = q.Operator,
                    Meals = q.Meals,
                    TransitStops = q.TransitStops,
                    DistanceFlownKm = q.DistanceFlownKm,
                    CO2Emissions = q.CO2Emissions,
                    SeqNo = q.SeqNo,
                    CrsKey = q.CrsKey
                };

                if (duplicateRow)
                    model.TripLineAirSegmentId = 0;

                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineAirSegmentEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirSegment_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripLineAirSegment_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.TripLineAirSegment.Include(t => t.TripLineAirPassengerAirSegments).Where(t => t.TripLineId > 0 && t.TripLineId == parentId).OrderBy(t => t.SeqNo).ThenBy(t => t.Id);

                var result = await q.Select(row => new TripLineAirSegmentViewModel {
                    TripLineAirSegmentId = row.Id,
                    TripLineId = row.TripLineId,
                    TripStatus = row.TripStatus,
                    DepartureCityId = row.DepartureCityId,
                    DepartureCity = row.DepartureCity.Name,
                    Class = row.Class,
                    ArrivalCityId = row.ArrivalCityId,
                    ArrivalCity = row.ArrivalCity.Name,
                    FlightNo = row.FlightNo,
                    DepartureDateStatus = row.DepartureDate == DateTime.MinValue ? DepartureDateStatus.Open : row.DepartureDate == AppConstants.VoidDate ? DepartureDateStatus.ARNK : DepartureDateStatus.Normal,
                    TripLineAirSegmentDepartureDate = row.DepartureDate <= AppConstants.VoidDate ? null : row.DepartureDate,
                    CheckInTime = row.CheckInTime,
                    DepartureTime = row.DepartureTime,
                    ArrivalTime = row.ArrivalTime,
                    FlightTime = row.FlightTime,
                    InternationalDateOffset = row.InternationalDateOffset,
                    DistanceFlownKm = row.DistanceFlownKm,
                    CO2Emissions = row.CO2Emissions,
                    AirportType = row.AirportType,
                    DepartureTerminal = row.DepartureTerminal,
                    ArrivalTerminal = row.ArrivalTerminal,
                    TripLineAirSegmentAirlinePnr = row.AirlinePnr,
                    AircraftId = row.AircraftId,
                    Aircraft = row.Aircraft.Name,
                    Operator = row.Operator,
                    Meals = row.Meals,
                    TransitStops = row.TransitStops.IndexOf(Environment.NewLine) == -1 ? row.TransitStops : string.Concat(row.TransitStops.Substring(0, row.TransitStops.IndexOf(Environment.NewLine)), "..."),
                    SeqNo = row.SeqNo,
                    AirPassengers = string.Join("; ", row.TripLineAirPassengerAirSegments.Select(t => t.TripLineAirPassenger.Passenger.FullName).ToArray().Distinct()),
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirSegment_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirSegment_CreateOrUpdate(TripLineAirSegmentViewModel model) {
            try {
                if (!ModelState.IsValid) {
                    string errors = WebUtils.GetModelStateErrors(ModelState);

                    if (errors.Length > 0)
                        throw new UnreportedException(errors);
                }

                var result = new TripLineAirSegmentCommon(HttpContext).CreateOrUpdate(model);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirSegment_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirSegment_Delete([DataSourceRequest] DataSourceRequest request, TripLineAirSegmentViewModel model) {
            try {
                new TripLineAirSegmentCommon(HttpContext).Delete(LazyContext, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirSegment_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirSegment_Reorder(int tripLineId, int index, int direction) {
            try {
                new TripLineAirSegmentCommon(HttpContext).Reorder(Context, tripLineId, index, direction);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirSegment_Reorder", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> TripLineAirSegmentQuickCompletion_Edit(int tripLineId, string message = null, MessageType messageType = MessageType.Warning) {
            try {
                ViewData["DepartureCityCodeList"] = Lists.GetCityCodeList(Context).Select(t => t.Value).ToArray();
                ViewData["ArrivalCityCodeList"] = Lists.GetCityCodeList(Context).Select(t => t.Value).ToArray();
                ViewData["DepartureDateStatusList"] = Lists.GetEnumList<DepartureDateStatus>();
                ViewData["InternationalDateOffsetList"] = Lists.GetEnumList<InternationalDateOffset>(EnumOrderByType.Value);

                ViewBag.TripLineAirSegmentQuickCompletionTripLineId = tripLineId;
                ViewBag.Message = message;
                ViewBag.MessageType = messageType;

                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineAirSegmentQuickCompletionEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirSegmentQuickCompletion_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirSegmentQuickCompletion_Create(IEnumerable<TripLineAirSegmentQuickCompletionViewModel> models, int parentId) {
            try {
                new TripLineAirSegmentCommon(HttpContext).QuickCompletionCreate(LazyContext, models, parentId);
                return Json(models);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirSegmentQuickCompletion_Create", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirSegment_AddArnks(int tripLineId) {
            try {
                bool result = new TripLineAirCommon(HttpContext).InsertArnkAirSegments(User, HttpContext.CurrentCustomerId(), tripLineId);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirSegment_AddArnks", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirPassenger_Edit(int agencyId, int tripLineAirPassengerId, int tripLineId, int clientAccountTypeId, bool duplicateRow) {
            try {
                var lazyContext = LazyContext;
                TripLineAirPassenger q = null;

                if (tripLineAirPassengerId <= 0) {
                    var creditor = Creditor.GetBspAgent(lazyContext, HttpContext.CurrentCustomerId(), TripLineType.Air);
                    var supplier = Supplier.GetBspAgent(lazyContext, HttpContext.CurrentCustomerId(), TripLineType.Air);

                    var tripLine = lazyContext.TripLine.Find(tripLineId == 0 ? -1 : tripLineId);

                    q = new TripLineAirPassenger {
                        Id = 0,
                        TripLineId = tripLine.Id,
                        TripLineAir = tripLine.TripLineAir,
                        CreditorId = creditor.Id,
                        Creditor = creditor,
                        SupplierId = supplier.Id,
                        Supplier = supplier,
                        IssueDate = DateTime.Today,
                        PassengerId = -1,
                        AirlineId = tripLine.TripLineAir.AirlineId,
                        Airline = tripLine.TripLineAir.Airline,
                        FormOfPaymentId = -1,
                        FormOfPayment = lazyContext.FormOfPayment.Find(-1),
                        SaleTypeId = -1,
                        SaleType = lazyContext.SaleType.Find(-1),
                        DiscountReasonId = -1,
                        DiscountReason = lazyContext.DiscountReason.Find(-1),
                        OverrideBasis = OverrideBasis.None,
                        MarkupStrategyId = -1,
                        BspEntryType = BspEntryType.Ticket,
                        TicketMethod = TicketMethod.ETicket,
                        OfferedReasonId = -1,
                        OfferedReason = lazyContext.OfferedReason.Find(-1),
                        IncludeMarkupInCreditCardPayment = creditor.IncludeMarkupInCreditCardPayment
                    };
                }
                else {
                    q = lazyContext.TripLineAirPassenger.Find(tripLineAirPassengerId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);
                }

                int sign = q.BspEntryType == BspEntryType.Refund ? -1 : 1;

                var model = new TripLineAirPassengerViewModel {
                    TripLineAirPassengerId = q.Id,
                    TripLineId = q.TripLineId,
                    TripId = q.TripLineAir.TripLine.TripId,
                    ClientAccountType = q.Id <= 0 ? (ClientAccountType)clientAccountTypeId : q.TripLineAir.TripLine.Trip.ClientAccountType,
                    CreditorId = q.CreditorId,
                    SupplierId = q.SupplierId,
                    IssueDate = q.IssueDate == DateTime.MinValue ? null : q.IssueDate,
                    PassengerId = q.PassengerId,
                    TripLineAirPassengerAirlineId = q.AirlineId,
                    FormOfPaymentId = q.FormOfPaymentId,
                    SaleTypeId = q.SaleTypeId <= 0 ? null : q.SaleTypeId,
                    CommissionRate = q.CommissionRate,
                    DiscountRate = q.DiscountRate,
                    DiscountReasonId = q.DiscountReasonId,
                    OverrideRate = q.OverrideRate,
                    OverrideBasis = q.OverrideBasis,
                    MarkupRate = q.MarkupRate,
                    MarkupStrategyId = q.MarkupStrategyId,
                    IsCreditCardDiscountApplicable = q.IsCreditCardDiscountApplicable,
                    IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment,
                    TicketNo = q.TicketNoMain,
                    TicketNoConjunction = q.TicketNoConjunction,
                    OriginalTicketNo = q.OriginalTicketNoMain,
                    OriginalTicketNoConjunction = q.OriginalTicketNoConjunction,
                    ConnectingTicketNos = q.ConnectingTicketNos,
                    BspEntryType = q.BspEntryType,
                    TicketMethod = q.TicketMethod,
                    OfferedReasonId = q.OfferedReasonId,
                    TripLineAirPassengerAmountPaid = q.Id <= 0 ? 0 : q.GetAmountPaid(lazyContext),
                    IsBspAgent = q.Creditor.IsBspAgent,
                    Comments = q.Comments,

                    FullFare = sign * q.FullFare,
                    OfferedFare = sign * q.OfferedFare,
                    TicketedFare = sign * q.TicketedFare,
                    NonCommissionable = sign * q.NonCommissionable,
                    Commission = sign * q.Commission,
                    RemainderCommission = sign * q.RemainderCommission,
                    OverrideAmount = sign * q.OverrideAmount,
                    Discount = sign * q.Discount,
                    Markup = sign * q.Markup,
                    PersonalTravelAmount = sign * q.PersonalTravelAmount,

                    TripLineAirPassengerGross = sign * q.Gross,
                    TripLineAirPassengerSupplierNet = sign * q.SupplierNet,
                    TripLineAirPassengerSellingPrice = sign * q.SellingPrice,
                    TripLineAirPassengerCostToClient = sign * q.GetCostToClient(HttpContext.CurrentCustomerId()),
                    TripLineAirPassengerAmountPayable = q.Id <= 0 ? 0 : sign * q.GetAmountPayable(HttpContext.CurrentCustomerId())
                };


                if (duplicateRow) {
                    model.TripLineAirPassengerId = 0;
                    model.TicketNo = string.Empty;
                    model.TicketNoConjunction = string.Empty;
                    model.OriginalTicketNo = string.Empty;
                    model.OriginalTicketNoConjunction = string.Empty;
                }

                ViewBag.AgencyId = agencyId;
                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineAirPassengerEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirPassenger_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripLineAirPassenger_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var lazyContext = LazyContext;

                var q = lazyContext.TripLineAirPassenger.Include(t => t.TripLineAir).ThenInclude(t => t.TripLine).ThenInclude(t => t.Trip)
                    .Include(t => t.TripLineAir).ThenInclude(t => t.TripLine).ThenInclude(t => t.Vouchers)
                    .Include(t => t.BspDetails).Include(t => t.NonBspDetails).Include(t => t.PaymentDetails)
                    .Include(t => t.Passenger).ThenInclude(t => t.Trip).Include(t => t.Creditor).Include(t => t.Supplier)
                    .Include(t => t.TripLineAirPassengerAirSegments).ThenInclude(t => t.TripLineAirSegment).ThenInclude(t => t.DepartureCity)
                    .Include(t => t.TripLineAirPassengerAirSegments).ThenInclude(t => t.TripLineAirSegment).ThenInclude(t => t.ArrivalCity)
                    .Include(t => t.Airline).Include(t => t.FormOfPayment).Include(t => t.SaleType).Include(t => t.DiscountReason).Include(t => t.MarkupStrategy).Include(t => t.OfferedReason)
                    .Where(t => t.TripLineId > 0 && t.TripLineId == parentId);

                var result = await q.AsEnumerable().OrderBy(t => t.Passenger.IsLeadPassenger ? 0 : 1).ThenBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName).ThenBy(t => t.Passenger.Title).ThenBy(t => t.Id).Select(row => new TripLineAirPassengerViewModel {
                    TripLineAirPassengerId = row.Id,
                    TripLineId = row.TripLineId,
                    CreditorId = row.CreditorId,
                    Creditor = row.Creditor.Name,
                    SupplierId = row.SupplierId,
                    Supplier = row.Supplier.Name,
                    IssueDate = row.IssueDate == DateTime.MinValue ? null : row.IssueDate,
                    PassengerId = row.PassengerId,
                    Passenger = row.Passenger.FullName,
                    TripLineAirPassengerAirlineId = row.AirlineId,
                    TripLineAirPassengerAirline = row.Airline.Name,
                    FormOfPaymentId = row.FormOfPaymentId,
                    FormOfPayment = row.FormOfPayment.PaySupplierDescription,
                    SaleTypeId = row.SaleTypeId <= 0 ? null : row.SaleTypeId,
                    SaleType = row.SaleType.Name,
                    CommissionRate = row.CommissionRate,
                    DiscountRate = row.DiscountRate,
                    DiscountReasonId = row.DiscountReasonId,
                    DiscountReason = row.DiscountReason.Name,
                    OverrideRate = row.OverrideRate,
                    OverrideBasis = row.OverrideBasis,
                    MarkupStrategyId = row.MarkupStrategyId,
                    MarkupStrategy = row.MarkupStrategy.Name,
                    TicketNo = row.TicketNoMain,
                    TicketNoConjunction = row.TicketNoConjunction,
                    OriginalTicketNo = row.OriginalTicketNoMain,
                    OriginalTicketNoConjunction = row.OriginalTicketNoConjunction,
                    BspEntryType = row.BspEntryType,
                    TicketMethod = row.TicketMethod,
                    OfferedReasonId = row.OfferedReasonId,
                    OfferedReason = row.OfferedReason.Name,
                    ClientAccountType = row.TripLineAir.TripLine.Trip.ClientAccountType,
                    IsBspAgent = row.Creditor.IsBspAgent,
                    TripLineAirPassengerIsLocked = row.TripLineAir.TripLine.Trip.IsLocked,
                    AirSegments = row.Routing,
                    TripLineAirPassengerGross = row.Gross,
                    TripLineAirPassengerSupplierNet = row.SupplierNet,
                    TripLineAirPassengerSellingPrice = row.SellingPrice,
                    TripLineAirPassengerCostToClient = row.GetCostToClient(HttpContext.CurrentCustomerId()),
                    TripLineAirPassengerAmountPayable = row.GetAmountPayable(HttpContext.CurrentCustomerId()),
                    TripLineAirPassengerAmountPaid = row.GetAmountPaid(lazyContext),
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser,

                    FullFare = row.FullFare,
                    OfferedFare = row.OfferedFare,
                    TicketedFare = row.TicketedFare,
                    NonCommissionable = row.NonCommissionable,
                    Commission = row.Commission,
                    RemainderCommission = row.RemainderCommission,
                    OverrideAmount = row.OverrideAmount,
                    Discount = row.Discount,
                    Markup = row.Markup,
                    PersonalTravelAmount = row.PersonalTravelAmount
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirPassenger_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirPassenger_CreateOrUpdate(TripLineAirPassengerViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                if (model.SaleTypeId <= 0)
                    throw new UnreportedException("Type of Sale is required.");

                var result = new TripLineAirPassengerCommon(HttpContext).CreateOrUpdate(model);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirPassenger_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirPassenger_Delete([DataSourceRequest] DataSourceRequest request, TripLineAirPassengerViewModel model) {
            try {
                new TripLineAirPassengerCommon(HttpContext).Delete(LazyContext, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirPassenger_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirPassenger_UpdateModel(TripLineAirPassengerViewModel model, string source) {
            try {
                var lazyContext = LazyContext;
                var q = lazyContext.TripLineAirPassenger.Find(model.TripLineAirPassengerId == 0 ? -1 : model.TripLineAirPassengerId);

                int sign = model.BspEntryType == BspEntryType.Refund ? -1 : 1;

                q.BspEntryType = model.BspEntryType;
                q.CreditorId = model.CreditorId ?? -1;
                q.SupplierId = model.SupplierId ?? -1;
                q.FormOfPaymentId = model.FormOfPaymentId ?? -1;
                q.SaleTypeId = model.SaleTypeId ?? -1;
                q.AirlineId = model.TripLineAirPassengerAirlineId ?? -1;
                q.IsCreditCardDiscountApplicable = model.IsCreditCardDiscountApplicable;
                q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;

                q.FullFare = sign * model.FullFare;
                q.OfferedFare = sign * model.OfferedFare;
                q.TicketedFare = sign * model.TicketedFare;
                q.NonCommissionable = sign * model.NonCommissionable;
                q.Commission = sign * model.Commission;
                q.RemainderCommission = sign * model.RemainderCommission;
                q.OverrideAmount = sign * model.OverrideAmount;
                q.Discount = sign * model.Discount;
                q.MarkupStrategyId = model.MarkupStrategyId ?? -1;
                q.Markup = sign * model.Markup;
                q.PersonalTravelAmount = sign * model.PersonalTravelAmount;

                switch (source) {
                    case "AirlineId":
                    case "SaleTypeId":
                        if (model.Commission == 0 && model.CommissionRate == 0)
                            model.CommissionRate = Airline.GetCommissionRate(lazyContext, q.AirlineId, q.SaleTypeId) * 100;

                        break;
                }

                switch (source) {
                    case "FullFare":
                        if (q.TicketedFare == 0) {
                            q.TicketedFare = q.FullFare;
                            model.TicketedFare = q.TicketedFare;
                        }

                        break;
                    case "SaleTypeId":
                        q.IsCreditCardDiscountApplicable = q.SaleType?.IsCreditCardDiscountApplicable ?? false;
                        model.IsCreditCardDiscountApplicable = q.IsCreditCardDiscountApplicable;
                        break;
                    case "CreditorId":
                        q.IncludeMarkupInCreditCardPayment = q.Creditor?.IncludeMarkupInCreditCardPayment ?? false;
                        model.IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment;
                        model.IsBspAgent = q.Creditor?.IsBspAgent ?? false;
                        break;
                    case "SupplierId":
                        if (q.Supplier == null)
                            break;

                        if (q.Supplier.SaleTypeId > 0) {
                            q.SaleTypeId = q.Supplier.SaleTypeId;
                            model.SaleTypeId = q.Supplier.SaleTypeId;
                        }

                        break;
                    case "OverrideAmount":
                        model.OverrideRate = q.OverrideRate * 100;
                        break;
                    case "Commission":
                        model.CommissionRate = q.CommissionRate * 100;
                        break;
                    case "Discount":
                        model.DiscountRate = q.DiscountRate * 100;
                        break;
                    case "Markup":
                        model.MarkupRate = q.MarkupRate * 100;
                        break;
                }

                if (source != "Commission" && source != "Discount" && source != "Markup") {
                    q.Commission = Math.Round(q.TicketedFare * model.CommissionRate / 100, 2);
                    model.Commission = q.Commission;

                    q.Discount = Math.Round(q.TicketedFare * model.DiscountRate / 100, 2);
                    model.Discount = q.Discount;

                    q.Markup = Math.Round(q.TicketedFare * model.MarkupRate / 100, 2);
                    model.Markup = q.Markup;
                }

                if (source != "OverrideAmount") {
                    q.OverrideAmount = Math.Round(q.TicketedFare * model.OverrideRate / 100, 2);
                    model.OverrideAmount = q.OverrideAmount;
                }

                if (q.MarkupStrategy != null)
                    model.RemainderCommission = q.MarkupStrategy.GetRemainderCommission(model.TicketedFare, model.Markup);

                model.FullFare = sign * q.FullFare;
                model.OfferedFare = sign * q.OfferedFare;
                model.TicketedFare = sign * q.TicketedFare;
                model.NonCommissionable = sign * q.NonCommissionable;
                model.Commission = sign * q.Commission;
                model.RemainderCommission = sign * q.RemainderCommission;
                model.OverrideAmount = sign * q.OverrideAmount;
                model.Discount = sign * q.Discount;
                model.Markup = sign * q.Markup;
                model.PersonalTravelAmount = sign * q.PersonalTravelAmount;

                model.TripLineAirPassengerGross = sign * q.Gross;
                model.TripLineAirPassengerSupplierNet = sign * q.SupplierNet;
                model.TripLineAirPassengerSellingPrice = sign * q.SellingPrice;
                model.TripLineAirPassengerCostToClient = sign * q.GetCostToClient(HttpContext.CurrentCustomerId());

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirPassenger_UpdateModel", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirPassengerAirSegment_Edit(int tripLineId, int tripLineAirPassengerId, int tripLineAirSegmentId, bool isAirPassenger) {
            try {
                ViewBag.TripLineAirPassengerAirSegmentTripLineId = tripLineId;
                ViewBag.IsAirPassenger = isAirPassenger;
                ViewBag.ViewOptionId = Context.TripLineAirPassengerAirSegment.Any(t => t.TripLineAirPassengerId == tripLineAirPassengerId || t.TripLineAirSegmentId == tripLineAirSegmentId) ? 0 : 1;
                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineAirPassengerAirSegmentEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirPassengerAirSegment_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripLineAirPassengerAirSegment_Read([DataSourceRequest] DataSourceRequest request, int tripLineId, int tripLineAirPassengerId, int tripLineAirSegmentId, bool assignedRowsOnly) {
            try {
                var result = await TripLineAirPassengerAirSegmentCommon.GetRows(Context, tripLineId, tripLineAirPassengerId, tripLineAirSegmentId, assignedRowsOnly).ToDataSourceResultAsync(request);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirPassengerAirSegment_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirPassengerAirSegment_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, TripLineAirPassengerAirSegmentViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                model = new TripLineAirPassengerAirSegmentCommon(HttpContext).CreateOrUpdate(model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirPassengerAirSegment_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineAirPassengerAirSegment_UpdateSelections(int tripLineId, int tripLineAirPassengerId, int tripLineAirSegmentId, int[] tripLineAirPassengerAirSegmentIds) {
            try {
                new TripLineAirPassengerAirSegmentCommon(HttpContext).UpdateSelections(Context, tripLineId, tripLineAirPassengerId, tripLineAirSegmentId, tripLineAirPassengerAirSegmentIds);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineAirPassengerAirSegment_UpdateSelections", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineLand_Edit(int agencyId, int tripLineTypeId, int tripLineId, int tripId) {
            try {
                var lazyContext = LazyContext;

                TripLineLand q = null;
                TripLineViewModel tripLineViewModel = null;

                var tripLineType = (TripLineType)tripLineTypeId;

                if (tripLineId <= 0) {
                    int serviceTypeRateBasisId = -1;
                    var serviceType = lazyContext.ServiceType.FirstOrDefault(t => t.TripLineType == tripLineType);

                    if (serviceType != null) {
                        var serviceTypeRateBasis = lazyContext.ServiceTypeRateBasis.FirstOrDefault(t => t.ServiceTypeId == serviceType.Id);

                        if (serviceTypeRateBasis != null)
                            serviceTypeRateBasisId = serviceTypeRateBasis.Id;
                    }

                    var trip = lazyContext.Trip.Find(tripId);

                    if (trip == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    q = new TripLineLand {
                        TripLineId = 0,
                        SupplierChainId = -1,
                        SupplierId = -1,
                        Supplier = lazyContext.Supplier.Find(-1),
                        SupplierServiceRateDetailId = -1,
                        SupplierServiceRateDetail = lazyContext.SupplierServiceRateDetail.Find(-1),
                        Crs = Crs.NotSpecified,
                        StartDate = DateTime.Today,
                        EndDate = DateTime.Today,
                        Duration = 1,
                        PayForDuration = 1,
                        DurationCoverageType = tripLineType == TripLineType.Transport || tripLineType == TripLineType.Tour ? DurationCoverageType.Days : DurationCoverageType.Nights,
                        ServiceTypeRateBasisId = serviceTypeRateBasisId,
                        ServiceTypeRateBasis = lazyContext.ServiceTypeRateBasis.Find(serviceTypeRateBasisId),
                        PassengerClassification = tripLineType == TripLineType.Transport ? PassengerClassification.Individual : PassengerClassification.Group,
                        CurrencyId = AppSettings.Setting(HttpContext.CurrentCustomerId()).CurrencyId,
                        Currency = lazyContext.Currency.Find(-1),
                        FormOfPaymentId = -1,
                        FormOfPayment = lazyContext.FormOfPayment.Find(-1),
                        PaymentDueDate = DateTime.MinValue,
                        SaleTypeId = -1,
                        SaleType = lazyContext.SaleType.Find(-1),
                        PaxAdultNo = tripLineType == TripLineType.Transport ? trip.PaxAdult : trip.PaxAdult + trip.PaxChild + trip.PaxInfant,
                        PaxChildNo = tripLineType == TripLineType.Transport ? trip.PaxChild : 0,
                        PaxInfantNo = tripLineType == TripLineType.Transport ? trip.PaxInfant : 0,
                        PaxAdultQty = tripLineType == TripLineType.Transport || tripLineType == TripLineType.Tour ? 1 : 0
                    };

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = 0,
                        TripId = tripId,
                        ClientAccountType = trip.ClientAccountType,
                        TripLineType = tripLineType,
                        TripLineStatus = TripLineStatus.Entry,
                        PrintOnQuote = true,
                        PrintOnConfirmation = true,
                        PrintOnItinerary = true,
                        PrintOnStatement = true,
                        IsLocked = trip.IsLocked
                    };
                }
                else {
                    q = lazyContext.TripLineLand.Find(tripLineId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = q.TripLine.Id,
                        TripId = q.TripLine.TripId,
                        ClientAccountType = q.TripLine.Trip.ClientAccountType,
                        TripLineType = q.TripLine.TripLineType,
                        TripLineStatus = q.TripLine.TripLineStatus,
                        PersonalTravelAmount = q.TripLine.PersonalTravelAmount,
                        AmountPaid = q.TripLine.AmountPaid,
                        PrintOnQuote = q.TripLine.PrintOnQuote,
                        PrintOnConfirmation = q.TripLine.PrintOnConfirmation,
                        PrintOnItinerary = q.TripLine.PrintOnItinerary,
                        PrintOnStatement = q.TripLine.PrintOnStatement,
                        LastWriteTime = q.TripLine.LastWriteTime.ToLocalTime(),
                        CreationTime = q.TripLine.CreationTime.ToLocalTime(),
                        LastWriteUser = q.TripLine.LastWriteUser,
                        CreationUser = q.TripLine.CreationUser
                    };
                }

                var model = new TripLineLandViewModel {
                    TripLineId = q.TripLineId,
                    TripStatus = q.TripStatus,
                    CreditorId = q.TripLineId <= 0 ? null : q.CreditorId,
                    SupplierId = q.TripLineId <= 0 ? null : q.SupplierId,
                    SupplierChainId = q.SupplierChainId,
                    SupplierCrsCode = q.SupplierCrsCode,
                    TripLineLandCrs = q.Crs,
                    TripLineLandCrsPnrRef = q.CrsPnrRef,
                    BookingPnr = q.BookingPnr,
                    ConfirmationNo = q.ConfirmationNo,
                    DocumentNo = q.DocumentNo,
                    Duration = q.Duration,
                    DurationCoverageType = q.DurationCoverageType,
                    SupplierName = q.SupplierName,
                    SupplierAddress = q.GetSupplierAddress(lazyContext, true),
                    SupplierCityCode = q.SupplierCityCode,
                    SupplierAddress1 = q.SupplierAddress1,
                    SupplierAddress2 = q.SupplierAddress2,
                    SupplierLocality = q.SupplierLocality,
                    SupplierRegion = q.SupplierRegion,
                    SupplierPostCode = q.SupplierPostCode,
                    SupplierCountryCode = q.SupplierCountryCode,
                    SupplierContactFullName = q.SupplierContactFullName,
                    SupplierContactPhoneNo = q.SupplierContactPhoneNo,
                    SupplierContactTitle = q.SupplierContactTitle,
                    SupplierContactName = q.SupplierContactName,
                    SupplierContactPhoneHome = q.SupplierContactPhoneHome,
                    SupplierContactPhoneWork = q.SupplierContactPhoneWork,
                    SupplierContactMobile = q.SupplierContactMobile,
                    SupplierContactFax = q.SupplierContactFax,
                    SupplierContactEmail = q.SupplierContactEmail,
                    StartDate = q.StartDate == DateTime.MinValue ? null : q.StartDate,
                    StartTime = q.StartTime,
                    StartDetails = q.StartDetails,
                    StartAddress1 = q.StartAddress1,
                    StartAddress2 = q.StartAddress2,
                    StartLocality = q.StartLocality,
                    StartRegion = q.StartRegion,
                    StartPostCode = q.StartPostCode,
                    StartCountryCode = q.StartCountryCode,
                    EndDate = q.EndDate == DateTime.MinValue ? null : q.EndDate,
                    EndTime = q.EndTime,
                    EndDetails = q.EndDetails,
                    EndAddress1 = q.EndAddress1,
                    EndAddress2 = q.EndAddress2,
                    EndLocality = q.EndLocality,
                    EndRegion = q.EndRegion,
                    EndPostCode = q.EndPostCode,
                    EndCountryCode = q.EndCountryCode,
                    PassengerClassification = q.PassengerClassification,
                    PayForDuration = q.PayForDuration,
                    RateCost = q.RateCost,
                    PaxAdultNo = q.PaxAdultNo,
                    PaxAdultRate = q.PaxAdultRate,
                    PaxAdultQty = q.PaxAdultQty,
                    PaxChildNo = q.PaxChildNo,
                    PaxChildRate = q.PaxChildRate,
                    PaxChildQty = q.PaxChildQty,
                    PaxInfantNo = q.PaxInfantNo,
                    PaxInfantRate = q.PaxInfantRate,
                    PaxInfantQty = q.PaxInfantQty,
                    ServiceTypeRateBasisId = q.ServiceTypeRateBasisId,
                    ServiceDescription = q.ServiceDescription,
                    SupplierServiceId = q.SupplierServiceId,
                    SupplierServiceDescription = q.SupplierServiceDescription,
                    SupplierServiceRateDetailId = q.SupplierServiceRateDetailId,
                    SupplierServiceRateDetailDescription = q.SupplierServiceRateDetailDescription,
                    CurrencyId = q.CurrencyId,
                    ForeignAmount = q.ForeignAmount,
                    ExchangeRate = q.ExchangeRate,
                    FormOfPaymentId = q.FormOfPaymentId,
                    PaymentDueDate = q.PaymentDueDate == DateTime.MinValue ? null : q.PaymentDueDate,
                    SaleTypeId = q.SaleTypeId <= 0 ? (int?)null : q.SaleTypeId,
                    Commission = q.Commission,
                    CommissionRate = q.CommissionRate,
                    RemainderCommission = q.RemainderCommission,
                    Discount = q.Discount,
                    DiscountRate = q.DiscountRate,
                    Markup = q.Markup,
                    MarkupRate = q.MarkupRate,
                    NonCommissionable = q.NonCommissionable,
                    DiscountReasonId = q.DiscountReasonId,
                    MarkupStrategyId = q.MarkupStrategyId,
                    IsCreditCardDiscountApplicable = q.IsCreditCardDiscountApplicable,
                    IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment,
                    AllowPassengerInvoicing = q.AllowPassengerInvoicing,
                    OfferedFare = q.OfferedFare,
                    OfferedReasonId = q.OfferedReasonId,
                    Inclusions = q.Inclusions,
                    Comments = q.Comments,
                    Gross = q.Gross,
                    SupplierNet = q.SupplierNet,
                    SellingPrice = q.SellingPrice,
                    CostToClient = q.GetCostToClient(HttpContext.CurrentCustomerId()),
                    CommissionableValue = q.CommissionableValue,
                    IsPaxNoApplicable = q.ServiceTypeRateBasis.IsPaxNoApplicable,
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser,
                    TripLineViewModel = tripLineViewModel
                };

                ViewBag.AgencyId = agencyId;
                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineLandEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineLand_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineLand_CreateOrUpdate(TripLineLandViewModel model, decimal rateCost) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                model.RateCost = rateCost;
                var result = new TripLineLandCommon(HttpContext).CreateOrUpdate(model);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineLand_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineLand_UpdateModel(TripLineLandViewModel model, decimal rateCost, string source) {
            try {
                var lazyContext = LazyContext;
                var q = lazyContext.TripLineLand.Find(model.TripLineId == 0 ? -1 : model.TripLineId);

                q.CreditorId = model.CreditorId ?? -1;
                q.SupplierId = model.SupplierId ?? -1;
                q.SupplierChainId = model.SupplierChainId ?? -1;
                q.StartDate = model.StartDate ?? DateTime.MinValue;
                q.EndDate = model.EndDate ?? DateTime.MinValue;
                q.FormOfPaymentId = model.FormOfPaymentId ?? -1;
                q.SaleTypeId = model.SaleTypeId ?? -1;
                q.PassengerClassification = model.PassengerClassification;
                q.ServiceTypeRateBasisId = model.ServiceTypeRateBasisId ?? -1;
                q.RateCost = rateCost;
                q.PaxAdultNo = model.PaxAdultNo;
                q.PaxChildNo = model.PaxChildNo;
                q.PaxInfantNo = model.PaxInfantNo;
                q.PaxAdultRate = model.PaxAdultRate;
                q.PaxChildRate = model.PaxChildRate;
                q.PaxInfantRate = model.PaxInfantRate;
                q.PaxAdultQty = model.PaxAdultQty;
                q.PaxChildQty = model.PaxChildQty;
                q.PaxInfantQty = model.PaxInfantQty;
                q.SupplierServiceRateDetailId = model.SupplierServiceRateDetailId;
                q.Duration = model.Duration;
                q.PayForDuration = model.PayForDuration;
                q.Commission = model.Commission;
                q.NonCommissionable = model.NonCommissionable;
                q.Discount = model.Discount;
                q.Markup = model.Markup;
                q.MarkupStrategyId = model.MarkupStrategyId ?? -1;
                q.CurrencyId = model.CurrencyId ?? -1;
                q.ForeignAmount = model.ForeignAmount;
                q.ExchangeRate = model.ExchangeRate;
                q.IsCreditCardDiscountApplicable = model.IsCreditCardDiscountApplicable;
                q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;
                q.SupplierAddress1 = model.SupplierAddress1;
                q.SupplierAddress2 = model.SupplierAddress2;
                q.SupplierLocality = model.SupplierLocality;
                q.SupplierRegion = model.SupplierRegion;
                q.SupplierPostCode = model.SupplierPostCode;
                q.SupplierCountryCode = model.SupplierCountryCode;
                q.SupplierContactTitle = model.SupplierContactTitle;
                q.SupplierContactName = model.SupplierContactName;
                q.SupplierContactPhoneHome = model.SupplierContactPhoneHome;
                q.SupplierContactPhoneWork = model.SupplierContactPhoneWork;
                q.SupplierContactMobile = model.SupplierContactMobile;
                q.SupplierContactFax = model.SupplierContactFax;
                q.SupplierContactEmail = model.SupplierContactEmail;

                model.RateCost = rateCost;

                switch (source) {
                    case "CurrencyId":
                        model.ExchangeRate = Currency.GetExchangeRate(lazyContext, model.CurrencyId ?? -1);
                        return Json(model);
                    case "RecalculateRates":
                        decimal adultRate = 0;
                        decimal childRate = 0;
                        decimal infantRate = 0;

                        if (q.ServiceTypeRateBasis.IsPaxNoApplicable) {
                            adultRate = model.PaxAdultNo;
                            childRate = model.PaxChildNo;
                            infantRate = model.PaxInfantNo;
                        }
                        else {
                            adultRate = model.PaxAdultQty;
                            childRate = model.PaxChildQty;
                            infantRate = model.PaxInfantQty;
                        }

                        if (model.PaxAdultRate != 0 || model.PaxChildRate != 0 || model.PaxInfantRate != 0) {
                            adultRate *= model.PaxAdultRate;
                            childRate *= model.PaxChildRate;
                            infantRate *= model.PaxInfantRate;
                        }

                        decimal denominator = adultRate + childRate + infantRate;

                        if (denominator != 0) {
                            decimal equivalentAmount = model.Duration == 0 ? model.EquivalentAmount : model.EquivalentAmount / model.Duration;

                            model.PaxAdultRate = equivalentAmount * adultRate / denominator;
                            model.PaxChildRate = equivalentAmount * childRate / denominator;
                            model.PaxInfantRate = equivalentAmount * infantRate / denominator;

                            q.PaxAdultRate = model.PaxAdultRate;
                            q.PaxChildRate = model.PaxChildRate;
                            q.PaxInfantRate = model.PaxInfantRate;
                        }

                        break;
                    case "SaleTypeId":
                        q.IsCreditCardDiscountApplicable = q.SaleType?.IsCreditCardDiscountApplicable ?? false;
                        model.IsCreditCardDiscountApplicable = q.IsCreditCardDiscountApplicable;
                        break;
                    case "CreditorId":
                        q.IncludeMarkupInCreditCardPayment = q.Creditor?.IncludeMarkupInCreditCardPayment ?? false;
                        model.IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment;
                        break;
                    case "SupplierId":
                    case "SupplierServiceRate":
                        if (q.Supplier == null)
                            break;

                        if (q.Supplier.SaleTypeId > 0) {
                            q.SaleTypeId = q.Supplier.SaleTypeId;
                            model.SaleTypeId = q.Supplier.SaleTypeId;
                        }

                        if (q.SupplierId > 0)
                            model.SupplierName = q.Supplier.Name;

                        model.SupplierChainId = q.Supplier.SupplierChainId;

                        var address = lazyContext.SupplierAddress.Where(t => t.SupplierId == q.SupplierId).OrderByDescending(t => t.IsDefault).FirstOrDefault() ?? new SupplierAddress();
                        var contact = lazyContext.SupplierContact.Where(t => t.SupplierId == q.SupplierId).OrderByDescending(t => t.IsDefault).FirstOrDefault() ?? new SupplierContact();

                        q.SupplierAddress1 = address.Address1;
                        q.SupplierAddress2 = address.Address2;
                        q.SupplierLocality = address.Locality;
                        q.SupplierRegion = address.Region;
                        q.SupplierPostCode = address.PostCode;
                        q.SupplierCountryCode = address.CountryCode;

                        model.SupplierAddress = q.GetSupplierAddress(lazyContext, true);
                        model.SupplierCityCode = q.Supplier.City.Code;

                        model.SupplierAddress1 = q.SupplierAddress1;
                        model.SupplierAddress2 = q.SupplierAddress2;
                        model.SupplierLocality = q.SupplierLocality;
                        model.SupplierRegion = q.SupplierRegion;
                        model.SupplierPostCode = q.SupplierPostCode;
                        model.SupplierCountryCode = q.SupplierCountryCode;

                        q.SupplierContactTitle = contact.Title;
                        q.SupplierContactName = contact.Name;
                        q.SupplierContactPhoneHome = contact.PhoneHome;
                        q.SupplierContactPhoneWork = contact.PhoneWork;
                        q.SupplierContactMobile = contact.Mobile;
                        q.SupplierContactFax = contact.Fax;
                        q.SupplierContactEmail = contact.Email;

                        model.SupplierContactFullName = q.SupplierContactFullName;
                        model.SupplierContactPhoneNo = q.SupplierContactPhoneNo;

                        model.SupplierContactTitle = q.SupplierContactTitle;
                        model.SupplierContactName = q.SupplierContactName;
                        model.SupplierContactPhoneHome = q.SupplierContactPhoneHome;
                        model.SupplierContactPhoneWork = q.SupplierContactPhoneWork;
                        model.SupplierContactMobile = q.SupplierContactMobile;
                        model.SupplierContactFax = q.SupplierContactFax;
                        model.SupplierContactEmail = q.SupplierContactEmail;
                        break;
                }

                switch (source) {
                    case "CreditorId":
                    case "SupplierId":
                    case "SaleTypeId":
                        model.CommissionRate = q.GetCommissionRate() * 100;
                        q.Commission = Math.Round(q.CommissionableValue * model.CommissionRate / 100, 2);
                        model.Commission = q.Commission;
                        break;
                    case "RecalculateRates":
                    case "SupplierServiceRate":
                        if (source == "SupplierServiceRate" && !q.ServiceTypeRateBasis.IsPaxNoApplicable && model.PaxAdultQty == 0) {
                            model.PaxAdultQty = 1;
                            q.PaxAdultQty = 1;
                        }

                        model.CommissionRate = q.SupplierServiceRateDetail.GetCommissionRate(q) * 100;
                        q.Commission = q.SupplierServiceRateDetail.GetCommission(q);
                        model.Commission = q.Commission;
                        break;
                    case "StartDate":
                    case "EndDate":
                        if (model.StartDate == null && model.EndDate == null)
                            break;

                        model.Duration = q.GetDuration();
                        model.PayForDuration = model.Duration;

                        q.StartDate = model.StartDate ?? DateTime.MinValue;
                        q.EndDate = model.EndDate ?? DateTime.MinValue;
                        q.Duration = model.Duration;
                        q.PayForDuration = model.PayForDuration;
                        break;
                    case "Duration":
                    case "DurationCoverageType":
                        if ((model.StartDate ?? DateTime.MinValue) > DateTime.MinValue) {
                            model.EndDate = ((DateTime)model.StartDate).AddDays(model.Duration + (model.DurationCoverageType == DurationCoverageType.Days ? -1 : (model.TripLineViewModel.TripLineType == TripLineType.Transport ? -1 : 0)));
                            model.PayForDuration = model.Duration;
                        }
                        else if ((model.EndDate ?? DateTime.MinValue) > DateTime.MinValue) {
                            model.StartDate = ((DateTime)model.EndDate).AddDays(-model.Duration - (model.DurationCoverageType == DurationCoverageType.Days ? 1 : 0));
                            model.PayForDuration = model.Duration;
                        }

                        if (model.TripLineViewModel.TripLineType == TripLineType.Transport && (model.EndDate ?? DateTime.MinValue) > DateTime.MinValue)
                            model.EndDate = (model.EndDate ?? DateTime.MinValue).AddDays(1);

                        q.StartDate = model.StartDate ?? DateTime.MinValue;
                        q.EndDate = model.EndDate ?? DateTime.MinValue;
                        q.Duration = model.Duration;
                        q.PayForDuration = model.PayForDuration;
                        break;
                    case "Commission":
                        model.CommissionRate = q.CommissionRate * 100;
                        break;
                    case "Discount":
                        model.DiscountRate = q.DiscountRate * 100;
                        break;
                    case "Markup":
                        model.MarkupRate = q.MarkupRate * 100;
                        break;
                }

                if (source != "Commission" && source != "Discount" && source != "Markup" && source != "RecalculateRates" && source != "SupplierServiceRate") {
                    q.Commission = Math.Round((q.Gross - q.NonCommissionable) * model.CommissionRate / 100, 2);
                    model.Commission = q.Commission;

                    q.Discount = Math.Round((q.Gross - q.NonCommissionable) * model.DiscountRate / 100, 2);
                    model.Discount = q.Discount;

                    q.Markup = Math.Round((q.Gross - q.NonCommissionable) * model.MarkupRate / 100, 2);
                    model.Markup = q.Markup;
                }

                model.IsPaxNoApplicable = q.ServiceTypeRateBasis.IsPaxNoApplicable;

                if (q.MarkupStrategy != null)
                    model.RemainderCommission = q.MarkupStrategy.GetRemainderCommission(q.SellingPrice, q.Markup);

                TripLineLandCommon.SetPricing(lazyContext, model, q);

                model.Gross = q.Gross;
                model.SupplierNet = q.SupplierNet;
                model.SellingPrice = q.SellingPrice;
                model.CostToClient = q.GetCostToClient(HttpContext.CurrentCustomerId());
                model.CommissionableValue = q.CommissionableValue;

                model.SupplierAddress = q.GetSupplierAddress(lazyContext, true);
                model.SupplierContactFullName = q.SupplierContactFullName;
                model.SupplierContactPhoneNo = q.SupplierContactPhoneNo;

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineLand_UpdateModel", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineInsurance_Edit(int agencyId, int tripLineId, int tripId) {
            try {
                var lazyContext = LazyContext;

                TripLineInsurance q = null;
                TripLineViewModel tripLineViewModel = null;

                if (tripLineId <= 0) {
                    var trip = lazyContext.Trip.Find(tripId);

                    if (trip == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    q = new TripLineInsurance {
                        TripLineId = 0,
                        StartDate = trip.DepartureDate,
                        EndDate = trip.ReturnDate == DateTime.MinValue ? trip.DepartureDate : trip.ReturnDate,
                        InsurancePolicyCoverage = InsurancePolicyCoverage.Individual,
                        FormOfPaymentId = -1,
                        SaleTypeId = -1
                    };

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = 0,
                        TripId = tripId,
                        ClientAccountType = trip.ClientAccountType,
                        TripLineType = TripLineType.Insurance,
                        TripLineStatus = TripLineStatus.Entry,
                        PrintOnQuote = true,
                        PrintOnConfirmation = true,
                        PrintOnItinerary = false,
                        PrintOnStatement = true,
                        IsLocked = trip.IsLocked
                    };
                }
                else {
                    q = lazyContext.TripLineInsurance.Find(tripLineId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = q.TripLine.Id,
                        TripId = q.TripLine.TripId,
                        ClientAccountType = q.TripLine.Trip.ClientAccountType,
                        TripLineType = q.TripLine.TripLineType,
                        TripLineStatus = q.TripLine.TripLineStatus,
                        PersonalTravelAmount = q.TripLine.PersonalTravelAmount,
                        AmountPaid = q.TripLine.AmountPaid,
                        PrintOnQuote = q.TripLine.PrintOnQuote,
                        PrintOnConfirmation = q.TripLine.PrintOnConfirmation,
                        PrintOnItinerary = q.TripLine.PrintOnItinerary,
                        PrintOnStatement = q.TripLine.PrintOnStatement,
                        LastWriteTime = q.TripLine.LastWriteTime.ToLocalTime(),
                        CreationTime = q.TripLine.CreationTime.ToLocalTime(),
                        LastWriteUser = q.TripLine.LastWriteUser,
                        CreationUser = q.TripLine.CreationUser
                    };
                }

                var model = new TripLineInsuranceViewModel {
                    TripLineId = q.TripLineId,
                    TripType = q.TripType,
                    PolicyNo = q.PolicyNo,
                    StartDate = q.StartDate,
                    EndDate = q.EndDate,
                    DurationWeeks = q.DurationWeeks,
                    DurationDays = q.DurationDays,
                    CreditorId = q.TripLineId <= 0 ? (int?)null : q.CreditorId,
                    SupplierId = q.TripLineId <= 0 ? (int?)null : q.SupplierId,
                    InsurancePolicyId = q.InsurancePolicyId == -1 ? (int?)null : q.InsurancePolicyId,
                    InsurancePolicyPlanId = q.InsurancePolicyPlanId == -1 ? (int?)null : q.InsurancePolicyPlanId,
                    InsurancePolicyCoverage = q.InsurancePolicyCoverage,
                    FormOfPaymentId = q.FormOfPaymentId,
                    SaleTypeId = q.SaleTypeId <= 0 ? (int?)null : q.SaleTypeId,
                    PolicyValue = q.PolicyValue,
                    AmountAlreadyPaid = q.AmountAlreadyPaid,
                    Commission = q.Commission,
                    CommissionRate = q.CommissionRate,
                    Discount = q.Discount,
                    DiscountRate = q.DiscountRate,
                    DiscountReasonId = q.DiscountReasonId,
                    Markup = q.Markup,
                    MarkupRate = q.MarkupRate,
                    MarkupStrategyId = q.MarkupStrategyId,
                    IsCreditCardDiscountApplicable = q.IsCreditCardDiscountApplicable,
                    IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment,
                    AllowPassengerInvoicing = q.AllowPassengerInvoicing,
                    Gross = q.Gross,
                    SupplierNet = q.SupplierNet,
                    SellingPrice = q.SellingPrice,
                    CostToClient = q.GetCostToClient(HttpContext.CurrentCustomerId()),
                    TotalSurcharge = q.TotalSurcharge,
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser,
                    TripLineViewModel = tripLineViewModel
                };

                ViewBag.AgencyId = agencyId;
                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineInsuranceEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsurance_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineInsurance_CreateOrUpdate(TripLineInsuranceViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var result = new TripLineInsuranceCommon(HttpContext).CreateOrUpdate(model);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsurance_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineInsurance_UpdateModel(TripLineInsuranceViewModel model, string source) {
            try {
                var q = LazyContext.TripLineInsurance.Find(model.TripLineId == 0 ? -1 : model.TripLineId);

                q.StartDate = model.StartDate;
                q.EndDate = model.EndDate;
                q.CreditorId = model.CreditorId ?? -1;
                q.SupplierId = model.SupplierId ?? -1;
                q.FormOfPaymentId = model.FormOfPaymentId ?? -1;
                q.SaleTypeId = model.SaleTypeId ?? -1;
                q.PolicyValue = model.PolicyValue;
                q.AmountAlreadyPaid = model.AmountAlreadyPaid;
                q.Commission = model.Commission;
                q.Discount = model.Discount;
                q.Markup = model.Markup;
                q.IsCreditCardDiscountApplicable = model.IsCreditCardDiscountApplicable;
                q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;

                switch (source) {
                    case "SaleTypeId":
                        q.IsCreditCardDiscountApplicable = q.SaleType?.IsCreditCardDiscountApplicable ?? false;
                        model.IsCreditCardDiscountApplicable = q.IsCreditCardDiscountApplicable;
                        break;
                    case "CreditorId":
                        q.IncludeMarkupInCreditCardPayment = q.Creditor?.IncludeMarkupInCreditCardPayment ?? false;
                        model.IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment;
                        break;
                    case "SupplierId":
                        if (q.Supplier == null)
                            break;

                        if (q.Supplier.SaleTypeId > 0) {
                            q.SaleTypeId = q.Supplier.SaleTypeId;
                            model.SaleTypeId = q.Supplier.SaleTypeId;
                        }

                        break;
                }

                switch (source) {
                    case "CreditorId":
                    case "SupplierId":
                    case "SaleTypeId":
                        model.CommissionRate = q.GetCommissionRate() * 100;
                        q.Commission = Math.Round((q.Gross - q.TotalNonCommissionableSurcharge) * model.CommissionRate / 100, 2);
                        model.Commission = q.Commission;
                        break;
                }

                switch (source) {
                    case "PolicyValue":
                    case "TotalSurcharge":
                        q.Commission -= q.Discount;
                        model.Commission = q.Commission;
                        model.DiscountRate = q.DiscountRate * 100;
                        break;
                    case "AmountAlreadyPaid":
                        q.Commission -= q.Discount;
                        model.Commission = q.Commission;
                        break;
                    case "StartDate":
                    case "EndDate":
                        if (model.StartDate == DateTime.MinValue && model.EndDate == DateTime.MinValue)
                            break;

                        if (model.StartDate > model.EndDate) {
                            model.EndDate = model.StartDate;
                            model.DurationWeeks = 0;
                            model.DurationDays = 1;
                        }
                        else if (model.EndDate < model.StartDate) {
                            model.StartDate = model.EndDate;
                            model.DurationWeeks = 0;
                            model.DurationDays = 1;
                        }
                        else {
                            model.DurationWeeks = q.DurationWeeks;
                            model.DurationDays = q.DurationDays;
                        }

                        break;
                    case "Commission":
                        model.CommissionRate = q.CommissionRate * 100;
                        break;
                    case "Discount":
                        model.DiscountRate = q.DiscountRate * 100;
                        break;
                    case "Markup":
                        model.MarkupRate = q.MarkupRate * 100;
                        break;
                }

                if (source != "Commission" && source != "Discount" && source != "Markup") {
                    q.Commission = Math.Round((q.Gross - q.TotalNonCommissionableSurcharge) * model.CommissionRate / 100, 2);
                    model.Commission = q.Commission;

                    q.Discount = Math.Round((q.Gross - q.TotalNonCommissionableSurcharge) * model.DiscountRate / 100, 2);
                    model.Discount = q.Discount;

                    q.Markup = Math.Round((q.Gross - q.TotalNonCommissionableSurcharge) * model.MarkupRate / 100, 2);
                    model.Markup = q.Markup;
                }

                model.Gross = q.Gross;
                model.SupplierNet = q.SupplierNet;
                model.SellingPrice = q.SellingPrice;
                model.CostToClient = q.GetCostToClient(HttpContext.CurrentCustomerId());

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsurance_UpdateModel", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineInsurancePassenger(int parentId) {
            try {
                ViewBag.ParentId = parentId;
                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineInsurancePassengerEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsurancePassenger", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripLineInsurancePassenger_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.TripLineInsurancePassenger.Include(t => t.Passenger).Where(t => t.TripLineId == parentId).OrderBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName);

                var result = await q.Select(row => new TripLineInsurancePassengerViewModel {
                    TripLineInsurancePassengerId = row.Id,
                    TripLineId = row.TripLineId,
                    PassengerId = row.PassengerId,
                    PassengerFullName = row.Passenger.FullName,
                    PassengerType = row.Passenger.PassengerType,
                    PassengerAge = row.Passenger.GetAge(),
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsurancePassenger_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineInsurancePassenger_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, PassengerViewModel model, int parentId) {
            try {
                new TripLineInsurancePassengerCommon(HttpContext).CreateOrUpdate(model.PassengerId, parentId);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsurancePassenger_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineInsurancePassenger_Delete([DataSourceRequest] DataSourceRequest request, TripLineInsurancePassengerViewModel model) {
            try {
                new TripLineInsurancePassengerCommon(HttpContext).Delete(LazyContext, model.PassengerId, model.TripLineInsurancePassengerId);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsurancePassenger_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripLineInsuranceAvailablePassenger_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var lazyContext = LazyContext;
                int tripId = lazyContext.TripLine.Find(parentId).TripId;

                var q = lazyContext.Passenger.Where(t1 => t1.TripId == tripId && !lazyContext.TripLineInsurancePassenger.Any(t2 => t2.TripLineId == parentId && t2.PassengerId == t1.Id)).AsEnumerable();
                q = Passenger.OrderByExpression(q);

                var result = await q.Select(row => new TripLineInsurancePassengerViewModel {
                    PassengerId = row.Id,
                    PassengerType = row.PassengerType,
                    PassengerFullName = row.FullName,
                    PassengerAge = row.GetAge(),
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsuranceAvailablePassenger_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineInsuranceSurcharge(int parentId) {
            try {
                ViewBag.ParentId = parentId;
                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineInsuranceSurchargeEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsuranceSurcharge", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TripLineInsuranceSurcharge_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.TripLineInsuranceSurcharge.Include(t => t.Passenger).Where(t => t.TripLineId == parentId).OrderBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName);

                var result = await q.Select(row => new TripLineInsuranceSurchargeViewModel {
                    TripLineInsuranceSurchargeId = row.Id,
                    TripLineId = row.TripLineId,
                    PassengerId = row.PassengerId,
                    Passenger = row.Passenger.FullName,
                    Name = row.Name,
                    SurchargeType = row.SurchargeType,
                    SurchargeRateType = row.SurchargeRateType,
                    SurchargeRate = row.SurchargeRate,
                    SurchargeAmount = row.Amount,
                    IsCommissionable = row.IsCommissionable,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsuranceSurcharge_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineInsuranceSurcharge_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, TripLineInsuranceSurchargeViewModel model, int parentId) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                model.TripLineInsuranceSurchargeId = new TripLineInsuranceSurchargeCommon(HttpContext).CreateOrUpdate(model, parentId);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsuranceSurcharge_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineInsuranceSurcharge_Delete([DataSourceRequest] DataSourceRequest request, TripLineInsuranceSurchargeViewModel model) {
            try {
                new TripLineInsuranceSurchargeCommon(HttpContext).Delete(LazyContext, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineInsuranceSurcharge_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineForeignCurrency_Edit(int agencyId, int tripLineId, int tripId) {
            try {
                var lazyContext = LazyContext;

                TripLineForeignCurrency q = null;
                TripLineViewModel tripLineViewModel = null;

                if (tripLineId <= 0) {
                    q = new TripLineForeignCurrency {
                        TripLineId = 0,
                        CurrencyId = -1,
                        Currency = new Currency(),
                        FormOfPaymentId = -1,
                        SaleTypeId = -1
                    };

                    var trip = lazyContext.Trip.Find(tripId);

                    if (trip == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = 0,
                        TripId = tripId,
                        ClientAccountType = trip.ClientAccountType,
                        TripLineType = TripLineType.ForeignCurrency,
                        TripLineStatus = TripLineStatus.Entry,
                        PrintOnQuote = true,
                        PrintOnConfirmation = true,
                        PrintOnItinerary = false,
                        PrintOnStatement = true,
                        IsLocked = trip.IsLocked
                    };
                }
                else {
                    q = lazyContext.TripLineForeignCurrency.Find(tripLineId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = q.TripLine.Id,
                        TripId = q.TripLine.TripId,
                        ClientAccountType = q.TripLine.Trip.ClientAccountType,
                        TripLineType = q.TripLine.TripLineType,
                        TripLineStatus = q.TripLine.TripLineStatus,
                        PersonalTravelAmount = q.TripLine.PersonalTravelAmount,
                        AmountPaid = q.TripLine.AmountPaid,
                        PrintOnQuote = q.TripLine.PrintOnQuote,
                        PrintOnConfirmation = q.TripLine.PrintOnConfirmation,
                        PrintOnItinerary = q.TripLine.PrintOnItinerary,
                        PrintOnStatement = q.TripLine.PrintOnStatement,
                        LastWriteTime = q.TripLine.LastWriteTime.ToLocalTime(),
                        CreationTime = q.TripLine.CreationTime.ToLocalTime(),
                        LastWriteUser = q.TripLine.LastWriteUser,
                        CreationUser = q.TripLine.CreationUser
                    };
                }

                var model = new TripLineForeignCurrencyViewModel {
                    TripLineId = q.TripLineId,
                    CreditorId = q.TripLineId <= 0 ? (int?)null : q.CreditorId,
                    SupplierId = q.TripLineId <= 0 ? (int?)null : q.SupplierId,
                    CurrencyId = q.CurrencyId,
                    DocumentNo = q.DocumentNo,
                    Description = q.Description,
                    FormOfPaymentId = q.FormOfPaymentId,
                    SaleTypeId = q.SaleTypeId <= 0 ? (int?)null : q.SaleTypeId,
                    ForeignAmount = q.ForeignAmount,
                    ExchangeRate = q.ExchangeRate,
                    OfficialRate = q.Currency.OfficialRate,
                    EquivalentValue = q.EquivalentValue,
                    BankFee = q.BankFee,
                    BankFeeRate = q.BankFeeRate,
                    ClientFee = q.ClientFee,
                    ClientFeeRate = q.ClientFeeRate,
                    Commission = q.Commission,
                    CommissionRate = q.CommissionRate,
                    OfferedFare = q.OfferedFare,
                    OfferedReasonId = q.OfferedReasonId,
                    Markup = q.Markup,
                    MarkupRate = q.MarkupRate,
                    MarkupStrategyId = q.MarkupStrategyId,
                    IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment,
                    AllowPassengerInvoicing = q.AllowPassengerInvoicing,
                    Gross = q.Gross,
                    SupplierNet = q.SupplierNet,
                    SellingPrice = q.SellingPrice,
                    CostToClient = q.CostToClient,
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser,
                    TripLineViewModel = tripLineViewModel
                };

                ViewBag.AgencyId = agencyId;
                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineForeignCurrencyEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineForeignCurrency_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineForeignCurrency_CreateOrUpdate(TripLineForeignCurrencyViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var result = new TripLineForeignCurrencyCommon(HttpContext).CreateOrUpdate(model);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineForeignCurrency_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineForeignCurrency_UpdateModel(TripLineForeignCurrencyViewModel model, decimal rate, string rateUpdateOption, string source) {
            try {
                var lazyContext = LazyContext;
                var q = lazyContext.TripLineForeignCurrency.Find(model.TripLineId == 0 ? -1 : model.TripLineId);

                q.CreditorId = model.CreditorId ?? -1;
                q.SupplierId = model.SupplierId ?? -1;
                q.CurrencyId = model.CurrencyId ?? -1;
                q.FormOfPaymentId = model.FormOfPaymentId ?? -1;
                q.SaleTypeId = model.SaleTypeId ?? -1;
                q.ForeignAmount = model.ForeignAmount;
                q.ExchangeRate = model.ExchangeRate;
                q.BankFee = model.BankFee;
                q.ClientFee = model.ClientFee;
                q.Markup = model.Markup;
                q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;

                switch (source) {
                    case "UpdateOption":
                        switch (rateUpdateOption) {
                            case "EquivalentValue":
                                model.ExchangeRate = rate;
                                model.EquivalentValue = model.ExchangeRate == 0 ? 0 : Math.Round(q.ForeignAmount / model.ExchangeRate, 2);
                                break;
                            case "ExchangeRate":
                                model.ExchangeRate = model.EquivalentValue == 0 ? 0 : model.ForeignAmount / model.EquivalentValue;
                                break;
                            case "ForeignAmount":
                                model.ExchangeRate = rate;
                                model.ForeignAmount = Math.Round(model.EquivalentValue * model.ExchangeRate, 2);
                                break;
                        }

                        break;
                    case "EquivalentValue":
                        if (rateUpdateOption == "ExchangeRate") {
                            model.ExchangeRate = model.EquivalentValue == 0 ? 0 : model.ForeignAmount / model.EquivalentValue;
                        }
                        else if (rateUpdateOption == "ForeignAmount") {
                            model.ForeignAmount = Math.Round(model.EquivalentValue * model.ExchangeRate, 2);
                        }

                        break;
                    case "ExchangeRate":
                        if (rateUpdateOption == "EquivalentValue") {
                            model.EquivalentValue = model.ExchangeRate == 0 ? 0 : Math.Round(model.ForeignAmount / model.ExchangeRate, 2);
                        }
                        else if (rateUpdateOption == "ForeignAmount") {
                            model.ForeignAmount = Math.Round(model.EquivalentValue * model.ExchangeRate, 2);
                        }

                        break;
                    case "ForeignAmount":
                        if (rateUpdateOption == "ExchangeRate") {
                            model.ExchangeRate = model.EquivalentValue == 0 ? 0 : model.ForeignAmount / model.EquivalentValue;
                        }
                        else if (rateUpdateOption == "EquivalentValue") {
                            model.EquivalentValue = model.ExchangeRate == 0 ? 0 : Math.Round(model.ForeignAmount / model.ExchangeRate, 2);
                        }

                        break;
                }

                q.ForeignAmount = model.ForeignAmount;
                q.ExchangeRate = model.ExchangeRate;

                switch (source) {
                    case "CreditorId":
                        q.IncludeMarkupInCreditCardPayment = q.Creditor?.IncludeMarkupInCreditCardPayment ?? false;
                        model.IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment;
                        break;
                    case "SupplierId":
                        if (q.Supplier == null)
                            break;

                        if (q.Supplier.SaleTypeId > 0) {
                            q.SaleTypeId = q.Supplier.SaleTypeId;
                            model.SaleTypeId = q.Supplier.SaleTypeId;
                        }

                        break;
                }

                if (source != "ClientFee") {
                    q.ClientFee = Math.Round(model.EquivalentValue * model.ClientFeeRate / 100, 2);
                    model.ClientFee = q.ClientFee;
                }

                if (source != "BankFee") {
                    q.BankFee = Math.Round(model.EquivalentValue * model.BankFeeRate / 100, 2);
                    model.BankFee = q.BankFee;
                }

                if (source != "Markup") {
                    q.Markup = Math.Round(model.EquivalentValue * model.MarkupRate / 100, 2);
                    model.Markup = q.Markup;
                }

                switch (source) {
                    case "ClientFee":
                        model.ClientFeeRate = q.ClientFeeRate * 100;
                        break;
                    case "BankFee":
                        model.BankFeeRate = q.BankFeeRate * 100;
                        break;
                    case "Markup":
                        model.MarkupRate = q.MarkupRate * 100;
                        break;
                }

                model.Commission = q.Commission;
                model.CommissionRate = q.CommissionRate * 100;

                model.Gross = q.Gross;
                model.SupplierNet = q.SupplierNet;
                model.SellingPrice = q.SellingPrice;
                model.CostToClient = q.CostToClient;

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineForeignCurrency_UpdateModel", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineServiceFee_Edit(int agencyId, int tripLineId, int tripId) {
            try {
                var lazyContext = LazyContext;

                TripLineServiceFee q = null;
                TripLineViewModel tripLineViewModel = null;

                if (tripLineId <= 0) {
                    q = new TripLineServiceFee {
                        TripLineId = 0,
                        PaxNo = 1,
                        ServiceFeePaymentType = ServiceFeePaymentType.Agency,
                        PassengerType = PassengerType.Adult,
                        Crs = Crs.NotSpecified,
                        ServiceFeeTypeId = -1,
                        CreditorId = -1,
                        SupplierId = -1,
                        FormOfPaymentId = -1,
                        SaleTypeId = -1
                    };

                    var trip = lazyContext.Trip.Find(tripId);

                    if (trip == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = 0,
                        TripId = tripId,
                        ClientAccountType = trip.ClientAccountType,
                        TripLineType = TripLineType.ServiceFee,
                        TripLineStatus = TripLineStatus.Entry,
                        PrintOnQuote = true,
                        PrintOnConfirmation = true,
                        PrintOnItinerary = false,
                        PrintOnStatement = true,
                        IsLocked = trip.IsLocked
                    };
                }
                else {
                    q = lazyContext.TripLineServiceFee.Find(tripLineId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = q.TripLine.Id,
                        TripId = q.TripLine.TripId,
                        ClientAccountType = q.TripLine.Trip.ClientAccountType,
                        TripLineType = q.TripLine.TripLineType,
                        TripLineStatus = q.TripLine.TripLineStatus,
                        PersonalTravelAmount = q.TripLine.PersonalTravelAmount,
                        AmountPaid = q.TripLine.AmountPaid,
                        PrintOnQuote = q.TripLine.PrintOnQuote,
                        PrintOnConfirmation = q.TripLine.PrintOnConfirmation,
                        PrintOnItinerary = q.TripLine.PrintOnItinerary,
                        PrintOnStatement = q.TripLine.PrintOnStatement,
                        LastWriteTime = q.TripLine.LastWriteTime.ToLocalTime(),
                        CreationTime = q.TripLine.CreationTime.ToLocalTime(),
                        LastWriteUser = q.TripLine.LastWriteUser,
                        CreationUser = q.TripLine.CreationUser
                    };
                }

                var model = new TripLineServiceFeeViewModel {
                    TripLineId = q.TripLineId,
                    ServiceFeePaymentType = q.ServiceFeePaymentType,
                    ServiceFeeTypeId = q.TripLineId <= 0 ? null : q.ServiceFeeTypeId,
                    TripLineServiceFeeCrs = q.Crs,
                    TripLineServiceFeeCrsPnrRef = q.CrsPnrRef,
                    DocumentNo = q.DocumentNo,
                    Description = q.Description,
                    CreditorId = q.CreditorId <= 0 && q.ServiceFeePaymentType == ServiceFeePaymentType.Supplier ? null : q.CreditorId,
                    SupplierId = q.SupplierId <= 0 && q.ServiceFeePaymentType == ServiceFeePaymentType.Supplier ? null : q.SupplierId,
                    PassengerType = q.PassengerType,
                    PaxNo = q.PaxNo,
                    FormOfPaymentId = q.FormOfPaymentId,
                    SaleTypeId = q.SaleTypeId <= 0 ? null : q.SaleTypeId,
                    ItemCost = q.ItemCost,
                    Commission = q.Commission,
                    CommissionRate = q.TripLineId <= 0 ? 1 : q.CommissionRate,
                    OfferedFare = q.OfferedFare,
                    OfferedReasonId = q.OfferedReasonId,
                    Markup = q.Markup,
                    MarkupRate = q.MarkupRate,
                    MarkupStrategyId = q.MarkupStrategyId,
                    IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment,
                    AllowPassengerInvoicing = q.AllowPassengerInvoicing,
                    Gross = q.Gross,
                    SupplierNet = q.SupplierNet,
                    SellingPrice = q.SellingPrice,
                    CostToClient = q.CostToClient,
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser,
                    TripLineViewModel = tripLineViewModel
                };

                ViewBag.AgencyId = agencyId;
                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineServiceFeeEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineServiceFee_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineServiceFee_CreateOrUpdate(TripLineServiceFeeViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var result = new TripLineServiceFeeCommon(HttpContext).CreateOrUpdate(model);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineServiceFee_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineServiceFee_UpdateModel(TripLineServiceFeeViewModel model, string source) {
            try {
                var q = LazyContext.TripLineServiceFee.Find(model.TripLineId == 0 ? -1 : model.TripLineId);

                q.ServiceFeeTypeId = model.ServiceFeeTypeId ?? -1;
                q.CreditorId = model.CreditorId ?? -1;
                q.SupplierId = model.SupplierId ?? -1;
                q.FormOfPaymentId = model.FormOfPaymentId ?? -1;
                q.SaleTypeId = model.SaleTypeId ?? -1;
                q.PaxNo = model.PaxNo;
                q.ItemCost = model.ItemCost;
                q.Commission = model.Commission;
                q.Markup = model.Markup;
                q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;

                switch (source) {
                    case "ServiceFeeTypeId":
                        if (q.ServiceFeeType.SaleTypeId > 0) {
                            q.SaleTypeId = q.ServiceFeeType.SaleTypeId;
                            model.SaleTypeId = q.SaleTypeId;
                        }

                        q.SupplierId = q.ServiceFeeType.SupplierId;
                        model.SupplierId = q.SupplierId;

                        q.SaleTypeId = q.ServiceFeeType.SaleTypeId;
                        model.SaleTypeId = q.SaleTypeId;

                        q.ItemCost = q.ServiceFeeType.Amount;
                        model.ItemCost = q.ItemCost;

                        model.Description = q.ServiceFeeType.AdjustmentType.Description;
                        break;
                    case "CreditorId":
                        q.IncludeMarkupInCreditCardPayment = q.Creditor?.IncludeMarkupInCreditCardPayment ?? false;
                        model.IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment;
                        break;
                    case "SupplierId":
                        if (q.Supplier == null)
                            break;

                        if (q.TripLineId > 0 && q.Supplier.SaleTypeId > 0) {
                            q.SaleTypeId = q.Supplier.SaleTypeId;
                            model.SaleTypeId = q.Supplier.SaleTypeId <= 0 ? (int?)null : q.Supplier.SaleTypeId;
                        }

                        break;
                }

                switch (source) {
                    case "CreditorId":
                    case "SupplierId":
                    case "SaleTypeId":
                        if (model.ServiceFeePaymentType == ServiceFeePaymentType.Agency)
                            break;

                        model.CommissionRate = q.GetCommissionRate() * 100;
                        q.Commission = Math.Round(q.Gross * model.CommissionRate / 100, 2);
                        model.Commission = q.Commission;
                        break;
                    case "Commission":
                        model.CommissionRate = q.CommissionRate * 100;
                        break;
                    case "Markup":
                        model.MarkupRate = q.MarkupRate * 100;
                        break;
                }

                if (source != "Commission" && source != "Markup") {
                    q.Commission = Math.Round(q.Gross * model.CommissionRate / 100, 2);
                    model.Commission = q.Commission;

                    q.Markup = Math.Round(q.Gross * model.MarkupRate / 100, 2);
                    model.Markup = q.Markup;
                }

                model.Gross = q.Gross;
                model.SupplierNet = q.SupplierNet;
                model.SellingPrice = q.SellingPrice;
                model.CostToClient = q.CostToClient;

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineServiceFee_UpdateModel", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineOtherInclusion_Edit(int agencyId, int tripLineId, int tripId) {
            try {
                var lazyContext = LazyContext;

                TripLineOtherInclusion q = null;
                TripLineViewModel tripLineViewModel = null;

                if (tripLineId <= 0) {
                    q = new TripLineOtherInclusion {
                        TripLineId = 0,
                        StartDate = DateTime.Today,
                        EndDate = DateTime.Today,
                        PassengerType = PassengerType.Adult,
                        PaxNo = 1,
                        FormOfPaymentId = -1,
                        SaleTypeId = -1
                    };

                    var trip = lazyContext.Trip.Find(tripId);

                    if (trip == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = 0,
                        TripId = tripId,
                        ClientAccountType = trip.ClientAccountType,
                        TripLineType = TripLineType.OtherInclusion,
                        TripLineStatus = TripLineStatus.Entry,
                        PrintOnQuote = true,
                        PrintOnConfirmation = true,
                        PrintOnItinerary = true,
                        PrintOnStatement = true,
                        IsLocked = trip.IsLocked
                    };
                }
                else {
                    q = lazyContext.TripLineOtherInclusion.Find(tripLineId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = q.TripLine.Id,
                        TripId = q.TripLine.TripId,
                        ClientAccountType = q.TripLine.Trip.ClientAccountType,
                        TripLineType = q.TripLine.TripLineType,
                        TripLineStatus = q.TripLine.TripLineStatus,
                        PersonalTravelAmount = q.TripLine.PersonalTravelAmount,
                        AmountPaid = q.TripLine.AmountPaid,
                        PrintOnQuote = q.TripLine.PrintOnQuote,
                        PrintOnConfirmation = q.TripLine.PrintOnConfirmation,
                        PrintOnItinerary = q.TripLine.PrintOnItinerary,
                        PrintOnStatement = q.TripLine.PrintOnStatement,
                        LastWriteTime = q.TripLine.LastWriteTime.ToLocalTime(),
                        CreationTime = q.TripLine.CreationTime.ToLocalTime(),
                        LastWriteUser = q.TripLine.LastWriteUser,
                        CreationUser = q.TripLine.CreationUser
                    };
                }

                var model = new TripLineOtherInclusionViewModel {
                    TripLineId = q.TripLineId,
                    TripStatus = q.TripStatus,
                    StartDate = q.StartDate == DateTime.MinValue ? null : q.StartDate,
                    EndDate = q.EndDate == DateTime.MinValue ? null : q.EndDate,
                    Time = q.Time,
                    CreditorId = q.TripLineId <= 0 ? (int?)null : q.CreditorId,
                    SupplierId = q.TripLineId <= 0 ? (int?)null : q.SupplierId,
                    DocumentNo = q.DocumentNo,
                    StandardCommentId = null,
                    Comments = q.Comments,
                    PassengerType = q.PassengerType,
                    PaxNo = q.PaxNo,
                    FormOfPaymentId = q.FormOfPaymentId,
                    SaleTypeId = q.SaleTypeId <= 0 ? (int?)null : q.SaleTypeId,
                    ItemCost = q.ItemCost,
                    OfferedFare = q.OfferedFare,
                    OfferedReasonId = q.OfferedReasonId,
                    Commission = q.Commission,
                    CommissionRate = q.CommissionRate,
                    Discount = q.Discount,
                    DiscountRate = q.DiscountRate,
                    DiscountReasonId = q.DiscountReasonId,
                    Markup = q.Markup,
                    MarkupRate = q.MarkupRate,
                    MarkupStrategyId = q.MarkupStrategyId,
                    IsCreditCardDiscountApplicable = q.IsCreditCardDiscountApplicable,
                    IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment,
                    AllowPassengerInvoicing = q.AllowPassengerInvoicing,
                    Gross = q.Gross,
                    SupplierNet = q.SupplierNet,
                    SellingPrice = q.SellingPrice,
                    CostToClient = q.CostToClient,
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser,
                    TripLineViewModel = tripLineViewModel
                };

                ViewBag.AgencyId = agencyId;
                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineOtherInclusionEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineOtherInclusion_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineOtherInclusion_CreateOrUpdate(TripLineOtherInclusionViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var result = new TripLineOtherInclusionCommon(HttpContext).CreateOrUpdate(model);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineOtherInclusion_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineOtherInclusion_UpdateModel(TripLineOtherInclusionViewModel model, string source) {
            try {
                var lazyContext = LazyContext;
                var q = lazyContext.TripLineOtherInclusion.Find(model.TripLineId == 0 ? -1 : model.TripLineId);

                q.CreditorId = model.CreditorId ?? -1;
                q.SupplierId = model.SupplierId ?? -1;
                q.FormOfPaymentId = model.FormOfPaymentId ?? -1;
                q.SaleTypeId = model.SaleTypeId ?? -1;
                q.PaxNo = model.PaxNo;
                q.ItemCost = model.ItemCost;
                q.Commission = model.Commission;
                q.Discount = model.Discount;
                q.Markup = model.Markup;
                q.IsCreditCardDiscountApplicable = model.IsCreditCardDiscountApplicable;
                q.IncludeMarkupInCreditCardPayment = model.IncludeMarkupInCreditCardPayment;

                switch (source) {
                    case "SaleTypeId":
                        q.IsCreditCardDiscountApplicable = q.SaleType?.IsCreditCardDiscountApplicable ?? false;
                        model.IsCreditCardDiscountApplicable = q.IsCreditCardDiscountApplicable;
                        break;
                    case "CreditorId":
                        q.IncludeMarkupInCreditCardPayment = q.Creditor?.IncludeMarkupInCreditCardPayment ?? false;
                        model.IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment;
                        break;
                    case "SupplierId":
                        if (q.Supplier == null)
                            break;

                        if (q.Supplier.SaleTypeId > 0) {
                            q.SaleTypeId = q.Supplier.SaleTypeId;
                            model.SaleTypeId = q.SaleTypeId;
                        }

                        break;
                }

                switch (source) {
                    case "CreditorId":
                    case "SupplierId":
                    case "SaleTypeId":
                        model.CommissionRate = q.GetCommissionRate() * 100;
                        q.Commission = Math.Round(q.Gross * model.CommissionRate / 100, 2);
                        model.Commission = q.Commission;
                        break;
                    case "StandardCommentId":
                        if (model.StandardCommentId > 0)
                            model.Comments = lazyContext.StandardComment.Find(model.StandardCommentId)?.Comment ?? string.Empty;

                        return Json(model);
                    case "Commission":
                        model.CommissionRate = q.CommissionRate * 100;
                        break;
                    case "Discount":
                        model.DiscountRate = q.DiscountRate * 100;
                        break;
                    case "Markup":
                        model.MarkupRate = q.MarkupRate * 100;
                        break;
                }

                if (source != "Commission" && source != "Discount" && source != "Markup") {
                    q.Commission = Math.Round(q.Gross * model.CommissionRate / 100, 2);
                    model.Commission = q.Commission;

                    q.Discount = Math.Round(q.Gross * model.DiscountRate / 100, 2);
                    model.Discount = q.Discount;

                    q.Markup = Math.Round(q.Gross * model.MarkupRate / 100, 2);
                    model.Markup = q.Markup;
                }

                model.Gross = q.Gross;
                model.SupplierNet = q.SupplierNet;
                model.SellingPrice = q.SellingPrice;
                model.CostToClient = q.CostToClient;

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineOtherInclusion_UpdateModel", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineRemark_Edit(int tripLineId, int tripId) {
            try {
                var lazyContext = LazyContext;

                TripLineRemark q = null;
                TripLineViewModel tripLineViewModel = null;

                if (tripLineId <= 0) {
                    q = new TripLineRemark {
                        TripLineId = tripLineId,
                        StartDate = DateTime.Today,
                        EndDate = DateTime.Today,
                        RelatedTripLineId = -1,
                        RelatedTripLineAirSegmentId = -1
                    };

                    var trip = lazyContext.Trip.Find(tripId);

                    if (trip == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = 0,
                        TripId = tripId,
                        ClientAccountType = trip.ClientAccountType,
                        TripLineType = TripLineType.Remark,
                        TripLineStatus = TripLineStatus.Entry,
                        PrintOnQuote = true,
                        PrintOnConfirmation = true,
                        PrintOnItinerary = true,
                        PrintOnStatement = true,
                        IsLocked = trip.IsLocked
                    };
                }
                else {
                    q = lazyContext.TripLineRemark.Find(tripLineId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    tripLineViewModel = new TripLineViewModel {
                        TripLineId = q.TripLine.Id,
                        TripId = q.TripLine.TripId,
                        ClientAccountType = q.TripLine.Trip.ClientAccountType,
                        TripLineType = q.TripLine.TripLineType,
                        TripLineStatus = q.TripLine.TripLineStatus,
                        PersonalTravelAmount = q.TripLine.PersonalTravelAmount,
                        PrintOnQuote = q.TripLine.PrintOnQuote,
                        PrintOnConfirmation = q.TripLine.PrintOnConfirmation,
                        PrintOnItinerary = q.TripLine.PrintOnItinerary,
                        PrintOnStatement = q.TripLine.PrintOnStatement,
                        LastWriteTime = q.TripLine.LastWriteTime.ToLocalTime(),
                        CreationTime = q.TripLine.CreationTime.ToLocalTime(),
                        LastWriteUser = q.TripLine.LastWriteUser,
                        CreationUser = q.TripLine.CreationUser
                    };
                }

                var model = new TripLineRemarkViewModel {
                    TripLineId = q.TripLineId,
                    TripLineRemarkCrs = q.Crs,
                    TripLineRemarkCrsPnrRef = q.CrsPnrRef,
                    StartDate = q.StartDate == DateTime.MinValue ? null : q.StartDate,
                    EndDate = q.EndDate == DateTime.MinValue ? null : q.EndDate,
                    Time = q.Time,
                    RelatedTripLineSegmentId = q.RelatedTripLineId == -1 && q.RelatedTripLineAirSegmentId == -1 ? "-1" : q.RelatedTripLineAirSegmentId > 0 ? string.Format("2.{0}.{1}", q.RelatedTripLineId, q.RelatedTripLineAirSegmentId) : string.Format("1.{0}.{1}", q.RelatedTripLineId, q.RelatedTripLineId),
                    PassengerId = q.PassengerId,
                    Description = q.Description,
                    StandardCommentType = StandardCommentType.Comment,
                    StandardCommentId = null,
                    Remark = q.Remark,
                    PrintAfterTotals = q.PrintAfterTotals,
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser,
                    TripLineViewModel = tripLineViewModel
                };

                return PartialView("~/Views/ClientLedger/EditorTemplates/TripLineRemarkEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineRemark_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineRemark_CreateOrUpdate(TripLineRemarkViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var result = new TripLineRemarkCommon(HttpContext).CreateOrUpdate(model);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineRemark_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripLineRemark_UpdateModel(TripLineRemarkViewModel model, string source) {
            try {
                var lazyContext = LazyContext;

                switch (source) {
                    case "StandardCommentId":
                        if (model.StandardCommentId <= 0)
                            break;

                        var q = lazyContext.StandardComment.Find(model.StandardCommentId);
                        model.Description = q?.Description ?? string.Empty;
                        model.Remark = string.Format("{0}{1}{1}{2}", model.Remark, AppConstants.HtmlLineBreak, q?.Comment ?? string.Empty).TrimStart(string.Format("{0}{0}", AppConstants.HtmlLineBreak));
                        break;
                    case "Remark":
                        if (!string.IsNullOrEmpty(model.Description) || string.IsNullOrEmpty(model.Remark))
                            break;

                        model.Description = Utils.RemoveHtmlFromString(model.Remark.Left(50));
                        break;
                }

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineRemark_UpdateModel", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Passengers
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Passenger_Edit(int passengerId, int profileId, int tripId) {
            try {
                var lazyContext = LazyContext;

                Passenger q = null;
                Profile profile = null;
                Trip trip = null;

                if (passengerId <= 0) {
                    profile = lazyContext.Profile.Find(profileId);
                    trip = lazyContext.Trip.Find(tripId);
                }

                if (passengerId == -2) {
                    q = new Passenger {
                        Id = 0,
                        ProfileId = profileId,
                        Profile = profile,
                        TripId = tripId,
                        Trip = trip,
                        PassengerType = PassengerType.NotSpecified,
                        Title = trip.Title,
                        FirstName = trip.FirstName,
                        LastName = trip.LastName,
                        Alias = string.Empty,
                        DisplayName = trip.FullName,
                        PhoneNo = trip.PhoneNo,
                        Email = trip.Email,
                        BirthDate = trip.Profile.BirthDate,
                        Gender = ContactTitle.GetContactTitle(lazyContext, trip.Title, false).Gender,
                        PassengerProfileId = profileId <= 0 || trip.ProfileId == profileId ? -1 : trip.ProfileId,
                        ProfilePassengerId = -1
                    };
                }
                else if (passengerId <= 0) {
                    q = new Passenger {
                        Id = 0,
                        ProfileId = profileId,
                        Profile = profile,
                        TripId = tripId,
                        Trip = trip,
                        PassengerType = PassengerType.NotSpecified,
                        Title = string.Empty,
                        FirstName = string.Empty,
                        LastName = string.Empty,
                        Alias = string.Empty,
                        DisplayName = string.Empty,
                        PhoneNo = string.Empty,
                        Email = string.Empty,
                        BirthDate = DateTime.MinValue,
                        Gender = Gender.NotSpecified,
                        PassengerProfileId = profileId <= 0 || trip.ProfileId == profileId ? -1 : trip.ProfileId,
                        ProfilePassengerId = -1
                    };
                }
                else {
                    q = lazyContext.Passenger.Find(passengerId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);
                }

                var model = new PassengerViewModel {
                    PassengerId = q.Id,
                    PassengerType = q.PassengerType,
                    PassengerProfileId = q.ProfileId,
                    PassengerTripId = q.TripId,
                    PassengerTitle = q.Title,
                    PassengerFirstName = q.FirstName,
                    PassengerLastName = q.LastName,
                    PassengerAlias = q.Alias,
                    PassengerDisplayName = q.DisplayName,
                    PassengerPhoneNo = q.PhoneNo,
                    PassengerEmail = q.Email,
                    PassengerBirthDate = q.BirthDate == DateTime.MinValue ? null : q.BirthDate,
                    PassengerAge = q.GetAge(),
                    PassengerGender = q.Gender,
                    PassengerPassengerProfileId = q.PassengerProfileId,
                    PassengerProfilePassengerId = q.ProfilePassengerId,
                    PassengerIsProfileUpdateable = q.ProfileId > 0 && q.Profile.IsUpdateable,
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser
                };

                return PartialView("~/Views/ClientLedger/EditorTemplates/PassengerEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Passenger_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Passenger_Read([DataSourceRequest] DataSourceRequest request, int profileId, int tripId) {
            try {
                var q = LazyContext.Passenger.Include(t => t.Trip).Where(t => t.Id > 0);

                if (profileId > 0) {
                    q = q.Where(t => t.ProfileId == profileId);
                }
                else if (tripId > 0) {
                    q = q.Where(t => t.TripId == tripId);
                }

                var result = await Passenger.OrderByExpression(q).Select(row => new PassengerViewModel {
                    PassengerId = row.Id,
                    PassengerType = row.PassengerType,
                    PassengerTripId = row.TripId,
                    PassengerProfileCode = row.ProfileId <= 0 ? string.Empty : row.Profile.Code,
                    PassengerFullName = row.FullName,
                    PassengerFullNameWithEmail = row.FullNameWithEmail,
                    PassengerAlias = row.Alias,
                    PassengerDisplayName = row.DisplayName,
                    PassengerPhoneNo = row.PhoneNo,
                    PassengerBirthDate = row.BirthDate == DateTime.MinValue ? null : row.BirthDate,
                    PassengerAge = row.GetAge(),
                    PassengerGender = row.Gender,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Passenger_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Passenger_CreateOrUpdate(PassengerViewModel model, bool updateRelatedProfilePassenger) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var result = new PassengerCommon(HttpContext).CreateOrUpdate(model, updateRelatedProfilePassenger);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Passenger_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Passenger_Delete(PassengerViewModel model) {
            try {
                var trip = new PassengerCommon(HttpContext).Delete(LazyContext, model);
                return Json(new { trip.PaxAdult, trip.PaxChild, trip.PaxInfant });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Passenger_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Passenger_Add(int profileId, int tripId, PassengerType passengerType, string title, string firstName, string lastName, string alias, string displayName, string phoneNo, string email, DateTime? birthDate, Gender gender) {
            try {
                var lazyContext = LazyContext;

                var q = new Passenger {
                    Id = 0,
                    ProfileId = profileId,
                    TripId = tripId,
                    Trip = lazyContext.Trip.Find(tripId),
                    PassengerType = passengerType,
                    Title = title.ToStringExt(),
                    FirstName = firstName,
                    LastName = lastName,
                    Alias = alias.ToStringExt(),
                    DisplayName = displayName.ToStringExt(),
                    PhoneNo = phoneNo.ToStringExt(),
                    Email = email.ToStringExt(),
                    BirthDate = birthDate ?? DateTime.MinValue,
                    Gender = gender,
                    CrsKey = string.Empty,
                    PassengerProfileId = -1,
                    ProfilePassengerId = -1
                };

                q.Age = q.GetAge();

                if (lazyContext.Insert(q) && q.TripId > 0)
                    q.Trip.UpdatePassengerCount(lazyContext);

                return Json(new { q.Id, q.Trip.PaxAdult, q.Trip.PaxChild, q.Trip.PaxInfant });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Passenger_Add", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Passenger_CopyToProfile(int profileId, int[] passengerIds) {
            try {
                int count = new PassengerCommon(HttpContext).CopyToProfile(Context, profileId, passengerIds);
                return Json(count);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Passenger_CopyToProfile", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Passenger_Reorder(int tripId, int index, int direction) {
            try {
                new PassengerCommon(HttpContext).Reorder(Context, tripId, index, direction);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Passenger_Reorder", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PassengerSelection_Edit(int profileId, int tripId, bool excludeCurrent, bool displayItinerarySelector, PassengerSelectionType passengerSelectionType = PassengerSelectionType.None, string sourceGridId = null, int? rowCount = null, string updateButtonText = null) {
            try {
                var model = new PassengerSelectionViewModel {
                    ProfileId = profileId,
                    TripId = tripId,
                    ExcludeCurrent = excludeCurrent,
                    DisplayItinerarySelector = displayItinerarySelector,
                    PassengerSelectionType = passengerSelectionType,
                    SourceGridId = sourceGridId.ToStringExt(),
                    RowCount = rowCount == null ? passengerSelectionType == PassengerSelectionType.Embedded ? 5 : 10 : (int)rowCount,
                    UpdateButtonText = updateButtonText.ToStringExt()
                };

                return PartialView("~/Views/ClientLedger/EditorTemplates/PassengerSelectionEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerSelection_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> PassengerSelection_Read([DataSourceRequest] DataSourceRequest request, int currentProfileId, int profileId, int tripId, bool excludeCurrent, PassengerSelectionType passengerSelectionType, string text) {
            try {
                var lazyContext = LazyContext;

                if (profileId <= 0)
                    profileId = 0;

                if (tripId <= 0)
                    tripId = 0;

                var q = lazyContext.Passenger.Include(t => t.Profile).Include(t => t.Trip).ThenInclude(t => t.Profile)
                    .Where(t => t.Id > 0 && (t.TripId <= 0 || !(t.Trip.CategoryId <= 0 || t.Trip.DestinationId <= 0 || t.Trip.ConsultantId <= 0 || t.Trip.SourceId <= 0 || t.Trip.DepartureDate == DateTime.MinValue || t.FirstName.Length == 0 || t.Trip.LastName.Length == 0)));

                if (passengerSelectionType == PassengerSelectionType.Trip) {
                    q = q.Where(t => t.TripId == tripId);
                }
                else if (passengerSelectionType == PassengerSelectionType.ProfileOrTrip) {
                    q = q.Where(t => t.ProfileId == profileId || t.Trip.ProfileId == profileId || t.TripId == tripId);
                }
                else if (passengerSelectionType == PassengerSelectionType.ProfileOrTripNoFilter || passengerSelectionType == PassengerSelectionType.EmbeddedNoFilter) {
                    q = q.Where(t => t.ProfileId == profileId || t.TripId == tripId);
                }

                if (!string.IsNullOrEmpty(text)) {
                    text = text.ToLower();

                    if (DateTime.TryParse(text, out DateTime birthdate)) {
                        q = q.Where(t => t.BirthDate == birthdate);
                    }
                    else {
                        q = q.Where(t => t.Profile.Code.ToLower().Contains(text)
                            || t.Trip.Profile.Code.ToLower().Contains(text)
                            || (t.Title + " " + t.FirstName + " " + t.LastName).Trim().ToLower().Contains(text)
                            || t.Alias.ToLower().Contains(text)
                            || t.DisplayName.ToLower().Contains(text));
                    }
                }

                if (excludeCurrent && passengerSelectionType == PassengerSelectionType.ProfileOrTrip)
                    q = profileId > 0 && tripId <= 0 ? q.Where(t => t.ProfileId != currentProfileId) : q.Where(t => t.TripId != tripId);

                var result = await Passenger.OrderByExpression(q.AsEnumerable()).GroupBy(row => new {
                    row.PassengerType,
                    ProfileCode = row.ProfileId > 0 ? row.Profile.Code : row.Trip.Profile.Code,
                    SeqNo1 = row.SeqNo,
                    SeqNo2 = row.Trip.FirstName.ToLower() == row.FirstName.ToLower() && row.Trip.LastName.ToLower() == row.LastName.ToLower() ? 0 : row.PassengerType == PassengerType.Infant ? 3 : row.PassengerType == PassengerType.Child ? 2 : 1,
                    FullName = string.Concat(row.Title, " ", row.FirstName, " ", row.LastName).Trim(),
                    row.PhoneNo,
                    row.BirthDate,
                    Age = row.GetAge(),
                    row.Gender
                }).OrderBy(t1 => t1.Key.SeqNo1).ThenBy(t1 => t1.Key.SeqNo2).ThenBy(t1 => t1.Max(t2 => t2.Trip.TripNo)).Select(row => new PassengerGridSelectionViewModel {
                    PassengerId = row.Max(t => t.Id),
                    PassengerType = row.Key.PassengerType,
                    PassengerProfileCode = row.Key.ProfileCode.Length == 0 ? string.Empty : row.Key.ProfileCode,
                    PassengerTripId = row.Max(t => t.TripId),
                    PassengerTripNo = row.Max(t => t.Trip.TripNo),
                    PassengerDepartureDate = row.Max(t => t.Trip.DepartureDate) <= lazyContext.VoidDate ? (DateTime?)null : row.Max(t => t.Trip.DepartureDate),
                    PassengerFullName = row.Key.FullName,
                    PassengerPhoneNo = row.Key.PhoneNo,
                    PassengerBirthDate = row.Key.BirthDate == DateTime.MinValue ? null : row.Key.BirthDate,
                    PassengerAge = row.Key.Age,
                    PassengerGender = row.Key.Gender
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerSelection_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PassengerSelection_Create(int[] passengerIds, int profileId, int tripId) {
            try {
                var result = new PassengerCommon(HttpContext).Create(Context, passengerIds, profileId, tripId);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerSelection_Create", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PassengerDocument(int parentId, DateTime birthDate, Gender gender) {
            try {
                ViewBag.ParentId = parentId;
                ViewBag.PassengerBirthDate = birthDate;
                ViewBag.PassengerGender = gender;
                return PartialView("~/Views/ClientLedger/EditorTemplates/PassengerDocumentEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerDocument", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PassengerDocument_Edit(int passengerId, int passengerDocumentId) {
            try {
                PassengerDocument q = null;

                if (passengerDocumentId <= 0) {
                    q = new PassengerDocument {
                        PassengerId = passengerId
                    };
                }
                else {
                    q = LazyContext.PassengerDocument.Find(passengerDocumentId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);
                }

                var model = new PassengerDocumentViewModel {
                    PassengerDocumentId = q.Id,
                    PassengerDocumentPassengerId = q.PassengerId,
                    PassengerDocumentType = q.DocumentType,
                    PassengerDocumentNo = q.DocumentNo,
                    PassengerDocumentIssueDate = q.IssueDate == DateTime.MinValue ? null : q.IssueDate,
                    PassengerDocumentExpiryDate = q.ExpiryDate == DateTime.MinValue ? null : q.ExpiryDate,
                    PassengerDocumentPlaceOfIssue = q.PlaceOfIssue,
                    PassengerDocumentIssuingCountryId = q.IssuingCountryId <= 0 ? null : q.IssuingCountryId,
                    PassengerDocumentIssuingCountry = q.IssuingCountryId <= 0 ? string.Empty : q.IssuingCountry.Name,
                    PassengerDocumentNationalityId = q.NationalityId,
                    PassengerDocumentNationality = q.NationalityId <= 0 ? string.Empty : q.Nationality.Name,
                    PassengerDocumentComments = q.Comments
                };

                return PartialView("~/Views/ClientLedger/EditorTemplates/PassengerDocumentGridEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerDocument_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> PassengerDocument_Read([DataSourceRequest] DataSourceRequest request, int parentId, bool isTripPassport = false) {
            try {
                var q = Context.PassengerDocument.Include(t => t.Passenger).Include(t => t.IssuingCountry).Include(t => t.Nationality).Select(t => t);

                if (isTripPassport) {
                    q = q.Where(t => t.Id > 0 && t.Passenger.TripId > 0 && t.Passenger.TripId == parentId && t.DocumentType == DocumentType.Passport);
                }
                else {
                    q = q.Where(t => t.Id > 0 && t.PassengerId == parentId);
                }

                var result = await q.OrderBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName).Select(row => new PassengerDocumentViewModel {
                    PassengerDocumentId = row.Id,
                    PassengerDocumentPassengerId = row.PassengerId,
                    PassengerDocumentFullName = row.Passenger.FullName,
                    PassengerDocumentType = row.DocumentType,
                    PassengerDocumentNo = row.DocumentNo,
                    PassengerDocumentIssueDate = row.IssueDate == DateTime.MinValue ? null : row.IssueDate,
                    PassengerDocumentExpiryDate = row.ExpiryDate == DateTime.MinValue ? null : row.ExpiryDate,
                    PassengerDocumentPlaceOfIssue = row.PlaceOfIssue,
                    PassengerDocumentIssuingCountryId = row.IssuingCountryId <= 0 ? null : row.IssuingCountryId,
                    PassengerDocumentIssuingCountry = row.IssuingCountryId <= 0 ? string.Empty : row.IssuingCountry.Name,
                    PassengerDocumentNationalityId = row.NationalityId,
                    PassengerDocumentNationality = row.NationalityId <= 0 ? string.Empty : row.Nationality.Name,
                    PassengerDocumentComments = row.Comments,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerDocument_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PassengerDocument_CreateOrUpdate(PassengerDocumentViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var result = new PassengerDocumentCommon(HttpContext).CreateOrUpdate(model);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerDocument_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PassengerDocument_Delete([DataSourceRequest] DataSourceRequest request, PassengerDocumentViewModel model) {
            try {
                var context = Context;
                var q = context.PassengerDocument.Find(model.PassengerDocumentId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerDocument_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PassengerClubMembership(int parentId) {
            try {
                ViewBag.ParentId = parentId;
                return PartialView("~/Views/ClientLedger/EditorTemplates/PassengerClubMembershipEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerClubMembership", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> PassengerClubMembership_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.PassengerClubMembership.Include(t => t.ClubMembership).Include(t => t.Airline).Where(t => t.Id > 0 && t.PassengerId == parentId).OrderBy(t => t.Passenger.LastName).ThenBy(t => t.Passenger.FirstName);

                var result = await q.Select(row => new PassengerClubMembershipViewModel {
                    PassengerClubMembershipId = row.Id,
                    PassengerClubMembershipPassengerId = row.PassengerId,
                    PassengerClubMembershipClubMembershipId = row.ClubMembershipId,
                    PassengerClubMembershipClubMembership = row.ClubMembershipId <= 0 ? string.Empty : row.ClubMembership.Name,
                    PassengerClubMembershipClubMembershipNo = row.ClubMembershipNo,
                    PassengerClubMembershipAirlineId = row.AirlineId,
                    PassengerClubMembershipAirlineName = row.AirlineId <= 0 ? string.Empty : string.Concat(row.Airline.Code, ": ", row.Airline.Name),
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerClubMembership_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PassengerClubMembership_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, PassengerClubMembershipViewModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var result = new PassengerClubMembershipCommon(HttpContext).CreateOrUpdate(model);
                return Json(await new[] { result }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerClubMembership_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PassengerClubMembership_Delete([DataSourceRequest] DataSourceRequest request, PassengerClubMembershipViewModel model) {
            try {
                var context = Context;
                var q = context.PassengerClubMembership.Find(model.PassengerClubMembershipId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerClubMembership_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PassengerClubMembership_UpdateProfileInfo(int passengerClubMembershipId, int passengerId, int clubMembershipId) {
            try {
                var context = Context;

                var passengerClubMembership = context.PassengerClubMembership.Include(t => t.Passenger).ThenInclude(t => t.Trip).Single(t => t.Id == passengerClubMembershipId);
                var q = context.ProfileClubMembership.SingleOrDefault(t => t.ProfileId == passengerClubMembership.Passenger.Trip.ProfileId && t.PassengerId == passengerId && t.ClubMembershipId == clubMembershipId);

                if (q == null) {
                    q = new ProfileClubMembership {
                        Id = 0,
                        ProfileId = passengerClubMembership.Passenger.Trip.ProfileId,
                        PassengerId = passengerId,
                        ClubMembershipId = clubMembershipId,
                        ClubMembershipNo = passengerClubMembership.ClubMembershipNo,
                        ClubMembershipPin = string.Empty,
                        PointsEarned = 0,
                        Comments = string.Empty
                    };

                    context.Insert(q);
                }
                else {
                    q.ClubMembershipNo = passengerClubMembership.ClubMembershipNo;
                    context.Save(q);
                }

                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PassengerClubMembership_UpdateProfileInfo", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region CRS Import
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsImport_Edit(int profileId, int tripId) {
            try {
                var model = new Gds.Models.CrsImportModel {
                    CrsProfileId = profileId,
                    CrsTripId = tripId
                };

                return PartialView("~/Views/ClientLedger/EditorTemplates/CrsImportEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsImport_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> CrsImportAmadeus_Read([DataSourceRequest] DataSourceRequest request, bool currentConsultantOnly) {
            try {
                var lazyContext = LazyContext;
                var q = Amadeus.ListPnrs(lazyContext, HttpContext.CurrentCustomerId(), WebHostEnvironment.ContentRootPath);

                if (currentConsultantOnly) {
                    var consultant = lazyContext.Consultant.Find(HttpContext.CurrentConsultantId());
                    q = q.Where(t => t.PnrCreatorAgent.ToLower() == consultant.AmadeusCode.ToLower() || t.PnrTicketingAgent.ToLower() == consultant.AmadeusCode.ToLower()).ToList();
                }

                var result = await q.ConvertAll(row => new CrsAmadeusViewModel {
                    FileName = row.FileName,
                    CrsPnrRef = row.CrsPnrRef,
                    CrsPnrDate = row.CrsPnrDate,
                    RouteInfo = row.RouteInfo,
                    Passengers = row.Passengers,
                    IsTicketed = row.IsTicketed,
                    IsValid = row.IsValid
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsImportAmadeus_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsImportAmadeus_UploadFiles(IEnumerable<IFormFile> crsAmadeusFileUpload) {
            try {
                string folderPath = WebUtils.GetAmadeusFilePath(HttpContext, WebHostEnvironment.ContentRootPath);
                var di = new DirectoryInfo(folderPath);

                if (!di.Exists)
                    di.Create();

                foreach (var file in crsAmadeusFileUpload.Where(t => t.FileName.StartsWith("air", StringComparison.OrdinalIgnoreCase) && t.FileName.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))) {
                    var fi = new FileInfo(file.FileName);

                    if (fi.Exists)
                        fi.Delete();

                    string filePath = Path.Combine(folderPath, file.FileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create)) {
                        await file.CopyToAsync(fileStream);
                    }
                }

                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsImportAmadeus_UploadFiles", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsImportAmadeus_CreateOrUpdate(Gds.Models.CrsImportModel model, string fileNames) {
            try {
                model.CalypsoCompany = "0";
                model.CalypsoCrsPnrRef = "0";
                model.CalypsoLastName = "0";
                model.GalileoCrsPnrRef = "0";
                model.EtgCrsPnrRef = "0";

                ModelState.Clear();
                TryValidateModel(model);

                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                model.CrsAgencyId = HttpContext.CurrentDefaultAgencyId();

                string filePath = WebUtils.GetAmadeusFilePath(HttpContext, WebHostEnvironment.ContentRootPath);
                int result = await new TripCommon(HttpContext).CrsImportAmadeus(LazyContext, model, filePath, fileNames.Split(','));

                if (result == 0)
                    throw new InvalidOperationException("Amadeus CRS import failed.");

                if (result == -1)
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(AppConstants.ApplicationError)));

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsImportAmadeus_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsImportAmadeus_DeleteSelections(string[] fileNames) {
            try {
                string filePath = WebUtils.GetAmadeusFilePath(HttpContext, WebHostEnvironment.ContentRootPath);
                Amadeus.DeleteFiles(filePath, fileNames);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsImportAmadeus_DeleteSelections", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsImportCalypso_CreateOrUpdate(Gds.Models.CrsImportModel model) {
            try {
                model.GalileoCrsPnrRef = "0";
                model.EtgCrsPnrRef = "0";

                ModelState.Clear();
                TryValidateModel(model);

                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                model.CrsAgencyId = HttpContext.CurrentDefaultAgencyId();

                new TripCommon(HttpContext).CrsImportCalypso(LazyContext, model);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsImportCalypso_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsImportEtg_CreateOrUpdate(Gds.Models.CrsImportModel model) {
            try {
                model.CalypsoCompany = "0";
                model.CalypsoCrsPnrRef = "0";
                model.CalypsoLastName = "0";
                model.GalileoCrsPnrRef = "0";

                ModelState.Clear();
                TryValidateModel(model);

                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                model.CrsAgencyId = HttpContext.CurrentDefaultAgencyId();

                await new TripCommon(HttpContext).CrsImportEtg(LazyContext, model);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsImportEtg_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsImportGalileo_CreateOrUpdate(Gds.Models.CrsImportModel model) {
            try {
                var lazyContext = LazyContext;

                model.CalypsoCompany = "0";
                model.CalypsoCrsPnrRef = "0";
                model.CalypsoLastName = "0";
                model.EtgCrsPnrRef = "0";

                ModelState.Clear();
                TryValidateModel(model);

                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                if (CustomerSettings.Setting(HttpContext.CurrentCustomerId()).CustomerType == CustomerType.Customer && model.GalileoPccId <= 0)
                    throw new UnreportedException("PCC is required.");

                model.CrsAgencyId = HttpContext.CurrentDefaultAgencyId();

                if (model.GalileoPccId <= 0) {
                    model.GalileoPcc = string.Empty;
                }
                else {
                    model.GalileoPcc = lazyContext.AgencyPseudoCityCode.Find(model.GalileoPccId).Name;
                }

                await new TripCommon(HttpContext).CrsImportGalileo(lazyContext, model);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsImportGalileo_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region CRS Export
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsExportAmadeus_CreateOrUpdate(Gds.Models.CrsAmadeusExportModel model) {
            try {
                var lazyContext = LazyContext;
                int consultantId = HttpContext.CurrentConsultantId();

                model.AmadeusConsultant = consultantId <= 0 ? string.Empty : lazyContext.Consultant.Find(consultantId)?.Name ?? string.Empty;
                new TripCommon(HttpContext).CrsExportAmadeus(lazyContext, model);

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsExportAmadeus_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsExportGalileo_CreateOrUpdate(Gds.Models.CrsGalileoExportModel model) {
            try {
                if (!ModelState.IsValid) throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                await new TripCommon(HttpContext).CrsExportGalileo(LazyContext, model);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsExportGalileo_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsExportGalileo_UpdateModel(Gds.Models.CrsGalileoExportModel model, string source) {
            try {
                switch (source) {
                    case "TripId":
                        if (model.GalileoExportTripId > 0) {
                            model.GalileoExportClientDetails = Context.Trip.Find(model.GalileoExportTripId)?.GetClientDetails(Context) ?? string.Empty;
                        }
                        else {
                            model.GalileoExportClientDetails = string.Empty;
                        }

                        break;
                }

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripLineRemark_UpdateModel", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [BasicAuthentication(AppSettings.SystemAccountName, AppSettings.SystemAccountPassword, BasicRealm = "travelog")]
        public async Task<IActionResult> GetCrsRecord(string userName, string password, string tripNo, string profileCode) {
            try {
                return Json(new CrsGalileoExportModel());
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GetCrsRecord", ex);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
        #endregion

        #region Quote Report
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Quote_IssueDocument(int agencyId, int tripId, int[] tripLineIds, int[] passengerIds, int quoteNo) {
            try {
                var context = Context;
                var reportSource = ClientLedgerDataSources.GetQuoteReportSource(HttpContext.CurrentCustomerId(), agencyId, quoteNo, await HttpContext.TravelDocumentTimeFormat(Cache), string.Join(",", tripLineIds), string.Join(",", passengerIds), HttpContext.Now(), HttpContext.UserFullName());
                var result = Utils.ExportToPdf(reportSource);

                var q = new IssuedDocument {
                    Id = 0,
                    IssuedDocumentType = IssuedDocumentType.Quote,
                    TripId = tripId,
                    DebtorId = -1,
                    CreditorId = -1,
                    ReceiptId = -1,
                    InvoiceId = -1,
                    VoucherId = -1,
                    Name = IssuedDocument.GetQuoteName(context, tripId, quoteNo),
                    FileExtension = "pdf",
                    Document = result.DocumentBytes
                };

                context.Insert(q);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Quote_IssueDocument", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Quote_EmailDocument(int tripId, string from, string to, string cc, string bcc, string subject, string body, IEnumerable<IFormFile> attachments) {
            try {
                var q = Context.IssuedDocument.OrderByDescending(t => t.CreationTime).FirstOrDefault(t => t.IssuedDocumentType == IssuedDocumentType.Quote && t.TripId == tripId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                var mailAttachments = new List<MailAttachment> {
                    new MailAttachment(q.Document, q.FileName, q.FileContentType)
                };

                if (attachments != null) {
                    foreach (var attachment in attachments) {
                        mailAttachments.Add(new MailAttachment(attachment.OpenReadStream().StreamToBytes(), attachment.FileName, attachment.ContentType));
                    }
                }

                await Mail.Instance.SendMailAsync(to, cc, bcc, subject, body, mailAttachments.ToArray(), from);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Quote_EmailDocument", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Quote_Report(int agencyId, int tripId, int[] tripLineIds, int[] passengerIds, int quoteNo) {
            try {
                var reportSource = ClientLedgerDataSources.GetQuoteReportSource(HttpContext.CurrentCustomerId(), agencyId, quoteNo, await HttpContext.TravelDocumentTimeFormat(Cache), string.Join(",", tripLineIds), string.Join(",", passengerIds), HttpContext.Now(), HttpContext.UserFullName());
                return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Quote_Report", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Quote_ExportPdf(int agencyId, int tripId, string tripLineIds, string passengerIds, int quoteNo) {
            try {
                string fileName = string.Format("{0}.pdf", IssuedDocument.GetQuoteName(Context, tripId, quoteNo));
                var reportSource = ClientLedgerDataSources.GetQuoteReportSource(HttpContext.CurrentCustomerId(), agencyId, quoteNo, await HttpContext.TravelDocumentTimeFormat(Cache), tripLineIds, passengerIds, HttpContext.Now(), HttpContext.UserFullName());

                var result = Utils.ExportToPdf(reportSource);
                return File(result.DocumentBytes, result.MimeType, fileName);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Quote_ExportPdf", ex);
                return Redirect("/Shared/Error");
            }
        }

        public async Task<IActionResult> Quote_ExportWord(int agencyId, int tripId, string tripLineIds, string passengerIds, int quoteNo) {
            try {
                string fileName = string.Format("{0}.docx", IssuedDocument.GetQuoteName(Context, tripId, quoteNo));
                var reportSource = ClientLedgerDataSources.GetQuoteReportSource(HttpContext.CurrentCustomerId(), agencyId, quoteNo, await HttpContext.TravelDocumentTimeFormat(Cache), tripLineIds, passengerIds, HttpContext.Now(), HttpContext.UserFullName());

                var result = Utils.ExportToWord(reportSource);
                return File(result.DocumentBytes, result.MimeType, fileName);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Quote_ExportWord", ex);
                return Redirect("/Shared/Error");
            }
        }
        #endregion

        #region Confirmation Report
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Confirmation_IssueDocument(int agencyId, int tripId, int[] tripLineIds, int[] passengerIds, int quoteNo) {
            try {
                var context = Context;
                var reportSource = ClientLedgerDataSources.GetConfirmationReportSource(HttpContext.CurrentCustomerId(), agencyId, WebHostEnvironment.ContentRootPath, quoteNo, await HttpContext.TravelDocumentTimeFormat(Cache), string.Join(",", tripLineIds), string.Join(",", passengerIds), HttpContext.Now(), HttpContext.UserFullName());
                var result = Utils.ExportToPdf(reportSource);

                var q = new IssuedDocument {
                    Id = 0,
                    IssuedDocumentType = IssuedDocumentType.Confirmation,
                    TripId = tripId,
                    DebtorId = -1,
                    CreditorId = -1,
                    ReceiptId = -1,
                    InvoiceId = -1,
                    VoucherId = -1,
                    Name = IssuedDocument.GetConfirmationName(context, tripId, quoteNo),
                    FileExtension = "pdf",
                    Document = result.DocumentBytes
                };

                context.Insert(q);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Confirmation_IssueDocument", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Confirmation_EmailDocument(int tripId, string from, string to, string cc, string bcc, string subject, string body, IEnumerable<IFormFile> attachments) {
            try {
                var q = Context.IssuedDocument.OrderByDescending(t => t.CreationTime).FirstOrDefault(t => t.IssuedDocumentType == IssuedDocumentType.Confirmation && t.TripId == tripId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                var mailAttachments = new List<MailAttachment> {
                    new MailAttachment(q.Document, q.FileName, q.FileContentType)
                };

                if (attachments != null) {
                    foreach (var attachment in attachments) {
                        mailAttachments.Add(new MailAttachment(attachment.OpenReadStream().StreamToBytes(), attachment.FileName, attachment.ContentType));
                    }
                }

                await Mail.Instance.SendMailAsync(to, cc, bcc, subject, body, mailAttachments.ToArray(), from);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Confirmation_EmailDocument", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Confirmation_Report(int agencyId, int tripId, int[] tripLineIds, int[] passengerIds, int quoteNo) {
            try {
                var reportSource = ClientLedgerDataSources.GetConfirmationReportSource(HttpContext.CurrentCustomerId(), agencyId, WebHostEnvironment.ContentRootPath, quoteNo, await HttpContext.TravelDocumentTimeFormat(Cache), string.Join(",", tripLineIds), string.Join(",", passengerIds), HttpContext.Now(), HttpContext.UserFullName());
                return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Confirmation_Report", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Confirmation_ExportPdf(int agencyId, int tripId, string tripLineIds, string passengerIds, int quoteNo) {
            try {
                string fileName = string.Format("{0}.pdf", IssuedDocument.GetConfirmationName(Context, tripId, quoteNo));
                var reportSource = ClientLedgerDataSources.GetConfirmationReportSource(HttpContext.CurrentCustomerId(), agencyId, WebHostEnvironment.ContentRootPath, quoteNo, await HttpContext.TravelDocumentTimeFormat(Cache), tripLineIds, passengerIds, HttpContext.Now(), HttpContext.UserFullName());

                var result = Utils.ExportToPdf(reportSource);
                return File(result.DocumentBytes, result.MimeType, fileName);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Confirmation_ExportPdf", ex);
                return Redirect("/Shared/Error");
            }
        }

        public async Task<IActionResult> Confirmation_ExportWord(int agencyId, int tripId, string tripLineIds, string passengerIds, int quoteNo) {
            try {
                string fileName = string.Format("{0}.docx", IssuedDocument.GetConfirmationName(Context, tripId, quoteNo));
                var reportSource = ClientLedgerDataSources.GetConfirmationReportSource(HttpContext.CurrentCustomerId(), agencyId, WebHostEnvironment.ContentRootPath, quoteNo, await HttpContext.TravelDocumentTimeFormat(Cache), tripLineIds, passengerIds, HttpContext.Now(), HttpContext.UserFullName());

                var result = Utils.ExportToWord(reportSource);
                return File(result.DocumentBytes, result.MimeType, fileName);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Confirmation_ExportWord", ex);
                return Redirect("/Shared/Error");
            }
        }
        #endregion

        #region Itinerary Report
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Itinerary_IssueDocument(int agencyId, int tripId, int[] tripLineIds, int[] passengerIds, int quoteNo, int tripItineraryId) {
            try {
                var context = Context;

                var reportSource = ClientLedgerDataSources.GetItineraryReportSource(HttpContext.CurrentCustomerId(), agencyId, WebHostEnvironment.ContentRootPath, quoteNo, tripItineraryId, await HttpContext.TravelDocumentTimeFormat(Cache), tripLineIds, passengerIds, HttpContext.Now(), HttpContext.UserFullName());
                var result = Utils.ExportToPdf(reportSource);

                var q = new IssuedDocument {
                    Id = 0,
                    IssuedDocumentType = IssuedDocumentType.Itinerary,
                    TripId = tripId,
                    DebtorId = -1,
                    CreditorId = -1,
                    ReceiptId = -1,
                    InvoiceId = -1,
                    VoucherId = -1,
                    Name = IssuedDocument.GetItineraryName(context, tripId, quoteNo),
                    FileExtension = "pdf",
                    Document = result.DocumentBytes
                };

                context.Insert(q);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Itinerary_IssueDocument", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Itinerary_EmailDocument(int tripId, string from, string to, string cc, string bcc, string subject, string body, IEnumerable<IFormFile> attachments) {
            try {
                var q = Context.IssuedDocument.OrderByDescending(t => t.CreationTime).FirstOrDefault(t => t.IssuedDocumentType == IssuedDocumentType.Itinerary && t.TripId == tripId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                var mailAttachments = new List<MailAttachment> {
                    new MailAttachment(q.Document, q.FileName, q.FileContentType)
                };

                if (attachments != null) {
                    foreach (var attachment in attachments) {
                        mailAttachments.Add(new MailAttachment(attachment.OpenReadStream().StreamToBytes(), attachment.FileName, attachment.ContentType));
                    }
                }

                await Mail.Instance.SendMailAsync(to, cc, bcc, subject, body, mailAttachments.ToArray(), from);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Itinerary_EmailDocument", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Itinerary_Report(int agencyId, int[] tripLineIds, int[] passengerIds, int quoteNo, int tripItineraryId) {
            try {
                var reportSource = ClientLedgerDataSources.GetItineraryReportSource(HttpContext.CurrentCustomerId(), agencyId, WebHostEnvironment.ContentRootPath, quoteNo, tripItineraryId, await HttpContext.TravelDocumentTimeFormat(Cache), tripLineIds, passengerIds, HttpContext.Now(), HttpContext.UserFullName());
                return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Itinerary_Report", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Itinerary_ExportPdf(int agencyId, int tripId, string tripLineIds, string passengerIds, int quoteNo, int tripItineraryId) {
            try {
                string fileName = string.Format("{0}.pdf", IssuedDocument.GetItineraryName(Context, tripId, quoteNo));
                var reportSource = ClientLedgerDataSources.GetItineraryReportSource(HttpContext.CurrentCustomerId(), agencyId, WebHostEnvironment.ContentRootPath, quoteNo, tripItineraryId, await HttpContext.TravelDocumentTimeFormat(Cache), tripLineIds, passengerIds, HttpContext.Now(), HttpContext.UserFullName());

                var result = Utils.ExportToPdf(reportSource);
                return File(result.DocumentBytes, result.MimeType, fileName);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Itinerary_ExportPdf", ex);
                return Redirect("/Shared/Error");
            }
        }

        public async Task<IActionResult> Itinerary_ExportWord(int agencyId, int tripId, string tripLineIds, string passengerIds, int quoteNo, int tripItineraryId) {
            try {
                string fileName = string.Format("{0}.docx", IssuedDocument.GetItineraryName(Context, tripId, quoteNo));
                var reportSource = ClientLedgerDataSources.GetItineraryReportSource(HttpContext.CurrentCustomerId(), agencyId, WebHostEnvironment.ContentRootPath, quoteNo, tripItineraryId, await HttpContext.TravelDocumentTimeFormat(Cache), tripLineIds, passengerIds, HttpContext.Now(), HttpContext.UserFullName());

                var result = Utils.ExportToWord(reportSource);
                return File(result.DocumentBytes, result.MimeType, fileName);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Itinerary_ExportWord", ex);
                return Redirect("/Shared/Error");
            }
        }
        #endregion

        #region Reports
        public IActionResult Reports() {
            var model = new ClientReportSourceModel {
                ReportDate = DateTime.Today,
                LedgerDocumentType = LedgerDocumentType.Standard,
                TransactionBalanceType = TransactionBalanceType.NonZero
            };

            return View(model);
        }

        public async Task<IActionResult> Client_Report(ClientReportSourceModel model) {
            try {
                var context = Context;

                model.CustomerId = HttpContext.CurrentCustomerId();
                model.DefaultAgency = await HttpContext.CurrentDefaultAgencyName(Cache);
                model.CreationUser = HttpContext.UserFullName();
                model.CreationTime = HttpContext.Now();

                model.TripNoFrom = context.Trip.Find(model.TripIdFrom)?.TripNo ?? string.Empty;
                model.TripNoTo = context.Trip.Find(model.TripIdTo)?.TripNo ?? string.Empty;

                var reportSource = ClientLedgerDataSources.GetReportSource(model);

                RenderingResult result = null;
                string fileName = null;

                switch (model.OutputType) {
                    default:
                        return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
                    case "ExportPdf":
                        result = Utils.ExportToPdf(reportSource);
                        fileName = string.Format("{0}.pdf", ClientLedgerDataSources.GetReportFileName(model.ReportSource));
                        break;
                    case "ExportWord":
                        result = Utils.ExportToWord(reportSource);
                        fileName = string.Format("{0}.docx", ClientLedgerDataSources.GetReportFileName(model.ReportSource));
                        break;
                    case "ExportExcel":
                        result = Utils.ExportToExcel(reportSource);
                        fileName = string.Format("{0}.xlsx", ClientLedgerDataSources.GetReportFileName(model.ReportSource));
                        break;
                }

                return File(result.DocumentBytes, result.MimeType, fileName);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Client_Report", ex);

                if (model.OutputType == "Report") {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
                else {
                    return Redirect("/Shared/Error");
                }
            }
        }
        #endregion
    }
}