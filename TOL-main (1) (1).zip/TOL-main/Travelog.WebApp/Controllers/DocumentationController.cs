﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Travelog.WebApp.Admin;

namespace Travelog.WebApp.Controllers {
    [Authorize]
	public class DocumentationController : BaseController {
		private const string ClassName = "Travelog.WebApp.Controllers.Documentation";

        public DocumentationController(IWebHostEnvironment webHostEnvironment, IDistributedCache cache) : base(webHostEnvironment, cache) {
        }

        [AllowAnonymous]
		public IActionResult ProductInfo() {
			return View();
		}

        public IActionResult TermsAndConditions() {
            ViewBag.LastWriteTime = string.Format("Last Updated: {0:g}", AdminSettings.GetTermsAndConditionsLastWriteTime(WebHostEnvironment.ContentRootPath));
            ViewBag.UseCurrentTheme = true;
            return View("~/Views/Documentation/TermsAndConditions.cshtml");
        }

        public async Task<IActionResult> TermsAndConditions_Read() {
            try {
                string filePath = Path.Combine(WebHostEnvironment.ContentRootPath, "wwwroot/html/TermsAndConditions.html");
                string result = await System.IO.File.ReadAllTextAsync(filePath);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TermsAndConditions_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
    }
}