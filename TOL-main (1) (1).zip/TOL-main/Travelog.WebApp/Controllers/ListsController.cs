using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kendo.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Caching.Distributed;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Enums;

namespace Travelog.WebApp.Controllers {
    [Authorize]
    public class ListsController : BaseController {
        public ListsController(IWebHostEnvironment webHostEnvironment, IDistributedCache cache) : base(webHostEnvironment, cache) {
        }

        #region Lists
        [HttpPost]
        public JsonResult GetAccessLevelList() {
            return Json(Lists.GetEnumList<AccessLevel>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetAccountCategoryList(bool includeDefault) {
            return Json(Lists.GetEnumList<AccountCategory>(EnumOrderByType.Value, includeDefault));
        }

        [HttpPost]
        public JsonResult GetAccountTypeList(bool includeDefault) {
            return Json(Lists.GetEnumList<AccountType>(EnumOrderByType.Value, includeDefault));
        }

        [HttpPost]
        public JsonResult GetAddressPrintOptionList() {
            return Json(Lists.GetEnumList<AddressPrintOption>());
        }

        [HttpPost]
        public JsonResult GetAddressTypeList() {
            return Json(Lists.GetEnumList<AddressType>());
        }

        [HttpPost]
        public JsonResult GetAdjustmentTransactionTypeList() {
            return Json(Lists.GetEnumList<AdjustmentTransactionType>());
        }

        [HttpPost]
        public JsonResult GetAdjustmentTypeList(bool includeDefault) {
            return Json(Lists.GetAdjustmentTypeList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetAgingCycleList(bool includeDefault) {
            return Json(Lists.GetEnumList<AgingCycle>(EnumOrderByType.Value, includeDefault));
        }

        [HttpPost]
        public JsonResult GetAgencyList(bool includeDefault) {
            return Json(Lists.GetAgencyList(HttpContext, Context, false, includeDefault));
        }

        [HttpPost]
        public JsonResult GetAgencyPseudoCityCodeList(Crs crs) {
            return Json(Lists.GetAgencyPseudoCityCodeList(Context, CustomerSettings.Setting(HttpContext.CurrentCustomerId()).CustomerType == CustomerType.Customer ? HttpContext.CurrentDefaultAgencyId() : 0, crs));
        }

        [HttpPost]
        public JsonResult GetAgencyTypeList() {
            return Json(Lists.GetEnumList<AgencyType>());
        }

        [HttpPost]
        public JsonResult GetAgentList(bool includeDefault) {
            return Json(Lists.GetAgentList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetAircraftList() {
            return Json(Lists.GetAircraftList(Context));
        }

        [HttpPost]
        public JsonResult GetAirlineSeatingList() {
            return Json(Lists.GetEnumList<AirlineSeating>());
        }

        [HttpPost]
        public JsonResult GetAirlineStandardCommentTypeList() {
            return Json(Lists.GetEnumList<AirlineStandardCommentType>());
        }

        [HttpPost]
        public JsonResult GetAirportTypeList() {
            return Json(Lists.GetEnumList<AirportType>());
        }

        [HttpPost]
        public JsonResult GetBaggageUnitList() {
            return Json(Lists.GetEnumList<BaggageUnit>());
        }

        [HttpPost]
        public JsonResult GetBankAccountList(bool includeDefault) {
            return Json(Lists.GetBankAccountList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetBankAccountListExt(DateTime documentDate, bool includeDefault) {
            return Json(Lists.GetBankAccountListExt(Context, documentDate, includeDefault));
        }

        [HttpPost]
        public JsonResult GetBankAccountStatementList(int bankAccountId, bool includeDefault, bool isCompactView = false) {
            return Json(Lists.GetBankAccountStatementList(Context, bankAccountId, includeDefault, isCompactView));
        }

        [HttpPost]
        public JsonResult GetBillingCycleList() {
            return Json(Lists.GetEnumList<BillingCycle>(EnumOrderByType.Value));
        }

        [HttpPost]
        public JsonResult GetBookingStatusList() {
            return Json(Lists.GetEnumList<SerkoOnlineBookingStatus>(EnumOrderByType.Value));
        }

        [HttpPost]
        public JsonResult GetBookingTypeList() {
            return Json(Lists.GetEnumList<BookingType>(EnumOrderByType.Value));
        }

        [HttpPost]
        public JsonResult GetBspPaymentList() {
            return Json(Lists.GetBspPaymentList(Context));
        }

        [HttpPost]
        public JsonResult GetBspStatusList(bool includeDefault) {
            return Json(Lists.GetEnumList<BspStatus>(EnumOrderByType.Value, includeDefault));
        }

        [HttpPost]
        public JsonResult GetBspTypeList(bool includeDefault, bool includeAgencyCc) {
            var q = Lists.GetEnumList<BspType>(EnumOrderByType.Value, includeDefault);

            if (!includeAgencyCc)
                q.Remove(q.Find(t => t.Value == ((int)BspType.AgencyCC).ToString()));

            return Json(q);
        }

        [HttpPost]
        public JsonResult GetBspEntryTypeList() {
            return Json(Lists.GetEnumList<BspEntryType>());
        }

        [HttpPost]
        public JsonResult GetCalypsoCompanyList() {
            return Json(Lists.GetCalypsoCompanyList(Context));
        }

        [HttpPost]
        public JsonResult GetCategoryList(bool includeDefault) {
            return Json(Lists.GetCategoryList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetChartOfAccountGroupList(bool includeDefault) {
            return Json(Lists.GetEnumList<ChartOfAccountGroup>(EnumOrderByType.Value, includeDefault));
        }

        [HttpPost]
        public JsonResult GetChartOfAccountList(bool includeDefault, RowType rowType = RowType.Normal, bool excludeBankAccount = false, bool excludeRetainedProfits = false, ChartOfAccountType? chartOfAccountType = null) {
            return Json(Lists.GetChartOfAccountList(Context, CustomerSettings.Setting(HttpContext.CurrentCustomerId()).AgencyType == AgencyType.MultiAgencyGLIndividual ? HttpContext.CurrentDefaultAgencyId() : -1, includeDefault, rowType, excludeBankAccount, excludeRetainedProfits, chartOfAccountType));
        }

        [HttpPost]
        public JsonResult GetChartOfAccountTransactionTypeList() {
            return Json(Lists.GetEnumList<ChartOfAccountTransactionType>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetChartOfAccountTypeList(bool includeDefault) {
            return Json(Lists.GetEnumList<ChartOfAccountType>(EnumOrderByType.Text, includeDefault));
        }

        [HttpPost]
        public JsonResult GetClassList(string classCategory, bool includeDefault) {
            return Json(Lists.GetClassList(Context, classCategory, includeDefault));
        }

        [HttpPost]
        public JsonResult GetClassTypeList(bool includeDefault) {
            return Json(Lists.GetEnumList<ClassType>(EnumOrderByType.Text, includeDefault));
        }

        [HttpPost]
        public JsonResult GetClientAccountTypeList() {
            return Json(Lists.GetEnumList<ClientAccountType>());
        }

        [HttpPost]
        public JsonResult GetClubMembershipList(bool includeDefault) {
            return Json(Lists.GetClubMembershipList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetConditionList() {
            return Json(Lists.GetConditionList(Context));
        }

        [HttpPost]
		public JsonResult GetConsultantList(bool validateOtherConsultants = false, bool includeDefault = false, int customerId = 0) {
			AppMainContext context = null;
			bool disposeContext = false;

			try {
				if (customerId == 0 || customerId == HttpContext.CurrentCustomerId()) {
					context = Context;
				}
				else {
					context = new AppMainContext(HttpContext.User, customerId, HttpContext.IsExternalUser(), HttpContext.IsSuperUser());
					disposeContext = true;
				}

				var q = Lists.GetConsultantList(HttpContext, context, validateOtherConsultants, includeDefault);
				return Json(disposeContext ? q.ToList() : q);
			}
			finally {
				if (disposeContext)
					context.Dispose();
			}
		}

		[HttpPost]
        public JsonResult GetContactTitleList() {
            return Json(Lists.GetContactTitleList(Context));
        }

        [HttpPost]
        public JsonResult GetContactMethodList() {
            return Json(Lists.GetEnumList<ContactMethod>());
        }

        [HttpPost]
        public JsonResult GetCountryZoneList() {
            return Json(Lists.GetEnumList<CountryZone>());
        }

        [HttpPost]
        public JsonResult GetCreditorNoPageList(int agencyId, bool includeDefault, BspAgentType bspAgentType = BspAgentType.All, bool outstandingVouchers = false) {
            return Json(Lists.GetCreditorList(HttpContext, Context, agencyId, includeDefault, bspAgentType, outstandingVouchers));
        }

        [HttpPost]
        public JsonResult GetCrsList(bool includeDefault, bool nullIsAll, bool isNew = false) {
            List<SelectListItem> q;

            if (isNew) {
                q = new List<SelectListItem> {
                    new SelectListItem { Value = ((int)Crs.Amadeus).ToString(), Text = nameof(Crs.Amadeus) },
                    new SelectListItem { Value = ((int)Crs.ExpressTravelGroup).ToString(), Text = Crs.ExpressTravelGroup.GetEnumDescription() },
                    new SelectListItem { Value = ((int)Crs.Galileo).ToString(), Text = nameof(Crs.Galileo) }
                };

                if (includeDefault)
                    q.Insert(0, new SelectListItem { Value = "-1", Text = nullIsAll ? "Default [All CRS]" : "Not Specified" });
            }
            else {
                q = Lists.GetEnumList<Crs>(EnumOrderByType.Text, includeDefault);

                if (includeDefault && nullIsAll)
                    q.Single(t => t.Value == ((int)Crs.NotSpecified).ToString()).Text = "Default [All CRS]";
            }

            return Json(q);
        }

        [HttpPost]
        public JsonResult GetCrsImportOptionList() {
            return Json(Lists.GetEnumList<CrsImportOption>());
        }

        [HttpPost]
        public JsonResult GetCurrencyList(bool includeDefault) {
            return Json(Lists.GetCurrencyList(Context, includeDefault));
        }

        [HttpPost]
        public async Task<JsonResult> GetCustomerChartOfAccountList(bool includeDefault, RowType rowType = RowType.Normal, bool excludeBankAccount = false) {
            return Json(Lists.GetChartOfAccountList(ManagementContext, await HttpContext.HeadOfficeAgencyId(Cache), includeDefault, rowType, excludeBankAccount));
        }

        [HttpPost]
        public JsonResult GetCustomerContactTypeList() {
            return Json(Lists.GetEnumList<CustomerContactType>());
        }

        [HttpPost]
        public JsonResult GetCustomerList(string userId) {
            return Json(Lists.GetCustomerList(AdminContext, userId));
        }

        [HttpPost]
        public JsonResult GetCustomerTransactionStatusList() {
            return Json(Lists.GetEnumList<CustomerTransactionStatus>());
        }

        [HttpPost]
        public JsonResult GetCustomerTransactionTypeList(bool accountOnly = false) {
            List<SelectListItem> q;

            if (accountOnly) {
                q = new List<SelectListItem> {
                    new SelectListItem {
                        Value = ((int)CustomerTransactionType.AccountDeactivated).ToString(),
                        Text = CustomerTransactionType.AccountDeactivated.GetEnumDescription()
                    },
                    new SelectListItem {
                        Value = ((int)CustomerTransactionType.AccountReactivated).ToString(),
                        Text = CustomerTransactionType.AccountReactivated.GetEnumDescription()
                    },
                    new SelectListItem {
                        Value = ((int)CustomerTransactionType.AccountSuspended).ToString(),
                        Text = CustomerTransactionType.AccountSuspended.GetEnumDescription()
                    },
                    new SelectListItem {
                        Value = ((int)CustomerTransactionType.SuspensionLifted).ToString(),
                        Text = CustomerTransactionType.SuspensionLifted.GetEnumDescription()
                    }
                };
            }
            else {
                q = Lists.GetEnumList<CustomerTransactionType>();
            }

            return Json(q);
        }

        [HttpPost]
        public JsonResult GetDayOfWeekList() {
            return Json(Lists.GetEnumList<DayOfWeekExt>(EnumOrderByType.Value));
        }

        [HttpPost]
        public JsonResult GetDebitCreditTypeList() {
            return Json(Lists.GetEnumList<DebitCreditType>(EnumOrderByType.Value));
        }

        [HttpPost]
        public JsonResult GetDebtorAddressList(int debtorId) {
            return Json(Lists.GetDebtorAddressList(LazyContext, debtorId));
        }

        [HttpPost]
        public JsonResult GetDebtorContactList(int debtorId, bool canBook, bool canAuthorise, bool includeDefault) {
            return Json(Lists.GetDebtorContactList(LazyContext, debtorId, canBook, canAuthorise, includeDefault));
        }

        [HttpPost]
        public JsonResult GetDebtorCustomerList(bool excludeManagementCustomers) {
            return Json(Lists.GetDebtorCustomerList(AdminContext, excludeManagementCustomers));
        }

        [HttpPost]
        public JsonResult GetDebtorNoPageList(bool includeDefault, int agencyId, bool isSubDebtor = false, int billingParentId = 0) {
            return Json(Lists.GetDebtorList(HttpContext, Context, agencyId, includeDefault, isSubDebtor, billingParentId));
        }

        [HttpPost]
        public JsonResult GetDepartureDateStatusList() {
            return Json(Lists.GetEnumList<DepartureDateStatus>());
        }

        [HttpPost]
        public JsonResult GetDestinationList(bool includeDefault) {
            return Json(Lists.GetDestinationList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetDiscountReasonList() {
            return Json(Lists.GetDiscountReasonList(Context));
        }

        [HttpPost]
        public JsonResult GetDocumentCombinedStatusList(DepositStatusType depositStatusType, bool includeDefault, DocumentStatus excludeDocumentStatus = DocumentStatus.None) {
            var q = Lists.GetEnumList<DocumentCombinedStatus>(EnumOrderByType.Value, includeDefault);

            if (depositStatusType != DepositStatusType.Default) {
                var item = q.Find(t => t.Value == ((int)DocumentCombinedStatus.DepositedPaid).ToString());

                switch (depositStatusType) {
                    case DepositStatusType.Deposited:
                        item.Text = "Deposited";
                        break;
                    case DepositStatusType.Paid:
                        item.Text = "Paid";
                        break;
                    case DepositStatusType.Excluded:
                        q.Remove(item);
                        break;
                }
            }

            if (excludeDocumentStatus != DocumentStatus.None) {
                var item = q.Find(t => t.Value == ((int)excludeDocumentStatus).ToString());
                q.Remove(item);
            }

            return Json(q);
        }

        [HttpPost]
        public JsonResult GetDocumentCommentList() {
            return Json(Lists.GetEnumList<DocumentComment>());
        }

        [HttpPost]
        public JsonResult GetDocumentStatusList(DepositStatusType depositStatusType, bool includeDefault, DocumentStatus excludeDocumentStatus = DocumentStatus.None) {
            var q = Lists.GetEnumList<DocumentStatus>(EnumOrderByType.Value, includeDefault);

            if (depositStatusType != DepositStatusType.Default) {
                var item = q.Find(t => t.Value == ((int)DocumentStatus.DepositedPaid).ToString());

                switch (depositStatusType) {
                    case DepositStatusType.Deposited:
                        item.Text = "Deposited";
                        break;
                    case DepositStatusType.Paid:
                        item.Text = "Paid";
                        break;
                    case DepositStatusType.Excluded:
                        q.Remove(item);
                        break;
                }
            }

            if (excludeDocumentStatus != DocumentStatus.None) {
                var item = q.Find(t => t.Value == ((int)excludeDocumentStatus).ToString());
                q.Remove(item);
            }

            return Json(q);
        }

        [HttpPost]
        public JsonResult GetDocumentTypeList() {
            return Json(Lists.GetEnumList<DocumentType>());
        }

        [HttpPost]
        public JsonResult GetDurationCoverageTypeList() {
            return Json(Lists.GetEnumList<DurationCoverageType>());
        }

        [HttpPost]
        public JsonResult GetExchangeRateTypeList() {
            return Json(Lists.GetEnumList<ExchangeRateType>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetExternalUserCustomerList() {
            return Json(Lists.GetExternalUserCustomerList(HttpContext, AdminContext));
        }

        [HttpPost]
        public JsonResult GetFiscalPeriodEnumList() {
            return Json(Lists.GetEnumList<FiscalPeriod>());
        }

        [HttpPost]
        public JsonResult GetFiscalPeriodBudgetList(int settingId, FiscalPeriod fiscalPeriod) {
            return Json(Lists.GetFiscalPeriodBudgetList(HttpContext, settingId, fiscalPeriod));
        }

        [HttpPost]
        public JsonResult GetFiscalPeriodList(DateTime fiscalYearStartDate) {
            return Json(Lists.GetFiscalPeriodList(HttpContext, fiscalYearStartDate));
        }

        [HttpPost]
        public JsonResult GetFiscalYearList() {
            return Json(Lists.GetFiscalYearList(HttpContext));
        }

        [HttpPost]
        public JsonResult GetFlightClassList() {
            return Json(Lists.GetEnumList<FlightClass>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetFormOfPaymentList(bool useFullDescription, bool excludeCash, bool includeDefault, bool excludeCreditCard = false, bool excludeAgencyCc = false, bool excludePaySupplierGross = false, bool excludeLoyaltyScheme = false) {
            return Json(Lists.GetFormOfPaymentList(Context, useFullDescription, excludeCash, includeDefault, excludeCreditCard, excludeAgencyCc, excludePaySupplierGross, excludeLoyaltyScheme));
        }

        [HttpPost]
        public JsonResult GetFormOfPaymentListExt(bool excludeCash, bool includeDefault) {
            return Json(Lists.GetFormOfPaymentListExt(Context, excludeCash, includeDefault));
        }

        [HttpPost]
        public JsonResult GetFormOfPaymentListByFormOfPaymentType(FormOfPaymentType formOfPaymentType, bool includeDefault) {
            return Json(Lists.GetFormOfPaymentListByFormOfPaymentType(Context, formOfPaymentType, includeDefault));
        }

        [HttpPost]
        public JsonResult GetFormOfPaymentReceiptList(bool excludeCash, bool includeDefault) {
            return Json(Lists.GetFormOfPaymentReceiptList(Context, excludeCash, includeDefault));
        }

        [HttpPost]
        public JsonResult GetFormOfPaymentTypeList(bool includeDefault) {
            return Json(Lists.GetEnumList<FormOfPaymentType>(EnumOrderByType.Text, includeDefault).Where(t => t.Value != ((int)FormOfPaymentType.ClearingHouseNet).ToString() && t.Value != ((int)FormOfPaymentType.ClearingHouseGross).ToString()));
        }

        [HttpPost]
        public JsonResult GetFormValidationMethodList() {
            return Json(Lists.GetEnumList<FormValidationMethod>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetGenderList() {
            return Json(Lists.GetEnumList<Gender>());
        }

        [HttpPost]
        public JsonResult GetGeneralLedgerDivisionList() {
            return Json(Lists.GetEnumList<GeneralLedgerDivision>());
        }

        [HttpPost]
        public JsonResult GetGeneralLedgerReportTypeList() {
            return Json(Lists.GetEnumList<GeneralLedgerReportType>());
        }

        [HttpPost]
        public JsonResult GetGroupList(bool includeDefault) {
            return Json(Lists.GetGroupList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetInsurancePassengerList(int tripLineId) {
            return Json(Lists.GetInsurancePassengerList(Context, tripLineId));
        }

        [HttpPost]
        public JsonResult GetInsurancePolicyList(int supplierId) {
            return Json(Lists.GetInsurancePolicyList(Context, supplierId));
        }

        [HttpPost]
        public JsonResult GetInsurancePolicyPlanList(int insurancePolicyId) {
            return Json(Lists.GetInsurancePolicyPlanList(Context, insurancePolicyId));
        }

        [HttpPost]
        public JsonResult GetInsurancePolicyCoverageList() {
            return Json(Lists.GetEnumList<InsurancePolicyCoverage>());
        }

        [HttpPost]
        public JsonResult GetInternationalDateOffsetList() {
            return Json(Lists.GetEnumList<InternationalDateOffset>(EnumOrderByType.Value));
        }

        [HttpPost]
        public JsonResult GetInvoiceTypeList(bool includeDefault) {
            return Json(Lists.GetEnumList<InvoiceType>(EnumOrderByType.Value, includeDefault));
        }

        [HttpPost]
        public JsonResult GetInvoiceList(int tripId, int debtorId, bool includeDefault) {
            return Json(Lists.GetInvoiceList(Context, tripId, debtorId, includeDefault));
        }

        [HttpPost]
        public JsonResult GetInvoiceValidationTypeList() {
            return Json(Lists.GetEnumList<InvoiceValidationType>());
        }

        [HttpPost]
        public JsonResult GetIssuedDocumentTypeList(bool quoteOnly = false, bool tripDocumentsOnly = false, bool includeDebtorStatement = true, bool includePersonalStatement = false, bool includeOther = true, bool includeTrialBalance = false) {
            List<SelectListItem> q = null;

            if (quoteOnly) {
                q = new List<SelectListItem> {
                    new SelectListItem {
                        Value = ((int)IssuedDocumentType.Quote).ToString(),
                        Text = IssuedDocumentType.Quote.GetEnumDescription()
                    },
                    new SelectListItem {
                        Value = ((int)IssuedDocumentType.TrialBalance).ToString(),
                        Text = IssuedDocumentType.TrialBalance.GetEnumDescription()
                    }
                };

                return Json(q);
            }

            q = Lists.GetEnumList<IssuedDocumentType>(EnumOrderByType.None, false);

            if (!includeDebtorStatement)
                q.Remove(q.Find(t => t.Value == ((int)IssuedDocumentType.DebtorStatement).ToString()));

            if (!includePersonalStatement)
                q.Remove(q.Find(t => t.Value == ((int)IssuedDocumentType.PersonalStatement).ToString()));

            if (tripDocumentsOnly) {
                q.Remove(q.Find(t => t.Value == ((int)IssuedDocumentType.Invoice).ToString()));
                q.Remove(q.Find(t => t.Value == ((int)IssuedDocumentType.Receipt).ToString()));
                q.Remove(q.Find(t => t.Value == ((int)IssuedDocumentType.Voucher).ToString()));
            }

            if (!includeOther)
                q.Remove(q.Find(t => t.Value == ((int)IssuedDocumentType.Other).ToString()));

            if (!includeTrialBalance)
                q.Remove(q.Find(t => t.Value == ((int)IssuedDocumentType.TrialBalance).ToString()));

            return Json(q);
        }

        [HttpPost]
        public JsonResult GetItineraryPricingOptionList() {
            return Json(Lists.GetEnumList<ItineraryPricingOption>());
        }

        [HttpPost]
        public JsonResult GetLedgerDocumentTypeList() {
            return Json(Lists.GetEnumList<LedgerDocumentType>());
        }

        [HttpPost]
        public JsonResult GetLedgerTypeList(LedgerType ledgerType, bool isAdministrator) {
            var q = Lists.GetEnumList<LedgerType>(EnumOrderByType.Value);

            var noLedger = q.Find(t => t.Value == ((int)LedgerType.None).ToString());
            var debtorLedger = q.Find(t => t.Value == ((int)LedgerType.DebtorLedger).ToString());
            var creditorLedger = q.Find(t => t.Value == ((int)LedgerType.CreditorLedger).ToString());

            if (isAdministrator) {
                noLedger.Text = "All Ledgers";

                if (ledgerType == LedgerType.DebtorLedger) {
                    q.Remove(creditorLedger);
                }
                else if (ledgerType == LedgerType.CreditorLedger) {
                    q.Remove(debtorLedger);
                }
            }
            else {
                var clientLedger = q.Find(t => t.Value == ((int)LedgerType.ClientLedger).ToString());
                var generalLedger = q.Find(t => t.Value == ((int)LedgerType.GeneralLedger).ToString());

                q.Remove(noLedger);

                switch (ledgerType) {
                    case LedgerType.ClientLedger:
                        q.Remove(debtorLedger);
                        q.Remove(creditorLedger);
                        q.Remove(generalLedger);
                        break;
                    case LedgerType.CreditorLedger:
                        q.Remove(clientLedger);
                        q.Remove(debtorLedger);
                        q.Remove(generalLedger);
                        break;
                    case LedgerType.DebtorLedger:
                        q.Remove(clientLedger);
                        q.Remove(creditorLedger);
                        q.Remove(generalLedger);
                        break;
                    case LedgerType.GeneralLedger:
                        q.Remove(clientLedger);
                        q.Remove(debtorLedger);
                        q.Remove(creditorLedger);
                        break;
                }
            }

            return Json(q);
        }

        [HttpPost]
        public JsonResult GetLeisureActivityList() {
            return Json(Lists.GetLeisureActivityList(Context));
        }

        [HttpPost]
        public JsonResult GetLocationList(bool includeDefault) {
            return Json(Lists.GetLocationList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetLoyaltySchemePointsRoundingMethodList() {
            return Json(Lists.GetEnumList<LoyaltySchemePointsRoundingMethod>());
        }

        [HttpPost]
        public JsonResult GetLoyaltySchemeTypeList() {
            return Json(Lists.GetEnumList<LoyaltySchemeType>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetMaritalStatusList() {
            return Json(Lists.GetEnumList<MaritalStatus>());
        }

        [HttpPost]
        public JsonResult GetMarkupStrategyList() {
            return Json(Lists.GetMarkupStrategyList(Context));
        }

        [HttpPost]
        public JsonResult GetMarkupStrategyApportionMethodList() {
            return Json(Lists.GetEnumList<ApportionMethod>());
        }

        [HttpPost]
        public JsonResult GetMatchedTxnsReportOptionList() {
            return Json(Lists.GetEnumList<MatchedTxnsReportOption>());
        }

        [HttpPost]
        public JsonResult GetMealServedList() {
            return Json(Lists.GetMealServedList(Context));
        }

        [HttpPost]
        public JsonResult GetNonBspPaymentList() {
            return Json(Lists.GetNonBspPaymentList(Context));
        }

        [HttpPost]
        public JsonResult GetNonBspStatusList(bool includeDefault) {
            return Json(Lists.GetEnumList<NonBspStatus>(EnumOrderByType.Value, includeDefault));
        }

        [HttpPost]
        public JsonResult GetNonBspTypeList(bool includeDefault, bool includeAgencyCc) {
            var q = Lists.GetEnumList<NonBspType>(EnumOrderByType.Value, includeDefault);

            if (!includeAgencyCc)
                q.Remove(q.Find(t => t.Value == ((int)NonBspType.AgencyCC).ToString()));

            return Json(q);
        }

        [HttpPost]
        public JsonResult GetOfferedReasonList() {
            return Json(Lists.GetOfferedReasonList(Context));
        }

        [HttpPost]
        public JsonResult GetOverrideBasisList() {
            return Json(Lists.GetEnumList<OverrideBasis>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetPaidStatusReportOptionList() {
            return Json(Lists.GetEnumList<PaidStatusReportOption>());
        }

        [HttpPost]
        public JsonResult GetPassengerClassificationList() {
            return Json(Lists.GetEnumList<PassengerClassification>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetPassengerListByProfileId(int profileId) {
            return Json(Lists.GetPassengerListByProfileId(Context, profileId));
        }

        [HttpPost]
        public JsonResult GetPassengerListByTripId(int tripId, bool includeDefault, int excludePassengerId = -1) {
            return Json(Lists.GetPassengerListByTripId(Context, tripId, includeDefault, excludePassengerId));
        }

        [HttpPost]
        public JsonResult GetPassengerListByTripIdOrDebtorIdOrCreditorId(int tripId, int debtorId, int creditorId, bool includeDefault, int excludePassengerId = -1) {
            return Json(Lists.GetPassengerListByTripIdOrDebtorIdOrCreditorId(Context, tripId, debtorId, creditorId, includeDefault, excludePassengerId));
        }

        [HttpPost]
        public JsonResult GetPassengerTypeList() {
            return Json(Lists.GetEnumList<PassengerType>(EnumOrderByType.Value));
        }

        [HttpPost]
        public JsonResult GetPayIdTypeList(bool includeDefault) {
            return Json(Lists.GetEnumList<PayIdType>(EnumOrderByType.Value, includeDefault));
        }

        [HttpPost]
        public JsonResult GetPaymentMethodList(AccountType accountType, FormOfPaymentType formOfPaymentType, int formOfPaymentId, int tripId, int debtorId, int creditorId, int chartOfAccountId, bool includeDefault, bool? isActive = null) {
            return Json(Lists.GetPaymentMethodList(Context, accountType, formOfPaymentType, formOfPaymentId, tripId, debtorId, creditorId, chartOfAccountId, includeDefault, isActive));
        }

        [HttpPost]
        public JsonResult GetPaymentMethodCreditCardList(AccountType accountType, int formOfPaymentId, int profileId, int tripId, int debtorId, int creditorId, int chartOfAccountId, bool includeDefault, bool? isActive = null) {
            return Json(Lists.GetPaymentMethodCreditCardList(Context, accountType, formOfPaymentId, profileId, tripId, debtorId, creditorId, chartOfAccountId, includeDefault, isActive));
        }

        [HttpPost]
        public JsonResult GetPaymentTermList() {
            return Json(Lists.GetPaymentTermList(Context));
        }

        [HttpPost]
        public JsonResult GetPaymentTypeList(bool includeDefault) {
            return Json(Lists.GetEnumList<PaymentType>(EnumOrderByType.Value, includeDefault));
        }

        [HttpPost]
        public JsonResult GetPositionList() {
            return Json(Lists.GetEnumList<Position>());
        }

        [HttpPost]
        public JsonResult GetPrincipalPaymentMethodList(int customerId, bool? isActive = null) {
            return Json(Lists.GetPrincipalPaymentMethodList(AdminContext, customerId, isActive));
        }

        [HttpPost]
        public JsonResult GetReceiptBankDepositList(int bankAccountId, bool includeDefault) {
            return Json(Lists.GetReceiptBankDepositList(Context, bankAccountId, includeDefault));
        }

        [HttpPost]
        public JsonResult GetReceiptDetailLoyaltySchemeReferenceList(int tripId) {
            return Json(Lists.GetReceiptDetailLoyaltySchemeReferenceList(Context, tripId));
        }

        [HttpPost]
        public JsonResult GetReceiptList(int tripId, int debtorId, int creditorId, bool includeDefault) {
            return Json(Lists.GetReceiptList(HttpContext, Context, tripId, debtorId, creditorId, includeDefault));
        }

        [HttpPost]
        public JsonResult GetReceiptStatusList(bool includeDefault) {
            return Json(Lists.GetEnumList<ReceiptStatus>(EnumOrderByType.Value, includeDefault));
        }

        [HttpPost]
        public JsonResult GetReceiptTypeList() {
            return Json(Lists.GetEnumList<ReceiptType>());
        }

        [HttpPost]
        public JsonResult GetRegionList(bool includeDefault) {
            return Json(Lists.GetRegionList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetReportPeriodList() {
            return Json(Lists.GetEnumList<ReportPeriod>());
        }

        [HttpPost]
        public JsonResult GetReportSignList() {
            return Json(Lists.GetEnumList<ReportSign>());
        }

        [HttpPost]
        public JsonResult GetRolesList(bool includeSystemAdministrator = false, bool includeDefault = false) {
            return Json(Lists.GetRolesList(AdminContext, includeSystemAdministrator, includeDefault));
        }

        [HttpPost]
        public JsonResult GetRowTypeList() {
            return Json(Lists.GetEnumList<RowType>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetSalesAnalysisPeriodList(SalesAnalysisPeriodType salesAnalysisPeriodType) {
            return Json(Lists.GetSalesAnalysisPeriodList(Context, salesAnalysisPeriodType));
        }

        [HttpPost]
        public JsonResult GetSalesAnalysisPeriodTypeList() {
            return Json(Lists.GetEnumList<SalesAnalysisPeriodType>());
        }

        [HttpPost]
        public JsonResult GetSaleTypeList(bool includeDefault) {
            return Json(Lists.GetSaleTypeList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetSaleTypeGroupingList() {
            return Json(Lists.GetSaleTypeGroupingList(Context));
        }

        [HttpPost]
        public JsonResult GetSaleTypeListExt(bool includeDefault) {
            return Json(Lists.GetSaleTypeListExt(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetSaleTypeReportingTypeList() {
            return Json(Lists.GetEnumList<SaleTypeReportingType>());
        }

        [HttpPost]
        public JsonResult GetSeatStatusList() {
            return Json(Lists.GetEnumList<SeatStatus>());
        }

        [HttpPost]
        public JsonResult GetSelectionOptionList() {
            return Json(Lists.GetEnumList<SelectionOption>());
        }

        [HttpPost]
        public JsonResult GetServiceFeeTypeList(DebitCreditType? debitCreditType = null, bool includeDefault = false) {
            return Json(Lists.GetServiceFeeTypeList(Context, debitCreditType, includeDefault));
        }

        [HttpPost]
        public JsonResult GetServiceFeePaymentTypeList() {
            return Json(Lists.GetEnumList<ServiceFeePaymentType>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetServiceTypeList(bool includeDefault) {
            return Json(Lists.GetServiceTypeList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetServiceTypeListExt(bool landTripLinesOnly, bool includeDefault) {
            return Json(Lists.GetServiceTypeListExt(Context, landTripLinesOnly, includeDefault));
        }

        [HttpPost]
        public JsonResult GetServiceTypeRateBasisListByTripLineType(TripLineType tripLineType) {
            return Json(Lists.GetServiceTypeRateBasisListByTripLineType(Context, tripLineType));
        }

        [HttpPost]
        public JsonResult GetServiceTypeRateBasisListByServiceTypeId(int serviceTypeId, bool includeDefault) {
            return Json(Lists.GetServiceTypeRateBasisListByServiceTypeId(Context, serviceTypeId, includeDefault));
        }

        [HttpPost]
        public JsonResult GetSignTypeList(bool includeDefault) {
            var q = Lists.GetEnumList<SignType>(EnumOrderByType.Value);

            if (!includeDefault) {
                var item = q.Find(t => t.Value == ((int)SignType.None).ToString());
                q.Remove(item);
            }

            return Json(q);
        }

        [HttpPost]
        public JsonResult GetSourceList(bool includeDefault) {
            return Json(Lists.GetSourceList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetSpecialRequestFreeFormatList() {
            return Json(Lists.GetEnumList<SpecialRequestFreeFormat>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetSpecialRequestList() {
            return Json(Lists.GetSpecialRequestList(Context));
        }

        [HttpPost]
        public JsonResult GetSpecialRequestTypeList(bool includeDefault) {
            return Json(Lists.GetEnumList<SpecialRequestType>(EnumOrderByType.Text, includeDefault));
        }

        [HttpPost]
        public JsonResult GetStandardCommentList(bool includeDefault, StandardCommentType standardCommentType = StandardCommentType.NotSpecified) {
            return Json(Lists.GetStandardCommentList(Context, includeDefault, standardCommentType));
        }

        [HttpPost]
        public JsonResult GetStandardCommentTypeList(bool includeDefault) {
            return Json(Lists.GetEnumList<StandardCommentType>(EnumOrderByType.Text, includeDefault));
        }

        [HttpPost]
        public JsonResult GetSupplierChainList(bool includeDefault, bool supplierServiceRateExistsOnly = false) {
            return Json(Lists.GetSupplierChainList(Context, includeDefault, supplierServiceRateExistsOnly));
        }

        [HttpPost]
        public JsonResult GetSupplierCommissionTypeList() {
            return Json(Lists.GetEnumList<SupplierCommissionType>());
        }

        [HttpPost]
        public JsonResult GetSupplierServiceList(bool includeDefault) {
            return Json(Lists.GetSupplierServiceList(Context, includeDefault));
        }

        [HttpPost]
        public JsonResult GetSurchargeRateTypeList() {
            return Json(Lists.GetEnumList<SurchargeRateType>());
        }

        [HttpPost]
        public JsonResult GetSurchargeTypeList() {
            return Json(Lists.GetEnumList<SurchargeType>());
        }

        [HttpPost]
        public JsonResult GetTicketMethodList() {
            return Json(Lists.GetEnumList<TicketMethod>());
        }

        [HttpPost]
        public JsonResult GetTimeFormatList() {
            return Json(Lists.GetEnumList<TimeFormat>());
        }

        [HttpPost]
        public JsonResult GetTimeZoneIdList() {
            return Json(Lists.GetTimeZoneIdList());
        }

        [HttpPost]
        public JsonResult GetTotalLevelList() {
            return Json(Lists.GetEnumList<TotalLevel>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetTransactionBalanceTypeList(bool includeDefault) {
            return Json(Lists.GetEnumList<TransactionBalanceType>(EnumOrderByType.Value, includeDefault));
        }

        [HttpPost]
        public JsonResult GetTransactionDateOptionList() {
            return Json(Lists.GetEnumList<TransactionDateOption>());
        }

        [HttpPost]
        public JsonResult GetTransactionMatchViewStatusList() {
            return Json(Lists.GetEnumList<TransactionMatchViewStatus>());
        }

        [HttpPost]
        public JsonResult GetTransactionTypeList(bool includeDefault) {
            var q = Lists.GetEnumList<TransactionType>(EnumOrderByType.Text, includeDefault);
            q.Remove(q.Single(t => t.Value == ((int)TransactionType.CreditNote).ToString()));
            return Json(q);
        }

        [HttpPost]
        public JsonResult GetTransactionViewOptionList(ReportSourceGeneralLedger reportSource = ReportSourceGeneralLedger.TrialBalance) {
            var q = Lists.GetEnumList<TransactionViewOption>();

            if (reportSource != ReportSourceGeneralLedger.BalanceSheet)
                q.Remove(q.Single(t => t.Value == ((int)TransactionViewOption.CurrentPrevious).ToString()));

            return Json(q);
        }

        [HttpPost]
        public JsonResult GetTravelSeasonList() {
            return Json(Lists.GetEnumList<TravelSeason>());
        }

        [HttpPost]
        public JsonResult GetTravelTypeList() {
            return Json(Lists.GetEnumList<TravelType>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetTravelZoneList() {
            return Json(Lists.GetEnumList<TravelZone>(EnumOrderByType.Text));
        }

        [HttpPost]
        public JsonResult GetTripItineraryListByTripId(int tripId, bool includePassengers = false) {
            return Json(Lists.GetTripItineraryListByTripId(Context, tripId, includePassengers));
        }

        [HttpPost]
        public JsonResult GetTripLineAirPassengerList(int tripLineId, bool includeDefault, bool isNew, TransactionType transactionType = TransactionType.All) {
            return Json(Lists.GetTripLineAirPassengerList(LazyContext, HttpContext.CurrentCustomerId(), tripLineId, includeDefault, isNew, transactionType));
        }

        [HttpPost]
        public JsonResult GetTripLineAirSegmentList(int tripId, int quoteNo) {
            return Json(Lists.GetTripLineAirSegmentList(Context, tripId, quoteNo));
        }

        [HttpPost]
        public JsonResult GetTripLineLandList(int tripId, bool includeDefault) {
            return Json(Lists.GetTripLineLandList(LazyContext, tripId, includeDefault));
        }

        [HttpPost]
        public JsonResult GetTripLineList(int tripId, bool includeDefault, bool isNew, int creditorId = 0, int supplierId = 0, int saleTypeId = 0) {
            return Json(Lists.GetTripLineList(LazyContext, tripId, includeDefault, isNew, creditorId, supplierId, saleTypeId));
        }

        [HttpPost]
        public JsonResult GetTripLineQuoteList(int tripId, int quoteNo = -2) {
            return Json(Lists.GetTripLineQuoteList(Context, tripId, quoteNo));
        }

        [HttpPost]
        public JsonResult GetTripLineReceiptList(int tripId, bool includeDefault, bool isNew) {
            return Json(Lists.GetTripLineReceiptList(LazyContext, tripId, includeDefault, isNew));
        }

        [HttpPost]
        public JsonResult GetTripLineSegmentList(int tripId, int quoteNo = -1) {
            return Json(Lists.GetTripLineSegmentList(LazyContext, tripId, quoteNo));
        }

        [HttpPost]
        public JsonResult GetTripLineTypeList() {
            return Json(Lists.GetEnumList<TripLineType>(EnumOrderByType.Value));
        }

        [HttpPost]
        public JsonResult GetTripStatusList() {
            return Json(Lists.GetEnumList<TripStatus>());
        }

        [HttpPost]
        public JsonResult GetTripTypeList() {
            return Json(Lists.GetEnumList<TripType>());
        }

        [HttpPost]
        [AllowAnonymous]
        public JsonResult GetTwoFactorAuthenticationMethodList() {
            return Json(Lists.GetEnumList<TwoFactorAuthenticationMethod>());
        }

        [HttpPost]
        public JsonResult GetUserList(int customerId) {
            return Json(Lists.GetUserList(AdminContext, customerId));
        }

        [HttpPost]
        public JsonResult GetValueTypeList() {
            return Json(Lists.GetEnumList<Biz.Enums.ValueType>());
        }

        [HttpPost]
        public async Task<JsonResult> GetVoucherDetailPassengerNameList([DataSourceRequest] DataSourceRequest request, bool includeTitle) {
            return Json(await Lists.GetVoucherDetailPassengerNameList(Context, includeTitle).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetVoucherList(int tripId, bool includeDefault) {
            return Json(Lists.GetVoucherList(Context, tripId, includeDefault));
        }

        [HttpPost]
        public JsonResult GetVoucherListExt(int creditorId, int supplierId, bool includeDefault) {
            return Json(Lists.GetVoucherListExt(Context, creditorId, supplierId, includeDefault));
        }

        [HttpPost]
        public JsonResult GetVoucherTypeList(bool includeDefault) {
            return Json(Lists.GetEnumList<VoucherType>(EnumOrderByType.Value, includeDefault));
        }
        #endregion

        #region Paged Lists
        [HttpPost]
        public async Task<JsonResult> GetAirlineList([DataSourceRequest] DataSourceRequest request, bool includeDefault, int? supplierId = null, int? id = null) {
            var q = Lists.GetAirlineList(Context, includeDefault, supplierId, id);

            if (request != null && request.Filters != null && request.Filters.Count > 0)
                q = q.OrderBy(t => t.Value.ToLower().StartsWith((request.Filters[0] as FilterDescriptor).Value.ToString().ToLower()) ? 0 : 1);

            return Json(await q.ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetAirlineListValue(int? id = null) {
            return Json(Lists.GetAirlineListValue(Context, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetBookingList([DataSourceRequest] DataSourceRequest request, Crs crs, bool isExport, int? tripId = null, int? id = null) {
            return Json(await Lists.GetBookingList(Context, crs, isExport, tripId, id).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetBookingListValue(Crs crs, bool isExport, int? tripId, int? id = null) {
            return Json(Lists.GetBookingListValue(Context, crs, isExport, tripId, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetCityList([DataSourceRequest] DataSourceRequest request, bool hasSupplierServiceRate = false, string idOrCode = null, bool codeIsId = false) {
            var q = Lists.GetCityList(Context, hasSupplierServiceRate, idOrCode, codeIsId);

            if (request?.Filters?.Count > 0)
                q = q.OrderBy(t => t.Text.ToLower().StartsWith((request.Filters[0] as FilterDescriptor).Value.ToString().ToLower()) ? 0 : 1);

            return Json(await q.ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetCityListValue(string idOrCode = null, bool codeIsId = false) {
            return Json(Lists.GetCityListValue(Context, idOrCode, codeIsId));
        }

        [HttpPost]
        public async Task<JsonResult> GetCityCodeList([DataSourceRequest] DataSourceRequest request, string idOrCode = null, bool codeIsId = true) {
            return Json(await Lists.GetCityCodeList(Context, idOrCode, codeIsId).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetCityCodeListValue(string idOrCode = null, bool codeIsId = true) {
            return Json(Lists.GetCityCodeListValue(Context, idOrCode, codeIsId));
        }

        [HttpPost]
        public async Task<JsonResult> GetCountryList([DataSourceRequest] DataSourceRequest request, bool useCountryCode, bool includeDefault, string code = null, int? id = null) {
            var q = Lists.GetCountryList(Context, useCountryCode, includeDefault, code, id);

            if (request?.Filters?.Count > 0)
                q = q.OrderBy(t => t.Text.ToLower().StartsWith((request.Filters[0] as FilterDescriptor).Value.ToString().ToLower()) ? 0 : 1);

            return Json(await q.ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetCountryListValue(bool useCountryCode, string code = null, int? id = null) {
            return Json(Lists.GetCountryListValue(Context, useCountryCode, code, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetCreditorList([DataSourceRequest] DataSourceRequest request, int agencyId, bool includeDefault, BspAgentType bspAgentType = BspAgentType.All, bool outstandingVouchers = false, int? id = null) {
            return Json(await Lists.GetCreditorList(HttpContext, Context, agencyId, includeDefault, bspAgentType, outstandingVouchers, id).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public async Task<JsonResult> GetCreditorListByTripLineType([DataSourceRequest] DataSourceRequest request, TripLineType tripLineType, int agencyId, bool includeDefault, int? id = null) {
            return Json(await Lists.GetCreditorListByTripLineType(HttpContext, Context, tripLineType, agencyId, includeDefault, id).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public async Task<JsonResult> GetCreditorListByServiceTypeId([DataSourceRequest] DataSourceRequest request, int serviceTypeId, int agencyId, bool includeDefault, int? id = null) {
            return Json(await Lists.GetCreditorListByServiceTypeId(HttpContext, Context, serviceTypeId, agencyId, includeDefault, id).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetCreditorListValue(int? id = null) {
            return Json(Lists.GetCreditorListValue(HttpContext, Context, id));
        }

        [HttpPost]
        public JsonResult GetCreditorListIndex(bool includeDefault, int? id = null) {
            return Json(Lists.GetCreditorListIndex(HttpContext, Context, includeDefault, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetDebtorList([DataSourceRequest] DataSourceRequest request, int agencyId, bool includeDefault, bool isSubDebtor = false, int billingParentId = 0, int? id = null) {
            var q = Lists.GetDebtorList(HttpContext, Context, agencyId, includeDefault, isSubDebtor, billingParentId, id);

            if (request?.Filters?.Count > 0)
                q = q.OrderBy(t => t.Value.ToLower().StartsWith((request.Filters[0] as FilterDescriptor).Value.ToString().ToLower()) ? 0 : 1);

            return Json(await q.ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetDebtorListValue(int? id = null) {
            return Json(Lists.GetDebtorListValue(HttpContext, Context, id));
        }

        public JsonResult GetDebtorListIndex(bool includeDefault, int? id = null) {
            return Json(Lists.GetDebtorListIndex(HttpContext, Context, includeDefault, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetDebtorListExt([DataSourceRequest] DataSourceRequest request, int agencyId, bool includeDefault, int? id = null) {
            var q = Lists.GetDebtorListExt(HttpContext, LazyContext, agencyId, includeDefault, id);

            if (request?.Filters?.Count > 0)
                q = q.OrderBy(t => t.Name.ToLower().StartsWith((request.Filters[0] as FilterDescriptor).Value.ToString().ToLower()) ? 0 : 1);

            return Json(await q.ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetDebtorListExtValue(int? id = null) {
            return Json(Lists.GetDebtorListExtValue(HttpContext, LazyContext, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetPassengerNameList([DataSourceRequest] DataSourceRequest request, bool includeTitle) {
            return Json(await Lists.GetPassengerNameList(Context, includeTitle).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public async Task<JsonResult> GetPaymentMethodPagedList([DataSourceRequest] DataSourceRequest request, AccountType accountType, FormOfPaymentType formOfPaymentType, int formOfPaymentId, int tripId, int debtorId, int creditorId, int chartOfAccountId, bool includeDefault, bool? isActive = null) {
            return Json(await Lists.GetPaymentMethodList(Context, accountType, formOfPaymentType, formOfPaymentId, tripId, debtorId, creditorId, chartOfAccountId, includeDefault, isActive).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetPaymentMethodPagedListValue(int? id = null) {
            return Json(Lists.GetPaymentMethodPagedListValue(Context, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetPaymentPayeeList([DataSourceRequest] DataSourceRequest request, AccountType accountType, int accountId) {
            return Json(await Lists.GetPaymentPayeeList(Context, accountType, accountId).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public async Task<JsonResult> GetProfileList([DataSourceRequest] DataSourceRequest request, bool includeDefault, string defaultText = "Not Specified", int? id = null) {
            var q = Lists.GetProfileList(HttpContext, Context, Cache, includeDefault, defaultText, id);

            if (request?.Filters?.Count > 0)
                q = q.OrderBy(t => t.Code.ToLower().StartsWith((request.Filters[0] as FilterDescriptor).Value.ToString().ToLower()) ? 0 : 1);

            return Json(await q.ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetProfileListValue(string defaultText = "Not Specified", int? id = null) {
            return Json(Lists.GetProfileListValue(HttpContext, Context, Cache, defaultText, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetReceiptPayerList([DataSourceRequest] DataSourceRequest request, AccountType accountType, int accountId) {
            return Json(await Lists.GetReceiptPayerList(Context, accountType, accountId).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public async Task<JsonResult> GetSupplierList([DataSourceRequest] DataSourceRequest request, bool includeDefault, BspAgentType bspAgentType = BspAgentType.All, bool supplierServiceRateExistsOnly = false, int[] nonBspIds = null, int? id = null) {
            return Json(await Lists.GetSupplierList(Context, includeDefault, bspAgentType, supplierServiceRateExistsOnly, nonBspIds, id).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public async Task<JsonResult> GetSupplierListByCreditorId([DataSourceRequest] DataSourceRequest request, int creditorId, bool includeDefault) {
            return Json(await Lists.GetSupplierListByCreditorId(Context, creditorId, includeDefault).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public async Task<JsonResult> GetSupplierListByTripLineType([DataSourceRequest] DataSourceRequest request, TripLineType tripLineType, bool includeDefault, bool supplierServiceRateExistsOnly = false, int? id = null) {
            return Json(await Lists.GetSupplierListByTripLineType(Context, tripLineType, includeDefault, supplierServiceRateExistsOnly, id).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetSupplierListValue(int[] nonBspIds = null, int? id = null) {
            return Json(Lists.GetSupplierListValue(Context, nonBspIds, id));
        }

        [HttpPost]
        public JsonResult GetSupplierListByCreditorIdIndex(int creditorId, bool includeDefault, int? id = null) {
            return Json(Lists.GetSupplierListByCreditorIdIndex(Context, creditorId, includeDefault, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetTripLineAirPassengerTicketList([DataSourceRequest] DataSourceRequest request, int? id = null) {
            return Json(await Lists.GetTripLineAirPassengerTicketList(Context, id).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetTripLineAirPassengerTicketListValue(int? id = null) {
            return Json(Lists.GetTripLineAirPassengerTicketListValue(Context, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetTripList([DataSourceRequest] DataSourceRequest request, bool bookingsOnly, bool includeDefault, bool nullIsNew, bool landOnly = false, int? id = null) {
            return Json(await Lists.GetTripList(HttpContext, Context, Cache, bookingsOnly, includeDefault, nullIsNew, landOnly, id).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetTripListValue(bool nullIsNew, int? id = null) {
            return Json(Lists.GetTripListValue(HttpContext, Context, Cache, nullIsNew, id));
        }

        [HttpPost]
        public JsonResult GetTripListIndex(bool bookingsOnly, bool includeDefault, bool nullIsNew, int? id = null) {
            return Json(Lists.GetTripListIndex(HttpContext, Context, Cache, bookingsOnly, includeDefault, nullIsNew, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetTripListExt([DataSourceRequest] DataSourceRequest request, int consultantId, bool includeDefault, bool nullIsNew) {
            return Json(await Lists.GetTripListExt(HttpContext, Context, Cache, consultantId, includeDefault, nullIsNew).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetTripListExtValue(bool nullIsNew, int? id = null) {
            return Json(Lists.GetTripListExtValue(HttpContext, Context, Cache, nullIsNew, id));
        }

        [HttpPost]
        public async Task<JsonResult> GetTripListByDebtorId([DataSourceRequest] DataSourceRequest request, int debtorId, int subDebtorId, bool includeDefault, int? id = null) {
            return Json(await Lists.GetTripListByDebtorId(HttpContext, Context, Cache, debtorId, subDebtorId, includeDefault, id).ToDataSourceResultAsync(request));
        }

        [HttpPost]
        public JsonResult GetTripListByDebtorIdValue(int? id = null) {
            return Json(Lists.GetTripListByDebtorIdValue(HttpContext, Context, Cache, id));
        }
        #endregion
    }
}