﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Google.Authenticator;
using Kendo.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.Infrastructure;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Admin;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Enums;
using Travelog.WebApp.Admin;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.Controllers {
    [Authorize]
    public class AccountController : BaseController {
        private const string ClassName = "Travelog.WebApp.Controllers.AccountController";

        public AccountController(SignInManager<ApplicationUser> signInManager, UserManager<ApplicationUser> userManager, IWebHostEnvironment webHostEnvironment, IDistributedCache cache) : base(signInManager, userManager, webHostEnvironment, cache) {
        }

        #region User Access
        [AllowAnonymous]
        public async Task<IActionResult> SignIn(string message = null, MessageType messageType = MessageType.Info, int timeoutSeconds = 30) {
            if (!string.IsNullOrEmpty(message)) {
                try {
                    string[] credentials = WebUtility.UrlDecode(Cryptography.Decrypt(message)).Split(new string[] { "password=" }, StringSplitOptions.None);

                    var model = new SignInViewModel {
                        UserName = credentials[0],
                        Password = credentials[1]
                    };

                    await HttpContext.NewUserMessage(message);
                    return View(model);
                }
                catch {
                }
            }

            if (await HttpContext.SessionExpiryStatus() == SessionExpiryStatus.ExpiredNotNotified) {
                message = "Your session has expired due to inactivity.";
                messageType = MessageType.Info;
                timeoutSeconds = 0;
                await HttpContext.SessionExpiryStatus(SessionExpiryStatus.ExpiredNotified);
            }

            ViewBag.Message = message;
            ViewBag.MessageType = messageType;
            ViewBag.TimeoutSeconds = timeoutSeconds;
            ViewBag.PlaceholderId = "tl-notification-sign-in";

            return View(new SignInViewModel {
                UserName = HttpContext.PersistentUserName(),
                IsPersistent = HttpContext.IsPersistentSignIn()
            });
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SignIn_Submit(SignInViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var appUser = await UserManager.FindByNameAsync(model.UserName);
                bool result = await UserManager.CheckPasswordAsync(appUser, model.Password);

                if (result) {
                    await HttpContext.AuthenticationStartTime(DateTime.Now);
                    await Cache.RemoveUserAsync(User.Identity.Name);

                    AppUsersOnline.RemoveUser(appUser.Id);
                    HttpContext.Theme(appUser.Theme);

                    if (appUser.ForceSignOut) {
                        appUser.ForceSignOut = false;
                        await UserManager.UpdateAsync(appUser);
                    }

                    if (AppSettings.IsLocal)
                        return await PreProcessSignIn(model);

                    string token = null;
                    string body = null;
                    string message = null;

                    switch (model.TwoFactorAuthenticationMethod) {
                        case TwoFactorAuthenticationMethod.None:
                            return await PreProcessSignIn(model);
                        case TwoFactorAuthenticationMethod.GoogleAuthenticator:
                            if (appUser.IsTwoFactorEnabled) {
                                try {
                                    await HttpContext.GoogleAccountSecretKey(Cryptography.Decrypt(appUser.GoogleAccountSecretKey));
                                }
                                catch {
                                    model.TwoFactorAuthenticationMethod = TwoFactorAuthenticationMethod.EmailAuthenticator;
                                    message = "Google Authentication failed. Please try again with Email Authenticator.";
                                    token = await UserManager.GenerateTwoFactorTokenAsync(appUser, TokenOptions.DefaultProvider);
                                    body = string.Format("Your authentication code is {0}.{1}{1}Regards{1}Travelog Online Notifications", token, AppConstants.HtmlLineBreak);
                                    Mail.Instance.SendMail(appUser.Email, "Authentication Code", body);
                                }
                            }
                            else {
                                model.TwoFactorAuthenticationMethod = TwoFactorAuthenticationMethod.EmailAuthenticator;
                                message = "Google Authenticator is not activated. Please use Email Authenticator.";
                                token = await UserManager.GenerateTwoFactorTokenAsync(appUser, TokenOptions.DefaultProvider);
                                body = string.Format("Your authentication code is {0}.{1}{1}Regards{1}Travelog Online Notifications", token, AppConstants.HtmlLineBreak);
                                Mail.Instance.SendMail(appUser.Email, "Authentication Code", body);
                            }

                            break;
                        case TwoFactorAuthenticationMethod.EmailAuthenticator:
                            token = await UserManager.GenerateTwoFactorTokenAsync(appUser, TokenOptions.DefaultProvider);
                            body = string.Format("Your authentication code is {0}.{1}{1}Regards{1}Travelog Online Notifications", token, AppConstants.HtmlLineBreak);
                            Mail.Instance.SendMail(appUser.Email, "Authentication Code", body);
                            break;
                    }

                    return Json(new { UserId = appUser.Id, Message = message, model.TwoFactorAuthenticationMethod });
                }
                else {
                    if (appUser == null)
                        throw new UnreportedException("Invalid sign in attempt.");

                    await UserManager.AccessFailedAsync(appUser);

                    if (await UserManager.IsLockedOutAsync(appUser))
                        throw new UnreportedException(AppConstants.UserAccountLocked);

                    throw new UnreportedException("Invalid sign in attempt.");
                }
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SignIn_Submit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> SignIn_Authenticate(SignInViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                DateTime startTime = await HttpContext.AuthenticationStartTime();

                if (startTime.AddMinutes(20) < DateTime.Now)
                    throw new UnreportedException("Authentication timeout has expired. Please try again.");

                var appUser = await UserManager.FindByNameAsync(model.UserName);

                switch (model.TwoFactorAuthenticationMethod) {
                    default:
                        throw new InvalidOperationException("Invalid authentication method.");
                    case TwoFactorAuthenticationMethod.GoogleAuthenticator:
                        if (string.IsNullOrEmpty(model.AuthenticationCodeGoogle))
                            throw new UnreportedException("Please enter a valid code.");

                        var tfa = new TwoFactorAuthenticator();

                        if (!tfa.ValidateTwoFactorPIN(await HttpContext.GoogleAccountSecretKey(), model.AuthenticationCodeGoogle)) {
                            await UserManager.AccessFailedAsync(appUser);
                            await HttpContext.AuthenticationStartTime(DateTime.Now);
                            throw new UnreportedException("Invalid Code.");
                        }

                        break;
                    case TwoFactorAuthenticationMethod.EmailAuthenticator:
                        if (string.IsNullOrEmpty(model.AuthenticationCodeEmail))
                            throw new UnreportedException("Please enter a valid code.");

                        if (!await UserManager.VerifyTwoFactorTokenAsync(appUser, TokenOptions.DefaultProvider, model.AuthenticationCodeEmail)) {
                            await UserManager.AccessFailedAsync(appUser);
                            await HttpContext.AuthenticationStartTime(DateTime.Now);
                            throw new UnreportedException("Invalid Code.");
                        }

                        break;
                }

                model.CustomerCount = AdminContext.AspNetUserRoles.Count(t => t.UserId == model.UserId);
                return await PreProcessSignIn(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SignIn_Authenticate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> PreProcessSignIn(SignInViewModel model) {
            var result = await SignInManager.PasswordSignInAsync(model.UserName, model.Password, model.IsPersistent, true);

            if (result.IsLockedOut)
                throw new UnreportedException(AppConstants.UserAccountLocked);

            if (!result.Succeeded)
                throw new UnreportedException("Invalid sign in attempt.");

            return RedirectToAction("ProcessSignIn", "Account", new { model.UserName, model.CustomerCount, model.IsPersistent });
        }

        public async Task<IActionResult> ProcessSignIn(string userName, int customerCount, bool isPersistent) {
            try {
                if (HttpContext.Inactive())
                    throw new UnreportedException("Your account has been deactivated. Please contact your Company Administrator to have it reactivated.");

                var appUser = await UserManager.FindByNameAsync(userName);
                int userCount = CustomerSettings.Setting(HttpContext.CurrentCustomerId()).UserCount;

                if (!appUser.IsGlobalUser && userCount > 0 && AppUsersOnline.GetConcurrentUserCount(appUser.Id, appUser.CurrentCustomerId) >= userCount) {
                    bool userLimitReached = true;

                    foreach (var aspNetUserRole in AdminContext.AspNetUserRoles.Include(t => t.Customer).Where(t => t.UserId == appUser.Id && t.AspNetUsers.IsGlobalUser && t.CustomerId != appUser.CurrentCustomerId).ToList()) {
                        if (AppUsersOnline.GetConcurrentUserCount(appUser.Id, aspNetUserRole.CustomerId) < aspNetUserRole.Customer.UserCount) {
                            appUser.CurrentCustomerId = aspNetUserRole.CustomerId;
                            userLimitReached = false;
                            break;
                        }
                    }

                    if (userLimitReached) {
                        await SignInManager.SignOutAsync();
                        await HttpContext.SignOutAsync(Cache);
                        throw new UnreportedException("Concurrent user limit has been exceeded. You cannot sign in.");
                    }
                }

                appUser.SessionId = HttpContext.Session.Id;
                appUser.TimeZoneOffsetMinutes = Utils.TimeZoneOffsetMinutes();
                appUser.LastSignInTime = DateTime.UtcNow;
                appUser.ForceSignOut = false;

                await UserManager.UpdateAsync(appUser);

                await HttpContext.AuthenticationStartTime(DateTime.MinValue);
                await HttpContext.GoogleAccountSecretKey(string.Empty);
                await HttpContext.SessionExpiryStatus(SessionExpiryStatus.None);

                string url = null;

                if (string.IsNullOrEmpty(HttpContext.NavNext()) || HttpContext.NavNext().StartsWith("/ClientLedger/QuotesAndBookings", StringComparison.OrdinalIgnoreCase) || HttpContext.NavNext().StartsWith("/ClientLedger/Trip", StringComparison.OrdinalIgnoreCase)) {
                    url = AppSettings.HomePage;
                }
                else {
                    url = HttpContext.NavNext();
                }

                return Json(new { Url = url, CustomerCount = customerCount });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ProcessSignIn", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
            finally {
                if (isPersistent) {
                    HttpContext.PersistentUserName(userName);
                }
                else {
                    HttpContext.PersistentUserName(string.Empty);
                }
            }
        }

        [AllowAnonymous]
        public IActionResult RecoverPassword() {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RecoverPassword_Submit(RecoverPasswordViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var appUser = await UserManager.FindByEmailAsync(model.Email);
                string url = Url.Action("SignIn", "Account", new { message = "Please check your email to reset your password." });

                if (appUser == null || !await UserManager.IsEmailConfirmedAsync(appUser))
                    return Json(url);

                string token = await UserManager.GeneratePasswordResetTokenAsync(appUser);
                string messageUrl = Url.Action("ResetPassword", "Account", new { userId = appUser.Id, token }, Request.Scheme);
                string body = string.Format(AppConstants.MailBodyRecoverPassword, messageUrl);

                await Mail.Instance.SendMailAsync(appUser.Email, "Reset Password", body);
                return Json(url);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "RecoverPassword_Submit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [AllowAnonymous]
        public IActionResult ResetPassword(string token) {
            return token == null ? View("Error") : View(new ResetPasswordViewModel {
                Token = token
            });
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ResetPassword_Submit(ResetPasswordViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var appUser = await UserManager.FindByEmailAsync(model.Email);
                string url = Url.Action("SignIn", "Account", new { message = "Your password has been reset." });

                if (appUser == null)
                    return Json(url);

                var result = await UserManager.ResetPasswordAsync(appUser, model.Token, model.NewPassword);

                if (result.Succeeded)
                    return Json(url);

                AddModelStateErrors(result);
                throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ResetPassword_Submit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ChangePassword(string message = null, MessageType messageType = MessageType.Info, int timeoutSeconds = 30) {
            var model = new ChangePasswordViewModel();
            string newUserMessage = await HttpContext.NewUserMessage();

            if (!string.IsNullOrEmpty(newUserMessage)) {
                string[] credentials = WebUtility.UrlDecode(Cryptography.Decrypt(newUserMessage)).Split(new string[] { "password=" }, StringSplitOptions.None);
                model.OldPassword = credentials[1];
                await HttpContext.NewUserMessage(string.Empty);
            }

            ViewBag.Message = message;
            ViewBag.MessageType = messageType;
            ViewBag.TimeoutSeconds = timeoutSeconds;

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword_Submit(ChangePasswordViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                if (model.OldPassword == model.NewPassword)
                    throw new UnreportedException("Current Password cannot be the same as New Password.");

                var appUser = await UserManager.GetUserAsync(User);
                var result = await UserManager.ChangePasswordAsync(appUser, model.OldPassword, model.NewPassword);

                if (result.Succeeded) {
                    appUser.LastPasswordChangeDate = DateTime.UtcNow;
                    await UserManager.UpdateAsync(appUser);

                    AppUserClaimsPrincipalFactory.UpdateUser(appUser, User);
                    await SignInManager.RefreshSignInAsync(appUser);

                    string url = Url.Action(AppSettings.HomePage, "Home", new { message = "Your password has been changed.", messageType = MessageType.Success });
                    return Json(url);
                }

                AddModelStateErrors(result);
                throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChangePassword_Submit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GoogleAuthenticatorSetup() {
            try {
                var appUser = await UserManager.FindByNameAsync(User.Identity.Name);

                if (appUser.IsTwoFactorEnabled) {
                    return Json(new { QrCodeSetupImageUrl = string.Empty, ManualEntryKey = string.Empty });
                }
                else if (appUser.GoogleAccountSecretKey.Length == 0) {
                    string password = Cryptography.GeneratePassword(10);
                    appUser.GoogleAccountSecretKey = Cryptography.Encrypt(password);
                    await UserManager.UpdateAsync(appUser);
                }

                string secretKey = string.Empty;

                try {
                    secretKey = Cryptography.Decrypt(appUser.GoogleAccountSecretKey);
                }
                catch (CryptographicException ex) {
                    await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GoogleAuthenticatorSetup", ex);
                    return Json(new { QrCodeSetupImageUrl = string.Empty, ManualEntryKey = string.Empty });
                }

                var tfa = new TwoFactorAuthenticator();
                var setupInfo = tfa.GenerateSetupCode("Travelog Online", User.Identity.Name, secretKey, false);

                return Json(new { setupInfo.QrCodeSetupImageUrl, setupInfo.ManualEntryKey });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GoogleAuthenticatorSetup", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ChangePassword_ValidateQrCode(string authenticationCode) {
            try {
                var appUser = await UserManager.FindByNameAsync(User.Identity.Name);
                var tfa = new TwoFactorAuthenticator();
                string secretKey = Cryptography.Decrypt(appUser.GoogleAccountSecretKey);

                if (!tfa.ValidateTwoFactorPIN(secretKey, authenticationCode)) {
                    await UserManager.AccessFailedAsync(appUser);
                    throw new UnreportedException("Invalid Code.");
                }

                if (appUser.IsTwoFactorEnabled) {
                    string url = Url.Action("ChangePassword", "Account", new { message = "Your Google Authenticator account is already activated.", messageType = MessageType.Info });
                    return Json(url);
                }

                appUser.IsTwoFactorEnabled = true;
                var result = await UserManager.UpdateAsync(appUser);

                if (result.Succeeded) {
                    string url = Url.Action("ChangePassword", "Account", new { message = "Your Google Authenticator account has been activated.", messageType = MessageType.Success });
                    return Json(url);
                }

                return Json(new JavaScriptResult(WebUtils.GetMessageScript("Your Google Authenticator account has not been activated.", MessageType.Warning)));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChangePassword_ValidateQrCode", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword_ResetQrCode(string authenticationCode) {
            try {
                var appUser = await UserManager.FindByNameAsync(User.Identity.Name);
                var tfa = new TwoFactorAuthenticator();
                string secretKey = Cryptography.Decrypt(appUser.GoogleAccountSecretKey);

                if (!tfa.ValidateTwoFactorPIN(secretKey, authenticationCode)) {
                    await UserManager.AccessFailedAsync(appUser);
                    throw new UnreportedException("Invalid Code.");
                }

                appUser.GoogleAccountSecretKey = string.Empty;
                appUser.IsTwoFactorEnabled = false;

                var result = await UserManager.UpdateAsync(appUser);

                if (result.Succeeded) {
                    string url = Url.Action("ChangePassword", "Account", new { message = "Your Google Authenticator account has been deactivated.", messageType = MessageType.Success });
                    return Json(url);
                }

                return Json(new JavaScriptResult(WebUtils.GetMessageScript("Your Google Authenticator account has not been deactivated.", MessageType.Warning)));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ChangePassword_ResetQrCode", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> SignOut(string message = null, MessageType messageType = MessageType.Info, int timeoutSeconds = 30) {
            var appUser = await UserManager.FindByNameAsync(User.Identity.Name);

            if (appUser?.ForceSignOut == true) {
                appUser.ForceSignOut = false;
                await UserManager.UpdateAsync(appUser);
            }

            await SignInManager.SignOutAsync();
            await HttpContext.SignOutAsync(Cache);

            HttpContext.PersistentUserName(string.Empty);
            return RedirectToAction("SignIn", new { message, messageType, timeoutSeconds });
        }
        #endregion

        #region User Accounts
        public async Task<IActionResult> MyAccount(string message = null, MessageType messageType = MessageType.Info, int timeoutSeconds = 30) {
            var appUser = await UserManager.FindByNameAsync(User.Identity.Name);

            var model = new UserAccountViewModel {
                UserId = appUser.Id,
                UserName = appUser.UserName,
                FullName = appUser.FullName,
                Email = appUser.Email,
                Theme = appUser.Theme,
                FormValidationMethod = (FormValidationMethod)appUser.FormValidationMethodId,
                IsSuperUser = appUser.IsSuperUser,
                RoleId = UserRole.GetUserRole((AppUserRole)appUser.AppUserRoleId).Id,
                IsLocked = appUser.IsLocked(),
                LastWriteTime = appUser.LastWriteTime.ToLocalTime(),
                CreationTime = appUser.CreationTime.ToLocalTime(),
                LastWriteUser = appUser.LastWriteUser,
                CreationUser = appUser.CreationUser
            };

            ViewBag.Message = message;
            ViewBag.MessageType = messageType;
            ViewBag.TimeoutSeconds = timeoutSeconds;

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MyAccount_Submit(UserAccountViewModel model) {
            try {
                if (ModelState.IsValid) {
                    var appUser = await UserManager.FindByNameAsync(model.UserName);

                    if (model.IsSuperUser && !HttpContext.IsGlobalUser())
                        model.IsSuperUser = false;

                    if (appUser.FullName == model.FullName && appUser.Email == model.Email && appUser.Theme == model.Theme && appUser.FormValidationMethodId == (int)model.FormValidationMethod && appUser.IsSuperUser == model.IsSuperUser)
                        throw new UnreportedException("No changes were made. Account was not updated.");

                    bool isThemeChanged = appUser.Theme != model.Theme;

                    appUser.UserName = model.Email;
                    appUser.FullName = model.FullName;
                    appUser.Email = model.Email;
                    appUser.Theme = model.Theme;
                    appUser.FormValidationMethodId = (int)model.FormValidationMethod;
                    appUser.IsSuperUser = model.IsSuperUser;
                    appUser.LastWriteTime = DateTime.UtcNow;
                    appUser.LastWriteUser = User.Identity.Name;

                    var result = await UserManager.UpdateAsync(appUser);

                    if (result.Succeeded) {
                        AppUserClaimsPrincipalFactory.UpdateUser(appUser, User);
                        await SignInManager.RefreshSignInAsync(appUser);

                        if (isThemeChanged) {
                            HttpContext.Theme(appUser.Theme);
                            return Json(new EmptyResult());
                        }

                        return Json(new JavaScriptResult(WebUtils.GetMessageScript("Account was updated.", MessageType.Success)));
                    }

                    AddModelStateErrors(result);
                }

                throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MyAccount_Submit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MyAccount_UpdateDefaultAgency(int defaultAgencyId) {
            try {
                var adminContext = AdminContext;

                int customerId = HttpContext.CurrentCustomerId();
                var aspNetUserRole = adminContext.AspNetUserRoles.Include(t => t.AspNetUsers).SingleOrDefault(t => t.UserId == HttpContext.UserId() && t.CustomerId == customerId);

                if (aspNetUserRole == null) {
                    if (HttpContext.IsExternalUser()) {
                        aspNetUserRole = new AspNetUserRoles {
                            UserId = HttpContext.UserId(),
                            CustomerId = customerId,
                            RoleId = UserRole.ReadOnly.Id,
                            ConsultantId = -1,
                            DefaultAgencyId = defaultAgencyId
                        };

                        adminContext.Entry(aspNetUserRole).State = EntityState.Added;
                        adminContext.SaveChanges();

                        aspNetUserRole.AspNetUsers = AspNetUsersCommon.GetUser(HttpContext, adminContext);
                    }
                    else {
                        throw new UnreportedException("You are not authorised to connect to this agency.");
                    }
                }

                if (aspNetUserRole.DefaultAgencyId != defaultAgencyId) {
                    aspNetUserRole.DefaultAgencyId = defaultAgencyId;
                    adminContext.Save(aspNetUserRole, false);
                }

                if (aspNetUserRole.AspNetUsers.CurrentDefaultAgencyId != defaultAgencyId) {
                    aspNetUserRole.AspNetUsers.CurrentDefaultAgencyId = defaultAgencyId;
                    adminContext.Save(aspNetUserRole.AspNetUsers, false);
                }

                var appUser = await UserManager.FindByNameAsync(User.Identity.Name);
                appUser.CurrentDefaultAgencyId = defaultAgencyId;

                AppUserClaimsPrincipalFactory.UpdateUser(appUser, User);
                await SignInManager.RefreshSignInAsync(appUser);

                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MyAccount_UpdateDefaultAgency", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public IActionResult UserAccounts(string message = null, MessageType messageType = MessageType.Info, int timeoutSeconds = 30) {
            ViewBag.Message = message;
            ViewBag.MessageType = messageType;
            ViewBag.TimeoutSeconds = timeoutSeconds;
            return View("~/Views/Admin/UserAccounts.cshtml");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UserAccount_Edit(string userId, int customerId) {
            try {
                AspNetUsers q;
                bool isNew = string.IsNullOrEmpty(userId);

                if (isNew) {
                    q = new AspNetUsers();
                }
                else {
                    q = AdminContext.AspNetUsers.Include(t => t.AspNetUserRoles).Single(t => t.Id == userId);
                }

                var model = new UserAccountViewModel {
                    UserId = q.Id,
                    UserName = q.UserName,
                    Email = q.Email,
                    FullName = q.FullName,
                    RoleId = string.Empty,
                    ConsultantId = -1,
                    DefaultAgencyId = -1,
                    LastSignInTime = q.LastSignInTime == DateTime.MinValue ? null : q.LastSignInTime.ToLocalTime(),
                    OtherAgencies = q.OtherAgencies,
                    OtherConsultants = q.OtherConsultants,
                    IsSupportUser = q.IsSupportUser,
                    IsSuperUser = q.IsSuperUser,
                    IsGlobalUser = q.IsGlobalUser,
                    IsLocked = q.IsLocked,
                    ForceSignOut = q.ForceSignOut,
                    Inactive = false,
                    IsOnline = false,
                    IsTwoFactorEnabled = q.IsTwoFactorEnabled,
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser
                };

                if (!isNew) {
                    var role = q.GetRole(customerId);
                    model.RoleId = role.RoleId;
                    model.ConsultantId = role.ConsultantId;
                    model.DefaultAgencyId = role.DefaultAgencyId;
                    model.Inactive = role.Inactive;
                    model.IsOnline = AppUsersOnline.IsUserOnline(q.Id, q.CurrentCustomerId);
                }

                return PartialView("~/Views/Admin/EditorTemplates/UserAccountEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "UserAccount_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> UserAccount_Read([DataSourceRequest] DataSourceRequest request, int customerId) {
            AppMainContext context = null;
            bool disposeContext = false;

            try {
                var adminContext = AdminContext;

                if (customerId == HttpContext.CurrentCustomerId()) {
                    context = Context;
                }
                else {
                    context = new AppMainContext(User, customerId, HttpContext.IsExternalUser(), HttpContext.IsSuperUser());
                    disposeContext = true;
                }

                var q = from row in adminContext.AspNetUsers.Include(t => t.AspNetUserRoles).ThenInclude(t => t.Customer).Include(t => t.AspNetUserRoles).ThenInclude(t => t.AspNetRoles).Where(t1 => t1.AspNetUserRoles.Any(t2 => t2.CustomerId == customerId)).OrderBy(t => t.FullName).AsEnumerable()
                        let UserRole = row.AspNetUserRoles.SingleOrDefault(t => t.CustomerId == customerId) ?? new AspNetUserRoles { UserId = row.Id, CustomerId = customerId, RoleId = Guid.Empty.ToString(), ConsultantId = -1, DefaultAgencyId = -1, Inactive = true, AspNetRoles = new AspNetRoles { Id = Guid.Empty.ToString(), Name = "No Access" } }
                        let Consultant = context.Consultant.Find(UserRole.ConsultantId) ?? new Consultant { Id = -1, Name = string.Empty }
                        let DefaultAgency = context.Agency.Find(UserRole.DefaultAgencyId) ?? new Agency { Id = -1, Name = string.Empty }
                        where customerId <= (int)CustomerType.TravelogProd || !row.IsGlobalUser
                        select new UserAccountViewModel {
                            UserId = row.Id,
                            UserName = row.UserName,
                            Email = row.Email,
                            FullNameWithEmail = row.FullNameWithEmail,
                            Theme = row.Theme,
                            ConsultantId = Consultant.Id,
                            ConsultantName = Consultant.Id <= 0 ? string.Empty : Consultant.Name,
                            DefaultAgencyId = DefaultAgency.Id,
                            DefaultAgencyName = DefaultAgency.Id <= 0 ? string.Empty : DefaultAgency.Name,
                            LastSignInTime = row.LastSignInTime == DateTime.MinValue ? null : row.LastSignInTime.ToLocalTime(),
                            RoleId = UserRole.RoleId,
                            RoleName = UserRole.RoleId == Guid.Empty.ToString() ? string.Empty : UserRole.AspNetRoles.Name,
                            OtherAgencies = row.OtherAgencies,
                            OtherConsultants = row.OtherConsultants,
                            Inactive = UserRole.Inactive,
                            IsLocked = row.IsLocked,
                            IsSupportUser = row.IsSupportUser,
                            IsSuperUser = row.IsSuperUser,
                            ForceSignOut = row.ForceSignOut,
                            IsTwoFactorEnabled = row.IsTwoFactorEnabled,
                            IsOnline = AppUsersOnline.IsUserOnline(row.Id, customerId),
                            LastWriteTime = row.LastWriteTime.ToLocalTime(),
                            CreationTime = row.CreationTime.ToLocalTime(),
                            LastWriteUser = row.LastWriteUser,
                            CreationUser = row.CreationUser
                        };

                if (request.Sorts.Count > 0) {
                    switch (request.Sorts[0].Member) {
                        case "FullNameWithEmail":
                            if (request.Sorts[0].SortDirection == ListSortDirection.Ascending) {
                                q = q.OrderBy(t => t.FullNameWithEmail);
                            }
                            else {
                                q = q.OrderByDescending(t => t.FullNameWithEmail);
                            }

                            break;
                        case "RoleName":
                            if (request.Sorts[0].SortDirection == ListSortDirection.Ascending) {
                                q = q.OrderBy(t => t.RoleName);
                            }
                            else {
                                q = q.OrderByDescending(t => t.RoleName);
                            }

                            break;
                        case "ConsultantName":
                            if (request.Sorts[0].SortDirection == ListSortDirection.Ascending) {
                                q = q.OrderBy(t => t.ConsultantName);
                            }
                            else {
                                q = q.OrderByDescending(t => t.ConsultantName);
                            }

                            break;
                        case "LastSignInTime":
                            if (request.Sorts[0].SortDirection == ListSortDirection.Ascending) {
                                q = q.OrderBy(t => t.LastSignInTime);
                            }
                            else {
                                q = q.OrderByDescending(t => t.LastSignInTime);
                            }

                            break;
                    }
                }

                var result = await Task.Run(() => new DataSourceResult {
                    Data = q.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToList(),
                    Total = q.Count()
                });

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "UserAccount_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
            finally {
                if (disposeContext)
                    context.Dispose();
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UserAccount_CreateOrUpdate(UserAccountViewModel model, int customerId) {
            try {
                var identityResult = await AspNetUsersCommon.CreateOrUpdate(HttpContext, AdminContext, SignInManager, UserManager, model, customerId);

                if (identityResult?.Succeeded ?? true)
                    return Json(true);

                AddModelStateErrors(identityResult);

                if (ModelState.Any(t1 => t1.Value.ValidationState == ModelValidationState.Invalid && t1.Value.Errors.All(t1 => t1.ErrorMessage.EndsWith("is already taken."))))
                    throw new UnreportedException("Email is already taken.");

                throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "UserAccount_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UserAccount_Delete([DataSourceRequest] DataSourceRequest request, UserAccountViewModel model, int customerId) {
            try {
                if (HttpContext.IsExternalUser())
                    throw new UnreportedException(AppConstants.UnauthorisedAccessRemoteAssistanceUser);

                if (HttpContext.CurrentCustomerId() != customerId)
                    throw new UnreportedException(AppConstants.UnauthorisedAccessAnotherCustomer);

                AspNetUsersCommon.Delete(HttpContext, AdminContext, Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "UserAccount_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UserAccountRole_Edit() {
            try {
                return PartialView("~/Views/Admin/EditorTemplates/UserAccountRoleEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "UserAccountRole_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> UserAccountRole_Read([DataSourceRequest] DataSourceRequest request, string userId) {
            try {
                var q = AdminContext.AspNetUserRoles.Include(t => t.Customer).Include(t => t.AspNetRoles).Where(t => t.UserId == userId);

                var result = await q.OrderBy(t => t.Customer.BusinessName.Length == 0 ? t.Customer.LegalName : t.Customer.BusinessName).Select(row => new UserAccountRoleViewModel {
                    UserId = row.UserId,
                    CustomerId = row.CustomerId,
                    CustomerName = row.Customer.BusinessName.Length == 0 ? row.Customer.LegalName : row.Customer.BusinessName,
                    RoleId = row.RoleId,
                    RoleName = row.AspNetRoles.Name,
                    Inactive = row.Inactive
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "UserAccountRole_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> UserSupport_Read([DataSourceRequest] DataSourceRequest request, int customerId) {
            AppMainContext context = null;
            bool disposeContext = false;

            try {
                var adminContext = AdminContext;

                if (customerId == HttpContext.CurrentCustomerId()) {
                    context = Context;
                }
                else {
                    context = new AppMainContext(HttpContext.User, customerId, HttpContext.IsExternalUser(), HttpContext.IsSuperUser());
                    disposeContext = true;
                }

                var q = adminContext.AspNetUsers.Include(t => t.AspNetUserRoles).ThenInclude(t => t.Customer).Include(t => t.AspNetUserRoles).ThenInclude(t => t.AspNetRoles).Where(t => t.IsSupportUser);

                switch (AppSettings.DbConnectionMode) {
                    case DbConnectionMode.Production:
                        q = q.Where(t1 => t1.AspNetUserRoles.Any(t2 => t2.CustomerId >= (int)CustomerType.TravelogProd));
                        break;
                    case DbConnectionMode.Staging:
                        q = q.Where(t1 => t1.AspNetUserRoles.Any(t2 => t2.CustomerId <= (int)CustomerType.TravelogStaging && t2.CustomerId >= (int)CustomerType.TravelogStagingTest9));
                        break;
                    case DbConnectionMode.Development:
                        q = q.Where(t1 => t1.AspNetUserRoles.Any(t2 => t2.CustomerId <= (int)CustomerType.TravelogDev && t2.CustomerId >= (int)CustomerType.TravelogDevTest9));
                        break;
                }

                var result = from row in q.OrderBy(t => t.FullName).AsEnumerable()
                             let UserRole = row.AspNetUserRoles.SingleOrDefault(t => t.CustomerId == customerId && t.RoleId != UserRole.ReadOnly.Id) ?? new AspNetUserRoles { UserId = row.Id, CustomerId = customerId, RoleId = Guid.Empty.ToString(), ConsultantId = -1, DefaultAgencyId = -1, Inactive = true, AspNetRoles = new AspNetRoles { Id = Guid.Empty.ToString(), Name = "No Access" } }
                             let Consultant = context.Consultant.Find(UserRole.ConsultantId) ?? new Consultant { Id = -1, Name = string.Empty }
                             select new UserAccountViewModel {
                                 UserId = row.Id,
                                 FullNameWithEmail = row.FullNameWithEmail,
                                 ConsultantId = Consultant.Id,
                                 ConsultantName = Consultant.Id <= 0 ? string.Empty : Consultant.Name,
                                 RoleId = UserRole.RoleId,
                                 RoleName = UserRole.AspNetRoles.Name,
                                 LastSignInTime = row.LastSignInTime == DateTime.MinValue ? null : row.LastSignInTime.ToLocalTime(),
                                 LastWriteTime = row.LastWriteTime.ToLocalTime(),
                                 CreationTime = row.CreationTime.ToLocalTime(),
                                 LastWriteUser = row.LastWriteUser,
                                 CreationUser = row.CreationUser
                             };

                if (request.Sorts.Count > 0) {
                    switch (request.Sorts[0].Member) {
                        case "FullNameWithEmail":
                            if (request.Sorts[0].SortDirection == ListSortDirection.Ascending) {
                                result = result.OrderBy(t => t.FullNameWithEmail);
                            }
                            else {
                                result = result.OrderByDescending(t => t.FullNameWithEmail);
                            }

                            break;
                        case "RoleId":
                            if (request.Sorts[0].SortDirection == ListSortDirection.Ascending) {
                                result = result.OrderBy(t => t.RoleName);
                            }
                            else {
                                result = result.OrderByDescending(t => t.RoleName);
                            }

                            break;
                        case "ConsultantId":
                            if (request.Sorts[0].SortDirection == ListSortDirection.Ascending) {
                                result = result.OrderBy(t => t.ConsultantName);
                            }
                            else {
                                result = result.OrderByDescending(t => t.ConsultantName);
                            }

                            break;
                        case "LastSignInTime":
                            if (request.Sorts[0].SortDirection == ListSortDirection.Ascending) {
                                result = result.OrderBy(t => t.LastSignInTime);
                            }
                            else {
                                result = result.OrderByDescending(t => t.LastSignInTime);
                            }

                            break;
                    }
                }

                return Json(await Task.Run(() => new DataSourceResult {
                    Data = result.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize).ToList(),
                    Total = result.Count()
                }));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "UserSupport_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
            finally {
                if (disposeContext)
                    context.Dispose();
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UserSupport_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, UserAccountViewModel model, int customerId) {
            try {
                if (CustomerSettings.Setting(HttpContext.CurrentCustomerId()).IsManagementCustomer)
                    throw new UnreportedException(AppConstants.UnauthorisedAccessManagementCustomer);

                if (HttpContext.IsExternalUser())
                    throw new UnreportedException(AppConstants.UnauthorisedAccessRemoteAssistanceUser);

                if (HttpContext.CurrentCustomerId() != customerId)
                    throw new UnreportedException(AppConstants.UnauthorisedAccessAnotherCustomer);

                var adminContext = AdminContext;
                var q = adminContext.AspNetUserRoles.SingleOrDefault(t => t.UserId == model.UserId && t.CustomerId == customerId);

                bool isNew = q == null;

                if (model.RoleId == Guid.Empty.ToString()) {
                    if (!isNew)
                        adminContext.Delete(q);
                }
                else {
                    if (isNew) {
                        q = new AspNetUserRoles {
                            UserId = model.UserId,
                            CustomerId = customerId,
                            DefaultAgencyId = model.DefaultAgencyId
                        };
                    }

                    q.RoleId = model.RoleId;
                    q.ConsultantId = model.ConsultantId;

                    if (isNew) {
                        adminContext.Insert(q);
                    }
                    else {
                        adminContext.Save(q);
                    }
                }

                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "UserSupport_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Customer Account
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Customer_Select() {
            try {
                return PartialView("~/Views/Shared/EditorTemplates/CustomerSelect.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Customer_Select", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> Customer_Connect(int customerId, bool isExternalUser) {
            try {
                if (customerId == 0)
                    throw new UnreportedException("Invalid company.");

                var adminContext = AdminContext;

                var appUser = await UserManager.FindByNameAsync(User.Identity.Name);
                bool isAuthorised = true;

                if (!AppSettings.IsLocal) {
                    switch (AppSettings.DbConnectionMode) {
                        case DbConnectionMode.Production:
                            if (!(customerId >= (int)CustomerType.TravelogProd))
                                isAuthorised = false;

                            break;
                        case DbConnectionMode.Staging:
                            if (!(customerId <= (int)CustomerType.TravelogStaging && customerId >= (int)CustomerType.TravelogStagingTest9))
                                isAuthorised = false;

                            break;
                        case DbConnectionMode.Development:
                            if (!(customerId <= (int)CustomerType.TravelogDev && customerId >= (int)CustomerType.TravelogDevTest9))
                                isAuthorised = false;

                            break;
                    }
                }

                if (!isAuthorised)
                    throw new UnreportedException(AppConstants.UnauthorisedAccessCurrentUrl);

                if ((isExternalUser && !adminContext.Customer.Find(customerId).CanConnectAsExternalUser) || (!isExternalUser && !adminContext.AspNetUserRoles.Any(t => t.UserId == appUser.Id && t.CustomerId == customerId)))
                    throw new UnreportedException("You are not authorised to connect to this company.");

                if (!isExternalUser && !appUser.IsGlobalUser) {
                    int userCount = CustomerSettings.Setting(HttpContext.CurrentCustomerId()).UserCount;

                    if (userCount > 0 && AppUsersOnline.GetConcurrentUserCount(appUser.Id, customerId) >= userCount)
                        throw new UnreportedException("Concurrent user limit has been exceeded. You cannot connect.");
                }

                appUser.CurrentCustomerId = customerId;
                appUser.IsExternalUser = isExternalUser;

                await UserManager.UpdateAsync(appUser);
                AppUserClaimsPrincipalFactory.UpdateUser(appUser, User);

                await SignInManager.RefreshSignInAsync(appUser);
                await Cache.RemoveUserAsync(User.Identity.Name);

                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Customer_Connect", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public IActionResult CustomerAccount(string message = null, MessageType messageType = MessageType.Info, int timeoutSeconds = 30) {
            if (string.IsNullOrEmpty(message))
                CustomerCommon.ValidateStatus(HttpContext, ref message, ref messageType, ref timeoutSeconds);

            ViewBag.Message = message;
            ViewBag.MessageType = messageType;
            ViewBag.TimeoutSeconds = timeoutSeconds;

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerAccount_Edit(int customerId) {
            try {
                var adminContext = AdminContext;

                if (customerId == 0)
                    customerId = HttpContext.CurrentCustomerId();

                var q = adminContext.Customer.Find(customerId);
                var accountBalances = Customer.GetAccountBalances(adminContext, customerId);

                var model = new CustomerViewModel {
                    CustomerId = q.Id,
                    LegalName = q.LegalName,
                    BusinessName = q.BusinessName,
                    Location = q.Location,
                    TaxNo = q.TaxNo,
                    AgencyType = q.AgencyType,
                    CustomerContactType = q.CustomerContactType,
                    CustomerStatus = q.CustomerStatus,
                    SubscriptionChartOfAccountId = q.SubscriptionChartOfAccountId,
                    SabreEprChartOfAccountId = q.SabreEprChartOfAccountId,
                    ExcludeFromBilling = q.ExcludeFromBilling,
                    AllowRemoteAssistance = q.AllowRemoteAssistance,
                    Address1 = q.Address1,
                    Address2 = q.Address2,
                    Locality = q.Locality,
                    Region = q.Region,
                    PostCode = q.PostCode,
                    CountryCode = q.CountryCode,
                    BillingContactName = q.BillingContactName,
                    BillingContactPhone = q.BillingContactPhone,
                    BillingContactEmail = q.BillingContactEmail,
                    TechnicalContactName = q.TechnicalContactName,
                    TechnicalContactPhone = q.TechnicalContactPhone,
                    TechnicalContactEmail = q.TechnicalContactEmail,
                    StartDate = q.StartDate,
                    UserCount = q.UserCount,
                    SystemGenDocRequiresApproval = AdminSettings.SystemGenDocRequiresApproval(adminContext),
                    CurrentAccountBalance = accountBalances[CustomerAgingCycle.None],
                    OverdueAccountBalance = accountBalances[CustomerAgingCycle.Overdue],
                    PayableNowAccountBalance = accountBalances[CustomerAgingCycle.PayableNow],
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser
                };

                if (CustomerSettings.Setting(HttpContext.CurrentCustomerId()).IsManagementCustomer) {
                    ViewBag.CustomerAccountBillingLastRunTime = AdminSettings.GetBillingLastRunTimeFormatted(adminContext, q);
                }
                else {
                    ViewBag.CustomerAccountBillingLastRunTime = string.Empty;
                }

                return PartialView("~/Views/Account/EditorTemplates/CustomerAccountEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerAccount_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerAccount_Update(CustomerViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                bool result = CustomerCommon.Update(HttpContext, AdminContext, Context, model);
                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerAccount_Update", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerPaymentMethod_Edit(int customerPaymentMethodId, int customerPaymentMethodCustomerId) {
            try {
                CustomerPaymentMethod q = null;

                if (customerPaymentMethodId <= 0) {
                    q = new CustomerPaymentMethod {
                        Id = 0,
                        CustomerId = customerPaymentMethodCustomerId,
                        ExpiryDate = DateTime.MinValue,
                        IsActive = true
                    };
                }
                else {
                    q = AdminContext.CustomerPaymentMethod.Find(customerPaymentMethodId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);
                }

                var model = new CustomerPaymentMethodViewModel {
                    CustomerPaymentMethodId = q.Id,
                    CustomerPaymentMethodCustomerId = q.CustomerId,
                    CustomerPaymentMethodCardNo = q.CardNo,
                    CustomerPaymentMethodCardholderName = q.CardholderName,
                    CustomerPaymentMethodExpiryDate = q.ExpiryDate == DateTime.MinValue ? null : q.ExpiryDate,
                    CustomerPaymentMethodIsRecurringPayment = q.IsRecurringPayment,
                    CustomerPaymentMethodIsActive = q.IsActive,
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser
                };

                return PartialView("~/Views/Account/EditorTemplates/CustomerPaymentMethodEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerPaymentMethod_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> CustomerPaymentMethod_Read([DataSourceRequest] DataSourceRequest request, int customerId) {
            try {
                if (!HttpContext.IsGlobalUser() && !HttpContext.IsExternalUser())
                    customerId = HttpContext.CurrentCustomerId();

                var result = await AdminContext.CustomerPaymentMethod.Where(t => t.CustomerId == customerId).OrderByDescending(t => t.IsActive).Select(row => new CustomerPaymentMethodViewModel {
                    CustomerPaymentMethodId = row.Id,
                    CustomerPaymentMethodCustomerId = row.CustomerId,
                    CustomerPaymentMethodCardNo = row.CardNo,
                    CustomerPaymentMethodCardholderName = row.CardholderName,
                    CustomerPaymentMethodExpiryDate = row.ExpiryDate,
                    CustomerPaymentMethodIsActive = row.IsActive,
                    CustomerPaymentMethodIsRecurringPayment = row.IsRecurringPayment,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerPaymentMethod_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerPaymentMethod_CreateOrUpdate(CustomerPaymentMethodViewModel model, string encryptedCardNo, string encryptedCvn) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                CustomerPaymentMethodCommon.CreateOrUpdate(HttpContext, AdminContext, model, encryptedCardNo, encryptedCvn);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerPaymentMethod_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerPaymentMethod_Delete([DataSourceRequest] DataSourceRequest request, CustomerPaymentMethodViewModel model) {
            try {
                CustomerPaymentMethodCommon.Delete(HttpContext, AdminContext, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerPaymentMethod_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Pricing_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var result = await AdminContext.Pricing.OrderBy(t => t.UserCount).Select(row => new PricingViewModel {
                    PricingId = row.Id,
                    PricingUserCount = row.UserCount,
                    PricingUserCharge = row.UserCharge
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Pricing_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> CustomerPricing_Read([DataSourceRequest] DataSourceRequest request, int customerId) {
            try {
                if (!HttpContext.IsGlobalUser() && !HttpContext.IsExternalUser())
                    customerId = HttpContext.CurrentCustomerId();

                var result = await AdminContext.CustomerPricing.Where(t => t.CustomerId == customerId).OrderBy(t => t.DateFrom).ThenBy(t => t.DateFrom).Select(row => new CustomerPricingViewModel {
                    CustomerPricingId = row.Id,
                    CustomerPricingCustomerId = row.CustomerId,
                    CustomerPricingDateFrom = row.DateFrom,
                    CustomerPricingDateTo = row.DateTo == DateTime.MinValue ? null : row.DateTo,
                    CustomerPricingBillingCycle = row.BillingCycle,
                    CustomerPricingUserCount = row.UserCount,
                    CustomerPricingUserCharge = row.UserCharge,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerPricing_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerPricing_CreateOrUpdate(CustomerPricingViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                CustomerPricingCommon.CreateOrUpdate(HttpContext, AdminContext, model);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerPricing_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerPricing_Delete([DataSourceRequest] DataSourceRequest request, CustomerPricingViewModel model) {
            try {
                CustomerPricingCommon.Delete(HttpContext, AdminContext, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerPricing_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerTransaction_Edit(int customerId, int customerTransactionId) {
            try {
                var adminContext = AdminContext;
                var context = Context;

                CustomerTransaction q = null;

                if (customerTransactionId <= 0) {
                    q = new CustomerTransaction {
                        Id = 0,
                        CustomerId = customerId,
                        DateFrom = DateTime.Today,
                        DateTo = DateTime.Today,
                        IsUserCreated = true
                    };
                }
                else {
                    q = adminContext.CustomerTransaction.Find(customerTransactionId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);
                }

                var model = new CustomerTransactionViewModel {
                    CustomerTransactionId = q.Id,
                    CustomerTransactionCustomerId = q.CustomerId,
                    CustomerTransactionDebtorId = context.Debtor.SingleOrDefault(t => t.CustomerId == q.CustomerId)?.Id ?? 0,
                    CustomerTransactionReceiptId = q.IsReceiptItem ? context.Receipt.SingleOrDefault(t => t.DocumentNo == q.DocumentNo)?.Id ?? 0 : 0,
                    CustomerTransactionInvoiceId = q.IsInvoiceItem ? context.Invoice.SingleOrDefault(t => t.DocumentNo == q.DocumentNo)?.Id ?? 0 : 0,
                    CustomerTransactionType = q.CustomerTransactionType,
                    CustomerTransactionApprovalStatus = q.CustomerTransactionApprovalStatus,
                    CustomerTransactionDateFrom = q.DateFrom == DateTime.MinValue ? null : q.DateFrom,
                    CustomerTransactionDateTo = q.DateTo == DateTime.MinValue ? null : q.DateTo,
                    CustomerTransactionDateDue = q.DateDue == DateTime.MinValue ? null : q.DateDue,
                    CustomerTransactionUserCount = q.UserCount,
                    CustomerTransactionUserCharge = q.UserCharge,
                    CustomerTransactionAmountGross = q.Amount + q.Tax,
                    CustomerTransactionTax = q.Tax,
                    CustomerTransactionDescription = q.Description,
                    CustomerTransactionDocumentNo = q.DocumentNo,
                    PaymentTransactionId = q.PaymentTransactionId,
                    IsReceiptItem = q.IsReceiptItem,
                    IsInvoiceItem = q.IsInvoiceItem,
                    IsUserCreated = q.IsUserCreated,
                    LastWriteTime = q.LastWriteTime.ToLocalTime(),
                    CreationTime = q.CreationTime.ToLocalTime(),
                    LastWriteUser = q.LastWriteUser,
                    CreationUser = q.CreationUser
                };

                return PartialView("~/Views/Account/EditorTemplates/CustomerTransactionEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerTransaction_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> CustomerTransaction_Read([DataSourceRequest] DataSourceRequest request, int customerId, string transactionNo, CustomerTransactionType? transactionType, CustomerTransactionStatus? transactionStatus, DateTime? dateFrom, DateTime? dateTo, DateTime? dateDue, string text, bool isExport, string sortMember = null, string sortDirection = null) {
            try {
                var adminContext = AdminContext;
                var context = Context;

                if (!HttpContext.IsGlobalUser() && !HttpContext.IsExternalUser())
                    customerId = HttpContext.CurrentCustomerId();

                var q = adminContext.CustomerTransactionView.Where(t => t.CustomerId == customerId);

                if (!HttpContext.IsGlobalUser())
                    q = q.Where(t => t.CustomerTransactionApprovalStatus != CustomerTransactionApprovalStatus.NotApproved);

                if (!string.IsNullOrEmpty(transactionNo)) {
                    int.TryParse(transactionNo, out int id);
                    q = q.Where(t => t.Id == id);
                }

                if (transactionType != null)
                    q = q.Where(t => t.CustomerTransactionType == transactionType);

                if (transactionStatus != null)
                    q = q.Where(t => t.CustomerTransactionStatus == transactionStatus);

                if (dateFrom != null)
                    q = q.Where(t => t.DateFrom >= dateFrom);

                if (dateTo != null)
                    q = q.Where(t => t.DateTo <= dateTo);

                if (dateDue != null)
                    q = q.Where(t => t.DateDue == dateDue);

                if (!string.IsNullOrEmpty(text)) {
                    text = text.Trim().ToLower();
                    q = q.Where(t => t.Description.ToLower().Contains(text));
                }

                q = q.OrderByDescending(t => t.Id);

                if (isExport) {
                    if (!HttpContext.IsAdministrator())
                        throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

                    var export = q.ApplySorting(null, WebUtils.GetSortDescriptors(sortMember, sortDirection)).AsEnumerable().Select(row => new CustomerTransactionExportModel {
                        TransactionType = row.CustomerTransactionType.GetEnumDescription(),
                        Status = row.CustomerTransactionStatus.GetEnumDescription(),
                        DateFrom = row.DateFrom,
                        DateTo = row.DateTo,
                        DateDue = row.DateDue == DateTime.MinValue ? null : row.DateDue,
                        UserCount = row.UserCount,
                        UserCharge = row.UserCharge,
                        Debit = row.Debit,
                        Credit = row.Credit,
                        Balance = row.Balance,
                        DocumentNo = row.DocumentNo,
                        IsUserCreated = row.IsUserCreated ? "Yes" : "No"
                    }).ToList();

                    var xlsx = new ExportToExcel<CustomerTransactionExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Account Transactions.xlsx");
                }

                var result = await q.AsEnumerable().Select(row => new CustomerTransactionViewModel {
                    CustomerTransactionId = row.Id,
                    CustomerTransactionCustomerId = row.CustomerId,
                    CustomerTransactionType = row.CustomerTransactionType,
                    CustomerTransactionStatus = row.CustomerTransactionStatus,
                    CustomerTransactionApprovalStatus = row.CustomerTransactionApprovalStatus,
                    CustomerTransactionDateFrom = row.DateFrom == DateTime.MinValue ? null : row.DateFrom,
                    CustomerTransactionDateTo = row.DateTo == DateTime.MinValue ? null : row.DateTo,
                    CustomerTransactionDateDue = row.DateDue == DateTime.MinValue ? null : row.DateDue,
                    CustomerTransactionUserCount = row.UserCount,
                    CustomerTransactionUserCharge = row.UserCharge,
                    IsDebit = row.IsDebit,
                    Debit = row.IsDebit ? row.Debit : null,
                    Credit = row.IsDebit ? null : row.Credit,
                    Balance = row.Balance,
                    CustomerTransactionDocumentNo = row.DocumentNo.Length == 0 ? string.Empty : string.Concat(@"<a href=""/Account/CustomerTransaction_DownloadDocument/?customerId=", customerId, "&documentNo=", row.DocumentNo, "&documentType=", row.IsReceiptItem ? "Receipt" : "Invoice", @""">", row.DocumentNo, "</a>"),
                    IsUserCreated = row.IsUserCreated,
                    CustomerTransactionDescription = row.Description,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                decimal totalDebit = q.Sum(t => (decimal?)t.Debit) ?? 0;
                decimal totalCredit = q.Sum(t => (decimal?)t.Credit) ?? 0;

                var accountBalances = Customer.GetAccountBalances(adminContext, customerId);

                result.AggregateResults = new List<AggregateResult> {
                    new AggregateResult(totalDebit, new SumFunction { FunctionName = "Sum", SourceField = "Debit", MemberType = typeof(decimal) }),
                    new AggregateResult(totalCredit, new SumFunction { FunctionName = "Sum", SourceField = "Credit", MemberType = typeof(decimal) }),
                    new AggregateResult(totalDebit + totalCredit, new SumFunction { FunctionName = "Sum", SourceField = "Balance", MemberType = typeof(decimal) }),
                    new AggregateResult(CustomerSettings.Setting(HttpContext.CurrentCustomerId()).UserCount, new MinFunction { FunctionName = "Min", SourceField = "CustomerTransactionUserCount", MemberType = typeof(int) }),
                    new AggregateResult(accountBalances[CustomerAgingCycle.None], new MinFunction { FunctionName = "Min", SourceField = "CurrentAccountBalance", MemberType = typeof(decimal) }),
                    new AggregateResult(accountBalances[CustomerAgingCycle.Overdue], new MinFunction { FunctionName = "Min", SourceField = "OverdueAccountBalance", MemberType = typeof(decimal) }),
                    new AggregateResult(accountBalances[CustomerAgingCycle.PayableNow], new MinFunction { FunctionName = "Min", SourceField = "PayableNowAccountBalance", MemberType = typeof(decimal) }),
                    new AggregateResult(Customer.GetCustomerAccountStatus(accountBalances[CustomerAgingCycle.Overdue], accountBalances[CustomerAgingCycle.PayableNow]).GetEnumDescription(), new MinFunction { FunctionName = "Min", SourceField = "CustomerAccountStatusDescription", MemberType = typeof(string) }),
                    new AggregateResult(HttpContext.IsSuperUser(), new MinFunction { FunctionName = "Min", SourceField = "IsSuperUser", MemberType = typeof(bool) })
                };

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerTransaction_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerTransaction_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, CustomerTransactionViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                model.IsUserCreated = true;
                CustomerTransactionCommon.CreateOrUpdate(HttpContext, AdminContext, Context, model, CustomerTxnSource.UserUpdated);

                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerTransaction_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerTransaction_Delete([DataSourceRequest] DataSourceRequest request, CustomerTransactionViewModel model) {
            try {
                CustomerTransactionCommon.Delete(HttpContext, AdminContext, Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerTransaction_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerTransaction_Approve([DataSourceRequest] DataSourceRequest request, int customerTransactionId, bool isApproved) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                CustomerTransactionCommon.Approve(HttpContext, AdminContext, customerTransactionId, isApproved);
				return Json(await new[] { true }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerTransaction_Approve", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerTransaction_UpdateModel(CustomerTransactionViewModel model, string source) {
            try {
                var context = Context;
                decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), model.CustomerTransactionDateFrom ?? DateTime.UtcNow.Date);

                switch (source) {
                    case "CustomerTransactionType":
                        var q = new CustomerTransaction {
                            CustomerTransactionType = model.CustomerTransactionType
                        };

                        model.IsReceiptItem = q.IsReceiptItem;
                        model.IsInvoiceItem = q.IsInvoiceItem;

                        if (model.IsReceiptItem) {
                            var receipt = context.Receipt.Include(t => t.ReceiptDetails).SingleOrDefault(t => t.Id == model.CustomerTransactionReceiptId);

                            if (receipt != null) {
                                model.CustomerTransactionDateFrom = receipt.DocumentDate;
                                model.CustomerTransactionDateTo = receipt.DocumentDate;
                                model.CustomerTransactionDateDue = receipt.DocumentDate;

                                model.CustomerTransactionAmountGross = receipt.GetTotalAmountGross();
                                model.CustomerTransactionTax = receipt.GetTotalTax();
                            }
                        }
                        else if (model.IsInvoiceItem) {
                            var invoice = context.Invoice.Include(t => t.InvoiceDetails).SingleOrDefault(t => t.Id == model.CustomerTransactionInvoiceId);

                            if (invoice != null) {
                                model.CustomerTransactionDateFrom = invoice.DocumentDate;
                                model.CustomerTransactionDateTo = invoice.DocumentDate;
                                model.CustomerTransactionDateDue = invoice.BalanceDueDate;

                                model.CustomerTransactionAmountGross = invoice.TotalAmount;
                                model.CustomerTransactionTax = invoice.TotalTax;
                            }
                        }

                        break;
                    case "UserCount":
                    case "UserCharge":
                        decimal amountGross = Math.Round(model.CustomerTransactionUserCount * model.CustomerTransactionUserCharge, 2);

                        if (amountGross == 0)
                            break;

                        model.CustomerTransactionAmountGross = amountGross;
                        model.CustomerTransactionTax = Math.Round(amountGross * taxRate / (1 + taxRate), 2);
                        break;
                    case "Amount":
                        model.CustomerTransactionTax = Math.Round(model.CustomerTransactionAmountGross * taxRate / (1 + taxRate), 2);
                        break;
                }

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerTransaction_UpdateModel", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> CustomerTransaction_DownloadDocument(int customerId, string documentNo, string documentType) {
            try {
                var q = AdminContext.CustomerTransaction.Where(t => t.CustomerId == customerId && t.DocumentNo == documentNo && t.Document != null).AsEnumerable().FirstOrDefault(t => t.IsReceiptItem == (documentType == "Receipt"));

                if (q == null)
                    return Redirect("/Shared/ResourceNotFound");

                return File(q.Document.ToArray(), "application/pdf", string.Format("{0} No {1}.pdf", documentType, q.DocumentNo));
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerTransaction_DownloadDocument", ex);
                return Redirect("/Shared/Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CustomerTransaction_ExecuteBillingRun(int managementCustomerId) {
            try {
                if (!CustomerSettings.Setting(HttpContext.CurrentCustomerId()).IsManagementCustomer || (HttpContext.AppUserRole() != AppUserRole.SystemAdministrator && HttpContext.AppUserRole() != AppUserRole.CompanyAdministrator))
                    throw new UnreportedException("You are not authorised to execute a billing run.");

                new Billing(HttpContext, false).ExecuteBillingRun(User, WebHostEnvironment.ContentRootPath, managementCustomerId);

                var adminContext = AdminContext;

                int customerId = HttpContext.CurrentCustomerId();
                var customer = adminContext.Customer.Include(t => t.CustomerTransactions).Single(t => t.Id == customerId);

                CustomerCommon.InitSettings(adminContext, customer, true);
                return Json(new { BillingLastRunTime = string.Format("Last Run: {0} ", AdminSettings.GetBillingLastRunTimeFormatted(AdminContext, customer)) });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CustomerTransaction_ExecuteBillingRun", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Menu
        public IActionResult UserRoles(string message = null, MessageType messageType = MessageType.Info, int timeoutSeconds = 30) {
            ViewBag.Message = message;
            ViewBag.MessageType = messageType;
            ViewBag.TimeoutSeconds = timeoutSeconds;
            return View("~/Views/Admin/UserRoles.cshtml");
        }

        public async Task<IActionResult> MenuBaseRole_Read([DataSourceRequest] DataSourceRequest request, string roleId) {
            try {
                int customerId = HttpContext.CurrentCustomerId();
                var q = AdminContext.MenuBaseRole.Where(t => t.CustomerId == customerId && t.RoleId == roleId).OrderBy(t => t.MenuBaseId);

                var result = await q.Select(row => new MenuRoleViewModel {
                    MenuBaseRoleId = row.Id,
                    ParentId = row.MenuBase.Id,
                    Item = row.MenuBase.Item,
                    NavigateUrl = row.MenuBase.NavigateUrl,
                    DefaultAccessLevel = row.MenuBase.MenuBaseRoleDefaults.Single(t => t.MenuBaseId == row.MenuBaseId && t.RoleId == row.RoleId).DefaultAccessLevel,
                    AccessLevel = row.AccessLevel
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MenuBaseRole_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MenuBaseRole_Update([DataSourceRequest] DataSourceRequest request, MenuRoleViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                HttpContext.UpdateMenuBaseRole(AdminContext, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MenuBaseRole_Update", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MenuBaseRole_ResetAccessLevels(string roleId) {
            try {
                HttpContext.ResetMenuAccessLevels(AdminContext, roleId);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MenuBaseRole_ResetAccessLevels", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> MenuNodeState_Update(int menuBaseId, bool isExpanded) {
            var menuItem = (await HttpContext.MenuList(Cache)).SingleOrDefault(t => t.MenuBaseId == menuBaseId);

            if (menuItem == null)
                return Json(false);

            menuItem.IsExpanded = isExpanded;
            return Json(true);
        }
        #endregion

        #region Audit Log
        public IActionResult AuditLog() {
            return View("~/Views/Admin/AuditLog.cshtml");
        }

        public async Task<IActionResult> AuditLog_Read([DataSourceRequest] DataSourceRequest request, string entityState, DateTime? dateFrom, DateTime? dateTo, string modifiedBy, string originalValues, string currentValues, string text, bool isArchive, bool isExport) {
            try {
                var adminContext = isArchive ? ArchiveContext : AdminContext;

                int customerId = HttpContext.CurrentCustomerId();
                var q = adminContext.AuditLog.Where(t => t.CustomerId == customerId);

                if (!string.IsNullOrEmpty(entityState))
                    q = q.Where(t => t.Type == entityState);

                if (dateFrom != null)
                    q = q.Where(t => t.CreationTime >= (dateFrom ?? DateTime.MinValue).Date);

                if (dateTo != null)
                    q = q.Where(t => t.CreationTime <= (dateTo ?? DateTime.MinValue).Date.AddDays(1).AddTicks(-1));

                if (!string.IsNullOrEmpty(modifiedBy))
                    q = q.Where(t => t.CreationUser.ToLower().Contains(modifiedBy.ToLower()));

                if (!string.IsNullOrEmpty(originalValues))
                    q = q.Where(t => t.OriginalValues.ToLower().Contains(originalValues.ToLower()));

                if (!string.IsNullOrEmpty(currentValues))
                    q = q.Where(t => t.CurrentValues.ToLower().Contains(currentValues.ToLower()));

                if (!string.IsNullOrEmpty(text))
                    q = q.Where(t => t.Entity.ToLower().Contains(text.ToLower()));

                if (isExport) {
                    if (!HttpContext.IsAdministrator())
                        throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

                    var export = q.OrderByDescending(t => t.Id).Select(row => new AuditLogExportModel {
                        Entity = row.Entity,
                        Type = row.Type,
                        OriginalValues = row.OriginalValues.Replace(AppConstants.HtmlLineBreak, Environment.NewLine),
                        CurrentValues = row.CurrentValues.Replace(AppConstants.HtmlLineBreak, Environment.NewLine),
                        ModifiedDate = row.CreationTime.ToLocalTime(),
                        ModifiedBy = row.CreationUser
                    }).ToList();

                    var xlsx = new ExportToExcel<AuditLogExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Audit Log.xlsx");
                }

                var result = await q.OrderByDescending(t => t.Id).Select(row => new AuditLogViewModel {
                    AuditLogId = row.Id,
                    Entity = row.Entity,
                    Type = row.Type,
                    SuperUser = row.SuperUser,
                    CreationTime = row.CreationTime.ToLocalTime(),
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AuditLog_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        public async Task<IActionResult> AuditLogDetail_Read([DataSourceRequest] DataSourceRequest request, int auditLogId) {
            try {
                var q = AdminContext.AuditLog.Where(t => t.Id == auditLogId);

                var result = await q.Select(row => new AuditLogViewModel {
                    AuditLogDetailId = row.Id,
                    OriginalValues = row.OriginalValues,
                    CurrentValues = row.CurrentValues
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AuditLogDetail_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AuditLog_Archive() {
            try {
                await Biz.Dao.AuditLog.ArchiveAuditLog(true);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AuditLog_Archive", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Service Desk
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RequestSupport_Edit() {
            try {
                var model = new RequestSupportViewModel {
                    RequestSupportIssueSummary = string.Empty,
                    RequestSupportIssueDescription = string.Empty,
                    RequestSupportIncludeScreenshot = true
                };

                return PartialView("~/Views/Account/EditorTemplates/RequestSupportEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "RequestSupport_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RequestSupport_Submit(string summary, string description, bool includeScreenshot, IEnumerable<IFormFile> files = null) {
            bool isError = false;

            try {
                if (string.IsNullOrEmpty(summary))
                    throw new UnreportedException("Summary is required.");

                if (string.IsNullOrEmpty(description))
                    throw new UnreportedException("Description is required.");

                string imageContent = string.Empty;

                if (includeScreenshot)
                    imageContent = await HttpContext.ImageContent();

                string issueKey = await new ServiceDesk().CreateJiraRequest(HttpContext.UserFullName(), User.Identity.Name, summary, description, imageContent, files);

                if (string.IsNullOrEmpty(issueKey))
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript("Support request failed.", MessageType.Warning, 30)));

                return Json(issueKey);
            }
            catch (Exception ex) {
                isError = true;
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "RequestSupport_Submit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
            finally {
                if (!isError)
                    await HttpContext.ImageContent(string.Empty);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ServiceDesk_DeleteAccount(string email) {
            try {
                var serviceDesk = new ServiceDesk();
                await serviceDesk.DeleteJiraCustomerAccount(email);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ServiceDesk_DeleteAccount", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RequestSupport_CaptureScreenShot(string imageContent) {
            try {
                imageContent = imageContent.Replace("data:image/octet-stream;base64,", string.Empty);
                await HttpContext.ImageContent(imageContent);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "RequestSupport_CaptureScreenShot", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Helpers
        private void AddModelStateErrors(IdentityResult result) {
            foreach (var error in result.Errors) {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }
        #endregion

        protected override void Dispose(bool disposing) {
            if (disposing) {
                if (UserManager != null) {
                    UserManager.Dispose();
                    UserManager = null;
                }

                if (SignInManager != null)
                    SignInManager = null;
            }

            base.Dispose(disposing);
        }
    }
}