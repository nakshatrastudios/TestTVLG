using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Admin;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Resources;
using Travelog.Gds;
using Travelog.WebApp.Admin;
using Travelog.WebApp.Common;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.Controllers {
    [Authorize]
    public class CommonController : BaseController {
        private const string ClassName = "Travelog.WebApp.Controllers.CommonController";

        public CommonController(SignInManager<ApplicationUser> signInManager, UserManager<ApplicationUser> userManager, IWebHostEnvironment webHostEnvironment, IDistributedCache cache) : base(signInManager, userManager, webHostEnvironment, cache) {
        }

        #region Adjustment Types
        public IActionResult AdjustmentTypes() {
            return View();
        }

        public async Task<IActionResult> AdjustmentType_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.AdjustmentType.Include(t => t.DebitTrip).Include(t => t.DebitDebtor).Include(t => t.DebitCreditor).Include(t => t.DebitChartOfAccount).Include(t => t.CreditTrip).Include(t => t.CreditDebtor).Include(t => t.CreditCreditor).Include(t => t.CreditChartOfAccount).Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.AsEnumerable().Select(row => new AdjustmentTypeViewModel {
                    AdjustmentTypeId = row.Id,
                    Name = row.Name,
                    Description = row.Description,
                    DebitType = row.DebitType,
                    DebitAccountName = row.DebitAccountName,
                    IsDebitAccountUnlocked = row.IsDebitAccountUnlocked,
                    DebitDisableTypesNotSelected = row.DebitDisableTypesNotSelected,
                    DebitTripId = row.DebitTripId,
                    DebitDebtorId = row.DebitDebtorId,
                    DebitChartOfAccountId = row.DebitChartOfAccountId,
                    DebitCreditorId = row.DebitCreditorId,
                    CreditType = row.CreditType,
                    CreditAccountName = row.CreditAccountName,
                    IsCreditAccountUnlocked = row.IsCreditAccountUnlocked,
                    CreditDisableTypesNotSelected = row.CreditDisableTypesNotSelected,
                    CreditTripId = row.CreditTripId,
                    CreditDebtorId = row.CreditDebtorId,
                    CreditChartOfAccountId = row.CreditChartOfAccountId,
                    CreditCreditorId = row.CreditCreditorId,
                    AdjustmentTransactionType = row.AdjustmentTransactionType,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AdjustmentType_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AdjustmentType_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AdjustmentTypeViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;

                switch (model.DebitType) {
                    case DebitCreditType.Client:
                        model.DebitDebtorId = -1;
                        model.DebitChartOfAccountId = -1;
                        model.DebitCreditorId = -1;
                        break;
                    case DebitCreditType.Debtor:
                        model.DebitTripId = -1;
                        model.DebitChartOfAccountId = -1;
                        model.DebitCreditorId = -1;
                        break;
                    case DebitCreditType.Creditor:
                        model.DebitTripId = -1;
                        model.DebitDebtorId = -1;
                        model.DebitChartOfAccountId = -1;
                        break;
                    case DebitCreditType.GeneralLedger:
                        model.DebitTripId = -1;
                        model.DebitDebtorId = -1;
                        model.DebitCreditorId = -1;
                        break;
                }

                switch (model.CreditType) {
                    case DebitCreditType.Client:
                        model.CreditDebtorId = -1;
                        model.CreditChartOfAccountId = -1;
                        model.CreditCreditorId = -1;
                        break;
                    case DebitCreditType.Debtor:
                        model.CreditTripId = -1;
                        model.CreditChartOfAccountId = -1;
                        model.CreditCreditorId = -1;
                        break;
                    case DebitCreditType.Creditor:
                        model.CreditTripId = -1;
                        model.CreditDebtorId = -1;
                        model.CreditChartOfAccountId = -1;
                        break;
                    case DebitCreditType.GeneralLedger:
                        model.CreditTripId = -1;
                        model.CreditDebtorId = -1;
                        model.CreditCreditorId = -1;
                        break;
                }

                AdjustmentType q = null;

                if (model.AdjustmentTypeId <= 0) {
                    q = new AdjustmentType();
                }
                else {
                    q = context.AdjustmentType.Find(model.AdjustmentTypeId);
                }

                if ((model.DebitChartOfAccountId != q.DebitChartOfAccountId && !ChartOfAccount.IsInRole(context, model.DebitChartOfAccountId ?? 0, HttpContext.RoleId())) || (model.CreditChartOfAccountId != q.CreditChartOfAccountId && !ChartOfAccount.IsInRole(context, model.CreditChartOfAccountId ?? 0, HttpContext.RoleId())))
                    throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                q.Name = model.Name;
                q.Description = model.Description;
                q.DebitType = model.DebitType;
                q.IsDebitAccountUnlocked = model.IsDebitAccountUnlocked;
                q.DebitDisableTypesNotSelected = model.DebitDisableTypesNotSelected;
                q.DebitTripId = model.DebitTripId ?? 0;
                q.DebitDebtorId = model.DebitDebtorId ?? 0;
                q.DebitChartOfAccountId = model.DebitChartOfAccountId ?? 0;
                q.DebitCreditorId = model.DebitCreditorId ?? 0;
                q.CreditType = model.CreditType;
                q.IsCreditAccountUnlocked = model.IsCreditAccountUnlocked;
                q.CreditDisableTypesNotSelected = model.CreditDisableTypesNotSelected;
                q.CreditTripId = model.CreditTripId ?? 0;
                q.CreditDebtorId = model.CreditDebtorId ?? 0;
                q.CreditChartOfAccountId = model.CreditChartOfAccountId ?? 0;
                q.CreditCreditorId = model.CreditCreditorId ?? 0;
                q.AdjustmentTransactionType = model.AdjustmentTransactionType;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.AdjustmentTypeId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AdjustmentType_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AdjustmentType_Delete([DataSourceRequest] DataSourceRequest request, AdjustmentTypeViewModel model) {
            try {
                var context = Context;
                var q = context.AdjustmentType.Find(model.AdjustmentTypeId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AdjustmentType_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> AdjustmentType_ExportExcel() {
            try {
                var q = Context.AdjustmentType.Include(t => t.DebitTrip).Include(t => t.DebitDebtor).Include(t => t.DebitCreditor).Include(t => t.DebitChartOfAccount).Include(t => t.CreditTrip).Include(t => t.CreditDebtor).Include(t => t.CreditCreditor).Include(t => t.CreditChartOfAccount).AsEnumerable().Where(t => t.Id > 0).OrderBy(t => t.Name).Select(row => new AdjustmentTypeExportModel {
                    AdjustmentType = row.Name,
                    Explanation = row.Description,
                    IsDebitAccountUnlocked = row.IsDebitAccountUnlocked,
                    DebitDisableTypesNotSelected = row.DebitDisableTypesNotSelected,
                    DebitAccountNameLink = row.DebitAccountName,
                    IsCreditAccountUnlocked = row.IsCreditAccountUnlocked,
                    CreditDisableTypesNotSelected = row.CreditDisableTypesNotSelected,
                    CreditAccountNameLink = row.CreditAccountName,
                    AdjustmentTransactionType = row.AdjustmentTransactionType.GetEnumDescription()
                }).ToList();

                var xlsx = new ExportToExcel<AdjustmentTypeExportModel>(q);
                return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Adjustment Types.xlsx");
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AdjustmentType_ExportExcel", ex);
                return Redirect("/Shared/Error");
            }
        }
        #endregion

        #region Agencies
        public IActionResult Agencies() {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Agency_Edit(int agencyId) {
            try {
                Agency q = null;

                if (agencyId <= 0) {
                    q = new Agency {
                        Id = 0,
                        TravelBankAccount = new BankAccount(),
                        AdminBankAccount = new BankAccount(),
                        AccentColor = AppConstants.DefaultAccentColor,
                        HighlightColor = AppConstants.DefaultHighlightColor
                    };
                }
                else {
                    q = Context.Agency.Include(t => t.TravelBankAccount).Include(t => t.AdminBankAccount).Single(t => t.Id == agencyId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);
                }

                var model = new AgencyViewModel {
                    AgencyId = q.Id,
                    Name = q.Name,
                    Abbreviation = q.Abbreviation,
                    BspRegister = q.BspRegister,
                    TaxNo = q.TaxNo,
                    TravelBankAccountId = q.TravelBankAccountId,
                    TravelBankAccount = q.TravelBankAccount.Name,
                    AdminBankAccountId = q.AdminBankAccountId,
                    AdminBankAccount = q.AdminBankAccount.Name,
                    AccentColor = q.AccentColor,
                    HighlightColor = q.HighlightColor,
                    IsAccentColorPageHeaderFooterOnly = q.IsAccentColorPageHeaderFooterOnly,
                    IsHeadOffice = q.IsHeadOffice,
                    TaxAuditReportPeriod = q.TaxAuditReportPeriod,
                    TravelDocumentTimeFormat = q.TravelDocumentTimeFormat,
                    PayIdType = q.PayIdType,
                    PayId = q.PayId,
                    TravelPayUrl = q.TravelPayUrl,
                    MintUrl = q.MintUrl,
                    PaymentOptions = q.PaymentOptions,
                    BillingAddress1 = q.BillingAddress1,
                    BillingAddress2 = q.BillingAddress2,
                    BillingLocality = q.BillingLocality,
                    BillingRegion = q.BillingRegion,
                    BillingPostCode = q.BillingPostCode,
                    BillingCountryCode = q.BillingCountryCode,
                    BillingContactName = q.BillingContactName,
                    BillingContactPhone = q.BillingContactPhone,
                    BillingContactEmail = q.BillingContactEmail,
                    TechnicalContactName = q.TechnicalContactName,
                    TechnicalContactPhone = q.TechnicalContactPhone,
                    TechnicalContactEmail = q.TechnicalContactEmail
                };

                return PartialView("~/Views/Common/EditorTemplates/AgencyEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Agency_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Agency_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Agency.Where(t => t.Id > 0).OrderBy(t => t.IsHeadOffice ? 0 : 1).ThenBy(t => t.Name);

                var result = await q.AsEnumerable().Select(row => new AgencyViewModel {
                    AgencyId = row.Id,
                    Name = row.Name,
                    TaxNo = row.TaxNo,
                    IsHeadOffice = row.IsHeadOffice,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser,
                    AddressViewModel = row.AgencyAddresses.Select(t => new AddressViewModel {
                        AddressId = t.Id,
                        AddressType = t.AddressType,
                        Address1 = t.Address1,
                        Address2 = t.Address2,
                        Locality = t.Locality,
                        Region = t.Region,
                        PostCode = t.PostCode,
                        CountryCode = t.CountryCode,
                        IsDefaultAddress = t.IsDefault,
                        LastWriteTime = t.LastWriteTime.ToLocalTime(),
                        CreationTime = t.CreationTime.ToLocalTime(),
                        LastWriteUser = t.LastWriteUser,
                        CreationUser = t.CreationUser
                    }).OrderBy(t => t.IsDefaultAddress ? 0 : 1).FirstOrDefault() ?? new AddressViewModel(),
                    ContactViewModel = row.AgencyContacts.Select(t => new ContactViewModel {
                        ContactId = t.Id,
                        Title = t.Title,
                        Name = t.Name,
                        PhoneHome = t.PhoneHome,
                        PhoneWork = t.PhoneWork,
                        Mobile = t.Mobile,
                        PhoneNo = t.PhoneNo,
                        Fax = t.Fax,
                        Email = t.Email,
                        IsDefaultContact = t.IsDefault,
                        LastWriteTime = t.LastWriteTime.ToLocalTime(),
                        CreationTime = t.CreationTime.ToLocalTime(),
                        LastWriteUser = t.LastWriteUser,
                        CreationUser = t.CreationUser
                    }).OrderBy(t => t.IsDefaultContact ? 0 : 1).FirstOrDefault() ?? new ContactViewModel()
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Agency_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Agency_CreateOrUpdate(AgencyViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                AgencyCommon.CreateOrUpdate(HttpContext, Context, Cache, model);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Agency_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Agency_Delete(AgencyViewModel model) {
            try {
                AgencyCommon.Delete(HttpContext, AdminContext, Context, Cache, model);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Agency_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Agency_ExportExcel() {
            try {
                var q = (from t1 in Context.Agency.Include(t => t.TravelBankAccount).Include(t => t.AdminBankAccount).Include(t => t.AgencyAddresses).Include(t => t.AgencyContacts).Where(t => t.Id > 0).OrderBy(t => t.Name).ToList()
                         from t2 in t1.AgencyAddresses.DefaultIfEmpty()
                         from t3 in t1.AgencyContacts.DefaultIfEmpty()
                         select new AgencyExportModel {
                             Agency = t1.Name,
                             Address = t2 == null ? string.Empty : t2.Address,
                             Contact = t3 == null ? string.Empty : t3.FullName,
                             PhoneHome = t3 == null ? string.Empty : t3.PhoneHome,
                             PhoneWork = t3 == null ? string.Empty : t3.PhoneWork,
                             Mobile = t3 == null ? string.Empty : t3.Mobile,
                             Fax = t3 == null ? string.Empty : t3.Fax,
                             Email = t3 == null ? string.Empty : t3.Email,
                             BspRegister = t1.BspRegister,
                             TaxNo = t1.TaxNo,
                             TravelBankAccount = t1.TravelBankAccount.Name,
                             AdminBankAccount = t1.AdminBankAccount.Name,
                             PaymentOptions = t1.PaymentOptions,
                             TravelPayUrl = t1.TravelPayUrl,
                             MintUrl = t1.MintUrl,
                             PayId = t1.PayId,
                             IsHeadOffice = t1.IsHeadOffice
                         }).ToList();

                var xlsx = new ExportToExcel<AgencyExportModel>(q);
                return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Agencies.xlsx");
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Agency_ExportExcel", ex);
                return Redirect("/Shared/Error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> AgencyAddress(int? parentId) {
            try {
                ViewBag.AddressParentId = parentId ?? 0;
                ViewBag.AddressReadUrl = Url.Action("AgencyAddress_Read", "Common", new { parentId = parentId ?? 0 });
                ViewBag.AddressUpdateUrl = Url.Action("AgencyAddress_CreateOrUpdate", "Common");
                ViewBag.AddressDeleteUrl = Url.Action("AgencyAddress_Delete", "Common");

                return PartialView("~/Views/Shared/EditorTemplates/AddressForm.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyAddress", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> AgencyAddress_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.AgencyAddress.Where(t => t.AgencyId == parentId);

                if (!q.Any())
                    q = new List<AgencyAddress> { new AgencyAddress() }.AsQueryable();

                var result = await q.OrderByDescending(t => t.IsDefault).Select(row => new AddressViewModel {
                    AddressType = row.AddressType,
                    AddressId = row.Id,
                    ParentId = row.AgencyId,
                    Address1 = row.Address1,
                    Address2 = row.Address2,
                    Locality = row.Locality,
                    Region = row.Region,
                    PostCode = row.PostCode,
                    CountryCode = row.CountryCode,
                    IsDefaultAddress = row.IsDefault,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyAddress_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyAddress_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                AgencyAddressCommon.CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyAddress_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyAddress_Delete([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                var context = Context;
                var q = context.AgencyAddress.Find(model.AddressId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyAddress_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> AgencyContact(int? parentId) {
            try {
                ViewBag.ContactParentId = parentId ?? 0;
                ViewBag.ContactReadUrl = Url.Action("AgencyContact_Read", "Common", new { parentId = parentId ?? 0 });
                ViewBag.ContactUpdateUrl = Url.Action("AgencyContact_CreateOrUpdate", "Common");
                ViewBag.ContactDeleteUrl = Url.Action("AgencyContact_Delete", "Common");

                ViewBag.ContactIsContactVisible = true;
                ViewBag.ContactIsPhoneHomeVisible = true;
                ViewBag.ContactIsPhoneWorkVisible = true;
                ViewBag.ContactIsMobileVisible = true;
                ViewBag.ContactIsFaxVisible = true;
                ViewBag.ContactIsEmailVisible = true;

                return PartialView("~/Views/Shared/EditorTemplates/ContactForm.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyContact", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> AgencyContact_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.AgencyContact.Where(t => t.AgencyId == parentId);

                if (q.Count() == 0)
                    q = new List<AgencyContact> { new AgencyContact() }.AsQueryable();

                var result = await q.OrderByDescending(t => t.IsDefault).Select(row => new ContactViewModel {
                    ContactId = row.Id,
                    ParentId = row.AgencyId,
                    Title = row.Title,
                    Name = row.Name,
                    PhoneHome = row.PhoneHome,
                    PhoneWork = row.PhoneWork,
                    Mobile = row.Mobile,
                    Fax = row.Fax,
                    Email = row.Email,
                    IsDefaultContact = row.IsDefault,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyContact_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyContact_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ContactViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                AgencyContactCommon.CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyContact_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyContact_Delete([DataSourceRequest] DataSourceRequest request, ContactViewModel model) {
            try {
                var context = Context;
                var q = context.AgencyContact.Find(model.ContactId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyContact_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> AgencyHeader(int? parentId) {
            try {
                ViewBag.ParentId = parentId ?? 0;
                return PartialView("~/Views/Common/EditorTemplates/AgencyHeaderEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyHeader", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> AgencyHeader_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.AgencyHeader.Where(t => t.AgencyId == parentId).OrderBy(t => t.IssuedDocumentType);

                var result = await q.Select(row => new AgencyHeaderViewModel {
                    AgencyHeaderId = row.Id,
                    AgencyId = row.AgencyId,
                    IssuedDocumentType = row.IssuedDocumentType,
                    AgencyHeaderContent = row.HeaderContent,
                    AgencyHeaderStandardCommentId = row.HeaderStandardCommentId,
                    AgencyFooterStandardCommentId = row.FooterStandardCommentId,
                    AgencyHeaderLogoPosition = row.LogoPosition,
                    AgencyHeaderIncludeTaxNo = row.IncludeTaxNo,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyHeader_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyHeader_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AgencyHeaderViewModel model, int parentId, bool isImageUpdated) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                if (model.IssuedDocumentType == IssuedDocumentType.None)
                    throw new ReportedException("Invalid document type.");

                var context = Context;
                AgencyHeader q = null;

                if (model.AgencyHeaderId <= 0) {
                    q = new AgencyHeader();
                }
                else {
                    q = context.AgencyHeader.Find(model.AgencyHeaderId);
                }

                if (model.IssuedDocumentType == IssuedDocumentType.Voucher) {
                    model.AgencyHeaderIncludeTaxNo = false;
                }
                else if (model.IssuedDocumentType != IssuedDocumentType.Quote && model.IssuedDocumentType != IssuedDocumentType.Confirmation && model.IssuedDocumentType != IssuedDocumentType.Itinerary) {
                    model.AgencyHeaderIncludeTaxNo = true;
                }

                q.AgencyId = parentId;
                q.IssuedDocumentType = model.IssuedDocumentType;
                q.HeaderContent = model.AgencyHeaderContent.ToStringExt().TrimEnd(AppConstants.HtmlLineBreak);
                q.HeaderStandardCommentId = model.AgencyHeaderStandardCommentId ?? 0;
                q.FooterStandardCommentId = model.AgencyFooterStandardCommentId ?? 0;
                q.LogoPosition = model.AgencyHeaderLogoPosition;
                q.IncludeTaxNo = model.AgencyHeaderIncludeTaxNo;

                if (isImageUpdated) {
                    string value = await HttpContext.ImageContent();

                    if (value == null) {
                        q.Logo = null;
                    }
                    else {
                        var content = Convert.FromBase64String(value);
                        var logo = content.BytesToImage();

                        if (logo.Width > 340)
                            logo = logo.Resize(340, (int)(340m * logo.Height / logo.Width));

                        q.Logo = logo.ImageToBytes();
                    }
                }

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.AgencyHeaderId = q.Id;

                await HttpContext.ImageContent(string.Empty);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyHeader_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyHeader_UploadLogo(IEnumerable<IFormFile> agencyHeaderFileUpload) {
            try {
                if (agencyHeaderFileUpload != null) {
                    using (var stream = agencyHeaderFileUpload.Single().OpenReadStream()) {
                        await HttpContext.ImageContent(stream.ToBase64String());
                    }
                }

                return Content(string.Empty);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyHeader_UploadLogo", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyHeader_GetLogo(int? agencyHeaderId = null) {
            try {
                await HttpContext.ImageContent(string.Empty);
                var q = Context.AgencyHeader.Find(agencyHeaderId);
                return Json(q?.Logo == null ? string.Empty : Convert.ToBase64String(q.Logo));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyHeader_GetLogo", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> AgencyConsultant(int? agencyId) {
            try {
                ViewBag.AgencyId = agencyId ?? 0;
                return PartialView("~/Views/Common/EditorTemplates/AgencyConsultantEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyConsultant", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> AgencyConsultant_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.ConsultantAgency.Include(t => t.Consultant).Include(t => t.Agency).Where(t => t.AgencyId == parentId);

                var result = await q.OrderBy(t => t.Consultant.Name).Select(row => new ConsultantAgencyViewModel {
                    ConsultantAgencyId = row.Id,
                    ConsultantId = row.ConsultantId,
                    ConsultantName = row.Consultant.Name,
                    AgencyId = row.AgencyId,
                    IsDefault = row.IsDefault,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyConsultant_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyConsultant_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ConsultantAgencyViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                var q = context.ConsultantAgency.Find(model.ConsultantAgencyId);

                if (q == null) {
                    q = new ConsultantAgency {
                        Id = 0,
                        ConsultantId = model.ConsultantId ?? 0,
                        AgencyId = model.AgencyId ?? 0,
                        IsDefault = false
                    };

                    context.Insert(q);
                }

                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyConsultant_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyConsultant_Delete([DataSourceRequest] DataSourceRequest request, ConsultantAgencyViewModel model) {
            try {
                var context = Context;
                var q = context.ConsultantAgency.Find(model.ConsultantAgencyId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyConsultant_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> AgencyPseudoCityCode(int? agencyId) {
            try {
                ViewBag.AgencyId = agencyId ?? 0;
                return PartialView("~/Views/Common/EditorTemplates/AgencyPseudoCityCodeEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyPseudoCityCode", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> AgencyPseudoCityCode_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.AgencyPseudoCityCode.Where(t => t.AgencyId == parentId);

                var result = await q.OrderBy(t => t.Name).Select(row => new AgencyPseudoCityCodeViewModel {
                    AgencyPseudoCityCodeId = row.Id,
                    AgencyId = row.AgencyId,
                    Crs = row.Crs,
                    PccName = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyPseudoCityCode_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyPseudoCityCode_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AgencyPseudoCityCodeViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                var q = context.AgencyPseudoCityCode.Find(model.AgencyPseudoCityCodeId);

                if (q == null) {
                    q = new AgencyPseudoCityCode {
                        Id = 0,
                        AgencyId = model.AgencyId
                    };
                }

                q.Crs = model.Crs;
                q.Name = model.PccName;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.AgencyPseudoCityCodeId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyPseudoCityCode_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyPseudoCityCode_Delete([DataSourceRequest] DataSourceRequest request, AgencyPseudoCityCodeViewModel model) {
            try {
                var context = Context;
                var q = context.AgencyPseudoCityCode.Find(model.AgencyPseudoCityCodeId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyPseudoCityCode_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> AgencyUserEmail(int? agencyId) {
            try {
                ViewBag.AgencyId = agencyId ?? 0;
                return PartialView("~/Views/Common/EditorTemplates/AgencyUserEmailEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyUserEmail", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> AgencyUserEmail_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.AgencyUserEmail.Where(t => t.AgencyId == parentId);

                var result = await q.Select(row => new AgencyUserEmailViewModel {
                    AgencyUserEmailId = row.Id,
                    AgencyId = row.AgencyId,
                    UserId = row.UserId,
                    Email = row.Email,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyUserEmail_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyUserEmail_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AgencyUserEmailViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                using (var ts = Utils.CreateTransactionScope()) {
                    var adminContext = AdminContext;
                    var context = Context;

                    var q = context.AgencyUserEmail.Find(model.AgencyUserEmailId);

                    if (q == null) {
                        q = new AgencyUserEmail {
                            Id = 0,
                            AgencyId = model.AgencyId
                        };
                    }

                    q.UserId = model.UserId;
                    q.Email = model.Email;

                    if (q.Id <= 0) {
                        context.Insert(q);
                    }
                    else {
                        context.Save(q);
                    }

                    model.AgencyUserEmailId = q.Id;

                    var aspNetUsers = adminContext.AspNetUsers.Find(q.UserId);

                    if (aspNetUsers.Email != q.Email) {
                        aspNetUsers.AgencyEmail = q.Email;
                        adminContext.Save(aspNetUsers, false);
                    }

                    if (HttpContext.UserId() == model.UserId) {
                        var appUser = await UserManager.FindByIdAsync(model.UserId);
                        AppUserClaimsPrincipalFactory.UpdateUser(appUser, User);
                        await SignInManager.RefreshSignInAsync(appUser);
                    }

                    ts.Complete();
                    return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
                }
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyUserEmail_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AgencyUserEmail_Delete([DataSourceRequest] DataSourceRequest request, AgencyUserEmailViewModel model) {
            try {
                var context = Context;
                var q = context.AgencyUserEmail.Find(model.AgencyUserEmailId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AgencyUserEmail_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Agents
        public IActionResult Agents() {
            return View();
        }

        public async Task<IActionResult> Agent_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Agent.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new AgentViewModel {
                    AgentId = row.Id,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Agent_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Agent_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AgentViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Agent q = null;

                if (model.AgentId <= 0) {
                    q = new Agent();
                }
                else {
                    q = context.Agent.Find(model.AgentId);
                }

                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.AgentId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Agent_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Agent_Delete([DataSourceRequest] DataSourceRequest request, AgentViewModel model) {
            try {
                var context = Context;
                var q = context.Agent.Find(model.AgentId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Agent_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Aircraft
        public IActionResult Aircraft() {
            return View();
        }

        public async Task<IActionResult> Aircraft_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Aircraft.Where(t => t.Id > 0).OrderBy(t => t.Code);

                var result = await q.Select(row => new AircraftViewModel {
                    AircraftId = row.Id,
                    Code = row.Code,
                    Name = row.Name,
                    Comments = row.Comments,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Aircraft_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Aircraft_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AircraftViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Aircraft q = null;

                if (model.AircraftId <= 0) {
                    q = new Aircraft();
                }
                else {
                    q = context.Aircraft.Find(model.AircraftId);
                }

                q.Code = Utils.RemoveExtraSpaces(model.Code).Replace(" ", string.Empty).ToUpper();
                q.Name = model.Name;
                q.Comments = model.Comments.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.AircraftId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Aircraft_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Aircraft_Delete([DataSourceRequest] DataSourceRequest request, AircraftViewModel model) {
            try {
                var context = Context;
                var q = context.Aircraft.Find(model.AircraftId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Aircraft_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Airlines
        public IActionResult Airlines() {
            return View();
        }

        public async Task<IActionResult> Airline_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Airline.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new AirlineViewModel {
                    AirlineId = row.Id,
                    Code = row.Code,
                    Name = row.Name,
                    IataCode = row.IataCode,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Airline_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Airline_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AirlineViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Airline q = null;

                if (model.AirlineId <= 0) {
                    q = new Airline();
                }
                else {
                    q = context.Airline.Find(model.AirlineId);
                }

                q.Code = Utils.RemoveExtraSpaces(model.Code).Replace(" ", string.Empty).ToUpper();
                q.Name = model.Name;
                q.IataCode = model.IataCode.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.AirlineId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Airline_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Airline_Delete([DataSourceRequest] DataSourceRequest request, AirlineViewModel model) {
            try {
                var context = Context;
                var q = context.Airline.Include(t => t.AirlineCommissions).Include(t => t.AirlineClasses).Include(t => t.AirlineStandardComments).SingleOrDefault(t => t.Id == model.AirlineId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Airline_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> AirlineClass_Read([DataSourceRequest] DataSourceRequest request, int parentId, bool isExport) {
            try {
                var q = Context.AirlineClass.Where(t => t.AirlineId > 0);

                if (isExport) {
                    var export = q.OrderBy(t => t.Airline.Name).ThenBy(t => t.Code).Select(row => new AirlineClassExportModel {
                        Airline = row.Airline.Name,
                        ClassCode = row.Code,
                        ClassName = row.Name
                    }).ToList();

                    var xlsx = new ExportToExcel<AirlineClassExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Airline Classes.xlsx");
                }

                var result = await q.OrderBy(t => t.Code).Where(t => t.AirlineId == parentId).Select(row => new AirlineClassViewModel {
                    AirlineClassId = row.Id,
                    AirlineId = row.AirlineId,
                    AirlineClassCode = row.Code,
                    AirlineClassName = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AirlineClass_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AirlineClass_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AirlineClassViewModel model, int parentId) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                AirlineClass q = null;

                if (model.AirlineClassId <= 0) {
                    q = new AirlineClass();
                }
                else {
                    q = context.AirlineClass.Find(model.AirlineClassId);
                }

                q.AirlineId = parentId;
                q.Code = model.AirlineClassCode.ToUpper();
                q.Name = model.AirlineClassName;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.AirlineClassId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AirlineClass_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AirlineClass_Delete([DataSourceRequest] DataSourceRequest request, AirlineClassViewModel model) {
            try {
                var context = Context;
                var q = context.AirlineClass.Find(model.AirlineClassId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AirlineClass_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AirlineCommission_Edit(int airlineCommissionId, int airlineId) {
            try {
                AirlineCommission q = null;

                if (airlineCommissionId <= 0) {
                    q = new AirlineCommission {
                        Id = 0,
                        AirlineId = airlineId,
                        SaleTypeId = -1
                    };
                }
                else {
                    q = Context.AirlineCommission.Find(airlineCommissionId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);
                }

                var model = new AirlineCommissionViewModel {
                    AirlineCommissionId = q.Id,
                    AirlineId = q.AirlineId,
                    SaleTypeId = q.SaleTypeId,
                    CountryZone = q.CountryZone,
                    CommissionRate = q.CommissionRate,
                    OverrideRate = q.OverrideRate,
                    OverrideBasis = q.OverrideBasis,
                    CommissionableTaxes = q.CommissionableTaxes
                };

                return PartialView("~/Views/Common/EditorTemplates/AirlineCommissionEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AirlineCommission_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> AirlineCommission_Read([DataSourceRequest] DataSourceRequest request, int parentId, bool isExport) {
            try {
                var q = Context.AirlineCommission.Where(t => t.AirlineId > 0).OrderBy(t => t.Airline.Name);

                if (isExport) {
                    var export = q.OrderBy(t => t.Airline.Name).ThenBy(t => t.SaleType.Name).Select(row => new AirlineCommissionExportModel {
                        Airline = row.Airline.Name,
                        SaleType = row.SaleType.Name,
                        CountryZone = row.CountryZone.GetEnumDescription(),
                        CommissionRate = row.CommissionRate,
                        OverrideRate = row.OverrideRate,
                        OverrideBasis = row.OverrideBasis.GetEnumDescription(),
                        CommissionableTaxes = row.CommissionableTaxes
                    }).ToList();

                    var xlsx = new ExportToExcel<AirlineCommissionExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Airline Commission Rates.xlsx");
                }

                var result = await q.Where(t => t.AirlineId == parentId).OrderBy(t => t.SaleType.Name).Select(row => new AirlineCommissionViewModel {
                    AirlineCommissionId = row.Id,
                    AirlineId = row.AirlineId,
                    SaleTypeId = row.SaleTypeId,
                    SaleType = row.SaleType.Name,
                    CountryZone = row.CountryZone,
                    CommissionRate = row.CommissionRate,
                    OverrideRate = row.OverrideRate,
                    OverrideBasis = row.OverrideBasis,
                    CommissionableTaxes = row.CommissionableTaxes,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AirlineCommission_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AirlineCommission_CreateOrUpdate(AirlineCommissionViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                AirlineCommission q = null;

                if (model.AirlineCommissionId <= 0) {
                    q = new AirlineCommission();
                }
                else {
                    q = context.AirlineCommission.Find(model.AirlineCommissionId);
                }

                q.AirlineId = model.AirlineId;
                q.SaleTypeId = model.SaleTypeId ?? 0;
                q.CountryZone = model.CountryZone;
                q.CommissionRate = model.CommissionRate / 100;
                q.OverrideRate = model.OverrideRate / 100;
                q.OverrideBasis = model.OverrideBasis;
                q.CommissionableTaxes = model.CommissionableTaxes.ToStringExt().ToUpper();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.AirlineCommissionId = q.Id;
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AirlineCommission_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AirlineCommission_Delete([DataSourceRequest] DataSourceRequest request, AirlineCommissionViewModel model) {
            try {
                var context = Context;
                var q = context.AirlineCommission.Find(model.AirlineCommissionId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AirlineCommission_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> AirlineStandardComment_Read([DataSourceRequest] DataSourceRequest request, int parentId, bool isExport) {
            try {
                var q = Context.AirlineStandardComment.Where(t => t.AirlineId > 0);

                if (isExport) {
                    var export = q.OrderBy(t => t.Airline.Name).ThenBy(t => (int)t.AirlineStandardCommentType).Select(row => new AirlineStandardCommentExportModel {
                        Airline = row.Airline.Name,
                        StandardCommentType = row.AirlineStandardCommentType.GetEnumDescription(),
                        StandardComment = row.StandardComment.Comment
                    }).ToList();

                    var xlsx = new ExportToExcel<AirlineStandardCommentExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Airline Standard Comments.xlsx");
                }

                var result = await q.OrderBy(t => (int)t.AirlineStandardCommentType).Where(t => t.AirlineId == parentId).Select(row => new AirlineStandardCommentViewModel {
                    AirlineStandardCommentId = row.Id,
                    AirlineId = row.AirlineId,
                    AirlineStandardCommentType = row.AirlineStandardCommentType,
                    StandardCommentId = row.StandardCommentId,
                    StandardComment = row.StandardComment.Code,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AirlineStandardComment_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AirlineStandardComment_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AirlineStandardCommentViewModel model, int parentId) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                AirlineStandardComment q = null;

                if (model.AirlineStandardCommentId <= 0) {
                    q = new AirlineStandardComment();
                }
                else {
                    q = context.AirlineStandardComment.Find(model.AirlineStandardCommentId);
                }

                q.AirlineId = parentId;
                q.AirlineStandardCommentType = model.AirlineStandardCommentType;
                q.StandardCommentId = model.StandardCommentId ?? 0;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.AirlineStandardCommentId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AirlineStandardComment_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AirlineStandardComment_Delete([DataSourceRequest] DataSourceRequest request, AirlineStandardCommentViewModel model) {
            try {
                var context = Context;
                var q = context.AirlineStandardComment.Find(model.AirlineStandardCommentId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "AirlineStandardComment_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Application Settings
        public IActionResult ApplicationSettings(string message = null, MessageType messageType = MessageType.Warning) {
            var adminContext = AdminContext;

            var generalModel = new ApplicationSettingGeneralViewModel {
                BspCreditorId = HttpContext.AppSettings().BspCreditorId,
                AgentCommissionDiscountReasonId = HttpContext.AppSettings().AgentCommissionDiscountReasonId,
                GeneralLedgerReportSign = HttpContext.AppSettings().GeneralLedgerReportSign,
                TaxAuditReportPeriod = HttpContext.AppSettings().TaxAuditReportPeriod,
                FiscalPeriodAutoCloseOffMonths = HttpContext.AppSettings().FiscalPeriodAutoCloseOffMonths,
                ExchangeRateMargin = HttpContext.AppSettings().ExchangeRateMargin / 100
            };

            var formOfPaymentModel = new ApplicationSettingFormOfPaymentViewModel {
                AmexFormOfPaymentId = HttpContext.AppSettings().AmexFormOfPaymentId,
                DinersClubFormOfPaymentId = HttpContext.AppSettings().DinersClubFormOfPaymentId,
                MastercardFormOfPaymentId = HttpContext.AppSettings().MastercardFormOfPaymentId,
                VisaFormOfPaymentId = HttpContext.AppSettings().VisaFormOfPaymentId,
                LoyaltySchemeFormOfPaymentId = HttpContext.AppSettings().LoyaltySchemeFormOfPaymentId,
                SystemGenReceiptFormOfPaymentId = AdminSettings.SystemGenReceiptFormOfPaymentId(adminContext),
                SystemGenInvoiceDiscountReasonId = AdminSettings.SystemGenInvoiceDiscountReasonId(adminContext),
                SystemGenDocRequiresApproval = AdminSettings.SystemGenDocRequiresApproval(adminContext)
            };

            var crsModel = new ApplicationSettingCrsViewModel {
                CrsDefaultProviderId = HttpContext.AppSettings().CrsDefaultProviderId,
                CrsDomesticAirSaleTypeId = HttpContext.AppSettings().CrsDomesticAirSaleTypeId,
                CrsInternationalAirSaleTypeId = HttpContext.AppSettings().CrsInternationalAirSaleTypeId,
                CrsDomesticAccommodationSaleTypeId = HttpContext.AppSettings().CrsDomesticAccommodationSaleTypeId,
                CrsInternationalAccommodationSaleTypeId = HttpContext.AppSettings().CrsInternationalAccommodationSaleTypeId,
                CrsDomesticTransportSaleTypeId = HttpContext.AppSettings().CrsDomesticTransportSaleTypeId,
                CrsInternationalTransportSaleTypeId = HttpContext.AppSettings().CrsInternationalTransportSaleTypeId,

                CrsAmadeusCreditorAirId = HttpContext.AppSettings().CrsAmadeusCreditorAirId,
                CrsAmadeusSupplierAirId = HttpContext.AppSettings().CrsAmadeusSupplierAirId,
                CrsAmadeusCreditorLandId = HttpContext.AppSettings().CrsAmadeusCreditorLandId,
                CrsAmadeusSupplierLandId = HttpContext.AppSettings().CrsAmadeusSupplierLandId,
                CrsAmadeusDomesticServiceFeeTypeId = HttpContext.AppSettings().CrsAmadeusDomesticServiceFeeTypeId,
                CrsAmadeusInternationalServiceFeeTypeId = HttpContext.AppSettings().CrsAmadeusInternationalServiceFeeTypeId,

                CrsCalypsoSandboxUrl = HttpContext.AppSettings().CrsCalypsoSandboxUrl,

                CrsEtgCreditorAirId = HttpContext.AppSettings().CrsEtgCreditorAirId,
                CrsEtgSupplierAirId = HttpContext.AppSettings().CrsEtgSupplierAirId,
                CrsEtgCreditorLandId = HttpContext.AppSettings().CrsEtgCreditorLandId,
                CrsEtgSupplierLandId = HttpContext.AppSettings().CrsEtgSupplierLandId,
                CrsEtgDomesticServiceFeeTypeId = HttpContext.AppSettings().CrsEtgDomesticServiceFeeTypeId,
                CrsEtgInternationalServiceFeeTypeId = HttpContext.AppSettings().CrsEtgInternationalServiceFeeTypeId,

                CrsEtgRefreshToken = CustomerSettings.EtgRefreshToken,
                CrsEtgAccessToken = CustomerSettings.EtgAccessToken,
                CrsEtgAccessTokenExpiration = CustomerSettings.EtgAccessTokenExpiration.ToLocalTime().ToShortDateTimeStringExt(),

                CrsGalileoCreditorAirId = HttpContext.AppSettings().CrsGalileoCreditorAirId,
                CrsGalileoSupplierAirId = HttpContext.AppSettings().CrsGalileoSupplierAirId,
                CrsGalileoCreditorLandId = HttpContext.AppSettings().CrsGalileoCreditorLandId,
                CrsGalileoSupplierLandId = HttpContext.AppSettings().CrsGalileoSupplierLandId,
                CrsGalileoDomesticServiceFeeTypeId = HttpContext.AppSettings().CrsGalileoDomesticServiceFeeTypeId,
                CrsGalileoInternationalServiceFeeTypeId = HttpContext.AppSettings().CrsGalileoInternationalServiceFeeTypeId,

                CrsGalileoUseProduction = HttpContext.AppSettings().CrsGalileoUseProduction
            };

            var paymentGatewayModel = new ApplicationSettingPaymentGatewayViewModel {
                EwayCustomerApiKey = HttpContext.AppSettings().EwayCustomerApiKey,
                EwayCustomerClientKey = HttpContext.AppSettings().EwayCustomerClientKey,
                EwayCustomerPassword = HttpContext.AppSettings().EwayCustomerPassword,
                EwaySandboxCustomerApiKey = HttpContext.AppSettings().EwaySandboxCustomerApiKey,
                EwaySandboxCustomerClientKey = HttpContext.AppSettings().EwaySandboxCustomerClientKey,
                EwaySandboxCustomerPassword = HttpContext.AppSettings().EwaySandboxCustomerPassword
            };

            ViewBag.Message = message;
            ViewBag.MessageType = messageType;

            return View("~/Views/Admin/ApplicationSettings.cshtml", Tuple.Create(generalModel, formOfPaymentModel, crsModel, paymentGatewayModel));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApplicationSettingGeneral_Update(ApplicationSettingGeneralViewModel model) {
            try {
                string message = null;
                var messageType = MessageType.Warning;

                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                if (!Enum.IsDefined(typeof(ReportSign), model.GeneralLedgerReportSign))
                    throw new UnreportedException("General Ledger Report Sign is invalid.");

                if (!Enum.IsDefined(typeof(ReportPeriod), model.TaxAuditReportPeriod))
                    throw new UnreportedException(string.Format("{0} is invalid.", Resource.TaxAuditReportPeriodLabel));

                HttpContext.AppSettings().BspCreditorId = model.BspCreditorId ?? -1;
                HttpContext.AppSettings().AgentCommissionDiscountReasonId = model.AgentCommissionDiscountReasonId ?? -1;
                HttpContext.AppSettings().GeneralLedgerReportSign = model.GeneralLedgerReportSign;
                HttpContext.AppSettings().TaxAuditReportPeriod = model.TaxAuditReportPeriod;
                HttpContext.AppSettings().FiscalPeriodAutoCloseOffMonths = model.FiscalPeriodAutoCloseOffMonths;
                HttpContext.AppSettings().ExchangeRateMargin = model.ExchangeRateMargin;

                if (AppSettings.UpdateAll(Context, HttpContext.CurrentCustomerId())) {
                    message = "Application Settings have been updated.";
                    messageType = MessageType.Success;
                }
                else {
                    message = "No changes were made. Application Settings were not updated.";
                }

                return Json(new JavaScriptResult(WebUtils.GetMessageScript(message, messageType)));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ApplicationSettingGeneral_Update", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApplicationSettingPayment_Update(ApplicationSettingFormOfPaymentViewModel model) {
            try {
                var adminContext = AdminContext;
                var context = Context;

                string message = null;
                var messageType = MessageType.Warning;

                if (model.LoyaltySchemeFormOfPaymentId > 0 && !context.FormOfPayment.Any(t => t.Id == model.LoyaltySchemeFormOfPaymentId && t.FormOfPaymentType == FormOfPaymentType.LoyaltyScheme))
                    throw new UnreportedException("Default Loyalty Scheme is invalid.");

                HttpContext.AppSettings().AmexFormOfPaymentId = model.AmexFormOfPaymentId ?? -1;
                HttpContext.AppSettings().DinersClubFormOfPaymentId = model.DinersClubFormOfPaymentId ?? -1;
                HttpContext.AppSettings().MastercardFormOfPaymentId = model.MastercardFormOfPaymentId ?? -1;
                HttpContext.AppSettings().VisaFormOfPaymentId = model.VisaFormOfPaymentId ?? -1;
                HttpContext.AppSettings().LoyaltySchemeFormOfPaymentId = model.LoyaltySchemeFormOfPaymentId ?? -1;

                bool result = false;

                if (AdminSettings.SystemGenReceiptFormOfPaymentId(adminContext, model.SystemGenReceiptFormOfPaymentId) == 1)
                    result = true;

                if (AdminSettings.SystemGenInvoiceDiscountReasonId(adminContext, model.SystemGenInvoiceDiscountReasonId) == 1)
                    result = true;

                if (AdminSettings.SystemGenDocRequiresApproval(adminContext, model.SystemGenDocRequiresApproval))
                    result = true;

                if (AppSettings.UpdateAll(context, HttpContext.CurrentCustomerId()) || result) {
                    message = "Application Settings have been updated.";
                    messageType = MessageType.Success;
                }
                else {
                    message = "No changes were made. Application Settings were not updated.";
                }

                return Json(new JavaScriptResult(WebUtils.GetMessageScript(message, messageType)));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ApplicationSettingPayment_Update", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApplicationSettingCrs_Update(ApplicationSettingCrsViewModel model) {
            try {
                string message = null;
                var messageType = MessageType.Warning;

                HttpContext.AppSettings().CrsDefaultProviderId = model.CrsDefaultProviderId ?? (int)Crs.NotSpecified;
                HttpContext.AppSettings().CrsDomesticAirSaleTypeId = model.CrsDomesticAirSaleTypeId ?? -1;
                HttpContext.AppSettings().CrsInternationalAirSaleTypeId = model.CrsInternationalAirSaleTypeId ?? -1;
                HttpContext.AppSettings().CrsDomesticAccommodationSaleTypeId = model.CrsDomesticAccommodationSaleTypeId ?? -1;
                HttpContext.AppSettings().CrsInternationalAccommodationSaleTypeId = model.CrsInternationalAccommodationSaleTypeId ?? -1;
                HttpContext.AppSettings().CrsDomesticTransportSaleTypeId = model.CrsDomesticTransportSaleTypeId ?? -1;
                HttpContext.AppSettings().CrsInternationalTransportSaleTypeId = model.CrsInternationalTransportSaleTypeId ?? -1;

                HttpContext.AppSettings().CrsAmadeusCreditorAirId = model.CrsAmadeusCreditorAirId ?? -1;
                HttpContext.AppSettings().CrsAmadeusSupplierAirId = model.CrsAmadeusSupplierAirId ?? -1;
                HttpContext.AppSettings().CrsAmadeusCreditorLandId = model.CrsAmadeusCreditorLandId ?? -1;
                HttpContext.AppSettings().CrsAmadeusSupplierLandId = model.CrsAmadeusSupplierLandId ?? -1;
                HttpContext.AppSettings().CrsAmadeusDomesticServiceFeeTypeId = model.CrsAmadeusDomesticServiceFeeTypeId ?? -1;
                HttpContext.AppSettings().CrsAmadeusInternationalServiceFeeTypeId = model.CrsAmadeusInternationalServiceFeeTypeId ?? -1;

                HttpContext.AppSettings().CrsCalypsoSandboxUrl = model.CrsCalypsoSandboxUrl.ToStringExt();

                HttpContext.AppSettings().CrsEtgCreditorAirId = model.CrsEtgCreditorAirId ?? -1;
                HttpContext.AppSettings().CrsEtgSupplierAirId = model.CrsEtgSupplierAirId ?? -1;
                HttpContext.AppSettings().CrsEtgCreditorLandId = model.CrsEtgCreditorLandId ?? -1;
                HttpContext.AppSettings().CrsEtgSupplierLandId = model.CrsEtgSupplierLandId ?? -1;
                HttpContext.AppSettings().CrsEtgDomesticServiceFeeTypeId = model.CrsEtgDomesticServiceFeeTypeId ?? -1;
                HttpContext.AppSettings().CrsEtgInternationalServiceFeeTypeId = model.CrsEtgInternationalServiceFeeTypeId ?? -1;

                HttpContext.AppSettings().CrsGalileoCreditorAirId = model.CrsGalileoCreditorAirId ?? -1;
                HttpContext.AppSettings().CrsGalileoSupplierAirId = model.CrsGalileoSupplierAirId ?? -1;
                HttpContext.AppSettings().CrsGalileoCreditorLandId = model.CrsGalileoCreditorLandId ?? -1;
                HttpContext.AppSettings().CrsGalileoSupplierLandId = model.CrsGalileoSupplierLandId ?? -1;
                HttpContext.AppSettings().CrsGalileoDomesticServiceFeeTypeId = model.CrsGalileoDomesticServiceFeeTypeId ?? -1;
                HttpContext.AppSettings().CrsGalileoInternationalServiceFeeTypeId = model.CrsGalileoInternationalServiceFeeTypeId ?? -1;

                HttpContext.AppSettings().CrsGalileoUseProduction = model.CrsGalileoUseProduction;

                if (AppSettings.UpdateAll(Context, HttpContext.CurrentCustomerId())) {
                    message = "Application Settings have been updated.";
                    messageType = MessageType.Success;
                }
                else {
                    message = "No changes were made. Application Settings were not updated.";
                }

                return Json(new JavaScriptResult(WebUtils.GetMessageScript(message, messageType)));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ApplicationSettingCrs_Update", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApplicationSettingPaymentGateway_Update(ApplicationSettingPaymentGatewayViewModel model) {
            try {
                string message = null;
                var messageType = MessageType.Warning;

                HttpContext.AppSettings().EwayCustomerApiKey = model.EwayCustomerApiKey.ToStringExt();
                HttpContext.AppSettings().EwayCustomerClientKey = model.EwayCustomerClientKey.ToStringExt();
                HttpContext.AppSettings().EwayCustomerPassword = model.EwayCustomerPassword.ToStringExt();
                HttpContext.AppSettings().EwaySandboxCustomerApiKey = model.EwaySandboxCustomerApiKey.ToStringExt();
                HttpContext.AppSettings().EwaySandboxCustomerClientKey = model.EwaySandboxCustomerClientKey.ToStringExt();
                HttpContext.AppSettings().EwaySandboxCustomerPassword = model.EwaySandboxCustomerPassword.ToStringExt();

                if (AppSettings.UpdateAll(Context, HttpContext.CurrentCustomerId())) {
                    message = "Application Settings have been updated.";
                    messageType = MessageType.Success;
                }
                else {
                    message = "No changes were made. Application Settings were not updated.";
                }

                return Json(new JavaScriptResult(WebUtils.GetMessageScript(message, messageType)));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ApplicationSettingPaymentGateway_Update", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RefreshEtgAccessToken_Update() {
            try {
                if (HttpContext.AppUserRole() != AppUserRole.SystemAdministrator)
                    throw new UnauthorizedAccessException(AppConstants.UnauthorisedAccess);

                await ExpressTravelGroup.RefreshAccessTokenAsync();
                return Json(Url.Action("ApplicationSettings", "Common", new { message = "Access token has been updated.", messageType = MessageType.Success }));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "RefreshEtgAccessToken_Update", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Bank Accounts
        public IActionResult BankAccounts() {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BankAccount_Edit(int bankAccountId) {
            try {
                BankAccount q = null;

                if (bankAccountId <= 0) {
                    q = new BankAccount();
                }
                else {
                    q = Context.BankAccount.Find(bankAccountId);
                }

                var model = new BankAccountViewModel {
                    BankAccountId = q.Id,
                    Name = q.Name,
                    Branch = q.Branch,
                    AccountNo = q.AccountNo,
                    AccountDescription = q.AccountDescription,
                    ChartOfAccountId = q.ChartOfAccountId,
                    DailyWithdrawalLimit = q.DailyWithdrawalLimit,
                    BankAccountOpeningBalance = q.OpeningBalance
                };

                return PartialView("~/Views/Common/EditorTemplates/BankAccountEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccount_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> BankAccount_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.BankAccount.Include(t => t.ChartOfAccount).Include(t => t.BankAccountAddresses).Include(t => t.ChartOfAccount).Include(t => t.BankAccountStatements).Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new BankAccountViewModel {
                    BankAccountId = row.Id,
                    Name = row.Name,
                    Branch = row.Branch,
                    AccountNo = row.AccountNo,
                    AccountDescription = row.AccountDescription,
                    ChartOfAccountId = row.ChartOfAccountId,
                    ChartOfAccount = string.Format("{0}: {1}", row.ChartOfAccount.Code, row.ChartOfAccount.Name),
                    DailyWithdrawalLimit = row.DailyWithdrawalLimit,
                    BankAccountOpeningBalance = row.OpeningBalance,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser,
                    AddressViewModel = row.BankAccountAddresses.Select(t2 => t2).Select(t3 => new AddressViewModel {
                        AddressId = t3.Id,
                        AddressType = t3.AddressType,
                        Address1 = t3.Address1,
                        Address2 = t3.Address2,
                        Locality = t3.Locality,
                        Region = t3.Region,
                        PostCode = t3.PostCode,
                        CountryCode = t3.CountryCode,
                        IsDefaultAddress = t3.IsDefault,
                        LastWriteTime = t3.LastWriteTime.ToLocalTime(),
                        CreationTime = t3.CreationTime.ToLocalTime(),
                        LastWriteUser = t3.LastWriteUser,
                        CreationUser = t3.CreationUser
                    }).OrderBy(t2 => t2.IsDefaultAddress ? 0 : 1).FirstOrDefault() ?? new AddressViewModel()
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccount_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BankAccount_CreateOrUpdate(BankAccountViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;

                if (context.BankAccount.Any(t => t.Id != model.BankAccountId && t.ChartOfAccountId == model.ChartOfAccountId))
                    throw new UnreportedException("GL Account already exists for another Bank Account.");

                BankAccount q = null;

                if (model.BankAccountId <= 0) {
                    q = new BankAccount();
                }
                else {
                    q = context.BankAccount.Find(model.BankAccountId);
                }

                if (model.ChartOfAccountId != q.ChartOfAccountId && !ChartOfAccount.IsInRole(context, model.ChartOfAccountId ?? 0, HttpContext.RoleId()))
                    throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                q.Name = model.Name;
                q.Branch = model.Branch;
                q.AccountNo = model.AccountNo;
                q.AccountDescription = model.AccountDescription.ToStringExt();
                q.ChartOfAccountId = model.ChartOfAccountId ?? 0;
                q.DailyWithdrawalLimit = model.DailyWithdrawalLimit;
                q.OpeningBalance = model.BankAccountOpeningBalance;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.BankAccountId = q.Id;
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccount_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BankAccount_Delete([DataSourceRequest] DataSourceRequest request, BankAccountViewModel model) {
            try {
                var context = Context;
                var q = context.BankAccount.Include(t => t.BankAccountAddresses).Include(t => t.BankAccountStatements).SingleOrDefault(t => t.Id == model.BankAccountId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccount_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> BankAccount_ExportExcel() {
            try {
                var q = (from t1 in Context.BankAccount.Include(t => t.ChartOfAccount).Include(t => t.BankAccountAddresses).Where(t => t.Id > 0).OrderBy(t => t.Name).AsEnumerable()
                         from t2 in t1.BankAccountAddresses.DefaultIfEmpty()
                         select new BankAccountExportModel {
                             AccountName = t1.Name,
                             Branch = t1.Branch,
                             AccountNo = t1.AccountNo,
                             AccountDescription = t1.AccountDescription,
                             Address = t2 == null ? string.Empty : t2.Address,
                             GeneralLedgerAccount = t1.ChartOfAccount.Name
                         }).ToList();

                var xlsx = new ExportToExcel<BankAccountExportModel>(q);
                return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Bank Accounts.xlsx");
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccount_ExportExcel", ex);
                return Redirect("/Shared/Error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> BankAccountAddress(int? parentId) {
            try {
                ViewBag.AddressParentId = parentId ?? 0;
                ViewBag.AddressReadUrl = Url.Action("BankAccountAddress_Read", "Common", new { parentId = parentId ?? 0 });
                ViewBag.AddressUpdateUrl = Url.Action("BankAccountAddress_CreateOrUpdate", "Common");
                ViewBag.AddressDeleteUrl = Url.Action("BankAccountAddress_Delete", "Common");

                return PartialView("~/Views/Shared/EditorTemplates/AddressForm.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccountAddress", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> BankAccountAddress_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.BankAccountAddress.Where(t => t.BankAccountId == parentId);

                if (q.Count() == 0)
                    q = new List<BankAccountAddress> { new BankAccountAddress() }.AsQueryable();

                var result = await q.OrderByDescending(t => t.IsDefault).Select(row => new AddressViewModel {
                    AddressType = row.AddressType,
                    AddressId = row.Id,
                    ParentId = row.BankAccountId,
                    Address1 = row.Address1,
                    Address2 = row.Address2,
                    Locality = row.Locality,
                    Region = row.Region,
                    PostCode = row.PostCode,
                    CountryCode = row.CountryCode,
                    IsDefaultAddress = row.IsDefault,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccountAddress_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BankAccountAddress_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                BankAccountAddressCommon.BankAccountAddress_CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccountAddress_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BankAccountAddress_Delete([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                var context = Context;
                var q = context.BankAccountAddress.Find(model.AddressId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccountAddress_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> BankAccountStatement(int? parentId) {
            try {
                ViewBag.ParentId = parentId ?? 0;
                return PartialView("~/Views/Common/EditorTemplates/BankAccountStatementEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccountStatement", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> BankAccountStatement_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.BankAccountStatement.Where(t => t.BankAccountId == parentId).OrderByDescending(t => t.StatementNo);

                var result = await q.Select(row => new BankAccountStatementViewModel {
                    BankAccountStatementId = row.Id,
                    BankAccountId = row.BankAccountId,
                    StatementNo = row.StatementNo,
                    OpeningBalance = row.OpeningBalance,
                    ClosingBalance = row.ClosingBalance,
                    ClosingDate = row.ClosingDate == DateTime.MinValue ? null : row.ClosingDate,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccountStatement_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BankAccountStatement_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, BankAccountStatementViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                if (!HttpContext.IsAdministrator())
                    throw new UnreportedException(AppConstants.RecordIsReadOnly);

                var context = Context;
                BankAccountStatement q = null;

                if (model.BankAccountStatementId <= 0) {
                    q = new BankAccountStatement {
                        StatementNo = (Context.BankAccountStatement.Where(t => t.BankAccountId == model.BankAccountId).OrderByDescending(t => t.StatementNo).FirstOrDefault()?.StatementNo ?? 0) + 1
                    };
                }
                else {
                    q = context.BankAccountStatement.Find(model.BankAccountStatementId);
                }

                q.BankAccountId = model.BankAccountId;
                q.OpeningBalance = model.OpeningBalance;
                q.ClosingBalance = model.ClosingBalance;
                q.ClosingDate = model.ClosingDate ?? DateTime.MinValue;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.BankAccountStatementId = q.Id;

                var bankAccountStatements = context.BankAccountStatement.Where(t => t.BankAccountId == q.BankAccountId).OrderBy(t => t.StatementNo).FirstOrDefault(t => t.StatementNo > q.StatementNo);

                if (bankAccountStatements != null && bankAccountStatements.OpeningBalance != q.ClosingBalance)
                    throw new UnreportedException("Closing Balance does not equal Opening Balance of the next statement.");

                bankAccountStatements = context.BankAccountStatement.Where(t => t.BankAccountId == q.BankAccountId).OrderByDescending(t => t.StatementNo).FirstOrDefault(t => t.StatementNo < q.StatementNo);

                if (bankAccountStatements != null && bankAccountStatements.ClosingBalance != q.OpeningBalance)
                    throw new UnreportedException("Opening Balance does not equal Closing Balance of the previous statement.");

                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccountStatement_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BankAccountStatement_Delete([DataSourceRequest] DataSourceRequest request, BankAccountStatementViewModel model) {
            try {
                if (!HttpContext.IsAdministrator())
                    throw new UnreportedException("Only Administrators can delete this record.");

                var context = Context;
                var q = context.BankAccountStatement.Find(model.BankAccountStatementId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccountStatement_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BankAccountStatement_GetDefaults(BankAccountStatementViewModel model) {
            try {
                var q = Context.BankAccountStatement.OrderByDescending(t => t.StatementNo).FirstOrDefault(t => t.BankAccountId == model.BankAccountId);

                int statementNo = 1;
                decimal openingBalance = 0;
                DateTime closingDate = DateTime.Today;

                if (q != null) {
                    statementNo = q.StatementNo + 1;
                    openingBalance = q.ClosingBalance;

                    if (DateTime.DaysInMonth(q.ClosingDate.Year, q.ClosingDate.Month) == q.ClosingDate.Day) {
                        closingDate = q.ClosingDate.AddDays(DateTime.DaysInMonth(q.ClosingDate.Year, q.ClosingDate.AddMonths(1).Month));
                    }
                    else {
                        closingDate = q.ClosingDate.AddMonths(1);
                    }
                }

                model.StatementNo = statementNo;
                model.OpeningBalance = openingBalance;
                model.ClosingDate = closingDate;

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankAccountStatement_GetDefaults", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Calypso Companies
        public IActionResult CalypsoCompanies() {
            return View();
        }

        public async Task<IActionResult> CalypsoCompany_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.CalypsoCompany.OrderBy(t => t.Code);

                var result = await q.Select(row => new CalypsoCompanyViewModel {
                    CalypsoCompanyId = row.Id,
                    Code = row.Code,
                    Name = row.Name,
                    CreditorAirId = row.CreditorAirId,
                    SupplierAirId = row.SupplierAirId,
                    CreditorLandId = row.CreditorLandId,
                    SupplierLandId = row.SupplierLandId,
                    CreditorAir = row.CreditorAirId <= 0 ? string.Empty : row.CreditorAir.Name,
                    SupplierAir = row.SupplierAirId <= 0 ? string.Empty : row.SupplierAir.Name,
                    CreditorLand = row.CreditorLandId <= 0 ? string.Empty : row.CreditorLand.Name,
                    SupplierLand = row.SupplierLandId <= 0 ? string.Empty : row.SupplierLand.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CalypsoCompany_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CalypsoCompany_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, CalypsoCompanyViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                CalypsoCompany q = null;

                if (model.CalypsoCompanyId <= 0) {
                    throw new UnreportedException("New record cannot be created.");
                }
                else {
                    q = context.CalypsoCompany.Find(model.CalypsoCompanyId);
                }

                q.CreditorAirId = model.CreditorAirId ?? 0;
                q.SupplierAirId = model.SupplierAirId ?? 0;
                q.CreditorLandId = model.CreditorLandId ?? 0;
                q.SupplierLandId = model.SupplierLandId ?? 0;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.CalypsoCompanyId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CalypsoCompany_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Cancel Reasons
        public IActionResult CancelReasons() {
            return View();
        }

        public async Task<IActionResult> CancelReason_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.CancelReason.OrderBy(t => t.Name);

                var result = await q.Select(row => new CancelReasonViewModel {
                    CancelReasonId = row.Id,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CancelReason_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CancelReason_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, CancelReasonViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                CancelReason q = null;

                if (model.CancelReasonId <= 0) {
                    q = new CancelReason();
                }
                else {
                    q = context.CancelReason.Find(model.CancelReasonId);
                }

                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.CancelReasonId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CancelReason_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CancelReason_Delete([DataSourceRequest] DataSourceRequest request, CancelReasonViewModel model) {
            try {
                var context = Context;
                var q = context.CancelReason.Find(model.CancelReasonId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CancelReason_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Categories
        public IActionResult Categories() {
            return View();
        }

        public async Task<IActionResult> Category_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Category.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new CategoryViewModel {
                    CategoryId = row.Id,
                    Name = row.Name,
                    DocumentComment = row.DocumentComment,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Category_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Category_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, CategoryViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Category q = null;

                if (model.CategoryId <= 0) {
                    q = new Category();
                }
                else {
                    q = context.Category.Find(model.CategoryId);
                }

                q.Name = model.Name;
                q.DocumentComment = model.DocumentComment;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.CategoryId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Category_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Category_Delete([DataSourceRequest] DataSourceRequest request, CategoryViewModel model) {
            try {
                var context = Context;
                var q = context.Category.Find(model.CategoryId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Category_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Classes
        public IActionResult Classes() {
            return View();
        }

        public async Task<IActionResult> Class_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Class.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new ClassViewModel {
                    ClassId = row.Id,
                    Name = row.Name,
                    ClassType = row.ClassType,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Class_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Class_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ClassViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Class q = null;

                if (model.ClassId <= 0) {
                    q = new Class();
                }
                else {
                    q = context.Class.Find(model.ClassId);
                }

                q.Name = model.Name;
                q.ClassType = model.ClassType;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ClassId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Class_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Class_Delete([DataSourceRequest] DataSourceRequest request, ClassViewModel model) {
            try {
                var context = Context;
                var q = context.Class.Find(model.ClassId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Class_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Club Memberships
        public IActionResult ClubMemberships() {
            return View();
        }

        public async Task<IActionResult> ClubMembership_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.ClubMembership.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new ClubMembershipViewModel {
                    ClubMembershipId = row.Id,
                    Name = row.Name,
                    CrsCode = row.CrsCode,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ClubMembership_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ClubMembership_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ClubMembershipViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                ClubMembership q = null;

                if (model.ClubMembershipId <= 0) {
                    q = new ClubMembership();
                }
                else {
                    q = context.ClubMembership.Find(model.ClubMembershipId);
                }

                q.Name = model.Name;
                q.CrsCode = model.CrsCode.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ClubMembershipId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ClubMembership_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ClubMembership_Delete([DataSourceRequest] DataSourceRequest request, ClubMembershipViewModel model) {
            try {
                var context = Context;
                var q = context.ClubMembership.Find(model.ClubMembershipId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ClubMembership_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Conditions
        public IActionResult Conditions() {
            return View();
        }

        public async Task<IActionResult> Condition_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Condition.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new ConditionViewModel {
                    ConditionId = row.Id,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Condition_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Condition_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ConditionViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Condition q = null;

                if (model.ConditionId <= 0) {
                    q = new Condition();
                }
                else {
                    q = context.Condition.Find(model.ConditionId);
                }

                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ConditionId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Condition_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Condition_Delete([DataSourceRequest] DataSourceRequest request, ConditionViewModel model) {
            try {
                var context = Context;
                var q = context.Condition.Find(model.ConditionId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Condition_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Consultants
        public IActionResult Consultants() {
            return View();
        }

        public async Task<IActionResult> Consultant_Read([DataSourceRequest] DataSourceRequest request, int agencyId = -1) {
            try {
                var q = Context.Consultant.Include(t => t.ConsultantAgencies).Where(t => t.Id > 0);

                if (agencyId > 0)
                    q = q.Where(t1 => t1.ConsultantAgencies.Any(t2 => t2.AgencyId == agencyId));

                var result = await q.OrderBy(t => t.Name).Select(row => new ConsultantViewModel {
                    ConsultantId = row.Id,
                    ConsultantName = row.Name,
                    JobTitle = row.JobTitle,
                    AmadeusCode = row.AmadeusCode,
                    Inactive = row.Inactive,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Consultant_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Consultant_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ConsultantViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Consultant q = null;

                if (model.ConsultantId <= 0) {
                    q = new Consultant();
                }
                else {
                    q = context.Consultant.Find(model.ConsultantId);
                }

                q.Name = model.ConsultantName;
                q.JobTitle = model.JobTitle.ToStringExt();
                q.AmadeusCode = model.AmadeusCode.ToStringExt().ToUpper();
                q.Inactive = model.Inactive;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ConsultantId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Consultant_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Consultant_Delete([DataSourceRequest] DataSourceRequest request, ConsultantViewModel model) {
            try {
                var adminContext = AdminContext;
                var context = Context;

                var q = context.Consultant.Include(t => t.ConsultantAgencies).Include(t => t.ConsultantMargins).SingleOrDefault(t => t.Id == model.ConsultantId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (adminContext.AspNetUsers.Any(t => t.CurrentConsultantId == model.ConsultantId) || adminContext.AspNetUserRoles.Any(t => t.ConsultantId == model.ConsultantId))
                    throw new UnreportedException(AppConstants.SqlReferenceConstraintDelete);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Consultant_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ConsultantAgency_Read([DataSourceRequest] DataSourceRequest request, int parentId, bool isExport) {
            try {
                var q = Context.ConsultantAgency.Include(t => t.Consultant).Include(t => t.Agency).Where(t => t.ConsultantId > 0);

                if (isExport) {
                    var export = q.OrderBy(t => t.Consultant.Name).ThenBy(t => t.Agency.Name).Select(row => new ConsultantAgencyExportModel {
                        Consultant = row.Consultant.Name,
                        Agency = row.Agency.Name
                    }).ToList();

                    var xlsx = new ExportToExcel<ConsultantAgencyExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Consultant Agencies.xlsx");
                }

                var result = await q.Where(t => t.ConsultantId == parentId).OrderBy(t => t.Agency.Name).Select(row => new ConsultantAgencyViewModel {
                    ConsultantAgencyId = row.Id,
                    ConsultantId = row.ConsultantId,
                    AgencyId = row.AgencyId,
                    IsDefault = row.IsDefault,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ConsultantAgency_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConsultantAgency_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ConsultantAgencyViewModel model, int parentId) {
            try {
                model.ConsultantId = parentId;

                ModelState.Clear();
                TryValidateModel(model);

                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                ConsultantAgency q = null;

                if (model.ConsultantAgencyId <= 0) {
                    q = new ConsultantAgency();
                }
                else {
                    q = context.ConsultantAgency.Find(model.ConsultantAgencyId);
                }

                q.ConsultantId = model.ConsultantId ?? 0;
                q.AgencyId = model.AgencyId ?? 0;
                q.IsDefault = model.IsDefault;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ConsultantAgencyId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ConsultantAgency_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConsultantAgency_Delete([DataSourceRequest] DataSourceRequest request, ConsultantAgencyViewModel model) {
            try {
                var context = Context;
                var q = context.ConsultantAgency.Find(model.ConsultantAgencyId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ConsultantAgency_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ConsultantMargin_Read([DataSourceRequest] DataSourceRequest request, int parentId, bool isExport) {
            try {
                var q = Context.ConsultantMargin.Where(t => t.ConsultantId > 0);

                if (isExport) {
                    var export = q.OrderBy(t => t.Consultant.Name).ThenBy(t => t.SaleType.Name).Select(row => new ConsultantMarginExportModel {
                        Consultant = row.Consultant.Name,
                        SaleType = row.SaleType.Name,
                        SellMarginMin = row.SellMarginMin
                    }).ToList();

                    var xlsx = new ExportToExcel<ConsultantMarginExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Consultant Margins.xlsx");
                }

                var result = await q.Where(t => t.ConsultantId == parentId).OrderBy(t => t.SaleType.Name).Select(row => new ConsultantMarginViewModel {
                    ConsultantMarginId = row.Id,
                    ConsultantId = row.ConsultantId,
                    SaleTypeId = row.SaleTypeId,
                    SellMarginMin = row.SellMarginMin,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ConsultantMargin_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConsultantMargin_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ConsultantMarginViewModel model, int parentId) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                ConsultantMargin q = null;

                if (model.ConsultantMarginId <= 0) {
                    q = new ConsultantMargin();
                }
                else {
                    q = context.ConsultantMargin.Find(model.ConsultantMarginId);
                }

                q.ConsultantId = parentId;
                q.SaleTypeId = model.SaleTypeId ?? 0;
                q.SellMarginMin = model.SellMarginMin;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ConsultantMarginId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ConsultantMargin_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConsultantMargin_Delete([DataSourceRequest] DataSourceRequest request, ConsultantMarginViewModel model) {
            try {
                var context = Context;
                var q = context.ConsultantMargin.Find(model.ConsultantMarginId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ConsultantMargin_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Contact Titles
        public IActionResult ContactTitles() {
            return View();
        }

        public async Task<IActionResult> ContactTitle_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.ContactTitle.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new ContactTitleViewModel {
                    ContactTitleId = row.Id,
                    Name = row.Name,
                    Gender = row.Gender,
                    CrsCode = row.CrsCode,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ContactTitle_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ContactTitle_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ContactTitleViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                ContactTitle q = null;

                if (model.ContactTitleId <= 0) {
                    q = new ContactTitle();
                }
                else {
                    q = context.ContactTitle.Find(model.ContactTitleId);
                }

                q.Name = model.Name;
                q.Gender = model.Gender;
                q.CrsCode = model.CrsCode.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ContactTitleId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ContactTitle_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ContactTitle_Delete([DataSourceRequest] DataSourceRequest request, ContactTitleViewModel model) {
            try {
                var context = Context;
                var q = context.ContactTitle.Find(model.ContactTitleId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ContactTitle_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Countries
        public IActionResult Countries() {
            return View();
        }

        public async Task<IActionResult> Country_Read([DataSourceRequest] DataSourceRequest request, string cityCode) {
            try {
                var q = Context.Country.Include(t => t.Cities).Where(t => t.Id > 0);

                if (!string.IsNullOrEmpty(cityCode?.Trim()))
                    q = q.Where(t1 => t1.Cities.Any(t2 => t2.Code.ToLower() == cityCode.Trim().ToLower()));

                var result = await q.OrderBy(t => t.Name).Select(row => new CountryViewModel {
                    CountryId = row.Id,
                    Code = row.Code,
                    Name = row.Name,
                    CountryZone = row.CountryZone,
                    CurrencyId = row.CurrencyId,
                    Currency = row.CurrencyId <= 0 ? string.Empty : row.Currency.Name,
                    IsoCode = row.IsoCode,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Country_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Country_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, CountryViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Country q = null;

                if (model.CountryId <= 0) {
                    q = new Country();
                }
                else {
                    q = context.Country.Find(model.CountryId);
                }

                q.Code = Utils.RemoveExtraSpaces(model.Code).Replace(" ", string.Empty).ToUpper();
                q.Name = model.Name;
                q.CountryZone = model.CountryZone;
                q.CurrencyId = model.CurrencyId ?? 0;
                q.IsoCode = model.IsoCode;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.CountryId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Country_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Country_Delete([DataSourceRequest] DataSourceRequest request, CountryViewModel model) {
            try {
                var context = Context;
                var q = context.Country.Include(t => t.Cities).SingleOrDefault(t => t.Id == model.CountryId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Country_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Country_GetCountryId(string country) {
            try {
                int id = Context.Country.SingleOrDefault(t => t.Name.ToLower() == country.ToLower())?.Id ?? 0;
                return Json(id);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Country_GetCountryId", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Country_GetCountryCode(string isoCode) {
            try {
                string code = Context.Country.SingleOrDefault(t => t.IsoCode.ToLower() == isoCode.ToLower())?.Code ?? string.Empty;
                return Json(code);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Country_GetCountryCode", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> City_Read([DataSourceRequest] DataSourceRequest request, int parentId, bool isExport) {
            try {
                var q = Context.City.Where(t => t.Id > 0 && t.CountryId > 0);

                if (isExport) {
                    var export = q.OrderBy(t => t.Country.Name).ThenBy(t => t.Code).Select(row => new CityExportModel {
                        Country = row.Country.Name,
                        CityCode = row.Code,
                        CityName = row.Name,
                        HasAirport = row.HasAirport
                    }).ToList();

                    var xlsx = new ExportToExcel<CityExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Cities.xlsx");
                }

                var result = await q.Where(t => t.Id > 0 && t.CountryId == parentId).OrderBy(t => t.Name).Select(row => new CityViewModel {
                    CityId = row.Id,
                    CountryId = row.CountryId,
                    CityCode = row.Code,
                    Name = row.Name,
                    HasAirport = row.HasAirport,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "City_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> City_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, CityViewModel model, int parentId) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                City q = null;

                if (model.CityId <= 0) {
                    q = new City();
                }
                else {
                    q = context.City.Find(model.CityId);
                }

                q.CountryId = parentId;
                q.Code = model.CityCode.ToUpper();
                q.Name = model.Name;
                q.HasAirport = model.HasAirport;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.CityId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "City_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> City_Delete([DataSourceRequest] DataSourceRequest request, CityViewModel model) {
            try {
                var context = Context;
                var q = context.City.Find(model.CityId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "City_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region CRS Remarks
        public IActionResult CrsRemarks() {
            return View();
        }

        public async Task<IActionResult> CrsRemark_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.CrsRemark.OrderBy(t => t.Name);

                var result = await q.Select(row => new CrsRemarkViewModel {
                    CrsRemarkId = row.Id,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsRemark_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsRemark_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, CrsRemarkViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                CrsRemark q = null;

                if (model.CrsRemarkId <= 0) {
                    q = new CrsRemark();
                }
                else {
                    q = context.CrsRemark.Find(model.CrsRemarkId);
                }

                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.CrsRemarkId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsRemark_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrsRemark_Delete([DataSourceRequest] DataSourceRequest request, CrsRemarkViewModel model) {
            try {
                var context = Context;
                var q = context.CrsRemark.Find(model.CrsRemarkId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CrsRemark_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Currencies
        public IActionResult Currencies() {
            return View();
        }

        public async Task<IActionResult> Currency_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Currency.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new CurrencyViewModel {
                    CurrencyId = row.Id,
                    Code = row.Code,
                    Name = row.Name,
                    Rate = row.Rate,
                    OfficialRate = row.OfficialRate,
                    ExchangeRateType = row.ExchangeRateType,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Currency_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Currency_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, CurrencyViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Currency q = null;

                if (model.CurrencyId <= 0) {
                    q = new Currency {
                        Id = 0,
                        OfficialRate = 0
                    };
                }
                else {
                    q = context.Currency.Find(model.CurrencyId);
                }

                decimal margin = AppSettings.Setting(HttpContext.CurrentCustomerId()).ExchangeRateMargin / 100;

                if (margin != 0 && model.ExchangeRateType == ExchangeRateType.Relative && model.Rate != 0 && q.OfficialRate != 0) {
                    if (model.Rate * (1 + margin) > q.OfficialRate) {
                        model.Rate = q.OfficialRate * (1 + margin);
                    }
                    else if (model.Rate * (1 - margin) < q.OfficialRate) {
                        model.Rate = q.OfficialRate * (1 - margin);
                    }
                }

                q.Code = Utils.RemoveExtraSpaces(model.Code).Replace(" ", string.Empty).ToUpper();
                q.Name = model.Name;
                q.Rate = Math.Round(model.Rate, 4);
                q.ExchangeRateType = model.ExchangeRateType;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.CurrencyId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Currency_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Currency_Delete([DataSourceRequest] DataSourceRequest request, CurrencyViewModel model) {
            try {
                var context = Context;
                var q = context.Currency.Find(model.CurrencyId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Currency_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Currency_GetExchangeRate(int currencyId) {
            try {
                return Json(Currency.GetExchangeRate(Context, currencyId));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Currency_GetExchangeRate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Destinations
        public IActionResult Destinations() {
            return View();
        }

        public async Task<IActionResult> Destination_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Destination.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new DestinationViewModel {
                    DestinationId = row.Id,
                    Name = row.Name,
                    StandardCommentId = row.StandardCommentId,
                    StandardComment = row.StandardCommentId <= 0 ? string.Empty : row.StandardComment.Code,
                    RegionId = row.RegionId,
                    Region = row.RegionId <= 0 ? string.Empty : row.Region.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Destination_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Destination_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, DestinationViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Destination q = null;

                if (model.DestinationId <= 0) {
                    q = new Destination();
                }
                else {
                    q = context.Destination.Find(model.DestinationId);
                }

                q.Name = model.Name;
                q.StandardCommentId = model.StandardCommentId ?? 0;
                q.RegionId = model.RegionId ?? 0;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.DestinationId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Destination_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Destination_Delete([DataSourceRequest] DataSourceRequest request, DestinationViewModel model) {
            try {
                var context = Context;
                var q = context.Destination.Find(model.DestinationId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Destination_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Discount Reasons
        public IActionResult DiscountReasons() {
            return View();
        }

        public async Task<IActionResult> DiscountReason_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.DiscountReason.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new DiscountReasonViewModel {
                    DiscountReasonId = row.Id,
                    Name = row.Name,
                    ChartOfAccountId = row.ChartOfAccountId,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DiscountReason_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DiscountReason_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, DiscountReasonViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                DiscountReason q = null;

                if (model.DiscountReasonId <= 0) {
                    q = new DiscountReason();
                }
                else {
                    q = context.DiscountReason.Find(model.DiscountReasonId);
                }

                if (model.ChartOfAccountId != q.ChartOfAccountId && !ChartOfAccount.IsInRole(Context, model.ChartOfAccountId ?? 0, HttpContext.RoleId()))
                    throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                q.Name = model.Name;
                q.ChartOfAccountId = model.ChartOfAccountId ?? 0;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.DiscountReasonId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DiscountReason_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DiscountReason_Delete([DataSourceRequest] DataSourceRequest request, DiscountReasonViewModel model) {
            try {
                var context = Context;
                var q = context.DiscountReason.Find(model.DiscountReasonId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DiscountReason_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Embassies
        public IActionResult Embassies() {
            return View();
        }

        public async Task<IActionResult> Embassy_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Embassy.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new EmbassyViewModel {
                    EmbassyId = row.Id,
                    Name = row.Name,
                    Address = row.Address,
                    Address1 = row.Address1,
                    Address2 = row.Address2,
                    Locality = row.Locality,
                    Region = row.Region,
                    PostCode = row.PostCode,
                    CountryCode = row.CountryCode,
                    PhoneWork = row.PhoneWork,
                    Fax = row.Fax,
                    Email = row.Email,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Embassy_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Embassy_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, EmbassyViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Embassy q = null;

                if (model.EmbassyId <= 0) {
                    q = new Embassy();
                }
                else {
                    q = context.Embassy.Find(model.EmbassyId);
                }

                q.Name = model.Name;
                q.Address1 = model.Address1.ToStringExt();
                q.Address2 = model.Address2.ToStringExt();
                q.Locality = model.Locality.ToStringExt();
                q.Region = model.Region.ToStringExt();
                q.PostCode = model.PostCode.ToStringExt();
                q.CountryCode = model.CountryCode.ToStringExt();
                q.PhoneWork = model.PhoneWork.ToStringExt();
                q.Fax = model.Fax.ToStringExt();
                q.Email = model.Email.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.EmbassyId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Embassy_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Embassy_Delete([DataSourceRequest] DataSourceRequest request, EmbassyViewModel model) {
            try {
                var context = Context;
                var q = context.Embassy.Find(model.EmbassyId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Embassy_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Forms of Payment
        public IActionResult FormsOfPayment() {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> FormOfPayment_Edit(int formOfPaymentId) {
            try {
                FormOfPayment q = null;

                if (formOfPaymentId <= 0) {
                    q = new FormOfPayment {
                        CreditorId = -1,
                        DebtorId = -1,
                        DefaultSupplierId = -1,
                        CreditCardChartOfAccountId = -1,
                        CreditCardSaleTypeId = -1,
                        CreditCardLoyaltySchemeId = -1,
                        LoyaltySchemeSaleType1Id = -1,
                        LoyaltySchemeSaleType2Id = -1,
                        LoyaltySchemeCategoryId = -1,
                        LoyaltySchemeDestinationId = -1,
                        LoyaltySchemeConsultantId = -1,
                        LoyaltySchemeSourceId = -1
                    };
                }
                else {
                    q = LazyContext.FormOfPayment.Find(formOfPaymentId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);
                }

                var model = new FormOfPaymentViewModel {
                    FormOfPaymentId = q.Id,
                    Name = q.Name,
                    FormOfPaymentType = q.FormOfPaymentType,
                    IncludeInDeposit = q.IncludeInDeposit,
                    DoNotGenerateInvoiceLine = q.DoNotGenerateInvoiceLine,
                    CreditorId = q.CreditorId,
                    DebtorId = q.DebtorId,
                    DefaultSupplierId = q.DefaultSupplierId,
                    MerchantFeeRate = q.MerchantFeeRate,
                    MerchantFeeReducesCommission = q.MerchantFeeReducesCommission,
                    CreditCardChartOfAccountId = q.CreditCardChartOfAccountId,
                    CreditCardSaleTypeId = q.CreditCardSaleTypeId,
                    CreditCardLoyaltySchemeId = q.CreditCardLoyaltySchemeId,
                    CreditCardLoyaltySchemeIsLocked = q.CreditCardLoyaltySchemeIsLocked,
                    LoyaltySchemePointsRoundingMethod = q.LoyaltySchemePointsRoundingMethod,
                    LoyaltySchemePointValue = q.LoyaltySchemePointValue,
                    LoyaltySchemeSaleType1Id = q.LoyaltySchemeSaleType1Id,
                    LoyaltySchemePointCost1 = q.LoyaltySchemePointCost1,
                    LoyaltySchemeSaleType2Id = q.LoyaltySchemeSaleType2Id,
                    LoyaltySchemePointCost2 = q.LoyaltySchemePointCost2,
                    LoyaltySchemeCategoryId = q.LoyaltySchemeCategoryId,
                    LoyaltySchemeDestinationId = q.LoyaltySchemeDestinationId,
                    LoyaltySchemeConsultantId = q.LoyaltySchemeConsultantId,
                    LoyaltySchemeSourceId = q.LoyaltySchemeSourceId,
                    LoyaltySchemeExcludeOnReceipt = q.LoyaltySchemeExcludeOnReceipt,
                    LoyaltySchemeValueIsReceiptAmount = q.LoyaltySchemeValueIsReceiptAmount,
                    LoyaltySchemeValueIsLocked = q.LoyaltySchemeValueIsLocked,
                    LoyaltySchemeCostIsLocked = q.LoyaltySchemeCostIsLocked
                };

                return PartialView("~/Views/Common/EditorTemplates/FormOfPaymentEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FormOfPayment_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> FormOfPayment_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = LazyContext.FormOfPayment.Where(t => t.Id > 0).OrderBy(t => t.Name).AsEnumerable();

                var result = await q.Select(row => new FormOfPaymentViewModel {
                    FormOfPaymentId = row.Id,
                    Name = row.Name,
                    FormOfPaymentType = row.FormOfPaymentType,
                    IncludeInDeposit = row.IncludeInDeposit,
                    DoNotGenerateInvoiceLine = row.DoNotGenerateInvoiceLine,
                    CreditorId = row.CreditorId,
                    Creditor = row.Creditor.Name,
                    DebtorId = row.DebtorId,
                    Debtor = row.Debtor.Name,
                    DefaultSupplierId = row.DefaultSupplierId,
                    DefaultSupplier = row.DefaultSupplier.Name,
                    MerchantFeeRate = row.MerchantFeeRate,
                    MerchantFeeReducesCommission = row.MerchantFeeReducesCommission,
                    CreditCardChartOfAccountId = row.CreditCardChartOfAccountId,
                    CreditCardChartOfAccount = row.CreditCardChartOfAccount.Name,
                    CreditCardSaleTypeId = row.CreditCardSaleTypeId,
                    CreditCardSaleType = row.CreditCardSaleType.Name,
                    CreditCardLoyaltySchemeId = row.CreditCardLoyaltySchemeId,
                    CreditCardLoyaltyScheme = row.CreditCardLoyaltyScheme.Name,
                    CreditCardLoyaltySchemeIsLocked = row.CreditCardLoyaltySchemeIsLocked,
                    LoyaltySchemePointsRoundingMethod = row.LoyaltySchemePointsRoundingMethod,
                    LoyaltySchemePointValue = row.LoyaltySchemePointValue,
                    LoyaltySchemeSaleType1Id = row.LoyaltySchemeSaleType1Id,
                    LoyaltySchemeSaleType1 = row.LoyaltySchemeSaleType1.Name,
                    LoyaltySchemePointCost1 = row.LoyaltySchemePointCost1,
                    LoyaltySchemeSaleType2Id = row.LoyaltySchemeSaleType2Id,
                    LoyaltySchemeSaleType2 = row.LoyaltySchemeSaleType2.Name,
                    LoyaltySchemePointCost2 = row.LoyaltySchemePointCost2,
                    LoyaltySchemeCategoryId = row.LoyaltySchemeCategoryId,
                    LoyaltySchemeCategory = row.LoyaltySchemeCategory.Name,
                    LoyaltySchemeDestinationId = row.LoyaltySchemeDestinationId,
                    LoyaltySchemeDestination = row.LoyaltySchemeDestination.Name,
                    LoyaltySchemeConsultantId = row.LoyaltySchemeConsultantId,
                    LoyaltySchemeConsultant = row.LoyaltySchemeConsultant.Name,
                    LoyaltySchemeSourceId = row.LoyaltySchemeSourceId,
                    LoyaltySchemeSource = row.LoyaltySchemeSource.Name,
                    LoyaltySchemeExcludeOnReceipt = row.LoyaltySchemeExcludeOnReceipt,
                    LoyaltySchemeValueIsReceiptAmount = row.LoyaltySchemeValueIsReceiptAmount,
                    LoyaltySchemeValueIsLocked = row.LoyaltySchemeValueIsLocked,
                    LoyaltySchemeCostIsLocked = row.LoyaltySchemeCostIsLocked,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FormOfPayment_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> FormOfPayment_CreateOrUpdate(FormOfPaymentViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;

                if (model.DebtorId > 0 && context.FormOfPayment.Any(t => t.Id != model.FormOfPaymentId && t.DebtorId == model.DebtorId))
                    throw new UnreportedException("The selected Debtor is already assigned to another Form of Payment.");

                FormOfPayment q = null;

                if (model.FormOfPaymentId <= 0) {
                    q = new FormOfPayment();
                }
                else {
                    q = context.FormOfPayment.Find(model.FormOfPaymentId);
                }

                if (model.CreditCardChartOfAccountId != q.CreditCardChartOfAccountId && !ChartOfAccount.IsInRole(context, model.CreditCardChartOfAccountId ?? 0, HttpContext.RoleId()))
                    throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                q.Name = model.Name;
                q.FormOfPaymentType = model.FormOfPaymentType;
                q.IncludeInDeposit = model.IncludeInDeposit;
                q.DoNotGenerateInvoiceLine = model.DoNotGenerateInvoiceLine;

                if (model.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || model.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || model.FormOfPaymentType == FormOfPaymentType.ClearingHouseNet || model.FormOfPaymentType == FormOfPaymentType.ClearingHouseGross || model.FormOfPaymentType == FormOfPaymentType.PaySupplierGross || model.FormOfPaymentType == FormOfPaymentType.LoyaltyScheme) {
                    if (model.FormOfPaymentType == FormOfPaymentType.PaySupplierGross && model.CreditorId <= 0)
                        throw new UnreportedException("Creditor is required for this Form of Payment Type.");

                    q.CreditorId = model.CreditorId ?? 0;
                    q.DefaultSupplierId = model.DefaultSupplierId ?? 0;

                    if (model.FormOfPaymentType == FormOfPaymentType.LoyaltyScheme) {
                        if (model.LoyaltySchemePointValue == 0)
                            throw new UnreportedException("Value of a Point is required.");

                        if (model.LoyaltySchemeSaleType1Id <= 0)
                            throw new UnreportedException("Type of Sale 1 is required.");

                        if (model.LoyaltySchemePointCost1 == 0)
                            throw new UnreportedException("Cost per Point for Type of Sale 1 is required.");

                        if (model.LoyaltySchemeSaleType2Id > 0) {
                            if (model.LoyaltySchemePointCost2 == 0)
                                throw new UnreportedException("Cost per Point for Type of Sale 2 is required.");

                            if (context.SaleType.Find(model.LoyaltySchemeSaleType1Id).IsTaxApplicable == context.SaleType.Find(model.LoyaltySchemeSaleType2Id).IsTaxApplicable)
                                throw new UnreportedException("When two Types of Sale are selected, one must be taxable and the other non-taxable.");
                        }

                        if (model.CreditorId <= 0)
                            throw new UnreportedException("Creditor is required.");

                        if (model.DefaultSupplierId <= 0)
                            throw new UnreportedException("Default Supplier is required.");

                        if (model.LoyaltySchemeSourceId <= 0)
                            throw new UnreportedException("Source is required.");

                        if (model.LoyaltySchemeCategoryId <= 0)
                            throw new UnreportedException("Category is required.");

                        if (model.LoyaltySchemeDestinationId <= 0)
                            throw new UnreportedException("Destination is required.");

                        if (model.LoyaltySchemeConsultantId <= 0)
                            throw new UnreportedException("Consultant is required.");
                    }
                }
                else {
                    q.CreditorId = -1;
                    q.DefaultSupplierId = -1;
                }

                if (model.FormOfPaymentType == FormOfPaymentType.CreditCard) {
                    q.DebtorId = model.DebtorId ?? 0;
                    q.MerchantFeeRate = model.MerchantFeeRate / 100;
                    q.CreditCardChartOfAccountId = model.CreditCardChartOfAccountId ?? 0;
                    q.CreditCardSaleTypeId = model.CreditCardSaleTypeId ?? 0;
                    q.CreditCardLoyaltySchemeId = model.CreditCardLoyaltySchemeId ?? 0;
                    q.MerchantFeeReducesCommission = model.MerchantFeeReducesCommission;
                    q.CreditCardLoyaltySchemeIsLocked = model.CreditCardLoyaltySchemeIsLocked;
                }
                else {
                    q.DebtorId = -1;
                    q.MerchantFeeRate = 0;
                    q.CreditCardChartOfAccountId = -1;
                    q.CreditCardSaleTypeId = -1;
                    q.CreditCardLoyaltySchemeId = -1;
                    q.MerchantFeeReducesCommission = false;
                    q.CreditCardLoyaltySchemeIsLocked = false;
                }

                if (model.FormOfPaymentType == FormOfPaymentType.LoyaltyScheme) {
                    q.LoyaltySchemePointValue = model.LoyaltySchemePointValue;
                    q.LoyaltySchemePointsRoundingMethod = model.LoyaltySchemePointsRoundingMethod;
                    q.LoyaltySchemeSaleType1Id = model.LoyaltySchemeSaleType1Id ?? 0;
                    q.LoyaltySchemePointCost1 = model.LoyaltySchemePointCost1;
                    q.LoyaltySchemeSaleType2Id = model.LoyaltySchemeSaleType2Id ?? 0;
                    q.LoyaltySchemePointCost2 = model.LoyaltySchemePointCost2;
                    q.LoyaltySchemeCategoryId = model.LoyaltySchemeCategoryId ?? 0;
                    q.LoyaltySchemeDestinationId = model.LoyaltySchemeDestinationId ?? 0;
                    q.LoyaltySchemeConsultantId = model.LoyaltySchemeConsultantId ?? 0;
                    q.LoyaltySchemeSourceId = model.LoyaltySchemeSourceId ?? 0;
                    q.LoyaltySchemeExcludeOnReceipt = model.LoyaltySchemeExcludeOnReceipt;
                    q.LoyaltySchemeValueIsReceiptAmount = model.LoyaltySchemeValueIsReceiptAmount;
                    q.LoyaltySchemeValueIsLocked = model.LoyaltySchemeValueIsLocked;
                    q.LoyaltySchemeCostIsLocked = model.LoyaltySchemeCostIsLocked;
                }
                else {
                    q.LoyaltySchemePointValue = 0;
                    q.LoyaltySchemePointsRoundingMethod = LoyaltySchemePointsRoundingMethod.None;
                    q.LoyaltySchemeSaleType1Id = -1;
                    q.LoyaltySchemePointCost1 = 0;
                    q.LoyaltySchemeSaleType2Id = -1;
                    q.LoyaltySchemePointCost2 = 0;
                    q.LoyaltySchemeCategoryId = -1;
                    q.LoyaltySchemeDestinationId = -1;
                    q.LoyaltySchemeConsultantId = -1;
                    q.LoyaltySchemeSourceId = -1;
                    q.LoyaltySchemeExcludeOnReceipt = false;
                    q.LoyaltySchemeValueIsReceiptAmount = false;
                    q.LoyaltySchemeValueIsLocked = false;
                    q.LoyaltySchemeCostIsLocked = false;
                }

                if (q.DebtorId <= 0)
                    q.MerchantFeeRate = 0;

                if (q.MerchantFeeReducesCommission && q.CreditCardSaleTypeId <= 0)
                    throw new UnreportedException("Type of Sale is required when Merchant Fee Reduces Commission on Trip is checked.");

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.FormOfPaymentId = q.Id;
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FormOfPayment_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> FormOfPayment_Delete(FormOfPaymentViewModel model) {
            try {
                var context = Context;
                var q = context.FormOfPayment.Include(t => t.FormOfPaymentCrs).SingleOrDefault(t => t.Id == model.FormOfPaymentId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FormOfPayment_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> FormOfPaymentCrs(int parentId) {
            try {
                ViewBag.ParentId = parentId;
                return PartialView("~/Views/Common/EditorTemplates/FormOfPaymentCrsEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FormOfPaymentCrs", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> FormOfPaymentCrs_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.FormOfPaymentCrs.Where(t => t.FormOfPaymentId == parentId).OrderBy(t => t.Crs);

                var result = await q.Select(row => new FormOfPaymentCrsViewModel {
                    FormOfPaymentCrsId = row.Id,
                    FormOfPaymentId = row.FormOfPaymentId,
                    Crs = row.Crs,
                    CrsCode = row.CrsCode,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FormOfPaymentCrs_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> FormOfPaymentCrs_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, FormOfPaymentCrsViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                FormOfPaymentCrs q = null;

                if (model.FormOfPaymentCrsId <= 0) {
                    q = new FormOfPaymentCrs();
                }
                else {
                    q = context.FormOfPaymentCrs.Find(model.FormOfPaymentCrsId);
                }

                q.FormOfPaymentId = model.FormOfPaymentId;
                q.Crs = model.Crs;
                q.CrsCode = model.CrsCode.ToUpper();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.FormOfPaymentCrsId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FormOfPaymentCrs_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> FormOfPaymentCrs_Delete([DataSourceRequest] DataSourceRequest request, FormOfPaymentCrsViewModel model) {
            try {
                var context = Context;
                var q = context.FormOfPaymentCrs.Find(model.FormOfPaymentCrsId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FormOfPaymentCrs_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> FormOfPayment_ExportExcel() {
            try {
                var q = Context.FormOfPayment.Where(t => t.Id > 0).OrderBy(t => t.Name).Select(row => new FormOfPaymentExportModel {
                    FormOfPayment = row.Name,
                    FormOfPaymentType = row.FormOfPaymentType.GetEnumDescription(),
                    IncludeInDeposit = row.IncludeInDeposit,
                    DoNotGenerateInvoiceLine = row.DoNotGenerateInvoiceLine,
                    Creditor = row.Creditor.Name,
                    Debtor = row.Debtor.Name,
                    DefaultSupplier = row.DefaultSupplier.Name,
                    MerchantFeeRate = row.MerchantFeeRate,
                    MerchantFeeReducesCommission = row.MerchantFeeReducesCommission,
                    CreditCardGLAccount = row.CreditCardChartOfAccount.Name,
                    CreditCardSaleType = row.CreditCardSaleType.Name,
                    CreditCardLoyaltyScheme = row.CreditCardLoyaltyScheme.Name,
                    CreditCardLoyaltySchemeIsLocked = row.CreditCardLoyaltySchemeIsLocked,
                    LoyaltySchemePointValue = row.LoyaltySchemePointValue,
                    LoyaltySchemePointsRoundingMethod = row.LoyaltySchemePointsRoundingMethod.GetEnumDescription(),
                    LoyaltySchemeSaleType1 = row.LoyaltySchemeSaleType1.Name,
                    LoyaltySchemePointCost1 = row.LoyaltySchemePointCost1,
                    LoyaltySchemeSaleType2 = row.LoyaltySchemeSaleType2.Name,
                    LoyaltySchemePointCost2 = row.LoyaltySchemePointCost2,
                    LoyaltySchemeCategory = row.LoyaltySchemeCategory.Name,
                    LoyaltySchemeDestination = row.LoyaltySchemeDestination.Name,
                    LoyaltySchemeConsultant = row.LoyaltySchemeConsultant.Name,
                    LoyaltySchemeSource = row.LoyaltySchemeSource.Name,
                    LoyaltySchemeExcludeOnReceipt = row.LoyaltySchemeExcludeOnReceipt,
                    LoyaltySchemeValueIsReceiptAmount = row.LoyaltySchemeValueIsReceiptAmount,
                    LoyaltySchemeValueIsLocked = row.LoyaltySchemeValueIsLocked,
                    LoyaltySchemeCostIsLocked = row.LoyaltySchemeCostIsLocked
                }).ToList();

                var xlsx = new ExportToExcel<FormOfPaymentExportModel>(q);
                return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Forms of Payment.xlsx");
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FormOfPayment_ExportExcel", ex);
                return Redirect("/Shared/Error");
            }
        }
        #endregion

        #region Groups
        public IActionResult Groups() {
            return View();
        }

        public async Task<IActionResult> Group_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Group.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new GroupViewModel {
                    GroupId = row.Id,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Group_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Group_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, GroupViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Group q = null;

                if (model.GroupId <= 0) {
                    q = new Group();
                }
                else {
                    q = context.Group.Find(model.GroupId);
                }

                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.GroupId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Group_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Group_Delete([DataSourceRequest] DataSourceRequest request, GroupViewModel model) {
            try {
                var context = Context;
                var q = context.Group.Find(model.GroupId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Group_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Insurance
        public IActionResult Insurance() {
            return View();
        }

        public async Task<IActionResult> InsurancePolicy_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.InsurancePolicy.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new InsurancePolicyViewModel {
                    InsurancePolicyId = row.Id,
                    Name = row.Name,
                    SupplierId = row.SupplierId,
                    SupplierName = row.Supplier.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InsurancePolicy_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> InsurancePolicy_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, InsurancePolicyViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                InsurancePolicy q = null;

                if (model.InsurancePolicyId <= 0) {
                    q = new InsurancePolicy();
                }
                else {
                    q = context.InsurancePolicy.Find(model.InsurancePolicyId);
                }

                q.Name = model.Name;
                q.SupplierId = model.SupplierId ?? 0;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.InsurancePolicyId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InsurancePolicy_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> InsurancePolicy_Delete([DataSourceRequest] DataSourceRequest request, InsurancePolicyViewModel model) {
            try {
                var context = Context;
                var q = context.InsurancePolicy.Include(t => t.InsurancePolicyPlans).SingleOrDefault(t => t.Id == model.InsurancePolicyId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InsurancePolicy_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> InsurancePolicyPlan_Read([DataSourceRequest] DataSourceRequest request, int parentId, bool isExport) {
            try {
                var q = Context.InsurancePolicyPlan.Where(t => t.InsurancePolicyId > 0);

                if (isExport) {
                    var export = q.OrderBy(t => t.InsurancePolicy.Name).ThenBy(t => t.Name).Select(row => new InsurancePolicyPlanExportModel {
                        InsurancePolicy = row.InsurancePolicy.Name,
                        InsurancePlan = row.Name,
                        SaleType = row.SaleType.Name
                    }).ToList();

                    var xlsx = new ExportToExcel<InsurancePolicyPlanExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Insurance Plans.xlsx");
                }

                var result = await q.Where(t => t.InsurancePolicyId == parentId).OrderBy(t => t.Name).Select(row => new InsurancePolicyPlanViewModel {
                    InsurancePolicyPlanId = row.Id,
                    InsurancePolicyId = row.InsurancePolicyId,
                    InsurancePlanName = row.Name,
                    SaleTypeId = row.SaleTypeId,
                    SaleType = row.SaleTypeId <= 0 ? string.Empty : row.SaleType.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InsurancePolicyPlan_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> InsurancePolicyPlan_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, InsurancePolicyPlanViewModel model, int parentId) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                InsurancePolicyPlan q = null;

                if (model.InsurancePolicyPlanId <= 0) {
                    q = new InsurancePolicyPlan();
                }
                else {
                    q = context.InsurancePolicyPlan.Find(model.InsurancePolicyPlanId);
                }

                q.InsurancePolicyId = parentId;
                q.Name = model.InsurancePlanName;
                q.SaleTypeId = model.SaleTypeId ?? 0;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.InsurancePolicyPlanId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InsurancePolicyPlan_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> InsurancePolicyPlan_Delete([DataSourceRequest] DataSourceRequest request, InsurancePolicyPlanViewModel model) {
            try {
                var context = Context;
                var q = context.InsurancePolicyPlan.Find(model.InsurancePolicyPlanId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InsurancePolicyPlan_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Issued Documents
        [HttpPost]
        public async Task<IActionResult> IssuedDocument(int tripId, int debtorId, int creditorId, bool isNative) {
            try {
                ViewBag.IssuedDocumentTripId = tripId;
                ViewBag.IssuedDocumentDebtorId = debtorId;
                ViewBag.IssuedDocumentCreditorId = creditorId;
                ViewBag.IssuedDocumentIsNative = isNative;
                return PartialView("~/Views/Common/_IssuedDocumentPartial.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "IssuedDocument", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> IssuedDocument_Read([DataSourceRequest] DataSourceRequest request, int tripId, int debtorId, int creditorId) {
            try {
                var q = Context.IssuedDocument.Include(t => t.Receipt).ThenInclude(t => t.ReceiptDetails).Include(t => t.Invoice).ThenInclude(t => t.InvoiceDetails).Include(t => t.Voucher).Select(t => t);

                if (tripId > 0)
                    q = q.Where(t1 => t1.TripId == tripId || t1.Invoice.InvoiceDetails.Any(t2 => t2.TripId == tripId));

                if (debtorId > 0)
                    q = q.Where(t => t.DebtorId == debtorId);

                if (creditorId > 0)
                    q = q.Where(t => t.CreditorId == creditorId);

                var result = await q.OrderByDescending(t => t.Id).AsEnumerable().Select(row => new IssuedDocumentViewModel {
                    IssuedDocumentId = row.Id,
                    IssuedDocumentType = row.IssuedDocumentType,
                    IssuedDocumentStatus = row.ReceiptId > 0 ? row.Receipt.DocumentStatus : row.InvoiceId > 0 ? row.Invoice.DocumentStatus : row.VoucherId > 0 ? row.Voucher.DocumentStatus : DocumentStatus.None,
                    IssuedDocumentName = row.Name,
                    IssuedDocumentTripId = row.TripId,
                    IssuedDocumentDebtorId = row.DebtorId,
                    IssuedDocumentCreditorId = row.CreditorId,
                    IssuedDocumentReceiptId = row.ReceiptId,
                    IssuedDocumentInvoiceId = row.InvoiceId,
                    IssuedDocumentVoucherId = row.VoucherId,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "IssuedDocument_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> IssuedDocument_Create([DataSourceRequest] DataSourceRequest request, IssuedDocumentViewModel model, IEnumerable<IFormFile> files) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                IssuedDocumentCommon.Create(Context, model, files);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "IssuedDocument_Create", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> IssuedDocument_Delete([DataSourceRequest] DataSourceRequest request, IssuedDocumentViewModel model) {
            try {
                if (!(HttpContext.IsAdministrator() || (HttpContext.IsAdministrator() && model.IssuedDocumentType == IssuedDocumentType.Other)))
                    throw new UnreportedException("This document cannot be deleted.");

                var context = Context;
                var q = context.IssuedDocument.Include(t => t.Receipt).Include(t => t.Invoice).Include(t => t.Voucher).Single(t => t.Id == model.IssuedDocumentId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                switch (q.IssuedDocumentType) {
                    case IssuedDocumentType.Receipt:
                        q.Receipt.IsIssued = false;
                        context.Save(q.Receipt, false);
                        break;
                    case IssuedDocumentType.Invoice:
                        q.Invoice.IsIssued = false;
                        context.Save(q.Invoice, false);
                        break;
                    case IssuedDocumentType.Voucher:
                        q.Voucher.IsIssued = false;
                        context.Save(q.Voucher, false);
                        break;
                }

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "IssuedDocument_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> IssuedDocument_Download(int issuedDocumentId) {
            try {
                var q = Context.IssuedDocument.Find(issuedDocumentId);
                return File(q.Document, q.FileContentType, q.FileName);
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "IssuedDocument_Download", ex);
                return Redirect("/Shared/Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> IssuedDocument_EmailSelections(string issuedDocumentIds, string from, string to, string cc, string bcc, string subject, string body, IEnumerable<IFormFile> attachments) {
            try {
                if (string.IsNullOrEmpty(issuedDocumentIds))
                    return Json(false);

                var mailAttachments = new List<MailAttachment>();

                foreach (var issuedDocumentId in issuedDocumentIds.Split(',').Select(int.Parse).ToArray()) {
                    var q = Context.IssuedDocument.Find(issuedDocumentId);

                    if (q == null)
                        throw new UnreportedException(AppConstants.RecordNotFound);

                    mailAttachments.Add(new MailAttachment(q.Document, q.FileName, q.FileContentType));
                }

                if (attachments != null) {
                    foreach (var attachment in attachments) {
                        mailAttachments.Add(new MailAttachment(attachment.OpenReadStream().StreamToBytes(), attachment.FileName, attachment.ContentType));
                    }
                }

                await Mail.Instance.SendMailAsync(to, cc, bcc, subject, body, mailAttachments.ToArray(), from);
                return Json(true);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "IssuedDocument_EmailSelections", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> IssuedDocument_GetIssuedStatus(IssuedDocumentType issuedDocumentType, int tripId, int debtorId, int creditorId, int receiptId, int invoiceId, int voucherId) {
            try {
                var context = Context;
                var q = context.IssuedDocument.Where(t => t.IssuedDocumentType == issuedDocumentType);

                if (tripId > 0)
                    q = q.Where(t => t.TripId == tripId);

                if (debtorId > 0)
                    q = q.Where(t => t.DebtorId == debtorId);

                if (creditorId > 0)
                    q = q.Where(t => t.CreditorId == creditorId);

                switch (issuedDocumentType) {
                    default:
                        return Json(0);
                    case IssuedDocumentType.Receipt:
                        q = q.Where(t1 => context.Receipt.Where(t2 => t2.Id == receiptId).Any(t2 => (t2.Id == receiptId && t2.IsIssued) || (t2.ReceiptType == t1.Receipt.ReceiptType && t2.IsSplit && t2.DocumentNo == t1.Receipt.DocumentNo && t2.IsIssued)));
                        break;
                    case IssuedDocumentType.Invoice:
                        q = q.Where(t => t.InvoiceId == invoiceId && t.Invoice.IsIssued);
                        break;
                    case IssuedDocumentType.Voucher:
                        q = q.Where(t => t.VoucherId == voucherId && t.Voucher.IsIssued);
                        break;
                }

                return Json(q.Any());
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "IssuedDocument_GetIssuedStatus", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Leisure Activities
        public IActionResult LeisureActivities() {
            return View();
        }

        public async Task<IActionResult> LeisureActivity_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.LeisureActivity.OrderBy(t => t.Name);

                var result = await q.Select(row => new LeisureActivityViewModel {
                    LeisureActivityId = row.Id,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "LeisureActivity_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> LeisureActivity_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, LeisureActivityViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                LeisureActivity q = null;

                if (model.LeisureActivityId <= 0) {
                    q = new LeisureActivity();
                }
                else {
                    q = context.LeisureActivity.Find(model.LeisureActivityId);
                }

                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.LeisureActivityId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "LeisureActivity_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> LeisureActivity_Delete([DataSourceRequest] DataSourceRequest request, LeisureActivityViewModel model) {
            try {
                var context = Context;
                var q = context.LeisureActivity.Find(model.LeisureActivityId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "LeisureActivity_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Locations
        public IActionResult Locations() {
            return View();
        }

        public async Task<IActionResult> Location_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Location.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new LocationViewModel {
                    LocationId = row.Id,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Location_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Location_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, LocationViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Location q = null;

                if (model.LocationId <= 0) {
                    q = new Location();
                }
                else {
                    q = context.Location.Find(model.LocationId);
                }

                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.LocationId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Location_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Location_Delete([DataSourceRequest] DataSourceRequest request, LocationViewModel model) {
            try {
                var context = Context;
                var q = context.Location.Find(model.LocationId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Location_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Mark-Up Strategies
        public IActionResult MarkupStrategies() {
            return View();
        }

        public async Task<IActionResult> MarkupStrategy_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.MarkupStrategy.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new MarkupStrategyViewModel {
                    MarkupStrategyId = row.Id,
                    Name = row.Name,
                    SaleTypeId = row.SaleTypeId,
                    SaleType = row.SaleType.Name,
                    ChartOfAccountId = row.ChartOfAccountId,
                    ChartOfAccount = string.Concat(row.ChartOfAccount.Code, ": ", row.ChartOfAccount.Name),
                    AllowInverseRemainderCommission = row.AllowInverseRemainderCommission,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MarkupStrategy_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkupStrategy_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, MarkupStrategyViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                MarkupStrategy q = null;

                if (model.MarkupStrategyId <= 0) {
                    q = new MarkupStrategy();
                }
                else {
                    q = context.MarkupStrategy.Find(model.MarkupStrategyId);
                }

                if (model.ChartOfAccountId != q.ChartOfAccountId && !ChartOfAccount.IsInRole(context, model.ChartOfAccountId ?? 0, HttpContext.RoleId()))
                    throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                q.Name = model.Name;
                q.SaleTypeId = model.SaleTypeId ?? 0;
                q.ChartOfAccountId = model.ChartOfAccountId ?? 0;
                q.AllowInverseRemainderCommission = model.AllowInverseRemainderCommission;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.MarkupStrategyId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MarkupStrategy_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkupStrategy_Delete([DataSourceRequest] DataSourceRequest request, MarkupStrategyViewModel model) {
            try {
                var context = Context;
                var q = context.MarkupStrategy.Include(t => t.MarkupStrategyElements).SingleOrDefault(t => t.Id == model.MarkupStrategyId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MarkupStrategy_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> MarkupStrategy_ExportExcel() {
            try {
                var q = Context.MarkupStrategy.Where(t => t.Id > 0).OrderBy(t => t.Name).Select(row => new MarkupStrategyExportModel {
                    MarkupStrategy = row.Name,
                    SaleType = row.SaleType.Name,
                    RemainderCommissionAcct = row.ChartOfAccount.Name,
                    AllowInverseRemainderCommission = row.AllowInverseRemainderCommission
                }).ToList();

                var xlsx = new ExportToExcel<MarkupStrategyExportModel>(q);
                return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Mark-Up Strategies.xlsx");
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MarkupStrategy_ExportExcel", ex);
                return Redirect("/Shared/Error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> MarkupStrategyElement(int? parentId) {
            try {
                ViewBag.ParentId = parentId ?? 0;
                return PartialView("~/Views/Common/EditorTemplates/MarkupStrategyElementEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MarkupStrategyElement", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> MarkupStrategyElement_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.MarkupStrategyElement.Where(t => t.MarkupStrategyId == parentId);

                var result = await q.Select(row => new MarkupStrategyElementViewModel {
                    MarkupStrategyElementId = row.Id,
                    MarkupStrategyId = row.MarkupStrategyId,
                    MarkupStrategyElementChartOfAccountId = row.ChartOfAccountId,
                    MarkupStrategyElementChartOfAccount = row.ChartOfAccountId <= 0 ? string.Empty : row.ChartOfAccount.Name,
                    ApportionMethod = row.ApportionMethod,
                    Amount = row.Amount,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MarkupStrategyMarkupElement_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkupStrategyElement_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, MarkupStrategyElementViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                MarkupStrategyElement q = null;

                if (model.MarkupStrategyElementId <= 0) {
                    q = new MarkupStrategyElement();
                }
                else {
                    q = context.MarkupStrategyElement.Find(model.MarkupStrategyElementId);
                }

                if (model.MarkupStrategyElementChartOfAccountId != q.ChartOfAccountId && !ChartOfAccount.IsInRole(context, model.MarkupStrategyElementChartOfAccountId ?? 0, HttpContext.RoleId()))
                    throw new UnreportedException(string.Format(AppConstants.UnauthorisedAccessWarning, "Chart of Account"));

                q.MarkupStrategyId = model.MarkupStrategyId;
                q.ChartOfAccountId = model.MarkupStrategyElementChartOfAccountId ?? 0;
                q.ApportionMethod = model.ApportionMethod;
                q.Amount = model.Amount;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.MarkupStrategyElementId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MarkupStrategyElement_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkupStrategyElement_Delete([DataSourceRequest] DataSourceRequest request, MarkupStrategyElementViewModel model) {
            try {
                var context = Context;
                var q = context.MarkupStrategyElement.Find(model.MarkupStrategyElementId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MarkupStrategyElement_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Meals Served
        public IActionResult MealsServed() {
            return View();
        }

        public async Task<IActionResult> MealServed_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.MealServed.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new MealServedViewModel {
                    MealServedId = row.Id,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MealServed_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MealServed_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, MealServedViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                MealServed q = null;

                if (model.MealServedId <= 0) {
                    q = new MealServed();
                }
                else {
                    q = context.MealServed.Find(model.MealServedId);
                }

                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.MealServedId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MealServed_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MealServed_Delete([DataSourceRequest] DataSourceRequest request, MealServedViewModel model) {
            try {
                var context = Context;
                var q = context.MealServed.Include(t => t.MealServedCrs).SingleOrDefault(t => t.Id == model.MealServedId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MealServed_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> MealServedCrs_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.MealServedCrs.Where(t => t.MealServedId == parentId).OrderBy(t => t.Crs);

                var result = await q.Select(row => new MealServedCrsViewModel {
                    MealServedCrsId = row.Id,
                    MealServedId = row.MealServedId,
                    Crs = row.Crs,
                    CrsCode = row.CrsCode,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MealServedCrs_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MealServedCrs_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, MealServedCrsViewModel model, int parentId) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                MealServedCrs q = null;

                if (model.MealServedCrsId <= 0) {
                    q = new MealServedCrs();
                }
                else {
                    q = context.MealServedCrs.Find(model.MealServedCrsId);
                }

                q.MealServedId = parentId;
                q.Crs = model.Crs;
                q.CrsCode = model.CrsCode.ToUpper();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.MealServedCrsId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MealServedCrs_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MealServedCrs_Delete([DataSourceRequest] DataSourceRequest request, MealServedCrsViewModel model) {
            try {
                var context = Context;
                var q = context.MealServedCrs.Find(model.MealServedCrsId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MealServedCrs_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Offered Reasons
        public IActionResult OfferedReasons() {
            return View();
        }

        public async Task<IActionResult> OfferedReason_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.OfferedReason.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new OfferedReasonViewModel {
                    OfferedReasonId = row.Id,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "OfferedReason_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> OfferedReason_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, OfferedReasonViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                OfferedReason q = null;

                if (model.OfferedReasonId <= 0) {
                    q = new OfferedReason();
                }
                else {
                    q = context.OfferedReason.Find(model.OfferedReasonId);
                }

                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.OfferedReasonId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "OfferedReason_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> OfferedReason_Delete([DataSourceRequest] DataSourceRequest request, OfferedReasonViewModel model) {
            try {
                var context = Context;
                var q = context.OfferedReason.Find(model.OfferedReasonId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "OfferedReason_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Payment Terms
        public IActionResult PaymentTerms() {
            return View();
        }

        public async Task<IActionResult> PaymentTerm_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.PaymentTerm.OrderBy(t => t.Term);

                var result = await q.Select(row => new PaymentTermViewModel {
                    PaymentTermId = row.Id,
                    Name = row.Name,
                    Term = row.Term,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentTerm_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PaymentTerm_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, PaymentTermViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                PaymentTerm q = null;

                if (model.PaymentTermId <= 0) {
                    q = new PaymentTerm();
                }
                else {
                    q = context.PaymentTerm.Find(model.PaymentTermId);
                }

                q.Name = model.Name;
                q.Term = model.Term;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.PaymentTermId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentTerm_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PaymentTerm_Delete([DataSourceRequest] DataSourceRequest request, PaymentTermViewModel model) {
            try {
                var context = Context;
                var q = context.PaymentTerm.Find(model.PaymentTermId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentTerm_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Rates
        public IActionResult Rates() {
            return View();
        }

        public async Task<IActionResult> Rate_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Rate.OrderBy(t => t.Name);

                var result = await q.Select(row => new RateViewModel {
                    RateId = row.Id,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Rate_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Rate_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, RateViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Rate q = null;

                if (model.RateId <= 0) {
                    q = new Rate();
                }
                else {
                    q = context.Rate.Find(model.RateId);
                }

                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.RateId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Rate_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Rate_Delete([DataSourceRequest] DataSourceRequest request, RateViewModel model) {
            try {
                var context = Context;
                var q = context.Rate.Find(model.RateId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Rate_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Regions
        public IActionResult Regions() {
            return View();
        }

        public async Task<IActionResult> Region_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Region.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new RegionViewModel {
                    RegionId = row.Id,
                    Name = row.Name,
                    TravelZone = row.TravelZone,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Region_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Region_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, RegionViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Region q = null;

                if (model.RegionId <= 0) {
                    q = new Region();
                }
                else {
                    q = context.Region.Find(model.RegionId);
                }

                q.Name = model.Name;
                q.TravelZone = model.TravelZone;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.RegionId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Region_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Region_Delete([DataSourceRequest] DataSourceRequest request, RegionViewModel model) {
            try {
                var context = Context;
                var q = context.Region.Find(model.RegionId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Region_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Sale Type Groupings
        public IActionResult SaleTypeGroupings() {
            return View();
        }

        public async Task<IActionResult> SaleTypeGrouping_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.SaleTypeGrouping.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new SaleTypeGroupingViewModel {
                    SaleTypeGroupingId = row.Id,
                    Name = row.Name,
                    Description = row.Description,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SaleTypeGrouping_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SaleTypeGrouping_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SaleTypeGroupingViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                SaleTypeGrouping q = null;

                if (model.SaleTypeGroupingId <= 0) {
                    q = new SaleTypeGrouping();
                }
                else {
                    q = context.SaleTypeGrouping.Find(model.SaleTypeGroupingId);
                }

                q.Name = model.Name;
                q.Description = model.Description.ToStringExt();

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.SaleTypeGroupingId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SaleTypeGrouping_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SaleTypeGrouping_Delete([DataSourceRequest] DataSourceRequest request, SaleTypeGroupingViewModel model) {
            try {
                var context = Context;
                var q = context.SaleTypeGrouping.Find(model.SaleTypeGroupingId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SaleTypeGrouping_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Sale Types
        public IActionResult SaleTypes() {
            return View();
        }

        public async Task<IActionResult> SaleType_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.SaleType.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new SaleTypeViewModel {
                    SaleTypeId = row.Id,
                    Name = row.Name,
                    TravelType = row.TravelType,
                    SaleTypeReportingType = row.SaleTypeReportingType,
                    SaleTypeGroupingId = row.SaleTypeGroupingId,
                    IsTaxApplicable = row.IsTaxApplicable,
                    IsCreditCardDiscountApplicable = row.IsCreditCardDiscountApplicable,
                    CommissionRate = row.CommissionRate,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SaleType_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SaleType_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SaleTypeViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                SaleType q = null;

                if (model.SaleTypeId <= 0) {
                    q = new SaleType();
                }
                else {
                    q = context.SaleType.Find(model.SaleTypeId);
                }

                q.Name = model.Name;
                q.TravelType = model.TravelType;
                q.SaleTypeReportingType = model.SaleTypeReportingType;
                q.SaleTypeGroupingId = model.SaleTypeGroupingId ?? 0;
                q.IsTaxApplicable = model.IsTaxApplicable;
                q.IsCreditCardDiscountApplicable = model.IsCreditCardDiscountApplicable;
                q.CommissionRate = model.CommissionRate;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.SaleTypeId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SaleType_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SaleType_Delete([DataSourceRequest] DataSourceRequest request, SaleTypeViewModel model) {
            try {
                var context = Context;
                var q = context.SaleType.Find(model.SaleTypeId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SaleType_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> SaleType_ExportExcel() {
            try {
                var q = Context.SaleType.Where(t => t.Id > 0).OrderBy(t => t.Name).Select(row => new SaleTypeExportModel {
                    SaleType = row.Name,
                    TravelType = row.TravelType.GetEnumDescription(),
                    ReportingType = row.SaleTypeReportingType.GetEnumDescription(),
                    Grouping = row.SaleTypeGrouping.Name,
                    IsTaxApplicable = row.IsTaxApplicable,
                    IsCreditCardDiscountApplicable = row.IsCreditCardDiscountApplicable,
                    CommissionRate = row.CommissionRate
                }).ToList();

                var xlsx = new ExportToExcel<SaleTypeExportModel>(q);
                return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Types of Sale.xlsx");
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SaleType_ExportExcel", ex);
                return Redirect("/Shared/Error");
            }
        }
        #endregion

        #region Service Fee Types
        public IActionResult ServiceFeeTypes() {
            return View();
        }

        public async Task<IActionResult> ServiceFeeType_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.ServiceFeeType.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new ServiceFeeTypeViewModel {
                    ServiceFeeTypeId = row.Id,
                    Name = row.Name,
                    SaleTypeId = row.SaleTypeId,
                    SaleType = row.SaleTypeId <= 0 ? string.Empty : row.SaleType.Name,
                    AdjustmentTypeId = row.AdjustmentTypeId <= 0 ? (int?)null : row.AdjustmentTypeId,
                    AdjustmentType = row.AdjustmentTypeId <= 0 ? string.Empty : row.AdjustmentType.Name,
                    SupplierId = row.SupplierId <= 0 ? (int?)null : row.SupplierId,
                    Supplier = row.SupplierId <= 0 ? string.Empty : row.Supplier.Name,
                    Amount = row.Amount,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ServiceFeeType_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ServiceFeeType_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ServiceFeeTypeViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                ServiceFeeType q = null;

                if (model.ServiceFeeTypeId <= 0) {
                    q = new ServiceFeeType();
                }
                else {
                    q = context.ServiceFeeType.Find(model.ServiceFeeTypeId);
                }

                q.Name = model.Name;
                q.Amount = model.Amount;
                q.SaleTypeId = model.SaleTypeId ?? 0;
                q.AdjustmentTypeId = model.AdjustmentTypeId ?? 0;
                q.SupplierId = model.SupplierId ?? 0;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.ServiceFeeTypeId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ServiceFeeType_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ServiceFeeType_Delete([DataSourceRequest] DataSourceRequest request, ServiceFeeTypeViewModel model) {
            try {
                var context = Context;
                var q = context.ServiceFeeType.Find(model.ServiceFeeTypeId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ServiceFeeType_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ServiceFeeType_ExportExcel() {
            try {
                var q = Context.ServiceFeeType.Where(t => t.Id > 0).OrderBy(t => t.Name).Select(row => new ServiceFeeExportModel {
                    ServiceFee = row.Name,
                    Amount = row.Amount,
                    SaleType = row.SaleType.Name,
                    AdjustmentType = row.AdjustmentType.Name,
                    Supplier = row.Supplier.Name,
                }).ToList();

                var xlsx = new ExportToExcel<ServiceFeeExportModel>(q);
                return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Service Fee Types.xlsx");
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ServiceFeeType_ExportExcel", ex);
                return Redirect("/Shared/Error");
            }
        }
        #endregion

        #region Service Types
        public IActionResult ServiceTypes() {
            return View("~/Views/Common/ServiceTypes.cshtml");
        }

        public async Task<IActionResult> ServiceType_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.ServiceType.Where(t => t.Id > 0);

                var result = await q.OrderBy(t => t.Name).Select(row => new ServiceTypeViewModel {
                    ServiceTypeId = row.Id,
                    Name = row.Name,
                    TripLineType = row.TripLineType,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ServiceType_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> ServiceTypeRateBasis_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.ServiceTypeRateBasis.Where(t => t.ServiceTypeId == parentId);

                var result = await q.Select(row => new ServiceTypeRateBasisViewModel {
                    ServiceTypeRateBasisId = row.Id,
                    ServiceTypeId = row.ServiceTypeId,
                    Name = row.Name,
                    IsPaxNoApplicable = row.IsPaxNoApplicable,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ServiceTypeRateBasis_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Sources
        public IActionResult Sources() {
            return View();
        }

        public async Task<IActionResult> Source_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.Source.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new SourceViewModel {
                    SourceId = row.Id,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Source_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Source_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SourceViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                Source q = null;

                if (model.SourceId <= 0) {
                    q = new Source();
                }
                else {
                    q = context.Source.Find(model.SourceId);
                }

                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.SourceId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Source_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Source_Delete([DataSourceRequest] DataSourceRequest request, SourceViewModel model) {
            try {
                var context = Context;
                var q = context.Source.Find(model.SourceId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Source_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Special Requests
        public IActionResult SpecialRequests() {
            return View();
        }

        public async Task<IActionResult> SpecialRequest_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.SpecialRequest.OrderBy(t => t.Description);

                var result = await q.Select(row => new SpecialRequestViewModel {
                    SpecialRequestId = row.Id,
                    Code = row.Code,
                    Description = row.Description,
                    SpecialRequestType = row.SpecialRequestType,
                    SpecialRequestFreeFormat = row.SpecialRequestFreeFormat,
                    ImportFromCrs = row.ImportFromCrs,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SpecialRequest_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SpecialRequest_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SpecialRequestViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                SpecialRequest q = null;

                if (model.SpecialRequestId <= 0) {
                    q = new SpecialRequest();
                }
                else {
                    q = context.SpecialRequest.Find(model.SpecialRequestId);
                }

                q.Code = Utils.RemoveExtraSpaces(model.Code).Replace(" ", string.Empty).ToUpper();
                q.Description = model.Description;
                q.SpecialRequestType = model.SpecialRequestType;
                q.SpecialRequestFreeFormat = model.SpecialRequestFreeFormat;
                q.ImportFromCrs = model.ImportFromCrs;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.SpecialRequestId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SpecialRequest_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SpecialRequest_Delete([DataSourceRequest] DataSourceRequest request, SpecialRequestViewModel model) {
            try {
                var context = Context;
                var q = context.SpecialRequest.Find(model.SpecialRequestId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SpecialRequest_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Standard Comments
        public IActionResult StandardComments() {
            return View();
        }

        public async Task<IActionResult> StandardComment_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.StandardComment.Where(t => t.Id > 0).OrderBy(t => t.Code);

                var result = await q.Select(row => new StandardCommentViewModel {
                    StandardCommentId = row.Id,
                    Code = row.Code,
                    Description = row.Description,
                    Comment = row.Comment,
                    StandardCommentType = row.StandardCommentType,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "StandardComment_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> StandardComment_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, StandardCommentViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                StandardComment q = null;

                if (model.StandardCommentId <= 0) {
                    q = new StandardComment();
                }
                else {
                    q = context.StandardComment.Find(model.StandardCommentId);
                }

                q.Code = Utils.RemoveExtraSpaces(model.Code).Replace(" ", string.Empty).ToUpper();
                q.Description = model.Description.ToStringExt();
                q.Comment = model.Comment;
                q.StandardCommentType = model.StandardCommentType;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.StandardCommentId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "StandardComment_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> StandardComment_Delete([DataSourceRequest] DataSourceRequest request, StandardCommentViewModel model) {
            try {
                var context = Context;
                var q = context.StandardComment.Find(model.StandardCommentId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "StandardComment_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Supplier Services
        public IActionResult SupplierServices() {
            return View("~/Views/Common/SupplierServices.cshtml");
        }

        public async Task<IActionResult> SupplierService_Read([DataSourceRequest] DataSourceRequest request, TripLineType tripLineType = TripLineType.All, string text = null) {
            try {
                var q = Context.SupplierService.Where(t => t.Id > 0).OrderBy(t => t.Name).Select(t => t);

                if (tripLineType != TripLineType.All)
                    q = q.Where(t => t.ServiceType.TripLineType == tripLineType);

                if (!string.IsNullOrEmpty(text))
                    q = q.Where(t => t.Name.Contains(text));

                var result = await q.Select(row => new SupplierServiceViewModel {
                    SupplierServiceId = row.Id,
                    Name = row.Name,
                    Comments = row.Comments,
                    RelatedRemarks = row.RelatedRemarks,
                    UnitOfService = row.UnitOfService,
                    ServiceCharged = row.ServiceCharged,
                    ServiceTypeId = row.ServiceTypeId,
                    ServiceType = row.ServiceType.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierService_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierService_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SupplierServiceViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new SupplierServiceCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierService_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierService_Delete([DataSourceRequest] DataSourceRequest request, SupplierServiceViewModel model) {
            try {
                new SupplierServiceCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierService_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Tax Codes
        public IActionResult TaxCodes() {
            return View();
        }

        public async Task<IActionResult> TaxCode_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.TaxCode.OrderBy(t => t.Name);

                var result = await q.Select(row => new TaxCodeViewModel {
                    TaxCodeId = row.Id,
                    Code = row.Code,
                    Name = row.Name,
                    Amount = row.Amount,
                    CityId = row.CityId,
                    City = row.CityId <= 0 ? string.Empty : row.City.Name,
                    SaleTypeId = row.SaleTypeId,
                    SaleType = row.SaleTypeId <= 0 ? string.Empty : row.SaleType.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TaxCode_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TaxCode_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, TaxCodeViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                TaxCode q = null;

                if (model.TaxCodeId <= 0) {
                    q = new TaxCode();
                }
                else {
                    q = context.TaxCode.Find(model.TaxCodeId);
                }

                q.Code = Utils.RemoveExtraSpaces(model.Code).Replace(" ", string.Empty).ToUpper();
                q.Name = model.Name;
                q.Amount = model.Amount;
                q.CityId = model.CityId ?? 0;
                q.SaleTypeId = model.SaleTypeId ?? 0;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.TaxCodeId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TaxCode_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TaxCode_Delete([DataSourceRequest] DataSourceRequest request, TaxCodeViewModel model) {
            try {
                var context = Context;
                var q = context.TaxCode.Find(model.TaxCodeId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TaxCode_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TaxCode_ExportExcel() {
            try {
                var q = Context.TaxCode.Where(t => t.Id > 0).OrderBy(t => t.Name).Select(row => new TaxCodeExportModel {
                    Code = row.Code,
                    TaxCode = row.Name,
                    Amount = row.Amount,
                    City = row.City.Name,
                    SaleType = row.SaleType.Name
                }).ToList();

                var xlsx = new ExportToExcel<TaxCodeExportModel>(q);
                return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Tax Codes.xlsx");
            }
            catch (Exception ex) {
                await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TaxCode_ExportExcel", ex);
                return Redirect("/Shared/Error");
            }
        }
        #endregion

        #region Tax Rates
        public IActionResult TaxRates() {
            return View();
        }

        public async Task<IActionResult> TaxRate_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var adminContext = AdminContext;
                var context = Context;

                var q = adminContext.TaxRate.OrderBy(t => t.CountryCode).ThenByDescending(t => t.DateEffective);

                var result = await q.ToList().ConvertAll(row => new TaxRateViewModel {
                    TaxRateId = row.Id,
                    CountryCode = row.CountryCode,
                    Country = context.Country.Single(t => t.Code == row.CountryCode).Name,
                    DateEffective = row.DateEffective,
                    Rate = row.Rate,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TaxRate_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TaxRate_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, TaxRateViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var adminContext = AdminContext;
                TaxRate q = null;

                if (model.TaxRateId <= 0) {
                    q = new TaxRate();
                }
                else {
                    q = adminContext.TaxRate.Find(model.TaxRateId);
                }

                q.CountryCode = model.CountryCode;
                q.DateEffective = model.DateEffective;
                q.Rate = model.Rate;

                bool result;

                if (q.Id <= 0) {
                    result = adminContext.Insert(q);
                }
                else {
                    result = adminContext.Save(q);
                }

                if (result)
                    AppSettings.Clear(HttpContext.CurrentCustomerId());

                model.TaxRateId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TaxRate_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TaxRate_Delete([DataSourceRequest] DataSourceRequest request, TaxRateViewModel model) {
            try {
                var q = AdminContext.TaxRate.Find(model.TaxRateId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                if (AdminContext.Delete(q))
                    AppSettings.Clear(HttpContext.CurrentCustomerId());

                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TaxRate_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Travel Class Defaults
        public IActionResult TravelClassDefaults() {
            return View();
        }

        public async Task<IActionResult> TravelClassDefault_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.TravelClassDefault.Where(t => t.Id > 0).OrderBy(t => t.Name).ThenBy(t => t.Code);

                var result = await q.Select(row => new TravelClassDefaultViewModel {
                    TravelClassDefaultId = row.Id,
                    Code = row.Code,
                    Name = row.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TravelClassDefault_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TravelClassDefault_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, TravelClassDefaultViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                TravelClassDefault q = null;

                if (model.TravelClassDefaultId <= 0) {
                    q = new TravelClassDefault();
                }
                else {
                    q = context.TravelClassDefault.Find(model.TravelClassDefaultId);
                }

                q.Code = Utils.RemoveExtraSpaces(model.Code).Replace(" ", string.Empty).ToUpper();
                q.Name = model.Name;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.TravelClassDefaultId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TravelClassDefault_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TravelClassDefault_Delete([DataSourceRequest] DataSourceRequest request, TravelClassDefaultViewModel model) {
            try {
                var context = Context;
                var q = context.TravelClassDefault.Find(model.TravelClassDefaultId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TravelClassDefault_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Trip Checklist Defaults
        public IActionResult TripChecklistDefaults() {
            return View();
        }

        public async Task<IActionResult> TripChecklistDefault_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.TripChecklistDefault.Where(t => t.Id > 0).OrderBy(t => t.SeqNo);

                var result = await q.Select(row => new TripChecklistDefaultViewModel {
                    TripChecklistDefaultId = row.Id,
                    Name = row.Name,
                    SeqNo = row.SeqNo,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripChecklistDefault_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripChecklistDefault_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, TripChecklistDefaultViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                var context = Context;
                TripChecklistDefault q = null;

                if (model.TripChecklistDefaultId <= 0) {
                    q = new TripChecklistDefault();
                }
                else {
                    q = context.TripChecklistDefault.Find(model.TripChecklistDefaultId);
                }

                q.Name = model.Name;
                q.SeqNo = model.SeqNo;

                if (q.Id <= 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                model.TripChecklistDefaultId = q.Id;
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripChecklistDefault_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TripChecklistDefault_Delete([DataSourceRequest] DataSourceRequest request, TripChecklistDefaultViewModel model) {
            try {
                var context = Context;
                var q = context.TripChecklistDefault.Find(model.TripChecklistDefaultId);

                if (q == null)
                    throw new UnreportedException(AppConstants.RecordNotFound);

                context.Delete(q);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TripChecklistDefault_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion
    }
}