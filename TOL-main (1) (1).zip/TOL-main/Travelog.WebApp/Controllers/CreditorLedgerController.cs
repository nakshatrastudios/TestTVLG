﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kendo.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Telerik.Reporting.Processing;
using Travelog.Biz;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;
using Travelog.Reports.CreditorLedger;
using Travelog.WebApp.CreditorLedger;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.Controllers {
    [Authorize]
    public class CreditorLedgerController : BaseController {
        private const string ClassName = "Travelog.WebApp.Controllers.CreditorLedgerController";

        public CreditorLedgerController(IWebHostEnvironment webHostEnvironment, IDistributedCache cache) : base(webHostEnvironment, cache) {
        }

        #region Creditors
        public IActionResult Index() {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Creditor_Edit(int creditorId, int agencyId) {
            try {
                if (agencyId <= 0)
                    agencyId = HttpContext.CurrentDefaultAgencyId();

                if (agencyId <= 0)
                    throw new UnreportedException(AppConstants.AgencyNotSpecified);

                Creditor q = null;

                if (creditorId <= 0) {
                    q = new Creditor {
                        Id = 0,
                        AgencyId = agencyId,
                        Name = string.Empty,
                        CurrencyId = -1,
                        ClassId = -1,
                        LocationId = -1,
                        AgingCycle = AgingCycle.SevenDay,
                        IsBspAgent = false,
                        IsNonBspAgent = false,
                        IsRcti = false,
                        IsTaxOnCommission = false,
                        Rules = string.Empty,
                        Remarks = string.Empty,
                        CreditLimit = 0
                    };
                }
                else {
                    q = Context.Creditor.Find(creditorId);
                }

                var model = new CreditorViewModel {
                    CreditorId = q.Id,
                    AgencyId = q.AgencyId,
                    Name = q.Name,
                    CurrencyId = q.CurrencyId,
                    ClassId = q.ClassId,
                    LocationId = q.LocationId,
                    AgingCycle = q.AgingCycle,
                    IsBspAgent = q.IsBspAgent,
                    IsNonBspAgent = q.IsNonBspAgent,
                    IsRcti = q.IsRcti,
                    IncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment,
                    IsTaxOnCommission = q.IsTaxOnCommission,
                    Rules = q.Rules,
                    Remarks = q.Remarks,
                    CommissionRate = q.CommissionRate,
                    CreditLimit = q.CreditLimit
                };

                return PartialView("~/Views/CreditorLedger/EditorTemplates/CreditorEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Creditor_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Creditor_Read([DataSourceRequest] DataSourceRequest request, BspAgentType bspAgentType, int agencyId, int supplierId, string text, bool isExport, int? id) {
            try {
                var q = Creditor.GetCreditorQuery(Context, bspAgentType, agencyId, supplierId, text, id);

                if (isExport) {
                    if (!HttpContext.IsAdministrator())
                        throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

                    var export = (from t1 in q.AsEnumerable()
                                  from t2 in t1.CreditorContacts.DefaultIfEmpty()
                                  select new CreditorExportModel {
                                      Creditor = t1.Name,
                                      AgingCycle = t1.AgingCycle.GetEnumDescription(),
                                      Currency = t1.Currency.Name,
                                      Class = t1.Class.Name,
                                      Agency = t1.Agency.Name,
                                      Address = string.Join(Environment.NewLine, t1.CreditorAddresses.Select(t => t.Address)),
                                      Contact = t2 == null ? string.Empty : t2.FullName,
                                      PhoneHome = t2 == null ? string.Empty : t2.PhoneHome,
                                      PhoneWork = t2 == null ? string.Empty : t2.PhoneWork,
                                      Mobile = t2 == null ? string.Empty : t2.Mobile,
                                      Fax = t2 == null ? string.Empty : t2.Fax,
                                      Email = t2 == null ? string.Empty : t2.Email,
                                      CommissionRate = t1.CommissionRate,
                                      CreditLimit = t1.CreditLimit,
                                      IsBspAgent = t1.IsBspAgent,
                                      IsNonBspAgent = t1.IsNonBspAgent,
                                      IsTaxOnCommission = t1.IsTaxOnCommission,
                                      IsRcti = t1.IsRcti
                                  }).ToList();

                    var xlsx = new ExportToExcel<CreditorExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Creditors.xlsx");
                }

                var result = await q.Select(row => new CreditorViewModel {
                    CreditorId = row.Id,
                    Name = row.Name,
                    Suppliers = string.Join("; ", row.SupplierCreditors.Select(t => t.Supplier.Name).Distinct()),
                    AgingCycle = row.AgingCycle,
                    CommissionRate = row.CommissionRate,
                    IsBspAgent = row.IsBspAgent,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser,
                    ContactViewModel = row.CreditorContacts.Select(t => new ContactViewModel {
                        ContactId = t.Id,
                        Title = t.Title,
                        Name = t.Name,
                        PhoneHome = t.PhoneHome,
                        PhoneWork = t.PhoneWork,
                        Mobile = t.Mobile,
                        PhoneNo = t.PhoneNo,
                        Fax = t.Fax,
                        Email = t.Email,
                        IsDefaultContact = t.IsDefault,
                        LastWriteTime = t.LastWriteTime.ToLocalTime(),
                        CreationTime = t.CreationTime.ToLocalTime(),
                        LastWriteUser = t.LastWriteUser,
                        CreationUser = t.CreationUser
                    }).OrderBy(t => t.IsDefaultContact ? 0 : 1).FirstOrDefault() ?? new ContactViewModel()
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Creditor_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Creditor_CreateOrUpdate(CreditorViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new CreditorCommon(HttpContext).CreateOrUpdate(Context, model);

                ViewBag.AddressParentId = model.CreditorId;
                ViewBag.ContactParentId = model.CreditorId;

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Creditor_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Creditor_Delete([DataSourceRequest] DataSourceRequest request, CreditorViewModel model) {
            try {
                new CreditorCommon(HttpContext).Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Creditor_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreditorAddress(int? parentId) {
            try {
                ViewBag.AddressParentId = parentId ?? 0;
                ViewBag.AddressReadUrl = Url.Action("CreditorAddress_Read", "CreditorLedger", new { parentId = parentId ?? 0 });
                ViewBag.AddressUpdateUrl = Url.Action("CreditorAddress_CreateOrUpdate", "CreditorLedger");
                ViewBag.AddressDeleteUrl = Url.Action("CreditorAddress_Delete", "CreditorLedger");

                return PartialView("~/Views/Shared/EditorTemplates/AddressForm.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorAddress", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> CreditorAddress_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.CreditorAddress.Where(t => t.CreditorId == parentId);

                if (q.Count() == 0)
                    q = new List<CreditorAddress> { new CreditorAddress() }.AsQueryable();

                var result = await q.OrderByDescending(t => t.IsDefault).Select(row => new AddressViewModel {
                    AddressType = row.AddressType,
                    AddressId = row.Id,
                    ParentId = row.CreditorId,
                    Address1 = row.Address1,
                    Address2 = row.Address2,
                    Locality = row.Locality,
                    Region = row.Region,
                    PostCode = row.PostCode,
                    CountryCode = row.CountryCode,
                    IsDefaultAddress = row.IsDefault,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorAddress_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreditorAddress_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new CreditorAddressCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorAddress_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreditorAddress_Delete([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                new CreditorAddressCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorAddress_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreditorContact(int? parentId) {
            try {
                ViewBag.ContactParentId = parentId ?? 0;
                ViewBag.ContactReadUrl = Url.Action("CreditorContact_Read", "CreditorLedger", new { parentId = parentId ?? 0 });
                ViewBag.ContactUpdateUrl = Url.Action("CreditorContact_CreateOrUpdate", "CreditorLedger");
                ViewBag.ContactDeleteUrl = Url.Action("CreditorContact_Delete", "CreditorLedger");

                ViewBag.ContactIsContactVisible = true;
                ViewBag.ContactIsPhoneHomeVisible = true;
                ViewBag.ContactIsPhoneWorkVisible = true;
                ViewBag.ContactIsMobileVisible = true;
                ViewBag.ContactIsFaxVisible = true;
                ViewBag.ContactIsEmailVisible = true;

                return PartialView("~/Views/Shared/EditorTemplates/ContactForm.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorContact", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> CreditorContact_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.CreditorContact.Where(t => t.CreditorId == parentId);

                if (q.Count() == 0)
                    q = new List<CreditorContact> { new CreditorContact() }.AsQueryable();

                var result = await q.OrderByDescending(t => t.IsDefault).Select(row => new ContactViewModel {
                    ContactId = row.Id,
                    ParentId = row.CreditorId,
                    Title = row.Title,
                    Name = row.Name,
                    PhoneHome = row.PhoneHome,
                    PhoneWork = row.PhoneWork,
                    Mobile = row.Mobile,
                    Fax = row.Fax,
                    Email = row.Email,
                    IsDefaultContact = row.IsDefault,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorContact_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreditorContact_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ContactViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new CreditorContactCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorContact_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreditorContact_Delete([DataSourceRequest] DataSourceRequest request, ContactViewModel model) {
            try {
                new CreditorContactCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorContact_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreditorSupplier(int parentId) {
            try {
                ViewBag.ParentId = parentId;
                return PartialView("~/Views/CreditorLedger/EditorTemplates/CreditorSupplierEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorSupplier", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> CreditorSupplier_Read([DataSourceRequest] DataSourceRequest request, int parentId, string text) {
            try {
                var q = Context.SupplierCreditor.Where(t => t.CreditorId == parentId);

                if (!string.IsNullOrEmpty(text))
                    q = q.Where(t => t.Supplier.Name.Contains(text));

                var result = await q.OrderBy(t => t.Supplier.Name).Select(row => new CreditorSupplierViewModel {
                    CreditorSupplierId = row.Id,
                    CreditorId = row.CreditorId,
                    SupplierId = row.SupplierId,
                    IsDefault = row.IsDefault,
                    SupplierName = row.Supplier.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorSupplier_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreditorSupplier_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, CreditorSupplierViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new CreditorSupplierCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorSupplier_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreditorSupplier_Delete([DataSourceRequest] DataSourceRequest request, CreditorSupplierViewModel model) {
            try {
                new CreditorSupplierCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorSupplier_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreditorCrs(int parentId) {
            try {
                ViewBag.ParentId = parentId;
                return PartialView("~/Views/CreditorLedger/EditorTemplates/CreditorCrsEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorCrs", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> CreditorCrs_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.CreditorCrs.Where(t => t.CreditorId == parentId).OrderBy(t => t.Crs);

                var result = await q.Select(row => new CreditorCrsViewModel {
                    CreditorCrsId = row.Id,
                    CreditorId = row.CreditorId,
                    Crs = row.Crs,
                    CrsCode = row.CrsCode,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorCrs_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreditorCrs_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, CreditorCrsViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new CreditorCrsCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorCrs_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreditorCrs_Delete([DataSourceRequest] DataSourceRequest request, CreditorCrsViewModel model) {
            try {
                new CreditorCrsCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorCrs_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreditorSupplierSearch_Edit(TripLineType tripLineType, BspAgentType bspAgentType, string creditorTargetId, string supplierTargetId, string saleTypeTargetId, int agencyId, int creditorId, int supplierId, bool useDefaultUpdateMethod) {
            try {
                var q1 = Creditor.GetCreditorQuery(Context, bspAgentType, HttpContext.CurrentDefaultAgencyId(), -1, null, null);
                var q2 = Supplier.GetSupplierQuery(LazyContext, tripLineType, bspAgentType, -1, null, null, null);

                ViewBag.CreditorSupplierSearchTripLineType = tripLineType;
                ViewBag.CreditorSupplierSearchBspAgentType = bspAgentType;

                ViewBag.CreditorSupplierSearchCreditorTargetId = creditorTargetId;
                ViewBag.CreditorSupplierSearchSupplierTargetId = supplierTargetId;
                ViewBag.CreditorSupplierSearchSaleTypeTargetId = saleTypeTargetId;

                ViewBag.CreditorSupplierSearchCreditorIndex = creditorId <= 0 ? 0 : q1.IndexOf(q1.SingleOrDefault(t => t.Id == creditorId) ?? new Creditor());
                ViewBag.CreditorSupplierSearchSupplierIndex = supplierId <= 0 ? 0 : q2.IndexOf(q2.SingleOrDefault(t => t.Id == supplierId) ?? new Supplier());

                ViewBag.CreditorSupplierSearchAgencyId = agencyId;
                ViewBag.CreditorSupplierSearchCreditorId = creditorId;
                ViewBag.CreditorSupplierSearchSupplierId = supplierId;

                ViewBag.UseDefaultUpdateMethod = useDefaultUpdateMethod;
                return PartialView("~/Views/CreditorLedger/EditorTemplates/CreditorSupplierSearchEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorSupplierSearch_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Suppliers
        public IActionResult Suppliers() {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Supplier_Edit(int supplierId) {
            try {
                Supplier q = null;

                if (supplierId <= 0) {
                    q = new Supplier {
                        Id = 0,
                        Name = string.Empty,
                        IataCode = string.Empty,
                        DxNo = string.Empty,
                        AddressPrintOption = AddressPrintOption.NotSpecified,
                        DefaultVoucherType = VoucherType.None,
                        CityId = -1,
                        ClassId = -1,
                        SaleTypeId = -1,
                        SupplierChainId = -1,
                        CommissionRate = 0,
                        ReminderLetter = false,
                        Comments = string.Empty,
                        PickupComments = string.Empty,
                        DropoffComments = string.Empty
                    };
                }
                else {
                    q = Context.Supplier.Include(t => t.SupplierServiceTypes).ThenInclude(t => t.ServiceType).SingleOrDefault(t => t.Id == supplierId);
                }

                var model = new SupplierViewModel {
                    SupplierId = q.Id,
                    Name = q.Name,
                    IataCode = q.IataCode,
                    DxNo = q.DxNo,
                    AddressPrintOption = q.AddressPrintOption,
                    DefaultVoucherType = q.DefaultVoucherType,
                    CityId = q.CityId,
                    ClassId = q.ClassId,
                    SaleTypeId = q.SaleTypeId,
                    SupplierChainId = q.SupplierChainId,
                    CommissionRate = q.CommissionRate,
                    ReminderLetter = q.ReminderLetter,
                    Comments = q.Comments,
                    PickupComments = q.PickupComments,
                    DropoffComments = q.DropoffComments,
                    ServiceTypeIds = q.Id <= 0 ? new List<int>() : q.SupplierServiceTypes.OrderBy(t => t.ServiceType.Name).Select(t => t.ServiceTypeId)
                };

                return PartialView("~/Views/CreditorLedger/EditorTemplates/SupplierEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Supplier_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> Supplier_Read([DataSourceRequest] DataSourceRequest request, TripLineType tripLineType, BspAgentType bspAgentType, int creditorId, string text, bool isExport, int? id) {
            try {
                string cityCode = string.Empty;

                if (request.Filters != null) {
                    foreach (var filter in request.Filters) {
                        if (filter is CompositeFilterDescriptor) {
                            foreach (var filterDescriptor in (filter as CompositeFilterDescriptor).FilterDescriptors.Cast<FilterDescriptor>()) {
                                if (filterDescriptor.Member == "CityCode") {
                                    cityCode = filterDescriptor.ConvertedValue.ToStringExt();
                                }
                                else if (filterDescriptor.Member == "Name") {
                                    text = filterDescriptor.ConvertedValue.ToStringExt();
                                }
                            }
                        }
                        else {
                            var filterDescriptor = filter as FilterDescriptor;

                            if (filterDescriptor.Member == "CityCode") {
                                cityCode = filterDescriptor.ConvertedValue.ToStringExt();
                            }
                            else if (filterDescriptor.Member == "Name") {
                                text = filterDescriptor.ConvertedValue.ToStringExt();
                            }
                        }
                    }

                    request.Filters.Clear();
                }

                var q = Supplier.GetSupplierQuery(LazyContext, tripLineType, bspAgentType, creditorId, cityCode, text, id);

                if (isExport) {
                    if (!HttpContext.IsAdministrator())
                        throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

                    var export = (from t1 in q.AsEnumerable()
                                  from t2 in t1.SupplierContacts.DefaultIfEmpty()
                                  select new SupplierExportModel {
                                      Supplier = t1.Name,
                                      AddressPrintOption = t1.AddressPrintOption.GetEnumDescription(),
                                      DefaultVoucherType = t1.DefaultVoucherType.GetEnumDescription(),
                                      Class = t1.Class.Name,
                                      SaleType = t1.SaleType.Name,
                                      SupplierChain = t1.SupplierChain.Name,
                                      CityCode = t1.CityId <= 0 ? string.Empty : t1.City.Code,
                                      CommissionRate = t1.CommissionRate,
                                      IsReminderLetter = t1.ReminderLetter,
                                      IataCode = t1.IataCode,
                                      DxNo = t1.DxNo,
                                      Address = string.Join(Environment.NewLine, t1.SupplierAddresses.Select(t => t.Address)),
                                      Contact = t2 == null ? string.Empty : t2.FullName,
                                      PhoneHome = t2 == null ? string.Empty : t2.PhoneHome,
                                      PhoneWork = t2 == null ? string.Empty : t2.PhoneWork,
                                      Mobile = t2 == null ? string.Empty : t2.Mobile,
                                      Fax = t2 == null ? string.Empty : t2.Fax,
                                      Email = t2 == null ? string.Empty : t2.Email,
                                      PickupComments = t1.PickupComments,
                                      DropoffComments = t1.DropoffComments,
                                      Comments = t1.Comments
                                  }).ToList();

                    var xlsx = new ExportToExcel<SupplierExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Suppliers.xlsx");
                }

                var result = await q.Select(row => new SupplierViewModel {
                    SupplierId = row.Id,
                    Name = row.Name,
                    Creditors = string.Join("; ", row.SupplierCreditors.Select(t => t.Creditor.Name).Distinct()),
                    SupplierChain = row.SupplierChainId <= 0 ? string.Empty : row.SupplierChain.Name,
                    CityCode = row.CityId <= 0 ? string.Empty : row.City.Code,
                    CommissionRate = row.CommissionRate,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser,
                    ContactViewModel = row.SupplierContacts.Select(t => new ContactViewModel {
                        ContactId = t.Id,
                        Title = t.Title,
                        Name = t.Name,
                        PhoneHome = t.PhoneHome,
                        PhoneWork = t.PhoneWork,
                        Mobile = t.Mobile,
                        PhoneNo = t.PhoneNo,
                        Fax = t.Fax,
                        Email = t.Email,
                        IsDefaultContact = t.IsDefault,
                        LastWriteTime = t.LastWriteTime.ToLocalTime(),
                        CreationTime = t.CreationTime.ToLocalTime(),
                        LastWriteUser = t.LastWriteUser,
                        CreationUser = t.CreationUser
                    }).OrderBy(t => t.IsDefaultContact ? 0 : 1).FirstOrDefault() ?? new ContactViewModel()
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Supplier_Read", ex);

                if (isExport) {
                    return Redirect("/Shared/Error");
                }
                else {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Supplier_CreateOrUpdate(SupplierViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new SupplierCommon().CreateOrUpdate(Context, model);

                ViewBag.AddressParentId = model.SupplierId;
                ViewBag.ContactParentId = model.SupplierId;

                return Json(model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Supplier_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Supplier_Delete([DataSourceRequest] DataSourceRequest request, SupplierViewModel model) {
            try {
                new SupplierCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Supplier_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Supplier_Add(string name, int creditorId, int cityId, TripLineType tripLineType, string address1, string address2, string locality, string region, string postCode, string countryCode, string contactTitle, string contactName, string phoneHome, string phoneWork, string mobile, string fax, string email) {
            try {
                int supplierId = new SupplierCommon().Add(Context, name, creditorId, cityId, tripLineType, address1, address2, locality, region, postCode, countryCode, contactTitle, contactName, phoneHome, phoneWork, mobile, fax, email);
                return Json(supplierId);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Supplier_Add", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Supplier_GetContactDetails(int supplierId) {
            try {
                var q = Context.Supplier.Where(t => t.Id == supplierId).Select(row => new {
                    SupplierId = row.Id,
                    row.Name,
                    (row.SupplierAddresses.OrderByDescending(t2 => t2.IsDefault).FirstOrDefault() ?? new SupplierAddress()).Address,
                    (row.SupplierContacts.OrderByDescending(t2 => t2.IsDefault).FirstOrDefault() ?? new SupplierContact()).FullName,
                    (row.SupplierContacts.OrderByDescending(t2 => t2.IsDefault).FirstOrDefault() ?? new SupplierContact()).PhoneNo,
                    (row.SupplierContacts.OrderByDescending(t2 => t2.IsDefault).FirstOrDefault() ?? new SupplierContact()).Email
                }).SingleOrDefault();

                return Json(q);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Supplier_GetContactDetails", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Supplier_GetIdByName(string name) {
            try {
                int id = Context.Supplier.SingleOrDefault(t => t.Name.ToLower() == name.ToLower())?.Id ?? -2;
                return Json(id);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Supplier_GetIdByName", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> SupplierAddress(int? parentId) {
            try {
                ViewBag.AddressParentId = parentId ?? 0;
                ViewBag.AddressReadUrl = Url.Action("SupplierAddress_Read", "CreditorLedger", new { parentId = parentId ?? 0 });
                ViewBag.AddressUpdateUrl = Url.Action("SupplierAddress_CreateOrUpdate", "CreditorLedger");
                ViewBag.AddressDeleteUrl = Url.Action("SupplierAddress_Delete", "CreditorLedger");

                return PartialView("~/Views/Shared/EditorTemplates/AddressForm.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierAddress", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> SupplierAddress_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.SupplierAddress.Where(t => t.SupplierId == parentId);

                if (q.Count() == 0)
                    q = new List<SupplierAddress> { new SupplierAddress() }.AsQueryable();

                var result = await q.OrderByDescending(t => t.IsDefault).Select(row => new AddressViewModel {
                    AddressType = row.AddressType,
                    AddressId = row.Id,
                    ParentId = row.SupplierId,
                    Address1 = row.Address1,
                    Address2 = row.Address2,
                    Locality = row.Locality,
                    Region = row.Region,
                    PostCode = row.PostCode,
                    CountryCode = row.CountryCode,
                    IsDefaultAddress = row.IsDefault,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierAddress_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierAddress_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new SupplierAddressCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierAddress_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierAddress_Delete([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
            try {
                new SupplierAddressCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierAddress_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> SupplierContact(int? parentId) {
            try {
                ViewBag.ContactParentId = parentId ?? 0;
                ViewBag.ContactReadUrl = Url.Action("SupplierContact_Read", "CreditorLedger", new { parentId = parentId ?? 0 });
                ViewBag.ContactUpdateUrl = Url.Action("SupplierContact_CreateOrUpdate", "CreditorLedger");
                ViewBag.ContactDeleteUrl = Url.Action("SupplierContact_Delete", "CreditorLedger");

                ViewBag.ContactIsContactVisible = true;
                ViewBag.ContactIsPhoneHomeVisible = true;
                ViewBag.ContactIsPhoneWorkVisible = true;
                ViewBag.ContactIsMobileVisible = true;
                ViewBag.ContactIsFaxVisible = true;
                ViewBag.ContactIsEmailVisible = true;

                return PartialView("~/Views/Shared/EditorTemplates/ContactForm.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierContact", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> SupplierContact_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.SupplierContact.Where(t => t.SupplierId == parentId);

                if (q.Count() == 0)
                    q = new List<SupplierContact> { new SupplierContact() }.AsQueryable();

                var result = await q.OrderByDescending(t => t.IsDefault).Select(row => new ContactViewModel {
                    ContactId = row.Id,
                    ParentId = row.SupplierId,
                    Title = row.Title,
                    Name = row.Name,
                    PhoneHome = row.PhoneHome,
                    PhoneWork = row.PhoneWork,
                    Mobile = row.Mobile,
                    Fax = row.Fax,
                    Email = row.Email,
                    IsDefaultContact = row.IsDefault,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierContact_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierContact_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ContactViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new SupplierContactCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierContact_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierContact_Delete([DataSourceRequest] DataSourceRequest request, ContactViewModel model) {
            try {
                new SupplierContactCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierContact_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> SupplierCreditor(int parentId) {
            try {
                ViewBag.ParentId = parentId;
                return PartialView("~/Views/CreditorLedger/EditorTemplates/SupplierCreditorEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierCreditor", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> SupplierCreditor_Read([DataSourceRequest] DataSourceRequest request, int parentId, string text) {
            try {
                var q = Context.SupplierCreditor.Where(t => t.SupplierId == parentId);

                if (!string.IsNullOrEmpty(text))
                    q = q.Where(t => t.Supplier.Name.Contains(text));

                var result = await q.OrderBy(t => t.Creditor.Name).Select(row => new SupplierCreditorViewModel {
                    SupplierCreditorId = row.Id,
                    SupplierId = row.SupplierId,
                    CreditorId = row.CreditorId,
                    IsDefault = row.IsDefault,
                    CreditorName = row.Creditor.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierCreditor_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierCreditor_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SupplierCreditorViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new SupplierCreditorCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierCreditor_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierCreditor_Delete([DataSourceRequest] DataSourceRequest request, SupplierCreditorViewModel model) {
            try {
                new SupplierCreditorCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierCreditor_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> SupplierServiceRate(int parentId) {
            try {
                ViewBag.ParentId = parentId;
                return PartialView("~/Views/CreditorLedger/EditorTemplates/SupplierServiceRateEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierServiceRate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> SupplierServiceRate_Edit(int supplierServiceRateId, int supplierId) {
            try {
                SupplierServiceRate q = null;

                if (supplierServiceRateId <= 0) {
                    q = new SupplierServiceRate {
                        Id = 0,
                        SupplierId = supplierId,
                        Name = string.Empty,
                        EffectiveFromDate = DateTime.MinValue,
                        EffectiveToDate = DateTime.MinValue,
                        CreditorId = -1,
                        SaleTypeId = -1,
                        SupplierServiceId = -1,
                        ServiceTypeRateBasisId = -1
                    };
                }
                else {
                    q = Context.SupplierServiceRate.Find(supplierServiceRateId);
                }

                var model = new SupplierServiceRateViewModel {
                    SupplierServiceRateId = q.Id,
                    SupplierId = q.SupplierId,
                    SupplierServiceRateName = q.Name,
                    TravelSeason = q.TravelSeason,
                    EffectiveFromDate = q.EffectiveFromDate == DateTime.MinValue ? null : q.EffectiveFromDate,
                    EffectiveToDate = q.EffectiveFromDate == DateTime.MinValue ? null : q.EffectiveToDate,
                    SupplierServiceRateCreditorId = q.CreditorId,
                    SupplierServiceRateSaleTypeId = q.SaleTypeId,
                    SupplierServiceId = q.SupplierServiceId,
                    ServiceTypeRateBasisId = q.ServiceTypeRateBasisId,
                    Rules = q.Rules,
                    ServiceTypeRateComments = q.Comments,
                    Inactive = q.Inactive
                };

                return PartialView("~/Views/CreditorLedger/EditorTemplates/SupplierServiceRateGridEdit.cshtml", model);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierServiceRate_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> SupplierServiceRate_Read([DataSourceRequest] DataSourceRequest request, int parentId, bool isExport) {
            try {
                if (isExport) {
                    if (!HttpContext.IsAdministrator())
                        throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

                    var export = LazyContext.SupplierServiceRateDetail.Where(t => t.SupplierServiceRate.SupplierId > 0).OrderBy(t => t.SupplierServiceRate.Supplier.Name).ThenBy(t => t.SupplierServiceRate.Name).ThenBy(t => t.Name).Select(row => new SupplierServiceRateExportModel {
                        Supplier = row.SupplierServiceRate.Supplier.Name,
                        SupplierRate = row.SupplierServiceRate.Name,
                        TravelSeason = row.SupplierServiceRate.TravelSeason,
                        EffectiveFromDate = row.SupplierServiceRate.EffectiveFromDate == DateTime.MinValue ? null : row.SupplierServiceRate.EffectiveFromDate,
                        EffectiveToDate = row.SupplierServiceRate.EffectiveToDate == DateTime.MinValue ? null : row.SupplierServiceRate.EffectiveToDate,
                        Creditor = row.SupplierServiceRate.CreditorId <= 0 ? string.Empty : row.SupplierServiceRate.Creditor.Name,
                        SaleType = row.SupplierServiceRate.SaleTypeId <= 0 ? string.Empty : row.SupplierServiceRate.SaleType.Name,
                        Service = row.SupplierServiceRate.SupplierServiceId <= 0 ? string.Empty : row.SupplierServiceRate.SupplierService.Name,
                        RateBasis = row.SupplierServiceRate.ServiceTypeRateBasisId <= 0 ? string.Empty : row.SupplierServiceRate.ServiceTypeRateBasis.Name,
                        ServiceRate = row.Name,
                        Currency = row.CurrencyId <= 0 ? string.Empty : row.Currency.Name,
                        ExchangeRate = row.ExchangeRate,
                        Cost = row.Cost,
                        Rate = row.Amount,
                        Comments = row.SupplierServiceRate.Comments,
                        Inactive = row.SupplierServiceRate.Inactive ? "Yes" : "No"
                    }).ToList();

                    var xlsx = new ExportToExcel<SupplierServiceRateExportModel>(export);
                    return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Supplier Service Rates.xlsx");
                }

                var q = Context.SupplierServiceRate.Where(t => t.SupplierId == parentId).OrderBy(t => t.Name);

                var result = await q.Select(row => new SupplierServiceRateViewModel {
                    SupplierServiceRateId = row.Id,
                    SupplierId = row.SupplierId,
                    SupplierServiceRateName = row.Name,
                    TravelSeason = row.TravelSeason,
                    EffectiveFromDate = row.EffectiveFromDate == DateTime.MinValue ? null : row.EffectiveFromDate,
                    EffectiveToDate = row.EffectiveToDate == DateTime.MinValue ? null : row.EffectiveToDate,
                    SupplierServiceRateCreditorId = row.CreditorId,
                    SupplierServiceId = row.SupplierServiceId,
                    SupplierService = row.SupplierServiceId <= 0 ? string.Empty : row.SupplierService.Name,
                    ServiceTypeRateBasisId = row.ServiceTypeRateBasisId,
                    ServiceTypeRateBasis = row.ServiceTypeRateBasisId <= 0 ? string.Empty : row.ServiceTypeRateBasis.Name,
                    Rules = row.Rules,
                    ServiceTypeRateComments = row.Comments,
                    Inactive = row.Inactive,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierServiceRate_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierServiceRate_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SupplierServiceRateViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new SupplierServiceRateCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierServiceRate_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierServiceRate_Delete([DataSourceRequest] DataSourceRequest request, SupplierServiceRateViewModel model) {
            try {
                new SupplierServiceRateCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierServiceRate_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> SupplierServiceRateDetail_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.SupplierServiceRateDetail.Include(t => t.Currency).Where(t => t.SupplierServiceRateId == parentId).OrderBy(t => t.Name);

                var result = await q.Select(row => new SupplierServiceRateDetailViewModel {
                    SupplierServiceRateDetailId = row.Id,
                    SupplierServiceRateId = row.SupplierServiceRateId,
                    Name = row.Name,
                    CurrencyId = row.CurrencyId,
                    CurrencyName = row.CurrencyId <= 0 ? string.Empty : row.Currency.Name,
                    ExchangeRate = row.ExchangeRate,
                    Cost = row.Cost,
                    Amount = row.Amount,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierServiceRateDetail_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierServiceRateDetail_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SupplierServiceRateDetailViewModel model, int parentId) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new SupplierServiceRateDetailCommon().CreateOrUpdate(Context, model, parentId);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierServiceRateDetail_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierServiceRateDetail_Delete([DataSourceRequest] DataSourceRequest request, SupplierServiceRateDetailViewModel model) {
            try {
                new SupplierServiceRateDetailCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierServiceRateDetail_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> SupplierCrs(int parentId) {
            try {
                ViewBag.ParentId = parentId;
                ViewData["CityCodeList"] = Lists.GetCityCodeList(Context).Select(t => t.Value).ToArray();
                return PartialView("~/Views/CreditorLedger/EditorTemplates/SupplierCrsEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierCrs", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> SupplierCrs_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.SupplierCrs.Where(t => t.SupplierId == parentId).OrderBy(t => t.Crs);

                var result = await q.Select(row => new SupplierCrsViewModel {
                    SupplierCrsId = row.Id,
                    SupplierId = row.SupplierId,
                    Crs = row.Crs,
                    CrsCode = row.CrsCode,
                    CityCode = row.CityCode,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierCrs_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierCrs_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SupplierCrsViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new SupplierCrsCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierCrs_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierCrs_Delete([DataSourceRequest] DataSourceRequest request, SupplierCrsViewModel model) {
            try {
                new SupplierCrsCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierCrs_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        public async Task<IActionResult> SupplierUrl(int parentId) {
            try {
                ViewBag.ParentId = parentId;
                return PartialView("~/Views/CreditorLedger/EditorTemplates/SupplierUrlEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierUrl", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> SupplierUrl_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.SupplierUrl.Where(t => t.SupplierId == parentId).OrderBy(t => t.Name);

                var result = await q.Select(row => new SupplierUrlViewModel {
                    SupplierUrlId = row.Id,
                    SupplierId = row.SupplierId,
                    UrlName = row.Name,
                    Url = row.Url,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierUrl_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierUrl_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SupplierUrlViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new SupplierUrlCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierUrl_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierUrl_Delete([DataSourceRequest] DataSourceRequest request, SupplierUrlViewModel model) {
            try {
                new SupplierUrlCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierUrl_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierServiceRateSelection_Edit() {
            try {
                return PartialView("~/Views/CreditorLedger/EditorTemplates/SupplierServiceRateSelectionEdit.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierServiceRateSelection_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> SupplierServiceRateSelection_Read([DataSourceRequest] DataSourceRequest request, int tripLineId, TripLineType tripLineType, int supplierChainId, int supplierId, string supplierCityCode, int supplierClassId, int supplierServiceId, DateTime? dateFrom, DateTime? dateTo) {
            try {
                var lazyContext = LazyContext;

                var q = lazyContext.SupplierServiceRateDetail.Where(t => t.Id > 0 && !t.SupplierServiceRate.Inactive);
                var tripLineLand = lazyContext.TripLineLand.Find(tripLineId);

                if (tripLineType != TripLineType.All)
                    q = q.Where(t => t.SupplierServiceRate.SupplierService.ServiceType.TripLineType == tripLineType);

                if (supplierChainId > 0)
                    q = q.Where(t => t.SupplierServiceRate.Supplier.SupplierChainId == supplierChainId);

                if (supplierId > 0)
                    q = q.Where(t => t.SupplierServiceRate.SupplierId == supplierId);

                if (!string.IsNullOrEmpty(supplierCityCode))
                    q = q.Where(t => t.SupplierServiceRate.Supplier.City.Code == supplierCityCode);

                if (supplierClassId > 0)
                    q = q.Where(t => t.SupplierServiceRate.Supplier.ClassId == supplierClassId);

                if (supplierServiceId > 0)
                    q = q.Where(t => t.SupplierServiceRate.SupplierServiceId == supplierServiceId);

                if (dateFrom != null)
                    q = q.Where(t => t.SupplierServiceRate.EffectiveFromDate == DateTime.MinValue || t.SupplierServiceRate.EffectiveFromDate <= dateFrom);

                if (dateTo != null)
                    q = q.Where(t => t.SupplierServiceRate.EffectiveToDate == DateTime.MinValue || t.SupplierServiceRate.EffectiveToDate >= dateTo);

                var result = await q.OrderBy(t => t.SupplierServiceRate.Supplier.Name).ThenBy(t => t.SupplierServiceRate.Name).ThenBy(t => t.SupplierServiceRate.SupplierService.Name).ThenBy(t => t.Name).Select(row => new SupplierServiceRateSelectionViewModel {
                    SupplierServiceRateDetailId = row.Id,
                    SupplierChainId = row.SupplierServiceRate.Supplier.SupplierChainId,
                    CreditorId = row.SupplierServiceRate.CreditorId,
                    CreditorName = row.SupplierServiceRate.Creditor.Name,
                    SupplierId = row.SupplierServiceRate.SupplierId,
                    SupplierName = row.SupplierServiceRate.Supplier.Name,
                    SupplierCityCode = row.SupplierServiceRate.Supplier.CityId <= 0 ? string.Empty : row.SupplierServiceRate.Supplier.City.Code,
                    TravelSeason = row.SupplierServiceRate.TravelSeason,
                    SupplierClassName = row.SupplierServiceRate.Supplier.ClassId <= 0 ? string.Empty : row.SupplierServiceRate.Supplier.Class.Name,
                    EffectiveFromDate = row.SupplierServiceRate.EffectiveFromDate == DateTime.MinValue ? null : row.SupplierServiceRate.EffectiveFromDate,
                    EffectiveToDate = row.SupplierServiceRate.EffectiveToDate == DateTime.MinValue ? null : row.SupplierServiceRate.EffectiveToDate,
                    SupplierServiceRateSaleTypeId = row.SupplierServiceRate.SaleTypeId,
                    SupplierServiceRateSaleTypeName = row.SupplierServiceRate.SaleTypeId <= 0 ? string.Empty : row.SupplierServiceRate.SaleType.Name,
                    SupplierServiceId = row.SupplierServiceRate.SupplierServiceId,
                    SupplierRateName = row.SupplierServiceRate.Name,
                    SupplierServiceName = row.SupplierServiceRate.SupplierServiceId <= 0 ? string.Empty : row.SupplierServiceRate.SupplierService.Name,
                    SupplierServiceRateName = row.Name,
                    SupplierServiceTypeRateBasisId = row.SupplierServiceRate.ServiceTypeRateBasisId,
                    SupplierServiceTypeRateBasisName = row.SupplierServiceRate.ServiceTypeRateBasisId <= 0 ? string.Empty : row.SupplierServiceRate.ServiceTypeRateBasis.Name,
                    SupplierPickupComments = row.SupplierServiceRate.Supplier.PickupComments,
                    SupplierDropoffComments = row.SupplierServiceRate.Supplier.DropoffComments,
                    SupplierServiceComments = row.SupplierServiceRate.Comments,
                    SupplierServiceRules = row.SupplierServiceRate.Rules,
                    SupplierServiceRateCurrencyName = row.CurrencyId <= 0 ? string.Empty : row.Currency.Name,
                    SupplierServiceRateExchangeRate = row.ExchangeRate,
                    SupplierServiceRateCost = row.ExchangeRate == 0 ? 0 : Math.Round(row.Cost / row.ExchangeRate, 2),
                    SupplierServiceRateAmount = row.Amount,
                    SupplierComments = row.SupplierServiceRate.Supplier.Comments,
                    SupplierServiceRateComments = row.SupplierServiceRate.Comments
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierServiceRateSelection_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Supplier Chains
        public IActionResult SupplierChains() {
            return View("~/Views/Common/SupplierChains.cshtml");
        }

        public async Task<IActionResult> SupplierChain_Read([DataSourceRequest] DataSourceRequest request) {
            try {
                var q = Context.SupplierChain.Where(t => t.Id > 0).OrderBy(t => t.Name);

                var result = await q.Select(row => new SupplierChainViewModel {
                    SupplierChainId = row.Id,
                    Name = row.Name,
                    IataCode = row.IataCode,
                    ServiceTypeId = row.ServiceTypeId,
                    CreditorId = row.CreditorId,
                    Creditor = row.CreditorId <= 0 ? string.Empty : row.Creditor.Name,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierChain_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierChain_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SupplierChainViewModel model) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new SupplierChainCommon().CreateOrUpdate(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierChain_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierChain_Delete([DataSourceRequest] DataSourceRequest request, SupplierChainViewModel model) {
            try {
                new SupplierChainCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierChain_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> SupplierChainCrs_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
            try {
                var q = Context.SupplierChainCrs.Where(t => t.SupplierChainId == parentId).OrderBy(t => t.Crs);

                var result = await q.Select(row => new SupplierChainCrsViewModel {
                    SupplierChainCrsId = row.Id,
                    SupplierChainId = row.SupplierChainId,
                    Crs = row.Crs,
                    CrsCode = row.CrsCode,
                    LastWriteTime = row.LastWriteTime.ToLocalTime(),
                    CreationTime = row.CreationTime.ToLocalTime(),
                    LastWriteUser = row.LastWriteUser,
                    CreationUser = row.CreationUser
                }).ToDataSourceResultAsync(request);

                return Json(result);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierChainCrs_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierChainCrs_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, SupplierChainCrsViewModel model, int parentId) {
            try {
                if (!ModelState.IsValid)
                    throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

                new SupplierChainCrsCommon().CreateOrUpdate(Context, model, parentId);
                return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierChainCrs_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SupplierChainCrs_Delete([DataSourceRequest] DataSourceRequest request, SupplierChainCrsViewModel model) {
            try {
                new SupplierChainCrsCommon().Delete(Context, model);
                return Json(await new[] { model }.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SupplierChainCrs_Delete", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }
        #endregion

        #region Reports
        public IActionResult Reports() {
            ViewBag.DateTo = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek - 14);
            return View();
        }

        public async Task<IActionResult> Creditor_Report(CreditorReportSourceModel model) {
            try {
                model.CustomerId = HttpContext.CurrentCustomerId();
                model.DefaultAgency = await HttpContext.CurrentDefaultAgencyName(Cache);
                model.CreationUser = HttpContext.UserFullName();
                model.CreationTime = HttpContext.Now();

                var reportSource = CreditorLedgerDataSources.GetReportSource(Context, model);

                RenderingResult result = null;
                string fileName = null;

                switch (model.OutputType) {
                    default:
                        return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
                    case "ExportPdf":
                        result = Utils.ExportToPdf(reportSource);
                        fileName = string.Format("{0}.pdf", CreditorLedgerDataSources.GetReportFileName(model.ReportSource));
                        break;
                    case "ExportWord":
                        result = Utils.ExportToWord(reportSource);
                        fileName = string.Format("{0}.docx", CreditorLedgerDataSources.GetReportFileName(model.ReportSource));
                        break;
                    case "ExportExcel":
                        result = Utils.ExportToExcel(reportSource);
                        fileName = string.Format("{0}.xlsx", CreditorLedgerDataSources.GetReportFileName(model.ReportSource));
                        break;
                }

                return File(result.DocumentBytes, result.MimeType, fileName);
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Creditor_Report", ex);

                if (model.OutputType == "Report") {
                    return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
                }
                else {
                    return Redirect("/Shared/Error");
                }
            }
        }
        #endregion
    }
}