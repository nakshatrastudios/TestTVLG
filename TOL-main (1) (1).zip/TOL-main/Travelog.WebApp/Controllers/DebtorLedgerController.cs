﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Telerik.Reporting.Processing;
using Travelog.Biz;
using Travelog.Biz.Dao.DebtorLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;
using Travelog.Reports.DebtorLedger;
using Travelog.WebApp.DebtorLedger;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.Controllers {
    [Authorize]
	public class DebtorLedgerController : BaseController {
		private const string ClassName = "Travelog.WebApp.Controllers.DebtorLedgerController";

        public DebtorLedgerController(IWebHostEnvironment webHostEnvironment, IDistributedCache cache) : base(webHostEnvironment, cache) {
        }
        
		#region Debtors
        public IActionResult Index() {
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Debtor_Edit(int debtorId, int agencyId) {
			try {
				if (agencyId <= 0)
					agencyId = HttpContext.CurrentDefaultAgencyId();

				if (agencyId <= 0)
					throw new UnreportedException(AppConstants.AgencyNotSpecified);

				Debtor q = null;

				if (debtorId <= 0) {
					q = new Debtor {
						Id = 0,
                        AgencyId = agencyId,
                        Code = string.Empty,
						Name = string.Empty,
						ReportingParentId = -1,
						BillingParentId = -1,
						AmadeusCid = string.Empty,
						GalileoCid = string.Empty,
						SabreCid = string.Empty,
						OrderNoMinLength = 0,
						CurrencyId = -1,
						ClassId = -1,
						LocationId = -1,
						AgingCycle = AgingCycle.SevenDay,
						AgingCycleStartDay = DayOfWeekExt.Monday,
						PaymentTermId = Context.PaymentTerm.First().Id,
						MatchedTxnsReportOption = MatchedTxnsReportOption.ExcludeAll,
						ItineraryPricingOption = ItineraryPricingOption.No,
						PrismReporting = false,
						PrismReportingStartDate = DateTime.MinValue,
						PrismReportingTripId = -1,
						VideoConferencingDomestic = false,
						VideoConferencingShortHaul = false,
						VideoConferencingInternational = false,
						IsAutoInvoice = false,
						IsAuthorisationMandatory = false,
						IsContactMandatory = false,
						IsOrderNoMandatory = false,
						IsTravelReasonMandatory = false,
						IsTaxInInvoiceLineAmount = false,
						IsContactLimitedToCurrentList = false,
						IsProfileChangesPrevented = false,
						Rules = string.Empty,
						Remarks = string.Empty,
						CreditLimit = 0,
						InvoiceValidationType = InvoiceValidationType.DisplayWarning
					};
				}
				else {
					q = Context.Debtor.Find(debtorId);
				}

				var model = new DebtorViewModel {
					DebtorId = q.Id,
					AgencyId = q.AgencyId,
					Code = q.Code,
					Name = q.Name,
					ReportingParentId = q.ReportingParentId,
					BillingParentId = q.BillingParentId,
					CustomerId = q.CustomerId,
					AmadeusCid = q.AmadeusCid,
					GalileoCid = q.GalileoCid,
					SabreCid = q.SabreCid,
					OrderNoMinLength = q.OrderNoMinLength,
					CurrencyId = q.CurrencyId,
					ClassId = q.ClassId,
					LocationId = q.LocationId,
					AgingCycle = q.AgingCycle,
					AgingCycleStartDay = q.AgingCycleStartDay,
					PaymentTermId = q.PaymentTermId,
					MatchedTxnsReportOption = q.MatchedTxnsReportOption,
					ItineraryPricingOption = q.ItineraryPricingOption,
					PrismReporting = q.PrismReporting,
					PrismReportingStartDate = q.PrismReportingStartDate,
					PrismReportingTripId = q.PrismReportingTripId,
					VideoConferencingDomestic = q.VideoConferencingDomestic,
					VideoConferencingShortHaul = q.VideoConferencingShortHaul,
					VideoConferencingInternational = q.VideoConferencingInternational,
					IsAutoInvoice = q.IsAutoInvoice,
					IsAuthorisationMandatory = q.IsAuthorisationMandatory,
					IsContactMandatory = q.IsContactMandatory,
					IsOrderNoMandatory = q.IsOrderNoMandatory,
					IsTravelReasonMandatory = q.IsTravelReasonMandatory,
					IsTaxInInvoiceLineAmount = q.IsTaxInInvoiceLineAmount,
					IsContactLimitedToCurrentList = q.IsContactLimitedToCurrentList,
					IsProfileChangesPrevented = q.IsProfileChangesPrevented,
					Rules = q.Rules,
					Remarks = q.Remarks,
					CreditLimit = q.CreditLimit,
					InvoiceValidationType = q.InvoiceValidationType
				};

				return PartialView("~/Views/DebtorLedger/EditorTemplates/DebtorEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Debtor_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Debtor_Read([DataSourceRequest] DataSourceRequest request, int agencyId, string text, bool isExport, int? id = null) {
			try {
				var context = Context;
				var q = context.Debtor.Where(t => t.Id > 0).OrderBy(t => t.Name).Select(t => t);

				if (agencyId > 0) {
					q = q.Where(t => t.AgencyId == agencyId);
				}

				if (!string.IsNullOrEmpty(text)) {
					text = text.Trim().ToLower();
					q = q.Where(t => t.Code.ToLower().Contains(text) || t.Name.ToLower().Contains(text));
				}

				if (id != null)
					q = q.Where(t => t.Id == id);

				if (isExport) {
					if (!HttpContext.IsAdministrator())
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var export = (from t1 in q.Include(t => t.DebtorContacts).Include(t => t.PaymentTerm).Include(t => t.Currency).Include(t => t.Class).Include(t => t.Location).Include(t => t.Agency).Include(t => t.ReportingParent).Include(t => t.BillingParent).Include(t => t.PrismReportingTrip).Include(t => t.DebtorAddresses).AsEnumerable()
						from t2 in t1.DebtorContacts.DefaultIfEmpty()
						select new DebtorExportModel {
							Code = t1.Code,
							Debtor = t1.Name,
							ReportingParentDebtor = t1.ReportingParent.Name,
							BillingParentDebtor = t1.BillingParent.Name,
							AgingCycle = t1.AgingCycle.GetEnumDescription(),
							AgingCycleStartDay = t1.AgingCycleStartDay.GetEnumDescription(),
							PaymentTerm = t1.PaymentTerm.Name,
							ItineraryPricingOption = t1.ItineraryPricingOption.GetEnumDescription(),
							Currency = t1.Currency.Name,
							Class = t1.Class.Name,
							Location = t1.Location.Name,
							Agency = t1.Agency.Name,
							PrismReporting = t1.PrismReporting,
							PrismReportingStartDate = t1.PrismReportingStartDate,
							PrismReportingTrip = t1.PrismReportingTrip.FullName,
							AmadeusCid = t1.AmadeusCid,
							GalileoCid = t1.GalileoCid,
							SabreCid = t1.SabreCid,
							OrderNoMinLength = t1.OrderNoMinLength,
							Address = string.Join(Environment.NewLine, t1.DebtorAddresses.Select(t => t.Address)),
							Contact = t2 == null ? string.Empty : t2.FullName,
							PhoneHome = t2 == null ? string.Empty : t2.PhoneHome,
							PhoneWork = t2 == null ? string.Empty : t2.PhoneWork,
							Mobile = t2 == null ? string.Empty : t2.Mobile,
							Fax = t2 == null ? string.Empty : t2.Fax,
							Email = t2 == null ? string.Empty : t2.Email,
							VideoConferencingDomestic = t1.VideoConferencingDomestic,
							VideoConferencingShortHaul = t1.VideoConferencingShortHaul,
							VideoConferencingInternational = t1.VideoConferencingInternational,
							IsAutoInvoice = t1.IsAutoInvoice,
							IsTaxInInvoiceLineAmount = t1.IsTaxInInvoiceLineAmount,
							IsContactLimitedToCurrentList = t1.IsContactLimitedToCurrentList,
							IsAuthorisationMandatory = t1.IsAuthorisationMandatory,
							IsContactMandatory = t1.IsContactMandatory,
							IsOrderNoMandatory = t1.IsOrderNoMandatory,
							IsProfileChangesPrevented = t1.IsProfileChangesPrevented,
							IsTravelReasonMandatory = t1.IsTravelReasonMandatory,
							Rules = t1.Rules,
							Remarks = t1.Remarks,
							CreditLimit = t1.CreditLimit,
							InvoiceValidation = t1.InvoiceValidationType.GetEnumDescription()
						}).ToList();

					var xlsx = new ExportToExcel<DebtorExportModel>(export);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Debtors.xlsx");
				}

				var result = await q.Select(row => new DebtorViewModel {
					DebtorId = row.Id,
					Code = row.Code,
					Name = row.Name,
					ItineraryPricingOption = row.ItineraryPricingOption,
					AgingCycle = row.AgingCycle,
					CreditLimit = row.CreditLimit,
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser,
					ContactViewModel = row.DebtorContacts.Select(t => new ContactViewModel {
						ContactId = t.Id,
						Title = t.Title,
						Name = t.Name,
						PhoneHome = t.PhoneHome,
						PhoneWork = t.PhoneWork,
						Mobile = t.Mobile,
						PhoneNo = t.PhoneNo,
						Fax = t.Fax,
						Email = t.Email,
						IsDefaultContact = t.IsDefault,
						LastWriteTime = t.LastWriteTime.ToLocalTime(),
						CreationTime = t.CreationTime.ToLocalTime(),
						LastWriteUser = t.LastWriteUser,
						CreationUser = t.CreationUser
					}).OrderBy(t => t.IsDefaultContact ? 0 : 1).FirstOrDefault() ?? new ContactViewModel()
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Debtor_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Debtor_GetNewCode(string name) {
			try {
				return Json(Debtor.GetNewCode(Context, name));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Debtor_GetNewCode", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Debtor_CreateOrUpdate(DebtorViewModel model) {
			try {
				if (!model.PrismReporting) {
					model.PrismReportingStartDate = DateTime.MinValue;
					model.PrismReportingTripId = -1;
					ModelState.Clear();
					TryValidateModel(model);
				}

				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				new DebtorCommon(HttpContext).CreateOrUpdate(LazyContext, model);

				ViewBag.AddressParentId = model.DebtorId;
				ViewBag.ContactParentId = model.DebtorId;

				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Debtor_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Debtor_Delete([DataSourceRequest] DataSourceRequest request, DebtorViewModel model) {
			try {
				new DebtorCommon(HttpContext).Delete(Context, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Debtor_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		public async Task<IActionResult> DebtorAddress(int? parentId) {
			try {
				ViewBag.AddressParentId = parentId ?? 0;
				ViewBag.AddressReadUrl = Url.Action("DebtorAddress_Read", "DebtorLedger", new { parentId = parentId ?? 0 });
				ViewBag.AddressUpdateUrl = Url.Action("DebtorAddress_CreateOrUpdate", "DebtorLedger");
				ViewBag.AddressDeleteUrl = Url.Action("DebtorAddress_Delete", "DebtorLedger");

				return PartialView("~/Views/Shared/EditorTemplates/AddressForm.cshtml");
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorAddress", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> DebtorAddress_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
			try {
				var q = Context.DebtorAddress.Where(t => t.DebtorId == parentId);

				if (q.Count() == 0)
					q = new List<DebtorAddress> { new DebtorAddress() }.AsQueryable();

				var result = await q.OrderByDescending(t => t.IsDefault).Select(row => new AddressViewModel {
					AddressType = row.AddressType,
					AddressId = row.Id,
					ParentId = row.DebtorId,
					Address1 = row.Address1,
					Address2 = row.Address2,
					Locality = row.Locality,
					Region = row.Region,
					PostCode = row.PostCode,
					CountryCode = row.CountryCode,
					IsDefaultAddress = row.IsDefault,
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorAddress_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DebtorAddress_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				new DebtorAddressCommon().CreateOrUpdate(Context, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorAddress_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DebtorAddress_Delete([DataSourceRequest] DataSourceRequest request, AddressViewModel model) {
			try {
				new DebtorAddressCommon().Delete(Context, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorAddress_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		public async Task<IActionResult> DebtorContact(int? parentId) {
			try {
				ViewBag.ContactParentId = parentId ?? 0;
				ViewBag.ContactReadUrl = Url.Action("DebtorContact_Read", "DebtorLedger", new { parentId = parentId ?? 0 });
				ViewBag.ContactUpdateUrl = Url.Action("DebtorContact_CreateOrUpdate", "DebtorLedger");
				ViewBag.ContactDeleteUrl = Url.Action("DebtorContact_Delete", "DebtorLedger");

				ViewBag.ContactIsContactVisible = true;
				ViewBag.ContactIsPhoneHomeVisible = true;
				ViewBag.ContactIsPhoneWorkVisible = true;
				ViewBag.ContactIsMobileVisible = true;
				ViewBag.ContactIsFaxVisible = true;
				ViewBag.ContactIsEmailVisible = true;
				ViewBag.ContactOption1Label = "Can Book";
				ViewBag.ContactOption2Label = "Can Authorise";

				return PartialView("~/Views/Shared/EditorTemplates/ContactForm.cshtml");
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorContact", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> DebtorContact_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
			try {
				var q = Context.DebtorContact.Where(t => t.DebtorId == parentId);

				if (q.Count() == 0)
					q = new List<DebtorContact> { new DebtorContact() }.AsQueryable();

				var result = await q.OrderByDescending(t => t.IsDefault).Select(row => new ContactViewModel {
					ContactId = row.Id,
					ParentId = row.DebtorId,
					Title = row.Title,
					Name = row.Name,
					PhoneHome = row.PhoneHome,
					PhoneWork = row.PhoneWork,
					Mobile = row.Mobile,
					Fax = row.Fax,
					Email = row.Email,
					IsDefaultContact = row.IsDefault,
					Option1 = row.CanBook,
					Option2 = row.CanAuthorise,
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorContact_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DebtorContact_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, ContactViewModel model) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				new DebtorContactCommon().CreateOrUpdate(Context, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorContact_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DebtorContact_Delete([DataSourceRequest] DataSourceRequest request, ContactViewModel model) {
			try {
				new DebtorContactCommon().Delete(Context, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorContact_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DebtorContact_Add(int debtorId, string type, string title, string name, string phoneHome, string phoneWork, string mobile, string email) {
			try {
				int debtorContactId = new DebtorContactCommon().Add(Context, debtorId, type, title, name, phoneHome, phoneWork, mobile, email);
				return Json(debtorContactId);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorContact_Add", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DebtorLink_Edit(int agencyId = 0) {
			try {
				ViewBag.AgencyId = agencyId == 0 ? HttpContext.CurrentDefaultAgencyId() : agencyId;
				return PartialView("~/Views/DebtorLedger/EditorTemplates/DebtorLinkEdit.cshtml");
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorLink", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> DebtorLink_Read(int debtorParentTypeId, int debtorId = -1) {
			try {
				var q = Context.Debtor.Where(t => t.Id > 0).OrderBy(t => t.Name).Select(row => new {
					DebtorId = row.Id,
					ParentId = debtorParentTypeId == 0 ? row.ReportingParentId : row.BillingParentId,
					DebtorName = string.Concat(row.Name, " [", row.Code, "]")
				});

				var result = q.Where(t => t.ParentId == debtorId).Select(row => new DebtorLinkViewModel {
					DebtorId = row.DebtorId,
					DebtorName = row.DebtorName,
					HasChildren = q.Any(t => t.ParentId == row.DebtorId)
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorLink_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DebtorLink_Update(int debtorParentTypeId, int debtorId, int parentId) {
			try {
				var model = new DebtorCommon(HttpContext).UpdateParent(LazyContext, debtorParentTypeId, debtorId, parentId);
				return Json(new { model.DebtorId, DebtorName = string.Format("{0} [{1}]", model.Name, model.Code) });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorLink_Update", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region Reports
		public IActionResult Reports() {
			return View();
		}

		public async Task<IActionResult> Debtor_Report(DebtorReportSourceModel model) {
			try {
				model.CustomerId = HttpContext.CurrentCustomerId();
				model.DefaultAgency = await HttpContext.CurrentDefaultAgencyName(Cache);
				model.CreationUser = HttpContext.UserFullName();
				model.CreationTime = HttpContext.Now();

				var reportSource = DebtorLedgerDataSources.GetReportSource(Context, model);

				RenderingResult result = null;
				string fileName = null;

				switch (model.OutputType) {
					default:
						return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
					case "ExportPdf":
						result = Utils.ExportToPdf(reportSource);
						fileName = string.Format("{0}.pdf", DebtorLedgerDataSources.GetReportFileName(model.ReportSource));
						break;
					case "ExportWord":
						result = Utils.ExportToWord(reportSource);
						fileName = string.Format("{0}.docx", DebtorLedgerDataSources.GetReportFileName(model.ReportSource));
						break;
					case "ExportExcel":
						result = Utils.ExportToExcel(reportSource);
						fileName = string.Format("{0}.xlsx", DebtorLedgerDataSources.GetReportFileName(model.ReportSource));
						break;
				}

				return File(result.DocumentBytes, result.MimeType, fileName);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Debtor_Report", ex);

				if (model.OutputType == "Report") {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
				else {
					return Redirect("/Shared/Error");
				}
			}
		}
		#endregion
	}
}