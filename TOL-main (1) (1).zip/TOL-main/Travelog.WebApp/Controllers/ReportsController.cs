using System.Collections.Concurrent;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Telerik.Reporting.Processing;
using Telerik.Reporting.Services;
using Telerik.Reporting.Services.AspNetCore;

namespace Travelog.WebApp.Controllers {
    [Authorize]
    [Route("/api/reports")]
    public class ReportsController : ReportsControllerBase {
        public ReportsController(IReportServiceConfiguration reportServiceConfiguration) : base(reportServiceConfiguration) {
        }

        protected override UserIdentity GetUserIdentity() {
            var identity = base.GetUserIdentity();
            identity.Context = new ConcurrentDictionary<string, object>();

            identity.Context["CustomerId"] = HttpContext.CurrentCustomerId();
            identity.Context["UserName"] = HttpContext.User.Identity.Name;

            return identity;
        }
    }
}