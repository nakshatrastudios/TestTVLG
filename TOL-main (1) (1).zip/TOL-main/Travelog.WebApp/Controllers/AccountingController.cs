﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Kendo.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.Infrastructure;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Telerik.Reporting;
using Telerik.Reporting.Processing;
using Travelog.Biz;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Dao.DebtorLedger;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;
using Travelog.Ledger.Accounting;
using Travelog.Ledger.Models;
using Travelog.Reports.Accounting;
using Travelog.WebApp.Accounting;
using Travelog.WebApp.ClientLedger;
using Travelog.WebApp.Models;

namespace Travelog.WebApp.Controllers {
    [Authorize]
	public class AccountingController : BaseController {
		private const string ClassName = "Travelog.WebApp.Controllers.AccountingController";

        public AccountingController(IWebHostEnvironment webHostEnvironment, IDistributedCache cache) : base(webHostEnvironment, cache) {
        }
        
		#region Receipts
        public IActionResult Receipts(string message = null, MessageType messageType = MessageType.Info, int timeoutSeconds = 30) {
			ViewBag.Message = message;
			ViewBag.MessageType = messageType;
			ViewBag.TimeoutSeconds = timeoutSeconds;
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Receipt_Edit(int receiptId, int accountTypeId, int receiptTypeId, int tripId, int debtorId, bool isNative, string createOption = null) {
			try {
				var lazyContext = LazyContext;
				const bool isTaxIncluded = true;

				var accountType = (AccountType)accountTypeId;
				var receiptType = (ReceiptType)receiptTypeId;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isAccounts = HttpContext.IsAccounts();
				bool isSuperUser = HttpContext.IsSuperUser();

				var trip = lazyContext.Trip.Find(tripId);
				bool isBooking = trip?.IsBooking ?? false;

				Receipt q = null;

				if (receiptId <= 0) {
					q = new Receipt {
						Id = 0,
						AccountType = accountType,
						ReceiptType = receiptType,
						DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Receipt"),
						DocumentDate = DateTime.Today,
						TripId = isBooking ? tripId : 0,
						Trip = isBooking ? trip : new Trip(),
						DebtorId = debtorId,
						Debtor = new Debtor { Id = debtorId },
                        CreditorId = -1,
                        Creditor = new Creditor { Id = -1 },
                        ChartOfAccountId = -1,
						ChartOfAccount = new ChartOfAccount { Id = -1 },
						SaleTypeId = -1,
						SaleType = new SaleType { Id = -1 },
						SourceId = -1,
						CategoryId = -1,
						BankAccountId = receiptType == ReceiptType.Admin ? HttpContext.AdminBankAccountId() : HttpContext.TravelBankAccountId(),
						AgencyId = HttpContext.CurrentDefaultAgencyId(),
                        Agency = lazyContext.Agency.Find(HttpContext.CurrentDefaultAgencyId()),
                        ConsultantId = HttpContext.CurrentConsultantId(),
                        DiscountReasonId = -1,
						CancellationSaleTypeId = -1
					};
				}
				else {
					q = lazyContext.Receipt.Find(receiptId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				int? receiptTripId = -1;
				int? receiptDebtorId = -1;
				int? receiptCreditorId = -1;
				int? receiptSupplierId = -1;
				int? receiptChartOfAccountId = -1;
				int? receiptSaleTypeId = -1;
				int? receiptDiscountReasonId = -1;
				int? receiptCancellationSaleTypeId = -1;
				int? receiptBankAccountFromId = -1;
				string receiptPayer = string.Empty;

				if (q.Id > 0) {
					receiptTripId = q.TripId;
					receiptDebtorId = q.DebtorId;
					receiptCreditorId = q.CreditorId;
					receiptSupplierId = q.SupplierId;
					receiptChartOfAccountId = q.ChartOfAccountId;
					receiptSaleTypeId = q.AccountType == AccountType.Creditor && q.SupplierCommissionType == SupplierCommissionType.None && q.SaleTypeId <= 0 ? null : q.SaleTypeId;
					receiptDiscountReasonId = q.DiscountReasonId;
					receiptBankAccountFromId = (lazyContext.BankAccount.Where(t => t.ChartOfAccountId == q.ChartOfAccountId).SingleOrDefault() ?? new BankAccount { Id = -1 }).Id;
					receiptPayer = q.ReceiptType == ReceiptType.Admin || q.ReceiptType == ReceiptType.Transfer ? q.Payer : string.Empty;

					if (q.AccountType == AccountType.Creditor && q.ReceiptType == ReceiptType.Refund)
						receiptCancellationSaleTypeId = q.CancellationFee + q.CancellationFeeTax != 0 && q.CancellationSaleTypeId <= 0 ? null : q.CancellationSaleTypeId;
				}
				else {
					switch (q.AccountType) {
						case AccountType.Client:
							if (isNative) {
								receiptTripId = null;
							}
							else {
								receiptTripId = q.TripId;
							}

							break;
						case AccountType.Debtor:
							if (isNative) {
								receiptDebtorId = null;
							}
							else {
								receiptDebtorId = q.DebtorId;
							}

							break;
						case AccountType.Creditor:
							receiptCreditorId = null;
							receiptSupplierId = null;
							receiptSaleTypeId = null;

							if (q.ReceiptType == ReceiptType.Refund) {
								receiptCancellationSaleTypeId = null;
								break;
							}

							var glSetting = Setting.GetRow(HttpContext.CurrentCustomerId(), q.DocumentDate);

							if (q.ReceiptType == ReceiptType.VoucherCommission) {
								receiptChartOfAccountId = glSetting.OtherCommissionAccount.Id;
							}
							else {
								switch (q.SupplierCommissionType) {
									case SupplierCommissionType.None:
										receiptChartOfAccountId = glSetting.OtherCommissionAccount.Id;
										break;
									case SupplierCommissionType.Creditor:
										receiptChartOfAccountId = glSetting.CreditorControlAccount.Id;
										break;
								}
							}

							break;
						case AccountType.GeneralLedger:
							if (q.ReceiptType == ReceiptType.Transfer) {
								receiptBankAccountFromId = null;
							}
							else {
								receiptChartOfAccountId = null;
							}

							break;
					}

					q.ChartOfAccountId = receiptChartOfAccountId ?? -1;
					q.SaleTypeId = receiptSaleTypeId ?? -1;
				}

				var rateModel = new RateModel {
					Commission = q.Commission,
					CommissionTax = q.CommissionTax,
					Discount = q.Discount,
					DiscountTax = q.DiscountTax,
					IsTaxIncluded = isTaxIncluded,
					IsFormBinding = true
				};

				var rates = new AccountingRates<Receipt>(HttpContext, q, rateModel);
				rates.SetRates(new List<string> { "Commission", "Discount" });

				var model = new ReceiptViewModel {
					ReceiptViewId = q.Id,
					ReceiptId = q.Id,
					ReceiptDocumentStatus = q.DocumentStatus,
					ReceiptReversalStatus = q.ReversalStatus,
					ReceiptAccountType = q.AccountType,
					ReceiptEffectiveAccountType = q.EffectiveAccountType,
					ReceiptType = q.ReceiptType,
					ReceiptDocumentNo = q.DocumentNo,
					ReceiptDocumentDate = q.IsDeposit ? q.DocumentDate.Date : q.DocumentDate,
					ReceiptPayer = receiptPayer,
					ReceiptProfileId = q.Trip.ProfileId,
					ReceiptTripId = receiptTripId,
					ReceiptDebtorId = receiptDebtorId,
					ReceiptCreditorId = receiptCreditorId,
					ReceiptSupplierId = receiptSupplierId,
					ReceiptChartOfAccountId = receiptChartOfAccountId,
					ReceiptBankAccountFromId = receiptBankAccountFromId,
					ReceiptBankAccountToId = q.DocumentStatus == DocumentStatus.Open && q.Id <= 0 && q.BankAccountId == -1 ? null : q.BankAccountId,
					ReceiptSupplierCommissionType = q.SupplierCommissionType,
					ReceiptSaleTypeId = receiptSaleTypeId,
					ReceiptCategoryId = q.CategoryId,
					ReceiptConsultantId = q.ConsultantId,
					ReceiptSourceId = q.SourceId,
					ReceiptNonCommissionable = q.NonCommissionableGross,
					ReceiptCancellationFee = q.CancellationFee + q.CancellationFeeTax,
					ReceiptCancellationSaleTypeId = receiptCancellationSaleTypeId,
					ReceiptSupplierCancellationFee = q.SupplierCancellationFee + q.SupplierCancellationFeeTax,
					ReceiptAmountToBank = q.AmountToBank + q.AmountToBankTax,
					ReceiptOriginalSaleTotal = q.OriginalSaleTotal + q.OriginalSaleTotalTax,
					ReceiptIsTaxIncluded = isTaxIncluded,
					ReceiptIsSplit = q.IsSplit,
					ReceiptStandardCommentId = q.StandardCommentId,
					ReceiptStandardComment = q.StandardCommentId <= 0 ? string.Empty : q.StandardComment.Comment,
					ReceiptFormOfPayment = string.Empty,
					ReceiptAgencyId = q.AgencyId,
					ReceiptDocumentTotal = q.GetDocumentTotal(lazyContext),
					ReceiptIsDeposit = q.IsDeposit,
					ReceiptIsIssued = q.IsIssued,
					ReceiptIsTaxApplicable = q.IsTaxApplicable,
					ReceiptIsClientAccountLocked = q.IsClientAccountLocked,
					ReceiptEmail = q.EmailRecipient,
                    ReceiptAgencyEmail = q.Agency.AgencyUserEmails.SingleOrDefault(t => t.UserId == HttpContext.UserId())?.Email ?? HttpContext.User.Identity.Name,
                    ReceiptDepositDate = q.Id > 0 && q.ReceiptType == ReceiptType.Transfer && q.DocumentStatus == DocumentStatus.Closed ? q.DocumentDate : null,
					ReceiptBankAccountStatementName = q.Id > 0 && q.ReceiptDetails.FirstOrDefault()?.BankAccountStatementId <= 0 ? string.Empty : q.ReceiptDetails.FirstOrDefault()?.BankAccountStatement.Name,
					ReceiptCanEdit = q.CanEdit(isAdministrator, isAccounts, isSuperUser),
					ReceiptCanDelete = q.CanDelete(isAdministrator, isAccounts, isSuperUser),
					ReceiptCanUndo = q.CanUndo(false),
					ReceiptCanReverse = q.CanReverse(),
					ReceiptCommission = q.Commission + (isTaxIncluded ? q.CommissionTax : 0),
					ReceiptCommissionTax = q.CommissionTax,
					ReceiptCommissionRate = rateModel.CommissionRate,
					ReceiptCommissionTaxRate = rateModel.CommissionTaxRate,
					ReceiptDiscount = q.Discount + (isTaxIncluded ? q.DiscountTax : 0),
					ReceiptDiscountTax = rateModel.DiscountTax,
					ReceiptDiscountRate = rateModel.DiscountRate,
					ReceiptDiscountTaxRate = rateModel.DiscountTaxRate,
					ReceiptDiscountReasonId = receiptDiscountReasonId,
					ReceiptTotalLoyaltySchemePointsCollected = q.TotalLoyaltySchemePointsCollected,
					ReceiptTotalLoyaltySchemePointsCost = q.TotalLoyaltySchemePointsCost,
					ReceiptTotalLoyaltySchemeValue = q.TotalLoyaltySchemeValue,
					ReceiptTotalLoyaltySchemeIsTaxApplicable = q.Id > 0 && q.ReceiptDetails.Any(t => t.LoyaltySchemeIsTaxApplicable),
					ReceiptTotalMerchantFee = q.TotalMerchantFee,
					ReceiptTotalAmount = q.GetTotalAmountGross(false),
					ReceiptTotalTax = q.GetTotalTax(false),
					ReceiptTotalTaxRate = rateModel.TaxRate,
					ReceiptCreateOption = createOption,
					LastWriteTime = q.LastWriteTime.ToLocalTime(),
					CreationTime = q.CreationTime.ToLocalTime(),
					LastWriteUser = q.LastWriteUser,
					CreationUser = q.CreationUser
				};

				ViewBag.ReceiptIsNative = isNative;
				return PartialView("~/Views/Accounting/EditorTemplates/ReceiptEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Receipt_Read([DataSourceRequest] DataSourceRequest request, DateTime? dateFrom, DateTime? dateTo, int accountTypeId, int? documentStatusId, int bankAccountId, int bankAccountStatementId,
			int dateDepositedReceiptId, decimal? amountFrom, decimal? amountTo, int creditorId, int supplierId, int formOfPaymentId, int paymentMethodId, int saleTypeId, int categoryId, int sourceId, int agencyId,
			int consultantId, string account, string passenger, string invoiceNo, string voucherNo, string text, int selectionOptionId, bool isExport, bool enableGrouping = false, string sortMember = null, string sortDirection = null) {

			try {
				var lazyContext = LazyContext;

				var receiptStatus = (ReceiptStatus?)documentStatusId;
				var selectionOption = (SelectionOption)selectionOptionId;
				var bankDepositType = dateDepositedReceiptId > 0 ? ReceiptBankDepositType.None : (ReceiptBankDepositType)dateDepositedReceiptId;

				bool isDetailView = receiptStatus == ReceiptStatus.Open || receiptStatus == ReceiptStatus.Deposited || bankDepositType == ReceiptBankDepositType.None || bankDepositType == ReceiptBankDepositType.BankDeposits || bankDepositType == ReceiptBankDepositType.NotDeposited;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isAccounts = HttpContext.IsAccounts();
				bool isSuperUser = HttpContext.IsSuperUser();
				bool isDeposit = bankDepositType == ReceiptBankDepositType.BankDeposits;

				var q1 = lazyContext.ReceiptDetail.Where(t => t.Id > 0 && t.Receipt.IsDeposit == isDeposit);

				if (dateFrom != null)
					q1 = q1.Where(t => t.Receipt.DocumentDate >= dateFrom);

				if (dateTo != null)
					q1 = q1.Where(t => t.Receipt.DocumentDate <= dateTo);

				if (accountTypeId != (int)AccountType.None)
					q1 = q1.Where(t => (t.Receipt.AccountType == AccountType.GeneralLedger ? t.Receipt.TripId > 0 ? AccountType.Client : t.Receipt.DebtorId > 0 ? AccountType.Debtor : t.Receipt.CreditorId > 0 ? AccountType.Creditor : AccountType.GeneralLedger : t.Receipt.AccountType) == (AccountType)accountTypeId);

				if (receiptStatus != null) {
					IQueryable<int> receiptDetailIds = null;

					if (receiptStatus == ReceiptStatus.NoAutoTransfer) {
						receiptDetailIds = Receipt.GetMissingAutoTransferReceipts(lazyContext, agencyId).SelectMany(t => t.ReceiptDetails).Select(t => t.Id).Distinct();
					}
					else if (receiptStatus == ReceiptStatus.NoAutoOtherCommission) {
						receiptDetailIds = Receipt.GetMissingAutoSupplierOtherCommissionReceipts(lazyContext, agencyId).SelectMany(t => t.ReceiptDetails).Select(t => t.Id).Distinct();
					}
					else if (receiptStatus == ReceiptStatus.NoAutoLoyaltyScheme) {
						receiptDetailIds = ReceiptDetail.GetMissingAutoLoyaltySchemeReceiptDetails(lazyContext, agencyId).Select(t => t.Id);
					}
					else if (receiptStatus == ReceiptStatus.Reversal || receiptStatus == ReceiptStatus.Reversed) {
						receiptDetailIds = lazyContext.ReceiptDetail.Where(t => t.ReversalStatus == (receiptStatus == ReceiptStatus.Reversal ? ReversalStatus.Reversal : ReversalStatus.Reversed)).Select(t => t.Id);
					}
					else {
						receiptDetailIds = lazyContext.ReceiptDetail.Where(t => t.DocumentStatus == (DocumentStatus)receiptStatus).Select(t => t.Id);
					}

					q1 = q1.Where(t => receiptDetailIds.Contains(t.Id));
				}

				if (bankAccountId > 0)
					q1 = q1.Where(t => t.Receipt.BankAccountId == bankAccountId);

				if (bankAccountStatementId > 0) {
					var receiptDetailIds = lazyContext.ReceiptDetail.Where(t => t.BankAccountStatementId == bankAccountStatementId).Select(t => t.Id);
					q1 = q1.Where(t => receiptDetailIds.Contains(t.Id));
				}

				if (bankDepositType == ReceiptBankDepositType.None) {
					var receiptDetailIds = lazyContext.ReceiptDetail.Where(t => t.ReceiptId == dateDepositedReceiptId).Select(t => t.Id);
					q1 = q1.Where(t => receiptDetailIds.Contains(t.DepositDetailId));
				}
				else if (bankDepositType == ReceiptBankDepositType.NotDeposited) {
					q1 = q1.Where(t => !t.Receipt.IsDeposit && t.Receipt.ReceiptType != ReceiptType.Transfer && t.BankAccountStatementId <= 0 && t.DepositDetailId <= 0 && t.FormOfPayment.IncludeInDeposit && t.FormOfPayment.DebtorId <= 0 && (t.Amount != 0 || t.Tax != 0));
				}

				if (amountFrom != null) {
					if (isDeposit) {
						q1 = q1.Where(t1 => t1.Receipt.ReceiptDetails.Sum(t2 => t2.DepositDetail.Amount + t2.DepositDetail.Tax) >= amountFrom);
					}
					else {
						q1 = q1.Where(t1 => t1.Receipt.ReceiptDetails.Sum(t2 => t2.Amount + t2.Tax) >= amountFrom);
					}
				}

				if (amountTo != null) {
					if (isDeposit) {
						q1 = q1.Where(t1 => t1.Receipt.ReceiptDetails.Sum(t2 => t2.DepositDetail.Amount + t2.DepositDetail.Tax) <= amountTo);
					}
					else {
						q1 = q1.Where(t1 => t1.Receipt.ReceiptDetails.Sum(t2 => t2.Amount + t2.Tax) <= amountTo);
					}
				}

				if (creditorId > 0)
					q1 = q1.Where(t => t.Receipt.CreditorId == creditorId);

				if (supplierId > 0)
					q1 = q1.Where(t => t.Receipt.SupplierId == supplierId);

				if (formOfPaymentId > 0) {
					var receiptDetailIds = lazyContext.ReceiptDetail.Where(t => t.FormOfPaymentId == formOfPaymentId).Select(t => t.Id);
					q1 = q1.Where(t => receiptDetailIds.Contains(t.Id));
				}

				if (paymentMethodId > 0) {
					var receiptDetailIds = lazyContext.ReceiptDetail.Where(t => t.PaymentMethodId == paymentMethodId).Select(t => t.Id);
					q1 = q1.Where(t => receiptDetailIds.Contains(t.Id));
				}

				if (saleTypeId > 0)
					q1 = q1.Where(t => t.Receipt.SaleTypeId == saleTypeId);

				if (categoryId > 0)
					q1 = q1.Where(t => t.Receipt.CategoryId == categoryId);

				if (sourceId > 0)
					q1 = q1.Where(t => t.Receipt.SourceId == sourceId);

				if (agencyId > 0)
					q1 = q1.Where(t => t.Receipt.AgencyId == agencyId);

				if (consultantId > 0)
					q1 = q1.Where(t => t.Receipt.ConsultantId == consultantId);

				if (!string.IsNullOrEmpty(account)) {
					var predicate = PredicateBuilder.False<ReceiptDetail>();

					foreach (var row in account.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
						predicate = predicate.Or(t => t.Receipt.TripId.ToString().Contains(row) || (t.Receipt.Trip.Title + " " + t.Receipt.Trip.FirstName + " " + t.Receipt.Trip.LastName).Trim().ToLower().Contains(row) || t.Receipt.Debtor.Code.ToLower().Contains(row) || t.Receipt.Debtor.Name.ToLower().Contains(row) || t.Receipt.Supplier.Name.ToLower().Contains(row) || t.Receipt.ChartOfAccount.Code.ToLower().Contains(row) || t.Receipt.ChartOfAccount.Name.ToLower().Contains(row));
					}

					q1 = q1.Where(predicate);
				}

				if (!string.IsNullOrEmpty(passenger)) {
					var predicate = PredicateBuilder.False<ReceiptDetail>();

					foreach (var row in passenger.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
						predicate = predicate.Or(t => (t.Passenger.Title + " " + t.Passenger.FirstName + " " + t.Passenger.LastName).Trim().ToLower().Contains(row));
					}

					var receiptDetailIds = lazyContext.ReceiptDetail.Where(predicate).Select(t => t.Id);
					q1 = q1.Where(t => receiptDetailIds.Contains(t.Id));
				}

				if (!string.IsNullOrEmpty(invoiceNo)) {
					invoiceNo = invoiceNo.Trim().ToLower();
					var receiptDetailIds = lazyContext.ReceiptDetail.Where(t1 => t1.TransactionDetailAllocations.Any(t2 => t2.TransactionDetail.InvoiceDetail.Invoice.DocumentNo.ToLower().Contains(invoiceNo))).Select(t => t.Id);
					q1 = q1.Where(t => receiptDetailIds.Contains(t.Id));
				}

				if (!string.IsNullOrEmpty(voucherNo)) {
					voucherNo = voucherNo.Trim().ToLower();
					var receiptDetailIds = lazyContext.ReceiptDetail.Where(t => t.Voucher.DocumentNo.ToLower().Contains(voucherNo)).Select(t => t.Id);
					q1 = q1.Where(t => receiptDetailIds.Contains(t.Id));
				}

				if (!string.IsNullOrEmpty(text)) {
					text = text.Trim().ToLower();
					q1 = q1.Where(t1 => t1.Receipt.DocumentNo.ToLower().Contains(text) || t1.Receipt.ReceiptDetails.Any(t2 => t2.Comments.ToLower().Contains(text)));
				}

				if (receiptStatus == ReceiptStatus.Open && selectionOption != SelectionOption.All) {
					int[] selectedIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionReceiptDetailIds;
					var arrays = selectedIds.Split(2100).ToArray();

					if (selectionOption == SelectionOption.Matched) {
						var predicate = PredicateBuilder.False<ReceiptDetail>();

						foreach (var array in arrays) {
							predicate = predicate.Or(t => array.Contains(t.Id));
						}

						q1 = q1.Where(predicate);
					}
					else if (selectionOption == SelectionOption.MatchZeros) {
						if (selectedIds.Length == 0) {
							q1 = q1.Where(t => t.Amount + t.Tax - t.MerchantFee - t.MerchantFeeTax == 0);
						}
						else {
							var predicate = PredicateBuilder.False<ReceiptDetail>();

							foreach (var array in arrays) {
								predicate = predicate.Or(t => !array.Contains(t.Id) && t.Amount + t.Tax - t.MerchantFee - t.MerchantFeeTax == 0);
							}

							q1 = q1.Where(predicate);
						}
					}
					else {
						foreach (var array in arrays) {
							q1 = q1.Where(t => !array.Contains(t.Id));
						}
					}
				}

				q1 = q1.OrderByDescending(t => t.Receipt.DocumentDate).ThenByDescending(t => t.Receipt.DocumentNo);

				if (isExport) {
					if (!isAdministrator)
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var export = q1.ApplySorting(null, WebUtils.GetSortDescriptors(sortMember, sortDirection)).ToList().GroupBy(t => new { t.Receipt }).ToList().ConvertAll(row => new ReceiptExportModel {
						AccountName = row.Key.Receipt.AccountName,
						AccountType = row.Key.Receipt.EffectiveAccountType.GetEnumDescription(),
						DocumentType = row.Key.Receipt.ReceiptType.GetEnumDescription(),
						SupplierCommissionType = row.Key.Receipt.SupplierCommissionType.GetEnumDescription(),
						DocumentNo = row.Key.Receipt.DocumentNo,
						DocumentDate = row.Key.Receipt.DocumentDate,
						DocumentStatus = row.Key.Receipt.DocumentStatus.GetEnumDescription(),
						ReversalStatus = row.Key.Receipt.ReversalStatus.GetEnumDescription(),
						BankAccountFrom = (lazyContext.BankAccount.Where(t => t.ChartOfAccountId == row.Key.Receipt.ChartOfAccountId).SingleOrDefault() ?? new BankAccount { Id = -1 }).Name,
						BankAccountTo = row.Key.Receipt.DocumentStatus == DocumentStatus.Open && row.Key.Receipt.Id <= 0 && row.Key.Receipt.BankAccountId == -1 ? string.Empty : row.Key.Receipt.BankAccount.Name,
						Payer = row.Key.Receipt.Payer,
						Supplier = row.Key.Receipt.Supplier.Name,
						SaleType = row.Key.Receipt.SaleType.Name,
						Category = row.Key.Receipt.Category.Name,
						Source = row.Key.Receipt.Source.Name,
						Consultant = row.Key.Receipt.Consultant.Name,
						AmountToBank = row.Key.Receipt.AmountToBank,
						AmountToBankTax = row.Key.Receipt.AmountToBankTax,
						ClientRefund = row.Key.Receipt.ClientRefundGross,
						OriginalSaleTotal = row.Key.Receipt.OriginalSaleTotal,
						OriginalSaleTotalTax = row.Key.Receipt.OriginalSaleTotalTax,
						Commission = row.Key.Receipt.Commission,
						CommissionTax = row.Key.Receipt.CommissionTax,
						NonCommissionable = row.Key.Receipt.NonCommissionable,
						NonCommissionableTax = row.Key.Receipt.NonCommissionableTax,
						Discount = row.Key.Receipt.Discount,
						DiscountTax = row.Key.Receipt.DiscountTax,
						DiscountReason = row.Key.Receipt.DiscountReason.Name,
						CancellationFee = row.Key.Receipt.CancellationFee,
						CancellationFeeTax = row.Key.Receipt.CancellationFeeTax,
						CancellationSaleType = row.Key.Receipt.CancellationSaleType.Name,
						SupplierCancellationFee = row.Key.Receipt.SupplierCancellationFee,
						SupplierCancellationFeeTax = row.Key.Receipt.SupplierCancellationFeeTax,
						TotalAmount = row.Key.Receipt.IsDeposit ? row.Key.Receipt.AmountToBank + row.Key.Receipt.AmountToBankTax : row.Sum(t => t.Amount + t.Tax)
					});

					var xlsx = new ExportToExcel<ReceiptExportModel>(export);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Receipts.xlsx");
				}

				IQueryable<ReceiptViewModel> q2 = null;

				if (receiptStatus == ReceiptStatus.None) {
					q2 = lazyContext.Receipt.Where(t => t.ReceiptDetails.Count == 0).OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).Select(row => new ReceiptViewModel {
						ReceiptViewId = row.Id,
						ReceiptId = row.Id,
						ReceiptDocumentStatus = DocumentStatus.None,
						ReceiptReversalStatus = ReversalStatus.None,
						ReceiptAccountName = row.AccountName,
						ReceiptAccountNameLink = row.AccountNameLink,
						ReceiptEffectiveAccountType = row.EffectiveAccountType,
						ReceiptType = row.ReceiptType,
						ReceiptDocumentNo = row.DocumentNo,
						ReceiptDocumentDate = row.DocumentDate.Date,
						ReceiptFormOfPayment = string.Empty,
						ReceiptTotalLoyaltySchemeValue = 0,
						ReceiptTotalAmount = 0,
						ReceiptTotalMerchantFee = 0,
						ReceiptTotalAmountNet = 0,
						ReceiptIsIssued = row.IsIssued,
						ReceiptCanEdit = row.CanEdit(isAdministrator, isAccounts, isSuperUser),
						ReceiptCanDelete = row.CanDelete(isAdministrator, isAccounts, isSuperUser),
						ReceiptCanUndo = row.CanUndo(false),
						ReceiptCanReverse = row.CanReverse(),
						LastWriteTime = row.LastWriteTime.ToLocalTime(),
						CreationTime = row.CreationTime.ToLocalTime(),
						LastWriteUser = row.LastWriteUser,
						CreationUser = row.CreationUser
					});
				}
				else if (isDetailView) {
					q2 = q1.OrderByDescending(t => t.Receipt.DocumentDate).ThenByDescending(t => t.Receipt.DocumentNo).Select(row => new ReceiptViewModel {
						ReceiptViewId = row.Id,
						ReceiptId = row.ReceiptId,
						ReceiptDocumentStatus = row.DocumentStatus,
						ReceiptReversalStatus = row.ReversalStatus,
						ReceiptAccountName = row.Receipt.AccountName,
						ReceiptAccountNameLink = row.Receipt.AccountNameLink,
						ReceiptEffectiveAccountType = row.Receipt.EffectiveAccountType,
						ReceiptType = row.Receipt.ReceiptType,
						ReceiptDocumentNo = row.Receipt.DocumentNo,
						ReceiptDocumentDate = row.Receipt.DocumentDate.Date,
						ReceiptFormOfPayment = row.FormOfPayment.Name,
						ReceiptTotalLoyaltySchemeValue = row.LoyaltySchemeValue,
						ReceiptTotalAmount = row.Receipt.IsDeposit ? row.AmountToBankGrossProRata : row.Amount + row.Tax,
						ReceiptTotalMerchantFee = row.MerchantFee + row.MerchantFeeTax,
						ReceiptTotalAmountNet = row.AmountNet,
						ReceiptIsIssued = row.Receipt.IsIssued,
						ReceiptCanEdit = row.CanEdit(isAdministrator, isAccounts, isSuperUser),
						ReceiptCanDelete = row.CanDelete(isAdministrator, isAccounts, isSuperUser),
						ReceiptCanUndo = row.CanUndo(false),
						ReceiptCanReverse = row.CanReverse(),
						LastWriteTime = row.LastWriteTime.ToLocalTime(),
						CreationTime = row.CreationTime.ToLocalTime(),
						LastWriteUser = row.LastWriteUser,
						CreationUser = row.CreationUser
					});
				}
				else {
					q2 = lazyContext.Receipt.Where(t1 => t1.ReceiptDetails.Any(t2 => q1.Any(t3 => t3.Id == t2.Id)))
						.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).Select(row => new ReceiptViewModel {
							ReceiptViewId = row.Id,
							ReceiptId = row.Id,
							ReceiptDocumentStatus = row.ReceiptDetails.Min(t => t.DocumentStatus),
							ReceiptReversalStatus = row.ReceiptDetails.Min(t => t.ReversalStatus),
							ReceiptAccountName = row.AccountName,
							ReceiptAccountNameLink = row.AccountNameLink,
							ReceiptEffectiveAccountType = row.EffectiveAccountType,
							ReceiptType = row.ReceiptType,
							ReceiptDocumentNo = row.DocumentNo,
							ReceiptDocumentDate = row.DocumentDate.Date,
							ReceiptTotalLoyaltySchemeValue = row.ReceiptDetails.Sum(t => t.LoyaltySchemeValue),
							ReceiptTotalAmount = row.IsDeposit ? row.AmountToBank + row.AmountToBankTax : row.ReceiptDetails.Sum(t => t.Amount + t.Tax),
							ReceiptTotalMerchantFee = row.ReceiptDetails.Sum(t => t.MerchantFee + t.MerchantFeeTax),
							ReceiptTotalAmountNet = row.ReceiptDetails.Sum(t => t.Amount + t.Tax - t.MerchantFee - t.MerchantFeeTax),
							ReceiptIsIssued = row.IsIssued,
							ReceiptCanEdit = row.CanEdit(isAdministrator, isAccounts, isSuperUser),
							ReceiptCanDelete = row.CanDelete(isAdministrator, isAccounts, isSuperUser),
							ReceiptCanUndo = row.CanUndo(false),
							ReceiptCanReverse = row.CanReverse(),
							LastWriteTime = row.LastWriteTime.ToLocalTime(),
							CreationTime = row.CreationTime.ToLocalTime(),
							LastWriteUser = row.LastWriteUser,
							CreationUser = row.CreationUser
						}).AsQueryable();
				}

				int[] gridIds = q1.Select(t => t.Id).ToArray();

				decimal totalLoyaltySchemeValue = 0;
				decimal totalAmount = 0;
				decimal totalMerchantFee = 0;

				if (receiptStatus == ReceiptStatus.Open) {
					totalLoyaltySchemeValue = q1.Sum(t => (decimal?)t.LoyaltySchemeValue) ?? 0;
					totalAmount = q1.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
					totalMerchantFee = q1.Sum(t => (decimal?)(t.MerchantFee + t.MerchantFeeTax)) ?? 0;
				}

				var aggregateResults = new List<AggregateResult> {
					new AggregateResult(gridIds, new MinFunction { FunctionName = "Min", SourceField = "GridIds", MemberType = typeof(int[]) }),
					new AggregateResult(isDetailView, new MinFunction { FunctionName = "Min", SourceField = "IsDetailView", MemberType = typeof(bool) }),
					new AggregateResult(totalLoyaltySchemeValue, new SumFunction { FunctionName = "Sum", SourceField = "ReceiptTotalLoyaltySchemeValue", MemberType = typeof(decimal) }),
					new AggregateResult(totalAmount, new SumFunction { FunctionName = "Sum", SourceField = "ReceiptTotalAmount", MemberType = typeof(decimal) }),
					new AggregateResult(totalMerchantFee, new SumFunction { FunctionName = "Sum", SourceField = "ReceiptTotalMerchantFee", MemberType = typeof(decimal) }),
					new AggregateResult(totalAmount - totalMerchantFee, new SumFunction { FunctionName = "Sum", SourceField = "ReceiptTotalAmountNet", MemberType = typeof(decimal) })
				};

				int total = q2.Count();
				q2 = q2.ApplySorting(request.Groups, request.Sorts).ApplyPaging(request.Page, request.PageSize);

				var result = await Task.Run(() => new DataSourceResult {
					Data = enableGrouping ? q2.ApplyGrouping(request.Groups, q1) : q2,
					Total = total,
					AggregateResults = aggregateResults
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Receipt_CreateOrUpdate(ReceiptViewModel model, bool isNew) {
			try {
				if (model.ReceiptType == ReceiptType.OtherCommission && model.ReceiptSupplierCommissionType == SupplierCommissionType.Creditor) {
					model.ReceiptSaleTypeId = -1;
					model.ReceiptConsultantId = HttpContext.CurrentConsultantId();
					ModelState.Clear();
					TryValidateModel(model);
				}

				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				var lazyContext = LazyContext;

				if (model.ReceiptType != ReceiptType.Transfer && !lazyContext.Receipt.Any(t => t.Id == model.ReceiptId))
					throw new UnreportedException(AppConstants.RecordCannotBeCreated);

				var receiptCommon = new ReceiptCommon(HttpContext);

				receiptCommon.CreateOrUpdate(model, !isNew, 0, 0, 0, !isNew);
				receiptCommon.CreateOrUpdateCustomerTransaction(lazyContext, lazyContext.Receipt.Find(model.ReceiptId));

				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ReceiptWithDetail_CreateOrUpdate(ReceiptViewModel model, ReceiptDetailViewModel detailModel, bool isNew, List<TransactionDetailAllocationModel> allocationList = null, bool allocationListIsConsolidated = false, TransactionMatchViewStatus transactionMatchViewStatus = TransactionMatchViewStatus.NotSaved) {
			try {
				if (model.ReceiptType == ReceiptType.OtherCommission && model.ReceiptSupplierCommissionType == SupplierCommissionType.Creditor) {
					model.ReceiptSaleTypeId = -1;
					model.ReceiptConsultantId = HttpContext.CurrentConsultantId();
					ModelState.Clear();
					TryValidateModel(model);
				}

				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				var lazyContext = LazyContext;

				new ReceiptDetailCommon(HttpContext).CreateOrUpdate(model, detailModel, isNew, allocationList, allocationListIsConsolidated, transactionMatchViewStatus);
				var receipt = lazyContext.Receipt.Find(model.ReceiptId);
				new ReceiptCommon(HttpContext).CreateOrUpdateCustomerTransaction(lazyContext, receipt);

				model.ReceiptAmountToBank = receipt.AmountToBank + receipt.AmountToBankTax;
				model.ReceiptOriginalSaleTotal = receipt.OriginalSaleTotal + receipt.OriginalSaleTotalTax;
				model.ReceiptTotalAmount = receipt.GetTotalAmountGross(false);
				model.ReceiptTotalTax = receipt.GetTotalTax(false);
				model.ReceiptDocumentTotal = receipt.GetDocumentTotal(lazyContext);

				model.ReceiptTotalLoyaltySchemePointsCollected = receipt.TotalLoyaltySchemePointsCollected;
				model.ReceiptTotalLoyaltySchemePointsCost = receipt.TotalLoyaltySchemePointsCost;
				model.ReceiptTotalLoyaltySchemeValue = receipt.TotalLoyaltySchemeValue;

				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ReceiptWithDetail_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Receipt_Delete([DataSourceRequest] DataSourceRequest request, ReceiptViewModel model) {
			try {
				new ReceiptCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Receipt_UpdateModel(ReceiptViewModel model, string source, decimal unsavedAmount, decimal unsavedTax, int detailId) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.Receipt.Find(model.ReceiptId <= 0 ? -1 : model.ReceiptId);

				int chartOfAccountId = q.ChartOfAccountId;
				int saleTypeId = q.SaleTypeId;

				bool isTaxApplicable = q.IsTaxApplicable;

				q.AccountType = model.ReceiptAccountType;
				q.ReceiptType = model.ReceiptType;
				q.SupplierCommissionType = model.ReceiptSupplierCommissionType;
				q.DocumentNo = model.ReceiptNewDocumentNo;
				q.DocumentDate = model.ReceiptDocumentDate ?? DateTime.Today;
				q.TripId = model.ReceiptTripId ?? -1;
				q.DebtorId = model.ReceiptDebtorId ?? -1;
				q.CreditorId = model.ReceiptCreditorId ?? -1;
				q.ChartOfAccountId = model.ReceiptChartOfAccountId ?? -1;
				q.BankAccountId = model.ReceiptBankAccountToId ?? -1;
				q.SupplierId = model.ReceiptSupplierId ?? -1;
				q.SaleTypeId = model.ReceiptSaleTypeId ?? -1;
				q.AgencyId = model.ReceiptAgencyId;
				q.ConsultantId = model.ReceiptConsultantId ?? -1;
				q.OriginalSaleTotal = model.ReceiptOriginalSaleTotal;
				q.CancellationFee = model.ReceiptCancellationFee;
				q.SupplierCancellationFee = model.ReceiptSupplierCancellationFee;
				q.Commission = model.ReceiptCommission;
				q.CommissionTax = model.ReceiptCommissionTax;
				q.Discount = model.ReceiptDiscount;
				q.DiscountTax = model.ReceiptDiscountTax;

				model.ReceiptIsClientAccountLocked = q.IsClientAccountLocked;

				bool updateRateModel = true;
				bool updateDetailModel = true;
				string message = string.Empty;

				if (model.ReceiptId > 0) {
					switch (source) {
						case "ChartOfAccountId":
						case "SaleTypeId":
							if (!q.ValidateTaxApplicability(isTaxApplicable)) {
								if (source == "ChartOfAccountId") {
									model.ReceiptChartOfAccountId = chartOfAccountId;
								}
								else {
									model.ReceiptSaleTypeId = saleTypeId;
								}

								message = AppConstants.TaxRelatedRecordCannotBeAltered;
							}

							break;
					}

					if (!string.IsNullOrEmpty(message))
						return Json(new { Model = model, Message = message });
				}

				switch (source) {
					case "StandardCommentId":
						if (model.ReceiptStandardCommentId <= 0) {
							model.ReceiptStandardComment = string.Empty;
						}
						else {
							var standardComment = lazyContext.StandardComment.Find(model.ReceiptStandardCommentId);
							model.ReceiptStandardComment = standardComment.Comment;
						}

						break;
					case "ChartOfAccountId":
						if (q.ChartOfAccountId > 0 && Setting.IsControlAccount(HttpContext.CurrentCustomerId(), q.DocumentDate, q.ChartOfAccountId)) {
							if (HttpContext.IsAdministrator()) {
								message = AppConstants.GlControlAccountUpdate;
							}
							else {
								message = AppConstants.GlControlAccountWarning;
							}
						}

						break;
					case "ReceiptType":
					case "SupplierCommissionType":
						if (q.ReceiptType == ReceiptType.Refund) {
							model.ReceiptChartOfAccountId = -1;
							break;
						}

						var glSetting = Setting.GetRow(HttpContext.CurrentCustomerId(), q.DocumentDate);

						if (q.ReceiptType == ReceiptType.VoucherCommission) {
							model.ReceiptChartOfAccountId = glSetting.OtherCommissionAccount.Id;
						}
						else {
							switch (q.SupplierCommissionType) {
								case SupplierCommissionType.None:
									model.ReceiptChartOfAccountId = glSetting.OtherCommissionAccount.Id;
									break;
								case SupplierCommissionType.Creditor:
									model.ReceiptChartOfAccountId = glSetting.CreditorControlAccount.Id;
									break;
							}
						}

						break;
					case "TripId":
						if (q.Trip == null) {
							updateRateModel = false;
							break;
						}

						model.ReceiptCategoryId = q.Trip.CategoryId;
						model.ReceiptConsultantId = q.Trip.ConsultantId <= 0 ? HttpContext.CurrentConsultantId() : q.Trip.ConsultantId;
						model.ReceiptSourceId = q.Trip.SourceId;
						break;
					case "Commission":
					case "CommissionRate":
					case "Discount":
					case "DiscountRate":
						updateDetailModel = false;
						break;
				}

				if (model.ReceiptId <= 0) {
					if (string.IsNullOrEmpty(model.ReceiptNewDocumentNo)) {
						model.ReceiptDocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Receipt");
					}
					else {
						model.ReceiptDocumentNo = model.ReceiptNewDocumentNo;
					}
				}

				model.ReceiptDocumentTotal = q.GetDocumentTotal(lazyContext);
				model.ReceiptIsTaxApplicable = q.IsTaxApplicable;

				model.ReceiptTotalLoyaltySchemePointsCollected = q.TotalLoyaltySchemePointsCollected;
				model.ReceiptTotalLoyaltySchemePointsCost = q.TotalLoyaltySchemePointsCost;
				model.ReceiptTotalLoyaltySchemeValue = q.TotalLoyaltySchemeValue;

				List<string> sources = null;

				if (source == "DeleteDetail") {
					sources = new List<string> { "CommissionRate", "DiscountRate" };
				}
				else {
					sources = new List<string> { source };
				}

				var rateModel = new RateModel {
					Commission = model.ReceiptCommission,
					CommissionRate = model.ReceiptCommissionRate / 100,
					CommissionTax = model.ReceiptCommissionTax,
					Discount = model.ReceiptDiscount,
					DiscountRate = model.ReceiptDiscountRate / 100,
					DiscountTax = model.ReceiptDiscountTax,
					IsTaxIncluded = model.ReceiptIsTaxIncluded
				};

				if (updateRateModel) {
					var rates = new AccountingRates<Receipt>(HttpContext, q, rateModel);
					bool result = rates.SetRates(sources, unsavedAmount, unsavedTax, detailId);

					if (result || source == "DeleteDetail") {
						model.ReceiptCommission = rateModel.CommissionGross;
						model.ReceiptCommissionRate = rateModel.CommissionRate * 100;
						model.ReceiptCommissionTax = rateModel.CommissionTax;
						model.ReceiptCommissionTaxRate = rateModel.CommissionTaxRate * 100;

						model.ReceiptDiscount = rateModel.DiscountGross;
						model.ReceiptDiscountRate = rateModel.DiscountRate * 100;
						model.ReceiptDiscountTax = rateModel.DiscountTax;
						model.ReceiptDiscountTaxRate = rateModel.DiscountTaxRate * 100;

						model.ReceiptTotalTaxRate = rateModel.TaxRate * 100;
					}
					else {
						updateDetailModel = false;
					}
				}
				else {
					updateDetailModel = false;
				}

				if (source == "CancellationFee" || source == "SupplierCancellationFee") {
					q.AmountToBank = q.GetAmountToBank();
					q.AmountToBankTax = q.GetAmountToBankTax();

					model.ReceiptAmountToBank = q.GetAmountToBankGross();
					model.ReceiptTotalAmount = q.GetTotalAmountGross(false);
					model.ReceiptTotalTax = q.GetTotalTax(false);
					model.ReceiptDocumentTotal = q.GetDocumentTotal(lazyContext);
				}

				if (source == "DeleteDetail") {
					model.ReceiptCommission = Math.Round(model.ReceiptTotalAmount * model.ReceiptCommissionRate / 100, 2);
					model.ReceiptDiscount = Math.Round(model.ReceiptTotalAmount * model.ReceiptDiscountRate / 100, 2);
					new ReceiptCommon(HttpContext).CreateOrUpdate(model, true, detailId);
				}

				if (model.ReceiptType == ReceiptType.Refund)
					model.ReceiptOriginalSaleTotal = q.GetOriginalSaleTotalGross();

				return Json(new { Model = model, DetailModel = new { Amount = rateModel.AmountGross, rateModel.Tax, TaxRate = rateModel.TaxRate * 100 }, UpdateDetailModel = updateDetailModel, Message = message });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Receipt_ProcessSelections(int[] receiptDetailIds, int bankAccountId, DateTime dateDeposited, bool isDetailView, bool undo) {
			try {
				bool result = new ReceiptCommon(HttpContext).ProcessSelections(LazyContext, receiptDetailIds, bankAccountId, dateDeposited, isDetailView, undo);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_ProcessSelections", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Receipt_Undo(int id, bool isDetailView) {
			try {
				bool result = new ReceiptCommon(HttpContext).Undo(LazyContext, id, isDetailView, false);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_Undo", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Receipt_Reverse(int receiptId, string type) {
			try {
				bool result = new ReceiptCommon(HttpContext).Reverse(LazyContext, receiptId, type);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_Reverse", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ReceiptDetail_Edit(AccountType accountType, ReceiptType receiptType, int receiptId, int receiptDetailId, bool isTaxIncluded, bool isBankDeposit) {
			try {
				ViewBag.ReceiptDetailAccountType = accountType;
				ViewBag.ReceiptDetailReceiptType = receiptType;
				ViewBag.ReceiptDetailIsBankDeposit = isBankDeposit;

				if (receiptDetailId == -1)
					return PartialView("~/Views/Accounting/EditorTemplates/ReceiptDetailEdit.cshtml");

				var lazyContext = LazyContext;
				ReceiptDetail q = null;

				if (receiptDetailId == 0) {
					q = new ReceiptDetail {
						Id = 0,
						DocumentStatus = DocumentStatus.Open,
						ReversalStatus = ReversalStatus.None,
						TripLineId = -1,
						TripLine = new TripLine { Id = -1 },
						TripLineAirPassengerId = -1,
						TripLineAirPassenger = new TripLineAirPassenger { Id = -1 },
						PassengerId = -1,
						FormOfPaymentId = -1,
						PaymentMethodId = -1,
						LoyaltySchemeId = AppSettings.Setting(HttpContext.CurrentCustomerId()).LoyaltySchemeFormOfPaymentId,
						LoyaltyScheme = new FormOfPayment { Id = AppSettings.Setting(HttpContext.CurrentCustomerId()).LoyaltySchemeFormOfPaymentId, LoyaltySchemeSaleType1Id = -1, LoyaltySchemeSaleType1 = new SaleType { Id = -1 }, LoyaltySchemeSaleType2Id = -1, LoyaltySchemeSaleType2 = new SaleType { Id = -1 } },
						LoyaltySchemeReference = string.Empty,
						VoucherId = -1,
						Class = string.Empty,
						OfferedReasonId = -1,
						VoucherIsPartiallyReceipted = false,
						DepositDetailId = -1,
						Comments = string.Empty,
						Receipt = lazyContext.Receipt.Find(receiptId) ?? new Receipt {
							Id = receiptId,
							DebtorId = -1,
							Debtor = new Debtor { Id = -1 },
							ChartOfAccountId = -1,
							ChartOfAccount = new ChartOfAccount { Id = -1 },
							SaleTypeId = -1,
							SaleType = new SaleType { Id = -1 }
						}
					};

					q.IsTaxApplicable = q.Receipt.IsTaxApplicable;
				}
				else {
					q = lazyContext.ReceiptDetail.Find(receiptDetailId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				var rateModel = new RateModel {
					Commission = q.Receipt.Commission,
					CommissionTax = q.Receipt.CommissionTax,
					Discount = q.Receipt.Discount,
					DiscountTax = q.Receipt.DiscountTax,
					IsTaxIncluded = isTaxIncluded,
					IsFormBinding = true,
					IsTaxApplicableOverride = q.IsTaxApplicable
				};

				var rates = new AccountingRates<ReceiptDetail>(HttpContext, q, rateModel);
				rates.SetRates(new List<string> { "Tax" });

				var model = new ReceiptDetailViewModel {
					ReceiptDetailId = q.Id,
					ReceiptId = q.ReceiptId,
					ReceiptDetailDocumentStatus = q.DocumentStatus,
					ReceiptDetailReversalStatus = q.ReversalStatus,
					ReceiptDetailTripLineType = q.TripLine.TripLineType,
					ReceiptDetailTripLineId = q.TripLineId,
					ReceiptDetailTripLineAirPassengerId = q.TripLineAirPassengerId,
					ReceiptDetailPassengerId = q.PassengerId,
					ReceiptDetailFormOfPaymentId = q.FormOfPaymentId <= 0 ? null : q.FormOfPaymentId,
					ReceiptDetailPaymentMethodId = q.PaymentMethodId,
					ReceiptDetailLoyaltySchemeId = q.LoyaltySchemeId,
					ReceiptDetailLoyaltySchemeReference = q.LoyaltySchemeReference,
					ReceiptDetailLoyaltySchemePointsCollected = q.LoyaltySchemePointsCollected,
					ReceiptDetailLoyaltySchemePointsCost = q.LoyaltySchemePointsCost,
					ReceiptDetailLoyaltySchemeValue = q.LoyaltySchemeValue,
					ReceiptDetailLoyaltySchemeIsPointsOnly = q.Id > 0 && q.LoyaltySchemeId > 0 && q.Amount == 0,
					ReceiptDetailLoyaltySchemeIsTaxApplicable = q.LoyaltySchemeIsTaxApplicable,
					ReceiptDetailAmount = isTaxIncluded ? q.Amount + q.Tax : q.Amount,
					ReceiptDetailTax = q.Tax,
					ReceiptDetailTaxRate = rateModel.TaxRate,
					ReceiptDetailIsTaxApplicable = q.IsTaxApplicable,
					ReceiptDetailIsCreditCardDebtor = q.Receipt.Debtor.IsCreditCardDebtor,
					ReceiptDetailVoucherId = q.VoucherId,
					ReceiptDetailClass = q.Class,
					ReceiptDetailDaysAway = q.DaysAway,
					ReceiptDetailTicketedFare = q.TicketedFare,
					ReceiptDetailOfferedFare = q.OfferedFare,
					ReceiptDetailOfferedReasonId = q.OfferedReasonId,
					ReceiptDetailVoucherIsPartiallyReceipted = q.VoucherIsPartiallyReceipted,
					ReceiptDetailComments = q.Comments
				};

				return PartialView("~/Views/Accounting/EditorTemplates/ReceiptDetailGridEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ReceiptDetail_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> ReceiptDetail_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
			try {
				var lazyContext = LazyContext;
				const bool isTaxIncluded = true;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isAccounts = HttpContext.IsAccounts();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q = lazyContext.ReceiptDetail.Where(t => t.ReceiptId == parentId);
				var receiptDetail = q.FirstOrDefault();

				if (receiptDetail?.Receipt.IsDeposit ?? false)
					q = lazyContext.ReceiptDetail.Where(t => t.DepositDetailId == receiptDetail.Id);

				var result = await q.AsEnumerable().Select(row => new ReceiptDetailViewModel {
					ReceiptDetailId = row.Id,
					ReceiptId = row.ReceiptId,
					ReceiptDetailDocumentNo = row.Receipt.DocumentNo,
					ReceiptDetailAccountNameLink = row.Receipt.AccountNameLink,
					ReceiptDetailTripLineType = row.TripLine.TripLineType,
					ReceiptDetailDocumentStatus = row.DocumentStatus,
					ReceiptDetailReversalStatus = row.ReversalStatus,
					ReceiptDetailVoucherNo = row.Voucher.DocumentNo,
					ReceiptDetailPassenger = row.PassengerId <= 0 ? row.TripLineAirPassenger.PassengerId <= 0 ? string.Empty : row.TripLineAirPassenger.Passenger.FullName : row.Passenger.FullName,
					ReceiptDetailFormOfPayment = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name,
					ReceiptDetailPaymentMethod = row.PaymentMethodId <= 0 ? string.Empty : row.PaymentMethod.AccountName,
					ReceiptDetailDepositDate = row.GetDateDeposited(lazyContext, row.DepositDetailId),
					ReceiptDetailBankAccountStatementName = row.Receipt.IsDeposit && row.DepositDetail.BankAccountStatementId > 0 ? row.DepositDetail.BankAccountStatement.Name : row.BankAccountStatementId > 0 ? row.BankAccountStatement.Name : row.FormOfPayment.DebtorId > 0 ? (row.TransactionDetails.SelectMany(t1 => t1.TransactionDetailAllocations).FirstOrDefault(t1 => row.TransactionDetails.Any(t2 => t2.Id == t1.TransactionDetailId) && t1.ReceiptDetailId != row.Id)?.ReceiptDetail.Receipt.DocumentNo ?? string.Empty) : string.Empty,
					ReceiptDetailAmount = isTaxIncluded ? row.Amount + row.Tax : row.Amount,
					ReceiptDetailTax = row.Tax,
					ReceiptDetailCanEdit = row.CanEdit(isAdministrator, isAccounts, isSuperUser),
					ReceiptDetailCanDelete = row.CanDelete(isAdministrator, isAccounts, isSuperUser),
					ReceiptDetailCanUndo = row.CanUndo(false),
					ReceiptDetailCanReverse = row.CanReverse(),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ReceiptDetail_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ReceiptDetail_Delete([DataSourceRequest] DataSourceRequest request, ReceiptDetailViewModel model) {
			try {
				new ReceiptDetailCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ReceiptDetail_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ReceiptDetail_UpdateModel(ReceiptViewModel model, ReceiptDetailViewModel detailModel, string source) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.ReceiptDetail.Find(detailModel.ReceiptDetailId <= 0 ? -1 : detailModel.ReceiptDetailId);

				q.ReceiptId = model.ReceiptId;
				q.TripLineId = detailModel.ReceiptDetailTripLineId ?? -1;
				q.FormOfPaymentId = detailModel.ReceiptDetailFormOfPaymentId ?? -1;
				q.LoyaltySchemeId = detailModel.ReceiptDetailLoyaltySchemeId ?? -1;
				q.Amount = detailModel.ReceiptDetailAmount;
				q.Tax = detailModel.ReceiptDetailTax;
				q.IsTaxApplicable = detailModel.ReceiptDetailIsTaxApplicable;

				q.Receipt ??= lazyContext.Receipt.Find(model.ReceiptId <= 0 ? -1 : model.ReceiptId);

				q.Receipt.AccountType = model.ReceiptAccountType;
				q.Receipt.ReceiptType = model.ReceiptType;
				q.Receipt.SupplierCommissionType = model.ReceiptSupplierCommissionType;
				q.Receipt.DocumentNo = model.ReceiptNewDocumentNo;
				q.Receipt.DocumentDate = model.ReceiptDocumentDate ?? DateTime.Today;
				q.Receipt.TripId = model.ReceiptTripId ?? -1;
				q.Receipt.DebtorId = model.ReceiptDebtorId ?? -1;
				q.Receipt.CreditorId = model.ReceiptCreditorId ?? -1;
				q.Receipt.ChartOfAccountId = model.ReceiptChartOfAccountId ?? -1;
				q.Receipt.BankAccountId = model.ReceiptBankAccountToId ?? -1;
				q.Receipt.SupplierId = model.ReceiptSupplierId ?? -1;
				q.Receipt.SaleTypeId = model.ReceiptSaleTypeId ?? -1;
				q.Receipt.AgencyId = model.ReceiptAgencyId;
				q.Receipt.ConsultantId = model.ReceiptConsultantId ?? -1;
				q.Receipt.OriginalSaleTotal = model.ReceiptOriginalSaleTotal;
				q.Receipt.CancellationFee = model.ReceiptCancellationFee;
				q.Receipt.SupplierCancellationFee = model.ReceiptSupplierCancellationFee;
				q.Receipt.Commission = model.ReceiptCommission;
				q.Receipt.CommissionTax = model.ReceiptCommissionTax;
				q.Receipt.Discount = model.ReceiptDiscount;
				q.Receipt.DiscountTax = model.ReceiptDiscountTax;

				model.ReceiptIsClientAccountLocked = q.Receipt.IsClientAccountLocked;
				var sources = new List<string> { source };

				bool updateRateModel = true;

				switch (source) {
					case "TripLineId":
						if (q.TripLine == null || q.TripLineId <= 0) {
							updateRateModel = false;
							break;
						}

						detailModel.ReceiptDetailTripLineType = q.TripLine.TripLineType;
						detailModel.ReceiptDetailAmount = q.TripLine.AmountReceivable;
						sources.Add("Amount");
						break;
				}

				if ((model.ReceiptAccountType == AccountType.Client && model.ReceiptType == ReceiptType.Receipt) || (model.ReceiptAccountType == AccountType.Debtor && model.ReceiptType == ReceiptType.Debtor)) {
					detailModel.ReceiptDetailLoyaltySchemeIsPointsOnly = detailModel.ReceiptDetailLoyaltySchemeId > 0 && detailModel.ReceiptDetailAmount == 0;

					if (source == "Amount" || source == "LoyaltySchemeId" || source == "PointsCollected" || source == "PointsCost" || source == "LoyaltySchemeValue") {
						decimal pointsCollected = detailModel.ReceiptDetailLoyaltySchemePointsCollected;
						decimal pointsCost = detailModel.ReceiptDetailLoyaltySchemePointsCost;
						decimal loyaltySchemeValue = detailModel.ReceiptDetailLoyaltySchemeValue;
						bool isTaxApplicable = false;

						q.GetLoyaltySchemeCalculations(source, detailModel.ReceiptDetailAmount, ref pointsCollected, ref pointsCost, ref loyaltySchemeValue, ref isTaxApplicable);

						detailModel.ReceiptDetailLoyaltySchemePointsCollected = pointsCollected;
						detailModel.ReceiptDetailLoyaltySchemePointsCost = pointsCost;
						detailModel.ReceiptDetailLoyaltySchemeValue = loyaltySchemeValue;
						detailModel.ReceiptDetailLoyaltySchemeIsTaxApplicable = isTaxApplicable;
					}
				}

				if (model.ReceiptAccountType == AccountType.GeneralLedger && model.ReceiptType == ReceiptType.Admin) {
					detailModel.ReceiptDetailIsTaxApplicable = q.IsTaxApplicable;
				}
				else {
					detailModel.ReceiptDetailIsTaxApplicable = q.Receipt.IsTaxApplicable;
				}

				var rateModel = new RateModel {
					Commission = model.ReceiptCommission,
					CommissionRate = model.ReceiptCommissionRate / 100,
					CommissionTax = model.ReceiptCommissionTax,
					Discount = model.ReceiptDiscount,
					DiscountRate = model.ReceiptDiscountRate / 100,
					DiscountTax = model.ReceiptDiscountTax,
					IsTaxIncluded = model.ReceiptIsTaxIncluded,
					IsTaxApplicableOverride = detailModel.ReceiptDetailIsTaxApplicable
				};

				bool result = false;

				if (updateRateModel) {
					var rates = new AccountingRates<ReceiptDetail>(HttpContext, q, rateModel);
					result = rates.SetRates(sources, detailModel.ReceiptDetailAmount, detailModel.ReceiptDetailTax, detailModel.ReceiptDetailId);

					if (result) {
						var receipt = q.Receipt;

						if (model.ReceiptType == ReceiptType.Refund && (source == "Amount" || source == "Tax" || source == "TripLineId")) {
							model.ReceiptCommission = rateModel.CommissionGross;
							model.ReceiptCommissionRate = rateModel.CommissionRate * 100;
							model.ReceiptCommissionTax = rateModel.CommissionTax;
							model.ReceiptDiscount = rateModel.DiscountGross;
							model.ReceiptDiscountRate = rateModel.DiscountRate * 100;
							model.ReceiptDiscountTax = rateModel.DiscountTax;

							receipt.Commission = rateModel.Commission;
							receipt.CommissionTax = rateModel.CommissionTax;
							receipt.Discount = rateModel.Discount;
							receipt.DiscountTax = rateModel.DiscountRate;
						}

						detailModel.ReceiptDetailAmount = rateModel.AmountGross;
						detailModel.ReceiptDetailTax = rateModel.Tax;
						detailModel.ReceiptDetailTaxRate = rateModel.TaxRate * 100;
					}
				}

				return Json(new { Model = model, DetailModel = detailModel, UpdateRateModel = result });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ReceiptDetail_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ReceiptVoucherCommissionAdd_Edit() {
			try {
				ViewBag.ChartOfAccountId = Setting.GetRow(HttpContext.CurrentCustomerId(), DateTime.Today).OtherCommissionAccount.Id;
				return PartialView("~/Views/Accounting/EditorTemplates/ReceiptVoucherCommissionAdd.cshtml");
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ReceiptVoucherCommissionAdd_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> ReceiptVoucherCommission_Read([DataSourceRequest] DataSourceRequest request, int creditorId, int[] supplierIds, DateTime? departureDateFrom, DateTime? departureDateTo, string passenger, int? voucherId = null) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.Voucher.Where(t1 => (t1.VoucherType == VoucherType.PaidDirect || t1.VoucherType == VoucherType.BillbackClientDirect) && t1.ReversalStatus == ReversalStatus.None && (!t1.ReceiptDetails.Any(t2 => t2.VoucherId == t1.Id) || t1.ReceiptDetails.Any(t2 => t2.VoucherId == t1.Id && t2.VoucherIsPartiallyReceipted)));

				if (voucherId != null) {
					q = q.Where(t => t.Id == voucherId);
				}
				else {
					if (creditorId == -1) {
						if (supplierIds == null || supplierIds.Length == 0)
							q = q.Where(t => t.CreditorId == 0);
					}
					else {
						q = q.Where(t => t.CreditorId == creditorId);
					}

					if (supplierIds != null && supplierIds.Length > 0)
						q = q.Where(t => supplierIds.Contains(t.SupplierId));

					if (departureDateFrom != null)
						q = q.Where(t => t.Trip.DepartureDate >= departureDateFrom);

					if (departureDateTo != null)
						q = q.Where(t => t.Trip.DepartureDate <= departureDateTo);

					if (!string.IsNullOrEmpty(passenger)) {
						var predicate = PredicateBuilder.False<VoucherDetail>();

						foreach (var row in passenger.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
							predicate = predicate.Or(t => (t.Passenger.Title + " " + t.Passenger.FirstName + " " + t.Passenger.LastName).Trim().ToLower().Contains(row));
						}

						var voucherDetailIds = lazyContext.VoucherDetail.Where(predicate).Select(t => t.Id);
						q = q.Where(t => voucherDetailIds.Contains(t.Id));
					}
				}

				var result = await q.Select(row => new ReceiptVoucherCommissionViewModel {
					VoucherId = row.Id,
					TripId = row.TripId,
					TripNo = row.Trip.TripNo,
					CreditorId = row.CreditorId,
					SupplierId = row.SupplierId,
					DocumentNo = row.DocumentNo,
					DocumentDate = row.DocumentDate,
					DepartureDate = row.Trip.DepartureDate,
					Supplier = row.Supplier.Name,
					SourceId = row.Trip.SourceId,
					CategoryId = row.Trip.CategoryId,
					SaleTypeId = row.SaleTypeId,
					ConsultantId = row.Trip.ConsultantId,
                    Amount = row.Commission + row.CommissionTax + (row.TripLine.FormOfPayment.FormOfPaymentType == FormOfPaymentType.CreditCard || row.TripLine.FormOfPayment.FormOfPaymentType == FormOfPaymentType.TravelCard ? (row.TripLine.IsCreditCardDiscountApplicable ? -row.TripLine.Discount : 0) + (row.TripLine.IncludeMarkupInCreditCardPayment ? row.TripLine.Markup : 0) : 0) - (row.ReceiptDetails.Where(t => t.VoucherIsPartiallyReceipted).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0),
                    TicketedFare = row.TripLine.Gross,
					DaysAway = row.Duration,
					OfferedReasonId = -1,
					IsFullyPaid = true
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ReceiptVoucherCommission_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ReceiptVoucherCommission_Create(string receiptVoucherCommissionModels, string receiptVoucherCommissionDetailModels, DateTime documentDate, int bankAccountId, int chartOfAccountId, int formOfPaymentId, int paymentMethodId) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				new ReceiptCommon(HttpContext).CreateReceiptVoucherCommission(LazyContext, receiptVoucherCommissionModels, receiptVoucherCommissionDetailModels, documentDate, bankAccountId, chartOfAccountId, formOfPaymentId, paymentMethodId);
				return Json(true);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ReceiptVoucherCommission_Create", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ReceiptAdd_Edit(int tripId, int[] tripLineIds = null, bool validateTripLineCount = true, bool ignoreInvoicedAmount = false) {
			try {
				var lazyContext = LazyContext;
				var trip = lazyContext.Trip.Find(tripId);

				if (!validateTripLineCount && (tripLineIds == null || tripLineIds.Length == 0))
					tripLineIds = lazyContext.TripLine.Where(t => t.TripId == tripId).Select(t => t.Id).ToArray();

				var tripLines = lazyContext.TripLine.Where(t => tripLineIds.Contains(t.Id)).ToList();

				if (validateTripLineCount && tripLines.Count == 0)
					throw new UnreportedException("No trip lines have been selected.");

				ViewBag.ReceiptAddTripId = tripId;
				ViewBag.ReceiptAddDebtorId = trip.DebtorId;
				ViewBag.ReceiptAddTripLineIds = string.Join(",", tripLineIds);
				ViewBag.ReceiptAddIgnoreInvoicedAmount = ignoreInvoicedAmount;

				decimal amountReceivable = 0;

				if (ignoreInvoicedAmount) {
					amountReceivable = tripLines.Sum(t => (decimal?)t.GetAmountReceivable()) ?? 0;
				}
				else {
					amountReceivable = tripLines.Sum(t => (decimal?)(t.GetAmountReceivableDue(lazyContext) - t.GetAmountInvoiced(lazyContext))) ?? 0;

					if (amountReceivable == 0) {
						if (validateTripLineCount) {
							throw new UnreportedException("Selected trip lines have already been receipted or are zero value.");
						}
						else {
							return new EmptyResult();
						}
					}
				}

				return PartialView("~/Views/Accounting/EditorTemplates/ReceiptAdd.cshtml");
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ReceiptAdd_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> ReceiptAdd_Read([DataSourceRequest] DataSourceRequest request, int tripId, string tripLineIds, bool ignoreInvoicedAmount = false) {
			try {
				var lazyContext = LazyContext;

				var tripLineIdList = tripLineIds.Split(',').Select(int.Parse).ToArray();
				var receiptAdd = new List<ReceiptAddViewModel>();

				decimal amountDue = 0;
				int i = 0;

				foreach (var tripLine in lazyContext.TripLine.Where(t => t.TripId == tripId && tripLineIdList.Contains(t.Id)).AsEnumerable().Where(t => t.IsBooking).ToList()) {
					switch (tripLine.TripLineType) {
						case TripLineType.Air:
							foreach (var row in tripLine.TripLineAir.TripLineAirPassengers) {
								i++;

								if (ignoreInvoicedAmount) {
									amountDue = row.GetAmountReceivable(HttpContext.CurrentCustomerId());
								}
								else {
									amountDue = row.GetAmountReceivableDue(lazyContext, HttpContext.CurrentCustomerId()) - row.GetAmountInvoiced(lazyContext);
								}

								if (amountDue == 0)
									continue;

								receiptAdd.Add(new ReceiptAddViewModel {
									ReceiptAddId = i,
									ReceiptAddTripLineType = TripLineType.Air,
									ReceiptAddDocumentDate = HttpContext.Today().ToUniversalTime(),
									ReceiptAddDescription = string.Concat(row.Routing, row.TicketNo.Length == 0 ? string.Empty : string.Concat(" [", row.TicketNo, "]")),
									ReceiptAddTripLineId = tripLine.Id,
									ReceiptAddTripLineAirPassengerId = row.Id,
									ReceiptAddPassengerId = row.Passenger.Id,
									ReceiptAddFormOfPaymentId = null,
									ReceiptAddPaymentMethodId = -1,
									ReceiptAddAmount = amountDue,
									ReceiptAddAmountOriginal = amountDue,
									ReceiptAddIsTaxApplicable = row.SaleType.IsTaxApplicable,
									ReceiptAddComments = string.Empty
								});
							}

							break;
						default:
							i++;

							if (ignoreInvoicedAmount) {
								amountDue = tripLine.GetAmountReceivable();
							}
							else {
								amountDue = tripLine.GetAmountReceivableDue(lazyContext) - tripLine.GetAmountInvoiced(lazyContext);
							}

							if (amountDue == 0)
								continue;

							int passengerId = (tripLine.Trip.TripPassengers.FirstOrDefault(t => t.PassengerType == PassengerType.Adult && t.FirstName.Equals(tripLine.Trip.FirstName, StringComparison.OrdinalIgnoreCase) && t.LastName.Equals(tripLine.Trip.LastName, StringComparison.OrdinalIgnoreCase)) ?? tripLine.Trip.TripPassengers.FirstOrDefault(t => t.PassengerType == PassengerType.Adult) ?? new Passenger { Id = -1 }).Id;

							receiptAdd.Add(new ReceiptAddViewModel {
								ReceiptAddId = i,
								ReceiptAddTripLineType = tripLine.TripLineType,
								ReceiptAddDocumentDate = HttpContext.Today().ToUniversalTime(),
								ReceiptAddDescription = tripLine.Description,
								ReceiptAddTripLineId = tripLine.Id,
								ReceiptAddTripLineAirPassengerId = -1,
								ReceiptAddPassengerId = passengerId,
								ReceiptAddFormOfPaymentId = null,
								ReceiptAddPaymentMethodId = -1,
								ReceiptAddAmount = amountDue,
								ReceiptAddAmountOriginal = amountDue,
								ReceiptAddIsTaxApplicable = tripLine.SaleType.IsTaxApplicable
							});

							break;
					}
				}

				return Json(await receiptAdd.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ReceiptAdd_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> ReceiptAdd_Create(int tripId, int bankAccountId, int standardCommentId, string receiptAddModels) {
			try {
				var receiptModel = new ReceiptCommon(HttpContext).Create(LazyContext, tripId, bankAccountId, standardCommentId, receiptAddModels);
				return Json(new { receiptModel.ReceiptId, AccountTypeId = (int)receiptModel.ReceiptAccountType, ReceiptTypeId = (int)receiptModel.ReceiptType });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "ReceiptAdd_Create", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Receipt_Report(int receiptId, string documentNo) {
			try {
				var lazyContext = LazyContext;
				TypeReportSource reportSource;

                if (HttpContext.CustomerSettings().IsManagementCustomer) {
					var receipt = lazyContext.Receipt.Find(receiptId);
					reportSource = AccountingDataSources.GetCustomerReceiptReportSource(HttpContext.CurrentCustomerId(), User.Identity.Name, receipt);
				}
				else {
					reportSource = AccountingDataSources.GetReceiptReportSource(lazyContext, HttpContext.CurrentCustomerId(), User.Identity.Name, receiptId, documentNo, HttpContext.Now(), HttpContext.UserFullName());
				}

				return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_Report", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Receipt_IssueDocument(ReceiptViewModel model, string documentNo, int? tripId = null) {
			try {
				new ReceiptCommon(HttpContext).IssueDocument(LazyContext, model, documentNo, tripId);
				return Json(true);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_IssueDocument", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Receipt_EmailDocument(AccountType accountType, int tripId, string documentNo, string from, string to, string cc, string bcc, string subject, string body, IEnumerable<IFormFile> attachments) {
			try {
				if (accountType == AccountType.Client && tripId <= 0) {
					throw new UnreportedException("Receipt cannot be issued because it is not assigned to a Trip.");
				}
				else if (accountType == AccountType.GeneralLedger) {
					throw new UnreportedException("Admin and Transfer receipts cannot be issued.");
				}

				var q = Context.IssuedDocument.SingleOrDefault(t => t.TripId == tripId && t.IssuedDocumentType == IssuedDocumentType.Receipt && t.Receipt.DocumentNo == documentNo);

				if (q == null)
					throw new UnreportedException(AppConstants.RecordNotFound);

				var mailAttachments = new List<MailAttachment> {
					new MailAttachment(q.Document, q.FileName, q.FileContentType)
				};

				if (attachments != null) {
					foreach (var attachment in attachments) {
						mailAttachments.Add(new MailAttachment(attachment.OpenReadStream().StreamToBytes(), attachment.FileName, attachment.ContentType));
					}
				}

				await Mail.Instance.SendMailAsync(to, cc, bcc, subject, body, mailAttachments.ToArray(), from);
				return Json(true);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_EmailDocument", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Receipt_ExportPdf(int receiptId, bool suppressReadOnlyException = false) {
			try {
				var lazyContext = LazyContext;
				var receipt = lazyContext.Receipt.Find(receiptId);

				if (receipt.CanEdit(HttpContext.IsAdministrator(), HttpContext.IsAccounts(), false))
					return RedirectToAction("Receipts", "Accounting", suppressReadOnlyException ? null : new { message = "Only read-only receipts can be exported.", messageType = MessageType.Warning });

				string documentNo = receipt.DocumentNo;
				string fileName = string.Format("{0}.pdf", IssuedDocument.GetReceiptName(receipt.ReceiptType, documentNo));

				TypeReportSource reportSource;

				if (HttpContext.CustomerSettings().IsManagementCustomer) {
					reportSource = AccountingDataSources.GetCustomerReceiptReportSource(HttpContext.CurrentCustomerId(), User.Identity.Name, receipt);
				}
				else {
					reportSource = AccountingDataSources.GetReceiptReportSource(lazyContext, HttpContext.CurrentCustomerId(), User.Identity.Name, receiptId, documentNo, HttpContext.Now(), HttpContext.UserFullName());
				}

				var result = Utils.ExportToPdf(reportSource);
				return File(result.DocumentBytes, result.MimeType, fileName);
			}
			catch (Exception ex) {
				await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_ExportPdf", ex);
				return Redirect("/Shared/Error");
			}
		}

		public async Task<IActionResult> Receipt_ExportWord(int receiptId) {
			try {
				var lazyContext = LazyContext;
				var receipt = lazyContext.Receipt.Find(receiptId);

				if (receipt.CanEdit(HttpContext.IsAdministrator(), HttpContext.IsAccounts(), false))
					return RedirectToAction("Receipts", "Accounting", new { message = "Only read-only receipts can be exported.", messageType = MessageType.Warning });

				string documentNo = receipt.DocumentNo;
				string fileName = string.Format("{0}.docx", IssuedDocument.GetReceiptName(receipt.ReceiptType, documentNo));

				TypeReportSource reportSource;

				if (HttpContext.CustomerSettings().IsManagementCustomer) {
					reportSource = AccountingDataSources.GetCustomerReceiptReportSource(HttpContext.CurrentCustomerId(), User.Identity.Name, receipt);
				}
				else {
					reportSource = AccountingDataSources.GetReceiptReportSource(lazyContext, HttpContext.CurrentCustomerId(), User.Identity.Name, receiptId, documentNo, HttpContext.Now(), HttpContext.UserFullName());
				}

				var result = Utils.ExportToWord(reportSource);
				return File(result.DocumentBytes, result.MimeType, fileName);
			}
			catch (Exception ex) {
				await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_ExportWord", ex);
				return Redirect("/Shared/Error");
			}
		}

		public async Task<IActionResult> Receipt_BankDepositReport(string outputType, DateTime? depositDate, int bankAccountId, int receiptId, string receiptDetailIds = null) {
			try {
				var reportSource = AccountingDataSources.GetReceiptBankDepositReportSource(Context, HttpContext.CurrentCustomerId(), depositDate, bankAccountId, receiptId, receiptDetailIds, HttpContext.Now(), HttpContext.UserFullName());

				RenderingResult result = null;
				string fileName = null;

				switch (outputType) {
					default:
						return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
					case "ExportPdf":
						result = Utils.ExportToPdf(reportSource);
						fileName = "Bank Deposit.pdf";
						break;
					case "ExportWord":
						result = Utils.ExportToWord(reportSource);
						fileName = "Bank Deposit.docx";
						break;
					case "ExportExcel":
						result = Utils.ExportToExcel(reportSource);
						fileName = "Bank Deposit.xlsx";
						break;
				}

				return File(result.DocumentBytes, result.MimeType, fileName);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Receipt_BankDepositReport", ex);

				if (outputType == "Report") {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
				else {
					return Redirect("/Shared/Error");
				}
			}
		}
		#endregion

		#region BSP Returns
		public IActionResult BspReturns() {
			ViewBag.BspCreditorId = AppSettings.Setting(HttpContext.CurrentCustomerId()).BspCreditorId;
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Bsp_Edit(int bspId, int tripId, bool isNative) {
			try {
				var lazyContext = LazyContext;
				const bool isTaxIncluded = true;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				var trip = lazyContext.Trip.Find(tripId);
				bool isBooking = trip?.IsBooking ?? false;

				Bsp q = null;

				if (bspId <= 0) {
					var creditor = Creditor.GetBspAgent(lazyContext, HttpContext.CurrentCustomerId(), TripLineType.Air);
					var supplier = Supplier.GetBspAgent(lazyContext, HttpContext.CurrentCustomerId(), TripLineType.Air);

					q = new Bsp {
						Id = 0,
						BspType = BspType.Bsp,
						DocumentDate = DateTime.Today,
						DepartureDate = DateTime.MinValue,
						CreditorId = creditor.Id,
						SupplierId = supplier.Id,
						TripId = isBooking ? tripId : 0,
						Trip = isBooking ? trip : new Trip(),
						TripLineId = -1,
						TripLine = new TripLine { Id = -1, TripId = tripId },
						AirlineId = 0,
						OfferedReasonId = -1,
						SaleTypeId = 0,
						SourceId = 0,
						CategoryId = 0,
						DestinationId = 0,
						AgencyId = HttpContext.CurrentDefaultAgencyId(),
						ConsultantId = HttpContext.CurrentConsultantId(),
						AgentId = -1,
						DiscountReasonId = -1,
						MarkupStrategyId = -1,
						PaymentId = -1,
						IncludeMarkupInCreditCardPayment = creditor.IncludeMarkupInCreditCardPayment
					};
				}
				else {
					q = lazyContext.Bsp.Find(bspId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				int? bspTripId = -1;
				int? bspAirlineId = 0;
				int? bspConsultantId = 0;

				if (q.Id > 0) {
					bspTripId = q.TripId;
					bspAirlineId = q.AirlineId;
					bspConsultantId = q.ConsultantId <= 0 ? null : q.ConsultantId;
				}
				else {
					if (isNative) {
						bspTripId = null;
						bspAirlineId = null;
					}
					else {
						bspTripId = q.TripId;
						bspAirlineId = q.AirlineId;
					}

					bspConsultantId = HttpContext.CurrentConsultantId();
				}

				var rateModel = new RateModel {
					Commission = q.Commission,
					CommissionTax = q.CommissionTax,
					Discount = q.Discount,
					DiscountTax = q.DiscountTax,
					Markup = q.Markup,
					MarkupTax = q.MarkupTax,
					IsTaxIncluded = isTaxIncluded,
					IsFormBinding = true
				};

				var rates = new AccountingRates<Bsp>(HttpContext, q, rateModel);
				rates.SetRates(new List<string> { "Commission", "Discount", "Markup" });

				var model = new BspViewModel {
					BspId = q.Id,
					BspTripLineType = q.TripLine.TripLineType,
					BspDocumentStatus = q.DocumentStatus,
					BspReversalStatus = q.ReversalStatus,
					BspType = q.BspType,
					BspDocumentNo = q.DocumentNo,
					BspDocumentDate = q.DocumentDate,
					BspCreditorId = q.CreditorId,
					BspSupplierId = q.SupplierId,
					BspTripId = bspTripId,
					BspTripLineId = q.TripLineId,
					BspAirlineId = bspAirlineId,
					BspDepartureDateStatus = q.DepartureDate == DateTime.MinValue ? DepartureDateStatus.Open : q.DepartureDate == lazyContext.VoidDate ? DepartureDateStatus.ARNK : DepartureDateStatus.Normal,
					BspDepartureDate = q.DepartureDate <= lazyContext.VoidDate ? (DateTime?)null : q.DepartureDate,
					BspOfferedFare = q.OfferedFare,
					BspOfferedReasonId = q.OfferedReasonId,
					BspSaleTypeId = q.SaleTypeId <= 0 && q.BspType != BspType.Conjunction && q.BspType != BspType.Free && q.BspType != BspType.Void ? null : q.SaleTypeId,
					BspCategoryId = q.CategoryId,
					BspDestinationId = q.DestinationId,
					BspAgencyId = q.AgencyId,
					BspConsultantId = bspConsultantId,
					BspAgentId = q.AgentId,
					BspSourceId = q.SourceId,
					BspPaymentLink = q.Id > 0 && (q.BspType == BspType.Conjunction || q.BspType == BspType.Free || q.BspType == BspType.Void) ? q.PaymentId <= 0 ? AppConstants.HtmlSpace : q.PaymentLink : AppConstants.HtmlSpace,
					BspPaymentDate = q.Id > 0 && (q.BspType == BspType.Conjunction || q.BspType == BspType.Free || q.BspType == BspType.Void) ? q.PaymentId <= 0 ? (DateTime?)null : q.Payment.DocumentDate : null,
					BspSupplierCancellationFee = q.SupplierCancellationFee + q.SupplierCancellationFeeTax,
					BspTotalNonCommissionable = q.TotalNonCommissionable,
                    BspAmountPayable = (q.BspType == BspType.Refund ? -1 : 1) * q.AmountPayable,
                    BspIsCommissionPermitted = q.IsCommissionPermitted,
					BspIsDiscountPermitted = q.IsDiscountPermitted,
					BspIsMarkupPermitted = q.IsMarkupPermitted,
					BspIsCancellationPermitted = q.IsCancellationPermitted,
					BspIsTaxIncluded = isTaxIncluded,
					BspIsTaxApplicable = q.IsTaxApplicable,
					BspIsAutoInvoiced = q.IsAutoInvoiced,
					BspIsClientAccountLocked = q.IsClientAccountLocked,
					BspCanEdit = q.CanEdit(isSuperUser),
					BspCanDelete = q.CanDelete(isSuperUser),
					BspCanUndo = q.CanUndo(),
					BspCanReverse = q.CanReverse(),
					BspCommission = q.Commission + (isTaxIncluded ? q.CommissionTax : 0),
					BspCommissionTax = q.CommissionTax,
					BspCommissionRate = rateModel.CommissionRate,
					BspCommissionTaxRate = rateModel.CommissionTaxRate,
					BspDiscount = q.Discount + (isTaxIncluded ? q.DiscountTax : 0),
					BspDiscountTax = q.DiscountTax,
					BspDiscountRate = rateModel.DiscountRate,
					BspDiscountTaxRate = rateModel.DiscountTaxRate,
					BspDiscountReasonId = q.DiscountReasonId,
					BspMarkup = q.Markup + (isTaxIncluded ? q.MarkupTax : 0),
					BspMarkupTax = q.MarkupTax,
					BspMarkupRate = rateModel.MarkupRate,
					BspMarkupTaxRate = rateModel.MarkupTaxRate,
					BspMarkupStrategyId = q.MarkupStrategyId,
					BspIsCreditCardDiscountApplicable = q.IsCreditCardDiscountApplicable,
					BspIncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment,
					BspTotalAmount = q.TotalAmountGross,
					BspTotalTax = q.TotalTax,
					BspTotalTaxRate = q.TotalTaxRate,
					BspComments = q.Comments,
					LastWriteTime = q.LastWriteTime.ToLocalTime(),
					CreationTime = q.CreationTime.ToLocalTime(),
					LastWriteUser = q.LastWriteUser,
					CreationUser = q.CreationUser
				};

				ViewBag.BspIsNative = isNative;
				return PartialView("~/Views/Accounting/EditorTemplates/BspEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Bsp_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Bsp_Read([DataSourceRequest] DataSourceRequest request, DateTime? dateFrom, DateTime? dateTo, DateTime? departureDate, int bspTypeId, int? documentStatusId, int bankAccountId,
			int? paymentId, decimal? amountFrom, decimal? amountTo, decimal? ticketedFare, decimal? amountPayable, int creditorId, int supplierId, int airlineId, int saleTypeId, int categoryId, int sourceId,
			int agencyId, int consultantId, string account, string passenger, string text, int selectionOptionId, bool isExport, string sortMember = null, string sortDirection = null, int? id = null) {

			try {
				var lazyContext = LazyContext;

				var bspStatus = (BspStatus?)documentStatusId;
				var selectionOption = (SelectionOption)selectionOptionId;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q1 = lazyContext.Bsp.Where(t => t.Id > 0);

				if (id != null) {
					q1 = q1.Where(t => t.Id == id);
				}
				else {
					if (dateFrom != null)
						q1 = q1.Where(t => t.DocumentDate >= dateFrom);

					if (dateTo != null) {
						if (bspStatus == BspStatus.Open && creditorId > 0 && bankAccountId > 0) {
							q1 = q1.Where(t => (t.PaymentId <= 0 && t.DocumentDate <= dateTo) || (t.PaymentId > 0 && t.Payment.ReturnDate <= dateTo));
						}
						else {
							q1 = q1.Where(t => t.DocumentDate <= dateTo);
						}
					}

					if (departureDate != null)
						q1 = q1.Where(t => t.DepartureDate == departureDate);

					if (bspTypeId != (int)BspType.All)
						q1 = q1.Where(t => (int)t.BspType == bspTypeId);

					if (bspStatus == BspStatus.MissingOpenDocuments) {
						int bspId = 0;
						var selectedIds = new List<int>();
						long previousDocumentNo = 0;

						foreach (var row in q1.Where(t1 => t1.BspDetails.Any(t2 => t2.DocumentStatus == DocumentStatus.Open)).ToList().Where(t => t.DocumentNo.Replace("/", string.Empty).IsNumeric()).OrderBy(t => t.DocumentNo).ToList()) {
							var documentNos = row.DocumentNo.Split('/');

							if (documentNos.Length == 1)
								continue;

							int i = 0;

							foreach (var documentNo in documentNos) {
								long.TryParse(string.Join(string.Empty, Array.FindAll(documentNo.ToCharArray(), char.IsDigit)), out long currentDocumentNo);

								if (currentDocumentNo == 0)
									continue;

								if (previousDocumentNo > 0) {
									if (i > 0 && i < documentNos.Length && documentNo == documentNos[i])
										currentDocumentNo = long.Parse(string.Concat(documentNos.First().Substring(0, documentNos.First().Length - documentNos[i].Length), documentNo));

									if (currentDocumentNo - previousDocumentNo > 1) {
										if (selectedIds.Count == 0)
											selectedIds.Add(bspId);

										selectedIds.Add(row.Id);
									}
								}
								else {
									bspId = row.Id;
								}

								previousDocumentNo = currentDocumentNo;
								i++;
							}
						}

						var arrays = selectedIds.ToArray().Split(2100).ToArray();
						var predicate = PredicateBuilder.False<Bsp>();

						foreach (var array in arrays) {
							predicate = predicate.Or(t => array.Contains(t.Id));
						}

						q1 = q1.Where(predicate);
					}
					else if (bspStatus != null) {
						if (bspStatus == BspStatus.None) {
							q1 = q1.Where(t => t.BspDetails.Count == 0);
						}
						else {
							IQueryable<int> bspIds = null;

							if (bspStatus == BspStatus.NoAutoAgencyCc) {
								bspIds = Bsp.GetMissingAutoAgencyCcBspIds(lazyContext, agencyId);
							}
							else if (bspStatus == BspStatus.Reversal || bspStatus == BspStatus.Reversed) {
								bspIds = lazyContext.BspDetail.Where(t => t.ReversalStatus == (bspStatus == BspStatus.Reversal ? ReversalStatus.Reversal : ReversalStatus.Reversed)).Select(t => t.BspId).Distinct();
							}
							else {
								bspIds = lazyContext.BspDetail.Where(t => t.DocumentStatus == (DocumentStatus)bspStatus).Select(t => t.BspId).Distinct();
							}

							q1 = q1.Where(t => bspIds.Contains(t.Id));
						}
					}

					if (bspStatus != BspStatus.Open && bankAccountId > 0)
						q1 = q1.Where(t => t.Payment.BankAccountId == bankAccountId);

					if (paymentId != null)
						q1 = q1.Where(t => t.PaymentId == paymentId);

					if (amountFrom != null)
						q1 = q1.Where(t1 => (t1.BspDetails.Sum(t2 => (decimal?)(t2.Amount + t2.Tax + t2.NonCommissionable + t2.NonCommissionableTax)) ?? 0) >= amountFrom);

					if (amountTo != null)
						q1 = q1.Where(t1 => (t1.BspDetails.Sum(t2 => (decimal?)(t2.Amount + t2.Tax + t2.NonCommissionable + t2.NonCommissionableTax)) ?? 0) <= amountTo);

					if (ticketedFare != null)
						q1 = q1.Where(t1 => lazyContext.TripLineAirPassenger.Any(t2 => t2.TripLineId == t1.TripLineId && t2.TicketedFare == ticketedFare));

					if (amountPayable != null)
						q1 = q1.Where(t => t.AmountPayable == amountPayable);

					if (creditorId > 0) {
						q1 = q1.Where(t1 => t1.CreditorId == creditorId && (t1.BspType != BspType.AgencyCC || t1.BspDetails.Any(t2 => t2.FormOfPayment.CreditorId == creditorId)));
					}
					else {
						q1 = q1.Where(t => t.BspType != BspType.AgencyCC);
					}

					if (supplierId > 0)
						q1 = q1.Where(t => t.SupplierId == supplierId);

					if (airlineId > 0)
						q1 = q1.Where(t => t.AirlineId == airlineId);

					if (saleTypeId > 0)
						q1 = q1.Where(t => t.SaleTypeId == saleTypeId);

					if (categoryId > 0)
						q1 = q1.Where(t => t.CategoryId == categoryId);

					if (sourceId > 0)
						q1 = q1.Where(t => t.SourceId == sourceId);

					if (agencyId > 0)
						q1 = q1.Where(t => t.AgencyId == agencyId);

					if (consultantId > 0)
						q1 = q1.Where(t => t.ConsultantId == consultantId);

					if (!string.IsNullOrEmpty(account)) {
						var predicate = PredicateBuilder.False<Bsp>();

						foreach (var row in account.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
							predicate = predicate.Or(t => t.Trip.Id.ToString().Contains(row) || (t.Trip.Title + " " + t.Trip.FirstName + " " + t.Trip.LastName).Trim().ToLower().Contains(row) || t.Supplier.Name.ToLower().Contains(row));
						}

						q1 = q1.Where(predicate);
					}

					if (!string.IsNullOrEmpty(passenger)) {
						var predicate = PredicateBuilder.False<BspDetail>();

						foreach (var row in passenger.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
							predicate = predicate.Or(t => (t.Passenger.Title + " " + t.Passenger.FirstName + " " + t.Passenger.LastName).Trim().ToLower().Contains(row));
						}

						var bspDetailIds = lazyContext.BspDetail.Where(predicate).Select(t => t.Id);
						q1 = q1.Where(t1 => t1.BspDetails.Any(t2 => bspDetailIds.Contains(t2.Id)));
					}

					if (!string.IsNullOrEmpty(text)) {
						text = text.Trim().ToLower();
						q1 = q1.Where(t => t.DocumentNo.ToLower().Contains(text));
					}

					if (bspStatus == BspStatus.Open && selectionOption != SelectionOption.All && selectionOption != SelectionOption.MatchZeros) {
						int[] selectedIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionBspIds;
						var arrays = selectedIds.Split(2100).ToArray();

						if (selectionOption == SelectionOption.Matched) {
							var predicate = PredicateBuilder.False<Bsp>();

							foreach (var array in arrays) {
								predicate = predicate.Or(t => array.Contains(t.Id));
							}

							q1 = q1.Where(predicate);
						}
						else {
							foreach (var array in arrays) {
								q1 = q1.Where(t => !array.Contains(t.Id));
							}
						}
					}
				}

				var q2 = q1.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).Select(row => new BspViewModel {
					BspId = row.Id,
					BspAccountName = row.AccountName,
					BspAccountNameLink = row.AccountNameLink,
					BspDocumentStatus = row.DocumentStatus,
					BspReversalStatus = row.ReversalStatus,
					BspType = row.BspType,
					BspDocumentNo = row.DocumentNo,
					BspDocumentDate = row.DocumentDate,
					BspCreditorId = row.CreditorId,
					BspCreditor = row.Creditor.Name,
					BspSupplier = row.Supplier.Name,
					BspDepartureDate = row.DepartureDate <= lazyContext.VoidDate ? (DateTime?)null : row.DepartureDate,
					BspSaleType = row.SaleTypeId <= 0 ? string.Empty : row.SaleType.Name,
					BspCommission = row.Commission,
					BspCommissionTax = row.CommissionTax,
					BspTotalCash = isExport || bspStatus == BspStatus.Open || bspStatus == BspStatus.Paid ? row.BspDetails.Where(t => t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.CreditCard && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.TravelCard).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0 : 0,
					BspTotalCashNonCommissionable = isExport || bspStatus == BspStatus.Open || bspStatus == BspStatus.Paid ? row.BspDetails.Where(t => t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.CreditCard && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.TravelCard).Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0 : 0,
					BspTotalCreditCard = isExport || bspStatus == BspStatus.Open || bspStatus == BspStatus.Paid ? row.BspDetails.Where(t => t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.CreditCard || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.TravelCard).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0 : 0,
					BspTotalCreditCardNonCommissionable = isExport || bspStatus == BspStatus.Open || bspStatus == BspStatus.Paid ? row.BspDetails.Where(t => t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.CreditCard || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.TravelCard).Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0 : 0,
					BspTotalTax = row.BspDetails.Sum(t => (decimal?)t.Tax) ?? 0,
					BspTotalAmount = !isExport && (bspStatus == BspStatus.Open || bspStatus == BspStatus.Paid) ? 0 : row.BspDetails.Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0,
					BspAmountPayable = lazyContext.Bsp.Where(t => (t.Id == row.Id || t.AgencyCreditCardBspId == row.Id) && t.CreditorId == row.CreditorId).Sum(t => (decimal?)t.AmountPayable) ?? 0,
					BspPaymentDocumentNo = row.Payment.DocumentNo,
					BspPaymentDate = row.Payment.DocumentDate,
					BspReturnDate = row.Payment.ReturnDate,
					BspChildCount = bspStatus == BspStatus.Open || bspStatus == BspStatus.Paid ? row.BspDetails.Count(t => (t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross) && (creditorId <= 0 || (t.Bsp.CreditorId == creditorId && t.FormOfPayment.CreditorId != creditorId))) : 0,
					BspCanEdit = row.CanEdit(isSuperUser),
					BspCanDelete = row.CanDelete(isSuperUser),
					BspCanUndo = row.CanUndo(),
					BspCanReverse = row.CanReverse(),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				});

				if (id == null) {
					if (bspStatus == BspStatus.Open && selectionOption == SelectionOption.MatchZeros) {
						int[] selectedIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionBspIds;

						if (selectedIds.Length == 0) {
							q2 = q2.Where(t => t.BspAmountPayable == 0);
						}
						else {
							var arrays = selectedIds.Split(2100).ToArray();
							var predicate = PredicateBuilder.False<BspViewModel>();

							foreach (var array in arrays) {
								predicate = predicate.Or(t => !array.Contains(t.BspId) && t.BspAmountPayable == 0);
							}

							q2 = q2.Where(predicate);
						}
					}

					if (isExport) {
						if (!isAdministrator)
							throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

						var export = q2.ApplySorting(null, WebUtils.GetSortDescriptors(sortMember, sortDirection)).ToList().ConvertAll(row => new BspExportModel {
							AccountName = row.BspAccountName,
							Type = row.BspTypeDescription,
							DocumentNo = row.BspDocumentNo,
							DocumentDate = row.BspDocumentDate,
							DocumentStatus = row.BspDocumentStatus.GetEnumDescription(),
							ReversalStatus = row.BspReversalStatus.GetEnumDescription(),
							DepartureDate = row.BspDepartureDate,
							Creditor = row.BspCreditor,
							Supplier = row.BspSupplier,
							SaleType = row.BspSaleType,
							Commission = row.BspCommission,
							CommissionTax = row.BspCommissionTax,
							Cash = row.BspTotalCash,
							CashNonCommissionable = row.BspTotalCashNonCommissionable,
							CreditCard = row.BspTotalCreditCard,
							CreditCardNonCommissionable = row.BspTotalCreditCardNonCommissionable,
							Tax = row.BspTotalTax,
							TotalAmount = row.BspTotalAmount,
							AmountPayable = row.BspAmountPayable,
							PaymentNo = row.BspPaymentDocumentNo,
							PaymentDate = row.BspPaymentDate,
							ReturnDate = row.BspReturnDate == DateTime.MinValue ? null : row.BspReturnDate
						});

						var xlsx = new ExportToExcel<BspExportModel>(export);
						return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "BSP Returns.xlsx");
					}

					if (bspStatus == BspStatus.Open || bspStatus == BspStatus.Paid) {
						q2 = q2.AsEnumerable().GroupBy(row => new {
							row.BspDocumentNo,
							row.BspDocumentDate,
							row.BspCreditorId,
							row.BspCreditor,
							row.BspSupplier
						}).Select(row => new BspViewModel {
							BspId = row.Min(t => t.BspId),
							BspAccountName = row.First().BspAccountName,
							BspAccountNameLink = row.First().BspAccountNameLink,
							BspType = (BspType)row.Min(t => (int)t.BspType),
							BspDocumentNo = row.Key.BspDocumentNo,
							BspDocumentDate = row.Key.BspDocumentDate,
							BspCreditorId = row.Key.BspCreditorId,
							BspCreditor = row.Key.BspCreditor,
							BspSupplier = row.Key.BspSupplier,
							BspDepartureDate = row.Max(t => t.BspDepartureDate),
							BspSaleType = row.Max(t => t.BspSaleType),
							BspCommission = row.Sum(t => t.BspCommission),
							BspCommissionTax = row.Sum(t => t.BspCommissionTax),
							BspTotalCash = row.Sum(t => t.BspTotalCash),
							BspTotalCashNonCommissionable = row.Sum(t => t.BspTotalCashNonCommissionable),
							BspTotalCreditCard = row.Sum(t => t.BspTotalCreditCard),
							BspTotalCreditCardNonCommissionable = row.Sum(t => t.BspTotalCreditCardNonCommissionable),
							BspTotalTax = row.Sum(t => t.BspTotalTax),
							BspTotalAmount = row.Sum(t => t.BspTotalAmount),
							BspAmountPayable = row.Sum(t => t.BspAmountPayable),
							BspHasChildren = row.Sum(t => t.BspChildCount) > 0,
							LastWriteTime = row.First().LastWriteTime,
							CreationTime = row.First().CreationTime,
							LastWriteUser = row.First().LastWriteUser,
							CreationUser = row.First().CreationUser
						}).AsQueryable();
					}
				}

				int[] gridIds = null;
				decimal totalAmountPayable = 0;

				if (bspStatus == BspStatus.Open) {
					gridIds = q2.Select(t => t.BspId).ToArray();
					totalAmountPayable = q2.Sum(t => (decimal?)t.BspAmountPayable) ?? 0;
				}

				var aggregateResults = new List<AggregateResult> {
					new AggregateResult(gridIds, new MinFunction { FunctionName = "Min", SourceField = "GridIds", MemberType = typeof(int[]) }),
					new AggregateResult(totalAmountPayable, new SumFunction { FunctionName = "Sum", SourceField = "BspAmountPayable", MemberType = typeof(decimal) })
				};

				int total = q2.Count();
				q2 = q2.ApplySorting(request.Groups, request.Sorts).ApplyPaging(request.Page, request.PageSize);

				var result = await Task.Run(() => new DataSourceResult {
					Data = q2,
					Total = total,
					AggregateResults = aggregateResults
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Bsp_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		public async Task<IActionResult> BspLinkedDocument_Read([DataSourceRequest] DataSourceRequest request, int bspId, int documentStatusId, int creditorId) {
			try {
				var lazyContext = LazyContext;

				var q1 = lazyContext.Bsp.Where(t => t.AgencyCreditCardBspId == bspId);
				var q2 = lazyContext.NonBsp.Where(t => t.AgencyCreditCardBspId == bspId);

				var bspStatus = (BspStatus)documentStatusId;

				if ((bspStatus == BspStatus.Open || bspStatus == BspStatus.Paid) && creditorId > 0) {
					q1 = q1.Where(t => t.CreditorId == creditorId);
					q2 = q2.Where(t => t.CreditorId == creditorId);
				}

				var result = await q1.Select(row => new BspViewModel {
					BspId = row.Id,
					BspCreditor = row.Creditor.Name,
					BspDocumentType = string.Format("{0} [BSP]", row.BspType.GetEnumDescription()),
					BspDocumentNo = row.DocumentNo,
					BspDocumentDate = row.DocumentDate,
					BspSaleType = row.SaleTypeId <= 0 ? string.Empty : row.SaleType.Name,
					BspFormOfPayment = row.BspDetails.First().FormOfPayment.Name,
					BspTotalAmount = row.TotalAmountGross,
					BspTotalTax = row.TotalTax,
					BspAmountPayable = row.AmountPayable,
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).AsEnumerable().Concat(q2.Select(row => new BspViewModel {
					BspId = row.Id,
					BspCreditor = row.Creditor.Name,
					BspDocumentType = string.Format("{0} [Non-BSP]", row.NonBspType.GetEnumDescription()),
					BspDocumentNo = row.DocumentNo,
					BspDocumentDate = row.DocumentDate,
					BspSaleType = row.SaleTypeId <= 0 ? string.Empty : row.SaleType.Name,
					BspFormOfPayment = row.NonBspDetails.First().FormOfPayment.Name,
					BspTotalAmount = row.TotalAmountGross,
					BspTotalTax = row.TotalTax,
					BspAmountPayable = row.AmountPayable,
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				})).AsEnumerable().ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BspLinkedDocument_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Bsp_CreateOrUpdate(BspViewModel model, bool isNew) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				if (model.BspType != BspType.Conjunction && model.BspType != BspType.Free && model.BspType != BspType.Void && !Context.Bsp.Any(t => t.Id == model.BspId))
					throw new UnreportedException(AppConstants.RecordCannotBeCreated);

				new BspCommon(HttpContext).CreateOrUpdate(model, true, !isNew, !isNew, !isNew);
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Bsp_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> BspWithDetail_CreateOrUpdate(BspViewModel model, BspDetailViewModel detailModel, bool isNew) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				var context = Context;

				new BspDetailCommon(HttpContext).CreateOrUpdate(model, detailModel, isNew);
				var q = context.Bsp.Find(model.BspId);

				model.BspTotalAmount = q.TotalAmountGross;
				model.BspTotalNonCommissionable = q.TotalNonCommissionable;
				model.BspTotalTax = q.TotalTax;
				model.BspTotalTaxRate = q.TotalTaxRate * 100;
				model.BspAmountPayable = q.GetAmountPayable(context);

				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BspWithDetail_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Bsp_Delete([DataSourceRequest] DataSourceRequest request, BspViewModel model) {
			try {
				new BspCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Bsp_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Bsp_UpdateModel(BspViewModel model, string source, decimal unsavedAmount, decimal unsavedTax, int detailId) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.Bsp.Find(model.BspId <= 0 ? -1 : model.BspId);

				int saleTypeId = q.SaleTypeId;
				bool isTaxApplicable = q.IsTaxApplicable;
                decimal nonCommissionable = 0;

                q.BspType = model.BspType;
				q.DocumentDate = model.BspDocumentDate ?? DateTime.Today;
				q.TripId = model.BspTripId ?? -1;
				q.TripLineId = model.BspTripLineId ?? -1;
				q.CreditorId = model.BspCreditorId ?? -1;
				q.SupplierId = model.BspSupplierId ?? -1;
				q.SaleTypeId = model.BspSaleTypeId ?? -1;
				q.AgencyId = model.BspAgencyId;
				q.ConsultantId = model.BspConsultantId ?? -1;
				q.SupplierCancellationFee = model.BspSupplierCancellationFee;
				q.Commission = model.BspCommission;
				q.CommissionTax = model.BspCommissionTax;
				q.Discount = model.BspDiscount;
				q.DiscountTax = model.BspDiscountTax;
				q.Markup = model.BspMarkup;
				q.MarkupTax = model.BspMarkupTax;
				q.IsCreditCardDiscountApplicable = model.BspIsCreditCardDiscountApplicable;
				q.IncludeMarkupInCreditCardPayment = model.BspIncludeMarkupInCreditCardPayment;

				model.BspIsClientAccountLocked = q.IsClientAccountLocked;

				bool updateRateModel = true;
				bool updateDetailModel = true;
				bool documentNoChanged = false;
				string message = string.Empty;
				int formOfPaymentId = -1;

				if (model.BspId > 0) {
					switch (source) {
						case "SaleTypeId":
							if (!q.ValidateTaxApplicability(isTaxApplicable)) {
								model.BspSaleTypeId = saleTypeId;
								message = AppConstants.TaxRelatedRecordCannotBeAltered;
							}

							break;
					}

					if (!string.IsNullOrEmpty(message))
						return Json(new { Model = model, Message = message });
				}

				List<string> sources = null;

				if (source == "DeleteDetail") {
					sources = new List<string> { "CommissionRate", "DiscountRate", "MarkupRate" };
				}
				else {
					sources = new List<string> { source };
				}

				switch (source) {
					case "CreditorId":
						model.BspIncludeMarkupInCreditCardPayment = q.Creditor.IncludeMarkupInCreditCardPayment;
						break;
					case "SaleTypeId":
						model.BspIsCreditCardDiscountApplicable = q.SaleType.IsCreditCardDiscountApplicable;
						break;
					case "BspType":
						model.BspIsCommissionPermitted = q.IsCommissionPermitted;
						model.BspIsDiscountPermitted = q.IsDiscountPermitted;
						model.BspIsMarkupPermitted = q.IsMarkupPermitted;
						model.BspIsCancellationPermitted = q.IsCancellationPermitted;
						break;
					case "DocumentNo":
						string documentNo = model.BspDocumentNo;
						model.BspDocumentNo = Bsp.GetUniqueDocumentNo(Context, model.BspType, model.BspId, documentNo);
						var tripLineAirPassenger = lazyContext.TripLineAirPassenger.FirstOrDefault(t => t.TicketNo == model.BspDocumentNo);

						if (tripLineAirPassenger?.TripLineAir.TripLine == null || tripLineAirPassenger?.TripLineId <= 0)
							return Json(new { IsCancelled = true });

						documentNoChanged = !string.IsNullOrEmpty(documentNo) && model.BspDocumentNo != documentNo;

						model.BspDocumentDate = tripLineAirPassenger.IssueDate == DateTime.MinValue ? DateTime.Today : tripLineAirPassenger.IssueDate;
						model.BspTripId = tripLineAirPassenger.TripLineAir.TripLine.TripId;
						model.BspAirlineId = tripLineAirPassenger.TripLineAir.TripLine.TripLineAir.AirlineId;
						model.BspDepartureDate = tripLineAirPassenger.TripLineAir.TripLine.TripLineType == TripLineType.Air ? tripLineAirPassenger.TripLineAir.TripLine.TripLineAir.DepartureDate : tripLineAirPassenger.TripLineAir.TripLine.Trip.DepartureDate;
						model.BspOfferedFare = tripLineAirPassenger.OfferedFare;
						model.BspOfferedReasonId = tripLineAirPassenger.OfferedReasonId;

						model.BspSaleTypeId = tripLineAirPassenger.SaleTypeId;
						model.BspCategoryId = tripLineAirPassenger.TripLineAir.TripLine.Trip.CategoryId;
						model.BspDestinationId = tripLineAirPassenger.TripLineAir.TripLine.Trip.DestinationId;
						model.BspConsultantId = tripLineAirPassenger.TripLineAir.TripLine.Trip.ConsultantId <= 0 ? null : tripLineAirPassenger.TripLineAir.TripLine.Trip.ConsultantId;
						model.BspAgentId = tripLineAirPassenger.TripLineAir.TripLine.Trip.AgentId;
						model.BspSourceId = tripLineAirPassenger.TripLineAir.TripLine.Trip.SourceId;

						model.BspCommission = tripLineAirPassenger.Commission;
						model.BspCommissionTax = 0;
						model.BspDiscount = tripLineAirPassenger.Discount;
						model.BspDiscountTax = 0;
						model.BspDiscountReasonId = tripLineAirPassenger.DiscountReasonId;
						model.BspMarkup = tripLineAirPassenger.Markup;
						model.BspMarkupTax = 0;
						model.BspMarkupStrategyId = tripLineAirPassenger.MarkupStrategyId;

						model.BspIsCreditCardDiscountApplicable = tripLineAirPassenger.IsCreditCardDiscountApplicable;
						model.BspIncludeMarkupInCreditCardPayment = tripLineAirPassenger.IncludeMarkupInCreditCardPayment;
						break;
					case "TripId":
						if (q.Trip == null) {
							updateRateModel = false;
							break;
						}

						var tripLines = q.Trip.TripLines.Where(t => t.TripLineType == TripLineType.Air && t.TripLineAir.DepartureDate > AppConstants.VoidDate).ToList();

						if (tripLines.Count > 0)
							model.BspDepartureDate = tripLines.Min(t => t.TripLineAir.DepartureDate);

						model.BspDepartureDate = q.Trip.DepartureDate;
						model.BspCategoryId = q.Trip.CategoryId;
						model.BspDestinationId = q.Trip.DestinationId;
						model.BspConsultantId = q.Trip.ConsultantId <= 0 ? HttpContext.CurrentConsultantId() : q.Trip.ConsultantId;
						model.BspAgentId = q.Trip.AgentId;
						model.BspSourceId = q.Trip.SourceId;
						break;
					case "TripLineId":
						if (q.TripLine == null || q.TripLineId <= 0 || q.TripLine.TripLineType == TripLineType.ServiceFee || q.BspType == BspType.Conjunction || q.BspType == BspType.Free || q.BspType == BspType.Void) {
							updateRateModel = false;
							break;
						}

                        bool isRefund = q.TripLine.TripLineType == TripLineType.Air && q.TripLine.TripLineAir.TripLineAirPassengers.Any(t => t.BspEntryType == BspEntryType.Refund);
                        bool isNotRefund = q.TripLine.TripLineType == TripLineType.Air && q.TripLine.TripLineAir.TripLineAirPassengers.Any(t => t.BspEntryType != BspEntryType.Refund);

                        if (isRefund && isNotRefund) {
                            updateRateModel = false;
                            break;
                        }

                        int sign = isRefund ? -1 : 1;

                        model.BspTripLineType = q.TripLine.TripLineType;
						model.BspDocumentNo = q.TripLine.DocumentNo;
						model.BspAirlineId = q.TripLine.TripLineAir?.AirlineId ?? -1;
						model.BspDepartureDate = q.TripLine.StartDate > AppConstants.VoidDate ? q.TripLine.StartDate : DateTime.MinValue;
						model.BspCreditorId = q.TripLine.Creditor.Id;
						model.BspSupplierId = q.TripLine.Supplier.Id;
						model.BspSaleTypeId = q.TripLine.SaleType.Id;
						model.BspCommission = sign * q.TripLine.Commission;
						model.BspCommissionTax = 0;
						model.BspDiscount = sign * q.TripLine.Discount;
						model.BspDiscountTax = 0;
						model.BspDiscountReasonId = q.TripLine.DiscountReason.Id;
						model.BspMarkup = sign * q.TripLine.Markup;
						model.BspMarkupTax = 0;
						model.BspMarkupStrategyId = q.TripLine.MarkupStrategy.Id;

						model.BspOfferedFare = q.TripLine.OfferedFare ?? 0;
						model.BspOfferedReasonId = q.TripLine.OfferedReason.Id;

						model.BspIsCreditCardDiscountApplicable = q.TripLine.IsCreditCardDiscountApplicable;
						model.BspIncludeMarkupInCreditCardPayment = q.TripLine.IncludeMarkupInCreditCardPayment;

						model.BspTotalNonCommissionable = sign * q.TripLine.NonCommissionable;

						q.SaleTypeId = q.TripLine.SaleType.Id;
						q.Commission = sign * q.TripLine.Commission;
						q.CommissionTax = 0;
						q.Discount = sign * q.TripLine.Discount;
						q.DiscountTax = 0;
						q.Markup = sign * q.TripLine.Markup;
						q.MarkupTax = 0;

						formOfPaymentId = q.TripLine.FormOfPayment.Id;
                        nonCommissionable = sign * q.TripLine.GetNonCommissionableDue(lazyContext);
                        unsavedAmount = sign * q.TripLine.GetAmountPayableDue(lazyContext, HttpContext.CurrentCustomerId()) - nonCommissionable;
						unsavedTax = 0;

						sources.Add("Commission");
						sources.Add("Discount");
						sources.Add("Markup");
						break;
					case "Commission":
					case "CommissionRate":
					case "CommissionTax":
					case "Discount":
					case "DiscountRate":
					case "Markup":
					case "MarkupRate":
						updateDetailModel = false;
						break;
				}

				model.BspDepartureDateStatus = model.BspDepartureDate == DateTime.MinValue ? DepartureDateStatus.Open : model.BspDepartureDate == AppConstants.VoidDate ? DepartureDateStatus.ARNK : DepartureDateStatus.Normal;
				model.BspIsTaxApplicable = q.IsTaxApplicable;

				var rateModel = new RateModel {
					Commission = model.BspCommission,
					CommissionRate = model.BspCommissionRate / 100,
					CommissionTax = model.BspCommissionTax,
					Discount = model.BspDiscount,
					DiscountRate = model.BspDiscountRate / 100,
					DiscountTax = model.BspDiscountTax,
					Markup = model.BspMarkup,
					MarkupRate = model.BspMarkupRate / 100,
					MarkupTax = model.BspMarkupTax,
					IsTaxIncluded = model.BspIsTaxIncluded
				};

				if (updateRateModel) {
					var rates = new AccountingRates<Bsp>(HttpContext, q, rateModel);
					bool result = rates.SetRates(sources, unsavedAmount, unsavedTax, detailId);

					if (result || source == "DeleteDetail") {
						model.BspCommission = rateModel.CommissionGross;
						model.BspCommissionRate = rateModel.CommissionRate * 100;
						model.BspCommissionTax = rateModel.CommissionTax;
						model.BspCommissionTaxRate = rateModel.CommissionTaxRate * 100;

						model.BspDiscount = rateModel.DiscountGross;
						model.BspDiscountRate = rateModel.DiscountRate * 100;
						model.BspDiscountTax = rateModel.DiscountTax;
						model.BspDiscountTaxRate = rateModel.DiscountTaxRate * 100;

						model.BspMarkup = rateModel.MarkupGross;
						model.BspMarkupRate = rateModel.MarkupRate * 100;
						model.BspMarkupTax = rateModel.MarkupTax;
						model.BspMarkupTaxRate = rateModel.MarkupTaxRate * 100;
					}
					else {
						updateDetailModel = false;
					}
				}
				else {
					updateDetailModel = false;
				}

				if (source == "DeleteDetail") {
					model.BspCommission = Math.Round(q.TotalAmountGross * model.BspCommissionRate / 100, 2);
					model.BspDiscount = Math.Round(q.TotalAmountGross * model.BspDiscountRate / 100, 2);
					model.BspMarkup = Math.Round(q.TotalAmountGross * model.BspMarkupRate / 100, 2);
					new BspCommon(HttpContext).CreateOrUpdate(model, false);
				}

				return Json(new { Model = model, DetailModel = new { FormOfPaymentId = formOfPaymentId, Amount = rateModel.AmountGross, NonCommissionable = nonCommissionable, rateModel.Tax, TaxRate = rateModel.TaxRate * 100 }, UpdateDetailModel = updateDetailModel, DocumentNoChanged = documentNoChanged, Message = message });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Bsp_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Bsp_ProcessSelections(int[] bspIds, int documentStatusId, int bankAccountId, string documentNo, DateTime documentDate, DateTime returnDate, bool undo) {
			try {
				if (bspIds == null || bspIds.Length == 0)
					throw new UnreportedException("No documents have been selected.");

				bool result = new BspCommon(HttpContext).ProcessSelections(LazyContext, bspIds, documentStatusId, bankAccountId, documentNo, documentDate, returnDate, undo);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Bsp_ProcessSelections", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Bsp_Undo(int id, bool isDetailView) {
			try {
				bool result = new BspCommon(HttpContext).Undo(LazyContext, id, isDetailView);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Bsp_Undo", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Bsp_Reverse(int bspId, string type) {
			try {
				bool result = new BspCommon(HttpContext).Reverse(LazyContext, bspId, type);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Bsp_Reverse", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> BspDetail_Edit(int bspId, int bspDetailId, bool isTaxIncluded) {
			try {
				if (bspDetailId == -1)
					return PartialView("~/Views/Accounting/EditorTemplates/BspDetailEdit.cshtml");

				var lazyContext = LazyContext;
				BspDetail q = null;

				if (bspDetailId == 0) {
					var creditor = Creditor.GetBspAgent(lazyContext, HttpContext.CurrentCustomerId(), TripLineType.Air);
					var supplier = Supplier.GetBspAgent(lazyContext, HttpContext.CurrentCustomerId(), TripLineType.Air);

					q = new BspDetail {
						Id = 0,
						BspId = bspId,
						DocumentStatus = DocumentStatus.Open,
						ReversalStatus = ReversalStatus.None,
						TripLineAirPassengerId = -1,
						PassengerId = -1,
						FormOfPaymentId = -1,
						Bsp = lazyContext.Bsp.Find(bspId) ?? new Bsp {
							Id = bspId,
							BspType = BspType.Bsp,
							DocumentDate = DateTime.Today,
							DepartureDate = DateTime.MinValue,
							Creditor = creditor,
							CreditorId = creditor.Id,
							Supplier = supplier,
							SupplierId = supplier.Id
						}
					};
				}
				else {
					q = lazyContext.BspDetail.Find(bspDetailId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				var rateModel = new RateModel {
					Commission = q.Bsp.Commission,
					CommissionTax = q.Bsp.CommissionTax,
					Discount = q.Bsp.Discount,
					DiscountTax = q.Bsp.DiscountTax,
					Markup = q.Bsp.Markup,
					MarkupTax = q.Bsp.MarkupTax,
					IsTaxIncluded = isTaxIncluded,
					IsFormBinding = true
				};

				var rates = new AccountingRates<BspDetail>(HttpContext, q, rateModel);
				rates.SetRates(new List<string> { "Tax" });

				var model = new BspDetailViewModel {
					BspDetailId = q.Id,
					BspId = q.BspId,
					BspDetailDocumentStatus = q.DocumentStatus,
					BspDetailReversalStatus = q.ReversalStatus,
					BspDetailTripLineAirPassengerId = q.TripLineAirPassengerId,
					BspDetailPassengerId = q.PassengerId,
					BspDetailFormOfPaymentId = q.FormOfPaymentId,
					BspDetailAmount = isTaxIncluded ? q.Amount + q.Tax : q.Amount,
					BspDetailTax = q.Tax,
					BspDetailTaxRate = rateModel.TaxRate,
					BspDetailNonCommissionable = q.NonCommissionableGross,
					BspDetailIsBspAgent = q.Bsp.Creditor.IsBspAgent
				};

				return PartialView("~/Views/Accounting/EditorTemplates/BspDetailGridEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BspDetail_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> BspDetail_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
			try {
				var lazyContext = LazyContext;
				bool isSuperUser = HttpContext.IsSuperUser();
				const bool isTaxIncluded = false;

				var q = lazyContext.BspDetail.Where(t => t.BspId == parentId);

				var result = await q.Select(row => new BspDetailViewModel {
					BspDetailId = row.Id,
					BspId = row.BspId,
					BspDetailDocumentStatus = row.DocumentStatus,
					BspDetailReversalStatus = row.ReversalStatus,
					BspDetailTripLineAirPassengerId = row.TripLineAirPassengerId,
					BspDetailPassengerId = row.PassengerId,
					BspDetailPassenger = row.TripLineAirPassengerId <= 0 && row.PassengerId <= 0 ? string.Empty : row.TripLineAirPassengerId > 0 ? row.TripLineAirPassenger.Passenger.FullName : row.Passenger.FullName,
					BspDetailFormOfPaymentId = row.FormOfPaymentId,
					BspDetailFormOfPayment = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.PaySupplierDescription,
					BspDetailPaymentLink = row.Bsp.PaymentId <= 0 ? string.Empty : row.Bsp.PaymentLink,
					BspDetailPaymentDate = row.Bsp.Payment.DocumentDate == DateTime.MinValue ? null : row.Bsp.Payment.DocumentDate,
					BspDetailAmount = isTaxIncluded ? row.Amount + row.Tax : row.Amount,
					BspDetailTax = row.Tax,
					BspDetailNonCommissionable = row.NonCommissionableGross,
					BspDetailCanEdit = row.CanEdit(isSuperUser),
					BspDetailCanDelete = row.CanDelete(isSuperUser),
					BspDetailCanUndo = row.CanUndo(),
					BspDetailCanReverse = row.CanReverse(),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BspDetail_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> BspDetail_Delete([DataSourceRequest] DataSourceRequest request, BspDetailViewModel model) {
			try {
				new BspDetailCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BspDetail_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> BspDetail_UpdateModel(BspViewModel model, BspDetailViewModel detailModel, string source) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.BspDetail.Find(detailModel.BspDetailId <= 0 ? -1 : detailModel.BspDetailId);

				q.BspId = model.BspId;
				q.TripLineAirPassengerId = detailModel.BspDetailTripLineAirPassengerId ?? -1;
				q.Amount = detailModel.BspDetailAmount;
				q.Tax = detailModel.BspDetailTax;
				q.NonCommissionable = detailModel.BspDetailNonCommissionable;

				q.Bsp ??= lazyContext.Bsp.Find(model.BspId <= 0 ? -1 : model.BspId);

				q.Bsp.BspType = model.BspType;
				q.Bsp.DocumentNo = model.BspDocumentNo;
				q.Bsp.DocumentDate = model.BspDocumentDate ?? DateTime.Today;
				q.Bsp.TripId = model.BspTripId ?? -1;
				q.Bsp.TripLineId = model.BspTripLineId ?? -1;
				q.Bsp.CreditorId = model.BspCreditorId ?? -1;
				q.Bsp.SupplierId = model.BspSupplierId ?? -1;
				q.Bsp.SaleTypeId = model.BspSaleTypeId ?? -1;
				q.Bsp.AgencyId = model.BspAgencyId;
				q.Bsp.ConsultantId = model.BspConsultantId ?? -1;
				q.Bsp.SupplierCancellationFee = model.BspSupplierCancellationFee;
				q.Bsp.Commission = model.BspCommission;
				q.Bsp.CommissionTax = model.BspCommissionTax;
				q.Bsp.Discount = model.BspDiscount;
				q.Bsp.DiscountTax = model.BspDiscountTax;
				q.Bsp.Markup = model.BspMarkup;
				q.Bsp.MarkupTax = model.BspMarkupTax;

				model.BspIsClientAccountLocked = q.Bsp.IsClientAccountLocked;
				var sources = new List<string> { source };

				switch (source) {
					case "CreditorId":
						detailModel.BspDetailIsBspAgent = q.Bsp.Creditor?.IsBspAgent ?? false;
						break;
					case "TripLineId":
						if (q.Bsp.TripLine == null || q.Bsp.TripLineId <= 0)
							break;

						detailModel.BspDetailFormOfPaymentId = q.Bsp.TripLine.FormOfPayment.Id;
						detailModel.BspDetailAmount = q.Bsp.TripLine.AmountPayable - q.Bsp.TripLine.NonCommissionable;
						detailModel.BspDetailTax = 0;
						detailModel.BspDetailNonCommissionable = q.Bsp.TripLine.NonCommissionable;
						sources.Add("Amount");
						break;
					case "TripLineAirPassengerId":
						if (lazyContext.BspDetail.Any(t => t.Id != detailModel.BspDetailId && t.BspId == model.BspId && t.TripLineAirPassengerId != detailModel.BspDetailTripLineAirPassengerId && detailModel.BspDetailTripLineAirPassengerId > 0))
							throw new UnreportedException(AppConstants.SqlDuplicateAirPassengerException);

						if (q.TripLineAirPassenger == null || q.TripLineAirPassengerId <= 0)
							break;

						model.BspIsTaxIncluded = true;
						model.BspDocumentNo = q.TripLineAirPassenger.TicketNo;
						model.BspDocumentDate = q.TripLineAirPassenger.IssueDate == DateTime.MinValue ? DateTime.Today : q.TripLineAirPassenger.IssueDate;
						model.BspAirlineId = q.TripLineAirPassenger.AirlineId;
						model.BspDepartureDate = q.TripLineAirPassenger.TripLineAir.DepartureDate;

						model.BspCreditorId = q.TripLineAirPassenger.CreditorId;
						model.BspSupplierId = q.TripLineAirPassenger.SupplierId;
						model.BspSaleTypeId = q.TripLineAirPassenger.SaleTypeId;
						model.BspCategoryId = q.TripLineAirPassenger.TripLineAir.TripLine.Trip.CategoryId;
						model.BspDestinationId = q.TripLineAirPassenger.TripLineAir.TripLine.Trip.DestinationId;
						model.BspConsultantId = q.TripLineAirPassenger.TripLineAir.TripLine.Trip.ConsultantId <= 0 ? null : q.TripLineAirPassenger.TripLineAir.TripLine.Trip.ConsultantId;
						model.BspAgentId = q.TripLineAirPassenger.TripLineAir.TripLine.Trip.AgentId;
						model.BspSourceId = q.TripLineAirPassenger.TripLineAir.TripLine.Trip.SourceId;

						model.BspOfferedFare = q.TripLineAirPassenger.OfferedFare;
						model.BspOfferedReasonId = q.TripLineAirPassenger.OfferedReasonId;

						model.BspCommission = q.TripLineAirPassenger.Commission;
						model.BspCommissionTax = 0;
						model.BspDiscount = q.TripLineAirPassenger.Discount;
						model.BspDiscountTax = 0;
						model.BspDiscountReasonId = q.TripLineAirPassenger.DiscountReasonId;
						model.BspMarkup = q.TripLineAirPassenger.Markup;
						model.BspMarkupTax = 0;
						model.BspMarkupStrategyId = q.TripLineAirPassenger.MarkupStrategyId;

						model.BspIsCreditCardDiscountApplicable = q.TripLineAirPassenger.IsCreditCardDiscountApplicable;
						model.BspIncludeMarkupInCreditCardPayment = q.TripLineAirPassenger.IncludeMarkupInCreditCardPayment;

						model.BspTotalNonCommissionable = q.TripLineAirPassenger.NonCommissionable;

						detailModel.BspDetailFormOfPaymentId = q.TripLineAirPassenger.FormOfPaymentId;
						detailModel.BspDetailNonCommissionable = q.TripLineAirPassenger.NonCommissionable;
						detailModel.BspDetailTax = q.TripLineAirPassenger.GetTicketedFareTax(HttpContext.CurrentCustomerId(), model.BspDocumentDate ?? DateTime.Today);

						if (model.BspIsTaxIncluded) {
							detailModel.BspDetailAmount = q.TripLineAirPassenger.TicketedFare;
						}
						else {
							detailModel.BspDetailAmount = q.TripLineAirPassenger.GetTicketedFareNet(HttpContext.CurrentCustomerId(), model.BspDocumentDate ?? DateTime.Today);
						}

						q.Bsp.SaleTypeId = q.TripLineAirPassenger.SaleTypeId;
						sources.Add("SaleTypeId");
						break;
				}

				var rateModel = new RateModel {
					Commission = model.BspCommission,
					CommissionRate = model.BspCommissionRate / 100,
					CommissionTax = model.BspCommissionTax,
					Discount = model.BspDiscount,
					DiscountRate = model.BspDiscountRate / 100,
					DiscountTax = model.BspDiscountTax,
					Markup = model.BspMarkup,
					MarkupRate = model.BspMarkupRate / 100,
					MarkupTax = model.BspMarkupTax,
					NonCommissionableGross = detailModel.BspDetailNonCommissionable,
					IsTaxIncluded = model.BspIsTaxIncluded
				};

				var rates = new AccountingRates<BspDetail>(HttpContext, q, rateModel);
				bool result = rates.SetRates(sources, detailModel.BspDetailAmount, detailModel.BspDetailTax, detailModel.BspDetailId);

				if (result) {
					model.BspCommission = rateModel.CommissionGross;
					model.BspCommissionRate = rateModel.CommissionRate * 100;
					model.BspCommissionTax = rateModel.CommissionTax;
					model.BspCommissionTaxRate = rateModel.CommissionTaxRate * 100;

					model.BspDiscount = rateModel.DiscountGross;
					model.BspDiscountRate = rateModel.DiscountRate * 100;
					model.BspDiscountTax = rateModel.DiscountTax;
					model.BspDiscountTaxRate = rateModel.DiscountTaxRate * 100;

					model.BspMarkup = rateModel.MarkupGross;
					model.BspMarkupRate = rateModel.MarkupRate * 100;
					model.BspMarkupTax = rateModel.MarkupTax;
					model.BspMarkupTaxRate = rateModel.MarkupTaxRate * 100;

					detailModel.BspDetailAmount = rateModel.AmountGross;
					detailModel.BspDetailTax = rateModel.Tax;
					detailModel.BspDetailTaxRate = rateModel.TaxRate * 100;

					if (source == "TripLineId" || source == "TripLineAirPassengerId") {
						if (detailModel.BspDetailAmount == 0) {
							detailModel.BspDetailNonCommissionable = 0;
						}
						else {
							detailModel.BspDetailNonCommissionable = rateModel.NonCommissionable + rateModel.NonCommissionableTax;
						}
					}
				}

				return Json(new { Model = model, DetailModel = detailModel, UpdateRateModel = result });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BspDetail_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region Non-BSP Returns
		public IActionResult NonBspReturns() {
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> NonBsp_Edit(int nonBspId, int tripId, bool isNative) {
			try {
				var lazyContext = LazyContext;
				const bool isTaxIncluded = true;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				var trip = lazyContext.Trip.Find(tripId);
				bool isBooking = trip?.IsBooking ?? false;

				NonBsp q = null;

				if (nonBspId <= 0) {
					q = new NonBsp {
						Id = 0,
						NonBspType = NonBspType.NonBsp,
						DocumentDate = DateTime.Today,
						DepartureDate = DateTime.MinValue,
						CreditorId = 0,
						SupplierId = 0,
						TripId = isBooking ? tripId : 0,
						Trip = isBooking ? trip : new Trip(),
						TripLineId = -1,
						TripLine = new TripLine { Id = -1, TripId = tripId },
						ChartOfAccountId = -1,
						SaleTypeId = 0,
						AirlineId = -1,
						OfferedReasonId = -1,
						SourceId = 0,
						CategoryId = 0,
						DestinationId = 0,
						AgencyId = HttpContext.CurrentDefaultAgencyId(),
						ConsultantId = HttpContext.CurrentConsultantId(),
						AgentId = -1,
						DiscountReasonId = -1,
						MarkupStrategyId = -1,
						PaymentId = -1,
					};
				}
				else {
					q = lazyContext.NonBsp.Find(nonBspId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				int? nonBspCreditorId = 0;
				int? nonBspSupplierId = 0;
				int? nonBspTripId = -1;
				int? nonBspChartOfAccountId = -1;
				int nonBspAirlineId = -1;
				int? nonBspSaleTypeId = 0;
				int? nonBspConsultantId = 0;

				if (q.Id > 0) {
					nonBspCreditorId = q.CreditorId;
					nonBspSupplierId = q.SupplierId;
					nonBspTripId = q.TripId;
					nonBspChartOfAccountId = q.ChartOfAccountId;
					nonBspAirlineId = q.AirlineId;
					nonBspSaleTypeId = q.NonBspType != NonBspType.Admin && q.SaleTypeId <= 0 ? null : q.SaleTypeId;
					nonBspConsultantId = q.ConsultantId <= 0 ? null : q.ConsultantId;
				}
				else {
					switch (q.NonBspType) {
						default:
							if (isNative) {
								nonBspCreditorId = null;
								nonBspSupplierId = null;
								nonBspTripId = null;
								nonBspAirlineId = -1;
							}
							else {
								nonBspCreditorId = q.CreditorId;
								nonBspSupplierId = q.SupplierId;
								nonBspTripId = q.TripId;
								nonBspAirlineId = q.AirlineId;
							}
							break;
						case NonBspType.Admin:
							nonBspChartOfAccountId = null;
							break;
					}

					nonBspSaleTypeId = null;
					nonBspConsultantId = HttpContext.CurrentConsultantId();
				}

				var rateModel = new RateModel {
					Commission = q.Commission,
					CommissionTax = q.CommissionTax,
					Discount = q.Discount,
					DiscountTax = q.DiscountTax,
					Markup = q.Markup,
					MarkupTax = q.MarkupTax,
					IsTaxIncluded = isTaxIncluded,
					IsFormBinding = true
				};

				var rates = new AccountingRates<NonBsp>(HttpContext, q, rateModel);
				rates.SetRates(new List<string> { "Commission", "Discount", "Markup" });

				var model = new NonBspViewModel {
					NonBspId = q.Id,
					NonBspTripLineType = q.TripLine.TripLineType,
					NonBspDocumentStatus = q.DocumentStatus,
					NonBspReversalStatus = q.ReversalStatus,
					NonBspType = q.NonBspType,
					NonBspDocumentNo = q.DocumentNo,
					NonBspDocumentDate = q.DocumentDate,
					NonBspCreditorId = nonBspCreditorId,
					NonBspSupplierId = nonBspSupplierId,
					NonBspTripId = nonBspTripId,
					NonBspChartOfAccountId = nonBspChartOfAccountId,
					NonBspTripLineId = q.TripLineId,
					NonBspAirlineId = nonBspAirlineId,
					NonBspDepartureDateStatus = q.DepartureDate == DateTime.MinValue ? DepartureDateStatus.Open : q.DepartureDate == lazyContext.VoidDate ? DepartureDateStatus.ARNK : DepartureDateStatus.Normal,
					NonBspDepartureDate = q.DepartureDate <= lazyContext.VoidDate ? (DateTime?)null : q.DepartureDate,
					NonBspOfferedFare = q.OfferedFare,
					NonBspOfferedReasonId = q.OfferedReasonId,
					NonBspSaleTypeId = nonBspSaleTypeId,
					NonBspCategoryId = q.CategoryId,
					NonBspDestinationId = q.DestinationId,
					NonBspAgencyId = q.AgencyId,
					NonBspConsultantId = nonBspConsultantId,
					NonBspAgentId = q.AgentId,
					NonBspSourceId = q.SourceId,
					NonBspSupplierCancellationFee = q.SupplierCancellationFee + q.SupplierCancellationFeeTax,
					NonBspTotalNonCommissionable = q.TotalNonCommissionable,
                    NonBspAmountPayable = (q.NonBspType == NonBspType.Refund ? -1 : 1) * q.AmountPayable,
                    NonBspIsCommissionPermitted = q.IsCommissionPermitted,
					NonBspIsDiscountPermitted = q.IsDiscountPermitted,
					NonBspIsMarkupPermitted = q.IsMarkupPermitted,
					NonBspIsCancellationPermitted = q.IsCancellationPermitted,
					NonBspIsTaxIncluded = isTaxIncluded,
					NonBspIsTaxApplicable = q.IsTaxApplicable,
					NonBspIsAutoInvoiced = q.IsAutoInvoiced,
					NonBspIsClientAccountLocked = q.IsClientAccountLocked,
					NonBspCanEdit = q.CanEdit(isSuperUser),
					NonBspCanDelete = q.CanDelete(isSuperUser),
					NonBspCanUndo = q.CanUndo(),
					NonBspCanReverse = q.CanReverse(),
					NonBspCommission = q.Commission + (isTaxIncluded ? q.CommissionTax : 0),
					NonBspCommissionTax = q.CommissionTax,
					NonBspCommissionRate = rateModel.CommissionRate,
					NonBspCommissionTaxRate = rateModel.CommissionTaxRate,
					NonBspDiscount = q.Discount + (isTaxIncluded ? q.DiscountTax : 0),
					NonBspDiscountTax = q.DiscountTax,
					NonBspDiscountRate = rateModel.DiscountRate,
					NonBspDiscountTaxRate = rateModel.DiscountTaxRate,
					NonBspDiscountReasonId = q.DiscountReasonId,
					NonBspIsCreditCardDiscountApplicable = q.IsCreditCardDiscountApplicable,
					NonBspIncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment,
					NonBspMarkup = q.Markup + (isTaxIncluded ? q.MarkupTax : 0),
					NonBspMarkupTax = q.MarkupTax,
					NonBspMarkupRate = rateModel.MarkupRate,
					NonBspMarkupTaxRate = rateModel.MarkupTaxRate,
					NonBspMarkupStrategyId = q.MarkupStrategyId,
					NonBspTotalAmount = q.TotalAmountGross,
					NonBspTotalTax = q.TotalTax,
					NonBspTotalTaxRate = q.TotalTaxRate,
					NonBspComments = q.Comments,
					LastWriteTime = q.LastWriteTime.ToLocalTime(),
					CreationTime = q.CreationTime.ToLocalTime(),
					LastWriteUser = q.LastWriteUser,
					CreationUser = q.CreationUser
				};

				ViewBag.NonBspIsNative = isNative;
				return PartialView("~/Views/Accounting/EditorTemplates/NonBspEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBsp_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> NonBsp_Read([DataSourceRequest] DataSourceRequest request, DateTime? dateFrom, DateTime? dateTo, DateTime? departureDate, int nonBspTypeId, int? documentStatusId,
			int bankAccountId, int? paymentId, decimal? amountFrom, decimal? amountTo, decimal? ticketedFare, decimal? amountPayable, int creditorId, int supplierId, int airlineId, int saleTypeId,
			int categoryId, int sourceId, int agencyId, int consultantId, string account, string passenger, string text, bool isExport, int selectionOptionId, string sortMember = null, string sortDirection = null, int? id = null) {

			try {
				var lazyContext = LazyContext;

				var nonBspStatus = (NonBspStatus?)documentStatusId;
				var selectionOption = (SelectionOption)selectionOptionId;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q1 = lazyContext.NonBsp.Where(t => t.Id > 0);

				if (id != null) {
					q1 = q1.Where(t => t.Id == id);
				}
				else {
					if (dateFrom != null)
						q1 = q1.Where(t => t.DocumentDate >= dateFrom);

					if (dateTo != null) {
						if (nonBspStatus == NonBspStatus.Open && creditorId > 0 && bankAccountId > 0) {
							q1 = q1.Where(t => (t.PaymentId <= 0 && t.DocumentDate <= dateTo) || (t.PaymentId > 0 && t.Payment.ReturnDate <= dateTo));
						}
						else {
							q1 = q1.Where(t => t.DocumentDate <= dateTo);
						}
					}

					if (departureDate != null)
						q1 = q1.Where(t => t.DepartureDate == departureDate);

					if (nonBspTypeId != (int)NonBspType.All)
						q1 = q1.Where(t => (int)t.NonBspType == nonBspTypeId);

					if (nonBspStatus != null) {
						if (nonBspStatus == NonBspStatus.None) {
							q1 = q1.Where(t => t.NonBspDetails.Count == 0);
						}
						else {
							IQueryable<int> nonBspIds = null;

							if (nonBspStatus == NonBspStatus.NoAutoAgencyCc) {
								nonBspIds = NonBsp.GetMissingAutoAgencyCcNonBspIds(lazyContext, agencyId);
							}
							else if (nonBspStatus == NonBspStatus.Reversal || nonBspStatus == NonBspStatus.Reversed) {
								nonBspIds = lazyContext.NonBspDetail.Where(t => t.ReversalStatus == (nonBspStatus == NonBspStatus.Reversal ? ReversalStatus.Reversal : ReversalStatus.Reversed)).Select(t => t.NonBspId).Distinct();
							}
							else {
								nonBspIds = lazyContext.NonBspDetail.Where(t => t.DocumentStatus == (DocumentStatus)nonBspStatus).Select(t => t.NonBspId).Distinct();
							}

							q1 = q1.Where(t => nonBspIds.Contains(t.Id));
						}
					}

					if (nonBspStatus != NonBspStatus.Open && bankAccountId > 0)
						q1 = q1.Where(t => t.Payment.BankAccountId == bankAccountId);

					if (paymentId != null)
						q1 = q1.Where(t => t.PaymentId == paymentId);

					if (amountFrom != null)
						q1 = q1.Where(t1 => (t1.NonBspDetails.Sum(t2 => (decimal?)(t2.Amount + t2.Tax + t2.NonCommissionable + t2.NonCommissionableTax)) ?? 0) >= amountFrom);

					if (amountTo != null)
						q1 = q1.Where(t1 => (t1.NonBspDetails.Sum(t2 => (decimal?)(t2.Amount + t2.Tax + t2.NonCommissionable + t2.NonCommissionableTax)) ?? 0) <= amountTo);

					if (ticketedFare != null)
						q1 = q1.Where(t1 => lazyContext.TripLineAirPassenger.Any(t2 => t2.TripLineId == t1.TripLineId && t2.TicketedFare == ticketedFare));

					if (amountPayable != null)
						q1 = q1.Where(t => t.AmountPayable == amountPayable);

					if (creditorId > 0) {
						q1 = q1.Where(t1 => t1.CreditorId == creditorId && (t1.NonBspType != NonBspType.AgencyCC || t1.NonBspDetails.Any(t2 => t2.FormOfPayment.CreditorId == creditorId)));
					}
					else {
						q1 = q1.Where(t => t.NonBspType != NonBspType.AgencyCC);
					}

					if (supplierId > 0)
						q1 = q1.Where(t => t.SupplierId == supplierId);

					if (airlineId > 0)
						q1 = q1.Where(t => t.AirlineId == airlineId);

					if (saleTypeId > 0)
						q1 = q1.Where(t => t.SaleTypeId == saleTypeId);

					if (categoryId > 0)
						q1 = q1.Where(t => t.CategoryId == categoryId);

					if (sourceId > 0)
						q1 = q1.Where(t => t.SourceId == sourceId);

					if (agencyId > 0)
						q1 = q1.Where(t => t.AgencyId == agencyId);

					if (consultantId > 0)
						q1 = q1.Where(t => t.ConsultantId == consultantId);

					if (!string.IsNullOrEmpty(account)) {
						var predicate = PredicateBuilder.False<NonBsp>();

						foreach (var row in account.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
							predicate = predicate.Or(t => t.Trip.Id.ToString().Contains(row) || (t.Trip.Title + " " + t.Trip.FirstName + " " + t.Trip.LastName).Trim().ToLower().Contains(row) || t.Supplier.Name.ToLower().Contains(row) || t.ChartOfAccount.Code.ToLower().Contains(row) || t.ChartOfAccount.Name.ToLower().Contains(row));
						}

						q1 = q1.Where(predicate);
					}

					if (!string.IsNullOrEmpty(passenger)) {
						var predicate = PredicateBuilder.False<NonBspDetail>();

						foreach (var row in passenger.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
							predicate = predicate.Or(t => (t.Passenger.Title + " " + t.Passenger.FirstName + " " + t.Passenger.LastName).Trim().ToLower().Contains(row));
						}

						var nonBspDetailIds = lazyContext.NonBspDetail.Where(predicate).Select(t => t.Id);
						q1 = q1.Where(t1 => t1.NonBspDetails.Any(t2 => nonBspDetailIds.Contains(t2.Id)));
					}

					if (!string.IsNullOrEmpty(text)) {
						text = text.Trim().ToLower();
						q1 = q1.Where(t => t.DocumentNo.ToLower().Contains(text));
					}

					if (nonBspStatus == NonBspStatus.Open && selectionOption != SelectionOption.All && selectionOption != SelectionOption.MatchZeros) {
						int[] selectedIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionNonBspIds;
						var arrays = selectedIds.Split(2100).ToArray();

						if (selectionOption == SelectionOption.Matched) {
							var predicate = PredicateBuilder.False<NonBsp>();

							foreach (var array in arrays) {
								predicate = predicate.Or(t => array.Contains(t.Id));
							}

							q1 = q1.Where(predicate);
						}
						else {
							foreach (var array in arrays) {
								q1 = q1.Where(t => !array.Contains(t.Id));
							}
						}
					}
				}

				var q2 = q1.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).Select(row => new NonBspViewModel {
					NonBspId = row.Id,
					NonBspAccountName = row.AccountName,
					NonBspAccountNameLink = row.AccountNameLink,
					NonBspDocumentStatus = row.DocumentStatus,
					NonBspReversalStatus = row.ReversalStatus,
					NonBspType = row.NonBspType,
					AgencyCreditCardBspId = row.AgencyCreditCardBspId,
					AgencyCreditCardNonBspId = row.AgencyCreditCardNonBspId,
					NonBspDocumentNo = row.DocumentNo,
					NonBspDocumentDate = row.DocumentDate,
					NonBspCreditorId = row.CreditorId,
					NonBspCreditor = row.Creditor.Name,
					NonBspSupplier = row.Supplier.Name,
					NonBspDepartureDate = row.DepartureDate <= lazyContext.VoidDate ? (DateTime?)null : row.DepartureDate,
					NonBspSaleType = row.SaleTypeId <= 0 ? string.Empty : row.SaleType.Name,
					NonBspCommission = row.Commission + row.CommissionTax,
					NonBspCommissionTax = row.CommissionTax,
					NonBspTotalCash = isExport || nonBspStatus == NonBspStatus.Open || nonBspStatus == NonBspStatus.Paid ? row.NonBspDetails.Where(t => t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.CreditCard && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.TravelCard).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0 : 0,
					NonBspTotalCashNonCommissionable = isExport || nonBspStatus == NonBspStatus.Open || nonBspStatus == NonBspStatus.Paid ? row.NonBspDetails.Where(t => t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.CreditCard && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.TravelCard).Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0 : 0,
					NonBspTotalCreditCard = isExport || nonBspStatus == NonBspStatus.Open || nonBspStatus == NonBspStatus.Paid ? row.NonBspDetails.Where(t => t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.CreditCard || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.TravelCard).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0 : 0,
					NonBspTotalCreditCardNonCommissionable = isExport || nonBspStatus == NonBspStatus.Open || nonBspStatus == NonBspStatus.Paid ? row.NonBspDetails.Where(t => t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.CreditCard || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.TravelCard).Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0 : 0,
					NonBspTotalTax = row.NonBspDetails.Sum(t => (decimal?)t.Tax) ?? 0,
					NonBspTotalAmount = !isExport && (nonBspStatus == NonBspStatus.Open || nonBspStatus == NonBspStatus.Paid) ? 0 : row.NonBspDetails.Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0,
					NonBspAmountPayable = lazyContext.NonBsp.Where(t => (t.Id == row.Id || t.AgencyCreditCardNonBspId == row.Id) && t.CreditorId == row.CreditorId).Sum(t => (decimal?)t.AmountPayable) ?? 0,
					NonBspPaymentDocumentNo = row.Payment.DocumentNo,
					NonBspPaymentDate = row.Payment.DocumentDate,
					NonBspReturnDate = row.Payment.ReturnDate,
					NonBspChildCount = nonBspStatus == NonBspStatus.Open || nonBspStatus == NonBspStatus.Paid ? row.NonBspDetails.Count(t => (t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross) && (creditorId <= 0 || (t.NonBsp.CreditorId == creditorId && t.FormOfPayment.CreditorId != creditorId))) : 0,
					NonBspCanEdit = row.CanEdit(isSuperUser),
					NonBspCanDelete = row.CanDelete(isSuperUser),
					NonBspCanUndo = row.CanUndo(),
					NonBspCanReverse = row.CanReverse(),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				});

				if (id == null) {
					if (nonBspStatus == NonBspStatus.Open && selectionOption == SelectionOption.MatchZeros) {
						int[] selectedIds = AppSettings.Setting(HttpContext.CurrentCustomerId()).GridSelectionBspIds;
						var arrays = selectedIds.Split(2100).ToArray();

						if (selectedIds.Length == 0) {
							q2 = q2.Where(t => t.NonBspAmountPayable == 0);
						}
						else {
							var predicate = PredicateBuilder.False<NonBspViewModel>();

							foreach (var array in arrays) {
								predicate = predicate.Or(t => !array.Contains(t.NonBspId) && t.NonBspAmountPayable == 0);
							}

							q2 = q2.Where(predicate);
						}
					}

					if (isExport) {
						if (!isAdministrator)
							throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

						var export = q2.ApplySorting(null, WebUtils.GetSortDescriptors(sortMember, sortDirection)).ToList().ConvertAll(row => new NonBspExportModel {
							AccountName = row.NonBspAccountName,
							DocumentStatus = row.NonBspDocumentStatus.GetEnumDescription(),
							ReversalStatus = row.NonBspReversalStatus.GetEnumDescription(),
							Type = row.NonBspTypeDescription,
							DocumentNo = row.NonBspDocumentNo,
							DocumentDate = row.NonBspDocumentDate,
							DepartureDate = row.NonBspDepartureDate,
							Creditor = row.NonBspCreditor,
							Supplier = row.NonBspSupplier,
							SaleType = row.NonBspSaleType,
							Commission = row.NonBspCommission,
							CommissionTax = row.NonBspCommissionTax,
							Cash = row.NonBspTotalCash,
							CashNonCommissionable = row.NonBspTotalCashNonCommissionable,
							CreditCard = row.NonBspTotalCreditCard,
							CreditCardNonCommissionable = row.NonBspTotalCreditCardNonCommissionable,
							Tax = row.NonBspTotalTax,
							TotalAmount = row.NonBspTotalAmount,
							AmountPayable = row.NonBspAmountPayable,
							PaymentNo = row.NonBspPaymentDocumentNo,
							PaymentDate = row.NonBspPaymentDate == DateTime.MinValue ? null : row.NonBspPaymentDate,
							ReturnDate = row.NonBspReturnDate == DateTime.MinValue ? null : row.NonBspReturnDate
						});

						var xlsx = new ExportToExcel<NonBspExportModel>(export);
						return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Non-BSP Returns.xlsx");
					}

					if (nonBspStatus == NonBspStatus.Open || nonBspStatus == NonBspStatus.Paid) {
						q2 = q2.AsEnumerable().GroupBy(row => new {
							row.NonBspDocumentNo,
							row.NonBspDocumentDate,
							row.NonBspCreditorId,
							row.NonBspCreditor,
							row.NonBspSupplier
						}).Select(row => new NonBspViewModel {
							NonBspId = row.Min(t => t.NonBspId),
							NonBspAccountName = row.First().NonBspAccountName,
							NonBspAccountNameLink = row.First().NonBspAccountNameLink,
							NonBspType = (NonBspType)row.Min(t => (int)t.NonBspType),
							NonBspDocumentNo = row.Key.NonBspDocumentNo,
							NonBspDocumentDate = row.Key.NonBspDocumentDate,
							NonBspCreditorId = row.Key.NonBspCreditorId,
							NonBspCreditor = row.Key.NonBspCreditor,
							NonBspSupplier = row.Key.NonBspSupplier,
							NonBspCommission = row.Sum(t => t.NonBspCommission),
							NonBspCommissionTax = row.Sum(t => t.NonBspCommissionTax),
							NonBspTotalCash = row.Sum(t => t.NonBspTotalCash),
							NonBspTotalCashNonCommissionable = row.Sum(t => t.NonBspTotalCashNonCommissionable),
							NonBspTotalCreditCard = row.Sum(t => t.NonBspTotalCreditCard),
							NonBspTotalCreditCardNonCommissionable = row.Sum(t => t.NonBspTotalCreditCardNonCommissionable),
							NonBspTotalTax = row.Sum(t => t.NonBspTotalTax),
							NonBspTotalAmount = row.Sum(t => t.NonBspTotalAmount),
							NonBspAmountPayable = row.Sum(t => t.NonBspAmountPayable),
							NonBspHasChildren = row.Sum(t => t.NonBspChildCount) > 0,
							LastWriteTime = row.First().LastWriteTime,
							CreationTime = row.First().CreationTime,
							LastWriteUser = row.First().LastWriteUser,
							CreationUser = row.First().CreationUser
						}).AsQueryable();
					}
				}

				int[] gridIds = null;
				decimal totalAmountPayable = 0;

				if (nonBspStatus == NonBspStatus.Open) {
					gridIds = q2.Select(t => t.NonBspId).ToArray();
					totalAmountPayable = q2.Sum(t => (decimal?)t.NonBspAmountPayable) ?? 0;
				}

				var aggregateResults = new List<AggregateResult> {
					new AggregateResult(gridIds, new MinFunction { FunctionName = "Min", SourceField = "GridIds", MemberType = typeof(int[]) }),
					new AggregateResult(totalAmountPayable, new SumFunction { FunctionName = "Sum", SourceField = "NonBspAmountPayable", MemberType = typeof(decimal) })
				};

				int total = q2.Count();
				q2 = q2.ApplySorting(request.Groups, request.Sorts).ApplyPaging(request.Page, request.PageSize);

				var result = await Task.Run(() => new DataSourceResult {
					Data = q2,
					Total = total,
					AggregateResults = aggregateResults
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBsp_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		public async Task<IActionResult> NonBspLinkedDocument_Read([DataSourceRequest] DataSourceRequest request, int nonBspId, int documentStatusId, int creditorId) {
			try {
				var lazyContext = LazyContext;

				var q = lazyContext.NonBsp.Where(t => t.AgencyCreditCardNonBspId == nonBspId);
				var nonBspStatus = (NonBspStatus)documentStatusId;

				if ((nonBspStatus == NonBspStatus.Open || nonBspStatus == NonBspStatus.Paid) && creditorId > 0)
					q = q.Where(t => t.CreditorId == creditorId);

				var result = await q.OrderBy(t => t.Id).Select(row => new NonBspViewModel {
					NonBspId = row.Id,
					NonBspCreditor = row.Creditor.Name,
					NonBspType = row.NonBspType,
					NonBspDocumentNo = row.DocumentNo,
					NonBspDocumentDate = row.DocumentDate,
					NonBspSaleType = row.SaleTypeId <= 0 ? string.Empty : row.SaleType.Name,
					NonBspFormOfPayment = row.NonBspDetails.First().FormOfPayment.Name,
					NonBspTotalAmount = row.TotalAmountGross,
					NonBspTotalTax = row.TotalTax,
					NonBspAmountPayable = row.AmountPayable,
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBspLinkedDocument_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> NonBsp_CreateOrUpdate(NonBspViewModel model, bool isNew) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				if (!Context.NonBsp.Any(t => t.Id == model.NonBspId))
					throw new UnreportedException(AppConstants.RecordCannotBeCreated);

				new NonBspCommon(HttpContext).CreateOrUpdate(model, true, !isNew, !isNew, !isNew);
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBsp_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> NonBspWithDetail_CreateOrUpdate(NonBspViewModel model, NonBspDetailViewModel detailModel, bool isNew) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				var context = Context;

				new NonBspDetailCommon(HttpContext).CreateOrUpdate(model, detailModel, isNew);
				var q = context.NonBsp.Find(model.NonBspId);

				model.NonBspTotalAmount = q.TotalAmountGross;
				model.NonBspTotalTax = q.TotalTax;
				model.NonBspTotalTaxRate = q.TotalTaxRate * 100;
				model.NonBspTotalNonCommissionable = q.TotalNonCommissionable;
				model.NonBspAmountPayable = q.GetAmountPayable(context);

				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBspWithDetail_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> NonBsp_Delete([DataSourceRequest] DataSourceRequest request, NonBspViewModel model) {
			try {
				new NonBspCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBsp_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> NonBsp_UpdateModel(NonBspViewModel model, string source, decimal unsavedAmount, decimal unsavedTax, int detailId) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.NonBsp.Find(model.NonBspId <= 0 ? -1 : model.NonBspId);

				int chartOfAccountId = q.ChartOfAccountId;
				int saleTypeId = q.SaleTypeId;
				bool isTaxApplicable = q.IsTaxApplicable;
                decimal nonCommissionable = 0;

                q.NonBspType = model.NonBspType;
				q.DocumentDate = model.NonBspDocumentDate ?? DateTime.Today;
				q.TripId = model.NonBspTripId ?? -1;
				q.TripLineId = model.NonBspTripLineId ?? -1;
				q.CreditorId = model.NonBspCreditorId ?? -1;
				q.ChartOfAccountId = model.NonBspChartOfAccountId ?? -1;
				q.SupplierId = model.NonBspSupplierId ?? -1;
				q.SaleTypeId = model.NonBspSaleTypeId ?? -1;
				q.AgencyId = model.NonBspAgencyId;
				q.ConsultantId = model.NonBspConsultantId ?? -1;
				q.SupplierCancellationFee = model.NonBspSupplierCancellationFee;
				q.SupplierCancellationFeeTax = 0;
				q.Commission = model.NonBspCommission;
				q.CommissionTax = model.NonBspCommissionTax;
				q.Discount = model.NonBspDiscount;
				q.DiscountTax = model.NonBspDiscountTax;
				q.Markup = model.NonBspMarkup;
				q.MarkupTax = model.NonBspMarkupTax;
				q.IsCreditCardDiscountApplicable = model.NonBspIsCreditCardDiscountApplicable;
				q.IncludeMarkupInCreditCardPayment = model.NonBspIncludeMarkupInCreditCardPayment;

				model.NonBspIsClientAccountLocked = q.IsClientAccountLocked;

				bool updateRateModel = true;
				bool updateDetailModel = true;
				bool documentNoChanged = false;
				string message = string.Empty;
				int formOfPaymentId = -1;

				if (model.NonBspId > 0) {
					switch (source) {
						case "ChartOfAccountId":
						case "SaleTypeId":
							if (!q.ValidateTaxApplicability(isTaxApplicable)) {
								if (source == "ChartOfAccountId") {
									model.NonBspChartOfAccountId = chartOfAccountId;
								}
								else {
									model.NonBspSaleTypeId = saleTypeId;
								}

								message = AppConstants.TaxRelatedRecordCannotBeAltered;
							}

							break;
					}

					if (!string.IsNullOrEmpty(message))
						return Json(new { Model = model, Message = message });
				}

				List<string> sources = null;

				if (source == "DeleteDetail") {
					sources = new List<string> { "CommissionRate", "DiscountRate", "MarkupRate" };
				}
				else {
					sources = new List<string> { source };
				}

				switch (source) {
					case "CreditorId":
						model.NonBspIncludeMarkupInCreditCardPayment = q.Creditor.IncludeMarkupInCreditCardPayment;
						break;
					case "SaleTypeId":
						model.NonBspIsCreditCardDiscountApplicable = q.SaleType.IsCreditCardDiscountApplicable;
						break;
					case "NonBspType":
						model.NonBspIsCommissionPermitted = q.IsCommissionPermitted;
						model.NonBspIsDiscountPermitted = q.IsDiscountPermitted;
						model.NonBspIsMarkupPermitted = q.IsMarkupPermitted;
						model.NonBspIsCancellationPermitted = q.IsCancellationPermitted;
						break;
					case "DocumentNo":
						string documentNo = model.NonBspDocumentNo;
						model.NonBspDocumentNo = NonBsp.GetUniqueDocumentNo(Context, model.NonBspType, model.NonBspId, documentNo);
						documentNoChanged = !string.IsNullOrEmpty(documentNo) && model.NonBspDocumentNo != documentNo;
						break;
					case "ChartOfAccountId":
						if (q.ChartOfAccountId > 0 && Setting.IsControlAccount(HttpContext.CurrentCustomerId(), q.DocumentDate, q.ChartOfAccountId)) {
							if (HttpContext.IsAdministrator()) {
								message = AppConstants.GlControlAccountUpdate;
							}
							else {
								message = AppConstants.GlControlAccountWarning;
							}
						}

						break;
					case "TripId":
						if (q.Trip == null) {
							updateRateModel = false;
							break;
						}

						if (q.Trip.TripLines != null) {
							var tripLines = q.Trip.TripLines.Where(t => t.TripLineType == TripLineType.Air && t.TripLineAir.DepartureDate > AppConstants.VoidDate).ToList();

							if (tripLines.Count > 0)
								model.NonBspDepartureDate = tripLines.Min(t => t.TripLineAir.DepartureDate);
						}

						model.NonBspDepartureDate = q.Trip.DepartureDate;
						model.NonBspSourceId = q.Trip.SourceId;
						model.NonBspCategoryId = q.Trip.CategoryId;
						model.NonBspDestinationId = q.Trip.DestinationId;
						model.NonBspConsultantId = q.Trip.ConsultantId <= 0 ? HttpContext.CurrentConsultantId() : q.Trip.ConsultantId;
						model.NonBspAgentId = q.Trip.AgentId;
						break;
					case "TripLineId":
						if (q.TripLine == null || q.TripLineId <= 0 || q.TripLine.TripLineType == TripLineType.ServiceFee) {
							updateRateModel = false;
							break;
						}

                        bool isRefund = q.TripLine.TripLineType == TripLineType.Air && q.TripLine.TripLineAir.TripLineAirPassengers.Any(t => t.BspEntryType == BspEntryType.Refund);
                        bool isNotRefund = q.TripLine.TripLineType == TripLineType.Air && q.TripLine.TripLineAir.TripLineAirPassengers.Any(t => t.BspEntryType != BspEntryType.Refund);

                        if (isRefund && isNotRefund) {
                            updateRateModel = false;
                            break;
                        }

                        int sign = isRefund ? -1 : 1;

						model.NonBspTripLineType = q.TripLine.TripLineType;
						model.NonBspDocumentNo = q.TripLine.DocumentNo;
						model.NonBspDepartureDate = q.TripLine.StartDate > AppConstants.VoidDate ? q.TripLine.StartDate : DateTime.MinValue;
						model.NonBspAirlineId = q.TripLine.TripLineAir?.AirlineId ?? -1;
						model.NonBspCreditorId = q.TripLine.Creditor.Id;
						model.NonBspSupplierId = q.TripLine.Supplier.Id;
						model.NonBspSaleTypeId = q.TripLine.SaleType.Id;

						model.NonBspOfferedFare = q.TripLine.OfferedFare ?? 0;
						model.NonBspOfferedReasonId = q.TripLine.OfferedReason.Id;

						model.NonBspCommission = sign * q.TripLine.Commission;
						model.NonBspCommissionTax = 0;
						model.NonBspDiscount = sign * q.TripLine.Discount;
						model.NonBspDiscountTax = 0;
						model.NonBspDiscountReasonId = q.TripLine.DiscountReason.Id;
						model.NonBspMarkup = sign * q.TripLine.Markup;
						model.NonBspMarkupTax = 0;
						model.NonBspMarkupStrategyId = q.TripLine.MarkupStrategy.Id;

						model.NonBspIsCreditCardDiscountApplicable = q.TripLine.IsCreditCardDiscountApplicable;
						model.NonBspIncludeMarkupInCreditCardPayment = q.TripLine.IncludeMarkupInCreditCardPayment;

						model.NonBspTotalNonCommissionable = sign * q.TripLine.NonCommissionable;

						q.SaleTypeId = q.TripLine.SaleType.Id;
						q.Commission = sign * q.TripLine.Commission;
						q.CommissionTax = 0;
						q.Discount = sign * q.TripLine.Discount;
						q.DiscountTax = 0;
						q.Markup = sign * q.TripLine.Markup;
						q.MarkupTax = 0;

						formOfPaymentId = q.TripLine.FormOfPayment.Id;
                        nonCommissionable = sign * q.TripLine.GetNonCommissionableDue(lazyContext);
                        unsavedAmount = sign * q.TripLine.GetAmountPayableDue(lazyContext, HttpContext.CurrentCustomerId()) - nonCommissionable;
						unsavedTax = 0;

						sources.Add("Commission");
						sources.Add("Discount");
						sources.Add("Markup");
						break;
					case "Commission":
					case "CommissionRate":
					case "CommissionTax":
					case "Discount":
					case "DiscountRate":
					case "Markup":
					case "MarkupRate":
						updateDetailModel = false;
						break;
				}

				model.NonBspDepartureDateStatus = model.NonBspDepartureDate == DateTime.MinValue ? DepartureDateStatus.Open : model.NonBspDepartureDate == AppConstants.VoidDate ? DepartureDateStatus.ARNK : DepartureDateStatus.Normal;
				model.NonBspIsTaxApplicable = q.IsTaxApplicable;

				var rateModel = new RateModel {
					Commission = q.Commission,
					CommissionRate = model.NonBspCommissionRate / 100,
					CommissionTax = q.CommissionTax,
					Discount = q.Discount,
					DiscountRate = model.NonBspDiscountRate / 100,
					DiscountTax = q.DiscountTax,
					Markup = q.Markup,
					MarkupRate = model.NonBspMarkupRate / 100,
					MarkupTax = q.MarkupTax,
					IsTaxIncluded = model.NonBspIsTaxIncluded
				};

				if (updateRateModel) {
					var rates = new AccountingRates<NonBsp>(HttpContext, q, rateModel);
					bool result = rates.SetRates(sources, unsavedAmount, unsavedTax, detailId);

					if (result || source == "DeleteDetail") {
						model.NonBspCommission = rateModel.CommissionGross;
						model.NonBspCommissionRate = rateModel.CommissionRate * 100;
						model.NonBspCommissionTax = rateModel.CommissionTax;
						model.NonBspCommissionTaxRate = rateModel.CommissionTaxRate * 100;

						model.NonBspDiscount = rateModel.DiscountGross;
						model.NonBspDiscountRate = rateModel.DiscountRate * 100;
						model.NonBspDiscountTax = rateModel.DiscountTax;
						model.NonBspDiscountTaxRate = rateModel.DiscountTaxRate * 100;

						model.NonBspMarkup = rateModel.MarkupGross;
						model.NonBspMarkupRate = rateModel.MarkupRate * 100;
						model.NonBspMarkupTax = rateModel.MarkupTax;
						model.NonBspMarkupTaxRate = rateModel.MarkupTaxRate * 100;
					}
					else {
						updateDetailModel = false;
					}
				}
				else {
					updateDetailModel = false;
				}

				if (source == "DeleteDetail") {
					model.NonBspCommission = Math.Round(q.TotalAmountGross * model.NonBspCommissionRate / 100, 2);
					model.NonBspDiscount = Math.Round(q.TotalAmountGross * model.NonBspDiscountRate / 100, 2);
					model.NonBspMarkup = Math.Round(q.TotalAmountGross * model.NonBspMarkupRate / 100, 2);
					new NonBspCommon(HttpContext).CreateOrUpdate(model, false);
				}

				return Json(new { Model = model, DetailModel = new { FormOfPaymentId = formOfPaymentId, Amount = rateModel.AmountGross, NonCommissionable = nonCommissionable, rateModel.Tax, TaxRate = rateModel.TaxRate * 100 }, UpdateDetailModel = updateDetailModel, DocumentNoChanged = documentNoChanged, Message = message });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBsp_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> NonBsp_ProcessSelections(int[] nonBspIds, int documentStatusId, int bankAccountId, string documentNo, DateTime documentDate, DateTime returnDate, bool undo) {
			try {
				if (nonBspIds == null || nonBspIds.Length == 0)
					throw new UnreportedException("No documents have been selected.");

				bool result = new NonBspCommon(HttpContext).ProcessSelections(LazyContext, nonBspIds, documentStatusId, bankAccountId, documentNo, documentDate, returnDate, undo);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBsp_ProcessSelections", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> NonBsp_Undo(int id, bool isDetailView) {
			try {
				bool result = new NonBspCommon(HttpContext).Undo(LazyContext, id, isDetailView);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBsp_Undo", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> NonBsp_Reverse(int nonBspId, string type) {
			try {
				bool result = new NonBspCommon(HttpContext).Reverse(LazyContext, nonBspId, type);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBsp_Reverse", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> NonBspDetail_Edit(int nonBspId, int nonBspDetailId, NonBspType nonBspType, bool isTaxIncluded) {
			try {
				if (nonBspDetailId == -1) {
					ViewBag.NonBspDetailNonBspType = nonBspType;
					return PartialView("~/Views/Accounting/EditorTemplates/NonBspDetailEdit.cshtml");
				}

				var lazyContext = LazyContext;
				NonBspDetail q = null;

				if (nonBspDetailId == 0) {
					q = new NonBspDetail {
						Id = 0,
						NonBspId = nonBspId,
						DocumentStatus = DocumentStatus.Open,
						ReversalStatus = ReversalStatus.None,
						TripLineAirPassengerId = -1,
						PassengerId = -1,
						FormOfPaymentId = -1,
						NonBsp = lazyContext.NonBsp.Find(nonBspId) ?? new NonBsp {
							Id = nonBspId,
							NonBspType = nonBspType,
							CreditorId = -1,
							Creditor = new Creditor { Id = -1 }
						}
					};

					q.IsTaxApplicable = q.NonBsp.IsTaxApplicable;
				}
				else {
					q = lazyContext.NonBspDetail.Find(nonBspDetailId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				var rateModel = new RateModel {
					Commission = q.NonBsp.Commission,
					CommissionTax = q.NonBsp.CommissionTax,
					Discount = q.NonBsp.Discount,
					DiscountTax = q.NonBsp.DiscountTax,
					Markup = q.NonBsp.Markup,
					MarkupTax = q.NonBsp.MarkupTax,
					IsTaxIncluded = isTaxIncluded,
					IsFormBinding = true,
					IsTaxApplicableOverride = q.IsTaxApplicable
				};

				var rates = new AccountingRates<NonBspDetail>(HttpContext, q, rateModel);
				rates.SetRates(new List<string> { "Tax" });

				var model = new NonBspDetailViewModel {
					NonBspDetailId = q.Id,
					NonBspId = q.NonBspId,
					NonBspDetailNonBspType = q.NonBsp.NonBspType,
					NonBspDetailDocumentStatus = q.DocumentStatus,
					NonBspDetailReversalStatus = q.ReversalStatus,
					NonBspDetailTripLineAirPassengerId = q.TripLineAirPassengerId,
					NonBspDetailPassengerId = q.PassengerId,
					NonBspDetailFormOfPaymentId = q.FormOfPaymentId,
					NonBspDetailAmount = isTaxIncluded ? q.Amount + q.Tax : q.Amount,
					NonBspDetailTax = q.Tax,
					NonBspDetailTaxRate = rateModel.TaxRate,
					NonBspDetailNonCommissionable = q.NonCommissionableGross,
					NonBspDetailIsTaxApplicable = q.IsTaxApplicable,
					NonBspDetailIsBspAgent = q.NonBsp.Creditor.IsBspAgent
				};

				return PartialView("~/Views/Accounting/EditorTemplates/NonBspDetailGridEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBspDetail_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> NonBspDetail_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
			try {
				const bool isTaxIncluded = true;

				var lazyContext = LazyContext;
				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q = lazyContext.NonBspDetail.Where(t => t.NonBspId == parentId);

				var result = await q.Select(row => new NonBspDetailViewModel {
					NonBspDetailId = row.Id,
					NonBspId = row.NonBspId,
					NonBspDetailDocumentStatus = row.DocumentStatus,
					NonBspDetailReversalStatus = row.ReversalStatus,
					NonBspDetailNonBspType = row.NonBsp.NonBspType,
					NonBspDetailTripLineAirPassengerId = row.TripLineAirPassengerId,
					NonBspDetailPassengerId = row.PassengerId,
					NonBspDetailPassenger = row.TripLineAirPassengerId <= 0 && row.PassengerId <= 0 ? string.Empty : row.TripLineAirPassengerId > 0 ? row.TripLineAirPassenger.Passenger.FullName : row.Passenger.FullName,
					NonBspDetailFormOfPaymentId = row.FormOfPaymentId,
					NonBspDetailFormOfPayment = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.PaySupplierDescription,
					NonBspDetailPaymentLink = row.NonBsp.PaymentId <= 0 ? string.Empty : row.NonBsp.PaymentLink,
					NonBspDetailPaymentDate = row.NonBsp.Payment.DocumentDate == DateTime.MinValue ? null : row.NonBsp.Payment.DocumentDate,
					NonBspDetailAmount = isTaxIncluded ? row.Amount + row.Tax : row.Amount,
					NonBspDetailTax = row.Tax,
					NonBspDetailNonCommissionable = row.NonCommissionableGross,
					NonBspDetailCanEdit = row.CanEdit(isSuperUser),
					NonBspDetailCanDelete = row.CanDelete(isSuperUser),
					NonBspDetailCanUndo = row.CanUndo(),
					NonBspDetailCanReverse = row.CanReverse(),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBspDetail_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> NonBspDetail_Delete([DataSourceRequest] DataSourceRequest request, NonBspDetailViewModel model) {
			try {
				new NonBspDetailCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBspDetail_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> NonBspDetail_UpdateModel(NonBspViewModel model, NonBspDetailViewModel detailModel, string source) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.NonBspDetail.Find(detailModel.NonBspDetailId <= 0 ? -1 : detailModel.NonBspDetailId);

				q.NonBspId = model.NonBspId;
				q.TripLineAirPassengerId = detailModel.NonBspDetailTripLineAirPassengerId ?? -1;
				q.Amount = detailModel.NonBspDetailAmount;
				q.Tax = detailModel.NonBspDetailTax;
				q.NonCommissionable = detailModel.NonBspDetailNonCommissionable;
				q.IsTaxApplicable = detailModel.NonBspDetailIsTaxApplicable;

				q.NonBsp ??= lazyContext.NonBsp.Find(model.NonBspId <= 0 ? -1 : model.NonBspId);

				q.NonBsp.NonBspType = model.NonBspType;
				q.NonBsp.DocumentNo = model.NonBspDocumentNo;
				q.NonBsp.DocumentDate = model.NonBspDocumentDate ?? DateTime.Today;
				q.NonBsp.TripId = model.NonBspTripId ?? -1;
				q.NonBsp.TripLineId = model.NonBspTripLineId ?? -1;
				q.NonBsp.CreditorId = model.NonBspCreditorId ?? -1;
				q.NonBsp.ChartOfAccountId = model.NonBspChartOfAccountId ?? -1;
				q.NonBsp.SupplierId = model.NonBspSupplierId ?? -1;
				q.NonBsp.SaleTypeId = model.NonBspSaleTypeId ?? -1;
				q.NonBsp.AgencyId = model.NonBspAgencyId;
				q.NonBsp.ConsultantId = model.NonBspConsultantId ?? -1;
				q.NonBsp.SupplierCancellationFee = model.NonBspSupplierCancellationFee;
				q.NonBsp.Commission = model.NonBspCommission;
				q.NonBsp.CommissionTax = model.NonBspCommissionTax;
				q.NonBsp.Discount = model.NonBspDiscount;
				q.NonBsp.DiscountTax = model.NonBspDiscountTax;
				q.NonBsp.Markup = model.NonBspMarkup;
				q.NonBsp.MarkupTax = model.NonBspMarkupTax;

				model.NonBspIsClientAccountLocked = q.NonBsp.IsClientAccountLocked;
				var sources = new List<string> { source };

				switch (source) {
					case "CreditorId":
						detailModel.NonBspDetailIsBspAgent = q.NonBsp.Creditor?.IsBspAgent ?? false;
						break;
					case "TripLineId":
						if (q.NonBsp.TripLine == null || q.NonBsp.TripLineId <= 0)
							break;

						detailModel.NonBspDetailFormOfPaymentId = q.NonBsp.TripLine.FormOfPayment.Id;
						detailModel.NonBspDetailAmount = q.NonBsp.TripLine.AmountPayable - q.NonBsp.TripLine.NonCommissionable;
						detailModel.NonBspDetailTax = 0;
						detailModel.NonBspDetailNonCommissionable = q.NonBsp.TripLine.NonCommissionable;
						sources.Add("Amount");
						break;
					case "TripLineAirPassengerId":
						if (lazyContext.NonBspDetail.Any(t => t.Id != detailModel.NonBspDetailId && t.NonBspId == model.NonBspId && t.TripLineAirPassengerId != detailModel.NonBspDetailTripLineAirPassengerId && detailModel.NonBspDetailTripLineAirPassengerId > 0))
							throw new UnreportedException(AppConstants.SqlDuplicateAirPassengerException);

						if (q.TripLineAirPassenger == null || q.TripLineAirPassengerId <= 0)
							break;

						model.NonBspIsTaxIncluded = true;
						model.NonBspDocumentNo = q.TripLineAirPassenger.TicketNo;
						model.NonBspDocumentDate = q.TripLineAirPassenger.IssueDate == DateTime.MinValue ? DateTime.Today : q.TripLineAirPassenger.IssueDate;
						model.NonBspAirlineId = q.TripLineAirPassenger.AirlineId;
						model.NonBspCreditorId = q.TripLineAirPassenger.Creditor.Id;
						model.NonBspSupplierId = q.TripLineAirPassenger.Supplier.Id;
						model.NonBspSaleTypeId = q.TripLineAirPassenger.SaleTypeId;

						model.NonBspOfferedFare = q.TripLineAirPassenger.OfferedFare;
						model.NonBspOfferedReasonId = q.TripLineAirPassenger.OfferedReasonId;

						model.NonBspCommission = q.TripLineAirPassenger.Commission;
						model.NonBspCommissionTax = 0;
						model.NonBspDiscount = q.TripLineAirPassenger.Discount;
						model.NonBspDiscountTax = 0;
						model.NonBspDiscountReasonId = q.TripLineAirPassenger.DiscountReasonId;
						model.NonBspMarkup = q.TripLineAirPassenger.Markup;
						model.NonBspMarkupTax = 0;
						model.NonBspMarkupStrategyId = q.TripLineAirPassenger.MarkupStrategyId;

						model.NonBspIsCreditCardDiscountApplicable = q.TripLineAirPassenger.IsCreditCardDiscountApplicable;
						model.NonBspIncludeMarkupInCreditCardPayment = q.TripLineAirPassenger.IncludeMarkupInCreditCardPayment;

						model.NonBspTotalNonCommissionable = q.TripLineAirPassenger.NonCommissionable;

						detailModel.NonBspDetailFormOfPaymentId = q.TripLineAirPassenger.FormOfPaymentId;
						detailModel.NonBspDetailNonCommissionable = q.TripLineAirPassenger.NonCommissionable;
						detailModel.NonBspDetailTax = q.TripLineAirPassenger.GetTicketedFareTax(HttpContext.CurrentCustomerId(), model.NonBspDocumentDate ?? DateTime.Today);

						if (model.NonBspIsTaxIncluded) {
							detailModel.NonBspDetailAmount = q.TripLineAirPassenger.TicketedFare;
						}
						else {
							detailModel.NonBspDetailAmount = q.TripLineAirPassenger.GetTicketedFareNet(HttpContext.CurrentCustomerId(), model.NonBspDocumentDate ?? DateTime.Today);
						}

						q.NonBsp.SaleTypeId = q.TripLineAirPassenger.SaleTypeId;
						sources.Add("SaleTypeId");
						break;
				}

				if (model.NonBspType == NonBspType.Admin) {
					detailModel.NonBspDetailIsTaxApplicable = q.IsTaxApplicable;
				}
				else {
					detailModel.NonBspDetailIsTaxApplicable = q.NonBsp.IsTaxApplicable;
				}

				var rateModel = new RateModel {
					Commission = model.NonBspCommission,
					CommissionRate = model.NonBspCommissionRate / 100,
					CommissionTax = model.NonBspCommissionTax,
					Discount = model.NonBspDiscount,
					DiscountRate = model.NonBspDiscountRate / 100,
					DiscountTax = model.NonBspDiscountTax,
					Markup = model.NonBspMarkup,
					MarkupRate = model.NonBspMarkupRate / 100,
					MarkupTax = model.NonBspMarkupTax,
					NonCommissionableGross = detailModel.NonBspDetailNonCommissionable,
					IsTaxIncluded = model.NonBspIsTaxIncluded,
					IsTaxApplicableOverride = detailModel.NonBspDetailIsTaxApplicable
				};

				var rates = new AccountingRates<NonBspDetail>(HttpContext, q, rateModel);
				bool result = rates.SetRates(sources, detailModel.NonBspDetailAmount, detailModel.NonBspDetailTax, detailModel.NonBspDetailId);

				if (result) {
					model.NonBspCommission = rateModel.CommissionGross;
					model.NonBspCommissionRate = rateModel.CommissionRate * 100;
					model.NonBspCommissionTax = rateModel.CommissionTax;
					model.NonBspCommissionTaxRate = rateModel.CommissionTaxRate * 100;

					model.NonBspDiscount = rateModel.DiscountGross;
					model.NonBspDiscountRate = rateModel.DiscountRate * 100;
					model.NonBspDiscountTax = rateModel.DiscountTax;
					model.NonBspDiscountTaxRate = rateModel.DiscountTaxRate * 100;

					model.NonBspMarkup = rateModel.MarkupGross;
					model.NonBspMarkupRate = rateModel.MarkupRate * 100;
					model.NonBspMarkupTax = rateModel.MarkupTax;
					model.NonBspMarkupTaxRate = rateModel.MarkupTaxRate * 100;

					detailModel.NonBspDetailAmount = rateModel.AmountGross;
					detailModel.NonBspDetailTax = rateModel.Tax;
					detailModel.NonBspDetailTaxRate = rateModel.TaxRate * 100;

					if (source == "TripLineId" || source == "TripLineAirPassengerId") {
						if (detailModel.NonBspDetailAmount == 0) {
							detailModel.NonBspDetailNonCommissionable = 0;
						}
						else {
							detailModel.NonBspDetailNonCommissionable = rateModel.NonCommissionable + rateModel.NonCommissionableTax;
						}
					}
				}

				return Json(new { Model = model, DetailModel = detailModel, UpdateRateModel = result });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "NonBspDetail_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region Payments
		public IActionResult Payments() {
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Payment_Edit(int paymentId, int tripId, int paymentTypeId, bool isNative) {
			try {
				var lazyContext = LazyContext;
				const bool isTaxIncluded = true;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isAccounts = HttpContext.IsAccounts();
				bool isSuperUser = HttpContext.IsSuperUser();

				var trip = lazyContext.Trip.Find(tripId);
				bool isBooking = trip?.IsBooking ?? false;

				Payment q = null;

				if (paymentId <= 0) {
					var paymentType = (PaymentType)paymentTypeId;

					q = new Payment {
						Id = 0,
						PaymentType = paymentType,
						DocumentDate = DateTime.Today,
						ReturnDate = DateTime.MinValue,
						TripId = isBooking ? tripId : 0,
						Trip = isBooking ? trip : new Trip(),
						BankAccountId = paymentType == PaymentType.Admin ? HttpContext.AdminBankAccountId() : HttpContext.TravelBankAccountId(),
						SaleTypeId = paymentType == PaymentType.SupplierPayment ? 0 : -1,
						SourceId = paymentType == PaymentType.SupplierPayment ? 0 : -1,
						CategoryId = paymentType == PaymentType.SupplierPayment ? 0 : -1,
						AgencyId = HttpContext.CurrentDefaultAgencyId(),
						ConsultantId = HttpContext.CurrentConsultantId(),
						AirlineId = -1,
						DiscountReasonId = -1,
						MarkupStrategyId = -1
					};
				}
				else {
					q = lazyContext.Payment.Find(paymentId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				int? paymentTripId = -1;
				int? paymentDebtorId = 0;
				int? paymentCreditorId = 0;
				int? paymentSupplierId = 0;
				int? paymentChartOfAccountId = -1;
				int? paymentSaleTypeId = 0;

				if (q.Id > 0) {
					paymentTripId = q.TripId;
					paymentDebtorId = q.DebtorId;
					paymentCreditorId = q.CreditorId;
					paymentSupplierId = q.SupplierId;
					paymentChartOfAccountId = q.ChartOfAccountId;
					paymentSaleTypeId = q.PaymentType == PaymentType.SupplierPayment && q.SaleTypeId <= 0 ? null : q.SaleTypeId;
				}
				else {
					switch (q.PaymentType) {
						case PaymentType.SupplierPayment:
							if (isNative) {
								paymentTripId = null;
							}
							else {
								paymentTripId = q.TripId;
							}

							paymentCreditorId = null;
							paymentSupplierId = null;
							paymentSaleTypeId = null;

							break;
						case PaymentType.ClientRefund:
							if (isNative) {
								paymentTripId = null;
							}
							else {
								paymentTripId = q.TripId;
							}

							paymentSaleTypeId = -1;
							break;
					}
				}

				var rateModel = new RateModel {
					Commission = q.Commission,
					CommissionTax = q.CommissionTax,
					Discount = q.Discount,
					DiscountTax = q.DiscountTax,
					Markup = q.Markup,
					MarkupTax = q.MarkupTax,
					IsTaxIncluded = isTaxIncluded,
					IsFormBinding = true
				};

				var rates = new AccountingRates<Payment>(HttpContext, q, rateModel);
				rates.SetRates(new List<string> { "Commission", "Discount", "Markup" });

				var model = new PaymentViewModel {
					PaymentId = q.Id,
					PaymentDocumentStatus = q.DocumentStatus,
					PaymentReversalStatus = q.ReversalStatus,
					PaymentType = q.PaymentType,
					PaymentDocumentNo = q.DocumentNo,
					PaymentDocumentDate = q.DocumentDate,
                    PaymentAccountType = q.Id <= 0 && q.PaymentType == PaymentType.Admin ? AccountType.GeneralLedger : q.AccountType,
                    PaymentTripId = paymentTripId,
					PaymentDebtorId = paymentDebtorId,
					PaymentCreditorId = paymentCreditorId,
					PaymentSupplierId = paymentSupplierId,
					PaymentChartOfAccountId = paymentChartOfAccountId,
					PaymentBankAccountId = q.DocumentStatus == DocumentStatus.Open && q.Id <= 0 && q.BankAccountId == -1 ? null : q.BankAccountId,
					PaymentBankAccountStatementName = q.Id > 0 && q.PaymentDetails.Count > 0 ? q.PaymentDetails.First().BankAccountStatement.Name : "None",
					PaymentPayee = q.Payee,
					PaymentSaleTypeId = paymentSaleTypeId,
					PaymentCategoryId = q.CategoryId,
					PaymentAgencyId = q.AgencyId,
					PaymentConsultantId = q.ConsultantId,
					PaymentSourceId = q.SourceId,
					PaymentAirlineId = q.AirlineId,
					PaymentTotalNonCommissionable = q.TotalNonCommissionable,
					PaymentAmountPayable = q.AmountPayable + q.AmountPayableTax,
					PaymentAmountPayableTax = q.AmountPayableTax,
					PaymentDocumentTotal = q.GetDocumentTotal(lazyContext),
					PaymentIsClientAccountLocked = q.IsClientAccountLocked,
					PaymentCanEdit = q.CanEdit(isAdministrator, isSuperUser),
					PaymentCanDelete = q.CanDelete(isAdministrator, isAccounts, isSuperUser),
					PaymentCanUndo = q.CanUndo(false),
					PaymentCanReverse = q.CanReverse(),
					PaymentIsDebtor = q.PaymentType == PaymentType.SupplierPayment && q.Trip.DebtorId > 0,
					PaymentComments = q.Comments,
					PaymentIsDeposit = q.IsDeposit,
					PaymentIsTaxIncluded = isTaxIncluded,
					PaymentIsTaxApplicable = q.IsTaxApplicable,
					PaymentIsAutoInvoiced = q.IsAutoInvoiced,
					PaymentIsSplit = q.IsSplit,
					PaymentCommission = q.Commission + (isTaxIncluded ? q.CommissionTax : 0),
					PaymentCommissionTax = q.CommissionTax,
					PaymentCommissionRate = rateModel.CommissionRate,
					PaymentCommissionTaxRate = rateModel.CommissionTaxRate,
					PaymentDiscount = q.Discount + (isTaxIncluded ? q.DiscountTax : 0),
					PaymentDiscountTax = q.DiscountTax,
					PaymentDiscountRate = rateModel.DiscountRate,
					PaymentDiscountTaxRate = rateModel.DiscountTaxRate,
					PaymentDiscountReasonId = q.DiscountReasonId,
					PaymentMarkup = q.Markup + (isTaxIncluded ? q.MarkupTax : 0),
					PaymentMarkupTax = q.MarkupTax,
					PaymentMarkupRate = rateModel.MarkupRate,
					PaymentMarkupTaxRate = rateModel.MarkupTaxRate,
					PaymentMarkupStrategyId = q.MarkupStrategyId,
					PaymentIsCreditCardDiscountApplicable = q.IsCreditCardDiscountApplicable,
					PaymentIncludeMarkupInCreditCardPayment = q.IncludeMarkupInCreditCardPayment,
					PaymentTotalAmount = q.TotalAmount,
					PaymentTotalTax = q.TotalTax,
					PaymentTotalTaxRate = q.TotalTaxRate,
					LastWriteTime = q.LastWriteTime.ToLocalTime(),
					CreationTime = q.CreationTime.ToLocalTime(),
					LastWriteUser = q.LastWriteUser,
					CreationUser = q.CreationUser
				};

				ViewBag.PaymentIsNative = isNative;
				return PartialView("~/Views/Accounting/EditorTemplates/PaymentEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Payment_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Payment_Read([DataSourceRequest] DataSourceRequest request, DateTime? dateFrom, DateTime? dateTo, DateTime? departureDate, int paymentTypeId, int? documentStatusId,
			int bankAccountId, int bankAccountStatementId, decimal? amountFrom, decimal? amountTo, decimal? ticketedFare, int creditorId, int supplierId, int airlineId, int saleTypeId, int categoryId, int sourceId,
			int agencyId, int consultantId, string account, string payee, string passenger, string text, bool isExport, bool enableGrouping = false, string sortMember = null, string sortDirection = null, int? id = null) {

			try {
				var lazyContext = LazyContext;
				var documentStatus = (DocumentCombinedStatus?)documentStatusId;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isAccounts = HttpContext.IsAccounts();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q1 = lazyContext.Payment.Where(t => t.Id > 0);

				if (dateFrom != null)
					q1 = q1.Where(t => t.DocumentDate >= dateFrom);

				if (dateTo != null)
					q1 = q1.Where(t => t.DocumentDate <= dateTo);

				if (departureDate != null)
					q1 = q1.Where(t => t.Trip.DepartureDate == departureDate);

				if (paymentTypeId != (int)PaymentType.All)
					q1 = q1.Where(t => (int)t.PaymentType == paymentTypeId);

				if (documentStatus != null) {
					if (documentStatus == DocumentCombinedStatus.None) {
						q1 = q1.Where(t => t.PaymentDetails.Count == 0);
					}
					else {
						IQueryable<int> paymentDetailIds = null;

						if (documentStatus == DocumentCombinedStatus.Reversal || documentStatus == DocumentCombinedStatus.Reversed) {
							paymentDetailIds = lazyContext.PaymentDetail.Where(t => t.ReversalStatus == (documentStatus == DocumentCombinedStatus.Reversal ? ReversalStatus.Reversal : ReversalStatus.Reversed)).Select(t => t.Id);
						}
						else {
							paymentDetailIds = lazyContext.PaymentDetail.Where(t => t.DocumentStatus == (DocumentStatus)documentStatus).Select(t => t.Id);
						}

						q1 = q1.Where(t1 => t1.PaymentDetails.Any(t2 => paymentDetailIds.Contains(t2.Id)));
					}
				}

				if (bankAccountId > 0)
					q1 = q1.Where(t => t.BankAccountId == bankAccountId);

				if (bankAccountStatementId > 0)
					q1 = q1.Where(t1 => t1.PaymentDetails.Any(t2 => t2.BankAccountStatementId == bankAccountStatementId));

				if (amountFrom != null)
					q1 = q1.Where(t => t.AmountPayable + t.AmountPayableTax >= amountFrom);

				if (amountTo != null)
					q1 = q1.Where(t => t.AmountPayable + t.AmountPayableTax <= amountTo);

				if (ticketedFare != null)
					q1 = q1.Where(t1 => t1.PaymentDetails.Any(t2 => t2.TripLineAirPassenger.TicketedFare == ticketedFare));

				if (creditorId > 0)
					q1 = q1.Where(t => t.CreditorId == creditorId);

				if (supplierId > 0)
					q1 = q1.Where(t => t.SupplierId == supplierId);

				if (airlineId > 0)
					q1 = q1.Where(t => t.AirlineId == airlineId);

				if (saleTypeId > 0)
					q1 = q1.Where(t => t.SaleTypeId == saleTypeId);

				if (categoryId > 0)
					q1 = q1.Where(t => t.CategoryId == categoryId);

				if (sourceId > 0)
					q1 = q1.Where(t => t.SourceId == sourceId);

				if (agencyId > 0)
					q1 = q1.Where(t => t.AgencyId == agencyId);

				if (consultantId > 0)
					q1 = q1.Where(t => t.ConsultantId == consultantId);

				if (!string.IsNullOrEmpty(account)) {
					var predicate = PredicateBuilder.False<Payment>();

					foreach (var row in account.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
						predicate = predicate.Or(t => t.Trip.Id.ToString().Contains(row) || (t.Trip.Title + " " + t.Trip.FirstName + " " + t.Trip.LastName).Trim().ToLower().Contains(row) || t.Supplier.Name.ToLower().Contains(row) || t.ChartOfAccount.Code.ToLower().Contains(row) || t.ChartOfAccount.Name.ToLower().Contains(row));
					}

					q1 = q1.Where(predicate);
				}

				if (!string.IsNullOrEmpty(payee)) {
					payee = payee.Trim().ToLower();
					q1 = q1.Where(t => t.Payee.ToLower().Contains(payee));
				}

				if (!string.IsNullOrEmpty(passenger)) {
					var predicate = PredicateBuilder.False<PaymentDetail>();

					foreach (var row in passenger.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
						predicate = predicate.Or(t => (t.Passenger.Title + " " + t.Passenger.FirstName + " " + t.Passenger.LastName).Trim().ToLower().Contains(row));
					}

					var paymentDetailIds = lazyContext.PaymentDetail.Where(predicate).Select(t => t.Id);
					q1 = q1.Where(t1 => t1.PaymentDetails.Any(t2 => paymentDetailIds.Contains(t2.Id)));
				}

				if (!string.IsNullOrEmpty(text)) {
					text = text.Trim().ToLower();
					q1 = q1.Where(t => t.DocumentNo.ToLower().Contains(text) || t.Comments.ToLower().Contains(text));
				}

				if (id != null)
					q1 = q1.Where(t => t.Id == id);

				if (isExport) {
					if (!isAdministrator)
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var export = q1.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).ApplySorting(null, WebUtils.GetSortDescriptors(sortMember, sortDirection)).AsEnumerable().Select(row => new PaymentExportModel {
						AccountName = row.AccountName,
						PaymentType = row.PaymentType.GetEnumDescription(),
						DocumentNo = row.DocumentNo,
						DocumentDate = row.DocumentDate,
						ReturnDate = row.ReturnDate,
						DocumentStatus = row.DocumentStatus.GetEnumDescription(),
						ReversalStatus = row.ReversalStatus.GetEnumDescription(),
						BankAccount = row.BankAccount.Name,
						Payee = row.Payee,
						SaleType = row.SaleType.Name,
						IsDeposit = row.IsDeposit,
						Commission = row.Commission + row.CommissionTax,
						CommissionTax = row.CommissionTax,
						Cash = row.GetTotalCashGross(lazyContext),
						CashNonCommissionable = row.GetTotalCashNonCommissionableGross(),
						CreditCard = row.GetTotalCreditCardGross(),
						CreditCardNonCommissionable = row.GetTotalCreditCardNonCommissionableGross(),
						Tax = row.GetAmountPayableTax(),
						AmountPayable = row.GetAmountPayableGross(lazyContext)
					}).ToList();

					var xlsx = new ExportToExcel<PaymentExportModel>(export);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Payments.xlsx");
				}

				var q2 = q1.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).ApplySorting(request.Groups, request.Sorts).ApplyPaging(request.Page, request.PageSize).ToList().ConvertAll(row => new PaymentViewModel {
					PaymentId = row.Id,
					PaymentDocumentStatus = row.DocumentStatus,
					PaymentReversalStatus = row.ReversalStatus,
					PaymentAccountName = row.AccountName,
					PaymentAccountNameLink = row.AccountNameLink,
					PaymentType = row.PaymentType,
					PaymentDocumentNo = row.DocumentNo,
					PaymentDocumentDate = row.DocumentDate,
					PaymentPayee = row.Payee,
					PaymentSaleType = row.SaleTypeId <= 0 ? string.Empty : row.SaleType.Name,
					PaymentBankAccountId = row.BankAccountId,
					PaymentIsDeposit = row.IsDeposit,
					PaymentCommission = row.Commission + row.CommissionTax,
					PaymentCommissionTax = row.CommissionTax,
					PaymentTotalCash = row.GetTotalCashGross(lazyContext),
					PaymentTotalCashNonCommissionable = row.GetTotalCashNonCommissionableGross(),
					PaymentTotalCreditCard = row.GetTotalCreditCardGross(),
					PaymentTotalCreditCardNonCommissionable = row.GetTotalCreditCardNonCommissionableGross(),
					PaymentTotalTax = row.TotalTax,
					PaymentAmountPayable = row.AmountPayable + row.AmountPayableTax,
					PaymentAmountPayableTax = row.AmountPayableTax,
					PaymentCanEdit = row.CanEdit(isAdministrator, isSuperUser),
					PaymentCanDelete = row.CanDelete(isAdministrator, isAccounts, isSuperUser),
					PaymentCanUndo = row.CanUndo(false),
					PaymentCanReverse = row.CanReverse(),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				});

				int total = q1.Count();

				var result = await Task.Run(() => new DataSourceResult {
					Data = enableGrouping ? q2.ApplyGrouping(request.Groups, q2) : q2,
					Total = total
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Payment_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Payment_CreateOrUpdate(PaymentViewModel model, bool isNew) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				if (!Context.Payment.Any(t => t.Id == model.PaymentId))
					throw new UnreportedException(AppConstants.RecordCannotBeCreated);

				new PaymentCommon(HttpContext).CreateOrUpdate(model, !isNew, !isNew);
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Payment_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> PaymentWithDetail_CreateOrUpdate(PaymentViewModel model, PaymentDetailViewModel detailModel, bool isNew) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				new PaymentDetailCommon(HttpContext).CreateOrUpdate(model, detailModel, isNew);

				var lazyContext = LazyContext;
				var q = lazyContext.Payment.Find(model.PaymentId);

				model.PaymentTotalAmount = q.TotalAmount;
				model.PaymentTotalTax = q.TotalTax;
				model.PaymentTotalTaxRate = q.TotalTaxRate * 100;
				model.PaymentTotalNonCommissionable = q.TotalNonCommissionable;
				model.PaymentAmountPayable = q.AmountPayable + q.AmountPayableTax;
				model.PaymentAmountPayableTax = q.AmountPayableTax;
				model.PaymentDocumentTotal = q.GetDocumentTotal(lazyContext);

				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentWithDetail_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Payment_Delete([DataSourceRequest] DataSourceRequest request, PaymentViewModel model) {
			try {
				new PaymentCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Payment_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Payment_UpdateModel(PaymentViewModel model, string source, decimal unsavedAmount, decimal unsavedTax, int detailId) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.Payment.Find(model.PaymentId <= 0 ? -1 : model.PaymentId);

				int chartOfAccountId = q.ChartOfAccountId;
				int saleTypeId = q.SaleTypeId;

				bool isTaxApplicable = q.IsTaxApplicable;

				q.PaymentType = model.PaymentType;
				q.DocumentDate = model.PaymentDocumentDate ?? DateTime.Today;
				q.TripId = model.PaymentTripId ?? -1;
				q.DebtorId = model.PaymentDebtorId ?? -1;
				q.CreditorId = model.PaymentCreditorId ?? -1;
				q.ChartOfAccountId = model.PaymentChartOfAccountId ?? -1;
				q.BankAccountId = model.PaymentBankAccountId ?? -1;
				q.SupplierId = model.PaymentSupplierId ?? -1;
				q.SaleTypeId = model.PaymentSaleTypeId ?? -1;
				q.AgencyId = model.PaymentAgencyId;
				q.ConsultantId = model.PaymentConsultantId ?? -1;
				q.Commission = model.PaymentCommission;
				q.CommissionTax = model.PaymentCommissionTax;
				q.Discount = model.PaymentDiscount;
				q.DiscountTax = model.PaymentDiscountTax;
				q.Markup = model.PaymentMarkup;
				q.MarkupTax = model.PaymentMarkupTax;
				q.IsCreditCardDiscountApplicable = model.PaymentIsCreditCardDiscountApplicable;
				q.IncludeMarkupInCreditCardPayment = model.PaymentIncludeMarkupInCreditCardPayment;

				model.PaymentIsClientAccountLocked = q.IsClientAccountLocked;

				bool updateRateModel = true;
				bool updateDetailModel = true;
				bool documentNoChanged = false;
				string documentNo = model.PaymentDocumentNo;
				string message = string.Empty;

				if (model.PaymentId > 0) {
					switch (source) {
						case "ChartOfAccountId":
						case "SaleTypeId":
							if (!q.ValidateTaxApplicability(isTaxApplicable)) {
								if (source == "ChartOfAccountId") {
									model.PaymentChartOfAccountId = chartOfAccountId;
								}
								else {
									model.PaymentSaleTypeId = saleTypeId;
								}

								message = AppConstants.TaxRelatedRecordCannotBeAltered;
							}

							break;
					}

					if (!string.IsNullOrEmpty(message))
						return Json(new { Model = model, Message = message });
				}

				switch (source) {
					case "CreditorId":
						model.PaymentIncludeMarkupInCreditCardPayment = q.Creditor.IncludeMarkupInCreditCardPayment;
						break;
					case "SaleTypeId":
						model.PaymentIsCreditCardDiscountApplicable = q.SaleType.IsCreditCardDiscountApplicable;
						break;
					case "DocumentNo":
					case "BankAccountId":
					case "IsSplit":
						model.PaymentDocumentNo = Payment.GetUniqueDocumentNo(Context, model.PaymentId, model.PaymentBankAccountId ?? 0, model.PaymentIsSplit, model.PaymentDocumentNo);
						documentNoChanged = !string.IsNullOrEmpty(documentNo) && model.PaymentDocumentNo != documentNo;
						break;
					case "PaymentDocumentNo":
						model.PaymentDocumentNo = Payment.GetUniqueDocumentNo(Context, model.PaymentId, model.PaymentBankAccountId ?? 0, false, model.PaymentDocumentNo);
						documentNoChanged = !string.IsNullOrEmpty(documentNo) && model.PaymentDocumentNo != documentNo;
						break;
					case "ChartOfAccountId":
						if (q.ChartOfAccountId > 0 && Setting.IsControlAccount(HttpContext.CurrentCustomerId(), q.DocumentDate, q.ChartOfAccountId)) {
							if (HttpContext.IsAdministrator()) {
								message = AppConstants.GlControlAccountUpdate;
							}
							else {
								message = AppConstants.GlControlAccountWarning;
							}
						}

						break;
					case "TripId":
						if (q.Trip == null) {
							updateRateModel = false;
							break;
						}

						model.PaymentSourceId = q.Trip.SourceId;
						model.PaymentCategoryId = q.Trip.CategoryId;
						model.PaymentConsultantId = q.Trip.ConsultantId <= 0 ? HttpContext.CurrentConsultantId() : q.Trip.ConsultantId;
						model.PaymentIsDebtor = q.Trip.DebtorId > 0;
						break;
					case "Commission":
					case "CommissionTax":
					case "Discount":
					case "DiscountRate":
					case "Markup":
					case "MarkupRate":
						updateDetailModel = false;
						break;
				}

				model.PaymentIsTaxApplicable = q.IsTaxApplicable;

				List<string> sources = null;

				if (source == "DeleteDetail") {
					sources = new List<string> { "CommissionRate", "DiscountRate", "MarkupRate" };
				}
				else {
					sources = new List<string> { source };
				}

				var rateModel = new RateModel {
					Commission = q.Commission,
					CommissionRate = model.PaymentCommissionRate / 100,
					CommissionTax = q.CommissionTax,
					Discount = q.Discount,
					DiscountRate = model.PaymentDiscountRate / 100,
					DiscountTax = q.DiscountTax,
					Markup = q.Markup,
					MarkupRate = model.PaymentMarkupRate / 100,
					MarkupTax = q.MarkupTax,
					IsTaxIncluded = model.PaymentIsTaxIncluded
				};

				if (updateRateModel) {
					var rates = new AccountingRates<Payment>(HttpContext, q, rateModel);
					bool result = rates.SetRates(new List<string> { source }, unsavedAmount, unsavedTax, detailId);

					if (result || source == "DeleteDetail") {
						model.PaymentCommission = rateModel.CommissionGross;
						model.PaymentCommissionRate = rateModel.CommissionRate * 100;
						model.PaymentCommissionTax = rateModel.CommissionTax;
						model.PaymentCommissionTaxRate = rateModel.CommissionTaxRate * 100;

						model.PaymentDiscount = rateModel.DiscountGross;
						model.PaymentDiscountRate = rateModel.DiscountRate * 100;
						model.PaymentDiscountTax = rateModel.DiscountTax;
						model.PaymentDiscountTaxRate = rateModel.DiscountTaxRate * 100;

						model.PaymentMarkup = rateModel.MarkupGross;
						model.PaymentMarkupRate = rateModel.MarkupRate * 100;
						model.PaymentMarkupTax = rateModel.MarkupTax;
						model.PaymentMarkupTaxRate = rateModel.MarkupTaxRate * 100;

						if (rateModel.TaxRate > 0) {
							if (model.PaymentIsTaxIncluded) {
								unsavedTax = Math.Round(unsavedAmount * rateModel.TaxRate / (1 + rateModel.TaxRate), 2);
							}
							else {
								unsavedTax = Math.Round(unsavedAmount * rateModel.TaxRate, 2);
							}
						}
						else {
							unsavedTax = 0;
						}
					}
					else {
						updateDetailModel = false;
					}
				}
				else {
					updateDetailModel = false;
				}

				if (source == "DeleteDetail") {
					model.PaymentCommission = Math.Round(q.TotalAmount * model.PaymentCommissionRate / 100, 2);
					model.PaymentDiscount = Math.Round(q.TotalAmount * model.PaymentDiscountRate / 100, 2);
					model.PaymentMarkup = Math.Round(q.TotalAmount * model.PaymentMarkupRate / 100, 2);
					new PaymentCommon(HttpContext).CreateOrUpdate(model);
				}

				return Json(new { Model = model, DetailModel = new { Amount = rateModel.AmountGross, rateModel.Tax, TaxRate = rateModel.TaxRate * 100 }, UpdateDetailModel = updateDetailModel, DocumentNoChanged = documentNoChanged, Message = message });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Payment_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Payment_ProcessSelections(int[] paymentIds, bool undo) {
			try {
				if (paymentIds == null || paymentIds.Length == 0)
					throw new UnreportedException("No documents have been selected.");

				bool result = new PaymentCommon(HttpContext).ProcessSelections(LazyContext, paymentIds, undo);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Payment_ProcessSelections", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Payment_Undo(int id, bool isDetailView) {
			try {
				bool result = new PaymentCommon(HttpContext).Undo(LazyContext, id, isDetailView, false);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Payment_Undo", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Payment_Reverse(int paymentId, string type) {
			try {
				bool result = new PaymentCommon(HttpContext).Reverse(LazyContext, paymentId, type);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Payment_Reverse", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> PaymentDetail_Edit(PaymentType paymentType, AccountType accountType, int paymentId, int paymentDetailId, bool isTaxIncluded) {
			try {
				ViewBag.PaymentDetailPaymentType = paymentType;
				ViewBag.PaymentDetailAccountType = accountType;

				if (paymentDetailId == -1)
					return PartialView("~/Views/Accounting/EditorTemplates/PaymentDetailEdit.cshtml");

				var lazyContext = LazyContext;
				PaymentDetail q = null;

				if (paymentDetailId == 0) {
					q = new PaymentDetail {
						Id = 0,
						PaymentId = paymentId,
						DocumentStatus = DocumentStatus.Open,
						ReversalStatus = ReversalStatus.None,
						TripLineId = -1,
						TripLine = new TripLine { Id = -1 },
						TripLineAirPassengerId = -1,
						PassengerId = -1,
						FormOfPaymentId = -1,
						BankAccountStatementId = -1,
						OfferedReasonId = -1,
						Payment = lazyContext.Payment.Find(paymentId) ?? new Payment {
							Id = paymentId,
							PaymentType = paymentType,
							ChartOfAccountId = -1,
							ChartOfAccount = new ChartOfAccount { Id = -1 },
							SaleTypeId = -1,
							SaleType = new SaleType { Id = -1 }
						}
					};

					q.IsTaxApplicable = q.Payment.IsTaxApplicable;
				}
				else {
					q = lazyContext.PaymentDetail.Find(paymentDetailId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				var rateModel = new RateModel {
					Commission = q.Payment.Commission,
					CommissionTax = q.Payment.CommissionTax,
					Discount = q.Payment.Discount,
					DiscountTax = q.Payment.DiscountTax,
					Markup = q.Payment.Markup,
					MarkupTax = q.Payment.MarkupTax,
					IsTaxIncluded = isTaxIncluded,
					IsFormBinding = true,
					IsTaxApplicableOverride = q.IsTaxApplicable
				};

				var rates = new AccountingRates<PaymentDetail>(HttpContext, q, rateModel);
				rates.SetRates(new List<string> { "Tax" });

				var model = new PaymentDetailViewModel {
					PaymentDetailId = q.Id,
					PaymentId = q.PaymentId,
					PaymentDetailPaymentType = q.Payment.PaymentType,
					PaymentDetailDocumentStatus = q.DocumentStatus,
					PaymentDetailReversalStatus = q.ReversalStatus,
					PaymentDetailTripLineType = q.TripLine.TripLineType,
					PaymentDetailTripLineId = q.TripLineId <= 0 ? null : q.TripLineId,
					PaymentDetailTripLineAirPassengerId = q.TripLineAirPassengerId,
					PaymentDetailPassengerId = q.PassengerId,
					PaymentDetailFormOfPaymentId = q.FormOfPaymentId,
					PaymentDetailOfferedFare = q.OfferedFare,
					PaymentDetailOfferedReasonId = q.OfferedReasonId,
					PaymentDetailAmount = isTaxIncluded ? q.Amount + q.Tax : q.Amount,
					PaymentDetailTax = q.Tax,
					PaymentDetailTaxRate = rateModel.TaxRate,
					PaymentDetailNonCommissionable = q.NonCommissionableGross,
					PaymentDetailIsTaxApplicable = q.IsTaxApplicable
				};

				return PartialView("~/Views/Accounting/EditorTemplates/PaymentDetailGridEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentDetail_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> PaymentDetail_Read([DataSourceRequest] DataSourceRequest request, int parentId) {
			try {
				var lazyContext = LazyContext;
				const bool isTaxIncluded = true;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isAccounts = HttpContext.IsAccounts();
				bool isSuperUser = HttpContext.IsSuperUser();

				DataSourceResult result = null;

				var q1 = lazyContext.Payment.Find(parentId);

				if (q1?.PaymentType == PaymentType.BspReturn) {
					var q2 = lazyContext.Bsp.Where(t => t.PaymentId == parentId && t.CreditorId == q1.CreditorId).AsEnumerable().OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).Select(row => new PaymentDetailViewModel {
						PaymentDetailId = row.Id,
						PaymentId = row.PaymentId,
						PaymentDetailLinkedDocumentNo = row.DocumentNo,
						PaymentDetailLinkedDocumentDate = row.DocumentDate,
						PaymentDetailDocumentStatus = row.DocumentStatus,
						PaymentDetailReversalStatus = row.ReversalStatus,
						PaymentDetailLinkedAccountName = string.Format(@"<a href=""/Accounting/BspReturns/?id={0}"" target=""_blank"">{1}</a>", row.Id, row.AccountName),
						PaymentDetailPassenger = row.BspDetails.FirstOrDefault()?.TripLineAirPassengerId <= 0 && row.BspDetails.FirstOrDefault()?.PassengerId <= 0 ? string.Empty : row.BspDetails.FirstOrDefault()?.TripLineAirPassengerId > 0 ? row.BspDetails.FirstOrDefault()?.TripLineAirPassenger.Passenger.FullName : row.BspDetails.FirstOrDefault()?.Passenger.FullName,
						PaymentDetailFormOfPayment = row.BspDetails.FirstOrDefault()?.FormOfPaymentId <= 0 ? string.Empty : row.BspDetails.FirstOrDefault()?.FormOfPayment.PaySupplierDescription,
						PaymentDetailLinkedAmountPayable = row.GetAmountPayable(lazyContext, false)
					});

					var aggregateResults = new List<AggregateResult> {
						new AggregateResult(q2.Sum(t => t.PaymentDetailLinkedAmountPayable), new SumFunction { FunctionName = "Sum", SourceField = "PaymentDetailLinkedAmountPayable", MemberType = typeof(decimal) }),
					};

					result = await Task.Run(() => new DataSourceResult {
						Data = q2.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize),
						Total = q2.Count(),
						AggregateResults = aggregateResults
					});
				}
				else if (q1?.PaymentType == PaymentType.NonBspReturn) {
					var q2 = lazyContext.NonBsp.Where(t => t.PaymentId == parentId && t.CreditorId == q1.CreditorId).AsEnumerable().OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).Select(row => new PaymentDetailViewModel {
						PaymentDetailId = row.Id,
						PaymentId = row.PaymentId,
						PaymentDetailLinkedDocumentNo = row.DocumentNo,
						PaymentDetailLinkedDocumentDate = row.DocumentDate,
						PaymentDetailDocumentStatus = row.DocumentStatus,
						PaymentDetailReversalStatus = row.ReversalStatus,
						PaymentDetailLinkedAccountName = string.Format(@"<a href=""/Accounting/NonBspReturns/?id={0}"" target=""_blank"">{1}</a>", row.Id, row.AccountName),
						PaymentDetailPassenger = row.NonBspDetails.FirstOrDefault()?.TripLineAirPassengerId <= 0 && row.NonBspDetails.FirstOrDefault()?.PassengerId <= 0 ? string.Empty : row.NonBspDetails.FirstOrDefault()?.TripLineAirPassengerId > 0 ? row.NonBspDetails.FirstOrDefault()?.TripLineAirPassenger.Passenger.FullName : row.NonBspDetails.FirstOrDefault()?.Passenger.FullName,
						PaymentDetailFormOfPayment = row.NonBspDetails.FirstOrDefault()?.FormOfPaymentId <= 0 ? string.Empty : row.NonBspDetails.FirstOrDefault()?.FormOfPayment.PaySupplierDescription,
						PaymentDetailLinkedAmountPayable = row.GetAmountPayable(lazyContext, false)
					});

					var aggregateResults = new List<AggregateResult> {
						new AggregateResult(q2.Sum(t => t.PaymentDetailLinkedAmountPayable), new SumFunction { FunctionName = "Sum", SourceField = "PaymentDetailLinkedAmountPayable", MemberType = typeof(decimal) }),
					};

					result = await Task.Run(() => new DataSourceResult {
						Data = q2.Skip((request.Page - 1) * request.PageSize).Take(request.PageSize),
						Total = q2.Count(),
						AggregateResults = aggregateResults
					});
				}
				else {
					result = await lazyContext.PaymentDetail.Where(t => t.PaymentId == parentId).AsEnumerable().Select(row => new PaymentDetailViewModel {
						PaymentDetailId = row.Id,
						PaymentId = row.PaymentId,
						PaymentDetailTripLineType = row.TripLine.TripLineType,
						PaymentDetailPaymentType = row.Payment.PaymentType,
						PaymentDetailDocumentStatus = row.DocumentStatus,
						PaymentDetailReversalStatus = row.ReversalStatus,
						PaymentDetailTripLineId = row.TripLineId <= 0 ? null : row.TripLineId,
						PaymentDetailTripLineAirPassengerId = row.TripLineAirPassengerId,
						PaymentDetailPassengerId = row.PassengerId,
						PaymentDetailPassenger = row.TripLineAirPassengerId <= 0 && row.PassengerId <= 0 ? string.Empty : row.TripLineAirPassengerId > 0 ? row.TripLineAirPassenger.Passenger.FullName : row.Passenger.FullName,
						PaymentDetailFormOfPaymentId = row.FormOfPaymentId,
						PaymentDetailFormOfPayment = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.PaySupplierDescription,
						PaymentDetailBankAccountStatementName = row.BankAccountStatementId > 0 ? row.BankAccountStatement.Name : string.Empty,
						PaymentDetailAmount = isTaxIncluded ? row.Amount + row.Tax : row.Amount,
						PaymentDetailTax = row.Tax,
						PaymentDetailNonCommissionable = row.NonCommissionableGross,
						PaymentDetailCanEdit = row.CanEdit(isAdministrator, isSuperUser),
						PaymentDetailCanDelete = row.CanDelete(isAdministrator, isAccounts, isSuperUser),
						PaymentDetailCanUndo = row.CanUndo(false),
						PaymentDetailCanReverse = row.CanReverse(),
						LastWriteTime = row.LastWriteTime.ToLocalTime(),
						CreationTime = row.CreationTime.ToLocalTime(),
						LastWriteUser = row.LastWriteUser,
						CreationUser = row.CreationUser
					}).ToDataSourceResultAsync(request);
				}

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentDetail_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> PaymentDetail_Delete([DataSourceRequest] DataSourceRequest request, PaymentDetailViewModel model) {
			try {
				new PaymentDetailCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentDetail_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> PaymentDetail_UpdateModel(PaymentViewModel model, PaymentDetailViewModel detailModel, string source) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.PaymentDetail.Find(detailModel.PaymentDetailId <= 0 ? -1 : detailModel.PaymentDetailId);

				q.PaymentId = model.PaymentId;
				q.TripLineId = detailModel.PaymentDetailTripLineId ?? -1;
				q.TripLineAirPassengerId = detailModel.PaymentDetailTripLineAirPassengerId ?? -1;
				q.Amount = detailModel.PaymentDetailAmount;
				q.Tax = detailModel.PaymentDetailTax;
				q.NonCommissionable = detailModel.PaymentDetailNonCommissionable;
				q.IsTaxApplicable = detailModel.PaymentDetailIsTaxApplicable;

				q.Payment ??= lazyContext.Payment.Find(model.PaymentId <= 0 ? -1 : model.PaymentId);

				q.Payment.PaymentType = model.PaymentType;
				q.Payment.DocumentNo = model.PaymentDocumentNo;
				q.Payment.DocumentDate = model.PaymentDocumentDate ?? DateTime.Today;
				q.Payment.TripId = model.PaymentTripId ?? -1;
				q.Payment.DebtorId = model.PaymentDebtorId ?? -1;
				q.Payment.CreditorId = model.PaymentCreditorId ?? -1;
				q.Payment.ChartOfAccountId = model.PaymentChartOfAccountId ?? -1;
				q.Payment.BankAccountId = model.PaymentBankAccountId ?? -1;
				q.Payment.SupplierId = model.PaymentSupplierId ?? -1;
				q.Payment.SaleTypeId = model.PaymentSaleTypeId ?? -1;
				q.Payment.AgencyId = model.PaymentAgencyId;
				q.Payment.ConsultantId = model.PaymentConsultantId ?? -1;
				q.Payment.Commission = model.PaymentCommission;
				q.Payment.CommissionTax = model.PaymentCommissionTax;
				q.Payment.Discount = model.PaymentDiscount;
				q.Payment.DiscountTax = model.PaymentDiscountTax;
				q.Payment.Markup = model.PaymentMarkup;
				q.Payment.MarkupTax = model.PaymentMarkupTax;

				model.PaymentIsClientAccountLocked = q.Payment.IsClientAccountLocked;
				var sources = new List<string> { source };

				DateTime documentDate = DateTime.Today;
				string documentNo = string.Empty;

				int creditorId = -1;
				int supplierId = -1;
				int airlineId = -1;
				int saleTypeId = -1;
				int discountReasonId = -1;
				int markupStrategyId = -1;
				int formOfPaymentId = -1;
				int offeredReasonId = -1;

				decimal offeredFare = 0;
				decimal commission = 0;
				decimal discount = 0;
				decimal markup = 0;
				decimal nonCommissionableGross = 0;

				bool updateRateModel = true;

				switch (source) {
					case "TripLineId":
						if (q.TripLine == null || q.TripLineId <= 0) {
							updateRateModel = false;
							break;
						}

						documentNo = q.TripLine.DocumentNo;
						creditorId = q.TripLine.Creditor.Id;
						supplierId = q.TripLine.Supplier.Id;
						saleTypeId = q.TripLine.SaleType.Id;

						discountReasonId = q.TripLine.DiscountReason.Id;
						markupStrategyId = q.TripLine.MarkupStrategy.Id;
						formOfPaymentId = q.TripLine.FormOfPayment.Id;
						offeredReasonId = q.TripLine.OfferedReason.Id;

						model.PaymentIsCreditCardDiscountApplicable = q.TripLine.IsCreditCardDiscountApplicable;
						model.PaymentIncludeMarkupInCreditCardPayment = q.TripLine.IncludeMarkupInCreditCardPayment;

						offeredFare = q.TripLine.OfferedFare ?? 0;
						commission = q.TripLine.Commission;
						discount = q.TripLine.Discount;
						markup = q.TripLine.Markup;
						nonCommissionableGross = q.TripLine.NonCommissionable;

						detailModel.PaymentDetailTripLineType = q.TripLine.TripLineType;

						if (model.PaymentType != PaymentType.ClientRefund)
							detailModel.PaymentDetailAmount = q.TripLine.GetAmountPayableDue(lazyContext, HttpContext.CurrentCustomerId());

						break;
					case "TripLineAirPassengerId":
						if (q.TripLineAirPassenger == null || q.TripLineAirPassengerId <= 0) {
							updateRateModel = false;
							break;
						}

						documentDate = q.TripLineAirPassenger.IssueDate == DateTime.MinValue ? DateTime.Today : q.TripLineAirPassenger.IssueDate;
						documentNo = q.TripLineAirPassenger.TicketNo;
						creditorId = q.TripLineAirPassenger.CreditorId;
						supplierId = q.TripLineAirPassenger.SupplierId;
						airlineId = q.TripLineAirPassenger.AirlineId;
						saleTypeId = q.TripLineAirPassenger.SaleTypeId;

						discountReasonId = q.TripLineAirPassenger.DiscountReasonId;
						markupStrategyId = q.TripLineAirPassenger.MarkupStrategyId;
						formOfPaymentId = q.TripLineAirPassenger.FormOfPaymentId;
						offeredReasonId = q.TripLineAirPassenger.OfferedReasonId;

						model.PaymentIsCreditCardDiscountApplicable = q.TripLineAirPassenger.IsCreditCardDiscountApplicable;
						model.PaymentIncludeMarkupInCreditCardPayment = q.TripLineAirPassenger.IncludeMarkupInCreditCardPayment;

						offeredFare = q.TripLineAirPassenger.OfferedFare;
						commission = q.TripLineAirPassenger.Commission;
						discount = q.TripLineAirPassenger.Discount;
						markup = q.TripLineAirPassenger.Markup;
						nonCommissionableGross = q.TripLineAirPassenger.NonCommissionable;

						detailModel.PaymentDetailTripLineType = TripLineType.Air;

						if (model.PaymentType != PaymentType.ClientRefund)
							detailModel.PaymentDetailAmount = q.TripLineAirPassenger.GetAmountPayableDue(lazyContext, HttpContext.CurrentCustomerId());

						q.Payment.SaleTypeId = q.TripLineAirPassenger.SaleTypeId;

						sources.Add("SaleTypeId");
						break;
				}

				if (source == "TripLineId" || source == "TripLineAirPassengerId") {
					model.PaymentDocumentDate = documentDate;
					model.PaymentAirlineId = airlineId;

					detailModel.PaymentDetailFormOfPaymentId = formOfPaymentId;
					detailModel.PaymentDetailOfferedFare = offeredFare;
					detailModel.PaymentDetailOfferedReasonId = offeredReasonId;

					if (!string.IsNullOrEmpty(documentNo))
						model.PaymentDocumentNo = documentNo;

					if (creditorId <= 0) {
						model.PaymentCreditorId = null;
					}
					else {
						model.PaymentCreditorId = creditorId;
					}

					if (supplierId <= 0) {
						model.PaymentSupplierId = null;
					}
					else {
						model.PaymentSupplierId = supplierId;
					}

					if (saleTypeId <= 0) {
						model.PaymentSaleTypeId = null;
					}
					else {
						model.PaymentSaleTypeId = saleTypeId;
					}

					q.Payment.CreditorId = model.PaymentCreditorId ?? -1;
					q.Payment.SupplierId = model.PaymentSupplierId ?? -1;
					q.Payment.SaleTypeId = model.PaymentSaleTypeId ?? -1;

					model.PaymentCommission = commission;
					model.PaymentCommissionTax = 0;

					model.PaymentDiscount = discount;
					model.PaymentDiscountTax = 0;

					if (model.PaymentDiscountReasonId <= 0)
						model.PaymentDiscountReasonId = discountReasonId;

					model.PaymentMarkup = markup;
					model.PaymentMarkupTax = 0;

					if (model.PaymentMarkupStrategyId <= 0)
						model.PaymentMarkupStrategyId = markupStrategyId;

					sources.Add("Commission");
					sources.Add("Discount");
					sources.Add("Markup");
				}

				if (model.PaymentType == PaymentType.Admin) {
					detailModel.PaymentDetailIsTaxApplicable = q.IsTaxApplicable;
				}
				else {
					detailModel.PaymentDetailIsTaxApplicable = q.Payment.IsTaxApplicable;
				}

				if (q.PaymentId <= 0) {
					q.Payment.DocumentDate = model.PaymentDocumentDate ?? DateTime.MinValue;
					q.Payment.CreditorId = model.PaymentCreditorId ?? -1;
					q.Payment.SupplierId = model.PaymentSupplierId ?? -1;
					q.Payment.SaleTypeId = model.PaymentSaleTypeId ?? -1;
				}

				var rateModel = new RateModel {
					Commission = model.PaymentCommission,
					CommissionRate = model.PaymentCommissionRate / 100,
					CommissionTax = model.PaymentCommissionTax,
					Discount = model.PaymentDiscount,
					DiscountRate = model.PaymentDiscountRate / 100,
					DiscountTax = model.PaymentDiscountTax,
					Markup = model.PaymentMarkup,
					MarkupRate = model.PaymentMarkupRate / 100,
					MarkupTax = model.PaymentMarkupTax,
					NonCommissionableGross = nonCommissionableGross,
					IsTaxIncluded = model.PaymentIsTaxIncluded,
					IsTaxApplicableOverride = detailModel.PaymentDetailIsTaxApplicable
				};

				bool result = false;

				if (updateRateModel) {
					var rates = new AccountingRates<PaymentDetail>(HttpContext, q, rateModel);
					result = rates.SetRates(sources, detailModel.PaymentDetailAmount, detailModel.PaymentDetailTax, detailModel.PaymentDetailId);

					if (result) {
						model.PaymentCommission = rateModel.CommissionGross;
						model.PaymentCommissionRate = rateModel.CommissionRate * 100;
						model.PaymentCommissionTax = rateModel.CommissionTax;
						model.PaymentCommissionTaxRate = rateModel.CommissionTaxRate * 100;

						model.PaymentDiscount = rateModel.DiscountGross;
						model.PaymentDiscountRate = rateModel.DiscountRate * 100;
						model.PaymentDiscountTax = rateModel.DiscountTax;
						model.PaymentDiscountTaxRate = rateModel.DiscountTaxRate * 100;

						model.PaymentMarkup = rateModel.MarkupGross;
						model.PaymentMarkupRate = rateModel.MarkupRate * 100;
						model.PaymentMarkupTax = rateModel.MarkupTax;
						model.PaymentMarkupTaxRate = rateModel.MarkupTaxRate * 100;

						if (model.PaymentType != PaymentType.ClientRefund) {
							detailModel.PaymentDetailAmount = rateModel.AmountGross;
							detailModel.PaymentDetailTax = rateModel.Tax;
							detailModel.PaymentDetailTaxRate = rateModel.TaxRate * 100;

							if (source == "TripLineId" || source == "TripLineAirPassengerId") {
								if (detailModel.PaymentDetailAmount == 0) {
									detailModel.PaymentDetailNonCommissionable = 0;
								}
								else {
									detailModel.PaymentDetailAmount -= rateModel.NonCommissionableGross;
									detailModel.PaymentDetailTax -= rateModel.NonCommissionableTax;
									detailModel.PaymentDetailNonCommissionable = rateModel.NonCommissionable + rateModel.NonCommissionableTax;
								}
							}
						}
					}
				}

				return Json(new { Model = model, DetailModel = detailModel, UpdateRateModel = result });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentDetail_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
        public async Task<IActionResult> PaymentAdd_Edit(int tripId, int tripLineAirPassengerId = 0, int[] tripLineIds = null, bool validateTripLineCount = true) {
            try {
                var lazyContext = LazyContext;

                if (tripLineAirPassengerId > 0) {
                    var tripLineAirPassenger = lazyContext.TripLineAirPassenger.Find(tripLineAirPassengerId);

                    if (tripLineAirPassenger.GetAmountPayableDue(lazyContext, HttpContext.CurrentCustomerId()) == 0)
                        throw new UnreportedException("This record has already been paid.");
                }
                else {
                    bool isNative = tripLineIds != null && tripLineIds.Length > 0;

                    if (!validateTripLineCount && (tripLineIds == null || tripLineIds.Length == 0))
                        tripLineIds = lazyContext.TripLine.Where(t => t.TripId == tripId).Select(t => t.Id).ToArray();

                    var tripLines = lazyContext.TripLine.Where(t => tripLineIds.Contains(t.Id)).ToList();

                    if (validateTripLineCount && tripLines.Count == 0)
                        throw new UnreportedException("No trip lines have been selected.");

                    if (tripLines.Sum(t => t.GetAmountPayableDue(lazyContext, HttpContext.CurrentCustomerId())) == 0) {
                        bool validateZeroValue = true;

                        foreach (var tripLine in tripLines) {
                            if (tripLine.TripLineType == TripLineType.Air && tripLine.TripLineAir.TripLineAirPassengers.Any(t => t.GetAmountPayableDue(lazyContext, HttpContext.CurrentCustomerId()) != 0)) {
                                validateZeroValue = false;
                                break;
                            }
                            else if (tripLine.TripLineType != TripLineType.Air && tripLine.GetAmountPayableDue(lazyContext, HttpContext.CurrentCustomerId()) != 0) {
                                validateZeroValue = false;
                                break;
                            }
                        }

                        if (validateZeroValue) {
                            if (isNative) {
                                throw new UnreportedException("Selected trip lines have already been paid or are zero value.");
                            }
                            else {
                                return new EmptyResult();
                            }
                        }
                    }
                }

                ViewData["PaymentAddPaymentTypeList"] = new List<SelectListItem> {
                    new SelectListItem {
                        Value = ((int)PaymentType.BspReturn).ToString(),
                        Text = "BSP"
                    },
                    new SelectListItem {
                        Value = ((int)PaymentType.NonBspReturn).ToString(),
                        Text = "Non-BSP"
                    },
                    new SelectListItem {
                        Value = ((int)PaymentType.SupplierPayment).ToString(),
                        Text = "Payment"
                    },
                    new SelectListItem {
                        Value = ((int)PaymentType.Admin).ToString(),
                        Text = "Adjustment"
                    }
                };

                ViewBag.PaymentAddTripId = tripId;
                ViewBag.PaymentAddTripLineAirPassengerId = tripLineAirPassengerId;
                ViewBag.PaymentAddTripLineIds = string.Join(",", tripLineIds);

                return PartialView("~/Views/Accounting/EditorTemplates/PaymentAdd.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentAdd_Edit", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> PaymentAdd_Read([DataSourceRequest] DataSourceRequest request, int tripLineAirPassengerId, string tripLineIds) {
			try {
				var lazyContext = LazyContext;
				var tripLineIdList = tripLineIds.Split(',').Select(int.Parse).ToArray();

				var paymentAdd = new List<PaymentAddViewModel>();
				var paymentType = PaymentType.All;

				string documentNo = null;
				string description = null;

				decimal amountDue = 0;
				decimal nonCommissionableDue = 0;

				decimal commissionDue = 0;
				decimal discountDue = 0;
				decimal markupDue = 0;

				int i = 0;
				var q = lazyContext.TripLine.Where(t => tripLineIdList.Contains(t.Id)).AsEnumerable().Where(t => t.IsBooking);

				foreach (var tripLine in q.ToList()) {
					if (tripLine.Voucher.PaymentClass == PaymentClass.PaidDirect)
						continue;

					if (tripLine.TripLineType != TripLineType.Air) {
						if (tripLine.AmountPayable != 0 && tripLine.AmountPayable == tripLine.AmountPaid)
							continue;

						i++;
						nonCommissionableDue = tripLine.GetNonCommissionableDue(lazyContext);
						amountDue = tripLine.GetAmountPayableDue(lazyContext, HttpContext.CurrentCustomerId()) - nonCommissionableDue;

						if (amountDue == 0)
							continue;

						commissionDue = tripLine.GetCommissionDue(lazyContext);
						discountDue = tripLine.GetDiscountDue(lazyContext);
						markupDue = tripLine.GetMarkupDue(lazyContext);
                    }

					switch (tripLine.TripLineType) {
						case TripLineType.Air:
							foreach (var row in tripLine.TripLineAir.TripLineAirPassengers.Where(t => tripLineAirPassengerId <= 0 || t.Id == tripLineAirPassengerId).ToList()) {
                                decimal amountPayable = row.GetAmountPayable(HttpContext.CurrentCustomerId());

                                if (amountPayable != 0 && amountPayable == row.GetAmountPaid(lazyContext))
									continue;

								nonCommissionableDue = row.GetNonCommissionableDue(lazyContext);
								amountDue = row.GetAmountPayableDue(lazyContext, HttpContext.CurrentCustomerId()) - nonCommissionableDue;

								if (amountDue == 0 && nonCommissionableDue == 0)
									continue;

								i++;

								commissionDue = row.GetCommissionDue(lazyContext);
								discountDue = row.GetDiscountDue(lazyContext);
								markupDue = row.GetMarkupDue(lazyContext);

								if (row.Creditor.IsBspAgent) {
									paymentType = PaymentType.BspReturn;
								}
								else if (row.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard || row.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Net || row.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Gross) {
									paymentType = PaymentType.NonBspReturn;
								}
								else {
									paymentType = row.Creditor.IsNonBspAgent ? PaymentType.NonBspReturn : PaymentType.SupplierPayment;
								}

								documentNo = row.TicketNo;

								description = string.Concat(row.Creditor.Name, AppConstants.HtmlLineBreak);

								if (row.TripLineAir.AirlineId > 0) {
									description = string.Concat(description, row.TripLineAir.Airline.Code);

									if (!string.IsNullOrEmpty(row.Routing))
										description = string.Concat(description, " - ", row.Routing);
								}
								else {
									description = string.Concat(description, row.Routing);
								}

								paymentAdd.Add(new PaymentAddViewModel {
									PaymentAddId = i,
									PaymentAddTripLineType = TripLineType.Air,
									PaymentAddPaymentType = paymentType,
									PaymentAddDescription = description,
									PaymentAddDocumentNo = documentNo,
									PaymentAddDocumentDate = (row.IssueDate == DateTime.MinValue ? HttpContext.Today() : row.IssueDate).ToUniversalTime(),
									PaymentAddTripLineId = tripLine.Id,
									PaymentAddTripLineAirPassengerId = row.Id,
									PaymentAddPassengerId = row.Passenger.Id,
									PaymentAddFormOfPaymentId = paymentType == PaymentType.BspReturn || paymentType == PaymentType.NonBspReturn ? row.FormOfPayment.Id : -1,
									PaymentAddAmount = amountDue,
									PaymentAddNonCommissionable = nonCommissionableDue,
									PaymentAddCommission = commissionDue,
									PaymentAddDiscount = discountDue,
									PaymentAddMarkup = markupDue,
									PaymentAddAmountPayable = amountDue,
									PaymentAddNonCommissionableMax = nonCommissionableDue,
									PaymentAddCommissionMax = commissionDue,
									PaymentAddDiscountMax = discountDue,
									PaymentAddMarkupMax = markupDue,
									PaymentAddTooltip = row.GetTooltip(lazyContext, HttpContext.CurrentCustomerId()),
									PaymentAddDatePaidIsIssueDate = row.IssueDate > DateTime.MinValue,
									PaymentAddIsBsp = paymentType == PaymentType.BspReturn,
									PaymentAddIsParent = true
								});
							}

							continue;
						case TripLineType.Accommodation:
						case TripLineType.Transport:
						case TripLineType.Cruise:
						case TripLineType.Tour:
						case TripLineType.OtherLand:
							if (tripLine.Creditor.IsBspAgent) {
								paymentType = PaymentType.BspReturn;
							}
							else if (tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard || tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Net || tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Gross) {
								paymentType = PaymentType.NonBspReturn;
							}
							else {
								paymentType = tripLine.TripLineLand.Creditor.IsBspAgent ? PaymentType.BspReturn : tripLine.TripLineLand.Creditor.IsNonBspAgent ? PaymentType.NonBspReturn : PaymentType.SupplierPayment;
							}

							description = tripLine.TripLineLand.Creditor.Name;
							documentNo = string.IsNullOrEmpty(tripLine.TripLineLand.DocumentNo) ? tripLine.Voucher.DocumentNo : tripLine.TripLineLand.DocumentNo;
							break;
						case TripLineType.Insurance:
							if (tripLine.Creditor.IsBspAgent) {
								paymentType = PaymentType.BspReturn;
							}
							else if (tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard || tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Net || tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Gross) {
								paymentType = PaymentType.NonBspReturn;
							}
							else {
								paymentType = tripLine.TripLineInsurance.Creditor.IsBspAgent ? PaymentType.BspReturn : tripLine.TripLineInsurance.Creditor.IsNonBspAgent ? PaymentType.NonBspReturn : PaymentType.SupplierPayment;
							}

							description = tripLine.TripLineInsurance.Creditor.Name;
							documentNo = tripLine.TripLineInsurance.PolicyNo;
							break;
						case TripLineType.ForeignCurrency:
							if (tripLine.Creditor.IsBspAgent) {
								paymentType = PaymentType.BspReturn;
							}
							else if (tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard || tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Net || tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Gross) {
								paymentType = PaymentType.NonBspReturn;
							}
							else {
								paymentType = tripLine.TripLineForeignCurrency.Creditor.IsBspAgent ? PaymentType.BspReturn : tripLine.TripLineForeignCurrency.Creditor.IsNonBspAgent ? PaymentType.NonBspReturn : PaymentType.SupplierPayment;
							}

							description = tripLine.TripLineForeignCurrency.Creditor.Name;
							documentNo = tripLine.TripLineForeignCurrency.DocumentNo;
							break;
						case TripLineType.ServiceFee:
							if (tripLine.TripLineServiceFee.ServiceFeePaymentType == ServiceFeePaymentType.Agency) {
								paymentType = PaymentType.Admin;
							}
							else if (tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard || tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Net || tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Gross) {
								paymentType = PaymentType.NonBspReturn;
							}
							else {
								paymentType = tripLine.TripLineServiceFee.Creditor.IsBspAgent ? PaymentType.BspReturn : tripLine.TripLineServiceFee.Creditor.IsNonBspAgent ? PaymentType.NonBspReturn : PaymentType.SupplierPayment;
							}

                            description = tripLine.TripLineServiceFee.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? string.Empty : tripLine.TripLineServiceFee.Creditor.Name;
                            documentNo = tripLine.TripLineServiceFee.ServiceFeePaymentType == ServiceFeePaymentType.Agency ? "Not Required" : tripLine.TripLineServiceFee.DocumentNo;
							break;
						case TripLineType.OtherInclusion:
							if (tripLine.Creditor.IsBspAgent) {
								paymentType = PaymentType.BspReturn;
							}
							else if (tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard || tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Net || tripLine.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.Gross) {
								paymentType = PaymentType.NonBspReturn;
							}
							else {
								paymentType = tripLine.TripLineOtherInclusion.Creditor.IsBspAgent ? PaymentType.BspReturn : tripLine.TripLineOtherInclusion.Creditor.IsNonBspAgent ? PaymentType.NonBspReturn : PaymentType.SupplierPayment;
							}

							description = tripLine.TripLineOtherInclusion.Creditor.Name;
							documentNo = tripLine.TripLineOtherInclusion.DocumentNo;
							break;
					}

                    description = string.Concat(description, AppConstants.HtmlLineBreak, tripLine.Description).TrimStart(AppConstants.HtmlLineBreak);

                    int passengerId = (tripLine.Trip.TripPassengers.FirstOrDefault(t => t.PassengerType == PassengerType.Adult && t.FirstName.Equals(tripLine.Trip.FirstName, StringComparison.OrdinalIgnoreCase) && t.LastName.Equals(tripLine.Trip.LastName, StringComparison.OrdinalIgnoreCase)) ?? tripLine.Trip.TripPassengers.FirstOrDefault(t => t.PassengerType == PassengerType.Adult) ?? new Passenger { Id = -1 }).Id;

					paymentAdd.Add(new PaymentAddViewModel {
						PaymentAddId = i,
						PaymentAddTripLineType = tripLine.TripLineType,
						PaymentAddPaymentType = paymentType,
						PaymentAddDescription = description,
						PaymentAddDocumentNo = documentNo,
						PaymentAddDocumentDate = HttpContext.Today().ToUniversalTime(),
						PaymentAddTripLineId = tripLine.Id,
						PaymentAddTripLineAirPassengerId = -1,
						PaymentAddPassengerId = passengerId,
						PaymentAddFormOfPaymentId = paymentType == PaymentType.BspReturn || paymentType == PaymentType.NonBspReturn ? tripLine.FormOfPayment.Id : -1,
						PaymentAddAmount = amountDue,
						PaymentAddNonCommissionable = nonCommissionableDue,
						PaymentAddCommission = commissionDue,
						PaymentAddDiscount = discountDue,
						PaymentAddMarkup = markupDue,
						PaymentAddAmountPayable = amountDue,
						PaymentAddNonCommissionableMax = nonCommissionableDue,
						PaymentAddCommissionMax = commissionDue,
						PaymentAddDiscountMax = discountDue,
						PaymentAddMarkupMax = markupDue,
						PaymentAddTooltip = tripLine.GetTooltip(lazyContext),
						PaymentAddIsBsp = paymentType == PaymentType.BspReturn,
						PaymentAddIsParent = true
					});
				}

				return Json(await paymentAdd.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentAdd_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> PaymentAdd_Create(int bankAccountId, string comments, bool isDeposit, string paymentAddModels) {
			try {
				int count = new PaymentCommon(HttpContext).Create(LazyContext, bankAccountId, comments, isDeposit, paymentAddModels);
				return Json(count);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentAdd_Create", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region Invoices
		public IActionResult Invoices(string message = null, MessageType messageType = MessageType.Info, int timeoutSeconds = 30) {
			ViewBag.Message = message;
			ViewBag.MessageType = messageType;
			ViewBag.TimeoutSeconds = timeoutSeconds;
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Invoice_Edit(int invoiceId, int debtorId, bool isNew, bool isNative) {
			try {
				var lazyContext = LazyContext;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();
				bool hasAutoClosed = false;

				Invoice q = null;

				if (invoiceId <= 0) {
					q = new Invoice {
						Id = 0,
						AccountType = AccountType.Client,
						InvoiceType = InvoiceType.Invoice,
						DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Invoice"),
						DocumentDate = DateTime.Today,
						DebtorId = debtorId,
						Debtor = lazyContext.Debtor.Find(debtorId),
						SubDebtorId = -1,
						DebtorContactId = -1,
						DebtorName = string.Empty,
						DebtorAddress1 = string.Empty,
						DebtorAddress2 = string.Empty,
						DebtorLocality = string.Empty,
						DebtorRegion = string.Empty,
						DebtorPostCode = string.Empty,
						DebtorCountryCode = string.Empty,
						DebtorOrderNo = string.Empty,
						DebtorCurrencyId = -1,
                        AgencyId = HttpContext.CurrentDefaultAgencyId(),
                        Agency = lazyContext.Agency.Find(HttpContext.CurrentDefaultAgencyId()),
                        PaymentTerms = string.Empty,
						InvoiceLinkId = -1,
						IsMatched = false
					};
				}
				else {
					q = lazyContext.Invoice.Find(invoiceId);

					if (!isNew)
						hasAutoClosed = q.UpdateDocumentStatus(lazyContext, DocumentStatus.Closed);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				var model = new InvoiceViewModel {
					InvoiceId = q.Id,
					InvoiceDocumentStatus = q.DocumentStatus,
					InvoiceAccountType = q.AccountType,
					InvoiceType = q.InvoiceType,
					InvoiceDocumentNo = q.DocumentNo,
					InvoiceDocumentDate = q.DocumentDate,
					InvoiceDebtorId = q.DebtorId,
					InvoiceSubDebtorId = q.SubDebtorId,
					InvoiceDebtorName = q.DebtorName,
					InvoiceDebtorContactId = q.DebtorContactId,
					InvoiceDebtorAddress1 = q.DebtorAddress1,
					InvoiceDebtorAddress2 = q.DebtorAddress2,
					InvoiceDebtorLocality = q.DebtorLocality,
					InvoiceDebtorRegion = q.DebtorRegion,
					InvoiceDebtorPostCode = q.DebtorPostCode,
					InvoiceDebtorCountryCode = q.DebtorCountryCode,
					InvoiceDebtorOrderNo = q.DebtorOrderNo,
					InvoiceDebtorCurrencyId = q.DebtorCurrencyId,
					InvoiceDebtorExchangeRate = q.DebtorExchangeRate,
					InvoiceDeposit = q.Deposit,
					InvoiceBalance = q.Balance,
					InvoiceDepositDueDate = q.DepositDueDate == DateTime.MinValue ? null : q.DepositDueDate,
					InvoiceDepositPaidDate = q.DepositPaidDate == DateTime.MinValue ? null : q.DepositPaidDate,
					InvoiceBalanceDueDate = q.BalanceDueDate == DateTime.MinValue ? null : q.BalanceDueDate,
					InvoicePaymentTerms = q.PaymentTerms,
					InvoiceComments = q.Comments,
					InvoicedPassengers = q.Id <= 0 ? string.Empty : string.Join("; ", q.InvoiceDetails.SelectMany(t => t.InvoiceDetailPassengers).Select(t => t.Passenger.FullName).Distinct()),
					InvoiceTotalAmount = q.TotalAmount,
					InvoiceTotalTax = q.TotalTax,
					InvoiceTotalTaxRate = q.TotalTaxRate,
					InvoiceTotalDiscount = q.TotalDiscount,
					InvoiceTotalDiscountRate = q.TotalDiscountRate,
					InvoiceIsTaxIncluded = true,
					InvoiceIsIssued = q.IsIssued,
					InvoiceAgencyId = q.Debtor.AgencyId,
                    InvoiceAgencyEmail = q.Agency.AgencyUserEmails.SingleOrDefault(t => t.UserId == HttpContext.UserId())?.Email ?? HttpContext.User.Identity.Name,
                    InvoiceEmail = q.DebtorContactId > 0 ? q.DebtorContact.Email : q.Debtor.DefaultContact.Email,
					InvoiceHasAutoClosed = hasAutoClosed,
					InvoiceIsNew = isNew,
					InvoiceCanEdit = q.CanEdit(isNew, isSuperUser),
					InvoiceCanDelete = q.CanDelete(isNew, isAdministrator, isSuperUser),
					InvoiceCanUndo = q.CanUndo(),
					InvoiceCanReissue = q.CanReissue(),
					LastWriteTime = q.LastWriteTime.ToLocalTime(),
					CreationTime = q.CreationTime.ToLocalTime(),
					LastWriteUser = q.LastWriteUser,
					CreationUser = q.CreationUser
				};

				ViewBag.InvoiceIsNative = isNative;
				return PartialView("~/Views/Accounting/EditorTemplates/InvoiceEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Invoice_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Invoice_Read([DataSourceRequest] DataSourceRequest request, DateTime? dateFrom, DateTime? dateTo, int invoiceAccountTypeId, int invoiceTypeId, int? documentStatusId,
			int saleTypeId, decimal? amountFrom, decimal? amountTo, int debtorId, int agencyId, int consultantId, string orderNo, string account, string passenger, string text, bool isExport, string sortMember = null, string sortDirection = null) {

			try {
				var lazyContext = LazyContext;
				var documentStatus = (DocumentStatus?)documentStatusId;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q1 = lazyContext.Invoice.Where(t => t.Id > 0);

				if (dateFrom != null)
					q1 = q1.Where(t => t.DocumentDate >= dateFrom);

				if (dateTo != null)
					q1 = q1.Where(t => t.DocumentDate <= dateTo);

				if (invoiceAccountTypeId != (int)AccountType.None)
					q1 = q1.Where(t => (int)t.AccountType == invoiceAccountTypeId);

				if (invoiceTypeId != (int)PaymentType.All)
					q1 = q1.Where(t => (int)t.InvoiceType == invoiceTypeId);

				if (documentStatus != null) {
					if (documentStatus == DocumentStatus.None) {
						q1 = q1.Where(t => t.InvoiceDetails.Count == 0);
					}
					else {
						q1 = q1.Where(t1 => t1.InvoiceDetails.Any(t2 => t2.DocumentStatus == documentStatus));
					}
				}

				if (saleTypeId > 0)
					q1 = q1.Where(t1 => t1.InvoiceDetails.Any(t2 => t2.SaleTypeId == saleTypeId));

				if (amountFrom != null)
					q1 = q1.Where(t1 => (t1.InvoiceType == InvoiceType.Invoice ? 1 : -1) * (t1.InvoiceDetails.Sum(t2 => (decimal?)(t2.Amount + t2.Tax + t2.PaymentTax)) ?? 0) >= amountFrom);

				if (amountTo != null)
					q1 = q1.Where(t1 => (t1.InvoiceType == InvoiceType.Invoice ? 1 : -1) * (t1.InvoiceDetails.Sum(t2 => (decimal?)(t2.Amount + t2.Tax + t2.PaymentTax)) ?? 0) <= amountTo);

				if (debtorId > 0)
					q1 = q1.Where(t => t.DebtorId == debtorId);

				if (agencyId > 0)
					q1 = q1.Where(t => t.AgencyId == agencyId);

				if (consultantId > 0)
					q1 = q1.Where(t1 => t1.InvoiceDetails.Any(t2 => t2.Trip.ConsultantId == consultantId));

				if (!string.IsNullOrEmpty(orderNo))
					q1 = q1.Where(t1 => t1.InvoiceDetails.Any(t2 => t2.Trip.DebtorOrderNo.ToLower() == orderNo.Trim().ToLower()));

				if (!string.IsNullOrEmpty(account)) {
					var predicate = PredicateBuilder.False<InvoiceDetail>();

					foreach (var row in account.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
						predicate = predicate.Or(t => t.Trip.Id.ToString().Contains(row) || (t.Trip.Title + " " + t.Trip.FirstName + " " + t.Trip.LastName).Trim().ToLower().Contains(row) || t.ChartOfAccount.Code.ToLower().Contains(row) || t.ChartOfAccount.Name.ToLower().Contains(row));
					}

					var invoiceDetailIds = lazyContext.InvoiceDetail.Where(predicate).Select(t => t.Id);
					q1 = q1.Where(t1 => t1.InvoiceDetails.Any(t2 => invoiceDetailIds.Contains(t2.Id)));
				}

				if (!string.IsNullOrEmpty(passenger)) {
					var predicate = PredicateBuilder.False<InvoiceDetail>();

					foreach (var row in passenger.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
						predicate = predicate.Or(t => t.Trip.TripPassengers.Any(t2 => t2.Id > 0 && (t2.Title + " " + t2.FirstName + " " + t2.LastName).Trim().ToLower().Contains(row)));
					}

					var invoiceDetailIds = lazyContext.InvoiceDetail.Where(predicate).Select(t => t.Id);
					q1 = q1.Where(t1 => t1.InvoiceDetails.Any(t2 => invoiceDetailIds.Contains(t2.Id)));
				}

				if (!string.IsNullOrEmpty(text)) {
					text = text.Trim().ToLower();
					q1 = q1.Where(t => t.DocumentNo.ToLower().Contains(text) || t.Comments.ToLower().Contains(text));
				}

				if (isExport) {
					if (!isAdministrator)
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var export = q1.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).ApplySorting(null, WebUtils.GetSortDescriptors(sortMember, sortDirection)).Select(row => new InvoiceExportModel {
						Debtor = row.Debtor.Name,
						AccountName = row.AccountName,
						AccountType = row.AccountType.GetEnumDescription(),
						DocumentType = row.InvoiceType.GetEnumDescription(),
						DocumentNo = row.DocumentNo,
						DocumentDate = row.DocumentDate,
						DocumentStatus = row.DocumentStatus.GetEnumDescription(),
						TotalAmount = row.TotalAmount,
						TotalTax = row.TotalTax,
						TotalDiscount = row.TotalDiscount,
						Comments = row.Comments
					}).ToList();

					var xlsx = new ExportToExcel<InvoiceExportModel>(export);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Invoices.xlsx");
				}

				var q2 = q1.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).ApplySorting(request.Groups, request.Sorts).ApplyPaging(request.Page, request.PageSize).ToList().ConvertAll(row => new InvoiceViewModel {
					InvoiceId = row.Id,
					InvoiceAccountName = row.AccountName,
					InvoiceAccountNameLink = row.AccountNameLink,
					InvoiceDocumentStatus = row.DocumentStatus,
					InvoiceAccountType = row.AccountType,
					InvoiceType = row.InvoiceType,
					InvoiceDocumentNo = row.DocumentNo,
					InvoiceDocumentDate = row.DocumentDate,
					InvoiceTotalAmount = (row.InvoiceType == InvoiceType.Invoice ? 1 : -1) * (row.InvoiceDetails.Sum(t => (decimal?)(t.Amount + t.Tax + t.PaymentTax)) ?? 0),
					InvoiceTotalTax = (row.InvoiceType == InvoiceType.Invoice ? 1 : -1) * (row.InvoiceDetails.Sum(t => (decimal?)(t.Tax + t.PaymentTax)) ?? 0),
					InvoiceTotalDiscount = (row.InvoiceType == InvoiceType.Invoice ? 1 : -1) * (row.InvoiceDetails.Sum(t => (decimal?)(t.Discount + t.DiscountTax)) ?? 0),
					InvoiceIsIssued = row.IsIssued,
					InvoiceCanEdit = row.CanEdit(false, isSuperUser),
					InvoiceCanDelete = row.CanDelete(false, isAdministrator, isSuperUser),
					InvoiceCanUndo = row.CanUndo(),
					InvoiceCanReissue = row.CanReissue(false),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				});

				var q4 = q1.ToList();

				decimal totalAmount = q4.Sum(t1 => (decimal?)(t1.InvoiceType == InvoiceType.Invoice ? 1 : -1) * (t1.InvoiceDetails.Sum(t2 => (decimal?)(t2.Amount + t2.Tax)) ?? 0)) ?? 0;
				decimal totalTax = q4.Sum(t1 => (decimal?)(t1.InvoiceType == InvoiceType.Invoice ? 1 : -1) * (t1.InvoiceDetails.Sum(t2 => (decimal?)t2.Tax) ?? 0)) ?? 0;
				decimal totalDiscount = q4.Sum(t1 => (decimal?)(t1.InvoiceType == InvoiceType.Invoice ? 1 : -1) * (t1.InvoiceDetails.Sum(t2 => (decimal?)(t2.Discount + t2.DiscountTax)) ?? 0)) ?? 0;

				var aggregateResults = new List<AggregateResult> {
					new AggregateResult(totalAmount, new SumFunction { FunctionName = "Sum", SourceField = "InvoiceTotalAmount", MemberType = typeof(decimal) }),
					new AggregateResult(totalTax, new SumFunction { FunctionName = "Sum", SourceField = "InvoiceTotalTax", MemberType = typeof(decimal) }),
					new AggregateResult(totalDiscount, new SumFunction { FunctionName = "Sum", SourceField = "InvoiceTotalDiscount", MemberType = typeof(decimal) }),
				};

				var result = await Task.Run(() => new DataSourceResult {
					Data = q2,
					Total = q4.Count,
					AggregateResults = aggregateResults
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Invoice_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Invoice_CreateOrUpdate(InvoiceViewModel model, bool isNew) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				var lazyContext = LazyContext;

				if (!lazyContext.Invoice.Any(t => t.Id == model.InvoiceId))
					throw new UnreportedException(AppConstants.RecordCannotBeCreated);

				var invoiceCommon = new InvoiceCommon(HttpContext);

				invoiceCommon.CreateOrUpdate(model, -1, !isNew, !isNew);
				invoiceCommon.CreateOrUpdateCustomerTransaction(lazyContext, lazyContext.Invoice.Find(model.InvoiceId));

				return Json(new { Model = model, Message = string.Empty });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Invoice_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> InvoiceWithDetail_CreateOrUpdate(InvoiceViewModel model, InvoiceDetailViewModel detailModel, bool isNew) {
			try {
				if (model.InvoiceAccountType == AccountType.Client) {
					detailModel.InvoiceDetailChartOfAccountId = -1;
				}
				else {
					detailModel.InvoiceDetailTripId = -1;
				}

				ModelState.Clear();
				TryValidateModel(model);

				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				var lazyContext = LazyContext;
				string message = string.Empty;

				new InvoiceDetailCommon(HttpContext).CreateOrUpdate(lazyContext, model, detailModel, isNew);
				var invoice = lazyContext.Invoice.Include(t => t.InvoiceDetails).Include(t => t.Debtor).Single(t => t.Id == model.InvoiceId);
				new InvoiceCommon(HttpContext).CreateOrUpdateCustomerTransaction(lazyContext, invoice);

				if (detailModel.InvoiceDetailAvailableCredit < 0)
					message = string.Format("This operation has resulted in the debtor's credit limit being exceeded by {0:c2}.", -detailModel.InvoiceDetailAvailableCredit);

				model.InvoiceDebtorId = invoice.DebtorId;
				model.InvoiceSubDebtorId = invoice.SubDebtorId;
				model.InvoiceDebtorName = invoice.Debtor.Name;
				model.InvoiceDebtorCurrencyId = invoice.DebtorCurrencyId;
				model.InvoiceDebtorExchangeRate = invoice.DebtorExchangeRate;

				model.InvoiceTotalDiscount = invoice.TotalDiscount;
				model.InvoiceTotalDiscountRate = invoice.TotalDiscountRate * 100;
				model.InvoiceTotalTax = invoice.TotalTax;
				model.InvoiceTotalTaxRate = invoice.TotalTaxRate * 100;
				model.InvoiceTotalAmount = invoice.TotalAmount;

				return Json(new { Model = model, Message = message });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InvoiceWithDetail_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Invoice_Delete([DataSourceRequest] DataSourceRequest request, InvoiceViewModel model, bool overrideValidation = false) {
			try {
				new InvoiceCommon(HttpContext).Delete(LazyContext, model, overrideValidation);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Invoice_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Invoice_UpdateModel(InvoiceViewModel model, int tripId, int addressId, string source) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.Invoice.Find(model.InvoiceId <= 0 ? -1 : model.InvoiceId);

				switch (source) {
					default:
						if (model.InvoiceId <= 0)
							model.InvoiceDocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Invoice");

						model.InvoiceTotalDiscount = q.TotalDiscount;
						model.InvoiceTotalDiscountRate = q.TotalDiscountRate;
						model.InvoiceTotalTax = q.TotalTax;
						model.InvoiceTotalTaxRate = q.TotalTaxRate;
						model.InvoiceTotalAmount = q.TotalAmount;
						break;
					case "DebtorId":
					case "TripId":
						if (tripId == 0)
							tripId = q.InvoiceDetails.FirstOrDefault()?.TripId ?? 0;

						if (tripId > 0) {
							var trip = lazyContext.Trip.Find(tripId);
							model.InvoiceDebtorOrderNo = trip.DebtorOrderNo;
							model.InvoiceDebtorContactId = trip.DebtorBookedById;
						}

						if ((model.InvoiceDebtorId ?? 0) <= 0)
							break;

						var debtor = lazyContext.Debtor.Find(model.InvoiceDebtorId)?.BillingHeadDebtor;

						if (debtor == null)
							break;

						if (debtor.Id != model.InvoiceDebtorId) {
							model.InvoiceSubDebtorId = model.InvoiceDebtorId;
							model.InvoiceDebtorId = debtor.Id;
						}

						model.InvoiceDebtorName = debtor.Name;
						model.InvoiceDebtorCurrencyId = debtor.CurrencyId;
						model.InvoiceDebtorExchangeRate = debtor.Currency.GetExchangeRate();

						model.InvoicePaymentTerms = debtor.PaymentTerm.Name;
						model.InvoiceBalanceDueDate = (model.InvoiceDocumentDate ?? DateTime.MinValue).AddDays(debtor.PaymentTerm.Term);

						if (model.InvoiceDebtorContactId <= 0 && debtor.DebtorContacts.Count == 1) {
							var contact = debtor.DebtorContacts.OrderBy(t => t.IsDefault ? 0 : 1).FirstOrDefault();
							model.InvoiceDebtorContactId = contact.Id;
						}

						var address = debtor.DebtorAddresses.OrderBy(t => t.IsDefault ? 0 : 1).FirstOrDefault();

						if (address == null) {
							model.InvoiceDebtorAddress1 = string.Empty;
							model.InvoiceDebtorAddress2 = string.Empty;
							model.InvoiceDebtorLocality = string.Empty;
							model.InvoiceDebtorRegion = string.Empty;
							model.InvoiceDebtorPostCode = string.Empty;
							model.InvoiceDebtorCountryCode = string.Empty;
						}
						else {
							model.InvoiceDebtorAddress1 = address.Address1;
							model.InvoiceDebtorAddress2 = address.Address2;
							model.InvoiceDebtorLocality = address.Locality;
							model.InvoiceDebtorRegion = address.Region;
							model.InvoiceDebtorPostCode = address.PostCode;
							model.InvoiceDebtorCountryCode = address.CountryCode;
						}

						break;
					case "AddressId":
						if (addressId <= 0)
							break;

						address = lazyContext.DebtorAddress.Find(addressId);

						model.InvoiceDebtorAddress1 = address.Address1;
						model.InvoiceDebtorAddress2 = address.Address2;
						model.InvoiceDebtorLocality = address.Locality;
						model.InvoiceDebtorRegion = address.Region;
						model.InvoiceDebtorPostCode = address.PostCode;
						model.InvoiceDebtorCountryCode = address.CountryCode;
						break;
				}

				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Invoice_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Invoice_Reissue(int invoiceId, InvoiceType invoiceType, bool autoMatch) {
			try {
				var model = new InvoiceCommon(HttpContext).Reissue(LazyContext, invoiceId, invoiceType, autoMatch);
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Invoice_Reissue", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> InvoiceDetail_Edit(int invoiceId, int invoiceDetailId, AccountType accountType, bool isTaxIncluded, bool isNew) {
			try {
				if (invoiceDetailId == -1)
					return PartialView("~/Views/Accounting/EditorTemplates/InvoiceDetailEdit.cshtml");

				var lazyContext = LazyContext;
				InvoiceDetail q = null;

				if (invoiceDetailId == 0) {
					q = new InvoiceDetail {
						Id = 0,
						InvoiceId = invoiceId,
						DocumentStatus = DocumentStatus.Open,
						TripId = -1,
						Trip = new Trip { Id = -1 },
						TripLineId = -1,
						TripLine = new TripLine { Id = -1 },
						TripLineAirPassengerId = -1,
						TripLineAirPassenger = new TripLineAirPassenger { Id = -1 },
						ChartOfAccountId = -1,
						ChartOfAccount = new ChartOfAccount { Id = -1 },
						SaleTypeId = -1,
						SaleType = new SaleType { Id = -1 },
						DiscountReasonId = -1,
						CreditorId = -1,
						SupplierId = -1,
						AirlineId = -1,
						DocumentNo = string.Empty,
						ConfirmationNo = string.Empty,
						Invoice = lazyContext.Invoice.Find(invoiceId) ?? new Invoice {
							Id = 0,
							AccountType = accountType,
							DebtorId = -1,
							Debtor = new Debtor { Id = -1 }
						}
					};
				}
				else {
					q = lazyContext.InvoiceDetail.Find(invoiceDetailId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				var rateModel = new RateModel {
					Discount = q.Discount,
					DiscountTax = q.DiscountTax,
					IsTaxIncluded = isTaxIncluded,
					IsFormBinding = true
				};

				var rates = new AccountingRates<InvoiceDetail>(HttpContext, q, rateModel);
				rates.SetRates(new List<string> { "Tax" });

				var model = new InvoiceDetailViewModel {
					InvoiceDetailId = q.Id,
					InvoiceId = q.InvoiceId,
					InvoiceDetailDocumentStatus = q.DocumentStatus,
					InvoiceDetailAccountType = q.Invoice.AccountType,
					InvoiceDetailTripLineType = q.TripLine.TripLineType,
					InvoiceDetailTripId = q.TripId <= 0 ? null : q.TripId,
					InvoiceDetailTripLineId = q.TripLineId,
					InvoiceDetailTripLineAirPassengerId = q.Invoice.AccountType == AccountType.Client && q.TripLineAirPassengerId <= 0 ? null : q.TripLineAirPassengerId,
					InvoiceDetailChartOfAccountId = q.ChartOfAccountId,
					InvoiceDetailSaleTypeId = q.Id <= 0 && q.Invoice.AccountType == AccountType.Client ? null : q.SaleTypeId,
					InvoiceDetailDiscount = isTaxIncluded ? q.Discount + q.DiscountTax : q.Discount,
					InvoiceDetailDiscountRate = rateModel.DiscountRate,
					InvoiceDetailDiscountTax = q.DiscountTax,
					InvoiceDetailDiscountTaxRate = rateModel.DiscountTaxRate,
					InvoiceDetailDiscountReasonId = q.DiscountReasonId,
					InvoiceDetailCreditorId = q.CreditorId,
					InvoiceDetailSupplierId = q.SupplierId,
					InvoiceDetailAirlineId = q.AirlineId,
					InvoiceDetailDocumentNo = q.DocumentNo,
					InvoiceDetailConfirmationNo = q.ConfirmationNo,
					InvoiceDetailAmount = isTaxIncluded ? q.Amount + q.Tax : q.Amount,
					InvoiceDetailTax = q.Tax,
					InvoiceDetailTaxRate = rateModel.TaxRate,
					InvoiceDetailTotalAmount = q.InvoiceDetailTotalAmount,
					InvoiceDetailDescription = q.Description,
					InvoiceDetailIsTaxApplicable = q.IsTaxApplicable,
                    InvoiceDetailIsPayment = q.IsPayment,
                    InvoiceDetailIsNew = isNew
				};

				return PartialView("~/Views/Accounting/EditorTemplates/InvoiceDetailGridEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InvoiceDetail_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> InvoiceDetail_Read([DataSourceRequest] DataSourceRequest request, int parentId, bool isNew) {
			try {
				const bool isTaxIncluded = true;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q = LazyContext.InvoiceDetail.Where(t => t.InvoiceId == parentId).AsEnumerable().OrderBy(t => t.IsPayment ? 1 : 0).ThenBy(t => t.TripLine.TripLineSelections.OrderBy(t2 => t2.QuoteNo == 0 ? 0 : 1).FirstOrDefault()?.SeqNo ?? 0);

				var result = await q.Select(row => new InvoiceDetailViewModel {
					InvoiceDetailId = row.Id,
					InvoiceId = row.InvoiceId,
					InvoiceDetailDocumentStatus = row.DocumentStatus,
					InvoiceDetailAccountType = row.Invoice.AccountType,
					InvoiceDetailAccountNameLink = row.AccountNameLink.Replace("Not Specified", string.Empty),
					InvoiceDetailSaleType = row.SaleTypeId > 0 ? row.SaleType.Name : string.Empty,
					InvoiceDetailAmount = (isTaxIncluded ? row.Amount + row.Tax : row.Amount) + row.PaymentTax,
					InvoiceDetailTax = row.Tax,
					InvoiceDetailDiscount = isTaxIncluded ? row.Discount + row.DiscountTax : row.Discount,
					InvoiceDetailIsNew = isNew,
					InvoiceDetailCanEdit = row.CanEdit(isNew, isSuperUser),
					InvoiceDetailCanDelete = row.CanDelete(isNew, isSuperUser),
					InvoiceDetailCanUndo = row.CanUndo(),
					InvoiceDetailCanReissue = row.CanReissue(false),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InvoiceDetail_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> InvoiceDetail_Delete([DataSourceRequest] DataSourceRequest request, InvoiceDetailViewModel model) {
			try {
				new InvoiceDetailCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InvoiceDetail_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> InvoiceDetail_UpdateModel(InvoiceViewModel model, InvoiceDetailViewModel detailModel, int standardCommentId, string source) {
			try {
				var lazyContext = LazyContext;

				var q = lazyContext.InvoiceDetail.Find(detailModel.InvoiceDetailId <= 0 ? -1 : detailModel.InvoiceDetailId);

				if (detailModel.InvoiceDetailTripLineId <= 0)
					detailModel.InvoiceDetailTripLineAirPassengerId = -1;

				q.InvoiceId = model.InvoiceId;
				q.TripId = detailModel.InvoiceDetailTripId ?? -1;
				q.TripLineId = detailModel.InvoiceDetailTripLineId ?? -1;
				q.TripLineAirPassengerId = detailModel.InvoiceDetailTripLineAirPassengerId ?? -1;
				q.ChartOfAccountId = detailModel.InvoiceDetailChartOfAccountId ?? -1;
				q.SaleTypeId = detailModel.InvoiceDetailSaleTypeId ?? -1;
				q.Amount = detailModel.InvoiceDetailAmount;
				q.Tax = detailModel.InvoiceDetailTax;
				q.Discount = detailModel.InvoiceDetailDiscount;
				q.DiscountTax = detailModel.InvoiceDetailDiscountTax;

				q.Invoice ??= lazyContext.Invoice.Find(model.InvoiceId <= 0 ? -1 : model.InvoiceId);

				q.Invoice.AccountType = model.InvoiceAccountType;
				q.Invoice.InvoiceType = model.InvoiceType;
				q.Invoice.DocumentDate = model.InvoiceDocumentDate ?? DateTime.Today;
				q.Invoice.DebtorId = model.InvoiceDebtorId ?? -1;

				var sources = new List<string> { source };

				switch (source) {
					case "TripLineId":
					case "TripLineAirPassengerId":
						if (q.TripLine == null || q.TripLineId <= 0)
							break;

						detailModel.InvoiceDetailDescription = q.TripLine.GetTravelDocumentInvoiceDetails(lazyContext, HttpContext.CurrentCustomerId(), tripLineAirPassengerId: q.TripLineAirPassengerId);
						detailModel.InvoiceDetailTripLineType = q.TripLine.TripLineType;
						detailModel.InvoiceDetailSaleTypeId = q.TripLine.SaleType.Id;
						detailModel.InvoiceDetailDiscount = q.TripLine.Discount;
						detailModel.InvoiceDetailDiscountReasonId = q.TripLine.DiscountReason.Id;
						detailModel.InvoiceDetailAmount = q.TripLine.AmountPayable;

						detailModel.InvoiceDetailCreditorId = q.TripLine.Creditor.Id;
						detailModel.InvoiceDetailSupplierId = q.TripLine.Supplier.Id;
						detailModel.InvoiceDetailAirlineId = q.TripLine.TripLineType == TripLineType.Air ? q.TripLine.TripLineAir.AirlineId : -1;
						detailModel.InvoiceDetailDocumentNo = q.TripLine.DocumentNo;
						detailModel.InvoiceDetailConfirmationNo = q.TripLine.ConfirmationNo;

						q.SaleTypeId = q.TripLine.SaleType.Id;
						q.Discount = q.TripLine.Discount;

						sources.Add("SaleTypeId");
						break;
					case "StandardCommentId":
						detailModel.InvoiceDetailDescription = lazyContext.StandardComment.Find(standardCommentId)?.Comment ?? string.Empty;
						break;
				}

				detailModel.InvoiceDetailTotalAmount = q.InvoiceDetailTotalAmount;
				detailModel.InvoiceDetailIsTaxApplicable = q.IsTaxApplicable;

				var rateModel = new RateModel {
					Discount = detailModel.InvoiceDetailDiscount,
					DiscountRate = detailModel.InvoiceDetailDiscountRate / 100,
					DiscountTax = detailModel.InvoiceDetailDiscountTax,
					IsTaxIncluded = model.InvoiceIsTaxIncluded
				};

				var rates = new AccountingRates<InvoiceDetail>(HttpContext, q, rateModel);
				bool result = rates.SetRates(sources, detailModel.InvoiceDetailAmount, detailModel.InvoiceDetailTax, detailModel.InvoiceDetailId);

				if (result) {
					detailModel.InvoiceDetailDiscount = rateModel.DiscountGross;
					detailModel.InvoiceDetailDiscountRate = rateModel.DiscountRate * 100;
					detailModel.InvoiceDetailDiscountTax = rateModel.DiscountTax;
					detailModel.InvoiceDetailDiscountTaxRate = rateModel.DiscountTaxRate * 100;

					detailModel.InvoiceDetailAmount = rateModel.AmountGross;
					detailModel.InvoiceDetailTax = rateModel.Tax;
					detailModel.InvoiceDetailTaxRate = rateModel.TaxRate * 100;
					detailModel.InvoiceDetailTotalAmount = q.InvoiceDetailTotalAmount;
				}

				return Json(new { Model = model, DetailModel = detailModel, UpdateRateModel = result });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InvoiceDetail_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> InvoiceAdd_Create(int tripId, int[] tripLineIds, int[] passengerIds, bool ignoreReceiptedAmount, bool deductCreditCardPayments, bool overrideDoNotGenerateInvoiceLine) {
			try {
				if (tripLineIds == null || tripLineIds.Length == 0)
					throw new UnreportedException("No trip lines have been selected.");

				var lazyContext = LazyContext;
                var invoiceModel = new InvoiceCommon(HttpContext).Create(lazyContext, tripId, tripLineIds, passengerIds, ignoreReceiptedAmount, deductCreditCardPayments, overrideDoNotGenerateInvoiceLine);

                var trip = lazyContext.Trip.Find(tripId);
                return Json(new { invoiceModel.InvoiceId, invoiceModel.InvoiceDebtorId, trip.BalanceDue });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "InvoiceAdd_Create", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Invoice_Report(IssuedDocumentType issuedDocumentType, int invoiceId, int tripId, int quoteNo = 0, int[] tripLineIds = null, int[] passengerIds = null) {
			try {
				var lazyContext = LazyContext;
				var invoice = lazyContext.Invoice.Find(invoiceId);

                TypeReportSource reportSource;
                
				if (HttpContext.CustomerSettings().IsManagementCustomer) {
					reportSource = AccountingDataSources.GetCustomerInvoiceReportSource(HttpContext.CurrentCustomerId(), invoice);
				}
				else {
					reportSource = AccountingDataSources.GetInvoiceReportSource(lazyContext, HttpContext.CurrentCustomerId(), issuedDocumentType, await HttpContext.TravelDocumentTimeFormat(Cache), invoiceId, tripId, quoteNo, string.Join(",", tripLineIds ?? new int[] { 0 }), string.Join(",", passengerIds ?? new int[] { 0 }), invoice.Debtor.IsTaxInInvoiceLineAmount, HttpContext.Now(), HttpContext.UserFullName(), HttpContext.Today());
				}

				return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Invoice_Report", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Invoice_IssueDocument(IssuedDocumentType issuedDocumentType, int invoiceId, int tripId = 0, int quoteNo = 0, int[] tripLineIds = null, int[] passengerIds = null) {
			try {
				new InvoiceCommon(HttpContext).IssueDocument(LazyContext, issuedDocumentType, await HttpContext.TravelDocumentTimeFormat(Cache), invoiceId, tripId, quoteNo, tripLineIds, passengerIds);
				return Json(true);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Invoice_IssueDocument", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Invoice_EmailDocument(IssuedDocumentType issuedDocumentType, int invoiceId, int tripId, string from, string to, string cc, string bcc, string subject, string body, IEnumerable<IFormFile> attachments) {
			try {
				var lazyContext = LazyContext;

				var invoice = lazyContext.Invoice.Find(invoiceId);
				invoice.UpdateDocumentStatus(lazyContext, DocumentStatus.Closed);

				IssuedDocument q = null;
				List<MailAttachment> mailAttachments = null;

				if (issuedDocumentType == IssuedDocumentType.Invoice) {
					q = lazyContext.IssuedDocument.SingleOrDefault(t => t.InvoiceId == invoiceId && t.IssuedDocumentType == issuedDocumentType);
				}
				else {
					q = lazyContext.IssuedDocument.Where(t => t.TripId == tripId && t.IssuedDocumentType == issuedDocumentType).ToList().LastOrDefault();
				}

				if (q == null)
					throw new UnreportedException(AppConstants.RecordNotFound);

				mailAttachments = new List<MailAttachment> {
					new MailAttachment(q.Document, q.FileName, q.FileContentType)
				};

				if (attachments != null) {
					foreach (var attachment in attachments) {
						mailAttachments.Add(new MailAttachment(attachment.OpenReadStream().StreamToBytes(), attachment.FileName, attachment.ContentType));
					}
				}

				await Mail.Instance.SendMailAsync(to, cc, bcc, subject, body, mailAttachments.ToArray(), from);
				return Json(true);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Invoice_EmailDocument", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Invoice_ExportPdf(IssuedDocumentType issuedDocumentType, int invoiceId, int tripId, int quoteNo = 0, string tripLineIds = null, string passengerIds = null, bool suppressReadOnlyException = false) {
			try {
				var lazyContext = LazyContext;

				var invoice = lazyContext.Invoice.Find(invoiceId);
				invoice.UpdateDocumentStatus(lazyContext, DocumentStatus.Closed);

				if (invoice.CanEdit(false, false))
					return RedirectToAction("Invoices", "Accounting", suppressReadOnlyException ? null : new { message = "Only read-only invoices can be exported.", messageType = MessageType.Warning });

				string fileName = null;

				if (invoiceId > 0) {
					fileName = string.Format("{0}.pdf", IssuedDocument.GetInvoiceName(invoice.InvoiceType, invoice.DocumentNo));
				}
				else {
					fileName = string.Format("{0}.pdf", IssuedDocument.GetStatementName(lazyContext, tripId, quoteNo));
				}

				TypeReportSource reportSource;

				if (HttpContext.CustomerSettings().IsManagementCustomer) {
					reportSource = AccountingDataSources.GetCustomerInvoiceReportSource(HttpContext.CurrentCustomerId(), invoice);
				}
				else {
					reportSource = AccountingDataSources.GetInvoiceReportSource(lazyContext, HttpContext.CurrentCustomerId(), issuedDocumentType, await HttpContext.TravelDocumentTimeFormat(Cache), invoiceId, tripId, quoteNo, tripLineIds, passengerIds, invoice.Debtor.IsTaxInInvoiceLineAmount, HttpContext.Now(), HttpContext.UserFullName(), HttpContext.Today());
				}

				var result = Utils.ExportToPdf(reportSource);
				return File(result.DocumentBytes, result.MimeType, fileName);
			}
			catch (Exception ex) {
				await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Invoice_ExportPdf", ex);
				return Redirect("/Shared/Error");
			}
		}

		public async Task<IActionResult> Invoice_ExportWord(IssuedDocumentType issuedDocumentType, int invoiceId, int tripId, int quoteNo = 0, string tripLineIds = null, string passengerIds = null) {
			try {
				var lazyContext = LazyContext;

				var invoice = lazyContext.Invoice.Find(invoiceId);
				invoice.UpdateDocumentStatus(lazyContext, DocumentStatus.Closed);

				if (invoice.CanEdit(false, false))
					return RedirectToAction("Invoices", "Accounting", new { message = "Only read-only invoices can be exported.", messageType = MessageType.Warning });

				string fileName = null;

				if (invoiceId > 0) {
					fileName = string.Format("{0}.docx", IssuedDocument.GetInvoiceName(invoice.InvoiceType, invoice.DocumentNo));
				}
				else {
					fileName = string.Format("{0}.docx", IssuedDocument.GetStatementName(lazyContext, tripId, quoteNo));
				}

				TypeReportSource reportSource;

				if (HttpContext.CustomerSettings().IsManagementCustomer) {
					reportSource = AccountingDataSources.GetCustomerInvoiceReportSource(HttpContext.CurrentCustomerId(), invoice);
				}
				else {
					reportSource = AccountingDataSources.GetInvoiceReportSource(lazyContext, HttpContext.CurrentCustomerId(), issuedDocumentType, await HttpContext.TravelDocumentTimeFormat(Cache), invoiceId, tripId, quoteNo, tripLineIds, passengerIds, invoice.Debtor.IsTaxInInvoiceLineAmount, HttpContext.Now(), HttpContext.UserFullName(), HttpContext.Today());
				}

				var result = Utils.ExportToWord(reportSource);
				return File(result.DocumentBytes, result.MimeType, fileName);
			}
			catch (Exception ex) {
				await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Invoice_ExportWord", ex);
				return Redirect("/Shared/Error");
			}
		}
		#endregion

		#region Journals
		public IActionResult Journals() {
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Journal_Edit(int journalId, bool isNative) {
			try {
				var context = Context;
				Journal q = null;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				if (journalId <= 0) {
					q = new Journal {
						Id = 0,
						DocumentNo = LastDocumentNo.DocumentNo(context, "Journal"),
						DocumentDate = DateTime.Today,
						DocumentStatus = DocumentStatus.Open,
						ReversalStatus = ReversalStatus.None
					};
				}
				else {
					q = context.Journal.Include(t => t.JournalDetails).ThenInclude(t => t.Trip).Include(t => t.JournalDetails).ThenInclude(t => t.TransactionDetailAllocations).SingleOrDefault(t => t.Id == journalId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				var model = new JournalViewModel {
					JournalId = q.Id,
					JournalDocumentStatus = q.DocumentStatus,
					JournalReversalStatus = q.ReversalStatus,
					JournalDocumentNo = q.DocumentNo,
					JournalDocumentDate = q.DocumentDate,
					JournalBalance = q.TotalAmount,
					JournalCanEdit = q.CanEdit(isSuperUser),
					JournalCanDelete = q.CanDelete(isSuperUser),
					JournalCanUndo = q.CanUndo(),
					JournalCanReverse = q.CanReverse(),
					LastWriteTime = q.LastWriteTime.ToLocalTime(),
					CreationTime = q.CreationTime.ToLocalTime(),
					LastWriteUser = q.LastWriteUser,
					CreationUser = q.CreationUser
				};

				ViewBag.JournalIsNative = isNative;
				return PartialView("~/Views/Accounting/EditorTemplates/JournalEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Journal_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Journal_Read([DataSourceRequest] DataSourceRequest request, DateTime? dateFrom, DateTime? dateTo, int accountTypeId, int? documentStatusId, decimal? amountFrom, decimal? amountTo, string account, string text, bool isExport, string sortMember = null, string sortDirection = null) {
			try {
				var lazyContext = LazyContext;
				var documentStatus = (DocumentStatus?)documentStatusId;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q1 = Journal.GetJournalQuery(lazyContext, HttpContext.CurrentDefaultAgencyId(), 0, dateFrom, dateTo, accountTypeId, documentStatusId, amountFrom, amountTo, account, text);

				if (isExport) {
					if (!isAdministrator)
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var export = q1.ApplySorting(null, WebUtils.GetSortDescriptors(sortMember, sortDirection)).SelectMany(t => t.JournalDetails).OrderByDescending(t => t.Journal.DocumentDate).ThenByDescending(t => t.Journal.DocumentNo).ToList().ConvertAll(row => new JournalExportModel {
						DocumentNo = row.Journal.DocumentNo,
						DocumentDate = row.Journal.DocumentDate,
						DocumentStatus = row.Journal.DocumentStatus.GetEnumDescription(),
						ReversalStatus = row.Journal.ReversalStatus.GetEnumDescription(),
						AccountType = row.AccountType.GetEnumDescription(),
						AccountName = row.AccountName,
						Debit = row.SignType == SignType.Debit ? row.Amount : (decimal?)null,
						Credit = row.SignType == SignType.Debit ? (decimal?)null : -row.Amount,
						Comments = row.Comments
					});

					var xlsx = new ExportToExcel<JournalExportModel>(export);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Journals.xlsx");
				}

				var q2 = q1.ApplySorting(request.Groups, request.Sorts).ApplyPaging(request.Page, request.PageSize).ToList().ConvertAll(row => new JournalViewModel {
					JournalId = row.Id,
					JournalDocumentStatus = row.DocumentStatus,
					JournalReversalStatus = row.ReversalStatus,
					JournalDocumentNo = row.DocumentNo,
					JournalDocumentDate = row.DocumentDate,
					JournalComments = row.Comments,
					JournalTotalDebit = row.JournalDetails.Sum(t => (decimal?)(t.SignType == SignType.Debit ? t.Amount : 0)) ?? 0,
					JournalTotalCredit = row.JournalDetails.Sum(t => (decimal?)(t.SignType == SignType.Debit ? 0 : -t.Amount)) ?? 0,
					JournalBalance = row.JournalDetails.Sum(t => (decimal?)(t.SignType == SignType.Debit ? t.Amount : -t.Amount)) ?? 0,
					JournalCanEdit = row.CanEdit(isSuperUser),
					JournalCanDelete = row.CanDelete(isSuperUser),
					JournalCanUndo = row.CanUndo(),
					JournalCanReverse = row.CanReverse(),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				});

				decimal totalDebit = q1.ToList().Sum(t1 => t1.JournalDetails.Sum(t2 => (decimal?)(t2.SignType == SignType.Debit ? t2.Amount : 0)) ?? 0);
				decimal totalCredit = q1.ToList().Sum(t1 => t1.JournalDetails.Sum(t2 => (decimal?)(t2.SignType == SignType.Debit ? 0 : -t2.Amount)) ?? 0);

				var aggregateResults = new List<AggregateResult> {
					new AggregateResult(totalDebit, new SumFunction { FunctionName = "Sum", SourceField = "JournalTotalDebit", MemberType = typeof(decimal) }),
					new AggregateResult(totalCredit, new SumFunction { FunctionName = "Sum", SourceField = "JournalTotalCredit", MemberType = typeof(decimal) }),
					new AggregateResult(totalDebit + totalCredit, new SumFunction { FunctionName = "Sum", SourceField = "JournalBalance", MemberType = typeof(decimal) })
				};

				var result = await Task.Run(() => new DataSourceResult {
					Data = q2,
					Total = q1.Count(),
					AggregateResults = aggregateResults
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Journal_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Journal_CreateOrUpdate(JournalViewModel model, bool postJournal, bool isNew) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				var lazyContext = LazyContext;

				if (!lazyContext.Journal.Any(t => t.Id == model.JournalId))
					throw new UnreportedException(AppConstants.RecordCannotBeCreated);

				new JournalCommon(HttpContext).CreateOrUpdate(lazyContext, model, postJournal, !isNew);
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Journal_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> JournalWithDetail_CreateOrUpdate(JournalViewModel model, JournalDetailViewModel detailModel, bool isNew, bool postJournal) {
			try {
				switch (detailModel.JournalDetailAccountType) {
					case AccountType.Client:
						if ((detailModel.JournalDetailTripId ?? -1) == -1)
							throw new UnreportedException("Trip is required.");

						detailModel.JournalDetailDebtorId = -1;
						detailModel.JournalDetailCreditorId = -1;
						detailModel.JournalDetailChartOfAccountId = -1;
						break;
					case AccountType.Debtor:
						if ((detailModel.JournalDetailDebtorId ?? -1) == -1)
							throw new UnreportedException("Debtor is required.");

						detailModel.JournalDetailTripId = -1;
						detailModel.JournalDetailCreditorId = -1;
						detailModel.JournalDetailChartOfAccountId = -1;
						break;
					case AccountType.Creditor:
						if ((detailModel.JournalDetailCreditorId ?? -1) == -1)
							throw new UnreportedException("Creditor is required.");

						detailModel.JournalDetailTripId = -1;
						detailModel.JournalDetailDebtorId = -1;
						detailModel.JournalDetailChartOfAccountId = -1;
						break;
					case AccountType.GeneralLedger:
						if ((detailModel.JournalDetailChartOfAccountId ?? -1) == -1)
							throw new UnreportedException("GL Account is required.");

						detailModel.JournalDetailTripId = -1;
						detailModel.JournalDetailDebtorId = -1;
						detailModel.JournalDetailCreditorId = -1;
						break;
				}

				ModelState.Clear();
				TryValidateModel(model);

				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				var lazyContext = LazyContext;

				new JournalDetailCommon(HttpContext).CreateOrUpdate(lazyContext, model, detailModel, isNew, postJournal);
				var q = lazyContext.Journal.Include(t => t.JournalDetails).Single(t => t.Id == model.JournalId);

				model.JournalBalance = q.TotalAmount;
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "JournalWithDetail_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Journal_Delete([DataSourceRequest] DataSourceRequest request, JournalViewModel model) {
			try {
				new JournalCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Journal_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Journal_UpdateModel(JournalViewModel model) {
			try {
				var context = Context;
				var q = context.Journal.Include(t => t.JournalDetails).Single(t => t.Id == (model.JournalId <= 0 ? -1 : model.JournalId));

				if (model.JournalId <= 0)
					model.JournalDocumentNo = LastDocumentNo.DocumentNo(context, "Journal");

				model.JournalBalance = q.TotalAmount;
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Journal_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Journal_Reverse(int journalId, string type) {
			try {
				bool result = new JournalCommon(HttpContext).Reverse(LazyContext, journalId, type);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Journal_Reverse", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> JournalDetail_Edit(int journalId, int journalDetailId) {
			try {
				if (journalDetailId == -1)
					return PartialView("~/Views/Accounting/EditorTemplates/JournalDetailEdit.cshtml");

				var lazyContext = LazyContext;
				JournalDetail q = null;

				if (journalDetailId == 0) {
					q = new JournalDetail {
						Id = 0,
						JournalId = journalId,
						AccountType = AccountType.GeneralLedger,
						TripId = -1,
						DebtorId = -1,
						CreditorId = -1,
						ChartOfAccountId = -1,
						SignType = SignType.Debit,
						Comments = lazyContext.JournalDetail.Where(t => t.JournalId == journalId).OrderByDescending(t => t.Id).FirstOrDefault()?.Comments ?? string.Empty,
						Journal = lazyContext.Journal.Find(journalId) ?? new Journal {
							Id = journalId
						}
					};
				}
				else {
					q = lazyContext.JournalDetail.Find(journalDetailId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				var model = new JournalDetailViewModel {
					JournalDetailId = q.Id,
					JournalId = q.JournalId,
					JournalDetailAccountType = q.AccountType,
					JournalDetailTripId = q.TripId,
					JournalDetailDebtorId = q.DebtorId,
					JournalDetailCreditorId = q.CreditorId,
					JournalDetailChartOfAccountId = q.ChartOfAccountId,
					JournalDetailSignType = q.SignType,
					JournalDetailAmount = q.Amount,
					JournalDetailComments = q.Comments
				};

				return PartialView("~/Views/Accounting/EditorTemplates/JournalDetailGridEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "JournalDetail_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> JournalDetail_Read(int parentId) {
			try {
				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q = LazyContext.JournalDetail.Where(t => t.JournalId == parentId).Select(row => new JournalDetailViewModel {
					JournalDetailId = row.Id,
					JournalId = row.JournalId,
					JournalDetailAccountType = row.AccountType,
					JournalDetailAccountNameLink = row.AccountNameLink,
					JournalDetailTripId = row.TripId,
					JournalDetailDebtorId = row.DebtorId,
					JournalDetailCreditorId = row.CreditorId,
					JournalDetailChartOfAccountId = row.ChartOfAccountId,
					JournalDetailSignType = row.SignType,
					JournalDetailDebit = row.SignType == SignType.Debit ? row.Amount : (decimal?)null,
					JournalDetailCredit = row.SignType == SignType.Debit ? (decimal?)null : -row.Amount,
					JournalDetailComments = row.Comments,
					JournalDetailCanEdit = row.CanEdit(isSuperUser),
					JournalDetailCanDelete = row.CanDelete(isSuperUser),
					JournalDetailCanUndo = row.CanUndo(),
					JournalDetailCanReverse = row.CanReverse(),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				});

				var aggregateResults = new List<AggregateResult> {
					new AggregateResult(q.Sum(t => t.JournalDetailDebit) ?? 0, new SumFunction { FunctionName = "Sum", SourceField = "JournalDetailDebit", MemberType = typeof(decimal) }),
					new AggregateResult(q.Sum(t => t.JournalDetailCredit) ?? 0, new SumFunction { FunctionName = "Sum", SourceField = "JournalDetailCredit", MemberType = typeof(decimal) })
				};

				int total = q.Count();

				var result = await Task.Run(() => new DataSourceResult {
					Data = q,
					Total = total,
					AggregateResults = aggregateResults
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "JournalDetail_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> JournalDetail_Delete([DataSourceRequest] DataSourceRequest request, JournalDetailViewModel model) {
			try {
				new JournalDetailCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "JournalDetail_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Journal_Report(string outputType, int agencyId, int journalId, DateTime? dateFrom, DateTime? dateTo, int accountTypeId, int? documentStatusId, decimal? amountFrom, decimal? amountTo, string account, string text) {
			try {
				var reportSource = AccountingDataSources.GetJournalReportSource(Context, HttpContext.CurrentCustomerId(), await HttpContext.CurrentDefaultAgencyName(Cache), agencyId, journalId, dateFrom, dateTo, accountTypeId, documentStatusId, amountFrom, amountTo, account, text, HttpContext.Now(), HttpContext.UserFullName());

				RenderingResult result = null;
				string fileName = null;

				switch (outputType) {
					default:
						return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
					case "ExportPdf":
						result = Utils.ExportToPdf(reportSource);
						fileName = "Journals.pdf";
						break;
					case "ExportWord":
						result = Utils.ExportToWord(reportSource);
						fileName = "Journals.docx";
						break;
					case "ExportExcel":
						result = Utils.ExportToExcel(reportSource);
						fileName = "Journals.xlsx";
						break;
				}

				return File(result.DocumentBytes, result.MimeType, fileName);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Journal_Report", ex);

				if (outputType == "Report") {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
				else {
					return Redirect("/Shared/Error");
				}
			}
		}
		#endregion

		#region Adjustments
		public IActionResult Adjustments() {
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Adjustment_Edit(int adjustmentId, int tripId, bool isNative) {
			try {
				var lazyContext = LazyContext;
				Adjustment q = null;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				if (adjustmentId <= 0) {
					q = new Adjustment {
						Id = 0,
						DocumentStatus = DocumentStatus.Open,
						ReversalStatus = ReversalStatus.None,
						AdjustmentTypeId = -1,
						DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Adjustment"),
						DocumentDate = DateTime.Today,
						DebitType = DebitCreditType.Client,
						DebitTripId = tripId,
						DebitTripLineId = -1,
						DebitDebtorId = -1,
						DebitCreditorId = -1,
						DebitChartOfAccountId = -1,
						CreditType = DebitCreditType.Client,
						CreditTripId = -1,
						CreditTripLineId = -1,
						CreditDebtorId = -1,
						CreditCreditorId = -1,
						CreditChartOfAccountId = -1,
						SupplierId = -1,
						SaleTypeId = -1,
						GroupId = -1,
						CategoryId = -1,
						DestinationId = -1,
						ConsultantId = HttpContext.CurrentConsultantId(),
						AgentId = -1,
						SourceId = -1
					};
				}
				else {
					q = lazyContext.Adjustment.Find(adjustmentId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				var model = new AdjustmentViewModel {
					AdjustmentId = q.Id,
					AdjustmentDocumentStatus = q.DocumentStatus,
					AdjustmentReversalStatus = q.ReversalStatus,
					AdjustmentTypeId = q.AdjustmentTypeId,
					AdjustmentDocumentNo = q.DocumentNo,
					AdjustmentDocumentDate = q.DocumentDate,
					AdjustmentDebitAccountNameLink = q.Id <= 0 ? string.Empty : q.DebitAccountNameLink,
					AdjustmentDebitType = q.DebitType,
					AdjustmentDebitTripId = q.DebitType == DebitCreditType.Client ? q.DebitTripId <= 0 ? null : q.DebitTripId : q.DebitTripId,
					AdjustmentDebitTripLineId = q.DebitTripLineId,
					AdjustmentDebitDebtorId = q.DebitType == DebitCreditType.Debtor ? q.DebitDebtorId <= 0 ? null : q.DebitDebtorId : q.DebitDebtorId,
					AdjustmentDebitCreditorId = q.DebitType == DebitCreditType.Creditor ? q.DebitCreditorId <= 0 ? null : q.DebitCreditorId : q.DebitCreditorId,
					AdjustmentDebitChartOfAccountId = q.DebitType == DebitCreditType.GeneralLedger ? q.DebitChartOfAccountId <= 0 ? null : q.DebitChartOfAccountId : q.DebitChartOfAccountId,
					AdjustmentCreditAccountNameLink = q.Id <= 0 ? string.Empty : q.CreditAccountNameLink,
					AdjustmentCreditType = q.CreditType,
					AdjustmentCreditTripId = q.CreditType == DebitCreditType.Client ? q.CreditTripId <= 0 ? null : q.CreditTripId : q.CreditTripId,
					AdjustmentCreditTripLineId = q.CreditTripLineId,
					AdjustmentCreditDebtorId = q.CreditType == DebitCreditType.Debtor ? q.CreditDebtorId <= 0 ? null : q.CreditDebtorId : q.CreditDebtorId,
					AdjustmentCreditCreditorId = q.DebitType == DebitCreditType.Creditor ? q.CreditCreditorId <= 0 ? null : q.CreditCreditorId : q.CreditCreditorId,
					AdjustmentCreditChartOfAccountId = q.CreditType == DebitCreditType.GeneralLedger ? q.CreditChartOfAccountId <= 0 ? null : q.CreditChartOfAccountId : q.CreditChartOfAccountId,
					AdjustmentSupplierId = q.SupplierId,
					AdjustmentSaleTypeId = q.SaleTypeId,
					AdjustmentGroupId = q.GroupId,
					AdjustmentCategoryId = q.CategoryId,
					AdjustmentDestinationId = q.DestinationId,
					AdjustmentConsultantId = q.ConsultantId,
					AdjustmentAgentId = q.AgentId,
					AdjustmentSourceId = q.SourceId,
					AdjustmentAmount = q.Amount + q.Tax,
					AdjustmentComments = q.Comments,
					AdjustmentIsTaxApplicable = q.IsTaxApplicable,
					AdjustmentCanEdit = q.CanEdit(isAdministrator, isSuperUser),
					AdjustmentCanDelete = q.CanDelete(isAdministrator, isSuperUser),
					AdjustmentCanUndo = q.CanUndo(),
					AdjustmentCanReverse = q.CanReverse(),
					LastWriteTime = q.LastWriteTime.ToLocalTime(),
					CreationTime = q.CreationTime.ToLocalTime(),
					LastWriteUser = q.LastWriteUser,
					CreationUser = q.CreationUser
				};

				ViewBag.AdjustmentIsNative = isNative;
				return PartialView("~/Views/Accounting/EditorTemplates/AdjustmentEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Adjustment_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Adjustment_Read([DataSourceRequest] DataSourceRequest request, DateTime? dateFrom, DateTime? dateTo, int adjustmentTypeId, int? documentStatusId, decimal? amountFrom, decimal? amountTo, int supplierId, string debitAccount, string creditAccount, int consultantId, string text, bool isExport, string sortMember = null, string sortDirection = null) {
			try {
				var lazyContext = LazyContext;
				var documentStatus = (DocumentCombinedStatus?)documentStatusId;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q1 = lazyContext.Adjustment.Where(t => t.Id > 0);

				if (dateFrom != null)
					q1 = q1.Where(t => t.DocumentDate >= dateFrom);

				if (dateTo != null)
					q1 = q1.Where(t => t.DocumentDate <= dateTo);

				if (adjustmentTypeId > 0)
					q1 = q1.Where(t => t.AdjustmentTypeId == adjustmentTypeId);

				if (documentStatus != null) {
					if (documentStatus == DocumentCombinedStatus.Reversal || documentStatus == DocumentCombinedStatus.Reversed) {
						q1 = q1.Where(t => t.ReversalStatus == (documentStatus == DocumentCombinedStatus.Reversal ? ReversalStatus.Reversal : ReversalStatus.Reversed));
					}
					else {
						q1 = q1.Where(t => t.DocumentStatus == (DocumentStatus)documentStatus);
					}
				}

				if (amountFrom != null)
					q1 = q1.Where(t => t.Amount >= amountFrom);

				if (amountTo != null)
					q1 = q1.Where(t => t.Amount <= amountTo);

				if (supplierId > 0)
					q1 = q1.Where(t => t.SupplierId == supplierId);

				if (!string.IsNullOrEmpty(debitAccount)) {
					var predicate = PredicateBuilder.False<Adjustment>();

					foreach (var row in debitAccount.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
						predicate = predicate.Or(t => t.DebitTrip.Id.ToString().Contains(row) || (t.DebitTrip.Title + " " + t.DebitTrip.FirstName + " " + t.DebitTrip.LastName).Trim().ToLower().Contains(row) || t.DebitDebtor.Name.ToLower().Contains(row) || t.DebitCreditor.Name.ToLower().Contains(row) || t.DebitChartOfAccount.Code.ToLower().Contains(row) || t.DebitChartOfAccount.Name.ToLower().Contains(row));
					}

					q1 = q1.Where(predicate);
				}

				if (!string.IsNullOrEmpty(creditAccount)) {
					var predicate = PredicateBuilder.False<Adjustment>();

					foreach (var row in creditAccount.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
						predicate = predicate.Or(t => t.CreditTrip.Id.ToString().Contains(row) || (t.CreditTrip.Title + " " + t.CreditTrip.FirstName + " " + t.CreditTrip.LastName).Trim().ToLower().Contains(row) || t.CreditDebtor.Name.ToLower().Contains(row) || t.CreditCreditor.Name.ToLower().Contains(row) || t.CreditChartOfAccount.Code.ToLower().Contains(row) || t.CreditChartOfAccount.Name.ToLower().Contains(row));
					}

					q1 = q1.Where(predicate);
				}

				if (consultantId > 0)
					q1 = q1.Where(t => t.ConsultantId == consultantId);

				if (!string.IsNullOrEmpty(text)) {
					text = text.Trim().ToLower();
					q1 = q1.Where(t => t.DocumentNo.ToLower().Contains(text) || t.Comments.ToLower().Contains(text));
				}

				var q2 = q1.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).ApplySorting(request.Groups, request.Sorts).Select(row => new AdjustmentViewModel {
					AdjustmentId = row.Id,
					AdjustmentDocumentStatus = row.DocumentStatus,
					AdjustmentReversalStatus = row.ReversalStatus,
					AdjustmentTypeId = row.AdjustmentTypeId,
					AdjustmentDocumentNo = row.DocumentNo,
					AdjustmentDocumentDate = row.DocumentDate,
					AdjustmentDebitAccountName = row.DebitAccountName,
					AdjustmentDebitAccountNameLink = row.DebitAccountNameLink,
					AdjustmentDebitType = row.DebitType,
					AdjustmentCreditAccountName = row.CreditAccountName,
					AdjustmentCreditAccountNameLink = row.CreditAccountNameLink,
					AdjustmentCreditType = row.CreditType,
					AdjustmentAmount = row.Amount + row.Tax,
					AdjustmentComments = row.Comments,
					AdjustmentCanEdit = row.CanEdit(isAdministrator, isSuperUser),
					AdjustmentCanDelete = row.CanDelete(isAdministrator, isSuperUser),
					AdjustmentCanUndo = row.CanUndo(),
					AdjustmentCanReverse = row.CanReverse(),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				});

				if (isExport) {
					if (!isAdministrator)
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var export = q1.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).ApplySorting(null, WebUtils.GetSortDescriptors(sortMember, sortDirection)).Select(row => new AdjustmentExportModel {
						DebitAccountName = row.DebitAccountName,
						CreditAccountName = row.CreditAccountName,
						AdjustmentType = row.AdjustmentType.Name,
						DebitType = row.DebitType.GetEnumDescription(),
						CreditType = row.CreditType.GetEnumDescription(),
						DocumentNo = row.DocumentNo,
						DocumentDate = row.DocumentDate,
						DocumentStatus = row.DocumentStatus.GetEnumDescription(),
						ReversalStatus = row.ReversalStatus.GetEnumDescription(),
						Supplier = row.Supplier.Name,
						SaleType = row.SaleType.Name,
						Group = row.Group.Name,
						Category = row.Category.Name,
						Destination = row.Destination.Name,
						Consultant = row.Consultant.Name,
						Agent = row.Agent.Name,
						Source = row.Source.Name,
						Amount = row.Amount,
						Comments = row.Comments
					}).ToList();

					var xlsx = new ExportToExcel<AdjustmentExportModel>(export);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Adjustments.xlsx");
				}

				int[] gridIds = null;
				decimal totalAmount = 0;

				if (documentStatus == DocumentCombinedStatus.Open) {
					gridIds = q2.Select(t => t.AdjustmentId).ToArray();
					totalAmount = q1.Sum(t3 => (decimal?)t3.Amount) ?? 0;
				}

				var aggregateResults = new List<AggregateResult> {
					new AggregateResult(gridIds, new MinFunction { FunctionName = "Min", SourceField = "GridIds", MemberType = typeof(int[]) }),
					new AggregateResult(totalAmount, new SumFunction { FunctionName = "Sum", SourceField = "AdjustmentAmount", MemberType = typeof(decimal) })
				};

				int total = q2.Count();
				q2 = q2.ApplyPaging(request.Page, request.PageSize);

				var result = await Task.Run(() => new DataSourceResult {
					Data = q2,
					Total = total,
					AggregateResults = aggregateResults
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Adjustment_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Adjustment_CreateOrUpdate(AdjustmentViewModel model) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				new AdjustmentCommon(HttpContext).CreateOrUpdate(LazyContext, model);
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Adjustment_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Adjustment_Delete([DataSourceRequest] DataSourceRequest request, AdjustmentViewModel model) {
			try {
				new AdjustmentCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Adjustment_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Adjustment_UpdateModel(AdjustmentViewModel model, string source) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.Adjustment.Find(model.AdjustmentId <= 0 ? -1 : model.AdjustmentId);

				q.DocumentDate = model.AdjustmentDocumentDate ?? DateTime.Today;
				q.AdjustmentTypeId = model.AdjustmentTypeId ?? -1;
				q.DebitTripId = model.AdjustmentDebitTripId ?? -1;
				q.DebitTripLineId = model.AdjustmentDebitTripLineId ?? -1;
				q.DebitDebtorId = model.AdjustmentDebitDebtorId ?? -1;
				q.DebitCreditorId = model.AdjustmentDebitCreditorId ?? -1;
				q.DebitChartOfAccountId = model.AdjustmentDebitChartOfAccountId ?? -1;
				q.CreditTripId = model.AdjustmentCreditTripId ?? -1;
				q.CreditDebtorId = model.AdjustmentCreditDebtorId ?? -1;
				q.CreditCreditorId = model.AdjustmentCreditCreditorId ?? -1;
				q.CreditChartOfAccountId = model.AdjustmentCreditChartOfAccountId ?? -1;
				q.SaleTypeId = model.AdjustmentSaleTypeId ?? -1;
				q.Amount = model.AdjustmentAmount;

				switch (source) {
					case "AdjustmentTypeId":
						if (q.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.None)
							model.AdjustmentSaleTypeId = -1;

						break;
					case "DebitTripId":
						if (q.DebitTrip != null) {
							model.AdjustmentGroupId = q.DebitTrip.GroupId;
							model.AdjustmentCategoryId = q.DebitTrip.CategoryId;
							model.AdjustmentDestinationId = q.DebitTrip.DestinationId;
							model.AdjustmentConsultantId = q.DebitTrip.ConsultantId == -1 ? null : q.DebitTrip.ConsultantId;
							model.AdjustmentAgentId = q.DebitTrip.AgentId;
							model.AdjustmentSourceId = q.DebitTrip.SourceId;
						}

						break;
					case "CreditTripId":
						if (q.CreditTrip != null) {
							model.AdjustmentGroupId = q.CreditTrip.GroupId;
							model.AdjustmentCategoryId = q.CreditTrip.CategoryId;
							model.AdjustmentDestinationId = q.CreditTrip.DestinationId;
							model.AdjustmentConsultantId = q.CreditTrip.ConsultantId == -1 ? null : q.CreditTrip.ConsultantId;
							model.AdjustmentAgentId = q.CreditTrip.AgentId;
							model.AdjustmentSourceId = q.CreditTrip.SourceId;
						}

						break;
				}

				model.AdjustmentIsTaxApplicable = q.IsTaxApplicable;
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Adjustment_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Adjustment_ProcessSelections(int[] adjustmentIds) {
			try {
				bool result = new AdjustmentCommon(HttpContext).ProcessSelections(LazyContext, adjustmentIds);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Adjustment_ProcessSelections", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Adjustment_Reverse(int adjustmentId, string type) {
			try {
				bool result = new AdjustmentCommon(HttpContext).Reverse(LazyContext, adjustmentId, type);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Adjustment_Reverse", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region Vouchers
		public IActionResult Vouchers(string message = null, MessageType messageType = MessageType.Info, int timeoutSeconds = 30) {
			ViewBag.Message = message;
			ViewBag.MessageType = messageType;
			ViewBag.TimeoutSeconds = timeoutSeconds;
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Voucher_Edit(int voucherId, int tripId, bool isNative) {
			try {
				var lazyContext = LazyContext;
				Voucher q = null;

				const bool isTaxIncluded = true;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				if (voucherId <= 0) {
					q = new Voucher {
						Id = 0,
						DocumentStatus = DocumentStatus.Open,
						ReversalStatus = ReversalStatus.None,
						VoucherType = VoucherType.PrePaid,
						DocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Voucher"),
						DocumentDate = DateTime.Today,
						TripId = tripId,
						Trip = lazyContext.Trip.Find(tripId),
						CreditorId = -1,
						SupplierId = -1,
						ServiceTypeRateBasisId = -1,
						ServiceTypeRateBasis = new ServiceTypeRateBasis { Id = -1 },
						SupplierServiceId = -1,
						Duration = 1,
						PassengerClassification = PassengerClassification.Individual,
						SaleTypeId = -1,
						SaleType = new SaleType { Id = -1 },
						CurrencyId = -1,
						DiscountReasonId = -1
					};
				}
				else {
					q = lazyContext.Voucher.Find(voucherId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				int? voucherTripId = -1;
				int? voucherTripLineId = null;
				int? voucherCreditorId = -1;
				int? voucherSupplierId = -1;
				int? voucherSupplierServiceId = -1;
				int? voucherServiceTypeId = -1;

				if (q.Id > 0) {
					voucherTripId = q.TripId;
					voucherTripLineId = q.TripLineId <= 0 ? null : q.TripLineId;
					voucherCreditorId = q.CreditorId;
					voucherSupplierId = q.SupplierId;
					voucherSupplierServiceId = q.SupplierServiceId;
					voucherServiceTypeId = q.ServiceTypeId;
				}
				else {
					if (isNative) {
						voucherTripId = null;
						voucherCreditorId = null;
						voucherSupplierId = null;
						voucherSupplierServiceId = null;
						voucherServiceTypeId = null;
					}
					else {
						voucherTripId = q.TripId;
						voucherCreditorId = q.CreditorId;
						voucherSupplierId = q.SupplierId;
						voucherSupplierServiceId = q.SupplierServiceId;
						voucherServiceTypeId = q.ServiceTypeId;
					}
				}

				var model = new VoucherViewModel {
					VoucherId = q.Id,
					VoucherAccountNameLink = q.Id <= 0 ? string.Empty : q.AccountNameLink,
					VoucherDocumentStatus = q.DocumentStatus,
					VoucherReversalStatus = q.ReversalStatus,
					VoucherType = q.VoucherType,
					VoucherDocumentNo = q.DocumentNo,
					VoucherDocumentDate = q.DocumentDate,
					VoucherTripId = voucherTripId,
					VoucherTripLineId = voucherTripLineId,
					VoucherCreditorId = voucherCreditorId,
					VoucherSupplierId = voucherSupplierId,
					VoucherConfirmationNo = q.ConfirmationNo,
					VoucherServiceTypeId = voucherServiceTypeId,
					VoucherSupplierServiceId = voucherSupplierServiceId,
					VoucherSupplierName = q.SupplierName,
					VoucherSupplierAddress = q.GetSupplierAddress(lazyContext, true),
					VoucherSupplierAddress1 = q.SupplierAddress1,
					VoucherSupplierAddress2 = q.SupplierAddress2,
					VoucherSupplierLocality = q.SupplierLocality,
					VoucherSupplierRegion = q.SupplierRegion,
					VoucherSupplierPostCode = q.SupplierPostCode,
					VoucherSupplierCountryCode = q.SupplierCountryCode,
					VoucherSupplierContactFullName = q.SupplierContactFullName,
					VoucherSupplierContactPhoneNo = q.SupplierContactPhoneNo,
					VoucherSupplierContactTitle = q.SupplierContactTitle,
					VoucherSupplierContactName = q.SupplierContactName,
					VoucherSupplierContactPhoneHome = q.SupplierContactPhoneHome,
					VoucherSupplierContactPhoneWork = q.SupplierContactPhoneWork,
					VoucherSupplierContactMobile = q.SupplierContactMobile,
					VoucherSupplierContactFax = q.SupplierContactFax,
					VoucherSupplierContactEmail = q.SupplierContactEmail,
					VoucherIsOpenDated = q.StartDate == DateTime.MinValue && q.EndDate == DateTime.MinValue,
					VoucherStartDate = q.StartDate == DateTime.MinValue ? null : q.StartDate,
					VoucherStartTime = q.StartTime,
					VoucherStartDetails = q.StartDetails,
					VoucherEndDate = q.EndDate == DateTime.MinValue ? null : q.EndDate,
					VoucherEndTime = q.EndTime,
					VoucherEndDetails = q.EndDetails,
					VoucherDuration = q.Duration,
					VoucherDurationCoverageType = q.DurationCoverageType,
					VoucherServiceTypeRateBasisId = q.ServiceTypeRateBasisId,
					VoucherPassengerClassification = q.PassengerClassification,
					VoucherPaxAdultNo = q.PaxAdultNo,
					VoucherPaxAdultRate = q.PaxAdultRate,
					VoucherPaxAdultQty = q.PaxAdultQty,
					VoucherPaxChildNo = q.PaxChildNo,
					VoucherPaxChildRate = q.PaxChildRate,
					VoucherPaxChildQty = q.PaxChildQty,
					VoucherPaxInfantNo = q.PaxInfantNo,
					VoucherPaxInfantRate = q.PaxInfantRate,
					VoucherPaxInfantQty = q.PaxInfantQty,
					VoucherServiceComments = q.ServiceComments,
					VoucherSaleTypeId = q.SaleTypeId <= 0 ? null : q.SaleTypeId,
					VoucherCurrencyId = q.CurrencyId,
					VoucherAmount = q.Amount,
					VoucherTax = q.Tax,
					VoucherNetValue = q.GetNetValue(isTaxIncluded),
					VoucherCommission = q.Commission + q.CommissionTax,
					VoucherCommissionTax = q.CommissionTax,
					VoucherCommissionRate = q.CommissionRate,
					VoucherDiscount = q.Discount + q.DiscountTax,
					VoucherDiscountTax = q.DiscountTax,
					VoucherDiscountRate = q.DiscountRate,
					VoucherDiscountReasonId = q.DiscountReasonId,
					VoucherIncludePricing = q.IncludePricing,
					VoucherIsTaxIncluded = isTaxIncluded,
					VoucherIsTaxApplicable = q.IsTaxApplicable,
					VoucherComments = q.Comments,
					VoucherIsIssued = q.IsIssued,
					VoucherAgencyId = q.AgencyId,
					VoucherEmail = q.Trip.Email,
                    VoucherAgencyEmail = q.Trip.Agency.AgencyUserEmails.SingleOrDefault(t => t.UserId == HttpContext.UserId())?.Email ?? HttpContext.User.Identity.Name,
                    VoucherIsPaxNoApplicable = q.ServiceTypeRateBasis.IsPaxNoApplicable,
					VoucherCanEdit = q.CanEdit(isAdministrator, isSuperUser),
					VoucherCanDelete = q.CanDelete(isSuperUser),
					VoucherCanUndo = q.CanUndo(),
					VoucherCanReverse = q.CanReverse(),
					LastWriteTime = q.LastWriteTime.ToLocalTime(),
					CreationTime = q.CreationTime.ToLocalTime(),
					LastWriteUser = q.LastWriteUser,
					CreationUser = q.CreationUser
				};

				if (q.IsTaxApplicable) {
					decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), q.DocumentDate);
					model.VoucherCommissionTaxRate = taxRate;
					model.VoucherDiscountTaxRate = taxRate;
					model.VoucherTaxRate = taxRate;
				}

				ViewBag.VoucherIsNative = isNative;
				return PartialView("~/Views/Accounting/EditorTemplates/VoucherEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Voucher_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Voucher_Read([DataSourceRequest] DataSourceRequest request, DateTime? dateFrom, DateTime? dateTo, int voucherTypeId, int? documentStatusId, decimal? amountFrom, decimal? amountTo, int creditorId, int supplierId, string account, string passenger, string confirmationNo, string text, bool isExport, string sortMember = null, string sortDirection = null) {
			try {
				var lazyContext = LazyContext;
				var documentStatus = (DocumentCombinedStatus?)documentStatusId;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q = lazyContext.Voucher.Where(t => t.Id > 0);

				if (dateFrom != null)
					q = q.Where(t => t.DocumentDate >= dateFrom);

				if (dateTo != null)
					q = q.Where(t => t.DocumentDate <= dateTo);

				if (voucherTypeId != (int)VoucherType.None)
					q = q.Where(t => (int)t.VoucherType == voucherTypeId);

				if (documentStatus != null) {
					if (documentStatus == DocumentCombinedStatus.Reversal || documentStatus == DocumentCombinedStatus.Reversed) {
						q = q.Where(t => t.ReversalStatus == (documentStatus == DocumentCombinedStatus.Reversal ? ReversalStatus.Reversal : ReversalStatus.Reversed));
					}
					else {
						q = q.Where(t => t.DocumentStatus == (DocumentStatus)documentStatus);
					}
				}

				if (amountFrom != null)
					q = q.Where(t => t.Amount >= amountFrom);

				if (amountTo != null)
					q = q.Where(t => t.Amount <= amountTo);

				if (creditorId > 0)
					q = q.Where(t => t.CreditorId == creditorId);

				if (supplierId > 0)
					q = q.Where(t => t.SupplierId == supplierId);

				if (!string.IsNullOrEmpty(account)) {
					var predicate = PredicateBuilder.False<Voucher>();

					foreach (var row in account.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
						predicate = predicate.Or(t => t.Trip.Id.ToString().Contains(row) || (t.Trip.Title + " " + t.Trip.FirstName + " " + t.Trip.LastName).Trim().ToLower().Contains(row));
					}

					q = q.Where(predicate);
				}

				if (!string.IsNullOrEmpty(passenger)) {
					var predicate = PredicateBuilder.False<VoucherDetail>();

					foreach (var row in passenger.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
						predicate = predicate.Or(t => t.PassengerId > 0 && (t.Passenger.Title + " " + t.Passenger.FirstName + " " + t.Passenger.LastName).Trim().ToLower().Contains(row));
					}

					var voucherDetailIds = lazyContext.VoucherDetail.Where(predicate).Select(t => t.Id);
					q = q.Where(t1 => t1.VoucherDetails.Any(t2 => voucherDetailIds.Contains(t2.Id)));
				}

				if (!string.IsNullOrEmpty(confirmationNo)) {
					confirmationNo = confirmationNo.Trim().ToLower();
					q = q.Where(t => t.ConfirmationNo.ToLower().Contains(confirmationNo));
				}

				if (!string.IsNullOrEmpty(text)) {
					text = text.Trim().ToLower();
					q = q.Where(t => t.DocumentNo.ToLower().Contains(text) || t.Comments.ToLower().Contains(text));
				}

				if (isExport) {
					if (!isAdministrator)
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var export = q.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).ApplySorting(null, WebUtils.GetSortDescriptors(sortMember, sortDirection)).Select(row => new VoucherExportModel {
						AccountName = row.AccountName,
						DocumentType = row.VoucherType.GetEnumDescription(),
						DocumentNo = row.DocumentNo,
						DocumentDate = row.DocumentDate,
						DocumentStatus = row.DocumentStatus.GetEnumDescription(),
						ReversalStatus = row.ReversalStatus.GetEnumDescription(),

						ConfirmationNo = row.ConfirmationNo,
						ServiceType = row.ServiceType.Name,
						ServiceTypeRateBasis = row.ServiceTypeRateBasis.Name,
						SupplierService = row.SupplierService.Name,
						Duration = row.Duration,
						DurationCoverageType = row.DurationCoverageType.GetEnumDescription(),
						PassengerClassification = row.PassengerClassification.GetEnumDescription(),

						Supplier = row.SupplierName,
						SupplierAddress1 = row.SupplierAddress1,
						SupplierAddress2 = row.SupplierAddress2,
						SupplierLocality = row.SupplierLocality,
						SupplierRegion = row.SupplierRegion,
						SupplierPostCode = row.SupplierPostCode,
						SupplierCountryCode = row.SupplierCountryCode,
						SupplierContactTitle = row.SupplierContactTitle,
						SupplierContactName = row.SupplierContactName,
						SupplierContactPhoneHome = row.SupplierContactPhoneHome,
						SupplierContactPhoneWork = row.SupplierContactPhoneWork,
						SupplierContactMobile = row.SupplierContactMobile,
						SupplierContactFax = row.SupplierContactFax,
						SupplierContactEmail = row.SupplierContactEmail,

						StartDate = row.StartDate == DateTime.MinValue ? null : row.StartDate,
						StartTime = row.StartTime,
						StartDetails = row.StartDetails,
						EndDate = row.EndDate == DateTime.MinValue ? null : row.EndDate,
						EndTime = row.EndTime,
						EndDetails = row.EndDetails,

						PaxAdultNo = row.PaxAdultNo,
						PaxAdultRate = row.PaxAdultRate,
						PaxAdultQty = row.PaxAdultQty,
						PaxChildNo = row.PaxChildNo,
						PaxChildRate = row.PaxChildRate,
						PaxChildQty = row.PaxChildQty,
						PaxInfantNo = row.PaxInfantNo,
						PaxInfantRate = row.PaxInfantRate,
						PaxInfantQty = row.PaxInfantQty,

						ServiceComments = row.ServiceComments,
						SaleType = row.SaleType.Name,
						Currency = row.Currency.Name,
						Amount = row.Amount,
						Tax = row.Tax,
						AmountNet = row.GetNetValue(false),
						Commission = row.Commission,
						CommissionTax = row.CommissionTax,
						Discount = row.Discount,
						DiscountTax = row.DiscountTax,
						DiscountReason = row.DiscountReason.Name,
						Comments = row.Comments
					}).ToList();

					var xlsx = new ExportToExcel<VoucherExportModel>(export);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Vouchers.xlsx");
				}

				var result = await q.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).ApplySorting(request.Groups, request.Sorts).Select(row => new VoucherViewModel {
					VoucherId = row.Id,
					VoucherAccountName = row.AccountName,
					VoucherAccountNameLink = row.AccountNameLink,
					VoucherDocumentStatus = row.DocumentStatus,
					VoucherReversalStatus = row.ReversalStatus,
					VoucherType = row.VoucherType,
					VoucherDocumentNo = row.DocumentNo,
					VoucherDocumentDate = row.DocumentDate,
					VoucherAmount = row.Amount,
					VoucherTax = row.Tax,
					VoucherDiscount = row.Discount + row.DiscountTax,
					VoucherIsIssued = row.IsIssued,
					VoucherCanEdit = row.CanEdit(isAdministrator, isSuperUser),
					VoucherCanDelete = row.CanDelete(isSuperUser),
					VoucherCanUndo = row.CanUndo(),
					VoucherCanReverse = row.CanReverse(),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Voucher_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Voucher_CreateOrUpdate(VoucherViewModel model, decimal amount, decimal tax, decimal commissionTax, decimal discountTax) {
			try {
				if (model.VoucherIsOpenDated) {
					model.VoucherStartDate = DateTime.MinValue;
					model.VoucherEndDate = DateTime.MinValue;
					ModelState.Clear();
					TryValidateModel(model);
				}

				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				model.VoucherAmount = amount;
				model.VoucherTax = tax;
				model.VoucherCommissionTax = commissionTax;
				model.VoucherDiscountTax = discountTax;

				new VoucherCommon(HttpContext).CreateOrUpdate(LazyContext, model);

				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Voucher_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Voucher_Delete([DataSourceRequest] DataSourceRequest request, VoucherViewModel model) {
			try {
				new VoucherCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Voucher_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Voucher_UpdateModel(VoucherViewModel model, decimal amount, decimal tax, decimal commissionTax, decimal discountTax, string source) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.Voucher.Find(model.VoucherId <= 0 ? -1 : model.VoucherId);

				bool tripLineUpdated = false;

				model.VoucherAmount = amount;
				model.VoucherTax = tax;
				model.VoucherCommissionTax = commissionTax;
				model.VoucherDiscountTax = discountTax;

				q.DocumentDate = model.VoucherDocumentDate ?? DateTime.Today;
				q.TripId = model.VoucherTripId ?? -1;
				q.TripLineId = model.VoucherTripLineId ?? -1;
				q.CreditorId = model.VoucherCreditorId ?? -1;
				q.SupplierId = model.VoucherSupplierId ?? -1;
				q.SaleTypeId = model.VoucherSaleTypeId ?? -1;
				q.ServiceTypeRateBasisId = model.VoucherServiceTypeRateBasisId ?? -1;
				q.Commission = model.VoucherCommission;
				q.CommissionTax = model.VoucherCommissionTax;
				q.Discount = model.VoucherDiscount;
				q.DiscountTax = model.VoucherDiscountTax;
				q.Amount = model.VoucherAmount;
				q.Tax = model.VoucherTax;
				q.SupplierAddress1 = model.VoucherSupplierAddress1;
				q.SupplierAddress2 = model.VoucherSupplierAddress2;
				q.SupplierLocality = model.VoucherSupplierLocality;
				q.SupplierRegion = model.VoucherSupplierRegion;
				q.SupplierPostCode = model.VoucherSupplierPostCode;
				q.SupplierCountryCode = model.VoucherSupplierCountryCode;
				q.SupplierContactTitle = model.VoucherSupplierContactTitle;
				q.SupplierContactName = model.VoucherSupplierContactName;
				q.SupplierContactPhoneHome = model.VoucherSupplierContactPhoneHome;
				q.SupplierContactPhoneWork = model.VoucherSupplierContactPhoneWork;
				q.SupplierContactMobile = model.VoucherSupplierContactMobile;
				q.SupplierContactFax = model.VoucherSupplierContactFax;
				q.SupplierContactEmail = model.VoucherSupplierContactEmail;

				switch (source) {
					case "SupplierId":
						if (q.Supplier == null)
							break;

						if (q.Supplier.SaleTypeId > 0) {
							q.SaleTypeId = q.Supplier.SaleTypeId;
							model.VoucherSaleTypeId = q.Supplier.SaleTypeId;
						}

						if (q.SupplierId <= 0) {
							model.VoucherSupplierName = string.Empty;
						}
						else {
							model.VoucherSupplierName = q.Supplier.Name;
						}

						var address = lazyContext.SupplierAddress.Where(t => t.SupplierId == model.VoucherSupplierId).OrderByDescending(t => t.IsDefault).FirstOrDefault() ?? new SupplierAddress();
						var contact = lazyContext.SupplierContact.Where(t => t.SupplierId == model.VoucherSupplierId).OrderByDescending(t => t.IsDefault).FirstOrDefault() ?? new SupplierContact();

						q.SupplierAddress1 = address.Address1;
						q.SupplierAddress2 = address.Address2;
						q.SupplierLocality = address.Locality;
						q.SupplierRegion = address.Region;
						q.SupplierPostCode = address.PostCode;
						q.SupplierCountryCode = address.CountryCode;

						model.VoucherSupplierAddress = q.GetSupplierAddress(lazyContext, true);

						model.VoucherSupplierAddress1 = q.SupplierAddress1;
						model.VoucherSupplierAddress2 = q.SupplierAddress2;
						model.VoucherSupplierLocality = q.SupplierLocality;
						model.VoucherSupplierRegion = q.SupplierRegion;
						model.VoucherSupplierPostCode = q.SupplierPostCode;
						model.VoucherSupplierCountryCode = q.SupplierCountryCode;

						q.SupplierContactTitle = contact.Title;
						q.SupplierContactName = contact.Name;
						q.SupplierContactPhoneHome = contact.PhoneHome;
						q.SupplierContactPhoneWork = contact.PhoneWork;
						q.SupplierContactMobile = contact.Mobile;
						q.SupplierContactFax = contact.Fax;
						q.SupplierContactEmail = contact.Email;

						model.VoucherSupplierContactFullName = q.SupplierContactFullName;
						model.VoucherSupplierContactPhoneNo = q.SupplierContactPhoneNo;

						model.VoucherSupplierContactTitle = q.SupplierContactTitle;
						model.VoucherSupplierContactName = q.SupplierContactName;
						model.VoucherSupplierContactPhoneHome = q.SupplierContactPhoneHome;
						model.VoucherSupplierContactPhoneWork = q.SupplierContactPhoneWork;
						model.VoucherSupplierContactMobile = q.SupplierContactMobile;
						model.VoucherSupplierContactFax = q.SupplierContactFax;
						model.VoucherSupplierContactEmail = q.SupplierContactEmail;
						break;
					case "TripId":
					case "TripLineId":
					case "SaleTypeId":
					case "Commission":
					case "CommissionRate":
					case "Discount":
					case "DiscountRate":
					case "Duration":
					case "RateBasis":
					case "Amount":
						if (source == "TripLineId" && q.TripLine != null && q.TripLineId > 0) {
							tripLineUpdated = true;

							switch (q.TripLine.TripLineType) {
								case TripLineType.Accommodation:
								case TripLineType.Transport:
								case TripLineType.Cruise:
								case TripLineType.Tour:
								case TripLineType.OtherLand:
									q.CurrencyId = q.TripLine.TripLineLand.CurrencyId;
									q.CreditorId = q.TripLine.TripLineLand.CreditorId;
									q.SupplierId = q.TripLine.TripLineLand.SupplierId;
									q.ServiceTypeId = q.TripLine.TripLineLand.ServiceTypeRateBasis.ServiceTypeId;
									q.SupplierServiceId = q.TripLine.TripLineLand.SupplierServiceRateDetail.SupplierServiceRate.SupplierServiceId;
									q.ServiceComments = q.TripLine.TripLineLand.SupplierServiceRateDetailDescription;
									q.ServiceTypeRateBasisId = q.TripLine.TripLineLand.ServiceTypeRateBasisId;
									q.PassengerClassification = q.TripLine.TripLineLand.PassengerClassification;
									q.SaleTypeId = q.TripLine.TripLineLand.SaleTypeId;
									q.PaxAdultNo = q.TripLine.TripLineLand.PaxAdultNo;
									q.PaxAdultRate = q.TripLine.TripLineLand.PaxAdultRate;
									q.PaxAdultQty = q.TripLine.TripLineLand.PaxAdultQty;
									q.PaxChildNo = q.TripLine.TripLineLand.PaxChildNo;
									q.PaxChildRate = q.TripLine.TripLineLand.PaxChildRate;
									q.PaxChildQty = q.TripLine.TripLineLand.PaxChildQty;
									q.PaxInfantNo = q.TripLine.TripLineLand.PaxInfantNo;
									q.PaxInfantRate = q.TripLine.TripLineLand.PaxInfantRate;
									q.PaxInfantQty = q.TripLine.TripLineLand.PaxInfantQty;
									q.StartDate = q.TripLine.TripLineLand.StartDate;
									q.StartTime = q.TripLine.TripLineLand.StartTime;
									q.StartDetails = q.TripLine.TripLineLand.StartDetails;
									q.EndDate = q.TripLine.TripLineLand.EndDate;
									q.EndTime = q.TripLine.TripLineLand.EndTime;
									q.EndDetails = q.TripLine.TripLineLand.EndDetails;

									if (q.SupplierId <= 0) {
										model.VoucherSupplierName = string.Empty;
									}
									else {
										model.VoucherSupplierName = q.Supplier.Name;
									}

									model.VoucherCurrencyId = q.CurrencyId;
									model.VoucherCreditorId = q.CreditorId;
									model.VoucherSupplierId = q.SupplierId;
									model.VoucherServiceTypeId = q.ServiceTypeId;
									model.VoucherSupplierServiceId = q.SupplierServiceId;
									model.VoucherServiceComments = q.ServiceComments;
									model.VoucherServiceTypeRateBasisId = q.ServiceTypeRateBasisId;
									model.VoucherIsPaxNoApplicable = q.ServiceTypeRateBasis.IsPaxNoApplicable;
									model.VoucherPassengerClassification = q.PassengerClassification;
									model.VoucherSaleTypeId = q.SaleTypeId;
									model.VoucherPaxAdultNo = q.PaxAdultNo;
									model.VoucherPaxAdultRate = q.PaxAdultRate;
									model.VoucherPaxAdultQty = q.PaxAdultQty;
									model.VoucherPaxChildNo = q.PaxChildNo;
									model.VoucherPaxChildRate = q.PaxChildRate;
									model.VoucherPaxChildQty = q.PaxChildQty;
									model.VoucherPaxInfantNo = q.PaxInfantNo;
									model.VoucherPaxInfantRate = q.PaxInfantRate;
									model.VoucherPaxInfantQty = q.PaxInfantQty;
									model.VoucherStartDate = q.StartDate;
									model.VoucherStartTime = q.StartTime;
									model.VoucherStartDetails = q.StartDetails;
									model.VoucherEndDate = q.EndDate;
									model.VoucherEndTime = q.EndTime;
									model.VoucherEndDetails = q.EndDetails;
									break;
							}
						}

						var tripLineLandModel = new TripLineLandViewModel {
							PassengerClassification = model.VoucherPassengerClassification,
							Duration = model.VoucherDuration,
							PaxAdultNo = model.VoucherPaxAdultNo,
							PaxAdultRate = model.VoucherPaxAdultRate,
							PaxAdultQty = model.VoucherPaxAdultQty,
							PaxChildNo = model.VoucherPaxChildNo,
							PaxChildRate = model.VoucherPaxChildRate,
							PaxChildQty = model.VoucherPaxChildQty,
							PaxInfantNo = model.VoucherPaxInfantNo,
							PaxInfantRate = model.VoucherPaxInfantRate,
							PaxInfantQty = model.VoucherPaxInfantQty,
							IsPaxNoApplicable = model.VoucherIsPaxNoApplicable
						};

						var tripLineLand = q.TripLine.TripLineLand;
                        model.VoucherDuration = tripLineLand.Duration;

                        TripLineLandCommon.SetPricing(lazyContext, tripLineLandModel, tripLineLand);
						q.Amount = tripLineLand.Gross;

						q.PaxAdultNo = tripLineLand.PaxAdultNo;
						q.PaxAdultRate = tripLineLand.PaxAdultRate;
						q.PaxAdultQty = tripLineLand.PaxAdultQty;

						q.PaxChildNo = tripLineLand.PaxChildNo;
						q.PaxChildRate = tripLineLand.PaxChildRate;
						q.PaxChildQty = tripLineLand.PaxChildQty;

						q.PaxInfantNo = tripLineLand.PaxInfantNo;
						q.PaxInfantRate = tripLineLand.PaxInfantRate;
						q.PaxInfantQty = tripLineLand.PaxInfantQty;

						model.VoucherPaxAdultNo = q.PaxAdultNo;
						model.VoucherPaxAdultRate = q.PaxAdultRate;
						model.VoucherPaxAdultQty = q.PaxAdultQty;

						model.VoucherPaxChildNo = q.PaxChildNo;
						model.VoucherPaxChildRate = q.PaxChildRate;
						model.VoucherPaxChildQty = q.PaxChildQty;

						model.VoucherPaxInfantNo = q.PaxInfantNo;
						model.VoucherPaxInfantRate = q.PaxInfantRate;
						model.VoucherPaxInfantQty = q.PaxInfantQty;

						if (q.Amount > 0 && q.IsTaxApplicable) {
							int agencyId = q.AgencyId <= 0 ? HttpContext.CurrentDefaultAgencyId() : q.AgencyId;
							decimal taxRate = CustomerSettings.GetTaxRate(HttpContext.CurrentCustomerId(), q.DocumentDate);

							if (taxRate > 0) {
								if (model.VoucherIsTaxIncluded) {
									q.Tax = Math.Round(q.Amount * taxRate / (1 + taxRate), 2);
								}
								else {
									q.Tax = Math.Round(q.Amount * taxRate, 2);
								}
							}
							else {
								q.Tax = 0;
							}
						}
						else {
							q.Tax = 0;
						}

						model.VoucherNetValue = q.GetNetValue(model.VoucherIsTaxIncluded);
						model.VoucherAmount = q.Amount;
						model.VoucherTax = q.Tax;
						break;
				}

				switch (source) {
					case "StartDate":
					case "EndDate":
						if (model.VoucherStartDate == null)
							break;

						if (model.VoucherStartDate >= (model.VoucherEndDate ?? DateTime.MinValue)) {
							model.VoucherEndDate = model.VoucherStartDate;
							model.VoucherDuration = 1;
						}
						else if (model.VoucherEndDate != null) {
							model.VoucherDuration = ((DateTime)model.VoucherEndDate - (DateTime)model.VoucherStartDate).Days + (model.VoucherDurationCoverageType == DurationCoverageType.Days ? -1 : 0);
						}

						q.StartDate = model.VoucherStartDate ?? DateTime.MinValue;
						q.EndDate = model.VoucherEndDate ?? DateTime.MinValue;
						q.Duration = model.VoucherDuration;
						break;
					case "Duration":
					case "DurationCoverageType":
						if ((model.VoucherStartDate ?? DateTime.MinValue) > DateTime.MinValue) {
							model.VoucherEndDate = ((DateTime)model.VoucherStartDate).AddDays(model.VoucherDuration + (model.VoucherDurationCoverageType == DurationCoverageType.Days ? -1 : 0));
						}
						else if ((model.VoucherEndDate ?? DateTime.MinValue) > DateTime.MinValue) {
							model.VoucherStartDate = ((DateTime)model.VoucherEndDate).AddDays(-model.VoucherDuration - (model.VoucherDurationCoverageType == DurationCoverageType.Days ? -1 : 0));
						}

						q.StartDate = model.VoucherStartDate ?? DateTime.MinValue;
						q.EndDate = model.VoucherEndDate ?? DateTime.MinValue;
						q.Duration = model.VoucherDuration;
						break;
				}

				if (model.VoucherId <= 0)
					model.VoucherDocumentNo = LastDocumentNo.DocumentNo(lazyContext, "Voucher");

				model.VoucherIsTaxApplicable = q.IsTaxApplicable;
				model.VoucherIsPaxNoApplicable = q.ServiceTypeRateBasis.IsPaxNoApplicable;

				var rateModel = new RateModel {
					Commission = model.VoucherCommission,
					CommissionRate = model.VoucherCommissionRate / 100,
					CommissionTax = model.VoucherCommissionTax,
					Discount = model.VoucherDiscount,
					DiscountRate = model.VoucherDiscountRate / 100,
					DiscountTax = model.VoucherDiscountTax,
					IsTaxIncluded = model.VoucherIsTaxIncluded
				};

				var rates = new AccountingRates<Voucher>(HttpContext, q, rateModel);
				bool result = rates.SetRates(new List<string> { source }, model.VoucherAmount, model.VoucherTax);

				if (result) {
					model.VoucherCommission = rateModel.CommissionGross;
					model.VoucherCommissionRate = rateModel.CommissionRate * 100;
					model.VoucherCommissionTax = rateModel.CommissionTax;
					model.VoucherCommissionTaxRate = rateModel.CommissionTaxRate * 100;

					model.VoucherDiscount = rateModel.DiscountGross;
					model.VoucherDiscountRate = rateModel.DiscountRate * 100;
					model.VoucherDiscountTax = rateModel.DiscountTax;
					model.VoucherDiscountTaxRate = rateModel.DiscountTaxRate * 100;

					model.VoucherAmount = rateModel.AmountGross;
					model.VoucherTax = rateModel.Tax;
					model.VoucherTaxRate = rateModel.TaxRate * 100;
				}

				return Json(new { Model = model, TripLineUpdated = tripLineUpdated, UpdateRateModel = result });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Voucher_UpdateModel", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Voucher_Undo(int voucherId) {
			try {
				bool result = new VoucherCommon(HttpContext).Undo(LazyContext, voucherId);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Voucher_Undo", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Voucher_Reverse(int voucherId, string type) {
			try {
				bool result = new VoucherCommon(HttpContext).Reverse(LazyContext, voucherId, type);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Voucher_Reverse", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> VoucherAdd_Edit(int tripId, int[] tripLineIds) {
			try {
				if (tripLineIds == null || tripLineIds.Length == 0)
					throw new UnreportedException("No trip lines have been selected.");

				var tripLines = LazyContext.TripLine.Where(t => t.TripId == tripId && tripLineIds.Contains(t.Id)).ToList();

				if (tripLines.Count == 0)
					throw new UnreportedException("No trip lines have been selected.");

				if (!tripLines.Any(t => t.Voucher.Id <= 0))
					throw new UnreportedException("Selections have already been paid.");

				if (tripLines.Any(t => !(t.TripLineType == TripLineType.Accommodation || t.TripLineType == TripLineType.Transport || t.TripLineType == TripLineType.Cruise || t.TripLineType == TripLineType.Tour || t.TripLineType == TripLineType.OtherLand)))
					throw new UnreportedException("One or more selections are not land bookings.");

				ViewBag.VoucherAddTripId = tripId;
				ViewBag.VoucherAddTripLineIds = string.Join(",", tripLineIds);

				return PartialView("~/Views/Accounting/EditorTemplates/VoucherAdd.cshtml");
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "VoucherAdd_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> VoucherAdd_Create(int voucherTypeId, DateTime documentDate, int tripId, string tripLineIds, int[] passengerIds, string comments) {
			try {
				int count = new VoucherCommon(HttpContext).Create(LazyContext, voucherTypeId, documentDate, tripId, tripLineIds, passengerIds, comments);
				return Json(count);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "VoucherAdd_Create", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> VoucherDetail_Edit() {
			try {
				return PartialView("~/Views/Accounting/EditorTemplates/VoucherDetailEdit.cshtml");
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "VoucherDetail_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> VoucherDetail_Read([DataSourceRequest] DataSourceRequest request, int voucherId) {
			try {
				var q = LazyContext.VoucherDetail.Where(t => t.VoucherId == voucherId);

				var result = await q.Select(row => new VoucherDetailViewModel {
					VoucherDetailId = row.Id,
					VoucherId = row.VoucherId,
					VoucherDetailPassengerId = row.PassengerId,
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "VoucherDetail_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> VoucherDetail_CreateOrUpdate([DataSourceRequest] DataSourceRequest request, VoucherDetailViewModel model, int voucherId) {
			try {
				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				VoucherDetailCommon.CreateOrUpdate(Context, model, voucherId);

				return Json(await new[] { model }.ToDataSourceResultAsync(request, ModelState));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "VoucherDetail_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> VoucherDetail_Delete([DataSourceRequest] DataSourceRequest request, VoucherDetailViewModel model) {
			try {
				VoucherDetailCommon.Delete(Context, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "VoucherDetail_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Voucher_Report(int voucherId) {
			try {
				var reportSource = AccountingDataSources.GetVoucherReportSource(Context, HttpContext.CurrentCustomerId(), voucherId);
				return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Voucher_Report", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Voucher_IssueDocument(int voucherId, int? tripId = null) {
			try {
				new VoucherCommon(HttpContext).IssueDocument(LazyContext, voucherId, tripId);
				return Json(true);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Voucher_IssueDocument", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Voucher_EmailDocument(int voucherId, string from, string to, string cc, string bcc, string subject, string body, IEnumerable<IFormFile> attachments) {
			try {
				var q = Context.IssuedDocument.SingleOrDefault(t => t.VoucherId == voucherId && t.IssuedDocumentType == IssuedDocumentType.Voucher);

				if (q == null)
					throw new UnreportedException(AppConstants.RecordNotFound);

				var mailAttachments = new List<MailAttachment> {
					new MailAttachment(q.Document, q.FileName, q.FileContentType)
				};

				if (attachments != null) {
					foreach (var attachment in attachments) {
						mailAttachments.Add(new MailAttachment(attachment.OpenReadStream().StreamToBytes(), attachment.FileName, attachment.ContentType));
					}
				}

				await Mail.Instance.SendMailAsync(to, cc, bcc, subject, body, mailAttachments.ToArray(), from);
				return Json(true);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Voucher_EmailDocument", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Voucher_ExportPdf(int voucherId) {
			try {
				var context = Context;
				var voucher = Context.Voucher.Find(voucherId);

				if (voucher.CanEdit(false, false))
					return RedirectToAction("Vouchers", "Accounting", new { message = "Only read-only vouchers can be exported.", messageType = MessageType.Warning });

				string fileName = string.Format("{0}.pdf", IssuedDocument.GetVoucherName(voucher.DocumentNo));
				var reportSource = AccountingDataSources.GetVoucherReportSource(context, HttpContext.CurrentCustomerId(), voucherId);
				var result = Utils.ExportToPdf(reportSource);

				return File(result.DocumentBytes, result.MimeType, fileName);
			}
			catch (Exception ex) {
				await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Voucher_ExportPdf", ex);
				return Redirect("/Shared/Error");
			}
		}
		#endregion

		#region Bank Reconciliations
		public IActionResult BankReconciliations() {
			return View();
		}

		public async Task<IActionResult> BankReconciliation_Read([DataSourceRequest] DataSourceRequest request, TransactionType transactionType, DocumentStatus documentStatus, DateTime? dateFrom, DateTime? dateTo, decimal? amountFrom, decimal? amountTo, int bankAccountId, int bankAccountStatementId, string text, bool isExport, string sortMember = null, string sortDirection = null) {
			try {
				var lazyContext = LazyContext;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isAccounts = HttpContext.IsAccounts();
				bool isSuperUser = HttpContext.IsSuperUser();

				if (documentStatus == DocumentStatus.DepositedPaid && bankAccountId > 0 && bankAccountStatementId > 0) {
                    var bankStatement = lazyContext.BankAccountStatement.Find(bankAccountStatementId);
                    DateTime closingDate = DateTime.MinValue;

                    if (bankStatement != null)
                        closingDate = bankStatement.ClosingDate.AddDays(1).AddTicks(-1);

                    if (dateTo == null || (closingDate > DateTime.MinValue && dateTo > closingDate))
                        dateTo = closingDate;
                }

                var bankReconciliation = BankReconciliation.GetBankReconciliationQuery(lazyContext, bankAccountId, bankAccountStatementId, transactionType, documentStatus, BankReconciliationReportType.None, dateFrom, dateTo, amountFrom, amountTo, text);

				var q = bankReconciliation.Select(row => new BankReconciliationViewModel {
					TransactionDetailBaseRefIds = row.TransactionDetailBaseRefIds,
					TransactionDetailRefId = row.TransactionType == TransactionType.Receipt ? row.TransactionDetailRefIds[0] : -row.TransactionDetailRefIds[0],
					TransactionRefId = row.TransactionType == TransactionType.Receipt ? row.Receipt.Id : row.Payment.Id,
					AccountName = row.TransactionType == TransactionType.Receipt ? row.Receipt.AccountName : row.Payment.AccountName,
					AccountNameLink = row.TransactionType == TransactionType.Receipt ? row.Receipt.AccountNameLink : row.Payment.AccountNameLink,
					TransactionType = row.TransactionType,
					DocumentType = row.TransactionType == TransactionType.Receipt ? row.Receipt.IsDeposit ? "Bank Deposit" : ((ReceiptTypeExt)row.Receipt.ReceiptType).GetEnumDescription() : ((PaymentTypeExt)row.Payment.PaymentType).GetEnumDescription(),
					DocumentNo = row.DocumentNo,
					DocumentDate = row.DocumentDate,
					DocumentStatus = row.DocumentStatus,
					StatementDocumentStatus = row.StatementDocumentStatus,
					FormOfPayment = row.TransactionType == TransactionType.Receipt ? row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name : row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name,
					BankAccountId = row.BankAccountId,
					BankAccountName = row.BankAccountName,
					IsDeposit = row.TransactionType == TransactionType.Receipt && row.Receipt.IsDeposit,
					Debit = row.Debit,
					Credit = row.Credit,
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				});

				if (isExport) {
					if (!isAdministrator)
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var export = q.ApplySorting(null, WebUtils.GetSortDescriptors(sortMember, sortDirection)).Where(t => t.DocumentStatus == documentStatus).Select(row => new BankReconciliationExportModel {
						AccountName = row.AccountName,
						DocumentType = row.DocumentType,
						DocumentNo = row.DocumentNo,
						DocumentDate = row.DocumentDate,
						DocumentStatus = row.DocumentStatus.GetEnumDescription(),
						BankAccount = row.BankAccountName,
						Debit = row.Debit ?? 0.00m,
						Credit = row.Credit ?? 0.00m
					}).ToList();

					var xlsx = new ExportToExcel<BankReconciliationExportModel>(export);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Bank Reconciliations.xlsx");
				}

				decimal totalCredit = 0;
				decimal totalDebit = 0;
				decimal totalAmount = 0;
				decimal runningTotal = 0;

				if (bankAccountId > 0 && bankAccountStatementId > 0) {
					var totals = bankReconciliation.Select(t => new { t.TransactionType, t.DocumentStatus, t.BankAccountId, t.BankAccountStatementId, t.Debit, t.Credit }).ToList().ConvertAll(row => new {
						row.Credit,
						row.Debit
					});

					totalCredit = totals.Sum(t => t.Credit) ?? 0;
					totalDebit = totals.Sum(t => t.Debit) ?? 0;

					if (documentStatus == DocumentStatus.DepositedPaid) {
						totalAmount = BankReconciliation.GetBankReconciliationQuery(lazyContext, bankAccountId, bankAccountStatementId, transactionType, DocumentStatus.Closed, BankReconciliationReportType.None, dateFrom, dateTo, amountFrom, amountTo, text).AsEnumerable().Sum(t => (decimal?)((t.Credit ?? 0) - (t.Debit ?? 0))) ?? 0;
					}
					else if (documentStatus == DocumentStatus.Closed) {
						totalAmount = totalCredit - totalDebit;
						runningTotal = lazyContext.BankAccountStatement.Find(bankAccountStatementId).OpeningBalance + (q.ApplySorting(request.Groups, request.Sorts).Take((request.Page - 1) * request.PageSize).Sum(t => (decimal?)((t.Credit ?? 0) - (t.Debit ?? 0))) ?? 0);
					}
				}

				var aggregateResults = new List<AggregateResult> {
					new AggregateResult(totalDebit, new SumFunction { FunctionName = "Sum", SourceField = "Debit", MemberType = typeof(decimal) }),
					new AggregateResult(totalCredit, new SumFunction { FunctionName = "Sum", SourceField = "Credit", MemberType = typeof(decimal) }),
					new AggregateResult(totalAmount, new SumFunction { FunctionName = "Sum", SourceField = "RunningTotal", MemberType = typeof(decimal) }),
					new AggregateResult(totalAmount, new SumFunction { FunctionName = "Sum", SourceField = "TotalClosed", MemberType = typeof(decimal) })
				};

				bool isReceiptAuthorised = await HttpContext.IsAuthorised(Cache, MenuPageType.Receipt);
				bool isPaymentAuthorised = await HttpContext.IsAuthorised(Cache, MenuPageType.Payment);

				var data = q.ApplySorting(request.Groups, request.Sorts).ApplyPaging(request.Page, request.PageSize).ToList();

				foreach (var row in data) {
					if (row.TransactionType == TransactionType.Receipt) {
						var receiptDetails = lazyContext.ReceiptDetail.Where(t => row.TransactionDetailRefIds.Contains(t.Id)).ToList();

						row.CanEdit = isReceiptAuthorised && receiptDetails.All(t => t.CanEdit(isAdministrator, isAccounts, isSuperUser));
						row.CanDelete = isReceiptAuthorised && receiptDetails.All(t => t.CanDelete(isAdministrator, isAccounts, isSuperUser));
						row.CanUndo = isReceiptAuthorised && receiptDetails.All(t => t.CanUndo(true));
						row.CanReverse = isReceiptAuthorised && receiptDetails.All(t => t.CanReverse());
					}
					else {
						var paymentDetails = lazyContext.PaymentDetail.Where(t => row.TransactionDetailRefIds.Contains(t.Id)).ToList();

						row.CanEdit = isPaymentAuthorised && paymentDetails.All(t => t.CanEdit(isAdministrator, isSuperUser));
						row.CanDelete = isPaymentAuthorised && paymentDetails.All(t => t.CanDelete(isAdministrator, isAccounts, isSuperUser));
						row.CanUndo = isPaymentAuthorised && paymentDetails.All(t => t.CanUndo(true));
						row.CanReverse = isPaymentAuthorised && paymentDetails.All(t => t.CanReverse());
					}

					row.RunningTotal = runningTotal += (row.Credit ?? 0) - (row.Debit ?? 0);
				}

				int total = q.Count();

				var result = await Task.Run(() => new DataSourceResult {
					Data = data,
					Total = total,
					AggregateResults = aggregateResults
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankReconciliation_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		public async Task<IActionResult> BankReconciliationDetail_Read([DataSourceRequest] DataSourceRequest request, int[] transactionDetailRefIds, TransactionType transactionType, bool includeRelatedDocuments = false) {
			try {
				var lazyContext = LazyContext;
				DataSourceResult result;

				switch (transactionType) {
					default:
						throw new InvalidOperationException("Invalid Transaction Type.");
					case TransactionType.Receipt:
						var receipts = lazyContext.Receipt.Where(t1 => t1.ReceiptDetails.Any(t2 => transactionDetailRefIds.Contains(t2.Id)));
						var receiptDetails = lazyContext.ReceiptDetail.AsQueryable();

						bool isDeposit = receipts.FirstOrDefault()?.IsDeposit ?? false;

						if (isDeposit) {
							int depositDetailId = receiptDetails.FirstOrDefault(t => transactionDetailRefIds.Contains(t.Id))?.Id ?? 0;
							receiptDetails = receiptDetails.Where(t => t.DepositDetailId == depositDetailId);
						}
						else {
							receiptDetails = receiptDetails.Where(t => transactionDetailRefIds.Contains(t.Id));
						}

						var q = receiptDetails.Select(row => new {
							row.Id,
							TransactionRefId = row.ReceiptId,
							TransactionType = TransactionType.Receipt,
							row.Receipt.AccountName,
							row.Receipt.AccountNameLink,
							row.Receipt.DocumentNo,
							row.Receipt.DocumentDate,
							row.DocumentStatus,
							row.ReversalStatus,
							row.TripLineAirPassenger,
							row.Passenger,
							row.FormOfPayment,
							row.BankAccountStatementId,
							BankAccountStatementName = row.Receipt.IsDeposit && row.DepositDetail.BankAccountStatementId > 0 ? row.DepositDetail.BankAccountStatement.Name : row.BankAccountStatementId > 0 ? row.BankAccountStatement.Name : string.Empty,
							DepositDate = row.GetDateDeposited(lazyContext, row.DepositDetailId),
							Debit = 0m,
							Credit = row.Amount + row.Tax,
							row.LastWriteTime,
							row.CreationTime,
							row.LastWriteUser,
							row.CreationUser
						});

						if (includeRelatedDocuments && !isDeposit) {
							q = q.AsEnumerable().Concat(lazyContext.PaymentDetail.Where(t1 => receiptDetails.Any(t2 => t2.BankAccountStatementId > 0 && t2.BankAccountStatementId == t1.BankAccountStatementId)).Select(row => new {
								row.Id,
								TransactionRefId = row.PaymentId,
								TransactionType = TransactionType.Payment,
								row.Payment.AccountName,
								row.Payment.AccountNameLink,
								row.Payment.DocumentNo,
								row.Payment.DocumentDate,
								row.DocumentStatus,
								row.ReversalStatus,
								row.TripLineAirPassenger,
								row.Passenger,
								row.FormOfPayment,
								row.BankAccountStatementId,
								BankAccountStatementName = row.BankAccountStatementId > 0 ? row.BankAccountStatement.Name : string.Empty,
								DepositDate = row.BankAccountStatementId <= 0 ? (DateTime?)null : row.Payment.DocumentDate,
								Debit = row.Amount + row.Tax,
								Credit = 0m,
								row.LastWriteTime,
								row.CreationTime,
								row.LastWriteUser,
								row.CreationUser
							})).AsQueryable();
						}

						result = await q.OrderByDescending(t => t.DocumentDate).Select(row => new BankReconciliationDetailViewModel {
							TransactionDetailRefId = row.Id,
							TransactionRefId = row.TransactionRefId,
							TransactionType = row.TransactionType,
							AccountName = row.AccountName,
							AccountNameLink = row.AccountNameLink,
							DocumentNo = row.DocumentNo,
							DocumentDate = row.DocumentDate,
							DocumentStatus = row.DocumentStatus,
							ReversalStatus = row.ReversalStatus,
							PassengerName = row.TripLineAirPassenger.Id > 0 ? row.TripLineAirPassenger.Passenger.FullName : row.Passenger.Id > 0 ? row.Passenger.FullName : string.Empty,
							FormOfPayment = row.FormOfPayment.Id <= 0 ? string.Empty : row.FormOfPayment.Name,
							BankAccountStatementName = row.BankAccountStatementName,
							DepositDate = row.DepositDate,
							Debit = row.Debit == 0 ? (decimal?)null : row.Debit,
							Credit = row.Credit == 0 ? (decimal?)null : row.Credit,
							LastWriteTime = row.LastWriteTime.ToLocalTime(),
							CreationTime = row.CreationTime.ToLocalTime(),
							LastWriteUser = row.LastWriteUser,
							CreationUser = row.CreationUser
						}).ToDataSourceResultAsync(request);

						break;
					case TransactionType.Payment:
						result = await lazyContext.PaymentDetail.Where(t => transactionDetailRefIds.Contains(t.Id)).OrderByDescending(t => t.Payment.DocumentDate).AsEnumerable().Select(row => new BankReconciliationDetailViewModel {
							TransactionDetailRefId = row.Id,
							TransactionRefId = row.PaymentId,
							TransactionType = TransactionType.Payment,
							AccountName = row.Payment.AccountName,
							AccountNameLink = row.Payment.AccountNameLink,
							DocumentNo = row.Payment.DocumentNo,
							DocumentDate = row.Payment.DocumentDate,
							DocumentStatus = row.DocumentStatus,
							ReversalStatus = row.ReversalStatus,
							PassengerName = row.TripLineAirPassengerId > 0 ? row.TripLineAirPassenger.Passenger.FullName : row.Passenger.Id > 0 ? row.Passenger.FullName : string.Empty,
							FormOfPayment = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name,
							BankAccountStatementName = row.BankAccountStatementId > 0 ? row.BankAccountStatement.Name : string.Empty,
							Debit = row.Amount + row.Tax + row.NonCommissionable + row.NonCommissionableTax,
							Credit = 0,
							LastWriteTime = row.LastWriteTime.ToLocalTime(),
							CreationTime = row.CreationTime.ToLocalTime(),
							LastWriteUser = row.LastWriteUser,
							CreationUser = row.CreationUser
						}).ToDataSourceResultAsync(request);

						break;
				}

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankReconciliationDetail_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> BankReconciliation_ProcessSelections(int[] receiptDetailIds, int[] paymentDetailIds, int bankAccountStatementId, string action, string type) {
			try {
				if ((receiptDetailIds == null || receiptDetailIds.Length == 0) && (paymentDetailIds == null || paymentDetailIds.Length == 0))
					throw new UnreportedException("No documents have been selected.");

				bool result = new BankReconciliationCommon(HttpContext).ProcessSelections(LazyContext, receiptDetailIds, paymentDetailIds, bankAccountStatementId, action, type);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "BankReconciliation_ProcessSelections", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region Payment Methods
		public IActionResult PaymentMethods() {
			return View();
		}

		public async Task<IActionResult> PaymentMethod(AccountType accountType, int parentId, bool isNative) {
			try {
				ViewBag.PaymentMethodAccountType = accountType;
				ViewBag.PaymentMethodParentId = parentId;
				ViewBag.PaymentMethodIsNative = isNative;
				return PartialView("~/Views/Accounting/_PaymentMethodPartial.cshtml");
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentMethod", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> PaymentMethod_Edit(AccountType accountType, int accountTypeId, int paymentMethodId, int parentId, bool isProfile, bool isNative) {
			try {
				var lazyContext = LazyContext;
				PaymentMethod q = null;

				if (paymentMethodId <= 0) {
					int profileId = -1;
					int tripId = -1;
					int debtorId = -1;
					int creditorId = -1;
					int chartOfAccountId = -1;

					switch (accountType) {
						case AccountType.Client:
							if (isProfile) {
								profileId = parentId;
							}
							else {
								tripId = parentId;
							}

							break;
						case AccountType.Debtor:
							debtorId = parentId;
							break;
						case AccountType.Creditor:
							creditorId = parentId;
							break;
						case AccountType.GeneralLedger:
							chartOfAccountId = parentId;
							break;
					}

					q = new PaymentMethod {
						Id = 0,
						ProfileId = profileId,
						TripId = tripId,
						DebtorId = debtorId,
						CreditorId = creditorId,
						ChartOfAccountId = chartOfAccountId,
						AccountType = (AccountType)accountTypeId,
						FormOfPaymentId = -1,
						FormOfPayment = new FormOfPayment { Id = -1 },
						TokenCustomerId = 0,
						ExpiryDate = DateTime.MinValue,
						IsActive = true
					};
				}
				else {
					q = lazyContext.PaymentMethod.Find(paymentMethodId);

					if (q == null)
						throw new UnreportedException(AppConstants.RecordNotFound);
				}

				var model = new PaymentMethodViewModel {
					PaymentMethodId = q.Id,
					PaymentMethodProfileId = q.Id <= 0 ? null : q.ProfileId,
					PaymentMethodTripId = q.Id <= 0 ? null : q.TripId,
					PaymentMethodDebtorId = q.Id <= 0 ? null : q.DebtorId,
					PaymentMethodCreditorId = q.Id <= 0 ? null : q.CreditorId,
					PaymentMethodChartOfAccountId = q.Id <= 0 ? null : q.ChartOfAccountId,
					PaymentMethodAccountNameLink = q.Id <= 0 ? string.Empty : q.AccountNameLink,
					PaymentMethodAccountType = q.AccountType,
					PaymentMethodFormOfPaymentId = q.FormOfPaymentId <= 0 ? null : q.FormOfPaymentId,
					PaymentMethodFormOfPayment = q.FormOfPayment.PaySupplierDescription,
					PaymentMethodAccountNo = q.AccountNo,
					PaymentMethodPaymentDetails1 = q.PaymentDetails1,
					PaymentMethodPaymentDetails2 = q.PaymentDetails2,
					PaymentMethodPaymentDetails3 = q.PaymentDetails3,
					PaymentMethodCreditLimit = q.CreditLimit,
					PaymentMethodExpiryDate = q.ExpiryDate == DateTime.MinValue ? null : q.ExpiryDate,
					PaymentMethodComments = q.Comments,
					PaymentMethodIsActive = q.IsActive,
					PaymentMethodIsProfile = (q.ProfileId > 0 && q.TripId <= 0) || isProfile,
					LastWriteTime = q.LastWriteTime.ToLocalTime(),
					CreationTime = q.CreationTime.ToLocalTime(),
					LastWriteUser = q.LastWriteUser,
					CreationUser = q.CreationUser
				};

				ViewBag.PaymentMethodAccountType = accountType;
				ViewBag.PaymentMethodParentId = parentId;
				ViewBag.PaymentMethodIsNative = isNative;

				return PartialView("~/Views/Accounting/EditorTemplates/PaymentMethodEdit.cshtml", model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentMethod_Edit", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> PaymentMethod_Read([DataSourceRequest] DataSourceRequest request, AccountType accountType, int accountTypeId, int parentId, bool isProfile, string text) {
			try {
				var lazyContext = LazyContext;
				var q = lazyContext.PaymentMethod.Where(t => t.Id > 0);

				switch (accountType) {
					case AccountType.None:
						if (accountTypeId != (int)AccountType.None)
							q = q.Where(t => (int)t.AccountType == accountTypeId);

						if (!string.IsNullOrEmpty(text)) {
							text = text.Trim().ToLower();

							if (int.TryParse(text, out int tripId) && lazyContext.Trip.Any(t => t.Id == tripId)) {
								q = q.Where(t => t.TripId == tripId);
								break;
							}

							if (DataValidation.IsPhone(text)) {
								text = text.Replace(" ", string.Empty);

								q = q.Where(t => t.AccountNo.ToLower().Contains(text)
									|| t.Profile.PhoneHome.ToLower().Replace(" ", string.Empty).Contains(text)
									|| t.Profile.PhoneWork.ToLower().Replace(" ", string.Empty).Contains(text)
									|| t.Profile.Mobile.ToLower().Replace(" ", string.Empty).Contains(text)
									|| t.Profile.Fax.ToLower().Replace(" ", string.Empty).Contains(text)
									|| t.Trip.PhoneHome.ToLower().Replace(" ", string.Empty).Contains(text)
									|| t.Trip.PhoneWork.ToLower().Replace(" ", string.Empty).Contains(text)
									|| t.Trip.Mobile.ToLower().Replace(" ", string.Empty).Contains(text)
									|| t.Trip.Fax.ToLower().Replace(" ", string.Empty).Contains(text));
							}
							else if (text.Contains('@')) {
								q = q.Where(t => t.Profile.Email.ToLower().Contains(text) || t.Trip.Email.ToLower().Contains(text));
							}
							else {
								q = q.Where(t => t.AccountNo.ToLower().Contains(text)
									|| t.Profile.Code.ToLower().Contains(text)
									|| (t.Profile.Title + " " + t.Profile.FirstName + " " + t.Profile.LastName).Trim().ToLower().Contains(text)
									|| t.Trip.Code.ToLower().Contains(text)
                                    || t.Trip.TripNo.ToLower().Contains(text)
                                    || (t.Trip.Title + " " + t.Trip.FirstName + " " + t.Trip.LastName).Trim().ToLower().Contains(text)
									|| t.Debtor.Code.ToLower().Contains(text)
									|| t.Debtor.Name.ToLower().Contains(text)
									|| t.Creditor.Name.ToLower().Contains(text)
									|| t.ChartOfAccount.Code.ToLower().Contains(text)
									|| t.ChartOfAccount.Name.ToLower().Contains(text));
							}
						}

						break;
					case AccountType.Client:
						if (isProfile) {
							q = q.Where(t1 => t1.ProfileId == parentId || lazyContext.Profile.Any(t2 => t2.Id == parentId && t2.DebtorId == t1.DebtorId && t1.DebtorId > 0) || lazyContext.Trip.Any(t2 => t2.ProfileId == parentId && t2.DebtorId == t1.DebtorId && t1.DebtorId > 0));
						}
						else {
							q = q.Where(t1 => t1.TripId == parentId || lazyContext.Profile.Any(t2 => t2.Trips.Any(t3 => t3.Id == parentId) && t2.DebtorId == t1.DebtorId && t1.DebtorId > 0) || lazyContext.Trip.Any(t2 => t2.Id == parentId && t2.DebtorId == t1.DebtorId && t1.DebtorId > 0));
						}

						break;
					case AccountType.Debtor:
						q = q.Where(t => t.DebtorId == parentId);
						break;
					case AccountType.Creditor:
						q = q.Where(t => t.CreditorId == parentId);
						break;
					case AccountType.GeneralLedger:
						q = q.Where(t => t.ChartOfAccountId == parentId);
						break;
				}

				var result = await q.OrderBy(t => t.FormOfPayment.Name).ThenByDescending(t => t.ExpiryDate).Select(row => new PaymentMethodViewModel {
					PaymentMethodId = row.Id,
					PaymentMethodAccountName = row.AccountName,
					PaymentMethodAccountNameLink = row.AccountNameLink,
					PaymentMethodAccountType = row.AccountType,
					PaymentMethodFormOfPayment = row.FormOfPayment.Name,
					PaymentMethodAccountNo = row.AccountNo,
					PaymentMethodIsActive = row.IsActive,
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentMethod_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> PaymentMethod_CreateOrUpdate(PaymentMethodViewModel model, string encryptedCardNo, string encryptedCvn) {
			try {
				if ((model.PaymentMethodChartOfAccountId ?? 0) <= 0)
					model.PaymentMethodChartOfAccountId = -1;

				ModelState.Clear();
				TryValidateModel(model);

				if (!ModelState.IsValid)
					throw new UnreportedException(WebUtils.GetModelStateErrors(ModelState));

				new PaymentMethodCommon(HttpContext).CreateOrUpdate(Context, model, encryptedCardNo, encryptedCvn);
				return Json(model);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentMethod_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> PaymentMethod_Delete([DataSourceRequest] DataSourceRequest request, PaymentMethodViewModel model) {
			try {
				var context = Context;
				var q = context.PaymentMethod.Find(model.PaymentMethodId);

				if (q == null)
					throw new UnreportedException(AppConstants.RecordNotFound);

				context.Delete(q);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "PaymentMethod_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region Transactions
		[HttpPost]
		public async Task<IActionResult> Transaction(LedgerType ledgerType, ClientAccountType clientAccountType, int tripId, int debtorId, int creditorId, int chartOfAccountId) {
			try {
				ViewBag.TransactionLedgerType = ledgerType;
				ViewBag.TransactionClientAccountType = clientAccountType;
				ViewBag.TransactionTripId = tripId;
				ViewBag.TransactionDebtorId = debtorId;
				ViewBag.TransactionCreditorId = creditorId;
				ViewBag.TransactionChartOfAccountId = chartOfAccountId;
				return PartialView("~/Views/Accounting/_TransactionPartial.cshtml");
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Transaction", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> Transaction_Read([DataSourceRequest] DataSourceRequest request, LedgerType selectedLedgerType, LedgerType ledgerType, int tripId, int debtorId, int creditorId, int chartOfAccountId, bool isExport) {
			try {
                if (HttpContext.AppUserRole() != AppUserRole.SystemAdministrator && !HttpContext.IsGlobalUser())
                    selectedLedgerType = LedgerType.CurrentAccountOnly;

                if (tripId <= 0 && debtorId <= 0 && creditorId <= 0 && chartOfAccountId <= 0)
					return Json(new EmptyResult());

				var lazyContext = LazyContext;

				bool isAdministrator = HttpContext.IsAdministrator();
				bool isAccounts = HttpContext.IsAccounts();
				bool isSuperUser = HttpContext.IsSuperUser();

				var q1 = lazyContext.Transaction.Where(t => t.Id > 0);

				if (selectedLedgerType == LedgerType.None) {
					selectedLedgerType = LedgerType.GeneralLedger;
				}
				else if (selectedLedgerType == LedgerType.CurrentAccountOnly) {
					q1 = q1.Where(t1 => t1.TransactionDetails.Any(t2 => t2.LedgerType == ledgerType));
				}
				else {
					q1 = q1.Where(t1 => t1.TransactionDetails.Any(t2 => t2.LedgerType == selectedLedgerType));
				}

				if (tripId > 0) {
					q1 = q1.Where(t1 => t1.TransactionDetails.Any(t2 => t2.TripId == tripId || t2.ReceiptDetail.Receipt.TripId == tripId || t2.BspDetail.Bsp.TripId == tripId || t2.NonBspDetail.NonBsp.TripId == tripId || t2.PaymentDetail.Payment.TripId == tripId || t2.InvoiceDetail.TripId == tripId || t2.JournalDetail.TripId == tripId || t2.Transaction.Adjustment.DebitTripId == tripId || t2.Transaction.Adjustment.CreditTripId == tripId));
				}
				else if (debtorId > 0) {
					q1 = q1.Where(t1 => t1.TransactionDetails.Any(t2 => t2.DebtorId == debtorId || t2.ReceiptDetail.Receipt.DebtorId == debtorId || t2.PaymentDetail.Payment.DebtorId == debtorId || t2.InvoiceDetail.Invoice.DebtorId == debtorId || t2.JournalDetail.DebtorId == debtorId || t2.Transaction.Adjustment.DebitDebtorId == debtorId || t2.Transaction.Adjustment.CreditDebtorId == debtorId));
				}
				else if (creditorId > 0) {
					q1 = q1.Where(t1 => t1.TransactionDetails.Any(t2 => t2.CreditorId == creditorId || t2.ReceiptDetail.Receipt.CreditorId == creditorId || t2.BspDetail.Bsp.CreditorId == creditorId || t2.NonBspDetail.NonBsp.CreditorId == creditorId || t2.PaymentDetail.Payment.CreditorId == creditorId || t2.JournalDetail.CreditorId == creditorId || t2.Transaction.Adjustment.DebitCreditorId == creditorId || t2.Transaction.Adjustment.CreditCreditorId == creditorId));
				}
				else if (chartOfAccountId > 0) {
					q1 = q1.Where(t1 => t1.TransactionDetails.Any(t2 => t2.ChartOfAccountId == chartOfAccountId || t2.ReceiptDetail.Receipt.ChartOfAccountId == chartOfAccountId || t2.NonBspDetail.NonBsp.ChartOfAccountId == chartOfAccountId || t2.PaymentDetail.Payment.ChartOfAccountId == chartOfAccountId || t2.InvoiceDetail.ChartOfAccountId == chartOfAccountId || t2.JournalDetail.ChartOfAccountId == chartOfAccountId || t2.Transaction.Adjustment.DebitChartOfAccountId == chartOfAccountId || t2.Transaction.Adjustment.CreditChartOfAccountId == chartOfAccountId));
				}

				var q2 = q1.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo).ThenBy(t => t.CreationTime).Select(row => new TransactionViewModel {
					TransactionId = row.Id,
					TransactionRefId = row.TransactionRefId,
					TransactionType = row.Invoice.InvoiceType == InvoiceType.CreditNote ? TransactionType.CreditNote : row.TransactionType,
					DocumentType = row.DocumentType,
					DocumentStatus = row.TransactionDetails.Count == 0 ? DocumentStatus.None : (DocumentStatus)row.TransactionDetails.Min(t => (int)t.DocumentStatus),
					ReversalStatus = row.TransactionDetails.Count == 0 ? ReversalStatus.None : (ReversalStatus)row.TransactionDetails.Min(t => (int)t.ReversalStatus),
					DocumentNo = row.DocumentNo,
					DocumentDate = row.DocumentDate,
					IsDebtorReceipt = row.TransactionType == TransactionType.Receipt && row.Receipt.ReceiptType == ReceiptType.Debtor,
					IsIssued = (row.ReceiptId > 0 && row.Receipt.IsIssued) || (row.InvoiceId > 0 && row.Invoice.IsIssued),
					CanEdit = row.CanEdit(isAdministrator, isAccounts, isSuperUser),
					CanDelete = row.CanDelete(isAdministrator, isAccounts, isSuperUser),
					CanUndo = row.CanUndo(),
					CanReverse = row.CanReverse(),
					LastWriteTime = row.LastWriteTime.ToLocalTime(),
					CreationTime = row.CreationTime.ToLocalTime(),
					LastWriteUser = row.LastWriteUser,
					CreationUser = row.CreationUser
				}).ApplyFiltering(request.Filters);

				if (isExport) {
					if (!HttpContext.IsGlobalUser())
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var export = (from txn in q2.AsEnumerable()
								  from txnDetail in TransactionDetail.GetTransactionDetailQuery(lazyContext, selectedLedgerType, ledgerType, txn.TransactionId, tripId, debtorId, creditorId, chartOfAccountId).AsEnumerable().DefaultIfEmpty()
								  where txnDetail != null
								  select new TransactionDetailExportModel {
									  TransactionType = txn.TransactionType.GetEnumDescription(),
									  DocumentNo = txn.DocumentNo,
									  DocumentType = txn.DocumentType,
									  DocumentDate = txn.DocumentDate,
									  DocumentStatus = txnDetail.DocumentStatus.GetEnumDescription(),
									  ReversalStatus = txnDetail.ReversalStatus.GetEnumDescription(),
									  AccountName = txnDetail.AccountName,
									  LedgerType = txnDetail.LedgerType.GetEnumDescription(),
									  Description = txnDetail.Description,
									  Reference = txnDetail.Reference,
									  Commission = txnDetail.Commission,
									  CommissionTax = txnDetail.CommissionTax,
									  Discount = txnDetail.Discount,
									  DiscountTax = txnDetail.DiscountTax,
									  NonCommissionable = txnDetail.NonCommissionable,
									  NonCommissionableTax = txnDetail.NonCommissionableTax,
									  Amount = txnDetail.Amount,
									  Tax = txnDetail.Tax
								  }).ToList();

					var xlsx = new ExportToExcel<TransactionDetailExportModel>(export);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Transaction Details.xlsx");
				}

				var q3 = q1.SelectMany(t => t.TransactionDetails).Where(t1 => q2.Any(t2 => t2.TransactionId == t1.TransactionId));

				if (selectedLedgerType == LedgerType.CurrentAccountOnly) {
					if (tripId > 0) {
						q3 = q3.Where(t => t.TripId == tripId);
					}
					else if (debtorId > 0) {
						q3 = q3.Where(t => t.DebtorId == debtorId);
					}
					else if (creditorId > 0) {
						q3 = q3.Where(t => t.CreditorId == creditorId);
					}
					else if (chartOfAccountId > 0) {
						q3 = q3.Where(t => t.ChartOfAccountId == chartOfAccountId);
					}
				}
				else {
					q3 = q3.Where(t => t.LedgerType == selectedLedgerType);
				}

				decimal totalDebit = q3.Where(t => t.SignType == SignType.Debit).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				decimal totalCredit = q3.Where(t => t.SignType == SignType.Credit).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				decimal totalCommission = q3.Sum(t => (decimal?)(t.Commission + t.CommissionTax)) ?? 0;
				decimal totalDiscount = q3.Sum(t => (decimal?)(t.Discount + t.DiscountTax)) ?? 0;
				decimal totalNonCommissionable = q3.Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0;

				var aggregateResults = new List<AggregateResult> {
					new AggregateResult(totalDebit, new SumFunction { FunctionName = "Sum", SourceField = "TotalDebit", MemberType = typeof(decimal) }),
					new AggregateResult(totalCredit, new SumFunction { FunctionName = "Sum", SourceField = "TotalCredit", MemberType = typeof(decimal) }),
					new AggregateResult(totalCommission, new SumFunction { FunctionName = "Sum", SourceField = "TotalCommission", MemberType = typeof(decimal) }),
					new AggregateResult(totalDiscount, new SumFunction { FunctionName = "Sum", SourceField = "TotalDiscount", MemberType = typeof(decimal) }),
					new AggregateResult(totalNonCommissionable, new SumFunction { FunctionName = "Sum", SourceField = "TotalNonCommissionable", MemberType = typeof(decimal) })
				};

				var q4 = q2.ApplySorting(request.Groups, request.Sorts).ApplyPaging(request.Page, request.PageSize).ToList();

				foreach (var row in q4) {
					bool isAuthorised = await HttpContext.IsAuthorised(Cache, row.MenuPageType);
					row.CanEdit = isAuthorised && row.CanEdit;
					row.CanDelete = isAuthorised && row.CanDelete;
					row.CanUndo = isAuthorised && row.CanUndo;
					row.CanReverse = isAuthorised && row.CanReverse;

					var q5 = TransactionDetail.GetTransactionDetailQuery(lazyContext, selectedLedgerType, ledgerType, row.TransactionId, tripId, debtorId, creditorId, chartOfAccountId).ToList();
					row.TotalDebit = q5.Where(t => t.SignType == SignType.Debit).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
					row.TotalCredit = q5.Where(t => t.SignType == SignType.Credit).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
					row.TotalCommission = q5.Sum(t => (decimal?)(t.Commission + t.CommissionTax)) ?? 0;
					row.TotalDiscount = q5.Sum(t => (decimal?)(t.Discount + t.DiscountTax)) ?? 0;
					row.TotalNonCommissionable = q5.Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0;
				}

				var result = await Task.Run(() => new DataSourceResult {
					Data = q4,
					Total = q1.Count(),
					AggregateResults = aggregateResults
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Transaction_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Transaction_Delete([DataSourceRequest] DataSourceRequest request, TransactionViewModel model) {
			try {
				new TransactionCommon(HttpContext).Delete(LazyContext, model);
				return Json(await new[] { model }.ToDataSourceResultAsync(request));
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Transaction_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Transaction_Undo(int transactionRefId, int transactionTypeId, bool isDetailView) {
			try {
				bool result = false;
				var lazyContext = LazyContext;

				switch (transactionTypeId) {
					case (int)TransactionType.Receipt:
						result = new ReceiptCommon(HttpContext).Undo(lazyContext, transactionRefId, isDetailView, false);
						break;
					case (int)TransactionType.Bsp:
						result = new BspCommon(HttpContext).Undo(lazyContext, transactionRefId, isDetailView);
						break;
					case (int)TransactionType.NonBsp:
						result = new NonBspCommon(HttpContext).Undo(lazyContext, transactionRefId, isDetailView);
						break;
					case (int)TransactionType.Payment:
						result = new PaymentCommon(HttpContext).Undo(lazyContext, transactionRefId, isDetailView, false);
						break;
					case (int)TransactionType.Adjustment:
					case (int)TransactionType.Invoice:
					case (int)TransactionType.Journal:
						throw new InvalidOperationException();
				}

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Transaction_Undo", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Transaction_Reverse(int transactionRefId, string type, int transactionTypeId) {
			try {
				var lazyContext = LazyContext;
				bool result = false;

				switch ((TransactionType)transactionTypeId) {
					default:
						throw new InvalidOperationException("Invalid Transaction Type.");
					case TransactionType.Receipt:
						result = new ReceiptCommon(HttpContext).Reverse(lazyContext, transactionRefId, type);
						break;
					case TransactionType.Bsp:
						result = new BspCommon(HttpContext).Reverse(lazyContext, transactionRefId, type);
						break;
					case TransactionType.NonBsp:
						result = new NonBspCommon(HttpContext).Reverse(lazyContext, transactionRefId, type);
						break;
					case TransactionType.Payment:
						result = new PaymentCommon(HttpContext).Reverse(lazyContext, transactionRefId, type);
						break;
					case TransactionType.Journal:
						result = new JournalCommon(HttpContext).Reverse(lazyContext, transactionRefId, type);
						break;
					case TransactionType.Adjustment:
						result = new AdjustmentCommon(HttpContext).Reverse(lazyContext, transactionRefId, type);
						return Json(result);
				}

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Transaction_Reverse", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> TransactionDetail_Read([DataSourceRequest] DataSourceRequest request, LedgerType selectedLedgerType, LedgerType ledgerType, TransactionType transactionType, int transactionId, int tripId, int debtorId, int creditorId, int chartOfAccountId) {
			try {
                if (HttpContext.AppUserRole() != AppUserRole.SystemAdministrator && !HttpContext.IsGlobalUser())
                    selectedLedgerType = LedgerType.CurrentAccountOnly;

                var q = TransactionDetail.GetTransactionDetailQuery(LazyContext, selectedLedgerType, ledgerType, transactionId, tripId, debtorId, creditorId, chartOfAccountId, transactionType);

				var result = await q.AsEnumerable().GroupBy(row => new {
					row.TransactionId,
					row.LedgerType,
					row.DocumentStatus,
					row.ReversalStatus,
					row.TripId,
					row.DebtorId,
					row.CreditorId,
					row.ChartOfAccountId,
					AccountName = row.GetAccount(false),
					AccountNameLink = row.GetAccountLink(false),
					row.Reference,
					row.Description
				}).Select(row => new TransactionDetailViewModel {
					TransactionDetailId = row.Min(t => t.Id),
					TransactionId = row.Key.TransactionId,
					LedgerType = row.Key.LedgerType,
					TripId = row.Key.TripId,
					DocumentStatus = row.Key.DocumentStatus,
					ReversalStatus = row.Key.ReversalStatus,
					AccountName = row.Key.AccountName,
					AccountNameLink = row.Key.AccountNameLink,
					Reference = row.Key.Reference,
					Description = row.Key.Description,
					Debit = row.Where(t => t.SignType == SignType.Debit).Sum(t => t.Amount + t.Tax),
					Credit = row.Where(t => t.SignType == SignType.Credit).Sum(t => t.Amount + t.Tax),
					Commission = row.Sum(t => t.Commission + t.CommissionTax),
					Discount = row.Sum(t => t.Discount + t.DiscountTax),
					NonCommissionable = row.Sum(t => t.NonCommissionable + t.NonCommissionableTax),
					LastWriteTime = row.Min(t => t.LastWriteTime).ToLocalTime(),
					CreationTime = row.Min(t => t.CreationTime).ToLocalTime(),
					LastWriteUser = row.Min(t => t.LastWriteUser),
					CreationUser = row.Min(t => t.CreationUser)
				}).OrderBy(t => t.LedgerType).ThenBy(t => t.AccountName).ThenByDescending(t => t.CreationTime).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TransactionDetail_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
        public async Task<IActionResult> TransactionDetailAllocation(int debtorId, int creditorId, int receiptDetailId, int agencyId, bool isCreditAllocation) {
            try {
                ViewBag.DebtorId = debtorId;
                ViewBag.CreditorId = creditorId;
                ViewBag.ReceiptDetailId = receiptDetailId;
                ViewBag.AgencyId = agencyId;
                ViewBag.IsCreditAllocation = isCreditAllocation;
                ViewBag.IsCreditCardDebtor = Context.Debtor.Include(t => t.FormOfPayments).SingleOrDefault(t => t.Id == debtorId)?.IsCreditCardDebtor ?? false;
                ViewBag.IsMasterDocumentTooltip = isCreditAllocation ? string.Format("Master Document{0}Required when there is no single {1} document or {2} document included in selections.{0}If this is unclear from the selections made, you will be advised if a master document is required when matching is attempted.", Environment.NewLine, debtorId > 0 ? "credit" : "debit", debtorId > 0 ? "negative debit" : "positive credit") : string.Empty;

                return PartialView("~/Views/Accounting/_TransactionDetailAllocationPartial.cshtml");
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TransactionDetailAllocation", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        public async Task<IActionResult> TransactionDetailAllocation_Read([DataSourceRequest] DataSourceRequest request, int debtorId, int creditorId, int receiptDetailId, int agencyId, bool isDetailView, bool isCreditAllocation, TransactionMatchViewStatus transactionMatchViewStatus) {
            try {
                var adminContext = AdminContext;
                var lazyContext = LazyContext;

                List<TransactionDetailAllocationViewModel> q = null;

                if (creditorId > 0) {
                    q = Creditor.GetCreditorLedgerTransactionQuery(lazyContext, creditorId, agencyId, isCreditAllocation, TransactionType.All, isDetailView, transactionMatchViewStatus).Select(row => new TransactionDetailAllocationViewModel {
                        TransactionDetailOrAllocationId = row.TransactionDetailAllocationId,
                        TransactionId = row.TransactionId,
                        TransactionDetailId = row.TransactionDetailId,
                        TransactionRefId = row.TransactionRefId,
                        TransactionDetailRefId = row.TransactionDetailRefId,
                        ReceiptDetailId = row.ReceiptDetailId,
                        NonBspDetailId = row.NonBspDetailId,
                        PaymentDetailId = row.PaymentDetailId,
                        InvoiceDetailId = -1,
                        JournalDetailId = row.JournalDetailId,
                        AdjustmentId = row.AdjustmentId,
                        TransactionType = row.TransactionType,
                        SignType = row.SignType,
                        DocumentNo = row.DocumentNo,
                        DocumentNoLink = row.DocumentNoLink,
                        DocumentDate = row.DocumentDate,
                        Description = row.Description,
                        Reference = row.Reference,
                        Amount = transactionMatchViewStatus == TransactionMatchViewStatus.NotSaved ? 0 : row.Amount,
                        AmountGross = row.AmountGross,
                        AmountNet = row.AmountGross,
                        Debit = row.SignType == SignType.Debit ? row.Debit : null,
                        Credit = row.SignType == SignType.Credit ? row.Credit : null,
                        TransactionMatchStatus = row.TransactionMatchStatus
                    }).ToList();
                }
                else {
                    q = Debtor.GetDebtorLedgerTransactionQuery(lazyContext, debtorId, HttpContext.CurrentCustomerId(), agencyId, receiptDetailId, isCreditAllocation, isDetailView, transactionMatchViewStatus).Select(row => new TransactionDetailAllocationViewModel {
                        TransactionDetailOrAllocationId = row.TransactionDetailAllocationId,
                        TransactionId = row.TransactionId,
                        TransactionDetailId = row.TransactionDetailId,
                        TransactionRefId = row.TransactionRefId,
                        TransactionDetailRefId = row.TransactionDetailRefId,
                        ReceiptDetailId = row.ReceiptDetailId,
                        NonBspDetailId = -1,
                        PaymentDetailId = row.PaymentDetailId,
                        InvoiceDetailId = row.InvoiceDetailId,
                        JournalDetailId = row.JournalDetailId,
                        AdjustmentId = row.AdjustmentId,
                        TransactionType = row.TransactionType,
                        SignType = row.SignType,
                        DocumentNo = row.DocumentNo,
                        DocumentNoLink = isCreditAllocation ? row.DocumentNoLink : row.DocumentNo,
                        DocumentDate = row.DocumentDate,
                        Description = row.Description,
                        Reference = row.Reference,
                        Amount = transactionMatchViewStatus == TransactionMatchViewStatus.NotSaved ? 0 : row.Amount,
                        AmountGross = row.AmountGross,
                        AmountNet = row.AmountGross - (isCreditAllocation ? 0 : row.MerchantFee + row.MerchantFeeTax),
                        Debit = row.SignType == SignType.Debit ? row.Debit : null,
                        Credit = row.SignType == SignType.Credit ? row.Credit : null,
                        TransactionMatchStatus = row.TransactionMatchStatus
                    }).ToList();

                    if (HttpContext.CustomerSettings().IsManagementCustomer) {
                        var customerTxns = (from allocation in q
                                            from invoiceDetail in lazyContext.InvoiceDetail.Where(t => t.Id == allocation.InvoiceDetailId)
                                            from customerTxn in adminContext.CustomerTransaction.Where(t => t.Id == invoiceDetail.CustomerTransactionId)
                                            where customerTxn.PaymentTransactionId > 0
                                            select new {
                                                allocation,
                                                customerTxn
                                            }).ToList();

                        foreach (var row in customerTxns) {
                            row.allocation.PaymentTransactionId = row.customerTxn.PaymentTransactionId;
                        }
                    }
                }

                return Json(await q.ToDataSourceResultAsync(request));
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TransactionDetailAllocation_Read", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> TransactionDetailAllocation_CreateOrUpdate(int debtorId, int creditorId, List<TransactionDetailAllocationModel> allocationList, bool allocationListIsConsolidated, bool unmatchSelections, TransactionMatchViewStatus transactionMatchViewStatus) {
			try {
				if (allocationList.Count == 0)
					throw new UnreportedException("No documents have been selected.");

				var lazyContext = LazyContext;

				var debtor = lazyContext.Debtor.Find(debtorId);
				var allocationType = debtorId > 0 ? LedgerType.DebtorLedger : LedgerType.CreditorLedger;

				new TransactionDetailAllocationCommon(HttpContext).CreateOrUpdate(lazyContext, allocationType, debtor, creditorId, allocationList, allocationListIsConsolidated, true, unmatchSelections, transactionMatchViewStatus);
				return Json(true);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TransactionDetailAllocation_CreateOrUpdate", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region Sales Analysis
		public IActionResult SalesAnalysis() {
			var q = Lists.GetEnumList<TransactionType>(EnumOrderByType.Text, false);

			q.Remove(q.Single(t => t.Value == ((int)TransactionType.Invoice).ToString()));
			q.Remove(q.Single(t => t.Value == ((int)TransactionType.CreditNote).ToString()));
			q.Remove(q.Single(t => t.Value == ((int)TransactionType.Journal).ToString()));

			ViewData["TransactionTypeList"] = q;

			ViewBag.IsCustomView = Context.SalesAnalysisView.Any();
			return View();
		}

		public async Task<IActionResult> SalesAnalysis_Read([DataSourceRequest] DataSourceRequest request, DateTime documentDateFrom, DateTime documentDateTo, bool isTaxIncluded, ExportMethod exportMethod, string exportColumns, string exportGroups) {
			try {
				int agencyId = HttpContext.CurrentDefaultAgencyId();
				int consultantId = HttpContext.CurrentConsultantId();

				bool otherAgencies = HttpContext.OtherAgencies();
				bool otherConsultants = HttpContext.OtherConsultants();

				var q = TransactionDetail.GetSalesAnalysisQuery(LazyContext, agencyId, consultantId, otherAgencies, otherConsultants, documentDateFrom.Date, documentDateTo.Date, isTaxIncluded).ToList();

				if (exportMethod != ExportMethod.None) {
                    var columns = JsonSerializer.Deserialize<string[]>(exportColumns, JsonExtensionsBiz.JsonSerializerOptions());

                    if (exportMethod == ExportMethod.ExcelDetail || exportMethod == ExportMethod.ExcelSummary) {
						var setting = Setting.GetRow(HttpContext.CurrentCustomerId(), documentDateTo.Date);
						var transactionDetails = TransactionDetail.GetTransactionAnalysisQuery(LazyContext, agencyId, setting.FiscalYearStartDate, documentDateTo.Date).Where(t => t.TransactionAnalysisType == TransactionAnalysisType.SalesAnalysis || t.TransactionAnalysisType == TransactionAnalysisType.SalesAnalysisAndTaxAuditReport);

                        if (request != null)
                            transactionDetails = transactionDetails.ApplyFiltering(request.Filters).ApplySorting(request.Groups, request.Sorts);
                        
						string[] groups = null;

						if (!string.IsNullOrEmpty(exportGroups))
                            groups = JsonSerializer.Deserialize<string[]>(exportGroups, JsonExtensionsBiz.JsonSerializerOptions());

                        decimal ytdCash = 0;
						decimal ytdCashNonCommissionable = 0;
						decimal ytdCreditCard = 0;
						decimal ytdCreditCardNonCommissionable = 0;
						decimal ytdCommission = 0;
						decimal ytdGrossAmount = 0;
						decimal ytdNonCommissionable = 0;
						decimal ytdNetAmount = ytdCash + 0;
						decimal ytdYield = 0;

						if (exportMethod == ExportMethod.ExcelDetail) {
							ytdCash = transactionDetails.AsEnumerable().Sum(t => (decimal?)(isTaxIncluded ? t.CashLessNonCommissionableGross : t.CashLessNonCommissionable)) ?? 0;
							ytdCashNonCommissionable = transactionDetails.AsEnumerable().Sum(t => (decimal?)t.CashNonCommissionable) ?? 0;
							ytdCreditCard = transactionDetails.AsEnumerable().Sum(t => (decimal?)(isTaxIncluded ? t.CreditCardLessNonCommissionableGross : t.CreditCardLessNonCommissionable)) ?? 0;
							ytdCreditCardNonCommissionable = transactionDetails.AsEnumerable().Sum(t => (decimal?)t.CreditCardNonCommissionable) ?? 0;
							ytdCommission = transactionDetails.AsEnumerable().Sum(t => (decimal?)(isTaxIncluded ? t.CommissionLessDiscountGross : t.CommissionLessDiscount)) ?? 0;
							ytdGrossAmount = ytdCash + ytdCreditCard;
							ytdNonCommissionable = ytdCashNonCommissionable + ytdCreditCardNonCommissionable;
							ytdNetAmount = ytdCash + ytdCreditCard + ytdCashNonCommissionable + ytdCreditCardNonCommissionable - ytdCommission;
							ytdYield = ytdCash + ytdCreditCard == 0 ? (ytdCommission == 0 ? 0 : (ytdCommission < 0 ? -1 : 1)) : Math.Round(ytdCommission / (ytdCash + ytdCreditCard), 3);

							var reportSource = new InstanceReportSource {
								ReportDocument = new SalesAnalysisReport(q, "Sales Analysis", columns, groups, false, ytdCash, ytdCashNonCommissionable, ytdCreditCard, ytdCreditCardNonCommissionable, ytdGrossAmount, ytdNonCommissionable, ytdCommission, ytdNetAmount, ytdYield)
							};

							var reportResult = Utils.ExportToExcel(reportSource);
							return File(reportResult.DocumentBytes, reportResult.MimeType, "Sales Analysis.xlsx");
						}
						else {
							var salesAnalysis = TransactionDetail.GetSalesAnalysisQuery(transactionDetails, agencyId, consultantId, otherAgencies, otherConsultants, isTaxIncluded).ToList();

							var report1 = new SalesAnalysisReport(q, "Summary", columns, groups, true, ytdCash, ytdCashNonCommissionable, ytdCreditCard, ytdCreditCardNonCommissionable, ytdGrossAmount, ytdNonCommissionable, ytdCommission, ytdNetAmount, ytdYield);
							var report2 = new SalesAnalysisReport(salesAnalysis, "Year To Date", columns, groups, true, ytdCash, ytdCashNonCommissionable, ytdCreditCard, ytdCreditCardNonCommissionable, ytdGrossAmount, ytdNonCommissionable, ytdCommission, ytdNetAmount, ytdYield);

							var reportResult = Utils.ExportToExcel(new List<Telerik.Reporting.Report> { report1, report2 });
							return File(reportResult.DocumentBytes, reportResult.MimeType, "Sales Analysis Summary.xlsx");
						}
					}
					else if (exportMethod == ExportMethod.CsvDetail) {
						var csv = new ExportToCsv<SalesAnalysisReportModel>(q);
						return File(csv.ExportToBytes(columns), AppConstants.ContentTypeCsv, "Sales Analysis.csv");
					}
				}

				var result = await q.ToDataSourceResultAsync(request);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SalesAnalysis_Read", ex);

				if (exportMethod != ExportMethod.None) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
        public async Task<IActionResult> SalesAnalysisView_CreateOrUpdate(int salesAnalysisViewId, string name, DateTime startDate, DateTime endDate, string state) {
            try {
                var context = Context;
                var q = context.SalesAnalysisView.Find(salesAnalysisViewId) ?? new SalesAnalysisView();

                q.Name = name;
                q.StartDate = startDate;
                q.EndDate = endDate;
                q.State = state;

                if (q.Id == 0) {
                    context.Insert(q);
                }
                else {
                    context.Save(q);
                }

                return Json(new { q.Id });
            }
            catch (Exception ex) {
                string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SalesAnalysisView_CreateOrUpdate", ex);
                return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
            }
        }

        [HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> SalesAnalysisView_Delete(int salesAnalysisViewId) {
			try {
				var context = Context;
				var q = context.SalesAnalysisView.Find(salesAnalysisViewId);

				if (q == null)
					throw new UnreportedException(AppConstants.RecordNotFound);

				context.Delete(q);
				return Json(true);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "SalesAnalysisView_Delete", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region Financial Integrity
		public IActionResult FinancialIntegrity() {
			var context = Context;
			var q = context.Agency.Find(HttpContext.CurrentDefaultAgencyId());

			ViewBag.FinancialIntegrityCheckLastRunTime = q.FinancialIntegrityLastRunTimeFormatted;
			ViewBag.FinancialIntegrityStatus = q.GetFinancialIntegrityStatus(context);
			ViewBag.DebtorCreditAllocationStatus = q.DebtorCreditAllocationStatus;
			ViewBag.CreditorCreditAllocationStatus = q.CreditorCreditAllocationStatus;
			ViewBag.MissingTransactionsStatus = q.MissingTransactionsStatus;
			ViewBag.TaxRateConflictStatus = q.TaxRateConflictStatus;
			ViewBag.GeneralLedgerSettingErrorStatus = q.GeneralLedgerSettingErrorStatus;
			ViewBag.MissingAutoGeneratedDocumentStatus = q.MissingAutoGeneratedDocumentStatus;

			return View();
		}

		public async Task<IActionResult> FinancialIntegrity_Read([DataSourceRequest] DataSourceRequest request, DateTime endDate, bool isExport) {
			try {
				if (isExport) {
					if (!HttpContext.IsAdministrator())
						throw new UnreportedException(AppConstants.UnauthorisedAccessExport);

					var lazyContext = LazyContext;
					var financialDetailIntegrityList = new List<FinancialIntegrityDetailExportModel>();

					foreach (var masterRow in FinancialIntegrityCommon.GetFinancialIntegrityList(lazyContext, HttpContext.CurrentCustomerId(), 0, HttpContext.Now(), endDate)) {
						var export = FinancialIntegrityCommon.GetFinancialIntegrityDetailList(lazyContext, 0, masterRow.AccountName, masterRow.FiscalYearStartDateName, endDate).AsEnumerable()
							.GroupBy(t => new {
								t.Transaction.TransactionRefId,
                                t.LedgerType,
                                TransactionType = t.Transaction.EffectiveTransactionType,
                                t.Transaction.DocumentNo,
								t.Transaction.DocumentDate,
                                t.Transaction.DocumentStatus
                            })
							.Select(detailRow => new TransactionDetailViewModel {
								TransactionId = detailRow.Min(t => t.TransactionId),
								TransactionRefId = detailRow.Key.TransactionRefId,
                                LedgerType = detailRow.Key.LedgerType,
                                TransactionType = detailRow.Key.TransactionType,
                                DocumentNo = detailRow.Key.DocumentNo,
								DocumentDate = detailRow.Key.DocumentDate,
								DocumentStatus = detailRow.Key.DocumentStatus,
								AccountName = detailRow.First().GetAccount(false),
								Reference = detailRow.First().Reference,
								Commission = detailRow.Sum(t => t.Commission),
								CommissionTax = detailRow.Sum(t => t.CommissionTax),
								Discount = detailRow.Sum(t => t.Discount),
								DiscountTax = detailRow.Sum(t => t.DiscountTax),
								NonCommissionable = detailRow.Sum(t => t.NonCommissionable),
								NonCommissionableTax = detailRow.Sum(t => t.NonCommissionableTax),
								Amount = detailRow.Sum(t => t.Amount),
								Tax = detailRow.Sum(t => t.Tax)
							}).OrderByDescending(t => t.DocumentDate).ThenBy(t => t.DocumentNo).ThenBy(t => t.CreationTime).ThenBy(t => t.TransactionType).ToList();

						financialDetailIntegrityList.AddRange(export.ConvertAll(row2 => new FinancialIntegrityDetailExportModel {
							FiscalYear = masterRow.FiscalYearStartDateName,
							GLAccount = masterRow.AccountName,
							AccountName = row2.AccountName,
							LedgerType = row2.LedgerType.GetEnumDescription(),
							TransactionType = row2.TransactionType.GetEnumDescription(),
							DocumentNo = row2.DocumentNo,
							DocumentDate = row2.DocumentDate,
							DocumentStatus = row2.DocumentStatus.GetEnumDescription(),
							Reference = row2.Reference,
							Description = row2.Description,
							Commission = row2.Commission,
							CommissionTax = row2.CommissionTax,
							Discount = row2.Discount,
							DiscountTax = row2.DiscountTax,
							NonCommissionable = row2.NonCommissionable,
							NonCommissionableTax = row2.NonCommissionableTax,
							Amount = row2.Amount,
							Tax = row2.Tax
						}));
					}

					var xlsx = new ExportToExcel<FinancialIntegrityDetailExportModel>(financialDetailIntegrityList);
					return File(xlsx.ExportToBytes(), AppConstants.ContentTypeExcel, "Financial Integrity Failures.xlsx");
				}

				var q = FinancialIntegrityCommon.GetFinancialIntegrityList(LazyContext, HttpContext.CurrentCustomerId(), 0, HttpContext.Now(), endDate);

				var result = await q.OrderByDescending(t => t.FiscalYearStartDate).Select(row => new FinancialIntegrityViewModel {
					FinancialIntegrityId = row.Id,
					SettingId = row.SettingId,
					AccountName = row.AccountName,
					FiscalYearStartDate = row.FiscalYearStartDate,
					FiscalYearStartDateName = row.FiscalYearStartDateName,
					LedgerAccountTotal = row.LedgerAccountTotal,
					GlAccountTotal = row.GlAccountTotal,
					FailureCount = row.FailureCount
				}).ToDataSourceResultAsync(request);

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FinancialIntegrity_Read", ex);

				if (isExport) {
					return Redirect("/Shared/Error");
				}
				else {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
			}
		}

		public async Task<IActionResult> FinancialIntegrityDetail_Read([DataSourceRequest] DataSourceRequest request, string accountName, string fiscalYearStartDateName, DateTime endDate) {
			try {
				var q1 = FinancialIntegrityCommon.GetFinancialIntegrityDetailList(LazyContext, 0, accountName, fiscalYearStartDateName, endDate)
					.ApplyFiltering(request.Filters).OrderByDescending(t => t.Transaction.DocumentDate).ThenBy(t => t.Transaction.DocumentNo).ThenBy(t => t.Transaction.TransactionType).ApplySorting(request.Groups, request.Sorts).AsEnumerable()
					.Select(row => new TransactionDetailViewModel {
						TransactionId = row.TransactionId,
						TransactionRefId = row.Transaction.TransactionRefId,
						TransactionType = row.Transaction.EffectiveTransactionType,
						DocumentNo = row.Transaction.DocumentNo,
						DocumentDate = row.Transaction.DocumentDate,
						DocumentNoLink = row.Transaction.GetDocumentNoLink("FinancialIntegrity"),
						AccountNameLink = row.GetAccountLink(false),
						Reference = row.Reference,
						Debit = row.SignType == SignType.Debit ? row.Amount + row.Tax : 0,
						Credit = row.SignType == SignType.Credit ? row.Amount + row.Tax : 0
					}).Where(t => t.Debit != -t.Credit || (accountName == "Supplier Returns Account" && t.Debit == 0)).ToList();

				int total = q1.Count;

				decimal totalDebit = q1.Sum(t => (decimal?)t.Debit) ?? 0;
				decimal totalCredit = q1.Sum(t => (decimal?)t.Credit) ?? 0;

				var q2 = q1.ApplyPaging(request.Page, request.PageSize);

				var aggregateResults = new List<AggregateResult> {
					new AggregateResult(totalDebit, new SumFunction { FunctionName = "Sum", SourceField = "Debit", MemberType = typeof(decimal) }),
					new AggregateResult(totalCredit, new SumFunction { FunctionName = "Sum", SourceField = "Credit", MemberType = typeof(decimal) }),
					new AggregateResult(totalCredit + totalDebit, new SumFunction { FunctionName = "Sum", SourceField = "Amount", MemberType = typeof(decimal) })
				};

				var result = await Task.Run(() => new DataSourceResult {
					Data = q2,
					Total = total,
					AggregateResults = aggregateResults
				});

				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FinancialIntegrityDetail_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> DebtorCreditAllocationError_Read([DataSourceRequest] DataSourceRequest request) {
			try {
				var result = await FinancialIntegrityCommon.GetDebtorCreditAllocationErrorList(LazyContext, HttpContext.CurrentDefaultAgencyId()).ToDataSourceResultAsync(request);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "DebtorCreditAllocationError_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> CreditorCreditAllocationError_Read([DataSourceRequest] DataSourceRequest request) {
			try {
				var result = await FinancialIntegrityCommon.GetCreditorCreditAllocationErrorList(LazyContext, HttpContext.CurrentDefaultAgencyId()).ToDataSourceResultAsync(request);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "CreditorCreditAllocationError_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> MissingTransactions_Read([DataSourceRequest] DataSourceRequest request) {
			try {
				var result = await FinancialIntegrityCommon.GetMissingTransactionsList(LazyContext, HttpContext.CurrentDefaultAgencyId()).ToDataSourceResultAsync(request);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MissingTransactions_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> GeneralLedgerSettingError_Read([DataSourceRequest] DataSourceRequest request) {
			try {
				var result = await FinancialIntegrityCommon.GetGeneralLedgerSettingErrorList(Context, HttpContext.CurrentCustomerId()).ToDataSourceResultAsync(request);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "GeneralLedgerSettingError_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> TaxRateConflict_Read([DataSourceRequest] DataSourceRequest request) {
			try {
				var result = await FinancialIntegrityCommon.GetTaxRateConflictList(AdminContext, LazyContext, AppSettings.Setting(HttpContext.CurrentCustomerId()).CountryCode).ToDataSourceResultAsync(request);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "TaxRateConflict_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		public async Task<IActionResult> MissingAutoGeneratedDocument_Read([DataSourceRequest] DataSourceRequest request) {
			try {
				var result = await FinancialIntegrityCommon.GetMissingAutoGeneratedDocumentList(Context, HttpContext.CurrentDefaultAgencyId()).ToDataSourceResultAsync(request);
				return Json(result);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "MissingAutoGeneratedDocument_Read", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> FinancialIntegrity_RunIntegrityCheck() {
			try {
				var adminContext = AdminContext;
				var lazyContext = LazyContext;

				FinancialIntegrityCommon.InsertMissingTransactions(lazyContext, HttpContext.CurrentCustomerId());
                FinancialIntegrityCommon.CloseOffFiscalPeriods(lazyContext);

                foreach (int agencyId in lazyContext.Agency.Where(t => t.Id > 0).Select(t => t.Id).ToList()) {
					FinancialIntegrityCommon.RunFinancialIntegrityCheck(adminContext, lazyContext, AppSettings.Setting(HttpContext.CurrentCustomerId()).CountryCode, HttpContext.CurrentCustomerId(), agencyId);
				}

				var q = lazyContext.Agency.Find(HttpContext.CurrentDefaultAgencyId());

				return Json(new {
					FinancialIntegrityCheckLastRunTime = q.FinancialIntegrityLastRunTimeFormatted,
					FinancialIntegrityStatus = q.GetFinancialIntegrityStatus(lazyContext),
					DebtorCreditAllocationStatus = q.DebtorCreditAllocationStatus.GetEnumDescription(),
					CreditorCreditAllocationStatus = q.CreditorCreditAllocationStatus.GetEnumDescription(),
					MissingTransactionsStatus = q.MissingTransactionsStatus.GetEnumDescription(),
					TaxRateConflictStatus = q.TaxRateConflictStatus.GetEnumDescription(),
					GeneralLedgerSettingErrorStatus = q.GeneralLedgerSettingErrorStatus.GetEnumDescription(),
					MissingAutoGeneratedDocumentStatus = q.MissingAutoGeneratedDocumentStatus.GetEnumDescription()
				});
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "FinancialIntegrity_RunIntegrityCheck", ex);
				return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
			}
		}
		#endregion

		#region Reports
		public IActionResult Reports() {
			return View();
		}

		public async Task<IActionResult> Accounting_Report(AccountingReportSourceModel model) {
			try {
				model.CustomerId = HttpContext.CurrentCustomerId();
				model.DefaultAgency = await HttpContext.CurrentDefaultAgencyName(Cache);
				model.CreationUser = HttpContext.UserFullName();
				model.CreationTime = HttpContext.Now();

				var reportSource = AccountingDataSources.GetReportSource(Context, User, model);

				RenderingResult result = null;
				string fileName = null;

				switch (model.OutputType) {
					default:
						return PartialView("~/Views/Shared/_ReportViewerPartial.cshtml", new ReportSourceViewModel { ReportSource = reportSource });
					case "ExportPdf":
						result = Utils.ExportToPdf(reportSource);
						fileName = string.Format("{0}.pdf", AccountingDataSources.GetReportFileName(model.ReportSource));
						break;
					case "ExportWord":
						result = Utils.ExportToWord(reportSource);
						fileName = string.Format("{0}.docx", AccountingDataSources.GetReportFileName(model.ReportSource));
						break;
					case "ExportExcel":
						result = Utils.ExportToExcel(reportSource);
						fileName = string.Format("{0}.xlsx", AccountingDataSources.GetReportFileName(model.ReportSource));
						break;
				}

				return File(result.DocumentBytes, result.MimeType, fileName);
			}
			catch (Exception ex) {
				string error = await ExceptionManager.HandleExceptionAsync(HttpContext, ClassName, "Accounting_Report", ex);

				if (model.OutputType == "Report") {
					return Json(new JavaScriptResult(WebUtils.GetMessageScript(error, ex)));
				}
				else {
					return Redirect("/Shared/Error");
				}
			}
		}
		#endregion
	}
}