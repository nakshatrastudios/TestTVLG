
namespace Travelog.PaymentGateway.Enums {
	public enum ClientType {
        Principal = 0,
        Customer = 1
	}
}