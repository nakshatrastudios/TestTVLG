
namespace Travelog.PaymentGateway.Enums {
	public enum PaymentGatewayClientType {
        Principal = 0,
        Customer = 1
	}
}