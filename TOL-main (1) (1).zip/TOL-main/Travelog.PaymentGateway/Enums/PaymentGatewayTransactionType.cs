
namespace Travelog.PaymentGateway.Enums {
	public enum PaymentGatewayTransactionType {
		Unknown = 0,
		Purchase = 1,
		Recurring = 2,
		Moto = 3
	}
}