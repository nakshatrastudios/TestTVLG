﻿using eWAY.Rapid;
using eWAY.Rapid.Enums;
using eWAY.Rapid.Models;
using Travelog.Biz;
using Travelog.PaymentGateway.Enums;

namespace Travelog.PaymentGateway {
    public class Eway {
        private string ApiKey { get; }
        private string Password { get; }
        private string RapidEndpoint { get; }

        public Eway(int customerId, PaymentGatewayClientType clientType, bool isDevelopmentMode) {
            switch (clientType) {
                case PaymentGatewayClientType.Principal:
                    if (isDevelopmentMode) {
                        ApiKey = EwaySandboxPrincipalApiKey;
                        Password = EwaySandboxPrincipalPassword;
                    }
                    else {
                        ApiKey = EwayPrincipalApiKey;
                        Password = EwayPrincipalPassword;
                    }

                    break;
                case PaymentGatewayClientType.Customer:
                    if (isDevelopmentMode) {
                        ApiKey = AppSettings.Setting(customerId).EwaySandboxCustomerApiKey;
                        Password = AppSettings.Setting(customerId).EwaySandboxCustomerPassword;
                    }
                    else {
                        ApiKey = AppSettings.Setting(customerId).EwayCustomerApiKey;
                        Password = AppSettings.Setting(customerId).EwayCustomerPassword;
                    }

                    break;
            }

            RapidEndpoint = isDevelopmentMode ? "Sandbox" : "Production";
        }

        public long CreateOrUpdateTokenCustomer(string cardNo, string cardholderName, string expiryMonth, string expiryYear, string cvn, string countryIsoCode, long tokenCustomerId = 0) {
            string firstName = string.Empty;
            string lastName = string.Empty;

            if (!string.IsNullOrEmpty(cardholderName)) {
                firstName = cardholderName.Split(' ')[0];

                if (cardholderName.Length > firstName.Length)
                    lastName = cardholderName.Substring(firstName.Length).Trim();
            }

            var customer = new Customer {
                TokenCustomerID = tokenCustomerId == 0 ? null : tokenCustomerId.ToString(),
                FirstName = firstName.Left(50),
                LastName = lastName.Left(50),
                Address = new Address {
                    Country = countryIsoCode
                },
                CardDetails = new CardDetails {
                    Name = cardholderName.Left(50),
                    Number = tokenCustomerId == 0 ? cardNo : null,
                    ExpiryMonth = expiryMonth,
                    ExpiryYear = expiryYear,
                    CVN = cvn
                }
            };

            var ewayClient = RapidClientFactory.NewRapidClient(ApiKey, Password, RapidEndpoint);
            CreateCustomerResponse response;

            if (tokenCustomerId == 0) {
                response = ewayClient.Create(PaymentMethod.Direct, customer);
            }
            else {
                response = ewayClient.UpdateCustomer(PaymentMethod.Direct, customer);
            }

            if (response.Errors != null)
                throw new EwayException(GetResponseErrors(response.Errors));

            return response.Customer.TokenCustomerID.ToLong();
        }

        public int MakeTokenPayment(long tokenCustomerId, int amount, string currencyCode, PaymentGatewayTransactionType transactionType,
            string companyName, Address companyAddress, string contactName, string contactPhone, string contactEmail, string invoiceNo = "", string invoiceDescription = "", string invoiceReference = "") {

            if (transactionType != PaymentGatewayTransactionType.Recurring && transactionType != PaymentGatewayTransactionType.Moto)
                throw new UnreportedException("Only Recurring or MOTO payments can be processed with this method.");

            string firstName = string.Empty;
            string lastName = string.Empty;

            if (!string.IsNullOrEmpty(contactName)) {
                firstName = contactName.Split(' ')[0];

                if (contactName.Length > firstName.Length)
                    lastName = contactName.Substring(firstName.Length).Trim();
            }

            var transaction = new Transaction {
                Customer = new Customer {
                    TokenCustomerID = tokenCustomerId.ToString(),
                    CompanyName = companyName.Left(50),
                    FirstName = firstName.Left(50),
                    LastName = lastName.Left(50),
                    Phone = contactPhone.Left(32),
                    Email = contactEmail.Left(50),
                    Address = companyAddress,
                },
                PaymentDetails = new PaymentDetails {
                    InvoiceNumber = invoiceNo,
                    InvoiceDescription = invoiceDescription.Left(64),
                    InvoiceReference = invoiceReference.Left(50),
                    TotalAmount = amount,
                    CurrencyCode = currencyCode
                },
                TransactionType = (TransactionTypes)transactionType,
                Capture = true
            };

            var ewayClient = RapidClientFactory.NewRapidClient(ApiKey, Password, RapidEndpoint);
            var response = ewayClient.Create(PaymentMethod.Direct, transaction);

            if (response.Errors != null)
                throw new EwayException(GetResponseErrors(response.Errors));

            return response.TransactionStatus.TransactionID;
        }

        public int MakeTokenPayment(long tokenCustomerId, string cardNo, string cardholderName, string expiryMonth, string expiryYear, string cvn, int amount, string currencyCode, PaymentGatewayTransactionType transactionType,
            string companyName, Address companyAddress, string contactName, string contactPhone, string contactEmail, string invoiceNo = "", string invoiceDescription = "", string invoiceReference = "") {

            string firstName = string.Empty;
            string lastName = string.Empty;

            if (!string.IsNullOrEmpty(contactName)) {
                firstName = contactName.Split(' ')[0];

                if (contactName.Length > firstName.Length)
                    lastName = contactName.Substring(firstName.Length).Trim();
            }

            var transaction = new Transaction {
                Customer = new Customer {
                    TokenCustomerID = tokenCustomerId.ToString(),
                    CardDetails = new CardDetails {
                        Name = cardholderName,
                        Number = cardNo,
                        ExpiryMonth = expiryMonth,
                        ExpiryYear = expiryYear,
                        CVN = cvn
                    },
                    CompanyName = companyName.Left(50),
                    FirstName = firstName.Left(50),
                    LastName = lastName.Left(50),
                    Phone = contactPhone.Left(32),
                    Email = contactEmail.Left(50),
                    Address = companyAddress
                },
                PaymentDetails = new PaymentDetails {
                    InvoiceNumber = invoiceNo,
                    InvoiceDescription = invoiceDescription.Left(64),
                    InvoiceReference = invoiceReference.Left(50),
                    TotalAmount = amount,
                    CurrencyCode = currencyCode
                },
                TransactionType = (TransactionTypes)transactionType,
                Capture = true
            };

            var ewayClient = RapidClientFactory.NewRapidClient(ApiKey, Password, RapidEndpoint);
            var response = ewayClient.Create(PaymentMethod.Direct, transaction);

            if (response.Errors != null)
                throw new EwayException(GetResponseErrors(response.Errors));

            return response.TransactionStatus.TransactionID;
        }

        public int MakeNonTokenPayment(string cardNo, string cardholderName, string expiryMonth, string expiryYear, string cvn, int amount, string currencyCode, PaymentGatewayTransactionType transactionType,
            string companyName, Address companyAddress, string contactName, string contactPhone, string contactEmail, string invoiceNo = "", string invoiceDescription = "", string invoiceReference = "", string customerReference = "") {

            string firstName = string.Empty;
            string lastName = string.Empty;

            if (!string.IsNullOrEmpty(contactName)) {
                firstName = contactName.Split(' ')[0];

                if (contactName.Length > firstName.Length)
                    lastName = contactName.Substring(firstName.Length).Trim();
            }

            var transaction = new Transaction {
                Customer = new Customer {
                    CardDetails = new CardDetails {
                        Name = cardholderName.Left(50),
                        Number = cardNo,
                        ExpiryMonth = expiryMonth,
                        ExpiryYear = expiryYear,
                        CVN = cvn
                    },
                    Reference = customerReference.Left(50),
                    CompanyName = companyName.Left(50),
                    FirstName = firstName.Left(50),
                    LastName = lastName.Left(50),
                    Phone = contactPhone.Left(32),
                    Email = contactEmail.Left(50),
                    Address = companyAddress
                },
                PaymentDetails = new PaymentDetails {
                    InvoiceNumber = invoiceNo,
                    InvoiceDescription = invoiceDescription.Left(64),
                    InvoiceReference = invoiceReference.Left(50),
                    TotalAmount = amount,
                    CurrencyCode = currencyCode
                },
                TransactionType = (TransactionTypes)transactionType,
                Capture = true
            };

            var ewayClient = RapidClientFactory.NewRapidClient(ApiKey, Password, RapidEndpoint);
            var response = ewayClient.Create(PaymentMethod.Direct, transaction);

            if (response.Errors != null)
                throw new EwayException(GetResponseErrors(response.Errors));

            return response.TransactionStatus.TransactionID;
        }

        public int ProcessRefund(int transactionId, int amount, string currencyCode) {
            var refund = new Refund {
                RefundDetails = new RefundDetails {
                    OriginalTransactionID = transactionId,
                    TotalAmount = amount,
                    CurrencyCode = currencyCode
                }
            };

            var ewayClient = RapidClientFactory.NewRapidClient(ApiKey, Password, RapidEndpoint);
            var response = ewayClient.Refund(refund);

            if (response.Errors != null)
                throw new EwayException(GetResponseErrors(response.Errors));

            return response.TransactionID == null ? 0 : (int)response.TransactionID;
        }

        public int ProcessRefund(int transactionId, string expiryMonth, string expiryYear, int amount, string currencyCode, string companyName, Address companyAddress, string contactName, string contactPhone, string contactEmail, string customerReference = "") {
            string firstName = string.Empty;
            string lastName = string.Empty;

            if (!string.IsNullOrEmpty(contactName)) {
                firstName = contactName.Split(' ')[0];

                if (contactName.Length > firstName.Length)
                    lastName = contactName.Substring(firstName.Length).Trim();
            }

            var refund = new Refund {
                Customer = new Customer {
                    CompanyName = companyName.Left(50),
                    FirstName = firstName.Left(50),
                    LastName = lastName.Left(50),
                    Phone = contactPhone.Left(32),
                    Email = contactEmail.Left(50),
                    Reference = customerReference.Left(50),
                    Address = companyAddress,
                    CardDetails = new CardDetails {
                        ExpiryMonth = expiryMonth,
                        ExpiryYear = expiryYear,
                    }
                },
                RefundDetails = new RefundDetails {
                    OriginalTransactionID = transactionId,
                    TotalAmount = amount,
                    CurrencyCode = currencyCode
                }
            };

            var ewayClient = RapidClientFactory.NewRapidClient(ApiKey, Password, RapidEndpoint);
            var response = ewayClient.Refund(refund);

            if (response.Errors != null)
                throw new EwayException(GetResponseErrors(response.Errors));

            return response.TransactionID == null ? 0 : (int)response.TransactionID;
        }

        public Customer QueryCustomer(long tokenCustomerId) {
            var ewayClient = RapidClientFactory.NewRapidClient(ApiKey, Password, RapidEndpoint);
            var response = ewayClient.QueryCustomer(tokenCustomerId);

            if (response.Errors != null)
                throw new EwayException(GetResponseErrors(response.Errors));

            return response.Customers[0];
        }

        public Transaction QueryInvoiceRef(string invoiceReference, out int transactionId) {
            var ewayClient = RapidClientFactory.NewRapidClient(ApiKey, Password, RapidEndpoint);
            var response = ewayClient.QueryInvoiceRef(invoiceReference);

            if (response.Errors != null)
                throw new EwayException(GetResponseErrors(response.Errors));

            transactionId = response.TransactionStatus.TransactionID;
            return response.Transaction;
        }

        public Transaction QueryTransaction(int transactionId) {
            var ewayClient = RapidClientFactory.NewRapidClient(ApiKey, Password, RapidEndpoint);
            var response = ewayClient.QueryTransaction(transactionId);

            if (response.Errors != null)
                throw new EwayException(GetResponseErrors(response.Errors));

            return response.Transaction;
        }

        public Transaction QueryTransaction(TransactionFilter filter, out int transactionId) {
            var ewayClient = RapidClientFactory.NewRapidClient(ApiKey, Password, RapidEndpoint);
            var response = ewayClient.QueryTransaction(filter);

            if (response.Errors != null)
                throw new EwayException(GetResponseErrors(response.Errors));

            transactionId = response.TransactionStatus.TransactionID;
            return response.Transaction;
        }

        private string GetResponseErrors(List<string> errors) {
            string error = string.Empty;

            foreach (string errorCode in errors) {
                string errorMessage = RapidClientFactory.UserDisplayMessage(errorCode, "EN");

                if (errorMessage.StartsWith(@""""))
                    errorMessage = errorMessage.Substring(1, errorMessage.Length - 2);

                if (errorMessage.StartsWith("Invalid TokenCustomerID", StringComparison.OrdinalIgnoreCase))
                    errorMessage = "Invalid Customer Reference";

                error += string.Format("{0}; ", errorMessage);
            }

            return error.Length <= 3 ? string.Empty : string.Format("{0}.", error.Left(error.Length - 2));
        }

        private static string EwayPrincipalApiKey => "44DD7AREiZES/Jvep0B/84GySjH/FqbrEol77fEXK2NxbbitLWE7vuh1Ctpc2Jq8ZlcaBj";
        public static string EwayPrincipalClientKey => "pq+js7famkVlliZAii98hmHRNxDxtAEuaE0E1NSNGIRVVewTyFwQvfmoXlq6nvJG8Rie86hyW5OjfSC632XTMfxRWKcJeTKLh6m2obBROX8Y0GAgdnzKCrCCNA6oGcXq2ZtnuvhN7oWOfCdJes04D+JA7xUxPgsCveF7sScq59retgC9SFmXWKEnz5+DsGQSbJS19N+CdlB+Iz+ZQpExFXnFr3Bvi+hKQ2fU9n/QgRtoJnhVnZCfT3kPNmRQQPlC7U0uqNFKNn1ttFhRPhMd+OPPnIRNhi0Ubt6qXXqZgNIFroSLBwVQYE6cYMX7gSWQOXu52c2bZHvoQX8dE1SVRw==";
        private static string EwayPrincipalPassword => "AFo9pOgU";
        private static string EwaySandboxPrincipalApiKey => "A1001CM1feU2EDmhhpBQPS6cwSR7qLAtY1jaKhwsk9QcjnelfmNbxGRX12tQZuZthpyIy4";
        public static string EwaySandboxPrincipalClientKey => "5sYW2OruikNjHMIbY+qWOo+Fdzn3cEyertMH+4lKaM06RTT7XuHjw0npAfXUpsooQmvcXVjY+HHBFzjYPMoQLX2QREEkl2NFl3PICkh9/b27r4agmniJ+VNn5/wi5TADewKJiLhY+S8C9LHvfZLWsZDxlf/JJ0JpOLfBZPeTM+C1oMEQTbQBIKSV6R8B6sFp6LSjs+QBY8LyZ1VxvM1yULb2kmwO7sAUoBvUKzJcNpyZooj4iGJssKWnvMuI0dYjWxCeSFKnIyA/4JUuQ4QocfkLl4uVIN4wzGeklrZv0gwopDkoGNebSJC9l1vyOsCy9XhDDf9nCXcZ65EyrmH6KQ==";
        private static string EwaySandboxPrincipalPassword => "YXxxyp9UYKi4tKqbaNAb";
    }
}