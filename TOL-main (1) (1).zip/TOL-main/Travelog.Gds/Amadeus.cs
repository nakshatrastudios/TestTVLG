﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Enums;
using Travelog.Gds.Models;
using Passenger = Travelog.Gds.Models.Passenger;
using PassengerClubMembership = Travelog.Gds.Models.PassengerClubMembership;
using PassengerDocument = Travelog.Gds.Models.PassengerDocument;
using TripLineAir = Travelog.Gds.Models.TripLineAir;
using TripLineAirPassenger = Travelog.Gds.Models.TripLineAirPassenger;
using TripLineAirPassengerAirSegment = Travelog.Gds.Models.TripLineAirPassengerAirSegment;
using TripLineAirSegment = Travelog.Gds.Models.TripLineAirSegment;
using TripLineLand = Travelog.Gds.Models.TripLineLand;
using TripLineRemark = Travelog.Gds.Models.TripLineRemark;

namespace Travelog.Gds {
    public static class Amadeus {
        public static List<CrsModel> ListPnrs(AppLazyContext lazyContext, int customerId, string contentRootPath) {
            var di = new DirectoryInfo(contentRootPath);

            if (!di.GetDirectories().Any(t => t.Name == AppSettings.AmadeusDataFilePath))
                di.CreateSubdirectory(AppSettings.AmadeusDataFilePath);

            string filePath = Path.Combine(contentRootPath, AppSettings.AmadeusDataFilePath);
            string dbName = CustomerSettings.Setting(customerId).DbName;

            di = new DirectoryInfo(filePath);

            if (!di.GetDirectories().Any(t => t.Name == dbName))
                di.CreateSubdirectory(dbName);

            filePath = Path.Combine(filePath, dbName);
            return GetPnrList(lazyContext, customerId, filePath);
        }

        public static void DeleteFiles(string filePath, string[] fileNames) {
            foreach (string fileName in fileNames) {
                var fi = new FileInfo(Path.Combine(filePath, fileName));

                if (fi.Exists)
                    fi.Delete();
            }
        }

        #region Primary Functions
        public static List<CrsModel> GetPnrList(AppLazyContext lazyContext, int customerId, string filePath, string[] fileNames = null, bool excludeInvalid = false, CrsImportModel crsImportModel = null) {
            crsImportModel?.Validate();

            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            var pnrList = new List<CrsModel>();
            var di = new DirectoryInfo(filePath);

            if (!di.Exists)
                return pnrList;

            crsImportModel ??= new CrsImportModel();
            bool isSummary = fileNames == null;

            foreach (string file in Directory.GetFiles(filePath, "air*.txt", SearchOption.TopDirectoryOnly)) {
                var fi = new FileInfo(file);

                if (!fi.Exists || (fileNames?.Contains(fi.Name) == false))
                    continue;

                var crsModel = new CrsModel {
                    Crs = Crs.Amadeus,
                    FileName = fi.Name,
                    IsValid = true,
                    ClientDetail = new ClientDetail {
                        AgencyId = crsImportModel.CrsAgencyId,
                        TripId = crsImportModel.CrsTripId,
                        ProfileId = crsImportModel.CrsProfileId,
                        ConsultantId = -1,
                        CurrencyId = -1,
                        Title = string.Empty,
                        FirstName = string.Empty,
                        LastName = string.Empty,
                        PhoneHome = string.Empty,
                        PhoneWork = string.Empty,
                        Mobile = string.Empty,
                        Fax = string.Empty,
                        Email = string.Empty,
                        Address1 = string.Empty,
                        Address2 = string.Empty,
                        Locality = string.Empty,
                        Region = string.Empty,
                        PostCode = string.Empty,
                        CountryCode = string.Empty,
                        BalanceDueDate = DateTime.MinValue,
                        DepartureDate = DateTime.MinValue
                    }
                };

                ProcessPnr(lazyContext, customerId, crsImportModel, crsModel, file, isSummary);

                if (excludeInvalid && !crsModel.IsValid)
                    continue;

                if (crsModel.PassengerList.Count > 0) {
                    var passenger = crsModel.PassengerList.First(t => int.Parse(t.PassengerNo) < 50);

                    crsModel.ClientDetail.Title = passenger.Title;
                    crsModel.ClientDetail.FirstName = passenger.FirstName;
                    crsModel.ClientDetail.LastName = passenger.LastName;
                    crsModel.ClientDetail.PhoneHome = passenger.PhoneHome.Length == 0 && passenger.Mobile.Length == 0 ? passenger.PhoneNo : passenger.PhoneHome;
                    crsModel.ClientDetail.PhoneWork = passenger.PhoneWork;
                    crsModel.ClientDetail.Mobile = passenger.Mobile;
                    crsModel.ClientDetail.Email = passenger.Email;
                    crsModel.ClientDetail.PaxInfant = crsModel.PassengerList.Count(t => t.PassengerType == PassengerType.Infant);
                    crsModel.ClientDetail.PaxChild = crsModel.PassengerList.Count(t => t.PassengerType == PassengerType.Child);
                    crsModel.ClientDetail.PaxAdult = crsModel.PassengerList.Count - crsModel.ClientDetail.PaxChild - crsModel.ClientDetail.PaxInfant;

                    foreach (var row in crsModel.NewPassengers) {
                        foreach (var passengerClone in crsModel.PassengerList.Where(t => t.PassengerNo == row.Value).ToList()) {
                            crsModel.PassengerList.Add(new Passenger {
                                PassengerId = -2,
                                PassengerNo = row.Key,
                                OriginalPassengerNo = row.Value,
                                CrsKey = GetCrsPassengerKey(row.Key, passengerClone.AccompaniedInfant, crsModel.CrsPnrRef),
                                PassengerType = passengerClone.PassengerType,
                                Title = passengerClone.Title,
                                FirstName = passengerClone.FirstName,
                                LastName = passengerClone.LastName,
                                PhoneNo = passengerClone.PhoneNo,
                                PhoneHome = passengerClone.PhoneHome,
                                PhoneWork = passengerClone.PhoneWork,
                                Mobile = passengerClone.Mobile,
                                Email = passengerClone.Email,
                                Gender = passengerClone.Gender,
                                AccompaniedInfant = passengerClone.AccompaniedInfant
                            });
                        }
                    }
                }

                pnrList.Add(crsModel);
            }

            foreach (var pnr in pnrList) {
                foreach (var tripLineAir in pnr.TripLineAirList) {
                    if (tripLineAir.AirlineId <= 0 && tripLineAir.TripLineAirPassengerList.Count > 0) {
                        var tripLineAirPassenger = tripLineAir.TripLineAirPassengerList.FirstOrDefault(t => t.AirlineId > 0);

                        if (tripLineAirPassenger?.AirlineId > 0)
                            tripLineAir.AirlineId = tripLineAirPassenger.AirlineId;
                    }

                    tripLineAir.TripLineAirSegmentList = tripLineAir.TripLineAirSegmentList.OrderBy(t => t.SeqNo).ToList();
                    tripLineAir.TripLineAirPassengerList = tripLineAir.TripLineAirPassengerList.OrderBy(t => t.CrsPassengerKey).ToList();

                    var tripLineAirSegment = tripLineAir.TripLineAirSegmentList.LastOrDefault();

                    if (tripLineAirSegment?.DepartureDate == AppConstants.VoidDate)
                        tripLineAir.TripLineAirSegmentList.Remove(tripLineAirSegment);
                }
            }

            return pnrList.OrderBy(t => t.CrsPnrRef).ToList();
        }

        private static void ProcessPnr(AppLazyContext lazyContext, int customerId, CrsImportModel crsImportModel, CrsModel crsModel, string file, bool isSummary) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            int tripLineAirId = 1;
            int tripLineLandId = 1;
            int tripLineRemarkId = 1;

            decimal airCommission = 0;
            decimal airCommissionRate = 0;

            string routeInfo = string.Empty;
            string pnrCreatorAgent = string.Empty;
            string pnrTicketingAgent = string.Empty;

            bool excludePassengerSegmentPricing = false;

            DateTime pnrChangeDate = DateTime.MinValue;
            DateTime airCreationDate = DateTime.MinValue;
            DateTime issueDate = DateTime.MinValue;

            var airlinePnrList = new Dictionary<string, string>();
            var operatingAirlineList = new Dictionary<string, string>();

            List<TextLineModel> textLineListAll = null;
            List<AirSegmentModel> airSegmentList = null;

            var textLineList = new List<TextLineModel>();
            var tourCodeList = new List<TourCodeModel>();
            var emdLineList = new List<EmdLineModel>();
            var emdFullList = new List<EmdLineModel>();

            var infantBirthDates = new Dictionary<string, DateTime>();
            var segmentPassengerList = new List<SegmentPassengerModel>();

            var passengerClubMembershipList = new List<PassengerClubMembershipModel>();
            var formOfPaymentList = new List<FormOfPaymentModel>();

            string[] textLines = File.ReadAllLines(file);
            textLines = string.Join(Environment.NewLine, textLines).Split(new string[] { Environment.NewLine }, StringSplitOptions.None);

            string line = textLines.FirstOrDefault(t => t.StartsWith("AIR-"));

            if (line != null) {
                string[] textParts = line.TrimStart("AIR-").Split(';');
                int versionNo = int.Parse(textParts[0].Substring(3));

                crsModel.IsValid = versionNo == 207;
                crsModel.IsTicketed = textParts[1].Length == 2 && textParts[1].EndsWith("A");

                if (!isSummary && !crsModel.IsValid)
                    throw new CrsException("One or more selected files are invalid.");
            }

            line = textLines.FirstOrDefault(t => t.StartsWith("D-"));

            if (line != null) {
                string[] textParts = line.TrimStart("D-").Split(';');
                pnrChangeDate = Utils.GetDate(textParts[0], "yyMMdd");

                if (textParts.Length > 1)
                    airCreationDate = Utils.GetDate(textParts[1], "yyMMdd");

                if (crsModel.IsTicketed && textParts.Length > 2)
                    issueDate = Utils.GetDate(textParts[2], "yyMMdd");
            }

            var segmentNoOrder = new Dictionary<string, int>();

            int i = 0;
            int j = 0;

            foreach (string textLine in textLines) {
                string[] parts = textLine.Split(';');

                string part = parts.FirstOrDefault(t => t.StartsWith("AT-"));
                int index = parts.IndexOf(part) + 1;

                if (!isSummary && textLine.StartsWith("TSA-")) {
                    foreach (var segmentNo in GetAirSegmentAssignments(textLine, 2)) {
                        if (!segmentNoOrder.ContainsKey(segmentNo))
                            segmentNoOrder.Add(segmentNo, j++);
                    }
                }

                var amadeusSegment = GetAmadeusSegment(textLine);

                textLineList.Add(new TextLineModel {
                    RowIndex = i++,
                    AmadeusSegment = amadeusSegment,
                    Value = textLine,
                    EmdType = index <= 0 ? string.Empty : parts[index] == "S" ? "EMDS" : "EMDA",
                    IsEmd = textLine.StartsWith("EMD") || (textLine.StartsWith("U-") && parts[1].EndsWith("EMD")),
                    IsVoid = amadeusSegment.TripLineType == TripLineType.Air && textLine.Split(';').Length >= 6 && textLine.Split(';')[5] == "VOID",
                    SeqNo = textLine.StartsWith("H-") || textLine.StartsWith("U-") || textLine.StartsWith("EMD") ? int.Parse(textLine.Split(';')[1].Left(3)) : 0
                });
            }

            foreach (var textLine in textLineList.Where(AirSegmentsWhereClause()).ToList()) {
                textLine.SeqNo = textLine.ResolveAirSegmentSeqNo(textLineList);
            }

            foreach (var textLine in textLineList.Where(t => t.Value.StartsWith("EMD")).ToList()) {
                string segmentNo = textLine.Value.Split(';')[1].Left(3);
                string[] textParts = textLine.Value.Split(';');

                foreach (string passengerNo in GetPassengerAssignments(textParts[textParts.Length - 2], 0)) {
                    segmentPassengerList.Add(new SegmentPassengerModel {
                        SegmentNo = segmentNo,
                        PassengerNo = passengerNo,
                        IsEmd = true
                    });
                }
            }

            if (isSummary) {
                textLineList = textLineList.Where(t => t.Value.StartsWith("C-") || t.Value.StartsWith("AIR-") || t.Value.StartsWith("MUC1") || t.Value.StartsWith("I-") || t.Value.StartsWith("H-") || t.Value.StartsWith("U-")).ToList();
            }
            else {
                ProcessTsaLines(crsModel, textLineList, segmentPassengerList);

                textLineListAll = textLineList.ToList();
                var airSegments = GetAirSegments(customerId, textLineList, segmentNoOrder);

                string[] segmentNoList = textLineList.Where(t => t.AmadeusSegment.TripLineType == TripLineType.Air && !t.IsEmd).Select(t => t.Value.Split(';')[1].Left(3)).Distinct().ToArray();
                string[] passengerNoList = textLineList.Where(t => t.Value.StartsWith("I-")).Select(t => t.Value.Split(';')[1].Left(2)).ToArray();

                ProcessSegmentPassengerAssignments(lazyContext, textLineList, airSegments, segmentPassengerList, segmentNoList, passengerNoList, airCreationDate, issueDate);

                airSegments = airSegments.Where(t1 => segmentPassengerList.Any(t2 => t2.IsEmd || (t2.SegmentNo == t1.SegmentNo && t2.PassengerNo == t1.PassengerNo))).ToList();

                airSegmentList = GetAirSegments(lazyContext, customerId, textLineList, airSegments, ref excludePassengerSegmentPricing);
                emdLineList = GetEmdLineList(lazyContext, customerId, textLineList, segmentPassengerList, emdFullList, airCreationDate);

                crsModel.ClientDetail.CurrencyId = airSegmentList.OrderBy(t => t.IsForeignCurrency ? 0 : 1)?.FirstOrDefault()?.CurrencyId ?? -1;

                textLineList = textLineList.Where(t => t.Value.StartsWith("AIR-") || t.Value.StartsWith("AM ") || t.Value.StartsWith("MUC1") || t.Value.StartsWith("FM*M*")
                    || t.Value.StartsWith("FO") || t.Value.StartsWith("FP") || t.Value.StartsWith("FQV") || t.Value.StartsWith("FT") || t.Value.StartsWith("FV") || t.Value.StartsWith("S-")
                    || t.Value.StartsWith("TK") || t.Value.StartsWith("TSA-") || t.Value.StartsWith("T-") || t.Value.StartsWith("I-") || t.Value.StartsWith("H-") || t.Value.StartsWith("U-")
                    || t.Value.StartsWith("X-") || t.Value.StartsWith("EMD") || t.Value.StartsWith("SSR"))
                    .OrderBy(t => t.Value.StartsWith("FM*M*") || t.Value.StartsWith("FP") || t.Value.StartsWith("FQV") || t.Value.StartsWith("FT") || t.Value.StartsWith("MUC1") ? -4 : -3)
                    .ThenBy(t => t.Value.StartsWith("I-") ? -2 : t.Value.StartsWith("H-") || t.Value.StartsWith("U-") ? t.SeqNo : t.Value.StartsWith("EMD") ? t.SeqNo + 500 : -1)
                    .ThenBy(t => t.Value.StartsWith("SSR-") ? 1 : 0).ToList();
            }

            foreach (var textLine in textLineList) {
                string lineId = GetLineId(textLine.Value);

                if (lineId == "AM") {
                    AddAddress(crsModel, textLine, lineId);
                }
                else if (lineId == "C-") {
                    string[] textParts = textLine.Value.TrimStart(lineId).Split(' ');
                    textParts = textParts[1].Split('-');

                    if (textParts.Length > 1) {
                        pnrCreatorAgent = textParts[0].Length <= 6 ? string.Empty : textParts[0].Substring(4, 2);
                        pnrTicketingAgent = textParts[1].Length <= 6 ? string.Empty : textParts[1].Substring(4, 2);
                    }
                }
                else if (lineId == "FM") {
                    string[] textParts = textLine.Value.Split('*');

                    if (textParts.Length > 2) {
                        string textPart = textParts[2].Split(';')[0];

                        if (textPart.EndsWith("A")) {
                            textPart = textPart.Left(textPart.Length - 1);
                            decimal.TryParse(textPart, out airCommission);
                        }
                        else {
                            decimal.TryParse(textPart, out airCommissionRate);
                        }
                    }
                }
                else if (lineId == "FP") {
                    string[] textParts = textLine.Value.TrimStart("FPO/").TrimStart(lineId).Split(';');

                    if (!textParts[0].Contains('/'))
                        continue;

                    string[] crsCodes = textParts[0].Split('/')[0].Split('+');

                    if (textParts.Length > 2) {
                        string[] segmentNos = GetAirSegmentAssignments(textParts[textParts.Length - 2], 0);
                        string[] passengerNos = GetPassengerAssignments(textParts[textParts.Length - 1], 0);

                        foreach (string segmentNo in segmentNos) {
                            foreach (string passengerNo in passengerNos) {
                                foreach (string crsCode in crsCodes) {
                                    string code = crsCode.Left(10).TrimEnd("0123456789".ToCharArray());

                                    if (code.StartsWith("CC"))
                                        code = code.TrimStart("CC");

                                    int formOfPaymentId = FormOfPayment.GetFormOfPayment(lazyContext, Crs.Amadeus, code).Id;

                                    if (formOfPaymentId <= 0 || formOfPaymentList.Any(t => t.SegmentNo == segmentNo && t.PassengerNo == passengerNo && t.FormOfPaymentId == formOfPaymentId))
                                        continue;

                                    formOfPaymentList.Add(new FormOfPaymentModel {
                                        SegmentNo = segmentNo,
                                        PassengerNo = passengerNo,
                                        FormOfPaymentId = formOfPaymentId
                                    });
                                }
                            }
                        }
                    }
                    else {
                        foreach (string crsCode in crsCodes) {
                            string code = crsCode.Left(10).TrimEnd("0123456789".ToCharArray());

                            if (code.StartsWith("CC"))
                                code = code.TrimStart("CC");

                            int formOfPaymentId = FormOfPayment.GetFormOfPayment(lazyContext, Crs.Amadeus, code).Id;

                            if (formOfPaymentId <= 0 || formOfPaymentList.Any(t => t.FormOfPaymentId == formOfPaymentId))
                                continue;

                            formOfPaymentList.Add(new FormOfPaymentModel {
                                SegmentNo = "*",
                                PassengerNo = "*",
                                FormOfPaymentId = formOfPaymentId
                            });
                        }
                    }
                }
                else if (lineId == "FQV") {
                    string[] textParts = textLine.Value.TrimStart(lineId).Trim().Split(';');
                    string clubMembershipAirlineCode = textParts[0].Split(' ')[0];

                    int clubMembershipId = ClubMembership.GetClubMembership(lazyContext, clubMembershipAirlineCode).Id;

                    if (clubMembershipId <= 0)
                        continue;

                    string[] passengerNos = GetPassengerAssignments(textParts[1], 0);
                    string clubMembershipNo = textParts[0].Split(' ')[2].Split('-')[1];

                    foreach (string passengerNo in passengerNos) {
                        passengerClubMembershipList.Add(new PassengerClubMembershipModel {
                            PassengerNo = passengerNo,
                            AirlineId = Airline.GetAirline(lazyContext, clubMembershipAirlineCode).Id,
                            ClubMembershipId = clubMembershipId,
                            ClubMembershipNo = clubMembershipNo
                        });
                    }
                }
                else if (lineId == "FT") {
                    string[] textParts = textLine.Value.TrimStart(lineId).Split(';');
                    string[] tourCode = textParts[0].Split('*');
                    string[] segmentNos = GetAirSegmentAssignments(textParts[1], 0);
                    string[] passengerNos = GetPassengerAssignments(textParts[2], 0);

                    string tourCodeItem = tourCode[tourCode.Length - 1];

                    foreach (string segmentNo in segmentNos) {
                        foreach (string passengerNo in passengerNos) {
                            if (tourCodeList.Any(t => t.SegmentNo == segmentNo && t.PassengerNo == passengerNo))
                                continue;

                            tourCodeList.Add(new TourCodeModel {
                                SegmentNo = segmentNo,
                                PassengerNo = passengerNo,
                                TourCode = tourCodeItem
                            });
                        }
                    }
                }
                else if (lineId == "MUC1") {
                    crsModel.CrsPnrRef = textLine.Value.Substring(6, 6);

                    if (isSummary)
                        continue;

                    string[] textParts = textLine.Value.TrimStart(lineId).Split(';');
                    int start = 0;
                    int end = 0;

                    if (textParts.Length > 31) {
                        start = 31;
                        end = textParts.Length;
                    }

                    for (int k = start; k < end; k++) {
                        string[] airlinePnr = textParts[k].Split(' ');

                        if (!airlinePnrList.Any(t => t.Key == airlinePnr[0]) && airlinePnr.Length >= 2)
                            airlinePnrList.Add(airlinePnr[0], airlinePnr[1]);
                    }
                }
                else if (lineId == "X-") {
                    string[] textParts = textLine.Value.TrimStart(lineId).Split(';');

                    if (textParts.Length > 5) {
                        string segmentNo = textParts[1].Left(3);
                        textParts = textParts[5].Split(" ", StringSplitOptions.RemoveEmptyEntries);
                        string flightNo = string.Format("{0}{1}", textParts[0], textParts[1].TrimStart('0'));
                        operatingAirlineList.Add(segmentNo, flightNo);
                    }
                }
                else if (lineId == "I-") {
                    AddPassenger(lazyContext, crsModel, textLine, lineId, infantBirthDates, isSummary);
                }
                else if (lineId == "H-" || lineId == "U-" || lineId == "EMD" || lineId == "SSR") {
                    string segmentNo = string.Empty;

                    if (!isSummary && lineId != "SSR")
                        segmentNo = textLine.Value.Split(';')[1].Left(3);

                    AddTripLines(
                        lazyContext: lazyContext,
                        customerId: customerId,
                        crsModel: crsModel,
                        crsImportModel: crsImportModel,
                        airlinePnrList: airlinePnrList,
                        operatingAirlineList: operatingAirlineList,
                        airSegmentList: airSegmentList,
                        segmentPassengerList: segmentPassengerList,
                        formOfPaymentList: formOfPaymentList,
                        tourCodeList: tourCodeList,
                        emdLineList: emdLineList,
                        emdFullList: emdFullList,
                        textLine: textLine,
                        lineId: lineId,
                        segmentNo: segmentNo,
                        airCreationDate: airCreationDate,
                        issueDate: issueDate,
                        airCommission: airCommission,
                        airCommissionRate: airCommissionRate,
                        excludePassengerSegmentPricing: excludePassengerSegmentPricing,
                        tripLineAirId: ref tripLineAirId,
                        tripLineLandId: ref tripLineLandId,
                        tripLineRemarkId: ref tripLineRemarkId,
                        routeInfo: ref routeInfo,
                        isSummary: isSummary
                    );
                }
            }

            crsModel.CrsPnrDate = airCreationDate;
            crsModel.RouteInfo = routeInfo.TrimStart('/');
            crsModel.PnrCreatorAgent = pnrCreatorAgent;
            crsModel.PnrTicketingAgent = pnrTicketingAgent;

            if (isSummary)
                return;

            foreach (var passengerClubMembership in passengerClubMembershipList) {
                foreach (var passenger in crsModel.PassengerList) {
                    string crsKey = GetCrsPassengerKey(passengerClubMembership.PassengerNo, passenger.AccompaniedInfant, crsModel.CrsPnrRef);

                    if (passenger.CrsKey == crsKey) {
                        passenger.PassengerClubMembershipList.Add(new PassengerClubMembership {
                            CrsPassengerKey = crsKey,
                            AirlineId = passengerClubMembership.AirlineId,
                            ClubMembershipId = passengerClubMembership.ClubMembershipId,
                            ClubMembershipNo = passengerClubMembership.ClubMembershipNo
                        });
                    }
                }
            }

            decimal taxRate = CustomerSettings.GetTaxRate(customerId, airCreationDate);
            int saleTypeId = 0;

            foreach (var tripLineAir in crsModel.TripLineAirList) {
                if (tripLineAir.TripLineAirSegmentList.All(t => lazyContext.City.Find(t.DepartureCityId).Country.CountryZone == CountryZone.Domestic && lazyContext.City.Find(t.ArrivalCityId).Country.CountryZone == CountryZone.Domestic)) {
                    saleTypeId = AppSettings.Setting(customerId).CrsDomesticAirSaleTypeId;
                }
                else {
                    saleTypeId = AppSettings.Setting(customerId).CrsInternationalAirSaleTypeId;
                }

                bool isTaxApplicable = lazyContext.SaleType.Find(saleTypeId).IsTaxApplicable;

                foreach (var airPassenger in tripLineAir.TripLineAirPassengerList) {
                    airPassenger.SaleTypeId = saleTypeId;

                    if (!isTaxApplicable)
                        continue;

                    airPassenger.Tax = GetValidatedLocalTax(airPassenger.Amount, airPassenger.Tax, taxRate);
                    airPassenger.NonCommissionable -= airPassenger.Tax;
                    airPassenger.Amount += airPassenger.Tax;
                    airPassenger.TicketedFare += airPassenger.Tax;
                }
            }
        }

        private static void ProcessTsaLines(CrsModel crsModel, List<TextLineModel> textLineList, List<SegmentPassengerModel> segmentPassengerList) {
            TextLineModel passengerLine = null;
            int count = 0;

            foreach (var tsaLine in textLineList.Where(t => t.Value.StartsWith("TSA-") || t.Value.StartsWith("I-")).ToList()) {
                if (tsaLine.Value.StartsWith("I-")) {
                    count = 0;
                    passengerLine = tsaLine;
                }

                if (tsaLine.Value.StartsWith("TSA-"))
                    count++;

                if (count > 1) {
                    string passengerNo = passengerLine.Value.Split(';')[1].Left(2);
                    string passengerNoClone = string.Format("{0:d2}", int.Parse(passengerNo) + 50);

                    var passengerLineClone = new TextLineModel {
                        RowIndex = passengerLine.RowIndex + 500,
                        AmadeusSegment = passengerLine.AmadeusSegment,
                        Value = string.Format("I-0{0};{1}{2}", passengerNoClone, passengerNoClone, passengerLine.Value.Substring(8)),
                        EmdType = string.Empty,
                        IsEmd = false,
                        IsVoid = false
                    };

                    textLineList.Insert(tsaLine.RowIndex, passengerLineClone);

                    foreach (string segmentNo in GetAirSegmentAssignments(tsaLine.Value, 2)) {
                        if (segmentPassengerList.Any(t => t.SegmentNo == segmentNo && t.PassengerNo == passengerNoClone))
                            continue;

                        segmentPassengerList.Add(new SegmentPassengerModel {
                            SegmentNo = segmentNo,
                            PassengerNo = passengerNoClone,
                            IsEmd = false
                        });
                    }

                    if (!crsModel.NewPassengers.ContainsKey(passengerNoClone))
                        crsModel.NewPassengers.Add(passengerNoClone, passengerNo);
                }
            }
        }

        private static void ProcessSegmentPassengerAssignments(AppLazyContext lazyContext, List<TextLineModel> textLineList, List<AirSegmentModel> airSegments, List<SegmentPassengerModel> segmentPassengerList, string[] segmentNoList, string[] passengerNoList, DateTime airCreationDate, DateTime issueDate) {
            bool fvLineExists = textLineList.Any(t => t.Value.StartsWith("FV"));
            bool tsaLineExists = textLineList.Any(t => t.Value.StartsWith("TSA-"));

            foreach (var textLine in textLineList.Where(t => t.Value.StartsWith("FV") || t.Value.StartsWith("TK") || t.Value.StartsWith("TSA-")).OrderBy(t => t.Value.StartsWith("FV") ? 0 : 1).ToList()) {
                string lineId = GetLineId(textLine.Value);

                if (lineId == "FV") {
                    int airlineId = -1;
                    string arlineCode = string.Empty;

                    if (textLine.Value.Contains('*')) {
                        string[] parts = textLine.Value.Split('*');

                        if (parts.Length > 2)
                            arlineCode = parts[2];
                    }
                    else {
                        arlineCode = textLine.Value.TrimStart(lineId).Left(2);
                    }

                    airlineId = Airline.GetAirline(lazyContext, arlineCode).Id;

                    string[] textParts = textLine.Value.TrimStart(lineId).Trim().Split(';');

                    string[] segmentNos = Array.Empty<string>();
                    string[] passengerNos = Array.Empty<string>();

                    if (textParts.Length > 3) {
                        segmentNos = GetAirSegmentAssignments(textParts[1], 0);
                        passengerNos = GetPassengerAssignments(textParts[2], 0);
                    }

                    if (segmentNos.Length == 0) {
                        segmentNos = airSegments.Select(t => t.SegmentNo).Distinct().ToArray();
                        passengerNos = airSegments.Select(t => t.PassengerNo).Distinct().ToArray();
                    }

                    foreach (string segmentNo in segmentNos) {
                        foreach (string passengerNo in passengerNos.Where(t => int.Parse(t) < 50)) {
                            if (segmentPassengerList.Any(t => t.SegmentNo == segmentNo && int.Parse(t.PassengerNo) > 50) || segmentPassengerList.Any(t => t.SegmentNo == segmentNo && t.PassengerNo == passengerNo))
                                continue;

                            segmentPassengerList.Add(new SegmentPassengerModel {
                                SegmentNo = segmentNo,
                                PassengerNo = passengerNo,
                                IssueDate = issueDate,
                                AirlineId = airlineId
                            });
                        }
                    }
                }
                else if (lineId == "TK") {
                    string[] textParts = textLine.Value.TrimStart(lineId).Trim().Split('/');

                    if (issueDate == DateTime.MinValue && textLine.Value.StartsWith("TKOK"))
                        DateTime.TryParse(string.Format("{0}{1}", textParts[0].Substring(2), airCreationDate.Year), out issueDate);

                    if (fvLineExists || tsaLineExists)
                        continue;

                    string[] segmentNos = Array.Empty<string>();
                    string[] passengerNos = Array.Empty<string>();

                    if (textParts.Length > 3) {
                        segmentNos = GetAirSegmentAssignments(textParts[3], 1);
                        passengerNos = GetPassengerAssignments(textParts[3], 2);
                    }

                    if (segmentNos.Length == 0)
                        segmentNos = segmentNoList;

                    if (passengerNos.Length == 0)
                        passengerNos = passengerNoList;

                    foreach (string segmentNo in segmentNos) {
                        foreach (string passengerNo in passengerNos.Where(t => int.Parse(t) < 50)) {
                            if (segmentPassengerList.Any(t => t.SegmentNo == segmentNo && int.Parse(t.PassengerNo) > 50) || segmentPassengerList.Any(t => t.SegmentNo == segmentNo && t.PassengerNo == passengerNo))
                                continue;

                            segmentPassengerList.Add(new SegmentPassengerModel {
                                SegmentNo = segmentNo,
                                PassengerNo = passengerNo,
                                IssueDate = issueDate
                            });
                        }
                    }
                }
                else if (lineId == "TSA-" && !fvLineExists) {
                    int airlineId = -1;

                    int skip = textLineList.IndexOf(textLine);
                    var endLine = textLineList.Skip(skip).FirstOrDefault(t => t.Value.StartsWith("L-*"));

                    if (endLine != null) {
                        string arlineCode = endLine.Value.TrimStart("L-*").Left(2);
                        airlineId = Airline.GetAirline(lazyContext, arlineCode).Id;
                    }

                    string[] textParts = textLine.Value.TrimStart(lineId).Trim().Split(';');
                    string[] segmentNos = Array.Empty<string>();

                    if (textParts.Length > 2)
                        segmentNos = GetAirSegmentAssignments(textParts[2], 0);

                    if (segmentNos.Length == 0)
                        segmentNos = airSegments.Select(t => t.SegmentNo).Distinct().ToArray();

                    foreach (string segmentNo in segmentNos) {
                        foreach (string passengerNo in passengerNoList.Where(t => int.Parse(t) < 50)) {
                            if (segmentPassengerList.Any(t => t.SegmentNo == segmentNo && int.Parse(t.PassengerNo) > 50) || segmentPassengerList.Any(t => t.SegmentNo == segmentNo && t.PassengerNo == passengerNo))
                                continue;

                            segmentPassengerList.Add(new SegmentPassengerModel {
                                SegmentNo = segmentNo,
                                PassengerNo = passengerNo,
                                IssueDate = issueDate,
                                AirlineId = airlineId
                            });
                        }
                    }
                }
            }

            foreach (var segmentPassenger in segmentPassengerList.Where(t => t.IssueDate == DateTime.MinValue).ToList()) {
                segmentPassenger.IssueDate = issueDate;
            }
        }

        private static List<EmdLineModel> GetEmdLineList(AppLazyContext lazyContext, int customerId, List<TextLineModel> textLineList, List<SegmentPassengerModel> segmentPassengerList, List<EmdLineModel> emdFullList, DateTime airCreationDate, bool includeEmdSegments = false) {
            var emdLineList = new List<EmdLineModel>();

            foreach (var textLine in textLineList.Where(t => t.IsEmd)) {
                string[] textParts = textLine.Value.Split(';');

                int partsIndex;

                if (textLine.Value.StartsWith("EMD")) {
                    partsIndex = 4;
                }
                else {
                    partsIndex = 5;
                }

                string startDateTime = textParts[partsIndex];
                string segment = string.Format("{0}/{1}", textParts[partsIndex + 6], textParts[partsIndex + 7]).TrimEnd('/');
                string code = textParts[partsIndex + 13];
                string issueReason = textParts[partsIndex + 14];

                if (textParts[partsIndex + 19].Length > 0 && textParts[partsIndex + 20].Length > 0)
                    issueReason = string.Format("{0}: {1} {2}", issueReason, textParts[partsIndex + 19], textParts[partsIndex + 20]);

                DateTime startDate = DateTime.MinValue;
                DateTime endDate = DateTime.MinValue;

                GetStartEndDate(airCreationDate, startDateTime, string.Empty, ref startDate, ref endDate, false);

                decimal localAmount = 0;
                decimal localNonCommissionable = 0;

                decimal foreignAmount = 0;
                decimal foreignNonCommissionable = 0;

                string currencyCode = string.Empty;
                string textPart = textParts[partsIndex + 27].Trim();

                if (textPart.Length == 0)
                    textPart = textParts[partsIndex + 24].Trim();

                if (textPart.Length > 3) {
                    currencyCode = textPart.Left(3);
                    decimal.TryParse(textPart.Substring(3).Trim(), out foreignAmount);
                }

                textPart = textParts[partsIndex + 30].Trim();

                if (textPart.Length > 3)
                    decimal.TryParse(textPart.Substring(3).Trim(), out foreignNonCommissionable);

                decimal exchangeRate = GetExchangeRate(lazyContext, customerId, new AmadeusSegmentModel { SegmentType = AmadeusSegmentType.Emd, TripLineType = TripLineType.Air }, currencyCode);

                if (exchangeRate != 0) {
                    localAmount = Math.Round(foreignAmount / exchangeRate, 2);
                    localNonCommissionable = Math.Round(foreignNonCommissionable / exchangeRate, 2);
                }

                string[] segmentNos;
                string[] passengerNos;

                string airSegmentPart = textParts[textParts.Length - 1];

                if (airSegmentPart.Left(1) == "P") {
                    segmentNos = segmentPassengerList.Select(t => t.SegmentNo).Distinct().ToArray();
                    passengerNos = GetPassengerAssignments(textParts[textParts.Length - 1], 0);
                }
                else {
                    segmentNos = GetAirSegmentAssignments(airSegmentPart, 0);
                    passengerNos = GetPassengerAssignments(textParts[textParts.Length - 2], 0);
                }

                foreach (string segmentNo in segmentNos) {
                    foreach (string passengerNo in passengerNos) {
                        if (emdLineList.Any(t => t.SegmentNo == segmentNo && t.PassengerNo == passengerNo))
                            continue;

                        emdLineList.Add(new EmdLineModel {
                            SegmentNo = segmentNo,
                            PassengerNo = passengerNo,
                            Amount = localAmount,
                            NonCommissionable = localNonCommissionable,
                            Segment = segment,
                            Comment = string.Format("EMD Type: {0}; Date: {1:d};{{0}} Coupon Value: {2}{3:f2}; Code: {4}; Issue Reason: {5}.", textLine.EmdType, startDate, currencyCode, localAmount, code, issueReason)
                        });
                    }
                }
            }

            emdFullList.AddRange(emdLineList);
            var emdLineListClone = new List<EmdLineModel>();

            foreach (var emdLine in emdLineList.GroupBy(t => new { t.PassengerNo }).ToList()) {
                string segments = string.Empty;

                if (includeEmdSegments) {
                    string[] previousSegmentParts = Array.Empty<string>();

                    foreach (string segment in emdLine.Select(t => t.Segment)) {
                        string[] segmentParts = segment.Split('/');

                        if (previousSegmentParts.Length == 0 || segmentParts[0] != previousSegmentParts[1]) {
                            segments += string.Format("/{0}", segment);
                        }
                        else {
                            segments += string.Format("/{0}", segmentParts[1]);
                        }

                        previousSegmentParts = segmentParts;
                    }

                    segments = segments.TrimStart('/');

                    if (segments.Length > 0)
                        segments = string.Format(" Segments: {0};", segments);
                }

                emdLineListClone.Add(new EmdLineModel {
                    SegmentNo = emdLine.First().SegmentNo,
                    PassengerNo = emdLine.Key.PassengerNo,
                    Amount = emdLine.First().Amount,
                    NonCommissionable = emdLine.First().NonCommissionable,
                    Comment = string.Format(emdLine.First().Comment, segments)
                });
            }

            return emdLineListClone;
        }

        private static List<AirSegmentModel> GetAirSegments(int customerId, List<TextLineModel> textLineList, Dictionary<string, int> segmentNoOrder) {
            var airSegments = new List<AirSegmentModel>();
            var airSegmentsClone = new List<AirSegmentModel>();
            var fareBasisList = new List<FareBasisModel>();

            var segmentLineList = textLineList.Where(t => t.AmadeusSegment.TripLineType == TripLineType.Air).ToList();
            int i = 0;

            foreach (var textLine in textLineList.Where(t => t.AmadeusSegment.TripLineType == TripLineType.Air || (t.Value.StartsWith("M-") && t.Value != "M-") || t.Value.StartsWith("I-")).OrderBy(t => t.AmadeusSegment.TripLineType == TripLineType.Air && !t.IsEmd ? 1 : t.IsEmd ? 2 : 0).ThenBy(t => t.RowIndex).ToList()) {
                if (textLine.Value.StartsWith("M-")) {
                    foreach (string textPart in textLine.Value.TrimStart("M-").Split(';')) {
                        string[] textParts = textPart.Split(' ');

                        fareBasisList.Add(new FareBasisModel {
                            Index = i++,
                            FareBasis = textParts[0],
                            TicketDesignator = textParts.Length == 0 ? string.Empty : textParts[1]
                        });
                    }
                }
                else if (textLine.Value.StartsWith("I-")) {
                    string[] textParts = textLine.Value.Split(';');

                    airSegments.Add(new AirSegmentModel(customerId) {
                        PassengerIndex = textLine.RowIndex,
                        PassengerNo = textParts[1].Left(2),
                        AccompaniedInfant = textParts[1].EndsWith("(INF)")
                    });
                }
                else if (textLine.AmadeusSegment.TripLineType == TripLineType.Air || textLine.IsVoid) {
                    string lineId = GetLineId(textLine.Value);

                    string[] textParts = textLine.Value.Split(';');
                    string[] passengerNos = Array.Empty<string>();

                    if (textLine.IsEmd) {
                        string textPart;

                        if (textParts[textParts.Length - 1].StartsWith("P")) {
                            textPart = textParts[textParts.Length - 1];
                        }
                        else {
                            textPart = textParts[textParts.Length - 2];
                        }

                        passengerNos = GetPassengerAssignments(textPart, 0);
                    }

                    string segmentNo = textParts[1].Left(3);
                    int index = segmentLineList.IndexOf(textLine);

                    if (segmentNoOrder.ContainsKey(segmentNo))
                        index = segmentNoOrder[segmentNo];

                    var fareBasis = fareBasisList.FirstOrDefault(t => t.Index == index);

                    foreach (var airSegment in airSegments) {
                        string departureCityCode = string.Empty;
                        string arrivalCityCode = string.Empty;

                        GetAmadeusSegmentParts(textLine, lineId, ref departureCityCode, ref arrivalCityCode);

                        airSegmentsClone.Add(new AirSegmentModel(customerId) {
                            RowIndex = textLine.RowIndex,
                            PassengerIndex = airSegment.PassengerIndex,
                            SegmentNo = segmentNo,
                            PassengerNo = airSegment.PassengerNo,
                            DepartureCityCode = departureCityCode,
                            ArrivalCityCode = arrivalCityCode,
                            BspEntryType = airSegment.BspEntryType,
                            TicketNo = textLine.IsVoid ? "VOID" : airSegment.TicketNo,
                            OriginalTicketNo = airSegment.OriginalTicketNo,
                            FareBasis = fareBasis?.FareBasis ?? string.Empty,
                            TicketDesignator = fareBasis?.TicketDesignator ?? string.Empty,
                            SeatNo = airSegment.SeatNo,
                            SeatStatus = airSegment.SeatStatus,
                            IsEmd = textLine.IsEmd,
                            AccompaniedInfant = airSegment.AccompaniedInfant
                        });
                    }
                }
            }

            return airSegmentsClone;
        }

        private static List<AirSegmentModel> GetAirSegments(AppLazyContext lazyContext, int customerId, List<TextLineModel> textLineList, List<AirSegmentModel> airSegments, ref bool excludePassengerSegmentPricing) {
            var airSegmentList = new List<AirSegmentModel>();
            var fareLineList = new List<FareLineModel>();

            foreach (var fvLine in textLineList.Where(t => t.Value.StartsWith("FV")).ToList()) {
                var passengerIndexes = new List<int>();

                foreach (string passengerNo in GetPassengerAssignments(fvLine.Value, 2)) {
                    foreach (int i in airSegments.Where(t => t.RowIndex == fvLine.RowIndex && t.PassengerNo == passengerNo).Select(t => t.PassengerIndex).Distinct()) {
                        if (passengerIndexes.Contains(i))
                            continue;

                        passengerIndexes.Add(i);
                    }
                }

                if (passengerIndexes.Count == 0)
                    continue;

                foreach (string segmentNo in GetAirSegmentAssignments(fvLine.Value, 1)) {
                    int skip = 0;

                    if (airSegments.Select(t => t.PassengerIndex).Distinct().Count() > 1)
                        skip = textLineList.Select(t => t.Value).Take(fvLine.RowIndex).ToList().FindLastIndex(t => t.StartsWith("I-"));

                    if (!textLineList.Skip(skip).Any(FareLineWhereClause()))
                        skip = 0;

                    TextLineModel fareLine;
                    bool ksLineExists = textLineList.Skip(skip).Any(t => t.Value.StartsWith("KS-") && t.Value != "KS-");

                    if (ksLineExists) {
                        fareLine = textLineList.Skip(skip).FirstOrDefault(FareLineKsWhereClause());
                    }
                    else {
                        fareLine = textLineList.Skip(skip).FirstOrDefault(FareLineKnWhereClause());
                    }

                    if (fareLine == null) {
                        if (ksLineExists) {
                            fareLine = textLineList.Skip(skip).FirstOrDefault(FareLineKsWhereClause());
                        }
                        else {
                            fareLine = textLineList.Skip(skip).FirstOrDefault(FareLineKnWhereClause());
                        }
                    }

                    if (fareLine == null || fareLineList.Any(t => t.RowIndex == fareLine.RowIndex && t.SegmentNo == segmentNo))
                        continue;

                    fareLineList.Add(new FareLineModel {
                        RowIndex = fareLine.RowIndex,
                        SegmentNo = segmentNo,
                        PassengerIndexes = passengerIndexes.Distinct().Select(t => new PassengerIndexModel { Index = t }).ToList()
                    });
                }
            }

            if (fareLineList.Count == 0) {
                foreach (var tsaLine in textLineList.Where(t => t.Value.StartsWith("TSA-")).ToList()) {
                    foreach (string segmentNo in GetAirSegmentAssignments(tsaLine.Value, 2)) {
                        var fareLine = textLineList.Skip(tsaLine.RowIndex).FirstOrDefault(FareLineWhereClause());

                        if (fareLine == null || fareLineList.Any(t => t.RowIndex == fareLine.RowIndex && t.SegmentNo == segmentNo))
                            continue;

                        int rowIndex = textLineList.Take(fareLine.RowIndex + 1).Last(t => t.Value.StartsWith("I-")).RowIndex;
                        int[] passengerIndexes = rowIndex < 0 ? airSegments.Select(t => t.PassengerIndex).Distinct().ToArray() : new int[] { rowIndex };

                        fareLineList.Add(new FareLineModel {
                            RowIndex = fareLine.RowIndex,
                            SegmentNo = segmentNo,
                            PassengerIndexes = passengerIndexes.Select(t => new PassengerIndexModel { Index = t }).ToList()
                        });
                    }
                }
            }

            foreach (var airSegment in airSegments.Where(t1 => !fareLineList.Any(t2 => t2.PassengerIndexes.Select(t3 => t3.Index).Contains(t1.PassengerIndex))).ToList()) {
                fareLineList.Add(new FareLineModel {
                    RowIndex = airSegment.RowIndex,
                    SegmentNo = airSegment.SegmentNo,
                    PassengerIndexes = excludePassengerSegmentPricing ? new List<PassengerIndexModel>() : new List<PassengerIndexModel> { new PassengerIndexModel { Index = airSegment.PassengerIndex, IsProcessed = excludePassengerSegmentPricing } }
                });
            }

            var atfLineList = new List<AtfLineModel>();

            if (textLineList.Any(t => t.Value.StartsWith("TSA-"))) {
                foreach (var textLine in textLineList.Where(t => t.Value.StartsWith("ATF-")).ToList()) {
                    var value = textLineList.Take(textLine.RowIndex).OrderByDescending(t => t.RowIndex).FirstOrDefault(t => t.Value.StartsWith("TSA-"))?.Value;

                    if (value == null && textLineList.Count(t => t.Value.StartsWith("ATF-")) == 1)
                        value = textLineList.First(t => t.Value.StartsWith("TSA-")).Value;

                    foreach (int segmentIndex in GetSegmentIndexAssignments(textLineList, value, 2)) {
                        if (atfLineList.Any(t => t.RowIndex == textLine.RowIndex && t.SegmentIndex == segmentIndex))
                            continue;

                        atfLineList.Add(new AtfLineModel {
                            RowIndex = textLine.RowIndex,
                            SegmentIndex = segmentIndex
                        });
                    }
                }
            }
            else {
                foreach (var segmentLine in textLineList.Where(t => t.AmadeusSegment.TripLineType == TripLineType.Air && !t.IsEmd).ToList()) {
                    foreach (var atfLine in textLineList.Where(t => t.Value.StartsWith("ATF-")).ToList()) {
                        atfLineList.Add(new AtfLineModel {
                            RowIndex = atfLine.RowIndex,
                            SegmentIndex = segmentLine.RowIndex
                        });
                    }
                }
            }

            bool qLineMethod = true;

            if (textLineList.Any(FareLineWhereClause()) || !textLineList.Any(t => t.Value.StartsWith("Q-") && t.Value.Contains('.'))) {
                qLineMethod = false;
                excludePassengerSegmentPricing = true;
            }

            string crsTaxCode = GetLocalTaxCode(customerId);
            var segmentIndexes = new List<SegmentIndexModel>();

            int partsIndex = 0;
            int passengerIndex = 0;

            string endLineId = textLineList.Any(t => t.Value.StartsWith("ATF-")) ? "ATF-" : "L-";

            foreach (var textLine in textLineList.Where(t => t.Value.StartsWith("I-") || (t.Value.StartsWith(endLineId) && t.Value != endLineId)).ToList()) {
                if (textLine.Value.StartsWith("I-"))
                    passengerIndex = textLine.RowIndex;

                int skip = (segmentIndexes.Count == 0 ? passengerIndex : segmentIndexes.Last().Skip + segmentIndexes.Last().Take) + 1;

                if (skip > textLineList.Count - textLineList.OrderByDescending(t => t.RowIndex).FindIndex(t => t.Value.StartsWith(endLineId))) {
                    if (passengerIndex > 500) {
                        skip = textLineList.IndexOf(textLine);
                    }
                    else {
                        skip = passengerIndex;
                    }
                }

                int take = textLineList.Skip(skip).FindIndex(t => (t.Value.StartsWith(endLineId) && t.Value != endLineId));

                if (take <= 0)
                    take = textLineList.Skip(skip).Count();

                segmentIndexes.Add(new SegmentIndexModel {
                    RowIndex = textLine.RowIndex,
                    PassengerIndex = passengerIndex,
                    Skip = skip,
                    Take = take
                });
            }

            var qLineList = new List<QLineModel>();

            foreach (var textLine in textLineList.Where(t => t.Value.StartsWith("Q-")).ToList()) {
                string[] textParts = textLine.Value.Split(';');

                if (textParts.Length > 1)
                    textParts = textParts[1].Split('/');

                if (textParts.Length <= 1)
                    continue;

                foreach (string segmentNo in GetAirSegmentAssignments(textParts[1], 0)) {
                    qLineList.Add(new QLineModel {
                        RowIndex = textLine.RowIndex,
                        SegmentNo = segmentNo
                    });
                }
            }

            bool takeAllLines = textLineList.Count(t => t.Value.StartsWith("I-")) == 1;

            foreach (var segment in airSegments.Where(t => !t.IsEmd).OrderBy(t => t.PassengerIndex).ThenBy(t => t.RowIndex).ToList()) {
                passengerIndex = segment.PassengerIndex;

                int skip = segment.PassengerIndex + 1;
                int take = takeAllLines ? textLineList.Count : textLineList.Skip(skip).FindIndex(t => t.Value.StartsWith("I-"));

                if (take <= 0)
                    take = textLineList.Count;

                var segmentIndex = segmentIndexes.FirstOrDefault(t => t.RowIndex == segment.RowIndex && t.PassengerIndex == passengerIndex && !t.IsProcessed);

                if (segmentIndex != null) {
                    if (!takeAllLines) {
                        skip = segmentIndex.Skip;
                        take = segmentIndex.Take;
                    }

                    segmentIndex.IsProcessed = true;

                    if (segmentIndexes.All(t => t.IsProcessed))
                        segmentIndexes.ForEach(t => t.IsProcessed = false);
                }

                var textLines = textLineList.Skip(skip).Take(take).Where(t => (t.Value.StartsWith("K-") && t.Value != "K-") || t.Value.StartsWith("KFT") || t.Value.StartsWith("KNT") || t.Value.StartsWith("KST") || t.Value.StartsWith("ATF-") || (t.Value.StartsWith("L-") && t.Value != "L-") || t.IsEmd).ToList();

                if (textLines.Count == 0)
                    textLines = textLineList.Where(t => (t.Value.StartsWith("K-") && t.Value != "K-") || t.Value.StartsWith("KFT") || t.Value.StartsWith("KNT") || t.Value.StartsWith("KST") || t.Value.StartsWith("ATF-") || (t.Value.StartsWith("L-") && t.Value != "L-") || t.IsEmd).ToList();

                int currencyId = -1;

                decimal amount = 0;
                decimal tax = 0;
                decimal baseFare = 0;
                decimal equivalentAmount = 0;
                decimal ticketedFare = 0;
                decimal nonCommissionable = 0;
                decimal exchangeRate = 0;

                string currencyCode = string.Empty;
                string lineId = string.Empty;

                GetTaxParts(lazyContext, textLines, crsTaxCode, ref currencyId, ref currencyCode, ref nonCommissionable, ref tax);
                TextLineModel fareLine;

                if (segment.TicketNo == "VOID") {
                    segment.IsProcessed = true;
                    airSegmentList.AddAirSegment(segment, customerId, -1, string.Empty, 0, 0, 0, 0, 0);
                    continue;
                }
                else if (qLineMethod) {
                    if (!qLineList.Any(t => t.SegmentNo == segment.SegmentNo))
                        continue;

                    fareLine = textLineList.FirstOrDefault(t1 => t1.Value.StartsWith("Q-") && qLineList.Any(t2 => t2.RowIndex == t1.RowIndex && !t2.IsProcessed));

                    if (fareLine != null) {
                        segment.IsProcessed = true;
                        qLineList.First(t => t.RowIndex == fareLine.RowIndex && !t.IsProcessed).IsProcessed = true;

                        if (qLineList.All(t => t.IsProcessed))
                            qLineList.ForEach(t => t.IsProcessed = false);
                    }
                }
                else {
                    if (!fareLineList.Any(t => t.SegmentNo == segment.SegmentNo))
                        continue;

                    fareLine = textLineList.FirstOrDefault(t1 => fareLineList.Any(t2 => t2.RowIndex == t1.RowIndex && t2.PassengerIndexes.Any(t3 => t3.Index == passengerIndex) && !t2.IsProcessed));

                    if (fareLine != null) {
                        segment.IsProcessed = true;
                        fareLineList.SelectMany(t => t.PassengerIndexes).ToList().First(t => t.Index == passengerIndex && !t.IsProcessed).IsProcessed = true;

                        if (fareLineList.All(t => t.IsProcessed))
                            fareLineList.SelectMany(t => t.PassengerIndexes).ToList().ForEach(t => t.IsProcessed = false);
                    }
                }

                if (fareLine == null) {
                    baseFare = 0;
                    equivalentAmount = 0;
                    amount = 0;
                    ticketedFare = 0;
                    nonCommissionable = 0;
                    tax = 0;
                }
                else {
                    string fareLineId = fareLine.Value.Left(2);
                    string[] fareParts = fareLine.Value.TrimStart(fareLineId).Split(';');

                    if (fareLineId == "Q-" && qLineMethod) {
                        string[] segmentFare = fareParts[0].Split(' ');

                        if (segmentFare.Length > 2)
                            decimal.TryParse(new(segmentFare[2].Where(t => char.IsDigit(t) || t == '.').ToArray()), out amount);

                        if (segmentFare.Length > 3 && segmentFare[3].Contains("NUC", StringComparison.CurrentCulture))
                            decimal.TryParse(new(segmentFare[3].Substring(0, segmentFare[3].IndexOf("NUC")).Where(t => char.IsDigit(t) || t == '.').ToArray()), out ticketedFare);

                        if (segmentFare.Length > 4 && segmentFare[4].StartsWith("ROE"))
                            decimal.TryParse(new(segmentFare[4].Trim().Where(t => char.IsDigit(t) || t == '.').ToArray()), out exchangeRate);

                        if (exchangeRate != 0) {
                            ticketedFare = Math.Round(ticketedFare / exchangeRate, 2);
                            amount = Math.Round(amount / exchangeRate, 2);
                        }
                    }
                    else if ((fareLineId == "K-" || fareLineId == "KN" || fareLineId == "KS") && !qLineMethod) {
                        if (fareParts[0].Trim().Length > 4) {
                            decimal.TryParse(new(fareParts[0].Trim().Where(t => char.IsDigit(t) || t == '.').ToArray()), out decimal result);
                            baseFare += result;

                            if (currencyId <= 0) {
                                currencyCode = fareParts[0].TrimStart(fareLineId).Substring(1, 3);
                                currencyId = Currency.GetCurrency(lazyContext, currencyCode).Id;
                            }
                        }

                        if (fareParts.Length > 1 && fareParts[1].Trim().Length > 4) {
                            decimal.TryParse(new(fareParts[1].Trim().Where(t => char.IsDigit(t) || t == '.').ToArray()), out decimal result);
                            equivalentAmount += result;
                        }

                        if (fareParts.Length > 12 && fareParts[12].Trim().Length > 4) {
                            decimal.TryParse(new(fareParts[12].Trim().Where(t => char.IsDigit(t) || t == '.').ToArray()), out decimal result);
                            amount += result;
                        }
                    }

                    amount += GetAtfAmount(textLineList, atfLineList, segment.RowIndex);

                    if (!qLineMethod) {
                        if (equivalentAmount == 0) {
                            if (amount > baseFare)
                                nonCommissionable = amount - baseFare;
                        }
                        else {
                            nonCommissionable = amount - equivalentAmount;
                        }

                        amount -= nonCommissionable;
                        ticketedFare = amount;
                        exchangeRate = GetExchangeRate(lazyContext, customerId, new AmadeusSegmentModel { SegmentType = AmadeusSegmentType.None, TripLineType = TripLineType.Air }, currencyCode, baseFare, equivalentAmount);
                    }
                }

                airSegmentList.AddAirSegment(segment, customerId, currencyId, currencyCode, exchangeRate, ticketedFare, amount, tax, nonCommissionable);
            }

            segmentIndexes.ForEach(t => t.IsProcessed = false);

            foreach (var segment in airSegments.Where(t => t.IsEmd)) {
                passengerIndex = segment.PassengerIndex;

                int skip = segment.PassengerIndex + 1;
                int take = takeAllLines ? textLineList.Count : textLineList.Skip(skip).FindIndex(t => t.Value.StartsWith("I-"));

                if (take <= 0)
                    take = textLineList.Count;

                var segmentIndex = segmentIndexes.FirstOrDefault(t => t.RowIndex == segment.RowIndex && t.PassengerIndex == passengerIndex && !t.IsProcessed);

                if (segmentIndex != null) {
                    if (!takeAllLines) {
                        skip = segmentIndex.Skip;
                        take = segmentIndex.Take;
                    }

                    segmentIndex.IsProcessed = true;

                    if (segmentIndexes.All(t => t.IsProcessed))
                        segmentIndexes.ForEach(t => t.IsProcessed = false);
                }

                var textLines = textLineList.Skip(skip).Take(take).Where(t => t.IsEmd).ToList();

                if (textLines.Count == 0)
                    textLines = textLineList.Where(t => t.IsEmd).ToList();

                var textLine = textLineList.Single(t => t.RowIndex == segment.RowIndex);
                string[] textParts = textLine.Value.Split(';');

                partsIndex = partsIndex = textParts.Length - 6;

                if (textParts[partsIndex].Trim().Length == 0)
                    partsIndex++;

                string currencyCode = textParts[partsIndex].Left(3);
                int currencyId = Currency.GetCurrency(lazyContext, currencyCode).Id;

                decimal ticketedFare = decimal.Parse(textParts[partsIndex].Substring(3).Trim());
                decimal tax = 0;
                decimal nonCommissionable = 0;
                decimal exchangeRate = GetExchangeRate(lazyContext, customerId, new AmadeusSegmentModel { SegmentType = AmadeusSegmentType.Emd, TripLineType = TripLineType.Air }, currencyCode, ticketedFare, ticketedFare);

                GetTaxParts(lazyContext, textLines, crsTaxCode, ref currencyId, ref currencyCode, ref nonCommissionable, ref tax);
                airSegmentList.AddAirSegment(segment, customerId, currencyId, currencyCode, exchangeRate, ticketedFare, 0, 0, 0);
            }

            partsIndex = 0;
            passengerIndex = 0;

            foreach (var airSegment in airSegmentList.OrderBy(t => t.PassengerIndex).ToList()) {
                if (passengerIndex != airSegment.PassengerIndex) {
                    passengerIndex = airSegment.PassengerIndex;
                    partsIndex = 0;
                }

                partsIndex++;

                string ticketNo = string.Empty;
                string seatNo = string.Empty;
                var seatStatus = SeatStatus.NotSpecified;

                var textLine = textLineList.Skip(passengerIndex).FirstOrDefault(t => t.Value.StartsWith("S-"));

                if (textLine != null) {
                    GetPassengerInfo(textLine, airSegment.PassengerNo, ref partsIndex, ref ticketNo, ref seatNo, ref seatStatus);
                    airSegment.SeatNo = seatNo;
                    airSegment.SeatStatus = seatStatus;
                }

                textLine = textLineList.Skip(passengerIndex).FirstOrDefault(t => t.Value.StartsWith("T-"));

                if (textLine != null) {
                    GetPassengerInfo(textLine, airSegment.PassengerNo, ref partsIndex, ref ticketNo, ref seatNo, ref seatStatus);
                    airSegment.TicketNo = ticketNo;
                }

                textLine = textLineList.Skip(passengerIndex).FirstOrDefault(t => t.Value.StartsWith("FO"));

                if (textLine != null) {
                    string[] textParts = textLine.Value.Split(';');

                    if (textParts.Length > 2) {
                        string[] segmentNos = GetAirSegmentAssignments(textParts[textParts.Length - 2], 0);
                        string[] passengerNos = GetPassengerAssignments(textParts[textParts.Length - 1], 0);

                        if (segmentNos.Contains(airSegment.SegmentNo) && passengerNos.Contains(airSegment.PassengerNo)) {
                            airSegment.OriginalTicketNo = textLine.Value.Split('-')[1].Split('/')[0].Left(10);
                            airSegment.BspEntryType = BspEntryType.Exchange;
                        }
                    }
                }

                textLine = textLineList.Skip(passengerIndex).FirstOrDefault(t => t.Value.StartsWith("K-R") || t.Value.StartsWith("KFTR") || t.Value.StartsWith("KNTR") || t.Value.StartsWith("KSTR"));

                if (textLine != null)
                    airSegment.BspEntryType = BspEntryType.Exchange;
            }

            foreach (var fareLineSegment in fareLineList.Where(t => !t.IsProcessed).ToList()) {
                foreach (var airSegment in airSegmentList.Where(t1 => t1.RowIndex == fareLineSegment.RowIndex && fareLineSegment.PassengerIndexes.All(t2 => t2.Index == passengerIndex && !t2.IsProcessed) && !t1.IsEmd && !t1.IsProcessed).ToList()) {
                    airSegmentList.Remove(airSegment);
                }
            }

            return airSegmentList.OrderBy(t => t.SegmentNo).ThenBy(t => t.PassengerNo).ThenBy(t => t.IsEmd ? 1 : 0).ToList();
        }

        private static void AddAirSegment(this List<AirSegmentModel> airSegments, AirSegmentModel airSegment, int customerId, int currencyId, string currencyCode, decimal exchangeRate, decimal ticketedFare, decimal amount, decimal tax, decimal nonCommissionable) {
            airSegments.Add(new AirSegmentModel(customerId) {
                RowIndex = airSegment.RowIndex,
                PassengerIndex = airSegment.PassengerIndex,
                SegmentNo = airSegment.SegmentNo,
                PassengerNo = airSegment.PassengerNo ?? string.Empty,
                DepartureCityCode = airSegment.DepartureCityCode,
                ArrivalCityCode = airSegment.ArrivalCityCode,
                BspEntryType = airSegment.BspEntryType,
                TicketNo = airSegment.TicketNo ?? string.Empty,
                OriginalTicketNo = airSegment.OriginalTicketNo ?? string.Empty,
                FareBasis = airSegment.FareBasis ?? string.Empty,
                TicketDesignator = airSegment.TicketDesignator ?? string.Empty,
                SeatNo = airSegment.SeatNo ?? string.Empty,
                SeatStatus = airSegment.SeatStatus,
                CurrencyId = currencyId,
                CurrencyCode = currencyCode,
                ExchangeRate = exchangeRate,
                TicketedFare = ticketedFare,
                Amount = amount,
                Tax = tax,
                NonCommissionable = nonCommissionable,
                IsEmd = airSegment.IsEmd,
                AccompaniedInfant = airSegment.AccompaniedInfant
            });
        }

        private static void AddAddress(CrsModel crsModel, TextLineModel textLine, string lineId) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            foreach (string namePart in textLine.Value.TrimStart(lineId).Trim().Split('/')) {
                string id = namePart.Left(3);
                string value = textInfo.ToTitleCase(namePart.Substring(3).ToLower());

                switch (id) {
                    case "A1-":
                        crsModel.ClientDetail.Address1 = value;
                        break;
                    case "A2-":
                        crsModel.ClientDetail.Address2 = value;
                        break;
                    case "CI-":
                        crsModel.ClientDetail.Locality = value;
                        break;
                    case "ZP-":
                        crsModel.ClientDetail.PostCode = value;
                        break;
                }
            }
        }

        private static void AddPassenger(AppLazyContext lazyContext, CrsModel crsModel, TextLineModel textLine, string lineId, Dictionary<string, DateTime> infantBirthDates, bool isSummary) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;
            string[] nameParts = textLine.Value.TrimStart(lineId).Split(';');

            string passengerNo = nameParts[1].Left(2);

            if (int.Parse(passengerNo) > 50)
                return;

            string passengerName = nameParts[1].Substring(2);

            string phoneNo = string.Empty;
            string phoneHome = string.Empty;
            string phoneWork = string.Empty;
            string mobile = string.Empty;
            string email = string.Empty;
            string value = string.Empty;

            if (!isSummary) {
                bool isLeadPassenger = crsModel.PassengerList.Count == 0;

                foreach (string namePart in nameParts[3].Split(new string[] { "//" }, StringSplitOptions.None)) {
                    string phoneEmail = namePart.TrimStart("N-").TrimStart("VA/").TrimStart("E+").TrimStart("E-").TrimStart("APE-").TrimStart("APE ").TrimEnd("/EN");

                    if (DataValidation.IsEmail(phoneEmail)) {
                        email = phoneEmail.TrimStart("S ").ToLower();
                    }
                    else if (phoneEmail.StartsWith("-") || phoneEmail.StartsWith("B ") || phoneEmail.EndsWith("-B")) {
                        value = new string(phoneEmail.TrimStart("-").TrimStart("B ").TrimEnd("-B").Replace("-", " ").Where(t => char.IsNumber(t) || char.IsWhiteSpace(t)).ToArray()).Trim();

                        if (DataValidation.IsPhone(value))
                            phoneWork = value;
                    }
                    else if (phoneEmail.StartsWith("H ") || phoneEmail.StartsWith("H-") || phoneEmail.EndsWith("-H")) {
                        value = new string(phoneEmail.TrimStart("H ").TrimStart("H-").TrimEnd("-H").Replace("-", " ").Where(t => char.IsNumber(t) || char.IsWhiteSpace(t)).ToArray()).Trim();

                        if (DataValidation.IsPhone(value))
                            phoneHome = value;
                    }
                    else if (phoneEmail.StartsWith("M ") || phoneEmail.StartsWith("M-") || phoneEmail.StartsWith("S-") || phoneEmail.StartsWith("N-SQ/M+") || phoneEmail.EndsWith("-M")) {
                        value = new string(phoneEmail.TrimStart("M ").TrimStart("M-").TrimStart("S-").TrimStart("N-SQ/M+").TrimEnd("-M").Replace("-", " ").Where(t => char.IsNumber(t) || char.IsWhiteSpace(t)).ToArray()).Trim();

                        if (DataValidation.IsPhone(value))
                            mobile = value;
                    }
                    else if (phoneEmail.StartsWith("S ") || phoneEmail.EndsWith("-S") || phoneEmail.StartsWith("APS ")) {
                        value = new string(phoneEmail.TrimStart("S ").TrimEnd("-S").TrimStart("APS ").Replace("-", " ").Where(t => char.IsNumber(t) || char.IsWhiteSpace(t)).ToArray()).Trim();

                        if (DataValidation.IsPhone(value))
                            phoneNo = value;
                    }
                    else if (phoneEmail.Contains("-M-")) {
                        value = phoneEmail.TrimStart("S-").Substring(0, phoneEmail.IndexOf("-M-") - 2);

                        if (DataValidation.IsPhone(value))
                            mobile = value;
                    }

                    if (isLeadPassenger && mobile.Length == 0 && phoneEmail.StartsWith("APM ")) {
                        value = new string(phoneEmail.TrimStart("APM ").Replace("-", " ").Where(t => char.IsNumber(t) || char.IsWhiteSpace(t)).ToArray()).Trim();

                        if (DataValidation.IsPhone(value))
                            mobile = value;
                    }

                    if (phoneNo.Length == 0)
                        phoneNo = phoneWork.Length > 0 ? phoneWork : mobile.Length > 0 ? mobile : phoneHome;
                }
            }

            string lastName = passengerName.Split('/')[0];
            string firstName = passengerName.Split('/')[1].Split('(')[0];
            string title = string.Empty;

            if (passengerName.Contains("(INF/")) {
                string birthDate = passengerName.Split("(INF/", StringSplitOptions.None)[1].TrimEnd(')').Right(7);
                DateTime.TryParse(string.Concat(birthDate.Left(2), "-", birthDate.Substring(2, 3), "-", birthDate.Right(2)), out DateTime infantBirthDate);

                if (infantBirthDate > DateTime.MinValue)
                    infantBirthDates.Add(passengerNo, infantBirthDate);
            }

            string[] firstNameParts = firstName.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
            string[] passengerTypeParts = passengerName.Split('(');

            bool accompaniedInfant = passengerName.EndsWith("(INF)");

            var gender = Gender.NotSpecified;
            var passengerType = PassengerType.NotSpecified;
            int index = firstNameParts.Length - 1;

            if (index >= 0) {
                firstName = firstNameParts[index];

                if (index == 0) {
                    var contactTitle = lazyContext.ContactTitle.AsEnumerable().FirstOrDefault(t => t.Id > 0 && ((firstName.Length > t.Name.Length && firstName.ToLower().Substring(firstName.Length - t.Name.Length) == t.Name.ToLower())
                        || (t.CrsCode.Length > 0 && firstName.Length > t.CrsCode.Length && firstName.ToLower().Substring(firstName.Length - t.CrsCode.Length) == t.CrsCode.ToLower())));

                    if (contactTitle != null) {
                        title = contactTitle.Name;
                        gender = contactTitle.Gender;

                        if (firstName.Length > title.Length) {
                            firstName = firstName.Left(firstName.Length - title.Length);
                        }
                        else {
                            firstName = string.Empty;
                        }
                    }
                }
                else {
                    var contactTitle = ContactTitle.GetContactTitle(lazyContext, firstName);
                    title = contactTitle.Name;
                    gender = contactTitle.Gender;
                    firstName = string.Join(" ", firstNameParts.Take(index));
                }
            }

            if (passengerTypeParts.Length > 1)
                passengerType = Biz.Dao.ClientLedger.Passenger.GetPassengerType(passengerTypeParts[1].Left(4).TrimEnd(')'));

            crsModel.PassengerList.Add(new Passenger {
                PassengerNo = passengerNo,
                CrsKey = GetCrsPassengerKey(passengerNo, accompaniedInfant, crsModel.CrsPnrRef),
                PassengerType = passengerType,
                Title = title,
                FirstName = textInfo.ToTitleCase(firstName.ToLower()),
                LastName = textInfo.ToTitleCase(lastName.ToLower()),
                PhoneNo = phoneNo,
                PhoneHome = phoneHome,
                PhoneWork = phoneWork,
                Mobile = mobile,
                Email = email,
                BirthDate = accompaniedInfant && infantBirthDates.ContainsKey(passengerNo) ? infantBirthDates[passengerNo] : DateTime.MinValue,
                Gender = gender,
                AccompaniedInfant = accompaniedInfant
            });
        }

        private static void GetPassengerInfo(TextLineModel textLine, string passengerNo, ref int partsIndex, ref string ticketNo, ref string seatNo, ref SeatStatus seatStatus) {
            if (!textLine.Value.StartsWith("S-") && !textLine.Value.StartsWith("T-"))
                return;

            string[] textParts;

            ticketNo = string.Empty;
            seatNo = string.Empty;

            if (textLine.Value.StartsWith("S-")) {
                textParts = textLine.Value.Split('/');

                if (textParts[0].Substring(2, 2) != passengerNo)
                    return;

                if (textParts.Length > partsIndex) {
                    if (textParts[partsIndex].Split('.')[0].Length > 1)
                        seatNo = textParts[partsIndex].Split('.')[0].Substring(1);

                    if (seatNo.Length == 0)
                        return;

                    if (textParts[partsIndex].Left(1) == "P") {
                        seatStatus = SeatStatus.OnRequest;
                    }
                    else {
                        seatStatus = SeatStatus.Confirmed;
                    }
                }
            }
            else if (textLine.Value.StartsWith("T-")) {
                textParts = textLine.Value.Split('-');

                if (textParts.Length > 2)
                    ticketNo = textParts[2];
            }
        }

        private static decimal GetAtfAmount(List<TextLineModel> textLineList, List<AtfLineModel> atfLineList, decimal segmentIndex) {
            if (atfLineList.Count == 0)
                return 0;

            var atfLine = atfLineList.FirstOrDefault(t => t.SegmentIndex == segmentIndex && !t.IsProcessed);

            if (atfLine == null)
                return 0;

            atfLine.IsProcessed = true;

            var textLine = textLineList.Single(t => t.RowIndex == atfLine.RowIndex);
            var fareParts = textLine.Value.TrimStart("ATF-").Split(';', StringSplitOptions.RemoveEmptyEntries);

            if (fareParts.Length > 0) {
                decimal.TryParse(new(fareParts[0].Where(t => char.IsDigit(t) || t == '.').ToArray()), out decimal result);
                return result;
            }

            return 0;
        }

        private static decimal GetValidatedLocalTax(decimal amount, decimal localTax, decimal taxRate) {
            decimal tax = Math.Round(amount * taxRate, 2);

            if (localTax >= tax + 0.02m || localTax <= tax - 0.02m)
                localTax = tax;

            return localTax;
        }

        private static string GetSsr(AppLazyContext lazyContext, CrsModel crsModel, TextLineModel textLine, DateTime airCreationDate, ref string[] ssrAirSegmentNos, ref string[] ssrPassengerNos, ref string inclusions, List<PassengerDocument> passengerDocumentList) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            ssrAirSegmentNos = Array.Empty<string>();
            ssrPassengerNos = Array.Empty<string>();

            SpecialRequest specialRequest = null;
            string ssr = string.Empty;

            int index = textLine.Value.IndexOf("/");

            string[] textParts = new string[] {
                textLine.Value.Left(index),
                textLine.Value.Replace("//", "@").Replace("..", "_").Substring(index + 1)
            };

            string ssrCode = textParts[0].Split(' ')[1];
            var ssrParts = textParts[1].Split(';');

            if (ssrParts.Length > 1) {
                if (ssrParts.Length > 2)
                    ssrAirSegmentNos = GetAirSegmentAssignments(ssrParts[ssrParts.Length - 2], 0);

                ssrPassengerNos = GetPassengerAssignments(ssrParts[ssrParts.Length - 1], 0);
            }

            switch (ssrCode) {
                default:
                    specialRequest = lazyContext.SpecialRequest.SingleOrDefault(t => t.Code.ToLower() == ssrCode.ToLower() && t.SpecialRequestType == SpecialRequestType.SSR && t.ImportFromCrs);

                    if (specialRequest == null)
                        return string.Empty;

                    ssr = specialRequest.Description;
                    string[] statusParts = textParts[0].Split(' ');

                    if (statusParts.Length > 4) {
                        string statusCode = statusParts[4].Left(2);
                        var status = Biz.Dao.ClientLedger.Trip.GetTripStatus(statusCode);

                        if (status != TripStatus.NotSpecified)
                            ssr += string.Format(" ({0})", status.GetEnumDescription());
                    }

                    ssr = ssr.Trim();
                    string freeText = textParts[1].Split(';')[0];

                    if (DataValidation.IsEmail(freeText.Split('/')[0]))
                        freeText = freeText.ToLower();

                    inclusions = string.Format("{0}. {1}.", ssr, freeText).TrimEnd(" .");
                    break;
                case "DOCS":
                    if (ssrPassengerNos.Length == 0)
                        return string.Empty;

                    var ssrValues = textLine.Value.Split(';')[0].Split('/');

                    string firstName = textInfo.ToTitleCase((ssrValues.Length >= 11 ? string.Format("{0} {1}", ssrValues[9], ssrValues[10]) : ssrValues[9]).ToLower());
                    string lastName = textInfo.ToTitleCase(ssrValues[8].ToLower());

                    var documentType = ssrValues[1] == "P" ? DocumentType.Passport : DocumentType.Visa;
                    string documentNo = ssrValues[3];
                    var gender = ssrValues[6] == "M" ? Gender.Male : ssrValues[6] == "F" ? Gender.Female : Gender.NotSpecified;

                    var issuingCountry = Country.GetCountry(lazyContext, ssrValues[2], true);

                    if (issuingCountry.Id == -1)
                        issuingCountry = Country.GetCountry(lazyContext, ssrValues[2]);

                    var nationality = Country.GetCountry(lazyContext, ssrValues[4], true);

                    if (nationality.Id == -1)
                        nationality = Country.GetCountry(lazyContext, ssrValues[4]);

                    DateTime.TryParse(ssrValues[5], out DateTime birthDate);
                    DateTime.TryParse(ssrValues[7], out DateTime expiryDate);

                    if (birthDate > DateTime.Today)
                        birthDate = birthDate.AddYears(-100);

                    int age = 0;
                    var passengerType = PassengerType.NotSpecified;

                    if (birthDate > DateTime.MinValue) {
                        age = Biz.Dao.ClientLedger.Passenger.GetAge(birthDate, airCreationDate);
                        passengerType = Biz.Dao.ClientLedger.Passenger.GetPassengerType(birthDate, airCreationDate);
                    }

                    string crsPassengerNo = ssrPassengerNos[0];
                    var crsPassenger = crsModel.PassengerList.SingleOrDefault(t => t.PassengerNo == crsPassengerNo && !t.AccompaniedInfant);

                    if (crsPassenger != null) {
                        if (passengerType != PassengerType.NotSpecified && crsPassenger.PassengerType == PassengerType.NotSpecified)
                            crsPassenger.PassengerType = passengerType;

                        if (birthDate > DateTime.MinValue && crsPassenger.BirthDate == DateTime.MinValue)
                            crsPassenger.BirthDate = birthDate;

                        if (age > 0 && crsPassenger.Age == 0)
                            crsPassenger.Age = age;

                        if (gender != Gender.NotSpecified && crsPassenger.Gender == Gender.NotSpecified)
                            crsPassenger.Gender = gender;

                        passengerDocumentList.Add(new PassengerDocument {
                            CrsPassengerKey = GetCrsPassengerKey(crsPassenger.PassengerNo, crsPassenger.AccompaniedInfant, crsModel.CrsPnrRef),
                            DocumentType = documentType,
                            DocumentNo = documentNo,
                            IssuingCountryId = issuingCountry.Id,
                            NationalityId = nationality.Id,
                            ExpiryDate = expiryDate,
                            IssueDate = expiryDate > DateTime.MinValue && issuingCountry.Code == "AU" ? expiryDate.AddYears(-10) : DateTime.MinValue
                        });
                    }

                    break;
            }

            if (string.IsNullOrEmpty(inclusions))
                inclusions = ssr;

            return ssr;
        }

        private static string GetInclusions(int customerId, TextLineModel textLine, string localCurrencyCode = null, string foreignCurrencyCode = null, decimal localAmount = 0, decimal foreignAmount = 0, decimal rateAmount = 0, int duration = 0, bool summaryOnly = false) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            string[] textParts;
            string inclusions = string.Empty;

            var amadeusSegment = textLine.AmadeusSegment;

            switch (amadeusSegment.SegmentType) {
                case AmadeusSegmentType.AutomatedCruiseSegment:
                case AmadeusSegmentType.AutomatedTourSegment:
                    return string.Empty;
                case AmadeusSegmentType.AutomatedHotelSegment:
                    if (!string.IsNullOrEmpty(foreignCurrencyCode) && !string.IsNullOrEmpty(localCurrencyCode) && rateAmount != 0 && duration != 0) {
                        string total = string.Empty;

                        if (localAmount > 0) {
                            if (foreignCurrencyCode == localCurrencyCode) {
                                total = string.Format(".{0}Total: {1}{2:f2}", AppConstants.HtmlLineBreak, localCurrencyCode, localAmount);
                            }
                            else {
                                total = string.Format(".{0}Total: {1}{2:f2} converted to {3}{4:f2}", AppConstants.HtmlLineBreak, foreignCurrencyCode, foreignAmount, localCurrencyCode, localAmount);
                            }
                        }

                        inclusions += string.Format("Rate: {1}{2:f2} per night for {3} {4}{5}.{0}{0}", AppConstants.HtmlLineBreak, foreignCurrencyCode, Math.Round(rateAmount, 2), duration, duration == 1 ? "night" : "nights", total);
                    }

                    if (summaryOnly)
                        break;

                    textParts = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None)[1].Split(';');

                    foreach (string part in textParts.Where(t => t.StartsWith("CXL-") || t.StartsWith("MEA-") || t.StartsWith("SF-") || t.StartsWith("SI-") || t.StartsWith("STA-") || t.StartsWith("VV-")).ToArray()) {
                        string item = part.Substring(part.IndexOf("-") + 1).Replace("/", string.Empty);

                        if (item.Length == 0 || item == "NOT INCLUDED")
                            continue;

                        if (part.StartsWith("CXL-"))
                            item = string.Format("{0} {1}", item, textParts[textParts.IndexOf(part) + 1]).Replace("/", string.Empty);

                        inclusions += string.Format("{1}.{0}", AppConstants.HtmlLineBreak, textInfo.ToTitleCase(item.Trim().TrimEnd(".").ToLower()));
                    }

                    break;
                case AmadeusSegmentType.AutomatedCarSegment:
                    bool isLocalCurrency = foreignCurrencyCode == AppSettings.Setting(customerId).CurrencyCode;

                    string[] elements = textLine.Value.Split(';');
                    string rateInfo = string.Empty;

                    int index = elements.FindIndex(t => t.StartsWith("RG-") && t != "RG-");

                    if (index < 0)
                        index = elements.FindIndex(t => t.StartsWith("RQ-") && t != "RQ-");

                    if (index >= 0) {
                        string[] pricingParts = elements[index].Split(' ');

                        if (pricingParts.Any(t => t == "DY") || pricingParts[0].EndsWith("DY")) {
                            rateInfo += " per day";
                        }
                        else if (pricingParts.Any(t => t == "WY") || pricingParts[0].EndsWith("WY")) {
                            rateInfo += " per week";
                        }

                        if (pricingParts.Any(t => t == "UNL" || t == "UNL KM"))
                            rateInfo += "| unlimited km";

                        index = pricingParts.FindIndex(t => t == "XH" || t == "XD");

                        if (index >= 0) {
                            decimal.TryParse(pricingParts[index - 2].TrimEnd('-'), out decimal rate);

                            if (rate > 0)
                                rateInfo += isLocalCurrency ? string.Format("| {0:c2} per extra {1}", rate, pricingParts[index] == "XH" ? "hour" : "day") : string.Format("| {0}{1:f2} per extra {2}", foreignCurrencyCode, rate, pricingParts[index] == "XH" ? "hour" : "day");
                        }
                    }

                    if (!string.IsNullOrEmpty(foreignCurrencyCode) && foreignAmount != 0 && rateAmount != 0) {
                        inclusions += string.Format("Rate: {1}{2}| Total: {3}.{0}",
                            AppConstants.HtmlLineBreak,
                            isLocalCurrency ? string.Format("{0:c2}", rateAmount) : string.Format("{0}{1:f2}", foreignCurrencyCode, rateAmount),
                            rateInfo,
                            isLocalCurrency ? string.Format("{0:c2}", foreignAmount) : string.Format("{0}{1:f2}", foreignCurrencyCode, foreignAmount));
                    }

                    if (elements.Length > 7)
                        inclusions += string.Format("Car Code: {1}| {2}.{0}", AppConstants.HtmlLineBreak, elements[6].Trim(), elements[7].Trim().TrimEnd(".").Replace("NO-", "(NO AIRCON)"));

                    inclusions = inclusions.TrimEnd(AppConstants.HtmlLineBreak);
                    break;
                case AmadeusSegmentType.ManualHotelSegment:
                    textParts = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None);
                    inclusions += textParts[8].TrimEnd(".");
                    break;
                case AmadeusSegmentType.ManualCarSegment:
                    textParts = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None);
                    inclusions += textParts[6].TrimEnd(".");
                    break;
                case AmadeusSegmentType.GroundTransportationSegment:
                    textParts = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None);
                    inclusions = textParts[10].TrimEnd(".");
                    break;
                case AmadeusSegmentType.ManualTourSegment:
                case AmadeusSegmentType.AirTaxiSegment:
                case AmadeusSegmentType.MiscellaneousSegment:
                    textParts = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None);
                    inclusions += textParts[5].TrimEnd(".");
                    break;
            }

            if (inclusions.Length > 0) {
                while (inclusions.StartsWith(AppConstants.HtmlLineBreak)) {
                    inclusions = inclusions.TrimStart(AppConstants.HtmlLineBreak);
                }

                while (inclusions.EndsWith(AppConstants.HtmlLineBreak)) {
                    inclusions = inclusions.TrimEnd(AppConstants.HtmlLineBreak);
                }

                inclusions = string.Format("{0}.", inclusions.Replace(";", AppConstants.HtmlLineBreak).Replace(string.Format("{0}{0}{0}", AppConstants.HtmlLineBreak), string.Format("{0}{0}", AppConstants.HtmlLineBreak)).Replace("|", ";").TrimEnd("."));
            }

            return inclusions.Replace("Am ", "am ").Replace("Pm ", "pm ");
        }

        private static string GetComments(int customerId, TextLineModel textLine, string localCurrencyCode = null, string foreignCurrencyCode = null, decimal localAmount = 0, decimal foreignAmount = 0, decimal rateAmount = 0, int duration = 0) {
            string[] textParts;
            string comments = string.Empty;

            var amadeusSegment = textLine.AmadeusSegment;

            switch (amadeusSegment.SegmentType) {
                case AmadeusSegmentType.AutomatedCruiseSegment:
                case AmadeusSegmentType.AutomatedTourSegment:
                    return string.Empty;
                case AmadeusSegmentType.AutomatedHotelSegment:
                    if (!string.IsNullOrEmpty(foreignCurrencyCode) && !string.IsNullOrEmpty(localCurrencyCode) && rateAmount != 0 && duration != 0) {
                        string total = string.Empty;

                        if (localAmount > 0) {
                            if (foreignCurrencyCode == localCurrencyCode) {
                                total = string.Format(".{0}Total: {1}{2:f2}", Environment.NewLine, localCurrencyCode, localAmount);
                            }
                            else {
                                total = string.Format(".{0}Total: {1}{2:f2} converted to {3}{4:f2}", Environment.NewLine, foreignCurrencyCode, foreignAmount, localCurrencyCode, localAmount);
                            }
                        }

                        comments += string.Format("Rate: {1}{2:f2} per night for {3} {4}{5}.{0}{0}", Environment.NewLine, foreignCurrencyCode, Math.Round(rateAmount, 2), duration, duration == 1 ? "night" : "nights", total);
                    }

                    break;
                case AmadeusSegmentType.AutomatedCarSegment:
                    bool isLocalCurrency = foreignCurrencyCode == AppSettings.Setting(customerId).CurrencyCode;

                    string[] elements = textLine.Value.Split(';');
                    string rateInfo = string.Empty;

                    int index = elements.FindIndex(t => t.StartsWith("RG-") && t != "RG-");

                    if (index < 0)
                        index = elements.FindIndex(t => t.StartsWith("RQ-") && t != "RQ-");

                    if (index >= 0) {
                        string[] pricingParts = elements[index].Split(' ');

                        if (pricingParts.Any(t => t == "DY") || pricingParts[0].EndsWith("DY")) {
                            rateInfo += " per day";
                        }
                        else if (pricingParts.Any(t => t == "WY") || pricingParts[0].EndsWith("WY")) {
                            rateInfo += " per week";
                        }

                        if (pricingParts.Any(t => t == "UNL" || t == "UNL KM"))
                            rateInfo += "| unlimited km";

                        index = pricingParts.FindIndex(t => t == "XH" || t == "XD");

                        if (index >= 0) {
                            decimal.TryParse(pricingParts[index - 2].TrimEnd('-'), out decimal rate);

                            if (rate > 0)
                                rateInfo += isLocalCurrency ? string.Format("| {0:c2} per extra {1}", rate, pricingParts[index] == "XH" ? "hour" : "day") : string.Format("| {0}{1:f2} per extra {2}", foreignCurrencyCode, rate, pricingParts[index] == "XH" ? "hour" : "day");
                        }
                    }

                    if (!string.IsNullOrEmpty(foreignCurrencyCode) && foreignAmount != 0 && rateAmount != 0) {
                        comments += string.Format("Rate: {1}{2}| Total: {3}.{0}",
                            Environment.NewLine,
                            isLocalCurrency ? string.Format("{0:c2}", rateAmount) : string.Format("{0}{1:f2}", foreignCurrencyCode, rateAmount),
                            rateInfo,
                            isLocalCurrency ? string.Format("{0:c2}", foreignAmount) : string.Format("{0}{1:f2}", foreignCurrencyCode, foreignAmount));
                    }

                    if (elements.Length > 7)
                        comments += string.Format("Car Code: {1}| {2}.{0}", Environment.NewLine, elements[6].Trim(), elements[7].Trim().TrimEnd(".").Replace("NO-", "(NO AIRCON)"));

                    comments = comments.TrimEnd(Environment.NewLine);
                    break;
                case AmadeusSegmentType.ManualHotelSegment:
                    textParts = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None);
                    comments = textParts[8].TrimEnd(".");
                    break;
                case AmadeusSegmentType.ManualCarSegment:
                    textParts = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None);
                    comments = textParts[6].TrimEnd(".");
                    break;
                case AmadeusSegmentType.GroundTransportationSegment:
                    textParts = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None);
                    comments = textParts[10].TrimEnd(".");
                    break;
                case AmadeusSegmentType.AirTaxiSegment:
                case AmadeusSegmentType.ManualTourSegment:
                case AmadeusSegmentType.MiscellaneousSegment:
                    textParts = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None);
                    comments = textParts[5].TrimEnd(".");
                    break;
            }

            if (comments.Length > 0) {
                while (comments.StartsWith(Environment.NewLine)) {
                    comments = comments.TrimStart(Environment.NewLine);
                }

                while (comments.EndsWith(Environment.NewLine)) {
                    comments = comments.TrimEnd(Environment.NewLine);
                }

                comments = string.Format("{0}.", comments.Replace(";", Environment.NewLine).Replace(string.Format("{0}{0}{0}", Environment.NewLine), string.Format("{0}{0}", Environment.NewLine)).Replace("|", ";").TrimEnd("."));
            }

            return comments;
        }

        private static void AddTripLines(AppLazyContext lazyContext, int customerId, CrsModel crsModel, CrsImportModel crsImportModel, Dictionary<string, string> airlinePnrList,
            Dictionary<string, string> operatingAirlineList, List<AirSegmentModel> airSegmentList, List<SegmentPassengerModel> segmentPassengerList, List<FormOfPaymentModel> formOfPaymentList,
            List<TourCodeModel> tourCodeList, List<EmdLineModel> emdLineList, List<EmdLineModel> emdFullList, TextLineModel textLine, string lineId, string segmentNo, DateTime airCreationDate,
            DateTime issueDate, decimal airCommission, decimal airCommissionRate, bool excludePassengerSegmentPricing, ref int tripLineAirId, ref int tripLineLandId, ref int tripLineRemarkId,
            ref string routeInfo, bool isSummary, bool includeNoValueSegmentTypes = false) {

            var textInfo = CultureInfo.CurrentCulture.TextInfo;
            var amadeusSegment = textLine.AmadeusSegment;

            string departureCityCode = string.Empty;
            string arrivalCityCode = string.Empty;

            string[] textParts = Array.Empty<string>();
            string[] pricingElements = Array.Empty<string>();

            GetAmadeusSegmentParts(textLine, lineId, ref departureCityCode, ref arrivalCityCode, ref textParts, ref pricingElements);

            if (amadeusSegment.TripLineType == TripLineType.Air && amadeusSegment.SegmentType != AmadeusSegmentType.Emd && arrivalCityCode.Length > 0) {
                if (textLine.IsVoid) {
                    routeInfo += "/";
                }
                else {
                    if (!routeInfo.EndsWith(departureCityCode))
                        routeInfo += string.Concat("/", departureCityCode);

                    if (!routeInfo.EndsWith(arrivalCityCode))
                        routeInfo += string.Concat("/", arrivalCityCode);
                }
            }

            if (isSummary)
                return;

            string airlinePnr = string.Empty;
            string flightNo = string.Empty;
            string bookingClass = string.Empty;
            string bookingStatus = string.Empty;
            string confirmationNo = string.Empty;

            string departureTerminal = string.Empty;
            string arrivalTerminal = string.Empty;
            string checkInTime = string.Empty;
            string flightTime = string.Empty;
            string transitStops = string.Empty;
            string meals = string.Empty;

            string supplierCityCode = string.Empty;
            string supplierCrsCode = string.Empty;

            string supplierName = string.Empty;
            string supplierAddress1 = string.Empty;
            string supplierAddress2 = string.Empty;
            string supplierLocality = string.Empty;
            string supplierRegion = string.Empty;
            string supplierPostCode = string.Empty;
            string supplierCountryCode = string.Empty;
            string supplierContactPhoneWork = string.Empty;

            string startDetails = string.Empty;
            string startTime = string.Empty;
            string startAddress1 = string.Empty;
            string startAddress2 = string.Empty;
            string startLocality = string.Empty;
            string startRegion = string.Empty;
            string startPostCode = string.Empty;
            string startCountryCode = string.Empty;

            string endDetails = string.Empty;
            string endTime = string.Empty;
            string endAddress1 = string.Empty;
            string endAddress2 = string.Empty;
            string endLocality = string.Empty;
            string endRegion = string.Empty;
            string endPostCode = string.Empty;
            string endCountryCode = string.Empty;

            string serviceDescription = string.Empty;
            string inclusions = string.Empty;
            string comments = string.Empty;

            string crsAirSegmentKey = string.Empty;
            string crsPassengerKey = string.Empty;

            DateTime startDate = DateTime.MinValue;
            DateTime endDate = DateTime.MinValue;

            int departureCityId = -1;
            int arrivalCityId = -1;
            int aircraftId = -1;
            int airlineId = -1;
            int currencyId = -1;
            int formOfPaymentId = -1;
            int duration = -1;

            int baggageAllowance = 0;
            int paxAdultNo = 0;
            int paxAdultQty = 0;

            decimal paxAdultRate = 0;
            decimal distanceFlown = 0;
            decimal nonCommissionable = 0;
            decimal landCommission = 0;

            decimal foreignAmountTotal = 0;
            decimal exchangeRate = 0;

            var durationCoverageType = DurationCoverageType.Days;
            var serviceTypeRateBasis = ServiceTypeRateBasisBase.AccommodationPerPerson;
            var passengerClassification = PassengerClassification.Group;

            var baggageUnit = BaggageUnit.Piece;
            var ticketMethod = TicketMethod.ETicket;
            var airportType = AirportType.NotSpecified;
            var internationalDateOffset = InternationalDateOffset.None;

            if (textLine.IsVoid) {
                startDate = AppConstants.VoidDate;
                departureCityId = City.GetCity(lazyContext, departureCityCode).Id;
                arrivalCityId = City.GetCity(lazyContext, arrivalCityCode).Id;
            }
            else {
                switch (amadeusSegment.SegmentType) {
                    case AmadeusSegmentType.TicketedAirSegment:
                    case AmadeusSegmentType.UnticketedAirSegment:
                    case AmadeusSegmentType.UnticketedOpenSegment:
                        GetAirSegmentInfo(
                            lazyContext: lazyContext,
                            customerId: customerId,
                            textLine: textLine,
                            textParts: textParts,
                            airlinePnrList: airlinePnrList,
                            airCreationDate: airCreationDate,
                            departureCityCode: departureCityCode,
                            arrivalCityCode: arrivalCityCode,
                            departureCityId: ref departureCityId,
                            arrivalCityId: ref arrivalCityId,
                            airportType: ref airportType,
                            internationalDateOffset: ref internationalDateOffset,
                            startDate: ref startDate,
                            endDate: ref endDate,
                            startTime: ref startTime,
                            endTime: ref endTime,
                            aircraftId: ref aircraftId,
                            airlineId: ref airlineId,
                            airlinePnr: ref airlinePnr,
                            flightNo: ref flightNo,
                            bookingClass: ref bookingClass,
                            bookingStatus: ref bookingStatus,
                            ticketMethod: ref ticketMethod,
                            paxAdultNo: ref paxAdultNo,
                            departureTerminal: ref departureTerminal,
                            arrivalTerminal: ref arrivalTerminal,
                            checkInTime: ref checkInTime,
                            flightTime: ref flightTime,
                            baggageAllowance: ref baggageAllowance,
                            baggageUnit: ref baggageUnit,
                            distanceFlown: ref distanceFlown,
                            transitStops: ref transitStops,
                            meals: ref meals,
                            inclusions: ref inclusions,
                            comments: ref comments
                        );

                        break;
                    case AmadeusSegmentType.AutomatedHotelSegment:
                        GetAutoHotelSegmentInfo(
                            lazyContext: lazyContext,
                            customerId: customerId,
                            textLine: textLine,
                            textParts: textParts,
                            pricingElements: pricingElements,
                            airCreationDate: airCreationDate,
                            durationCoverageType: ref durationCoverageType,
                            serviceTypeRateBasis: ref serviceTypeRateBasis,
                            startDate: ref startDate,
                            endDate: ref endDate,
                            startTime: ref startTime,
                            endTime: ref endTime,
                            duration: ref duration,
                            currencyId: ref currencyId,
                            foreignAmountTotal: ref foreignAmountTotal,
                            exchangeRate: ref exchangeRate,
                            bookingStatus: ref bookingStatus,
                            supplierCityCode: ref supplierCityCode,
                            supplierCrsCode: ref supplierCrsCode,
                            confirmationNo: ref confirmationNo,
                            supplierName: ref supplierName,
                            supplierAddress1: ref supplierAddress1,
                            supplierAddress2: ref supplierAddress2,
                            supplierRegion: ref supplierRegion,
                            supplierPostCode: ref supplierPostCode,
                            supplierCountryCode: ref supplierCountryCode,
                            supplierContactPhoneWork: ref supplierContactPhoneWork,
                            supplierLocality: ref supplierLocality,
                            paxAdultQty: ref paxAdultQty,
                            paxAdultRate: ref paxAdultRate,
                            landCommission: ref landCommission,
                            inclusions: ref inclusions,
                            comments: ref comments
                        );

                        break;
                    case AmadeusSegmentType.AutomatedCarSegment:
                        GetAutoCarSegmentInfo(
                            lazyContext: lazyContext,
                            customerId: customerId,
                            textLine: textLine,
                            textParts: textParts,
                            airCreationDate: airCreationDate,
                            durationCoverageType: ref durationCoverageType,
                            serviceTypeRateBasis: ref serviceTypeRateBasis,
                            startDate: ref startDate,
                            endDate: ref endDate,
                            startTime: ref startTime,
                            endTime: ref endTime,
                            duration: ref duration,
                            currencyId: ref currencyId,
                            foreignAmountTotal: ref foreignAmountTotal,
                            exchangeRate: ref exchangeRate,
                            bookingStatus: ref bookingStatus,
                            supplierCityCode: ref supplierCityCode,
                            supplierCrsCode: ref supplierCrsCode,
                            serviceDescription: ref serviceDescription,
                            confirmationNo: ref confirmationNo,
                            formOfPaymentId: ref formOfPaymentId,
                            startDetails: ref startDetails,
                            endDetails: ref endDetails,
                            startAddress1: ref startAddress1,
                            startAddress2: ref startAddress2,
                            startLocality: ref startLocality,
                            startCountryCode: ref startCountryCode,
                            endAddress1: ref endAddress1,
                            endAddress2: ref endAddress2,
                            endLocality: ref endLocality,
                            endCountryCode: ref endCountryCode,
                            paxAdultQty: ref paxAdultQty,
                            paxAdultRate: ref paxAdultRate,
                            nonCommissionable: ref nonCommissionable,
                            inclusions: ref inclusions,
                            comments: ref comments
                        );

                        break;
                    case AmadeusSegmentType.DirectAccessHotelSegment:
                        GetDirectAccessHotelSegmentInfo(
                            lazyContext: lazyContext,
                            customerId: customerId,
                            textLine: textLine,
                            textParts: textParts,
                            airCreationDate: airCreationDate,
                            durationCoverageType: ref durationCoverageType,
                            serviceTypeRateBasis: ref serviceTypeRateBasis,
                            startDate: ref startDate,
                            endDate: ref endDate,
                            startTime: ref startTime,
                            endTime: ref endTime,
                            currencyId: ref currencyId,
                            foreignAmountTotal: ref foreignAmountTotal,
                            exchangeRate: ref exchangeRate,
                            bookingStatus: ref bookingStatus,
                            supplierCrsCode: ref supplierCrsCode,
                            confirmationNo: ref confirmationNo,
                            supplierName: ref supplierName,
                            paxAdultQty: ref paxAdultQty,
                            paxAdultRate: ref paxAdultRate,
                            inclusions: ref inclusions,
                            comments: ref comments
                        );

                        break;
                    case AmadeusSegmentType.AutomatedTourSegment:
                        if (!includeNoValueSegmentTypes)
                            return;

                        GetAutoTourSegmentInfo(
                            customerId: customerId,
                            textLine: textLine,
                            textParts: textParts,
                            airCreationDate: airCreationDate,
                            durationCoverageType: ref durationCoverageType,
                            serviceTypeRateBasis: ref serviceTypeRateBasis,
                            startDate: ref startDate,
                            endDate: ref endDate,
                            startTime: ref startTime,
                            endTime: ref endTime,
                            bookingStatus: ref bookingStatus,
                            supplierCrsCode: ref supplierCrsCode,
                            confirmationNo: ref confirmationNo,
                            paxAdultNo: ref paxAdultNo,
                            inclusions: ref inclusions,
                            comments: ref comments
                        );

                        break;
                    case AmadeusSegmentType.ManualCarSegment:
                    case AmadeusSegmentType.ManualHotelSegment:
                        if (!includeNoValueSegmentTypes)
                            return;

                        GetManualLandSegmentInfo(
                            customerId: customerId,
                            textLine: textLine,
                            textParts: textParts,
                            airCreationDate: airCreationDate,
                            durationCoverageType: ref durationCoverageType,
                            serviceTypeRateBasis: ref serviceTypeRateBasis,
                            startDate: ref startDate,
                            endDate: ref endDate,
                            startTime: ref startTime,
                            endTime: ref endTime,
                            bookingStatus: ref bookingStatus,
                            supplierCrsCode: ref supplierCrsCode,
                            paxAdultQty: ref paxAdultQty,
                            inclusions: ref inclusions,
                            comments: ref comments
                        );

                        break;
                    case AmadeusSegmentType.AirTaxiSegment:
                    case AmadeusSegmentType.GroundTransportationSegment:
                    case AmadeusSegmentType.ManualTourSegment:
                        if (!includeNoValueSegmentTypes)
                            return;

                        GetTransportSegmentInfo(
                            customerId: customerId,
                            textLine: textLine,
                            textParts: textParts,
                            airCreationDate: airCreationDate,
                            durationCoverageType: ref durationCoverageType,
                            serviceTypeRateBasis: ref serviceTypeRateBasis,
                            startDate: ref startDate,
                            endDate: ref endDate,
                            startTime: ref startTime,
                            endTime: ref endTime,
                            bookingStatus: ref bookingStatus,
                            supplierCrsCode: ref supplierCrsCode,
                            paxAdultNo: ref paxAdultNo,
                            inclusions: ref inclusions,
                            comments: ref comments
                        );

                        break;
                    case AmadeusSegmentType.AutomatedCruiseSegment:
                        if (!includeNoValueSegmentTypes)
                            return;

                        GetCruiseSegmentInfo(
                            textParts: textParts,
                            airCreationDate: airCreationDate,
                            durationCoverageType: ref durationCoverageType,
                            serviceTypeRateBasis: ref serviceTypeRateBasis,
                            startDate: ref startDate,
                            endDate: ref endDate,
                            startTime: ref startTime,
                            endTime: ref endTime,
                            bookingStatus: ref bookingStatus);

                        break;
                    case AmadeusSegmentType.UnticketedRailSegment:
                        if (!includeNoValueSegmentTypes)
                            return;

                        GetRailSegmentInfo(
                            textParts: textParts,
                            airCreationDate: airCreationDate,
                            durationCoverageType: ref durationCoverageType,
                            serviceTypeRateBasis: ref serviceTypeRateBasis,
                            startDate: ref startDate,
                            endDate: ref endDate,
                            bookingStatus: ref bookingStatus,
                            startTime: ref startTime,
                            endTime: ref endTime
                        );

                        break;
                }
            }

            switch (amadeusSegment.TripLineType) {
                case TripLineType.Air:
                    if (crsModel.TripLineAirList.Count == 0) {
                        crsModel.TripLineAirList.Add(new TripLineAir {
                            CrsRefId = tripLineAirId++,
                            AirlineId = segmentPassengerList.FirstOrDefault(t => t.AirlineId > 0)?.AirlineId ?? airlineId,
                            ValidUntilDate = DateTime.MinValue,
                            CrsPnrRef = crsModel.CrsPnrRef
                        });
                    }

                    var tripLineAir = crsModel.TripLineAirList.Last();

                    if (tripLineAir.TripLineAirSegmentList.Count > 0) {
                        DateTime departureDate = tripLineAir.TripLineAirSegmentList.Last().DepartureDate;

                        if (departureDate > DateTime.MinValue) {
                            while (departureDate.AddDays(-2) > startDate) {
                                startDate = startDate.AddYears(1);
                            }
                        }

                        DateTime arrivalDate = tripLineAir.TripLineAirSegmentList.Last().ArrivalDate;

                        if (arrivalDate > DateTime.MinValue) {
                            while (arrivalDate.AddDays(-2) > endDate) {
                                endDate = endDate.AddYears(1);
                            }
                        }
                    }

                    if (amadeusSegment.SegmentType != AmadeusSegmentType.SpecialServiceRequest)
                        crsAirSegmentKey = GetCrsAirSegmentKey(segmentNo, departureCityCode, arrivalCityCode);

                    string operatingAirline = string.Empty;

                    if (operatingAirlineList.ContainsKey(segmentNo)) {
                        var airline = Airline.GetAirline(lazyContext, operatingAirlineList[segmentNo].Left(2));

                        if (airline.Id > 0)
                            operatingAirline = string.Format("{0} as flight {1}", airline.Name, operatingAirlineList[segmentNo]);
                    }

                    if (departureCityId > 0 && arrivalCityId > 0 && amadeusSegment.SegmentType != AmadeusSegmentType.Emd) {
                        tripLineAir.TripLineAirSegmentList.Add(new TripLineAirSegment {
                            CrsKey = crsAirSegmentKey,
                            TripStatus = Trip.GetTripStatus(bookingStatus),
                            DepartureCityCode = departureCityCode,
                            ArrivalCityCode = arrivalCityCode,
                            DepartureCityId = departureCityId,
                            ArrivalCityId = arrivalCityId,
                            Class = bookingClass,
                            FlightNo = flightNo,
                            CheckInTime = checkInTime,
                            DepartureDate = textLine.IsVoid ? AppConstants.VoidDate : startDate,
                            DepartureTime = textLine.IsVoid ? string.Empty : startTime,
                            ArrivalDate = textLine.IsVoid ? AppConstants.VoidDate : endDate,
                            ArrivalTime = textLine.IsVoid ? string.Empty : endTime,
                            FlightTime = flightTime,
                            InternationalDateOffset = internationalDateOffset,
                            AirportType = airportType,
                            DepartureTerminal = departureTerminal,
                            ArrivalTerminal = arrivalTerminal,
                            AirlinePnr = airlinePnr,
                            AircraftId = aircraftId,
                            Operator = operatingAirline,
                            DistanceFlownKm = (int)(distanceFlown * AppConstants.MilesToKm),
                            CO2Emissions = 0,
                            TransitStops = transitStops,
                            Meals = meals,
                            SeqNo = (int)textLine.SeqNo
                        });
                    }

                    if (textLine.IsVoid)
                        return;

                    foreach (var airSegment in airSegmentList.Where(t => t.SegmentNo == segmentNo).ToList()) {
                        if (formOfPaymentId <= 0) {
                            if (formOfPaymentList.Any(t => t.SegmentNo == "*" && t.PassengerNo == "*")) {
                                formOfPaymentId = formOfPaymentList[0].FormOfPaymentId;
                            }
                            else {
                                formOfPaymentId = formOfPaymentList.SingleOrDefault(t => t.SegmentNo == airSegment.SegmentNo && t.PassengerNo == airSegment.PassengerNo)?.FormOfPaymentId ?? -1;
                            }
                        }

                        crsAirSegmentKey = GetCrsAirSegmentKey(airSegment.SegmentNo, airSegment.DepartureCityCode, airSegment.ArrivalCityCode);
                        crsPassengerKey = GetCrsPassengerKey(airSegment.PassengerNo, airSegment.AccompaniedInfant, crsModel.CrsPnrRef);

                        var tripLineAirPassenger = tripLineAir.TripLineAirPassengerList.SingleOrDefault(t => t.CrsPassengerKey == crsPassengerKey);

                        if (tripLineAirPassenger == null && !airSegment.IsEmd) {
                            issueDate = segmentPassengerList.SingleOrDefault(t => t.SegmentNo == airSegment.SegmentNo && t.PassengerNo == airSegment.PassengerNo)?.IssueDate ?? DateTime.MinValue;

                            if (airCommissionRate > 0)
                                airCommission = Math.Round(airSegment.TicketedFare * airCommissionRate / 100, 2);

                            tripLineAirPassenger = new TripLineAirPassenger {
                                CrsPassengerKey = crsPassengerKey,
                                CreditorId = crsImportModel.CrsCreditorAirId,
                                SupplierId = crsImportModel.CrsSupplierAirId,
                                PassengerId = -1,
                                SaleTypeId = -1,
                                FormOfPaymentId = formOfPaymentId,
                                AirlineId = segmentPassengerList.SingleOrDefault(t => t.SegmentNo == airSegment.SegmentNo && t.PassengerNo == airSegment.PassengerNo && t.AirlineId > 0)?.AirlineId ?? airlineId,
                                IssueDate = issueDate,
                                BspEntryType = airSegment.BspEntryType,
                                TicketNo = airSegment.TicketNo,
                                OriginalTicketNo = airSegment.OriginalTicketNo,
                                TicketMethod = ticketMethod,
                                FareCalc = string.Empty,
                                Amount = airSegment.Amount,
                                Tax = airSegment.Tax,
                                TicketedFare = airSegment.TicketedFare,
                                NonCommissionable = airSegment.NonCommissionable,
                                Commission = airCommission,
                                AccompaniedInfant = airSegment.AccompaniedInfant,
                                Comments = string.Empty
                            };

                            tripLineAir.TripLineAirPassengerList.Add(tripLineAirPassenger);
                        }

                        if (tripLineAirPassenger?.TripLineAirPassengerAirSegmentList.Any(t => t.CrsAirSegmentKey == crsAirSegmentKey && t.CrsPassengerKey == crsPassengerKey) ?? true)
                            continue;

                        decimal emdAmount = 0;
                        string emdComments = string.Empty;
                        bool isEmd = false;

                        if (emdLineList.Any(t => t.SegmentNo == airSegment.SegmentNo && t.PassengerNo == airSegment.PassengerNo)) {
                            isEmd = true;

                            foreach (var emdLine in emdLineList.Where(t => t.SegmentNo == airSegment.SegmentNo && t.PassengerNo == airSegment.PassengerNo)) {
                                emdComments += emdLine.Comment;
                            }

                            emdAmount = emdLineList.Where(t => t.SegmentNo == airSegment.SegmentNo && t.PassengerNo == airSegment.PassengerNo).Sum(t => t.Amount);
                        }

                        tripLineAirPassenger.TripLineAirPassengerAirSegmentList.Add(new TripLineAirPassengerAirSegment {
                            CrsAirSegmentKey = crsAirSegmentKey,
                            CrsPassengerKey = crsPassengerKey,
                            DepartureCityCode = airSegment.DepartureCityCode,
                            ArrivalCityCode = airSegment.ArrivalCityCode,
                            SeatNo = airSegment.SeatNo,
                            SeatStatus = airSegment.SeatStatus,
                            BaggageAllowance = baggageAllowance,
                            BaggageUnit = baggageUnit,
                            FareBasis = airSegment.FareBasis,
                            TourCode = tourCodeList.SingleOrDefault(t => t.SegmentNo == airSegment.SegmentNo && t.PassengerNo == airSegment.PassengerNo)?.TourCode ?? string.Empty,
                            TicketDesignator = airSegment.TicketDesignator,
                            TicketMethod = ticketMethod,
                            TicketedFare = emdAmount,
                            Amount = 0,
                            Tax = 0,
                            NonCommissionable = 0,
                            Commission = 0,
                            ExcludePassengerSegmentPricing = excludePassengerSegmentPricing,
                            Comments = emdComments,
                            EmdSegmentNos = emdFullList.Where(t => t.PassengerNo == airSegment.PassengerNo).Select(t => t.SegmentNo).Distinct().ToArray(),
                            IsEmd = isEmd
                        });
                    }

                    break;
                case TripLineType.Accommodation:
                case TripLineType.Transport:
                case TripLineType.Cruise:
                case TripLineType.Tour:
                case TripLineType.OtherLand:
                    int paxChildNo = 0;
                    int paxInfantNo = 0;

                    if (paxAdultNo == 0) {
                        paxInfantNo = crsModel.PassengerList.Count(t => t.PassengerType == PassengerType.Infant);
                        paxChildNo = crsModel.PassengerList.Count(t => t.PassengerType == PassengerType.Child);
                        paxAdultNo = crsModel.PassengerList.Count - paxChildNo - paxInfantNo;
                    }

                    if (duration == -1)
                        duration = Common.GetDuration(amadeusSegment.TripLineType, startDate, endDate, durationCoverageType);

                    var supplier = Supplier.GetSupplier(lazyContext, Crs.Amadeus, supplierCrsCode, supplierName);

                    crsModel.TripLineLandList.Add(new TripLineLand {
                        CrsRefId = tripLineLandId++,
                        CrsKey = crsAirSegmentKey,
                        TripLineType = amadeusSegment.TripLineType,
                        TripStatus = Trip.GetTripStatus(bookingStatus),
                        ConfirmationNo = confirmationNo,
                        CreditorId = crsImportModel.CrsCreditorLandId,
                        SupplierId = supplier.Id <= 0 ? crsImportModel.CrsSupplierLandId : supplier.Id,
                        SupplierName = supplierName.Length == 0 && supplier.Id > 0 ? supplier.Name : textInfo.ToTitleCase(supplierName.ToLower()),
                        SupplierChainId = -1,
                        SupplierCityCode = supplierCityCode,
                        SupplierCrsCode = supplierCrsCode,
                        SupplierAddress1 = textInfo.ToTitleCase(supplierAddress1.ToLower()),
                        SupplierAddress2 = textInfo.ToTitleCase(supplierAddress2.ToLower()),
                        SupplierLocality = textInfo.ToTitleCase(supplierLocality.ToLower()),
                        SupplierRegion = supplierRegion,
                        SupplierPostCode = supplierPostCode,
                        SupplierCountryCode = supplierCountryCode,
                        SupplierContactPhoneWork = supplierContactPhoneWork,

                        StartDate = startDate,
                        StartTime = startTime,
                        StartDetails = startDetails,
                        StartAddress1 = textInfo.ToTitleCase(startAddress1.ToLower()),
                        StartAddress2 = textInfo.ToTitleCase(startAddress2.ToLower()),
                        StartLocality = startLocality.Length <= 3 ? startLocality : textInfo.ToTitleCase(startLocality.ToLower()),
                        StartRegion = startRegion,
                        StartPostCode = startPostCode,
                        StartCountryCode = startCountryCode,
                        EndDate = endDate,
                        EndTime = endTime,
                        EndDetails = endDetails,
                        EndAddress1 = textInfo.ToTitleCase(endAddress1.ToLower()),
                        EndAddress2 = textInfo.ToTitleCase(endAddress2.ToLower()),
                        EndLocality = endLocality.Length <= 3 ? endLocality : textInfo.ToTitleCase(endLocality.ToLower()),
                        EndRegion = endRegion,
                        EndPostCode = endPostCode,
                        EndCountryCode = endCountryCode,
                        SupplierServiceDescription = serviceDescription,
                        Inclusions = inclusions,
                        Comments = comments,

                        DurationCoverageType = durationCoverageType,
                        Duration = duration,
                        PayForDuration = duration,
                        ServiceTypeRateBasis = serviceTypeRateBasis,
                        PassengerClassification = passengerClassification,
                        PaxAdultNo = paxAdultNo,
                        PaxAdultQty = paxAdultQty,
                        PaxAdultRate = paxAdultRate,
                        PaxChildNo = paxChildNo,
                        PaxChildQty = 0,
                        PaxChildRate = 0,
                        PaxInfantNo = paxInfantNo,
                        PaxInfantQty = 0,
                        PaxInfantRate = 0,
                        NonCommissionable = nonCommissionable,
                        Commission = landCommission,
                        FormOfPaymentId = formOfPaymentId,
                        SaleTypeId = GetSaleTypeId(lazyContext, customerId, amadeusSegment.TripLineType, departureCityCode, supplier.Id),
                        CurrencyId = currencyId,
                        ForeignAmount = foreignAmountTotal,
                        ExhangeRate = exchangeRate
                    });

                    break;
                case TripLineType.Remark:
                    switch (amadeusSegment.SegmentType) {
                        case AmadeusSegmentType.MiscellaneousSegment:
                            crsModel.TripLineRemarkList.Add(new TripLineRemark {
                                CrsAirSegmentKey = string.Empty,
                                CrsPassengerKey = string.Empty,
                                CrsRefId = tripLineRemarkId++,
                                CrsTripLineAirSegmentNo = string.Empty,
                                CrsPassengerNo = string.Empty,
                                TripLineId = 0,
                                TripLineAirSegmentId = 0,
                                PassengerId = 0,
                                StartDate = DateTime.MinValue,
                                EndDate = DateTime.MinValue,
                                Description = GetComments(customerId, textLine),
                                Remark = GetInclusions(customerId, textLine)
                            });

                            break;
                        case AmadeusSegmentType.SpecialServiceRequest:
                            string[] ssrAirSegmentNos = Array.Empty<string>();
                            string[] ssrPassengerNos = Array.Empty<string>();

                            var passengerDocumentList = new List<PassengerDocument>();
                            comments = GetSsr(lazyContext, crsModel, textLine, airCreationDate, ref ssrAirSegmentNos, ref ssrPassengerNos, ref inclusions, passengerDocumentList);

                            foreach (var passengerDocument in passengerDocumentList) {
                                var passenger = crsModel.PassengerList.SingleOrDefault(t => t.CrsKey == passengerDocument.CrsPassengerKey && !t.AccompaniedInfant);
                                passenger?.PassengerDocumentList.Add(passengerDocument);
                            }

                            if (string.IsNullOrEmpty(comments) && string.IsNullOrEmpty(inclusions))
                                break;

                            for (int i = 0; i < (ssrAirSegmentNos.Length == 0 ? 1 : ssrAirSegmentNos.Length); i++) {
                                string crsTripLineAirSegmentNo = amadeusSegment.SegmentType == AmadeusSegmentType.SpecialServiceRequest && ssrAirSegmentNos.Length > 0 ? ssrAirSegmentNos[i] : string.Empty;

                                for (int j = 0; j < (ssrPassengerNos.Length == 0 ? 1 : ssrPassengerNos.Length); j++) {
                                    string crsPassengerNo = amadeusSegment.SegmentType == AmadeusSegmentType.SpecialServiceRequest && ssrPassengerNos.Length > 0 && ssrPassengerNos.Length < crsModel.PassengerList.Count ? ssrPassengerNos[j] : string.Empty;

                                    if (crsModel.TripLineRemarkList.Any(t => t.CrsTripLineAirSegmentNo == crsTripLineAirSegmentNo && t.CrsPassengerNo == crsPassengerNo && t.Description == comments && t.Remark == inclusions))
                                        break;

                                    crsModel.TripLineRemarkList.Add(new TripLineRemark {
                                        CrsAirSegmentKey = GetCrsAirSegmentKey(crsTripLineAirSegmentNo.Length == 0 ? "0" : crsTripLineAirSegmentNo, departureCityCode, arrivalCityCode),
                                        CrsPassengerKey = GetCrsPassengerKey(crsPassengerNo, false, crsModel.CrsPnrRef),
                                        CrsRefId = tripLineRemarkId++,
                                        CrsTripLineAirSegmentNo = crsTripLineAirSegmentNo.Length == 0 ? "000" : crsTripLineAirSegmentNo,
                                        CrsPassengerNo = crsPassengerNo,
                                        TripLineId = 0,
                                        TripLineAirSegmentId = 0,
                                        PassengerId = 0,
                                        StartDate = DateTime.MinValue,
                                        EndDate = DateTime.MinValue,
                                        Description = comments,
                                        Remark = inclusions
                                    });

                                    if (ssrPassengerNos.Length == crsModel.PassengerList.Count)
                                        break;
                                }
                            }

                            break;
                    }

                    break;
            }
        }
        #endregion

        #region Other Functions
        private static string GetLineId(string value) {
            string lineId = value.Left(4);

            switch (lineId) {
                case "AIR-":
                case "KFTR":
                case "KNTR":
                case "KSTR":
                case "MUC1":
                case "TSA-":
                    return lineId;
                case "FM*M":
                    return "FM";
            }

            lineId = value.Left(3);

            switch (lineId) {
                case "AM ":
                case "EMD":
                case "FQV":
                case "K-R":
                case "KF-":
                case "KN-":
                case "KS-":
                case "KFT":
                case "KNT":
                case "KST":
                case "SSR":
                    return lineId.Trim();
            }

            lineId = value.Left(2);

            switch (lineId) {
                case "C-":
                case "D-":
                case "H-":
                case "I-":
                case "K-":
                case "O-":
                case "Q-":
                case "U-":
                case "X-":
                case "FO":
                case "FP":
                case "FT":
                case "FV":
                case "KF":
                case "KN":
                case "KS":
                case "TK":
                    return lineId;
            }

            lineId = value.Left(4).Trim();

            if (lineId.Length > 1 && lineId.Substring(1, 1) == "-")
                return lineId.Left(2);

            if (lineId.Length > 2 && lineId.Substring(2, 1) == "-")
                return lineId.Left(3);

            return lineId.Trim();
        }

        private static AmadeusSegmentModel GetAmadeusSegment(string textLineValue, string lineId = null) {
            lineId ??= GetLineId(textLineValue);
            string amadeusSegmentId = string.Empty;

            if (lineId == "SSR") {
                amadeusSegmentId = "SSR";
            }
            else if (lineId == "EMD") {
                amadeusSegmentId = "EMD";
            }
            else if (lineId == "H-" || lineId == "U-") {
                amadeusSegmentId = textLineValue.Split(';')[1].Substring(3, 3);

                if (amadeusSegmentId.StartsWith("O") || amadeusSegmentId.StartsWith("X"))
                    amadeusSegmentId = "AIR";
            }

            var amadeusSegment = AmadeusSegmentList.Single(t => t.SegmentType == AmadeusSegmentType.None);

            if (AmadeusSegmentList.Count(t => t.AmadeusSegmentId == amadeusSegmentId) == 1)
                amadeusSegment = AmadeusSegmentList.Single(t => t.AmadeusSegmentId == amadeusSegmentId);

            if (amadeusSegment.SegmentType == AmadeusSegmentType.None) {
                if (amadeusSegmentId == "AIR") {
                    if (lineId == "H-") {
                        amadeusSegment = AmadeusSegmentList.Single(t => t.SegmentType == AmadeusSegmentType.TicketedAirSegment);
                    }
                    else {
                        amadeusSegment = AmadeusSegmentList.Single(t => t.SegmentType == AmadeusSegmentType.UnticketedAirSegment);
                    }
                }
                else {
                    amadeusSegment = AmadeusSegmentList.FirstOrDefault(t => t.AmadeusSegmentId == amadeusSegmentId) ?? AmadeusSegmentList.Single(t => t.SegmentType == AmadeusSegmentType.None);
                }
            }

            return amadeusSegment;
        }

        private static void GetAmadeusSegmentParts(TextLineModel textLine, string lineId, ref string departureCityCode, ref string arrivalCityCode) {
            string[] textParts = Array.Empty<string>();
            string[] pricingElements = Array.Empty<string>();
            GetAmadeusSegmentParts(textLine, lineId, ref departureCityCode, ref arrivalCityCode, ref textParts, ref pricingElements);
        }

        private static void GetAmadeusSegmentParts(TextLineModel textLine, string lineId, ref string departureCityCode, ref string arrivalCityCode, ref string[] textParts, ref string[] pricingElements) {
            var amadeusSegment = textLine.AmadeusSegment;
            int index = 0;

            switch (amadeusSegment.SegmentType) {
                default:
                    textParts = textLine.Value.TrimStart(lineId).Split(';');
                    break;
                case AmadeusSegmentType.AutomatedHotelSegment:
                    index = textLine.Value.GetNthIndex(';', 9);
                    pricingElements = textLine.Value.Substring(index + 1).Split(amadeusSegment.SegmentParts, StringSplitOptions.None);
                    textParts = textLine.Value.Left(index).TrimStart("H-").TrimStart("U-").Split(';').Concat(textLine.Value.Substring(index + pricingElements[0].Length + 1).Split(';')).ToArray();
                    break;
                case AmadeusSegmentType.AutomatedCarSegment:
                    textParts = textLine.Value.TrimStart(lineId).Split(amadeusSegment.SegmentParts, StringSplitOptions.None);
                    break;
                case AmadeusSegmentType.AutomatedCruiseSegment:
                    index = textLine.Value.GetNthIndex(';', 20);
                    string cruiseElement = textLine.Value.Substring(index + 1).Split(amadeusSegment.SegmentParts, StringSplitOptions.None)[0];
                    textParts = textLine.Value.Left(index).TrimStart("H-").TrimStart("U-").Split(';').Concat(textLine.Value.Substring(index + cruiseElement.Length + 1).Split(';')).ToArray();
                    break;
            }

            switch (amadeusSegment.SegmentType) {
                default:
                    departureCityCode = textParts[4];
                    arrivalCityCode = string.Empty;
                    break;
                case AmadeusSegmentType.None:
                case AmadeusSegmentType.TicketedAirSegment:
                case AmadeusSegmentType.UnticketedAirSegment:
                case AmadeusSegmentType.UnticketedOpenSegment:
                    departureCityCode = textParts[1].Right(3);
                    arrivalCityCode = textParts[3];
                    break;
                case AmadeusSegmentType.AutomatedCarSegment:
                    var parts = textParts[0].Split(';');

                    if (parts.Length > 4) {
                        departureCityCode = parts[4];
                    }
                    else {
                        departureCityCode = string.Empty;
                    }

                    arrivalCityCode = string.Empty;
                    break;
                case AmadeusSegmentType.GroundTransportationSegment:
                case AmadeusSegmentType.UnticketedSurfaceSegment:
                case AmadeusSegmentType.MiscellaneousSegment:
                    departureCityCode = textParts[3];
                    arrivalCityCode = string.Empty;
                    break;
                case AmadeusSegmentType.AutomatedCruiseSegment:
                    departureCityCode = textParts[3];
                    arrivalCityCode = textParts[5];
                    break;
                case AmadeusSegmentType.AutomatedTourSegment:
                case AmadeusSegmentType.ManualTourSegment:
                    departureCityCode = textParts[3].Left(3);
                    arrivalCityCode = string.Empty;
                    break;
                case AmadeusSegmentType.SpecialServiceRequest:
                    break;
                case AmadeusSegmentType.Emd:
                    departureCityCode = textParts[11];
                    arrivalCityCode = textParts[12];
                    break;
            }
        }

        private static string GetLocalTaxCode(int customerId) {
            return AppSettings.CrsLocalTaxCodes.ContainsKey(AppSettings.Setting(customerId).CountryCode) ? AppSettings.CrsLocalTaxCodes[AppSettings.Setting(customerId).CountryCode] : string.Empty;
        }

        private static string[] GetTaxParts(AppLazyContext lazyContext, List<TextLineModel> textLineList, string crsTaxCode, ref int currencyId, ref string currencyCode, ref decimal nonCommissionable, ref decimal localTax) {
            string[] taxParts = Array.Empty<string>();
            var textLine = textLineList.FirstOrDefault(t => (t.Value.StartsWith("KFT") || t.Value.StartsWith("KNT") || t.Value.StartsWith("KST")) && !t.IsProcessed);

            if (textLine == null) {
                textLineList.ForEach(t => t.IsProcessed = false);
                return taxParts;
            }

            textLine.IsProcessed = true;

            string lineId = GetLineId(textLine.Value);
            taxParts = textLine.Value.TrimStart(lineId).Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string taxPart in taxParts) {
                if (taxPart.Length <= 4)
                    break;

                if (currencyId <= 0) {
                    currencyCode = new string(taxPart.Where(t => char.IsLetter(t)).ToArray()).Right(3);
                    currencyId = Currency.GetCurrency(lazyContext, currencyCode).Id;
                }
            }

            foreach (string taxPart in taxParts.Where(t => t.StartsWith(" ") || t.StartsWith("G"))) {
                if (taxPart.Length < 6)
                    continue;

                string part = taxPart.Left(taxPart.Length - 5);
                string[] textParts = part.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                string amount = new(part.Where(t => char.IsDigit(t) || t == '.').ToArray());
                decimal.TryParse(amount, out decimal result);

                if (textParts.Length > 1 && textParts[1] == crsTaxCode) {
                    localTax = result;
                }
                else {
                    nonCommissionable += result;
                }
            }

            return taxParts;
        }

        private static int GetSaleTypeId(AppLazyContext lazyContext, int customerId, TripLineType tripLineType, string cityCode, int supplierId) {
            int saleTypeId = 0;

            if (supplierId > 0)
                saleTypeId = lazyContext.Supplier.Find(supplierId)?.SaleTypeId ?? -1;

            if (saleTypeId > 0)
                return saleTypeId;

            string countryCode = City.GetCity(lazyContext, cityCode).Country.Code;

            saleTypeId = string.IsNullOrEmpty(countryCode) || countryCode == AppSettings.Setting(customerId).CountryCode ? tripLineType == TripLineType.Transport ? AppSettings.Setting(customerId).CrsDomesticTransportSaleTypeId : AppSettings.Setting(customerId).CrsDomesticAccommodationSaleTypeId
                : tripLineType == TripLineType.Transport ? AppSettings.Setting(customerId).CrsInternationalTransportSaleTypeId : AppSettings.Setting(customerId).CrsInternationalAccommodationSaleTypeId;

            return saleTypeId;
        }

        private static decimal GetExchangeRate(AppLazyContext lazyContext, int customerId, AmadeusSegmentModel segment, string foreignCurrencyCode, decimal localAmount = 0, decimal foreignAmount = 0, AirSegmentModel segmentPassenger = null) {
            if (foreignCurrencyCode == AppSettings.Setting(customerId).CurrencyCode)
                return 1;

            decimal exchangeRate;

            switch (segment.SegmentType) {
                default:
                    if (segment.TripLineType == TripLineType.Air) {
                        if (segmentPassenger == null) {
                            if (localAmount != 0 && foreignAmount != 0) {
                                exchangeRate = foreignAmount / localAmount;
                            }
                            else {
                                exchangeRate = Currency.GetExchangeRate(lazyContext, foreignCurrencyCode);
                            }
                        }
                        else {
                            exchangeRate = segmentPassenger.ExchangeRate;
                        }
                    }
                    else {
                        exchangeRate = Currency.GetExchangeRate(lazyContext, foreignCurrencyCode);
                    }

                    break;
                case AmadeusSegmentType.AutomatedHotelSegment:
                    if (localAmount != 0 && foreignAmount != 0) {
                        exchangeRate = foreignAmount / localAmount;
                    }
                    else {
                        exchangeRate = Currency.GetExchangeRate(lazyContext, foreignCurrencyCode);
                    }

                    break;
            }

            return Math.Round(exchangeRate, 8);
        }

        private static void GetStartEndDate(DateTime airCreationDate, string startDateTime, string endDateTime, ref DateTime startDate, ref DateTime endDate, bool startDateIsFuture = true) {
            int year = airCreationDate.Year;

            if (startDateTime.Length >= 5) {
                if (startDateTime.Left(5) == "29FEB") {
                    while (!DateTime.IsLeapYear(year)) {
                        year++;
                    }
                }

                DateTime.TryParse(string.Concat(startDateTime.Left(5), year), out startDate);
            }

            if (startDate > DateTime.MinValue) {
                if (startDateIsFuture) {
                    while (startDate < airCreationDate.AddDays(-7)) {
                        startDate = startDate.AddYears(1);
                    }
                }
                else {
                    while (startDate > airCreationDate) {
                        startDate = startDate.AddYears(-1);
                    }
                }
            }

            year = airCreationDate.Year;

            if (endDateTime.Length >= 5) {
                if (endDateTime.Left(5) == "29FEB") {
                    while (!DateTime.IsLeapYear(year)) {
                        year++;
                    }
                }

                DateTime.TryParse(string.Concat(endDateTime.Left(5), year), out endDate);
            }

            if (endDate > DateTime.MinValue) {
                while (endDate < startDate.AddDays(-2)) {
                    endDate = endDate.AddYears(1);
                }
            }
        }

        private static decimal ResolveAirSegmentSeqNo(this TextLineModel textLine, List<TextLineModel> textLineList) {
            if (textLine.SeqNo > 0)
                return textLine.SeqNo;

            var previousTextLine = textLineList.Skip(textLine.RowIndex - 1).FirstOrDefault(AirSegmentsWhereClause());
            var nextTextLine = textLineList.Skip(textLine.RowIndex + 1).FirstOrDefault(AirSegmentsWhereClause());

            var airSegments = textLineList.Where(AirSegmentsWhereClause());

            if (previousTextLine == null) {
                return (airSegments.Min(t => (int?)t.SeqNo) ?? 0) - 1;
            }
            else if (nextTextLine == null) {
                return (airSegments.Max(t => (int?)t.SeqNo) ?? 0) + 1;
            }
            else {
                return previousTextLine.SeqNo + .5m;
            }
        }

        private static string[] GetAirSegmentAssignments(string textPart, int index) {
            try {
                return GetIdAssignments(textPart, index).Select(t => string.Format("{0:d3}", t)).ToArray();
            }
            catch {
                return Array.Empty<string>();
            }
        }

        private static string[] GetPassengerAssignments(string textPart, int index) {
            try {
                return GetIdAssignments(textPart, index).Select(t => string.Format("{0:d2}", t)).ToArray();
            }
            catch {
                return Array.Empty<string>();
            }
        }

        private static List<int> GetSegmentIndexAssignments(List<TextLineModel> textLineList, string textPart, int index) {
            var segmentNoList = GetAirSegmentAssignments(textPart, index);
            var textLines = textLineList.Where(t => t.AmadeusSegment.TripLineType == TripLineType.Air && !t.IsEmd);

            var segmentIndexList = new List<int>();

            foreach (var segmentNo in segmentNoList) {
                int segmentIndex = textLines.FirstOrDefault(t => t.Value.Split(';')[1].Left(3) == segmentNo)?.RowIndex ?? 0;

                if (segmentIndex > 0)
                    segmentIndexList.Add(segmentIndex);
            }

            return segmentIndexList;
        }

        private static List<int> GetIdAssignments(string textPart, int index) {
            var idList = new List<int>();
            string[] textParts = textPart.Split(';');

            if (textParts.Length - 1 < index)
                return idList;

            foreach (string part in textParts[index].Replace("P", string.Empty).Replace("S", string.Empty).Split(',').ToArray()) {
                if (part.Contains('-')) {
                    for (int i = part.Split('-')[0].ToInt(); i <= part.Split('-')[1].ToInt(); i++) {
                        idList.Add(i);
                    }
                }
                else {
                    idList.Add(part.ToInt());
                }
            }

            return idList;
        }

        private static string GetCrsAirSegmentKey(string airSegmentNo, string departureCityCode, string arrivalCityCode) {
            return string.Format("{0}¶{1}¶{2}", int.Parse(airSegmentNo), departureCityCode, arrivalCityCode);
        }

        private static string GetCrsPassengerKey(string passengerNo, bool accompaniedInfant, string crsPnrRef) {
            return string.Format("{0}¶{1}¶{2}", passengerNo, accompaniedInfant ? 1 : 0, crsPnrRef);
        }

        private static Func<TextLineModel, bool> AirSegmentsWhereClause() {
            return t => t.Value.StartsWith("H-") || t.Value.StartsWith("U-") || t.Value.StartsWith("EMD");
        }

        private static Func<TextLineModel, bool> FareLineWhereClause() {
            return t => (t.Value.StartsWith("K-") && t.Value != "K-") || (t.Value.StartsWith("KN-") && t.Value != "KN-") || (t.Value.StartsWith("KS-") && t.Value != "KS-");
        }

        private static Func<TextLineModel, bool> FareLineKnWhereClause() {
            return t => (t.Value.StartsWith("K-") && t.Value != "K-") || (t.Value.StartsWith("KN-") && t.Value != "KN-");
        }

        private static Func<TextLineModel, bool> FareLineKsWhereClause() {
            return t => (t.Value.StartsWith("K-") && t.Value != "K-") || (t.Value.StartsWith("KS-") && t.Value != "KS-");
        }
        #endregion

        #region Trip Line Functions
        private static void GetAirSegmentInfo(AppLazyContext lazyContext, int customerId, TextLineModel textLine, string[] textParts, Dictionary<string, string> airlinePnrList, DateTime airCreationDate,
            string departureCityCode, string arrivalCityCode, ref int departureCityId, ref int arrivalCityId, ref AirportType airportType, ref InternationalDateOffset internationalDateOffset,
            ref DateTime startDate, ref DateTime endDate, ref string startTime, ref string endTime, ref int aircraftId, ref int airlineId, ref string airlinePnr,
            ref string flightNo, ref string bookingClass, ref string bookingStatus, ref TicketMethod ticketMethod, ref int paxAdultNo, ref string departureTerminal, ref string arrivalTerminal,
            ref string checkInTime, ref string flightTime, ref int baggageAllowance, ref BaggageUnit baggageUnit, ref decimal distanceFlown, ref string transitStops, ref string meals,
            ref string inclusions, ref string comments) {

            var amadeusSegment = textLine.AmadeusSegment;
            flightNo = textParts[5].Left(10).Replace(" ", string.Empty);

            if (flightNo.Right(4) == "OPEN")
                return;

            flightNo = string.Format("{0}{1}", flightNo.Left(2), flightNo.Right(4).TrimStart('0'));

            string startDateTime = string.Empty;
            string endDateTime = string.Empty;
            string electronicTicket = string.Empty;
            string baggage = string.Empty;
            string aircraftCode = string.Empty;
            string distance = string.Empty;

            int stops = 0;
            string[] mealCodes = Array.Empty<string>();

            string serviceClass = textParts[5].Substring(11, 1);
            bookingClass = textParts[5].Substring(13, 1);

            string airlineCode = flightNo.Left(2);

            if (airlineCode.Length > 0) {
                airlineId = Airline.GetAirline(lazyContext, airlineCode).Id;
                var item = airlinePnrList.SingleOrDefault(t => t.Key == airlineCode);
                airlinePnr = item.Key == null ? string.Empty : item.Value;
            }

            if (amadeusSegment.SegmentType == AmadeusSegmentType.UnticketedOpenSegment) {
                startDateTime = textParts[6].Trim();
                bookingStatus = textParts[7].Trim();
                baggage = textParts[8].Trim();
                electronicTicket = textParts[9].Trim();
                decimal.TryParse(textParts[11].Trim(), out distanceFlown);
            }
            else {
                if (textParts[5].Length == 32) {
                    startDateTime = textParts[5].Substring(12, 9);
                    endDateTime = string.Concat(textParts[5].AsSpan(27, 5), textParts[5].AsSpan(22, 4));
                }
                else {
                    startDateTime = textParts[5].Substring(15, 9);
                    endDateTime = string.Concat(textParts[5].AsSpan(30, 5), textParts[5].AsSpan(25, 4));
                }

                bookingStatus = textParts[6].Left(2);
                paxAdultNo = int.Parse(textParts[6].Substring(2, 2));

                if (textParts.Length == 22) {
                    mealCodes = textParts[7].Trim().ToCharArray().Select(t => t.ToString()).ToArray();
                    stops = textParts[8].ToInt();
                    aircraftCode = textParts[9].Trim();
                    baggage = textParts[12].Trim();

                    departureTerminal = textParts[13].Trim();
                    checkInTime = textParts[14].Trim();
                    electronicTicket = textParts[15].Trim();
                    flightTime = textParts[16].Trim();
                    distance = textParts[19].Trim();
                    arrivalTerminal = textParts[21].Trim();
                }
                else if (textParts.Length == 23) {
                    mealCodes = textParts[8].Trim().ToCharArray().Select(t => t.ToString()).ToArray();
                    stops = textParts[9].ToInt();
                    aircraftCode = textParts[10].Trim();
                    baggage = textParts[13].Trim();

                    departureTerminal = textParts[14].Trim();
                    checkInTime = textParts[15].Trim();
                    electronicTicket = textParts[16].Trim();
                    flightTime = textParts[17].Trim();
                    distance = textParts[19].Trim();
                    arrivalTerminal = textParts[22].Trim();
                }
                else {
                    mealCodes = textParts[8].Trim().ToCharArray().Select(t => t.ToString()).ToArray();
                    stops = textParts[9].ToInt();
                    aircraftCode = textParts[10].Trim();
                    baggage = textParts[13].Trim();

                    departureTerminal = textParts[14].Trim();
                    checkInTime = textParts[15].Trim();
                    electronicTicket = textParts[16].Trim();
                    flightTime = textParts[17].Trim();
                    distance = textParts[20].Trim();

                    if (textParts.Length > 24)
                        arrivalTerminal = textParts[24].Trim();
                }

                decimal.TryParse(distance, out distanceFlown);
            }

            if (endDateTime.Length >= 9)
                startTime = string.Concat(startDateTime.Substring(5, 2), ":", startDateTime.Right(2));

            if (endDateTime.Length >= 9)
                endTime = string.Concat(endDateTime.Substring(5, 2), ":", endDateTime.Right(2));

            GetStartEndDate(airCreationDate, startDateTime, endDateTime, ref startDate, ref endDate);

            if (electronicTicket.Length > 0)
                ticketMethod = electronicTicket == "ET" ? TicketMethod.ETicket : TicketMethod.Hand;

            if (aircraftCode.Length > 0)
                aircraftId = Aircraft.GetAircraft(lazyContext, aircraftCode).Id;

            if (baggage.Length > 0) {
                if (baggage.EndsWith("K")) {
                    baggage = baggage.TrimEnd("K");
                    baggageUnit = BaggageUnit.Kilogram;
                }
                else if (baggage.EndsWith("PC")) {
                    baggage = baggage.TrimEnd("PC");
                    baggageUnit = BaggageUnit.Piece;
                }

                baggageAllowance = baggage.ToInt();
            }

            if (stops == 1) {
                transitStops = "1 stop";
            }
            else if (stops > 1) {
                transitStops = string.Format("{0} stops", stops);
            }

            if (checkInTime.Length > 0)
                checkInTime = string.Concat(checkInTime.Left(2), ":", checkInTime.Right(2));

            if (flightTime.Length > 0)
                flightTime = string.Concat(flightTime.Left(2), ":", flightTime.Right(2));

            var departureCity = City.GetCity(lazyContext, departureCityCode);
            var arrivalCity = City.GetCity(lazyContext, arrivalCityCode);

            departureCityId = departureCity.Id;
            arrivalCityId = arrivalCity.Id;

            airportType = departureCity.Country.Code == arrivalCity.Country.Code ? AirportType.Domestic : AirportType.International;

            int days = (endDate - startDate).Days;
            Enum.TryParse(days.ToStringExt(), out internationalDateOffset);

            if (textLine.IsVoid) {
                startDate = AppConstants.VoidDate;
                endDate = AppConstants.VoidDate;
            }

            foreach (string mealCode in mealCodes) {
                var mealServed = MealServed.GetMealServed(lazyContext, Crs.Amadeus, mealCode);

                if (mealServed.Id > 0)
                    meals += string.Format("{0}; ", mealServed.Name);
            }

            meals = meals.TrimEnd("; ");

            inclusions = GetInclusions(customerId, textLine);
            comments = GetComments(customerId, textLine);
        }

        private static void GetAutoHotelSegmentInfo(AppLazyContext lazyContext, int customerId, TextLineModel textLine, string[] textParts, string[] pricingElements, DateTime airCreationDate,
            ref DurationCoverageType durationCoverageType, ref ServiceTypeRateBasisBase serviceTypeRateBasis, ref DateTime startDate, ref DateTime endDate, ref string startTime, ref string endTime,
            ref int duration, ref int currencyId, ref decimal foreignAmountTotal, ref decimal exchangeRate, ref string bookingStatus, ref string supplierCityCode, ref string supplierCrsCode,
            ref string confirmationNo, ref string supplierName, ref string supplierAddress1, ref string supplierAddress2, ref string supplierLocality, ref string supplierRegion, ref string supplierPostCode,
            ref string supplierCountryCode, ref string supplierContactPhoneWork, ref int paxAdultQty, ref decimal paxAdultRate, ref decimal landCommission, ref string inclusions, ref string comments,
            bool validateRateBasisUsingRateAmount = false) {

            var amadeusSegment = textLine.AmadeusSegment;
            durationCoverageType = DurationCoverageType.Nights;

            bookingStatus = textParts[1].Substring(10, 2);
            supplierCityCode = textParts[4];
            confirmationNo = textParts.FirstOrDefault(t => t.StartsWith("CF-"))?.TrimStart("CF-") ?? string.Empty;

            string startDateTime;
            string endDateTime;

            string[] dateTimeParts = textParts.FirstOrDefault(t => t.StartsWith("IN-"))?.Split("OUT-");

            if (dateTimeParts?.Length > 1) {
                startDateTime = string.Format("{0}{1}", textParts[2].Right(5), dateTimeParts[0].TrimStart("IN-")?.Left(5)).Trim();
                endDateTime = string.Format("{0}{1}", textParts[3], dateTimeParts[1].TrimStart("OUT-")?.Left(5)).Trim();
            }
            else if (textParts.Length <= 82) {
                startDateTime = textParts[2].Right(5);
                endDateTime = textParts[3];
            }
            else {
                startDateTime = textParts[1].Right(5);
                endDateTime = textParts[2];
            }

            if (startDateTime.Length >= 9)
                startTime = string.Concat(startDateTime.Substring(5, 2), ":", startDateTime.Right(2));

            if (endDateTime.Length >= 9)
                endTime = string.Concat(endDateTime.Substring(5, 2), ":", endDateTime.Right(2));

            GetStartEndDate(airCreationDate, startDateTime, endDateTime, ref startDate, ref endDate);

            string localCurrencyCode = string.Empty;
            string foreignCurrencyCode = string.Empty;
            string supplierCountry = string.Empty;

            if (textParts.Length <= 82) {
                supplierCrsCode = string.Format("{0}{1}{2}", textParts[1].Substring(7, 2), textParts[4], textParts[11]);

                foreignCurrencyCode = textParts[8].Left(3);
                localCurrencyCode = textParts[8].Right(3);

                supplierName = textParts[31];
                supplierAddress1 = textParts[32];
                supplierAddress2 = textParts[33];
                supplierLocality = textParts[34];
                supplierRegion = textParts[35];
                supplierPostCode = textParts[38];
                supplierCountry = textParts[37];
                supplierContactPhoneWork = textParts[39].Replace("/", " ");
            }
            else {
                supplierCrsCode = string.Format("{0}{1}{2}", textParts[1].Substring(7, 2), textParts[4], textParts[10]);

                foreignCurrencyCode = textParts[7].Left(3);
                localCurrencyCode = textParts[7].Right(3);

                supplierName = textParts[30];
                supplierAddress1 = textParts[31];
                supplierAddress2 = textParts[32];
                supplierLocality = textParts[33];
                supplierRegion = textParts[34];
                supplierPostCode = textParts[35];
                supplierCountry = textParts[36];
                supplierContactPhoneWork = textParts[37].Replace("/", " ");
            }

            currencyId = Currency.GetCurrency(lazyContext, foreignCurrencyCode).Id;
            supplierCountryCode = lazyContext.Country.SingleOrDefault(t => t.Name.ToLower() == supplierCountry.ToLower())?.Code ?? string.Empty;

            string[] elements = pricingElements[2].Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);

            decimal.TryParse(elements[0].Substring(4), out decimal foreignAmount);
            decimal.TryParse(elements[3].Substring(3), out decimal localAmount);

            if (localAmount == 0 && foreignCurrencyCode == AppSettings.Setting(customerId).CurrencyCode)
                localAmount = foreignAmount;

            pricingElements = pricingElements[0].Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
            int elementCount = pricingElements.Length;

            int index = 0;
            decimal totalRateAmount = 0;

            duration = 0;
            var rateDurations = new List<decimal>();

            foreach (string pricingElement in pricingElements) {
                index++;
                var pricingParts = pricingElement.Split('+');

                decimal rateAmount = 0;
                decimal localRateAmount = 0;

                int rateDuration = 0;

                if (pricingParts.Length > 2) {
                    rateAmount = decimal.Parse(pricingParts[0]);
                    rateDuration = int.Parse(pricingParts[2]);

                    if (!rateDurations.Contains(rateDuration))
                        rateDurations.Add(rateDuration);
                }

                if (localCurrencyCode == foreignCurrencyCode) {
                    localRateAmount = rateAmount;
                }
                else if (pricingParts.Length > 3) {
                    localRateAmount = decimal.Parse(pricingParts[3]);
                }

                duration += rateDuration;
                totalRateAmount += localRateAmount * rateDuration;

                inclusions += string.Format("{1}{0}", AppConstants.HtmlLineBreak, GetInclusions(customerId, textLine, localCurrencyCode, foreignCurrencyCode, index < elementCount ? 0 : localAmount, foreignAmount, rateAmount, rateDuration, index < elementCount).Replace("!.", "!"));
                comments += string.Format("{1}{0}", Environment.NewLine, GetComments(customerId, textLine, localCurrencyCode, foreignCurrencyCode, index < elementCount ? 0 : localAmount, foreignAmount, rateAmount, rateDuration).Replace("!.", "!"));
            }

            inclusions = inclusions.TrimEnd(AppConstants.HtmlLineBreak);
            comments = comments.TrimEnd(Environment.NewLine);

            paxAdultRate = localAmount;
            paxAdultQty = int.Parse(textParts[1].Split(' ')[2].Right(2));

            if (rateDurations.Count <= 1) {
                if (duration > 1)
                    paxAdultRate /= duration;

                if (paxAdultQty > 1)
                    paxAdultRate /= paxAdultQty;
            }

            if ((validateRateBasisUsingRateAmount && localAmount > totalRateAmount) || (!validateRateBasisUsingRateAmount && paxAdultQty > 1) || rateDurations.Count > 1) {
                serviceTypeRateBasis = ServiceTypeRateBasisBase.AccommodationPackage;
            }
            else {
                serviceTypeRateBasis = ServiceTypeRateBasisBase.AccommodationPerRoom;
            }

            var commissionParts = textParts[42].Split(new string[] { "COM-" }, StringSplitOptions.None);

            if (commissionParts.Length > 1)
                landCommission = decimal.Parse(commissionParts[1]);

            if (localAmount == 0 && foreignCurrencyCode == AppSettings.Setting(customerId).CurrencyCode) {
                foreignAmountTotal = 0;
                exchangeRate = 1;
            }
            else {
                foreignAmountTotal = foreignAmount;
                exchangeRate = GetExchangeRate(lazyContext, customerId, amadeusSegment, foreignCurrencyCode, localAmount, foreignAmount);
            }
        }

        private static void GetAutoCarSegmentInfo(AppLazyContext lazyContext, int customerId, TextLineModel textLine, string[] textParts, DateTime airCreationDate, ref DurationCoverageType durationCoverageType,
            ref ServiceTypeRateBasisBase serviceTypeRateBasis, ref DateTime startDate, ref DateTime endDate, ref string startTime, ref string endTime, ref int duration, ref int currencyId,
            ref decimal foreignAmountTotal, ref decimal exchangeRate, ref string bookingStatus, ref string supplierCityCode, ref string supplierCrsCode, ref string serviceDescription,
            ref string confirmationNo, ref int formOfPaymentId, ref string startDetails, ref string endDetails, ref string startAddress1, ref string startAddress2, ref string startLocality,
            ref string startCountryCode, ref string endAddress1, ref string endAddress2, ref string endLocality, ref string endCountryCode, ref int paxAdultQty, ref decimal paxAdultRate,
            ref decimal nonCommissionable, ref string inclusions, ref string comments, bool processPickupDropoff = false) {

            var amadeusSegment = textLine.AmadeusSegment;

            durationCoverageType = DurationCoverageType.Days;
            serviceTypeRateBasis = ServiceTypeRateBasisBase.TransportPerDay;

            string rateElement = textParts[1];
            textParts = textParts[0].Split(';');

            paxAdultQty = int.Parse(textParts[1].Split(' ')[2].Right(2));
            supplierCityCode = textParts[4];
            supplierCrsCode = string.Format("{0}{1}", textParts[1].Substring(7, 2), textParts.FirstOrDefault(t => t.StartsWith("LC-"))?.TrimStart("LC-") ?? string.Empty);

            string code = supplierCrsCode;

            if (!lazyContext.SupplierCrs.Any(t => t.CrsCode.ToLower() == code.ToLower()))
                supplierCrsCode = textParts[1].Substring(7, 2);

            bookingStatus = textParts[1].Substring(10, 2);
            confirmationNo = textParts.FirstOrDefault(t => t.StartsWith("CF-"))?.TrimStart("CF-") ?? string.Empty;

            if (textParts[17].Length > 3) {
                string formOfPayment = textParts[17].Substring(3);

                if (formOfPayment.Length > 0) {
                    formOfPaymentId = lazyContext.FormOfPayment.SingleOrDefault(t => t.Name.ToLower() == formOfPayment.ToLower())?.Id ?? -1;

                    if (formOfPaymentId == -1)
                        formOfPaymentId = lazyContext.FormOfPaymentCrs.SingleOrDefault(t => t.CrsCode.ToLower() == formOfPayment.ToLower())?.FormOfPaymentId ?? -1;
                }
            }

            string startDateTime = textParts[2].Right(5);
            string endDateTime = textParts[3];

            startTime = textParts[8].TrimStart("ARR-");
            endTime = textParts[9].TrimStart("RT-");

            if (startTime.Length >= 4) {
                startTime = string.Format("{0}:{1}", startTime.Right(4).Left(2), startTime.Right(2));
            }
            else {
                startTime = string.Empty;
            }

            if (endTime.Length >= 4) {
                endTime = string.Format("{0}:{1}", endTime.Right(4).Left(2), endTime.Right(2));
            }
            else {
                endTime = string.Empty;
            }

            GetStartEndDate(airCreationDate, startDateTime, endDateTime, ref startDate, ref endDate);

            if (processPickupDropoff) {
                string pickupElement = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None)[2];
                string dropoffElement = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None)[1];

                startDetails = pickupElement.Split(';')[0];
                endDetails = dropoffElement.Split(';')[0];
            }

            decimal localAmount = 0;
            decimal foreignAmount = 0;
            decimal rateAmount = 0;

            string localCurrencyCode = AppSettings.Setting(customerId).CurrencyCode;
            string foreignCurrencyCode = string.Empty;

            int index = 0;

            string[] pricingParts = null;
            string[] parts = null;

            if (rateElement.Contains("ES-") || rateElement.Contains("RG-") || rateElement.Contains("RQ-")) {
                string pricingPart = string.Empty;
                string ratePart = string.Empty;
                string prefix = string.Empty;

                pricingParts = rateElement.Split(';');
                index = pricingParts.FindIndex(t => t.StartsWith("ES-") && t != "ES-");

                if (index >= 0) {
                    prefix = "ES-";
                    pricingPart = pricingParts[index].TrimStart("ES-");
                    serviceTypeRateBasis = ServiceTypeRateBasisBase.TransportPackage;
                }

                index = pricingParts.FindIndex(t => t.StartsWith("RG-") && t != "RG-");

                if (index >= 0) {
                    prefix = "RG-";
                    ratePart = pricingParts[index].TrimStart("RG-");

                    if (pricingPart.Length == 0)
                        pricingPart = ratePart;
                }
                else {
                    index = pricingParts.FindIndex(t => t.StartsWith("RQ-") && t != "RQ-");

                    if (index >= 0) {
                        prefix = "RQ-";
                        ratePart = pricingParts[index].TrimStart("RQ-");

                        if (pricingPart.Length == 0)
                            pricingPart = ratePart;
                    }
                }

                if (pricingPart.Length > 3) {
                    parts = pricingPart.Split('*');
                    pricingPart = parts[parts.Length - 1];

                    foreignCurrencyCode = pricingPart.Left(3);

                    if (pricingPart.Contains('+')) {
                        parts = pricingPart.Substring(3).Split('+');
                    }
                    else {
                        parts = pricingPart.Substring(3).Split(' ');
                    }

                    if (parts.Length > 0 && parts[0].Length > 0) {
                        decimal.TryParse(parts[0].GetDigits(), out foreignAmount);
                        foreignAmount /= 100;
                    }

                    exchangeRate = GetExchangeRate(lazyContext, customerId, amadeusSegment, foreignCurrencyCode);
                    localAmount = exchangeRate == 0 ? 0 : foreignAmount / exchangeRate;
                }

                parts = ratePart.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);

                if (parts.Length > 0 && parts[0].Length > 0) {
                    decimal.TryParse(parts[0].GetDigits(), out rateAmount);
                    rateAmount /= 100;
                }
            }

            index = textParts.FindIndex(t => t.StartsWith("TAX-"));

            if (index > 0) {
                pricingParts = textParts[index].TrimStart("TAX-").Split(';');

                if (pricingParts.Length > 3 && pricingParts[0].Length > 0) {
                    decimal.TryParse(pricingParts[0], out nonCommissionable);

                    if (pricingParts[1] == "PERCENT")
                        nonCommissionable = localAmount * nonCommissionable / 100;

                    if (pricingParts[3] == "I")
                        localAmount -= nonCommissionable;
                }
            }

            currencyId = Currency.GetCurrency(lazyContext, foreignCurrencyCode).Id;
            paxAdultRate = localAmount;

            string[] startAddress = textLine.Value.Split(new string[] { "PUP-" }, StringSplitOptions.None)[1].Split('*');
            string[] endAddress = textLine.Value.Split(new string[] { "DO-" }, StringSplitOptions.None)[1].Split('*');

            if (startAddress[0].Length == 3) {
                startLocality = startAddress[0];
                var city = City.GetCity(lazyContext, startLocality);

                if (city.Id > 0) {
                    startLocality = city.Name;
                    startCountryCode = city.Country.Code;
                }
            }

            if (startAddress.Length > 1) {
                startAddress = startAddress[1].Split(';')[0].Split(',');
                startAddress1 = startAddress[0].Trim();

                if (startAddress.Length > 1)
                    startAddress2 = string.Join(", ", startAddress[1].Trim());
            }

            if (endAddress[0].Length == 3) {
                endLocality = endAddress[0];
                var city = City.GetCity(lazyContext, endLocality);

                if (city.Id > 0) {
                    endLocality = city.Name;
                    endCountryCode = city.Country.Code;
                }
            }

            if (endAddress.Length > 1) {
                endAddress = endAddress[1].Split(';')[0].Split(',');
                endAddress1 = endAddress[0].Trim();

                if (endAddress.Length > 1)
                    endAddress2 = string.Join(", ", endAddress[1].Trim());
            }

            textParts = textLine.Value.Split(amadeusSegment.SegmentParts, StringSplitOptions.None);
            string element = textParts.FirstOrDefault(t1 => t1.Split(';').Any(t2 => t2 == "BAG-" || t2 == "BOO-" || t2 == "DRS-" || t2 == "GRP-" || t2 == "SEA-"));

            if (element != null)
                serviceDescription = element.Split(';')[0].Trim();

            duration = Common.GetDuration(amadeusSegment.TripLineType, startDate, endDate, durationCoverageType);
            int rateDuration;

            if (serviceTypeRateBasis == ServiceTypeRateBasisBase.TransportPerDay) {
                rateDuration = duration;
            }
            else {
                rateDuration = 1;
            }

            foreignAmountTotal = Math.Round(foreignAmount * rateDuration, 2);

            inclusions = GetInclusions(customerId, textLine, localCurrencyCode, foreignCurrencyCode, localAmount, foreignAmount * rateDuration, rateAmount, rateDuration);
            comments = GetComments(customerId, textLine, localCurrencyCode, foreignCurrencyCode, localAmount, foreignAmount * rateDuration, rateAmount, rateDuration);
        }

        private static void GetAutoTourSegmentInfo(int customerId, TextLineModel textLine, string[] textParts, DateTime airCreationDate, ref DurationCoverageType durationCoverageType,
            ref ServiceTypeRateBasisBase serviceTypeRateBasis, ref DateTime startDate, ref DateTime endDate, ref string startTime, ref string endTime, ref string bookingStatus, ref string supplierCrsCode,
            ref string confirmationNo, ref int paxAdultNo, ref string inclusions, ref string comments) {

            var amadeusSegment = textLine.AmadeusSegment;

            durationCoverageType = DurationCoverageType.Days;
            serviceTypeRateBasis = ServiceTypeRateBasisBase.TourPerTour;

            supplierCrsCode = textParts[5];
            bookingStatus = textParts[1].Substring(10, 2);
            paxAdultNo = int.Parse(textParts[1].Right(2));
            confirmationNo = textParts.FirstOrDefault(t => t.StartsWith("CF-"))?.TrimStart("CF-") ?? string.Empty;

            string startDateTime = textParts[2].Substring(5, 7);
            string endDateTime = textParts[2].Right(5);

            if (endDateTime.Length >= 9)
                startTime = string.Concat(startDateTime.Substring(5, 2), ":", startDateTime.Right(2));

            if (endDateTime.Length >= 9)
                endTime = string.Concat(endDateTime.Substring(5, 2), ":", endDateTime.Right(2));

            GetStartEndDate(airCreationDate, startDateTime, endDateTime, ref startDate, ref endDate);

            inclusions = GetInclusions(customerId, textLine);
            comments = GetComments(customerId, textLine);
        }

        private static void GetDirectAccessHotelSegmentInfo(AppLazyContext lazyContext, int customerId, TextLineModel textLine, string[] textParts, DateTime airCreationDate, ref DurationCoverageType durationCoverageType,
            ref ServiceTypeRateBasisBase serviceTypeRateBasis, ref DateTime startDate, ref DateTime endDate, ref string startTime, ref string endTime, ref int currencyId, ref decimal foreignAmountTotal,
            ref decimal exchangeRate, ref string bookingStatus, ref string supplierCrsCode, ref string confirmationNo, ref string supplierName, ref int paxAdultQty, ref decimal paxAdultRate,
            ref string inclusions, ref string comments) {

            var amadeusSegment = textLine.AmadeusSegment;
            decimal localAmount = decimal.Parse(textParts[7].Substring(3));

            string localCurrencyCode = textParts[7].Right(3);
            string foreignCurrencyCode = textParts[7].Left(3);

            currencyId = Currency.GetCurrency(lazyContext, foreignCurrencyCode).Id;

            durationCoverageType = DurationCoverageType.Nights;
            serviceTypeRateBasis = ServiceTypeRateBasisBase.AccommodationPerRoom;

            supplierCrsCode = textParts[1].Substring(7, 2);
            bookingStatus = textParts[1].Substring(10, 2);

            string startDateTime = textParts[2].Right(5);
            string endDateTime = textParts[3];

            if (endDateTime.Length >= 9)
                startTime = string.Concat(startDateTime.Substring(5, 2), ":", startDateTime.Right(2));

            if (endDateTime.Length >= 9)
                endTime = string.Concat(endDateTime.Substring(5, 2), ":", endDateTime.Right(2));

            GetStartEndDate(airCreationDate, startDateTime, endDateTime, ref startDate, ref endDate);

            supplierName = textParts[12];
            paxAdultQty = int.Parse(textParts[1].Right(2));
            confirmationNo = textParts.FirstOrDefault(t => t.StartsWith("CF-"))?.TrimStart("CF-") ?? string.Empty;

            inclusions = GetInclusions(customerId, textLine, localCurrencyCode, foreignCurrencyCode, localAmount);
            comments = GetComments(customerId, textLine, localCurrencyCode, foreignCurrencyCode, localAmount);

            exchangeRate = GetExchangeRate(lazyContext, customerId, amadeusSegment, foreignCurrencyCode, localAmount);
            foreignAmountTotal = Math.Round(localAmount * exchangeRate, 2);
            paxAdultRate = localAmount;
        }

        private static void GetManualLandSegmentInfo(int customerId, TextLineModel textLine, string[] textParts, DateTime airCreationDate, ref DurationCoverageType durationCoverageType,
            ref ServiceTypeRateBasisBase serviceTypeRateBasis, ref DateTime startDate, ref DateTime endDate, ref string startTime, ref string endTime, ref string bookingStatus, ref string supplierCrsCode,
            ref int paxAdultQty, ref string inclusions, ref string comments) {

            var amadeusSegment = textLine.AmadeusSegment;

            if (amadeusSegment.SegmentType == AmadeusSegmentType.ManualHotelSegment) {
                durationCoverageType = DurationCoverageType.Nights;
            }
            else {
                durationCoverageType = DurationCoverageType.Days;
            }

            serviceTypeRateBasis = ServiceTypeRateBasisBase.AccommodationPerRoom;

            supplierCrsCode = textParts[1].Substring(7, 2);
            bookingStatus = textParts[1].Substring(10, 2);
            paxAdultQty = int.Parse(textParts[1].Right(2));

            string startDateTime = textParts[2].Right(5);
            string endDateTime = textParts[3];

            if (endDateTime.Length >= 9)
                startTime = string.Concat(startDateTime.Substring(5, 2), ":", startDateTime.Right(2));

            if (endDateTime.Length >= 9)
                endTime = string.Concat(endDateTime.Substring(5, 2), ":", endDateTime.Right(2));

            GetStartEndDate(airCreationDate, startDateTime, endDateTime, ref startDate, ref endDate);

            inclusions = GetInclusions(customerId, textLine);
            comments = GetComments(customerId, textLine);
        }

        private static void GetTransportSegmentInfo(int customerId, TextLineModel textLine, string[] textParts, DateTime airCreationDate, ref DurationCoverageType durationCoverageType,
            ref ServiceTypeRateBasisBase serviceTypeRateBasis, ref DateTime startDate, ref DateTime endDate, ref string startTime, ref string endTime, ref string bookingStatus, ref string supplierCrsCode,
            ref int paxAdultNo, ref string inclusions, ref string comments) {

            durationCoverageType = DurationCoverageType.Days;
            serviceTypeRateBasis = ServiceTypeRateBasisBase.TransportPerDay;

            supplierCrsCode = textParts[1].Substring(7, 2);
            bookingStatus = textParts[1].Substring(10, 2);
            paxAdultNo = int.Parse(textParts[1].Right(2));

            string startDateTime = textParts[2].Right(5);
            string endDateTime = string.Empty;

            if (endDateTime.Length >= 9)
                startTime = string.Concat(startDateTime.Substring(5, 2), ":", startDateTime.Right(2));

            if (endDateTime.Length >= 9)
                endTime = string.Concat(endDateTime.Substring(5, 2), ":", endDateTime.Right(2));

            GetStartEndDate(airCreationDate, startDateTime, endDateTime, ref startDate, ref endDate);

            inclusions = GetInclusions(customerId, textLine);
            comments = GetComments(customerId, textLine);
        }

        private static void GetCruiseSegmentInfo(string[] textParts, DateTime airCreationDate, ref DurationCoverageType durationCoverageType, ref ServiceTypeRateBasisBase serviceTypeRateBasis,
            ref DateTime startDate, ref DateTime endDate, ref string startTime, ref string endTime, ref string bookingStatus) {

            durationCoverageType = DurationCoverageType.Days;
            serviceTypeRateBasis = ServiceTypeRateBasisBase.CruisePerPerson;
            bookingStatus = textParts[12].Left(2);

            startTime = textParts[11].Substring(5, 4);

            if (textParts[11].Substring(9, 1) == "P")
                startTime = string.Format("0{0}", startTime.ToInt() + 12).Right(4);

            startTime = string.Format("{0}:{1}", startTime.Right(4).Left(2), startTime.Right(2));
            string startDateTime = string.Concat(textParts[11].Left(5), startTime);

            endTime = textParts[11].Substring(10, 4);

            if (textParts[11].Substring(14, 1) == "P")
                endTime = string.Format("0{0}", endTime.ToInt() + 12).Right(4);

            endTime = string.Format("{0}:{1}", endTime.Right(4).Left(2), endTime.Right(2));
            string endDateTime = string.Concat(textParts[11].Right(5), endTime);

            GetStartEndDate(airCreationDate, startDateTime, endDateTime, ref startDate, ref endDate);
        }

        private static void GetRailSegmentInfo(string[] textParts, DateTime airCreationDate, ref DurationCoverageType durationCoverageType, ref ServiceTypeRateBasisBase serviceTypeRateBasis,
            ref DateTime startDate, ref DateTime endDate, ref string bookingStatus, ref string startTime, ref string endTime) {

            durationCoverageType = DurationCoverageType.Days;
            serviceTypeRateBasis = ServiceTypeRateBasisBase.TransportPerDay;
            bookingStatus = textParts[12].Left(2);

            startTime = textParts[11].Substring(5, 4);

            if (textParts[11].Substring(9, 1) == "P")
                startTime = string.Format("0{0}", startTime.ToInt() + 12).Right(4);

            startTime = string.Format("{0}:{1}", startTime.Right(4).Left(2), startTime.Right(2));
            string startDateTime = string.Concat(textParts[11].Left(5), startTime);

            endTime = textParts[11].Substring(10, 4);

            if (textParts[11].Substring(14, 1) == "P")
                endTime = string.Format("0{0}", endTime.ToInt() + 12).Right(4);

            endTime = string.Format("{0}:{1}", endTime.Right(4).Left(2), endTime.Right(2));
            string endDateTime = string.Concat(textParts[11].Right(5), endTime);

            GetStartEndDate(airCreationDate, startDateTime, endDateTime, ref startDate, ref endDate);
        }
        #endregion

        #region Models
        private class TextLineModel {
            public int RowIndex { get; set; }
            public AmadeusSegmentModel AmadeusSegment { get; set; }
            public string Value { get; set; }
            public string EmdType { get; set; }
            public bool IsEmd { get; set; }
            public bool IsVoid { get; set; }
            public bool IsProcessed { get; set; }
            public decimal SeqNo { get; set; }
        }

        private class AirSegmentModel {
            private int CustomerId { get; }

            public AirSegmentModel(int customerId) {
                CustomerId = customerId;
                BspEntryType = BspEntryType.Ticket;
            }

            public int RowIndex { get; set; }
            public int PassengerIndex { get; set; }
            public string SegmentNo { get; set; }
            public string PassengerNo { get; set; }
            public string DepartureCityCode { get; set; }
            public string ArrivalCityCode { get; set; }
            public BspEntryType BspEntryType { get; set; }
            public string TicketNo { get; set; }
            public string OriginalTicketNo { get; set; }
            public string FareBasis { get; set; }
            public string TicketDesignator { get; set; }
            public string SeatNo { get; set; }
            public SeatStatus SeatStatus { get; set; }
            public int CurrencyId { get; set; }
            public string CurrencyCode { get; set; }
            public decimal ExchangeRate { get; set; }
            public decimal TicketedFare { get; set; }
            public decimal Amount { get; set; }
            public decimal Tax { get; set; }
            public decimal NonCommissionable { get; set; }
            public bool IsEmd { get; set; }
            public bool AccompaniedInfant { get; set; }
            public bool IsProcessed { get; set; }
            public bool IsForeignCurrency { get { return !string.IsNullOrEmpty(CurrencyCode) && CurrencyCode != AppSettings.Setting(CustomerId).CurrencyCode; } }
        }

        private class SegmentPassengerModel {
            public SegmentPassengerModel() {
                AirlineId = -1;
            }

            public string SegmentNo { get; set; }
            public string PassengerNo { get; set; }
            public DateTime IssueDate { get; set; }
            public int AirlineId { get; set; }
            public bool IsEmd { get; set; }
        }

        private class SegmentIndexModel {
            public int RowIndex { get; set; }
            public int PassengerIndex { get; set; }
            public int Skip { get; set; }
            public int Take { get; set; }
            public bool IsProcessed { get; set; }
        }

        private class AtfLineModel {
            public int RowIndex { get; set; }
            public int SegmentIndex { get; set; }
            public bool IsProcessed { get; set; }
        }

        private class QLineModel {
            public int RowIndex { get; set; }
            public string SegmentNo { get; set; }
            public bool IsProcessed { get; set; }
        }

        private class FareLineModel {
            public int RowIndex { get; set; }
            public string SegmentNo { get; set; }
            public List<PassengerIndexModel> PassengerIndexes { get; set; }
            public bool IsProcessed { get { return PassengerIndexes.All(t => t.IsProcessed); } }
        }

        private class FareBasisModel {
            public int Index { get; set; }
            public string FareBasis { get; set; }
            public string TicketDesignator { get; set; }
        }

        private class EmdLineModel {
            public string SegmentNo { get; set; }
            public string PassengerNo { get; set; }
            public decimal Amount { get; set; }
            public decimal NonCommissionable { get; set; }
            public string Segment { get; set; }
            public string Comment { get; set; }
        }

        private class TourCodeModel {
            public string SegmentNo { get; set; }
            public string PassengerNo { get; set; }
            public string TourCode { get; set; }
        }

        private class FormOfPaymentModel {
            public string SegmentNo { get; set; }
            public string PassengerNo { get; set; }
            public int FormOfPaymentId { get; set; }
        }

        private class PassengerClubMembershipModel {
            public string PassengerNo { get; set; }
            public int AirlineId { get; set; }
            public int ClubMembershipId { get; set; }
            public string ClubMembershipNo { get; set; }
        }

        private class PassengerIndexModel {
            public int Index { get; set; }
            public bool IsProcessed { get; set; }
        }

        private class AmadeusSegmentModel {
            public string AmadeusSegmentId { get; set; }
            public AmadeusSegmentType SegmentType { get; set; }
            public string[] SegmentParts { get; set; }
            public TripLineType TripLineType { get; set; }
        }

        private static List<AmadeusSegmentModel> AmadeusSegmentList {
            get {
                return new List<AmadeusSegmentModel> {
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = string.Empty,
                        SegmentType = AmadeusSegmentType.None,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.All
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "AIR",
                        SegmentType = AmadeusSegmentType.TicketedAirSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Air
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "AIR",
                        SegmentType = AmadeusSegmentType.UnticketedAirSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Air
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "AIR",
                        SegmentType = AmadeusSegmentType.UnticketedOpenSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Air
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "HHL",
                        SegmentType = AmadeusSegmentType.AutomatedHotelSegment,
                        SegmentParts = new string[] { "DLY", "TTL" },
                        TripLineType = TripLineType.Accommodation
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "HTL",
                        SegmentType = AmadeusSegmentType.ManualHotelSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Accommodation
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "HTL",
                        SegmentType = AmadeusSegmentType.DirectAccessHotelSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Accommodation
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "CCR",
                        SegmentType = AmadeusSegmentType.AutomatedCarSegment,
                        SegmentParts = new string[] { "RB-", "TAX-", "SI-", "SUR-", "COV-", "VEH-" },
                        TripLineType = TripLineType.Transport
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "CAR",
                        SegmentType = AmadeusSegmentType.ManualCarSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Transport
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "SUR",
                        SegmentType = AmadeusSegmentType.GroundTransportationSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Transport
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = string.Empty,
                        SegmentType = AmadeusSegmentType.UnticketedSurfaceSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Transport
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = string.Empty,
                        SegmentType = AmadeusSegmentType.UnticketedRailSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Transport
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "ATX",
                        SegmentType = AmadeusSegmentType.AirTaxiSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Transport
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "CRU",
                        SegmentType = AmadeusSegmentType.AutomatedCruiseSegment,
                        SegmentParts = new string[] { "DIN-", "INS-", "TSF-", "PAK-", "GFT-", "SSR-" },
                        TripLineType = TripLineType.Cruise
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "TTO",
                        SegmentType = AmadeusSegmentType.AutomatedTourSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Tour
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "TUR",
                        SegmentType = AmadeusSegmentType.ManualTourSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Tour
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "MIS",
                        SegmentType = AmadeusSegmentType.MiscellaneousSegment,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Remark
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "SSR",
                        SegmentType = AmadeusSegmentType.SpecialServiceRequest,
                        SegmentParts = new string[] { "/" },
                        TripLineType = TripLineType.Remark
                    },
                    new AmadeusSegmentModel {
                        AmadeusSegmentId = "EMD",
                        SegmentType = AmadeusSegmentType.Emd,
                        SegmentParts = new string[] { ";" },
                        TripLineType = TripLineType.Air
                    }
                };
            }
        }

        private enum AmadeusSegmentType {
            None = 0,
            TicketedAirSegment = 1,
            UnticketedAirSegment = 2,
            UnticketedOpenSegment = 3,
            AutomatedHotelSegment = 4,
            ManualHotelSegment = 5,
            DirectAccessHotelSegment = 6,
            AutomatedCarSegment = 7,
            ManualCarSegment = 8,
            GroundTransportationSegment = 9,
            UnticketedSurfaceSegment = 10,
            UnticketedRailSegment = 11,
            AirTaxiSegment = 12,
            AutomatedCruiseSegment = 13,
            AutomatedTourSegment = 14,
            ManualTourSegment = 15,
            MiscellaneousSegment = 16,
            SpecialServiceRequest = 17,
            Emd = 18
        }
    }
    #endregion
}