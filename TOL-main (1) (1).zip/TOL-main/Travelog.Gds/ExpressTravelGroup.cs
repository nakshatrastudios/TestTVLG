﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Enums;
using Travelog.Gds.Models;
using City = Travelog.Biz.Dao.Common.City;
using TripLineAir = Travelog.Gds.Models.TripLineAir;
using TripLineAirPassenger = Travelog.Gds.Models.TripLineAirPassenger;
using TripLineAirPassengerAirSegment = Travelog.Gds.Models.TripLineAirPassengerAirSegment;
using TripLineAirSegment = Travelog.Gds.Models.TripLineAirSegment;
using TripLineServiceFee = Travelog.Gds.Models.TripLineServiceFee;

namespace Travelog.Gds {
    public static class ExpressTravelGroup {
        public static async Task<bool> RefreshAccessTokenAsync() {
            string json = null;

            try {
                const string endpoint = "https://ticketapi.expresstickets.com.au/authenticate/refresh-token";

                using (var adminContext = new AppAdminContext(false)) {
                    var accessToken = adminContext.AppSetting.Find("EtgAccessToken");
                    var refreshToken = adminContext.AppSetting.Find("EtgRefreshToken");
                    var expiration = adminContext.AppSetting.Find("EtgAccessTokenExpiration");

                    var httpClient = new HttpClient();
                    SetHeaders(httpClient, new Uri(endpoint));

                    var request = new TokenRequestModel {
                        AccessToken = accessToken.Value,
                        RefreshToken = refreshToken.Value
                    };

                    var content = JsonSerializer.Serialize(request);
                    var data = new StringContent(content, Encoding.UTF8, "application/json");

                    using (var response = await httpClient.PostAsync(endpoint, data)) {
                        if (response.IsSuccessStatusCode) {
                            json = await response.Content.ReadAsStringAsync();
                            var result = JsonSerializer.Deserialize<TokenRequestModel>(json, JsonExtensionsBiz.JsonSerializerOptions());

                            CustomerSettings.EtgAccessToken = result.AccessToken;
                            CustomerSettings.EtgRefreshToken = result.RefreshToken;
                            CustomerSettings.EtgAccessTokenExpiration = Utils.GetIso8601DateTime(result.Expiration);

                            accessToken.Value = CustomerSettings.EtgAccessToken;
                            adminContext.Save(accessToken, false);

                            refreshToken.Value = CustomerSettings.EtgRefreshToken;
                            adminContext.Save(refreshToken, false);

                            expiration.Value = CustomerSettings.EtgAccessTokenExpiration.ToShortDateTimeStringExt();
                            adminContext.Save(expiration, false);
                        }
                        else {
                            string result = await response.Content.ReadAsStringAsync();
                            throw new InvalidOperationException(string.Format(@"Request failed with Status Code ""{0}"".{1}", response.StatusCode, string.IsNullOrEmpty(result) ? string.Empty : string.Format("{0}Errors: {1}.", Environment.NewLine, result)));
                        }
                    }
                }

                return true;
            }
            catch (Exception ex) {
                string error = ExceptionManagerBiz.Instance.GetErrorMessage("Travelog.Gds.ExpressTravelGroup", "RefreshAccessToken", ex);

                if (!string.IsNullOrEmpty(json))
                    error = string.Format("{1}{0}JSON Response:{0}{2}", Environment.NewLine, error, json);

                ExceptionManagerBiz.Instance.LogError(error);

                string subject = string.Format("{0} - Application Error", AppSettings.AppTitle);
                string body = string.Format(AppConstants.MailBody, WebUtility.HtmlEncode(error).Replace(Environment.NewLine, AppConstants.HtmlLineBreak));

                await Mail.Instance.SendMailAsync(AppSettings.EmailErrors, subject, body);
                return false;
            }
        }

        public static async Task<CrsModel> RetrievePnrAsync(AppLazyContext lazyContext, int customerId, CrsImportModel model) {
            model.Validate();
            model.EtgCrsPnrRef = model.EtgCrsPnrRef.ToUpper();

            const string endpoint = "https://ticketapi.expresstickets.com.au/ticket/byreloc";
            List<EtgModel> pnrList;

            var httpClient = new HttpClient();
            SetHeaders(httpClient, new Uri(endpoint), CustomerSettings.EtgAccessToken);

            var request = new {
                relocator = model.EtgCrsPnrRef
            };

            string content = JsonSerializer.Serialize(request);
            var data = new StringContent(content, Encoding.UTF8, "application/json");

            using (var response = await httpClient.PostAsync(endpoint, data)) {
                if (response.IsSuccessStatusCode) {
                    pnrList = await response.Content.ReadAsAsync<List<EtgModel>>();
                }
                else {
                    string result = await response.Content.ReadAsStringAsync();

                    if (response.StatusCode == HttpStatusCode.Unauthorized)
                        throw new CrsException(string.Format("Authorisation failed for PNR {0}.", model.EtgCrsPnrRef));

                    if (result.Contains("Error! Invalid Relocator", StringComparison.OrdinalIgnoreCase))
                        throw new CrsException(string.Format("ETG reports that PNR {0} is invalid.", model.EtgCrsPnrRef));

                    if (result.Contains("Error! Agent associated to this", StringComparison.OrdinalIgnoreCase))
                        throw new CrsException(string.Format("Agent associated with PNR {0} is not enabled.", model.EtgCrsPnrRef));

                    throw new InvalidOperationException(string.Format(@"Request failed with Status Code ""{0}"".{1}", response.StatusCode, string.IsNullOrEmpty(result) ? string.Empty : string.Format("{0}Errors: {1}.", Environment.NewLine, result)));
                }
            }

            var passenger = pnrList.Select(t => t.Passenger).FirstOrDefault(t => Biz.Dao.ClientLedger.Passenger.GetPassengerType(t.PaxType) == PassengerType.Adult) ?? pnrList.FirstOrDefault()?.Passenger;

            var crsModel = new CrsModel {
                Crs = Crs.ExpressTravelGroup,
                CrsPnrRef = model.EtgCrsPnrRef,
                ClientDetail = passenger.GetClientDetail(lazyContext, model),
                PassengerList = pnrList.GetPassengerList(lazyContext, model)
            };

            crsModel.TripLineAirList = pnrList.GetTripLineAirList(lazyContext, customerId, model, crsModel.PassengerList);
            crsModel.TripLineServiceFeeList = pnrList.GetTripLineServiceFeeList(lazyContext, customerId);

            if (crsModel.ClientDetail.CurrencyId <= 0)
                crsModel.ClientDetail.CurrencyId = AppSettings.Setting(customerId).CurrencyId;

            return crsModel;
        }

        private static ClientDetail GetClientDetail(this Passenger passenger, AppLazyContext lazyContext, CrsImportModel model) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            var clientDetail = new ClientDetail {
                TripId = model.CrsTripId,
                ProfileId = model.CrsProfileId,
                Address1 = string.Empty,
                Address2 = string.Empty,
                Locality = string.Empty,
                Region = string.Empty,
                PostCode = string.Empty,
                CountryCode = string.Empty,
                Title = passenger == null ? string.Empty : textInfo.ToTitleCase(lazyContext.ContactTitle.SingleOrDefault(t => t.Name.ToLower() == passenger.Title.ToLower())?.Name ?? string.Empty),
                FirstName = passenger == null ? string.Empty : textInfo.ToTitleCase(passenger.FirstName.ToLower()),
                LastName = passenger == null ? string.Empty : textInfo.ToTitleCase(passenger.Surname.ToLower()),
                PhoneHome = string.Empty,
                PhoneWork = string.Empty,
                Mobile = string.Empty,
                Fax = string.Empty,
                Email = string.Empty,
                PaxAdult = 0,
                PaxChild = 0,
                PaxInfant = 0,
                DepartureDate = DateTime.MinValue,
                BalanceDueDate = DateTime.MinValue,
                ConsultantId = -1,
                AgencyId = model.CrsAgencyId,
                CurrencyId = -1
            };

            return clientDetail;
        }

        private static List<Models.Passenger> GetPassengerList(this List<EtgModel> pnrList, AppLazyContext lazyContext, CrsImportModel model) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;
            var passengerList = new List<Models.Passenger>();

            foreach (var pnr in pnrList) {
                var crsKey = GetPassengerCrsKey(pnr.Passenger, model);
                bool isDuplicate = passengerList.Any(t => t.CrsKey == crsKey);

                DateTime.TryParse(pnr.Passenger.DateOfBirth, out DateTime birthDate);

                passengerList.Add(new Models.Passenger {
                    EtgTicketId = pnr.Id,
                    EtgTransactionType = pnr.TranType,
                    CrsKey = crsKey,
                    PassengerType = Biz.Dao.ClientLedger.Passenger.GetPassengerType(pnr.Passenger.PaxType),
                    Title = textInfo.ToTitleCase(lazyContext.ContactTitle.SingleOrDefault(t => t.Name.ToLower() == pnr.Passenger.Title.ToLower())?.Name ?? string.Empty),
                    FirstName = textInfo.ToTitleCase(pnr.Passenger.FirstName.ToLower()),
                    LastName = textInfo.ToTitleCase(pnr.Passenger.Surname.ToLower()),
                    Email = string.Empty,
                    BirthDate = birthDate,
                    Age = pnr.Passenger.Age,
                    Gender = Gender.NotSpecified,
                    AirPrice = 0,
                    LandPrice = 0,
                    InsurancePrice = 0,
                    TotalPrice = 0,
                    IsDuplicate = isDuplicate
                });
            }

            return passengerList;
        }

        private static List<TripLineAir> GetTripLineAirList(this List<EtgModel> pnrList, AppLazyContext lazyContext, int customerId, CrsImportModel model, IEnumerable<Models.Passenger> passengerList) {
            string platedCarrier = pnrList.FirstOrDefault(t => !string.IsNullOrEmpty(t.PlatedCarrier))?.PlatedCarrier;
            int airlineId = Airline.GetAirline(lazyContext, platedCarrier).Id;

            var tripLineAirList = new List<TripLineAir> {
                new TripLineAir {
                    CrsRefId = 1,
                    ValidUntilDate = DateTime.MinValue,
                    AirlineId = airlineId,
                    CrsPnrRef = model.EtgCrsPnrRef
                }
            };

            var tripLineAir = tripLineAirList[0];

            tripLineAir.TripLineAirSegmentList = pnrList.GetTripLineAirSegmentList(lazyContext);
            tripLineAir.TripLineAirPassengerList = pnrList.GetTripLineAirPassengerList(lazyContext, customerId, model, tripLineAir, passengerList);

            if (airlineId == -1 && tripLineAir.TripLineAirPassengerList.Count > 0)
                tripLineAir.AirlineId = tripLineAir.TripLineAirPassengerList[0].AirlineId;

            return tripLineAirList;
        }

        private static List<TripLineAirSegment> GetTripLineAirSegmentList(this List<EtgModel> pnrList, AppLazyContext lazyContext) {
            var tripLineAirSegmentList = new List<TripLineAirSegment>();

            foreach (var pnr in pnrList) {
                foreach (var sector in pnr.Sectors) {
                    var tripLineAirSegment = tripLineAirSegmentList.SingleOrDefault(t => t.CrsKey == sector.GetAirSegmentCrsKey());

                    if (tripLineAirSegment != null) {
                        if (!tripLineAirSegment.EtgTicketIds.Contains(sector.TicketsId))
                            tripLineAirSegment.EtgTicketIds.Add(sector.TicketsId);

                        continue;
                    }

                    var departureCity = City.GetCity(lazyContext, sector.Origin);
                    var arrivalCity = City.GetCity(lazyContext, sector.Destination);

                    var airportType = pnr.IsInternational ? AirportType.International : AirportType.Domestic;

                    int days = int.Parse(sector.ArrivalDay) - int.Parse(sector.DepartureDay);
                    Enum.TryParse(days.ToStringExt(), out InternationalDateOffset internationalDateOffset);

                    tripLineAirSegmentList.Add(new TripLineAirSegment {
                        CrsKey = sector.GetAirSegmentCrsKey(),
                        TripStatus = Trip.GetTripStatus(sector.StatusCode?.Trim()),
                        DepartureCityId = departureCity.Id,
                        ArrivalCityId = arrivalCity.Id,
                        DepartureCityCode = departureCity.Code,
                        ArrivalCityCode = arrivalCity.Code,
                        Class = sector.BookingClass,
                        FlightNo = string.Format("{0}{1}", sector.Carrier, sector.FlightNumber),
                        CheckInTime = string.Empty,
                        DepartureDate = DateTime.Parse(sector.DepartureDate),
                        DepartureTime = string.IsNullOrEmpty(sector.DepartureTime) ? string.Empty : string.Format("{0}:{1}", sector.DepartureTime.Left(2), sector.DepartureTime.Right(2)),
                        ArrivalDate = DateTime.Parse(sector.ArrivalDate),
                        ArrivalTime = string.IsNullOrEmpty(sector.ArrivalTime) ? string.Empty : string.Format("{0}:{1}", sector.ArrivalTime.Left(2), sector.ArrivalTime.Right(2)),
                        FlightTime = string.Empty,
                        InternationalDateOffset = internationalDateOffset,
                        AirportType = airportType,
                        DepartureTerminal = sector.OriginTerminal?.TrimStart("TERMINAL ") ?? string.Empty,
                        ArrivalTerminal = sector.DestinationTerminal?.TrimStart("TERMINAL ") ?? string.Empty,
                        AirlinePnr = sector.AirlineReloc,
                        AircraftId = -1,
                        Operator = Airline.GetAirline(lazyContext, sector.Carrier).Name.Replace("Not Specified", string.Empty),
                        DistanceFlownKm = 0,
                        CO2Emissions = 0,
                        Meals = string.Empty,
                        TransitStops = string.Empty,
                        SeqNo = sector.SectorNum
                    });

                    tripLineAirSegment = tripLineAirSegmentList.Last();

                    if (!tripLineAirSegment.EtgTicketIds.Contains(sector.TicketsId))
                        tripLineAirSegment.EtgTicketIds.Add(sector.TicketsId);
                }
            }

            return tripLineAirSegmentList;
        }

        private static List<TripLineAirPassenger> GetTripLineAirPassengerList(this List<EtgModel> pnrList, AppLazyContext lazyContext, int customerId, CrsImportModel model, TripLineAir tripLineAir, IEnumerable<Models.Passenger> passengerList) {
            var tripLineAirPassengerList = new List<TripLineAirPassenger>();

            foreach (var passenger in passengerList.OrderBy(t => t.EtgTransactionType == "EMD" ? 1 : 0).ToList()) {
                var q = tripLineAir.TripLineAirSegmentList.Where(t => t.EtgTicketIds.Contains(passenger.EtgTicketId)).ToList();

                if (q.Count == 0) {
                    q = new List<TripLineAirSegment> {
                        new TripLineAirSegment {
                            EtgTicketIds = new List<int> { passenger.EtgTicketId },
                            ArrivalCityId = 0,
                            ArrivalCityCode = "???",
                            DepartureCityId = 0,
                            DepartureCityCode = "???",
                            AircraftId = -1
                        }
                    };
                }

                if (passenger.EtgTransactionType == "EMD") {
                    foreach (var pnr in pnrList.Where(t => t.Passenger.GetPassengerCrsKey(model) == passenger.CrsKey && t.TranType == "EMD" && t.Emd.Length > 0)) {
                        foreach (var emd in pnr.Emd) {
                            if (tripLineAirPassengerList.Any(t => t.EtgTicketId == emd.TicketsId))
                                continue;

                            int saleTypeId = 0;

                            if (pnr.IsInternational) {
                                saleTypeId = AppSettings.Setting(customerId).CrsInternationalAirSaleTypeId;
                            }
                            else {
                                saleTypeId = AppSettings.Setting(customerId).CrsDomesticAirSaleTypeId;
                            }

                            var tripLineAirPassenger = new TripLineAirPassenger {
                                EtgTicketId = emd.TicketsId,
                                CrsPassengerKey = passenger.CrsKey,
                                CreditorId = model.CrsCreditorAirId,
                                SupplierId = model.CrsSupplierAirId,
                                AirlineId = -1,
                                SaleTypeId = saleTypeId,
                                FormOfPaymentId = FormOfPayment.GetFormOfPayment(lazyContext, Crs.ExpressTravelGroup, pnr.FormOfPayment).Id,
                                IssueDate = emd.ServiceDate == null ? DateTime.MinValue : DateTime.Parse(emd.ServiceDate),
                                TicketNo = pnr.TicketNumber ?? string.Empty,
                                ConnectingTicketNos = emd.ConnectingTicketNumber.Length > 0 && tripLineAirPassengerList.Any(t => t.TicketNo.EndsWith(emd.ConnectingTicketNumber)) ? tripLineAirPassengerList.First(t => t.TicketNo.EndsWith(emd.ConnectingTicketNumber)).TicketNo : emd.ConnectingTicketNumber ?? string.Empty,
                                Comments = pnr.GetEmdDetails(),
                                TripLineAirPassengerAirSegmentList = new List<TripLineAirPassengerAirSegment> {
                                    new TripLineAirPassengerAirSegment {
                                        EtgTicketId = emd.TicketsId,
                                        CrsAirSegmentKey = string.Empty,
                                        CrsPassengerKey = passenger.CrsKey,
                                        DepartureCityCode = string.Empty,
                                        ArrivalCityCode = string.Empty,
                                        TicketMethod = TicketMethod.ETicket,
                                        TicketedFare = pnr.Fare.CashFare + pnr.Fare.CashTax + pnr.Fare.CreditFare + pnr.Fare.CreditTax,
                                        Amount = pnr.Fare.CashFare + pnr.Fare.CashTax + pnr.Fare.CreditFare + pnr.Fare.CreditTax,
                                        Tax = pnr.Fare.CashTax + pnr.Fare.CreditTax,
                                        NonCommissionable = pnr.Fare.ServiceFee + pnr.Fare.GstOnServiceFee,
                                        IsEmd = true
                                    }
                                }
                            };

                            tripLineAirPassengerList.Add(tripLineAirPassenger);
                        }
                    }
                }
                else {
                    var pnr = pnrList.Single(t => t.Id == passenger.EtgTicketId);
                    int airSegmentIndex = -1;

                    foreach (var airSegment in q) {
                        airSegmentIndex++;
                        Sectors sector;

                        if (pnr.Sectors.Length == 0) {
                            sector = new Sectors {
                                TicketsId = passenger.EtgTicketId,
                                StatusCode = string.Empty,
                                Carrier = string.Empty,
                                FareBasis = string.Empty,
                                BaggageAllowance = string.Empty
                            };
                        }
                        else {
                            sector = pnr.Sectors.Where(t => airSegment.EtgTicketIds.Contains(t.TicketsId)).Skip(airSegmentIndex).Take(1).First();
                        }

                        var fare = pnr.Fare;
                        var taxes = pnr.Taxes;

                        int airlineId = Airline.GetAirline(lazyContext, sector.Carrier).Id;
                        int saleTypeId = 0;

                        if (pnr.IsInternational) {
                            saleTypeId = AppSettings.Setting(customerId).CrsInternationalAirSaleTypeId;
                        }
                        else {
                            saleTypeId = AppSettings.Setting(customerId).CrsDomesticAirSaleTypeId;
                        }

                        TripLineAirPassenger tripLineAirPassenger;

                        if (pnr.TranType == "REI") {
                            tripLineAirPassenger = tripLineAirPassengerList.SingleOrDefault(t => t.BspEntryType == BspEntryType.Exchange && t.EtgTicketId == sector.TicketsId && t.CrsPassengerKey == passenger.CrsKey && t.TicketNo == pnr.ExOrigTicketNumber);
                        }
                        else {
                            tripLineAirPassenger = tripLineAirPassengerList.SingleOrDefault(t => t.BspEntryType != BspEntryType.Exchange && t.EtgTicketId == sector.TicketsId && t.CrsPassengerKey == passenger.CrsKey);
                        }

                        if (tripLineAirPassenger == null) {
                            tripLineAirPassenger = new TripLineAirPassenger {
                                EtgTicketId = sector.TicketsId,
                                CrsPassengerKey = passenger.CrsKey,
                                CreditorId = model.CrsCreditorAirId,
                                SupplierId = model.CrsSupplierAirId,
                                AirlineId = airlineId,
                                SaleTypeId = saleTypeId,
                                FormOfPaymentId = FormOfPayment.GetFormOfPayment(lazyContext, Crs.ExpressTravelGroup, pnr.FormOfPayment).Id,
                                IssueDate = pnr.IssueDate == null ? DateTime.MinValue : DateTime.Parse(pnr.IssueDate),
                                TicketNo = pnr.TicketNumber ?? string.Empty,
                                OriginalTicketNo = pnr.ExOrigTicketNumber ?? string.Empty,
                                ConnectingTicketNos = string.Join("; ", pnr.Emd.Select(t => t.ConnectingTicketNumber).Distinct()).Left(256),
                                BspEntryType = pnr.TranType == "REI" ? BspEntryType.Exchange : BspEntryType.Ticket,
                                Comments = pnr.GetEmdDetails()
                            };

                            tripLineAirPassengerList.Add(tripLineAirPassenger);
                        }

                        if (airSegment.CrsKey == null || tripLineAirPassenger.TripLineAirPassengerAirSegmentList.Any(t => t.EtgTicketId == sector.TicketsId && t.CrsAirSegmentKey == airSegment.CrsKey && t.CrsPassengerKey == passenger.CrsKey && t.DepartureCityCode == airSegment.DepartureCityCode && t.ArrivalCityCode == airSegment.ArrivalCityCode))
                            continue;

                        decimal amount = Math.Round(fare.CashFare + fare.CreditFare, 2);
                        decimal commission = Math.Round(fare.TotalAgentCommAmt, 2);

                        decimal taxRate = 0;

                        if (lazyContext.SaleType.Find(saleTypeId).IsTaxApplicable)
                            taxRate = CustomerSettings.GetTaxRate(customerId, airSegment.DepartureDate);

                        decimal nonCommissionable = GetNonCommissionable(customerId, fare, taxes, taxRate);
                        decimal tax = GetLocalTax(customerId, taxes);

                        var baggageUnit = BaggageUnit.Piece;
                        string allowance = null;

                        if (sector.BaggageAllowance.Right(2) == "PC") {
                            allowance = sector.BaggageAllowance.Left(sector.BaggageAllowance.Length - 2);
                        }
                        else if (sector.BaggageAllowance.Right(2) == "K") {
                            baggageUnit = BaggageUnit.Kilogram;
                            allowance = sector.BaggageAllowance.Left(sector.BaggageAllowance.Length - 1);
                        }
                        else if (sector.BaggageAllowance.Right(2) == "P") {
                            baggageUnit = BaggageUnit.Pound;
                            allowance = sector.BaggageAllowance.Left(sector.BaggageAllowance.Length - 1);
                        }

                        int.TryParse(allowance, out int baggageAllowance);

                        tripLineAirPassenger.TripLineAirPassengerAirSegmentList.Add(new TripLineAirPassengerAirSegment {
                            EtgTicketId = sector.TicketsId,
                            CrsAirSegmentKey = airSegment.CrsKey,
                            CrsPassengerKey = tripLineAirPassenger.CrsPassengerKey,
                            DepartureCityCode = airSegment.DepartureCityCode,
                            ArrivalCityCode = airSegment.ArrivalCityCode,
                            SeatNo = string.Empty,
                            SeatStatus = Biz.Dao.ClientLedger.TripLineAirPassengerAirSegment.GetSeatStatus(sector.StatusCode.Trim()),
                            BaggageAllowance = baggageAllowance,
                            BaggageUnit = baggageUnit,
                            FareBasis = sector.FareBasis,
                            TicketDesignator = string.Empty,
                            TourCode = fare.TktTourCode,
                            TicketMethod = TicketMethod.ETicket,
                            TicketedFare = amount + tax,
                            Amount = amount + tax,
                            Tax = tax,
                            NonCommissionable = nonCommissionable,
                            Commission = commission
                        });
                    }
                }
            }

            return tripLineAirPassengerList;
        }

        private static List<TripLineServiceFee> GetTripLineServiceFeeList(this List<EtgModel> pnrList, AppLazyContext lazyContext, int customerId) {
            var tripLineServiceFeeList = new List<TripLineServiceFee>();

            int crsDomesticServiceFeeTypeId = AppSettings.Setting(customerId).CrsEtgDomesticServiceFeeTypeId;
            int crsInternationalServiceFeeTypeId = AppSettings.Setting(customerId).CrsEtgInternationalServiceFeeTypeId;

            decimal serviceFee = 0;
            string description = string.Empty;

            if (crsDomesticServiceFeeTypeId > 0) {
                serviceFee = pnrList.Where(t => !t.IsInternational).Sum(t => t.Fare?.ServiceFee + t.Fare?.GstOnServiceFee) ?? 0;

                if (serviceFee != 0) {
                    var q = lazyContext.ServiceFeeType.Find(crsDomesticServiceFeeTypeId);

                    if (q != null) {
                        tripLineServiceFeeList.Add(new TripLineServiceFee {
                            ServiceFeeTypeId = crsDomesticServiceFeeTypeId,
                            SaleTypeId = q.SaleTypeId,
                            FormOfPaymentId = -1,
                            ItemCost = serviceFee,
                            PaxNo = 1
                        });
                    }
                }
            }

            if (crsInternationalServiceFeeTypeId > 0) {
                serviceFee = pnrList.Where(t => t.IsInternational).Sum(t => t.Fare?.ServiceFee + t.Fare?.GstOnServiceFee) ?? 0;

                if (serviceFee != 0) {
                    var q = lazyContext.ServiceFeeType.Find(crsInternationalServiceFeeTypeId);

                    if (q != null) {
                        tripLineServiceFeeList.Add(new TripLineServiceFee {
                            ServiceFeeTypeId = crsInternationalServiceFeeTypeId,
                            SaleTypeId = q.SaleTypeId,
                            FormOfPaymentId = -1,
                            ItemCost = serviceFee,
                            PaxNo = 1
                        });
                    }
                }
            }

            return tripLineServiceFeeList;
        }

        private static string GetEmdDetails(this EtgModel pnr) {
            string emdDetails = string.Empty;

            foreach (var emd in pnr.Emd) {
                emdDetails += string.Format("EMD Type: {1}; Date: {2:d}; Coupon Value: {3}; Code: {4}-{5}; Issue Reason: {6}.{0}{0}", Environment.NewLine, emd.EMDType, DateTime.Parse(emd.ServiceDate), emd.CouponValue, emd.IssuanceCode, emd.IssuanceSubCode, emd.IssueReason);
            }

            return emdDetails.TrimEnd(Environment.NewLine.ToCharArray()).Left(1000);
        }

        private static string GetPassengerCrsKey(this Passenger passenger, CrsImportModel model) {
            return string.Concat(model.CrsProfileId, "¶", model.CrsTripId, "¶", passenger.PaxType, "¶", passenger.Title, "¶", passenger.FirstName, "¶", passenger.Surname, "¶", passenger.DateOfBirth, "¶", passenger.Age);
        }

        private static string GetAirSegmentCrsKey(this Sectors sector) {
            return string.Concat(sector.SectorNum, "¶", sector.Origin, "¶", sector.Destination);
        }

        private static string GetLocalTaxCode(int customerId) {
            return AppSettings.CrsLocalTaxCodes.ContainsKey(AppSettings.Setting(customerId).CountryCode) ? AppSettings.CrsLocalTaxCodes[AppSettings.Setting(customerId).CountryCode] : string.Empty;
        }

        private static decimal GetLocalTax(int customerId, Taxes[] taxes) {
            return taxes.Where(t => t.TaxCode.Contains(GetLocalTaxCode(customerId))).Sum(t => (decimal?)t.TaxAmount) ?? 0;
        }

        private static decimal GetValidatedLocalTax(int customerId, Fare fare, Taxes[] taxes, decimal taxRate) {
            decimal localTax = 0;

            if (taxes != null)
                localTax = GetLocalTax(customerId, taxes);

            if (localTax != 0 && taxRate != 0) {
                decimal tax = Math.Round((fare.CashFare + fare.CreditFare + fare.AirlineFee) * taxRate, 2);

                if (localTax >= tax + 0.02m || localTax <= tax - 0.02m)
                    localTax = tax;
            }

            return localTax;
        }

        private static decimal GetNonCommissionable(int customerId, Fare fare, Taxes[] taxes, decimal taxRate) {
            //decimal localTax = taxes.Where(t => t.TaxCode.Contains(GetLocalTaxCode(customerId))).Sum(t => (decimal?)t.TaxAmount) ?? 0;
            decimal localTax = GetValidatedLocalTax(customerId, fare, taxes, taxRate);
            return Math.Round(fare.CashTax + fare.CreditTax - localTax, 2);
        }

        private static void SetHeaders(HttpClient httpClient, Uri endpoint, string accessToken = null) {
            if (accessToken != null)
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            httpClient.BaseAddress = endpoint;
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        private class TokenRequestModel {
            public string AccessToken { get; set; }
            public string RefreshToken { get; set; }
            public string Expiration { get; set; }
        }

        private class EtgModel {
            public int EtgPnrListIndex { get; set; }
            public Passenger Passenger { get; set; }
            public Fare Fare { get; set; }
            public Taxes[] Taxes { get; set; }
            public Sectors[] Sectors { get; set; }
            public Emd[] Emd { get; set; }
            public int Id { get; set; }
            public string TranType { get; set; }
            public string TicketNumber { get; set; }
            public string Relocator { get; set; }
            public string AgencyName { get; set; }
            public int AccountCode { get; set; }
            public string IssueDate { get; set; }
            public string PlatedCarrier { get; set; }
            public string Origin { get; set; }
            public string Destination { get; set; }
            public string IssuingApplication { get; set; }
            public bool IsInternational { get; set; }
            public string AirlineName { get; set; }
            public string IssuedByStaffUserName { get; set; }
            public string IssuedByStaffFullName { get; set; }
            public string FormOfPayment { get; set; }
            public bool Cancelled { get; set; }
            public string CancelledDate { get; set; }
            public string Refunded { get; set; }
            public string ExTicketNumber { get; set; }
            public string ExOrigTicketNumber { get; set; }
        }

        private class Passenger {
            public string Surname { get; set; }
            public string FirstName { get; set; }
            public string Title { get; set; }
            public string PaxType { get; set; }
            public string DateOfBirth { get; set; }
            public int Age { get; set; }
        }

        private class Fare {
            public decimal TotalAgentCommAmt { get; set; }
            public decimal CashFare { get; set; }
            public decimal CreditFare { get; set; }
            public decimal CashTax { get; set; }
            public decimal CreditTax { get; set; }
            public decimal ServiceFee { get; set; }
            public decimal GstOnServiceFee { get; set; }
            public decimal GstOnCommission { get; set; }
            public decimal AirlineFee { get; set; }
            public string TktTourCode { get; set; }
        }

        private class Taxes {
            public string TaxCode { get; set; }
            public decimal TaxAmount { get; set; }
        }

        private class Sectors {
            public int SectorNum { get; set; }
            public int TicketsId { get; set; }
            public string Carrier { get; set; }
            public string FlightNumber { get; set; }
            public string Origin { get; set; }
            public string Destination { get; set; }
            public string OriginCityName { get; set; }
            public string OriginTerminal { get; set; }
            public string DestinationCityName { get; set; }
            public string DestinationTerminal { get; set; }
            public string BookingClass { get; set; }
            public string ArrivalDate { get; set; }
            public string ArrivalTime { get; set; }
            public string ArrivalDay { get; set; }
            public string DepartureDate { get; set; }
            public string DepartureTime { get; set; }
            public string DepartureDay { get; set; }
            public string StatusCode { get; set; }
            public string BaggageAllowance { get; set; }
            public string FareBasis { get; set; }
            public string NotValidAfter { get; set; }
            public string NotValidBefore { get; set; }
            public string AirlineReloc { get; set; }
            public bool TurnAround { get; set; }
        }

        private class Emd {
            public int TicketsId { get; set; }
            public string ConnectingTicketNumber { get; set; }
            public string CouponValue { get; set; }
            public string IssuanceCode { get; set; }
            public string IssuanceSubCode { get; set; }
            public string IssueReason { get; set; }
            public string PresentTo { get; set; }
            public string ServiceCity { get; set; }
            public string ServiceCode { get; set; }
            public string ServiceDate { get; set; }
            public string ValidFor { get; set; }
            public string EMDType { get; set; }
        }
    }
}