﻿using System;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Enums;

namespace Travelog.Gds {
    internal static class Common {
        public static int GetDuration(TripLineType tripLineType, DateTime startDate, DateTime endDate, DurationCoverageType durationCoverageType) {
            var q = new TripLineLand {
                StartDate = startDate,
                EndDate = endDate,
                DurationCoverageType = durationCoverageType,
                TripLine = new TripLine {
                    TripLineType = tripLineType
                }
            };

            return q.GetDuration();
        }
    }
}
