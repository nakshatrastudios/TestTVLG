﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Enums;
using Travelog.Gds.Models;
using Travelog.Gds.Services.Calypso;
using Passenger = Travelog.Gds.Models.Passenger;
using TripLineAir = Travelog.Gds.Models.TripLineAir;
using TripLineAirPassenger = Travelog.Gds.Models.TripLineAirPassenger;
using TripLineAirPassengerAirSegment = Travelog.Gds.Models.TripLineAirPassengerAirSegment;
using TripLineAirSegment = Travelog.Gds.Models.TripLineAirSegment;
using TripLineLand = Travelog.Gds.Models.TripLineLand;

namespace Travelog.Gds {
    public static class Calypso {
        public static CrsModel RetrievePnr(AppLazyContext lazyContext, int customerId, CrsImportModel model) {
            model.Validate();

            if (model.CalypsoRemoveSpaces)
                model.CalypsoLastName = Utils.RemoveExtraSpaces(model.CalypsoLastName).Replace(" ", string.Empty);

            string bookingNo = model.CalypsoCrsPnrRef.ToUpper();

            var credentials = new CredentialsCT {
                Company = model.CalypsoCompany,
                BookingNumber = bookingNo,
                LastName = model.CalypsoLastName,
                Password = "9q2gf87u2j45"
            };

            var bookingDetailsCT = new GetBookingDetailsCT {
                BookingReference = new BookingReferenceCT {
                    Company = model.CalypsoCompany,
                    BookingNumber = bookingNo
                }
            };

            string remoteAddress;

            if (AppSettings.IsDevelopmentMode) {
                remoteAddress = AppSettings.Setting(customerId).CrsCalypsoSandboxUrl;
            }
            else {
                remoteAddress = "https://webservices.calypso.net.au:443/apps/csg/4/jtg/jtgCsgService";
            }

            using (var client = new CsgClient("CsgPort", remoteAddress)) {
                GetBookingDetailsRSCT booking;

                try {
                    booking = client.GetBookingDetails("Calypso", credentials, "12", bookingDetailsCT);
                }
                catch (Exception ex) {
                    if (ex.Message == "Invalid header" || ex.Message.Contains("BOOKF3_NOT_EXIST") || ex.Message.Contains("BKG_PAX_NOT_FOUND"))
                        throw new UnreportedException("Booking not found.");

                    if (ex.Message == "Invalid credentials")
                        throw new UnreportedException("Invalid credentials.");

                    if (ex.Message.StartsWith("There was no endpoint listening at", StringComparison.OrdinalIgnoreCase))
                        throw new CrsException("Connection cannot be made to remote server. Address was not found.", ex);

                    throw;
                }

                if (booking.Errors?.Length > 0)
                    throw new CrsException(string.Concat("Calypso errors: ", string.Join("; ", booking.Errors.Select(t => string.Concat(t.Code, ": ", t.Text)))));

                var bookingDetails = booking.BookingDetails;
                int agencyId = bookingDetails.Agency?.Name == null ? -1 : (lazyContext.Agency.SingleOrDefault(t => t.Name.ToLower() == bookingDetails.Agency.Name.ToLower()) ?? new Agency { Id = -1 }).Id;

                if (agencyId > 0)
                    model.CrsAgencyId = agencyId;

                int currencyId = bookingDetails.Company?.Currency?.Code == null ? -1 : Currency.GetCurrency(lazyContext, bookingDetails.Company.Currency.Code.ToLower()).Id;

                var crsModel = new CrsModel {
                    Crs = Crs.Calypso,
                    CrsPnrRef = string.Format("{0}{1}", bookingDetails.BookingReference.Company, bookingDetails.BookingReference.BookingNumber).ToUpper(),
                    ClientDetail = bookingDetails.GetClientDetail(lazyContext, model, currencyId),
                    PassengerList = bookingDetails.GetPassengerList(lazyContext)
                };

                int id = 1;
                crsModel.TripLineAirList = bookingDetails.GetTripLineAirList(lazyContext, customerId, model, ref id);

                id++;
                crsModel.TripLineLandList = bookingDetails.GetTripLineLandList(lazyContext, customerId, model.CrsCreditorLandId, currencyId, ref id);

                crsModel.TripLineAirList.ForEach(t => t.CrsRefId = 0);
                crsModel.TripLineLandList.ForEach(t => t.CrsRefId = 0);

                int airId = 0;
                int landId = 0;

                id = 1;

                foreach (var row in bookingDetails.Itinerary) {
                    if (row.Item.GetType() == typeof(ItineraryFlightCT)) {
                        var item = row.Item as ItineraryFlightCT;

                        if (crsModel.TripLineAirList.Count > airId && crsModel.TripLineAirList[airId].CrsRefId == 0 && crsModel.TripLineAirList[airId].AirlineCode == item.Sector.Carrier)
                            crsModel.TripLineAirList[airId].CrsRefId = id;

                        airId++;
                    }
                    else {
                        if (crsModel.TripLineLandList.Count > landId && crsModel.TripLineLandList[landId].CrsRefId == 0)
                            crsModel.TripLineLandList[landId].CrsRefId = id;

                        landId++;
                    }

                    id++;
                }

                return crsModel;
            }
        }

        private static ClientDetail GetClientDetail(this BookingDetailsCT bookingDetails, AppLazyContext lazyContext, CrsImportModel model, int currencyId) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            return new ClientDetail {
                TripId = model.CrsTripId,
                ProfileId = model.CrsProfileId,
                Address1 = bookingDetails.BookingContact?.Address?.Line1,
                Address2 = bookingDetails.BookingContact?.Address?.Line2,
                Locality = bookingDetails.BookingContact?.Address?.Line3,
                Title = bookingDetails.LeadPassenger?.Name?.Title == null ? string.Empty : lazyContext.ContactTitle.SingleOrDefault(t => t.Name.ToLower() == bookingDetails.LeadPassenger.Name.Title.ToLower())?.Name ?? string.Empty,
                FirstName = textInfo.ToTitleCase(bookingDetails.LeadPassenger?.Name?.FirstName?.ToLower() ?? string.Empty),
                LastName = textInfo.ToTitleCase(bookingDetails.LeadPassenger?.Name?.LastName?.ToLower() ?? string.Empty),
                PhoneHome = bookingDetails.BookingContact?.PhoneNumbers?.Home?.Value,
                PhoneWork = bookingDetails.BookingContact?.PhoneNumbers?.Work?.Value,
                Fax = bookingDetails.BookingContact?.PhoneNumbers?.Fax?.Value,
                Email = bookingDetails.BookingContact?.Email?.Address,
                PaxAdult = bookingDetails.BookingPassengers?.Count(t => t.Type == PassengerCTType.Adult) ?? 0,
                PaxChild = bookingDetails.BookingPassengers?.Count(t => t.Type == PassengerCTType.Child) ?? 0,
                PaxInfant = bookingDetails.BookingPassengers?.Count(t => t.Type == PassengerCTType.Infant) ?? 0,
                DepartureDate = bookingDetails.DepartureDate,
                BalanceDueDate = bookingDetails.PaymentSchedule?.BalanceDueDate ?? DateTime.MinValue,
                ConsultantId = bookingDetails.Agency?.Consultant?.Name == null ? -1 : (lazyContext.Consultant.SingleOrDefault(t => t.Name.ToLower() == bookingDetails.Agency.Consultant.Name.ToLower()) ?? new Consultant { Id = -1 }).Id,
                AgencyId = model.CrsAgencyId,
                CurrencyId = currencyId
            };
        }

        private static List<Passenger> GetPassengerList(this BookingDetailsCT bookingDetails, AppLazyContext lazyContext) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            var passengerList = bookingDetails.BookingPassengers.OrderBy(t => t.LeadPassenger ? 0 : 1).Select(row => new Passenger {
                CrsKey = row.PassengerNumber,
                PassengerType = row.Type == PassengerCTType.Adult ? PassengerType.Adult : row.Type == PassengerCTType.Child ? PassengerType.Child : PassengerType.Infant,
                Title = row.Name?.Title == null ? string.Empty : lazyContext.ContactTitle.SingleOrDefault(t => t.Name.ToLower() == row.Name.Title.ToLower())?.Name ?? string.Empty,
                FirstName = textInfo.ToTitleCase(row.Name?.FirstName?.ToLower() ?? string.Empty),
                LastName = textInfo.ToTitleCase(row.Name?.LastName?.ToLower() ?? string.Empty),
                PhoneNo = row.PhoneNumber,
                Email = row.Email,
                BirthDate = row.BirthDate,
                Age = row.Age.ToInt(),
                Gender = row.Gender == PassengerGenderST.Female ? Gender.Female : row.Gender == PassengerGenderST.Male ? Gender.Male : Gender.NotSpecified,
                AirPrice = row.Prices?.AirPrice?.Value ?? 0,
                LandPrice = row.Prices?.LandPrice?.Value ?? 0,
                InsurancePrice = row.Prices?.InsurancePrice?.Value ?? 0,
                TotalPrice = row.Prices?.TotalPrice?.Value ?? 0
            }).Where(t => t.FirstName.Length > 0 || t.LastName.Length > 0);

            return passengerList.OrderBy(t => t.Title.ToLower() == bookingDetails.LeadPassenger?.Name?.Title.ToLower() && t.FirstName.ToLower() == bookingDetails.LeadPassenger?.Name?.FirstName.ToLower() && t.LastName.ToLower() == bookingDetails.LeadPassenger?.Name?.LastName.ToLower() ? 0 : t.PassengerType == PassengerType.Infant ? 3 : t.PassengerType == PassengerType.Child ? 2 : 1).ToList();
        }

        private static List<TripLineAir> GetTripLineAirList(this BookingDetailsCT bookingDetails, AppLazyContext lazyContext, int customerId, CrsImportModel model, ref int id) {
            var tripLineAirList = new List<TripLineAir>();

            if (bookingDetails.AirBookings == null)
                return tripLineAirList;

            int tripLineAirId = id;

            foreach (var bookingDetail in bookingDetails.AirBookings) {
                var airSegmentList = bookingDetails.Itinerary.Where(t => t.Item.GetType() == typeof(ItineraryFlightCT)).Select(t => new { Item = t.Item as ItineraryFlightCT }).Where(t => t.Item.Sector.Carrier == bookingDetail.CarrierCode).ToArray();

                int airlineId = Airline.GetAirline(lazyContext, bookingDetail.CarrierCode).Id;
                int saleTypeId = 0;

                if (airSegmentList.All(t => City.GetCity(lazyContext, t.Item.Departs?.City?.Code).Country.CountryZone == CountryZone.Domestic && City.GetCity(lazyContext, t.Item.Arrives?.City?.Code).Country.CountryZone == CountryZone.Domestic)) {
                    saleTypeId = AppSettings.Setting(customerId).CrsDomesticAirSaleTypeId;
                }
                else {
                    saleTypeId = AppSettings.Setting(customerId).CrsInternationalAirSaleTypeId;
                }

                decimal taxRate = 0;

                if (lazyContext.SaleType.Find(saleTypeId).IsTaxApplicable)
                    taxRate = CustomerSettings.GetTaxRate(customerId, bookingDetails.QuoteDate);

                var airSegments = new List<ItineraryFlightCT>();

                var tripLineAir = new TripLineAir {
                    CrsRefId = tripLineAirId++,
                    ValidUntilDate = bookingDetail.TicketByDate,
                    AirlineId = airlineId,
                    AirlineCode = bookingDetail.CarrierCode,
                    CrsPnrRef = string.Format("{0}{1}", bookingDetails.BookingReference.Company, bookingDetails.BookingReference.BookingNumber).ToUpper(),
                    TripLineAirSegmentList = bookingDetails.GetTripLineAirSegmentList(lazyContext, customerId, bookingDetail.CarrierCode, airSegments)
                };

                foreach (var airSegment in airSegments) {
                    tripLineAir.TripLineAirPassengerList = airSegment.GetTripLineAirPassengerList(bookingDetail.TicketIndicator, model, airlineId, saleTypeId, taxRate);
                }

                tripLineAirList.Add(tripLineAir);
            }

            id = tripLineAirList.Max(t => (int?)t.CrsRefId) ?? 0;
            return tripLineAirList;
        }

        private static List<TripLineAirSegment> GetTripLineAirSegmentList(this BookingDetailsCT bookingDetails, AppLazyContext lazyContext, int customerId, string carrierCode, List<ItineraryFlightCT> airSegments) {
            var tripLineAirSegmentList = new List<TripLineAirSegment>();

            if (bookingDetails.Itinerary == null)
                return tripLineAirSegmentList;

            foreach (var airSegment in bookingDetails.Itinerary.Where(t => t.Item.GetType() == typeof(ItineraryFlightCT)).Select(t => new { Item = t.Item as ItineraryFlightCT }).Where(t => t.Item.Sector.Carrier == carrierCode)) {
                airSegments.Add(airSegment.Item);

                var departureCity = City.GetCity(lazyContext, airSegment.Item.Departs?.City?.Code);
                var arrivalCity = City.GetCity(lazyContext, airSegment.Item.Arrives?.City?.Code);

                var airportType = departureCity.Country.Code == AppSettings.Setting(customerId).CountryCode && arrivalCity.Country.Code == AppSettings.Setting(customerId).CountryCode ? AirportType.Domestic : AirportType.International;

                int days = (airSegment.Item.Arrives?.Date - airSegment.Item.Departs?.Date).Value.Days;
                Enum.TryParse(days.ToStringExt(), out InternationalDateOffset internationalDateOffset);

                tripLineAirSegmentList.Add(new TripLineAirSegment {
                    CrsKey = airSegment.Item.Sector.FlightNumber,
                    TripStatus = airSegment.Item.Status == ComponentInventoryStatusST.Confirmed ? TripStatus.Confirmed : airSegment.Item.Status == ComponentInventoryStatusST.OnRequest ? TripStatus.OnRequest : airSegment.Item.Status == ComponentInventoryStatusST.Waitlisted ? TripStatus.Waitlisted : airSegment.Item.Status == ComponentInventoryStatusST.Pending ? TripStatus.Pending : airSegment.Item.Status == ComponentInventoryStatusST.NotAvailable ? TripStatus.CannotConfirm : TripStatus.NotSpecified,
                    DepartureCityId = departureCity.Id,
                    ArrivalCityId = arrivalCity.Id,
                    Class = string.Empty,
                    FlightNo = string.Concat(airSegment.Item.Sector?.Carrier, airSegment.Item.Sector?.FlightNumber),
                    CheckInTime = string.Empty,
                    DepartureDate = airSegment.Item.Departs?.Date ?? DateTime.MinValue,
                    DepartureTime = airSegment.Item.Departs?.Time == null ? string.Empty : string.Format("{0:D2}:{1:D2}", airSegment.Item.Departs.Time.Hour, airSegment.Item.Departs.Time.Minute),
                    ArrivalDate = airSegment.Item.Arrives?.Date ?? DateTime.MinValue,
                    ArrivalTime = airSegment.Item.Arrives?.Time == null ? string.Empty : string.Format("{0:D2}:{1:D2}", airSegment.Item.Arrives.Time.Hour, airSegment.Item.Arrives.Time.Minute),
                    FlightTime = string.Empty,
                    InternationalDateOffset = internationalDateOffset,
                    AirportType = airportType,
                    DepartureTerminal = string.Empty,
                    ArrivalTerminal = string.Empty,
                    AirlinePnr = string.Empty,
                    AircraftId = -1,
                    Operator = Airline.GetAirline(lazyContext, airSegment.Item.Sector?.Carrier).Name.Replace("Not Specified", string.Empty),
                    DistanceFlownKm = 0,
                    CO2Emissions = 0,
                    Meals = string.Empty,
                    TransitStops = string.Empty
                });
            }

            return tripLineAirSegmentList;
        }

        private static List<TripLineAirPassenger> GetTripLineAirPassengerList(this ItineraryFlightCT airSegment, AirBookingCTTicketIndicator ticketIndicator, CrsImportModel model, int airlineId, int saleTypeId, decimal taxRate) {
            var tripLineAirPassengerList = new List<TripLineAirPassenger>();

            foreach (var row in airSegment.ComponentPassengers) {
                var tripLineAirPassenger = tripLineAirPassengerList.SingleOrDefault(t1 => t1.TripLineAirPassengerAirSegmentList.Any(t2 => t2.CrsAirSegmentKey == airSegment.Sector.FlightNumber));

                if (tripLineAirPassenger == null) {
                    tripLineAirPassenger = new TripLineAirPassenger {
                        CrsPassengerKey = row.PassengerNumber,
                        CreditorId = model.CrsCreditorAirId,
                        SupplierId = model.CrsSupplierAirId,
                        AirlineId = airlineId,
                        SaleTypeId = saleTypeId,
                        FormOfPaymentId = -1,
                        IssueDate = DateTime.MinValue,
                        TicketNo = string.Empty
                    };

                    tripLineAirPassengerList.Add(tripLineAirPassenger);
                }

                decimal amount = Math.Round(((airSegment.Amounts?.TotalPrice ?? 0) - (airSegment.Amounts?.TicketTaxes ?? 0)) / airSegment.ComponentPassengers.Length, 2);
                decimal tax = Math.Round(amount * taxRate, 2);
                decimal nonCommissionable = (airSegment.Amounts?.TicketTaxes ?? 0) / airSegment.ComponentPassengers.Length;
                decimal commission = airSegment.Amounts?.TotalPrice == null || airSegment.Amounts?.NettPrice == null ? 0 : (airSegment.Amounts.TotalPrice - airSegment.Amounts.NettPrice) / airSegment.ComponentPassengers.Length;

                amount -= tax;

                tripLineAirPassenger.TripLineAirPassengerAirSegmentList.Add(new TripLineAirPassengerAirSegment {
                    CrsAirSegmentKey = airSegment.Sector.FlightNumber,
                    CrsPassengerKey = tripLineAirPassenger.CrsPassengerKey,
                    DepartureCityCode = airSegment.Departs.City.Code,
                    ArrivalCityCode = airSegment.Arrives.City.Code,
                    SeatNo = string.Empty,
                    SeatStatus = SeatStatus.NotSpecified,
                    BaggageAllowance = 0,
                    BaggageUnit = BaggageUnit.Piece,
                    FareBasis = string.Empty,
                    TicketDesignator = string.Empty,
                    TourCode = string.Empty,
                    TicketedFare = amount + tax,
                    Amount = amount + tax,
                    Tax = tax,
                    NonCommissionable = nonCommissionable,
                    Commission = commission,
                    TicketMethod = ticketIndicator == AirBookingCTTicketIndicator.ETicket ? TicketMethod.ETicket : TicketMethod.Hand
                });
            }

            return tripLineAirPassengerList;
        }

        private static List<TripLineLand> GetTripLineLandList(this BookingDetailsCT bookingDetails, AppLazyContext lazyContext, int customerId, int creditorAgencyLandId, int currencyId, ref int id) {
            var tripLineLandList = new List<TripLineLand>();

            if (bookingDetails.Itinerary == null)
                return tripLineLandList;

            var textInfo = CultureInfo.CurrentCulture.TextInfo;
            int tripLineLandId = id;

            var serviceTypeRateBasis = ServiceTypeRateBasisBase.AccommodationPerPerson;
            var passengerClassification = PassengerClassification.Individual;

            int paxAdultNo = 0;
            int paxChildNo = 0;
            int paxInfantNo = 0;

            int paxAdultQty = 0;
            int paxChildQty = 0;
            int paxInfantQty = 0;

            decimal paxAdultRate = 0;
            decimal paxChildRate = 0;
            decimal paxInfantRate = 0;

            int duration = 0;
            decimal totalAmount = 0;

            string startAddress1 = string.Empty;
            string startLocality = string.Empty;
            string startRegion = string.Empty;

            string endAddress1 = string.Empty;
            string endLocality = string.Empty;
            string endRegion = string.Empty;

            foreach (var row in bookingDetails.Itinerary) {
                if (row.Item.GetType() == typeof(ItineraryHotelStayCT)) {
                    var item = row.Item as ItineraryHotelStayCT;

                    item.GetPaxValues(ref serviceTypeRateBasis, ref passengerClassification, ref duration, ref paxAdultNo, ref paxChildNo, ref paxInfantNo, ref paxAdultQty, ref paxChildQty, ref paxInfantQty, ref paxAdultRate, ref paxChildRate, ref paxInfantRate, ref totalAmount);
                    decimal foreignAmount = item.GetForeignAmount(lazyContext);

                    tripLineLandList.Add(new TripLineLand {
                        CrsRefId = tripLineLandId++,
                        TripLineType = TripLineType.Accommodation,
                        TripStatus = GetTripStatus(item.Status),
                        ConfirmationNo = string.Empty,
                        CreditorId = creditorAgencyLandId,
                        SupplierId = Supplier.GetSupplier(lazyContext, item?.Supplier?.Name ?? string.Empty).Id,
                        SupplierName = textInfo.ToTitleCase(item?.Supplier?.Name?.ToLower() ?? string.Empty),
                        SupplierChainId = -1,
                        SupplierCityCode = string.Empty,
                        SupplierCrsCode = item.Supplier?.Code ?? string.Empty,
                        SupplierAddress1 = textInfo.ToTitleCase(item?.Supplier?.Address?.Line1?.ToLower() ?? string.Empty),
                        SupplierAddress2 = string.Empty,
                        SupplierLocality = string.Format("{0} {1}", textInfo.ToTitleCase(item?.Supplier?.Address?.Line2?.ToLower() ?? string.Empty), textInfo.ToTitleCase(item?.Supplier?.Address?.Line3?.ToLower() ?? string.Empty)).Trim(),
                        SupplierRegion = item.Supplier?.City ?? string.Empty,
                        SupplierPostCode = string.Empty,
                        SupplierCountryCode = string.Empty,
                        SupplierContactPhoneWork = item.Supplier?.Phone ?? string.Empty,

                        StartDate = item.StayDetails?.CheckinDate ?? DateTime.MinValue,
                        StartTime = item.StayDetails?.CheckinDate.ToString("HH:mm") ?? string.Empty,
                        StartDetails = string.Empty,
                        StartAddress1 = string.Empty,
                        StartAddress2 = string.Empty,
                        StartLocality = string.Empty,
                        StartRegion = string.Empty,
                        StartPostCode = string.Empty,
                        StartCountryCode = string.Empty,
                        EndDate = item.StayDetails?.CheckoutDate ?? DateTime.MinValue,
                        EndTime = item.StayDetails?.CheckoutTime.ToString("HH:mm") ?? string.Empty,
                        EndDetails = string.Empty,
                        EndAddress1 = string.Empty,
                        EndAddress2 = string.Empty,
                        EndLocality = string.Empty,
                        EndRegion = string.Empty,
                        EndPostCode = string.Empty,
                        EndCountryCode = string.Empty,
                        SupplierServiceDescription = textInfo.ToTitleCase(item?.ProductGroup?.Description?.ToLower() ?? item?.ProductDetails?.Description?.ToLower() ?? string.Empty),
                        Inclusions = item.GetInclusions(paxAdultRate, totalAmount),
                        Comments = item.GetComments(row.ItineraryComment, paxAdultRate, totalAmount),

                        DurationCoverageType = DurationCoverageType.Nights,
                        Duration = duration,
                        PayForDuration = duration,
                        ServiceTypeRateBasis = serviceTypeRateBasis,
                        PassengerClassification = passengerClassification,

                        PaxAdultNo = paxAdultNo,
                        PaxAdultQty = paxAdultQty,
                        PaxAdultRate = paxAdultRate,
                        PaxChildNo = paxChildNo,
                        PaxChildQty = paxChildQty,
                        PaxChildRate = paxChildRate,
                        PaxInfantNo = paxInfantNo,
                        PaxInfantQty = paxInfantQty,
                        PaxInfantRate = paxInfantRate,

                        NonCommissionable = GetNonCommissionable(item.Amounts),
                        Commission = item.Amounts?.TotalPrice == null || item.Amounts?.NettPrice == null ? 0 : item.Amounts.TotalPrice - item.Amounts.NettPrice,
                        FormOfPaymentId = -1,
                        SaleTypeId = GetSaleTypeId(lazyContext, customerId, item.City, TripLineType.Accommodation),
                        CurrencyId = currencyId,
                        ForeignAmount = foreignAmount,
                        ExhangeRate = 1
                    });
                }
                else if (row.Item.GetType() == typeof(ItineraryCarRentalCT)) {
                    var item = row.Item as ItineraryCarRentalCT;

                    item.GetAddressDetails(ref startAddress1, ref startLocality, ref startRegion, ref endAddress1, ref endLocality, ref endRegion);
                    item.GetPaxValues(ref serviceTypeRateBasis, ref passengerClassification, ref duration, ref paxAdultNo, ref paxChildNo, ref paxInfantNo, ref paxAdultQty, ref paxChildQty, ref paxInfantQty, ref paxAdultRate, ref paxChildRate, ref paxInfantRate, ref totalAmount);

                    decimal foreignAmount = item.GetForeignAmount(lazyContext);

                    tripLineLandList.Add(new TripLineLand {
                        CrsRefId = tripLineLandId++,
                        TripLineType = TripLineType.Transport,
                        TripStatus = GetTripStatus(item.Status),
                        ConfirmationNo = string.Empty,
                        CreditorId = creditorAgencyLandId,
                        SupplierId = Supplier.GetSupplier(lazyContext, item?.Supplier?.Name ?? string.Empty).Id,
                        SupplierName = textInfo.ToTitleCase(item?.Supplier?.Name?.ToLower() ?? string.Empty),
                        SupplierChainId = -1,
                        SupplierCityCode = string.Empty,
                        SupplierCrsCode = item.Supplier?.Code ?? string.Empty,
                        SupplierAddress1 = textInfo.ToTitleCase(item.Supplier?.Address?.Line1 ?? string.Empty),
                        SupplierAddress2 = string.Empty,
                        SupplierLocality = string.Format("{0} {1}", textInfo.ToTitleCase(item.Supplier?.Address?.Line2 ?? string.Empty), textInfo.ToTitleCase(item.Supplier?.Address?.Line3 ?? string.Empty)).Trim(),
                        SupplierRegion = item.Supplier?.City ?? string.Empty,
                        SupplierPostCode = string.Empty,
                        SupplierCountryCode = string.Empty,
                        SupplierContactPhoneWork = item.Supplier?.Phone ?? string.Empty,

                        StartDate = item.PickUp?.Date ?? DateTime.MinValue,
                        StartTime = item.PickUp?.Time.ToString("HH:mm") ?? string.Empty,
                        StartDetails = string.Empty,
                        StartAddress1 = startAddress1,
                        StartAddress2 = string.Empty,
                        StartLocality = startLocality,
                        StartRegion = startRegion,
                        StartPostCode = string.Empty,
                        StartCountryCode = string.Empty,
                        EndDate = item.DropOff?.Date ?? DateTime.MinValue,
                        EndTime = item.DropOff?.Time.ToString("HH:mm") ?? string.Empty,
                        EndDetails = string.Empty,
                        EndAddress1 = endAddress1,
                        EndAddress2 = string.Empty,
                        EndLocality = endLocality,
                        EndRegion = endRegion,
                        EndPostCode = string.Empty,
                        EndCountryCode = string.Empty,
                        SupplierServiceDescription = textInfo.ToTitleCase(item?.ProductDetails?.Description?.ToLower() ?? string.Empty),
                        Inclusions = item.GetInclusions(paxAdultRate, totalAmount),
                        Comments = item.GetComments(row.ItineraryComment, paxAdultRate, totalAmount),

                        DurationCoverageType = DurationCoverageType.Days,
                        Duration = duration,
                        PayForDuration = duration,
                        ServiceTypeRateBasis = serviceTypeRateBasis,
                        PassengerClassification = passengerClassification,

                        PaxAdultNo = paxAdultNo,
                        PaxAdultQty = paxAdultQty,
                        PaxAdultRate = paxAdultRate,
                        PaxChildNo = paxChildNo,
                        PaxChildQty = paxChildQty,
                        PaxChildRate = paxChildRate,
                        PaxInfantNo = paxInfantNo,
                        PaxInfantQty = paxInfantQty,
                        PaxInfantRate = paxInfantRate,

                        NonCommissionable = GetNonCommissionable(item.Amounts),
                        Commission = item.Amounts?.TotalPrice == null || item.Amounts?.NettPrice == null ? 0 : item.Amounts.TotalPrice - item.Amounts.NettPrice,
                        FormOfPaymentId = -1,
                        SaleTypeId = GetSaleTypeId(lazyContext, customerId, item.PickUp.City, TripLineType.Transport),
                        CurrencyId = currencyId,
                        ForeignAmount = foreignAmount,
                        ExhangeRate = 1
                    });
                }
                else if (row.Item.GetType() == typeof(ItineraryVanRentalCT)) {
                    var item = row.Item as ItineraryVanRentalCT;

                    item.GetAddressDetails(ref startAddress1, ref startLocality, ref startRegion, ref endAddress1, ref endLocality, ref endRegion);
                    item.GetPaxValues(ref serviceTypeRateBasis, ref passengerClassification, ref duration, ref paxAdultNo, ref paxChildNo, ref paxInfantNo, ref paxAdultQty, ref paxChildQty, ref paxInfantQty, ref paxAdultRate, ref paxChildRate, ref paxInfantRate, ref totalAmount);

                    decimal foreignAmount = item.GetForeignAmount(lazyContext);

                    tripLineLandList.Add(new TripLineLand {
                        CrsRefId = tripLineLandId++,
                        TripLineType = TripLineType.Transport,
                        TripStatus = GetTripStatus(item.Status),
                        ConfirmationNo = string.Empty,
                        CreditorId = creditorAgencyLandId,
                        SupplierId = Supplier.GetSupplier(lazyContext, item?.Supplier?.Name ?? string.Empty).Id,
                        SupplierName = textInfo.ToTitleCase(item?.Supplier?.Name?.ToLower() ?? string.Empty),
                        SupplierChainId = -1,
                        SupplierCityCode = string.Empty,
                        SupplierCrsCode = item.Supplier?.Code ?? string.Empty,
                        SupplierAddress1 = textInfo.ToTitleCase(item.Supplier?.Address?.Line1 ?? string.Empty),
                        SupplierAddress2 = string.Empty,
                        SupplierLocality = string.Format("{0} {1}", textInfo.ToTitleCase(item.Supplier?.Address?.Line2 ?? string.Empty), textInfo.ToTitleCase(item.Supplier?.Address?.Line3 ?? string.Empty)).Trim(),
                        SupplierRegion = item.Supplier?.City ?? string.Empty,
                        SupplierPostCode = string.Empty,
                        SupplierCountryCode = string.Empty,
                        SupplierContactPhoneWork = item.Supplier?.Phone ?? string.Empty,

                        StartDate = item.PickUp?.Date ?? DateTime.MinValue,
                        StartTime = item.PickUp?.Time.ToString("HH:mm") ?? string.Empty,
                        StartDetails = string.Empty,
                        StartAddress1 = startAddress1,
                        StartAddress2 = string.Empty,
                        StartLocality = startLocality,
                        StartRegion = startRegion,
                        StartPostCode = string.Empty,
                        StartCountryCode = string.Empty,
                        EndDate = item.DropOff?.Date ?? DateTime.MinValue,
                        EndTime = item.DropOff?.Time.ToString("HH:mm") ?? string.Empty,
                        EndDetails = string.Empty,
                        EndAddress1 = endAddress1,
                        EndAddress2 = string.Empty,
                        EndLocality = endLocality,
                        EndRegion = endRegion,
                        EndPostCode = string.Empty,
                        EndCountryCode = string.Empty,
                        SupplierServiceDescription = textInfo.ToTitleCase(item?.ProductDetails?.Description?.ToLower() ?? string.Empty),
                        Inclusions = item.GetInclusions(paxAdultRate, totalAmount),
                        Comments = item.GetComments(row.ItineraryComment, paxAdultRate, totalAmount),

                        DurationCoverageType = DurationCoverageType.Days,
                        Duration = duration,
                        PayForDuration = duration,
                        ServiceTypeRateBasis = serviceTypeRateBasis,
                        PassengerClassification = passengerClassification,

                        PaxAdultNo = paxAdultNo,
                        PaxAdultQty = paxAdultQty,
                        PaxAdultRate = paxAdultRate,
                        PaxChildNo = paxChildNo,
                        PaxChildQty = paxChildQty,
                        PaxChildRate = paxChildRate,
                        PaxInfantNo = paxInfantNo,
                        PaxInfantQty = paxInfantQty,
                        PaxInfantRate = paxInfantRate,

                        NonCommissionable = GetNonCommissionable(item.Amounts),
                        Commission = item.Amounts?.TotalPrice == null || item.Amounts?.NettPrice == null ? 0 : item.Amounts.TotalPrice - item.Amounts.NettPrice,
                        FormOfPaymentId = -1,
                        SaleTypeId = GetSaleTypeId(lazyContext, customerId, item.PickUp.City, TripLineType.Transport),
                        CurrencyId = currencyId,
                        ForeignAmount = foreignAmount,
                        ExhangeRate = 1
                    });
                }
                else if (row.Item.GetType() == typeof(ItineraryTransferCT)) {
                    var item = row.Item as ItineraryTransferCT;

                    item.GetPaxValues(ref serviceTypeRateBasis, ref passengerClassification, ref duration, ref paxAdultNo, ref paxChildNo, ref paxInfantNo, ref paxAdultQty, ref paxChildQty, ref paxInfantQty, ref paxAdultRate, ref paxChildRate, ref paxInfantRate, ref totalAmount);
                    decimal foreignAmount = item.GetForeignAmount(lazyContext);

                    tripLineLandList.Add(new TripLineLand {
                        CrsRefId = tripLineLandId++,
                        TripLineType = TripLineType.Transport,
                        TripStatus = GetTripStatus(item.Status),
                        ConfirmationNo = string.Empty,
                        CreditorId = creditorAgencyLandId,
                        SupplierId = Supplier.GetSupplier(lazyContext, item?.Supplier?.Name ?? string.Empty).Id,
                        SupplierName = textInfo.ToTitleCase(item?.Supplier?.Name?.ToLower() ?? string.Empty),
                        SupplierChainId = -1,
                        SupplierCityCode = City.GetCity(lazyContext, item.Departs?.City?.Code).Code,
                        SupplierCrsCode = item.Supplier?.Code ?? string.Empty,
                        SupplierAddress1 = textInfo.ToTitleCase(item.Supplier?.Address?.Line1 ?? string.Empty),
                        SupplierAddress2 = string.Empty,
                        SupplierLocality = string.Format("{0} {1}", textInfo.ToTitleCase(item.Supplier?.Address?.Line2 ?? string.Empty), textInfo.ToTitleCase(item.Supplier?.Address?.Line3 ?? string.Empty)).Trim(),
                        SupplierRegion = item.Supplier?.City ?? string.Empty,
                        SupplierPostCode = string.Empty,
                        SupplierCountryCode = string.Empty,
                        SupplierContactPhoneWork = item.Supplier?.Phone ?? string.Empty,

                        StartDate = item.Departs?.Date ?? DateTime.MinValue,
                        StartTime = item.Departs?.Time.ToString("HH:mm") ?? string.Empty,
                        StartDetails = string.Empty,
                        StartAddress1 = string.Empty,
                        StartAddress2 = string.Empty,
                        StartLocality = City.GetCity(lazyContext, item.Departs?.City?.Code).Name,
                        StartRegion = string.Empty,
                        StartPostCode = string.Empty,
                        StartCountryCode = Country.GetCountry(lazyContext, item.Departs?.City?.Country, true).Code,
                        EndDate = item.Arrives?.Date ?? DateTime.MinValue,
                        EndTime = item.Arrives?.Time.ToString("HH:mm") ?? string.Empty,
                        EndDetails = string.Empty,
                        EndAddress1 = string.Empty,
                        EndAddress2 = string.Empty,
                        EndLocality = City.GetCity(lazyContext, item.Arrives?.City?.Code).Name,
                        EndRegion = string.Empty,
                        EndPostCode = string.Empty,
                        EndCountryCode = Country.GetCountry(lazyContext, item.Arrives?.City?.Country, true).Code,
                        SupplierServiceDescription = textInfo.ToTitleCase(item?.ProductDetails?.Description?.ToLower().Replace("a ", string.Empty) ?? string.Empty),
                        Inclusions = item.GetInclusions(paxAdultRate, totalAmount),
                        Comments = item.GetComments(row.ItineraryComment, paxAdultRate, totalAmount),

                        DurationCoverageType = DurationCoverageType.Days,
                        Duration = duration,
                        PayForDuration = duration,
                        ServiceTypeRateBasis = serviceTypeRateBasis,
                        PassengerClassification = passengerClassification,

                        PaxAdultNo = paxAdultNo,
                        PaxAdultQty = paxAdultQty,
                        PaxAdultRate = paxAdultRate,
                        PaxChildNo = paxChildNo,
                        PaxChildQty = paxChildQty,
                        PaxChildRate = paxChildRate,
                        PaxInfantNo = paxInfantNo,
                        PaxInfantQty = paxInfantQty,
                        PaxInfantRate = paxInfantRate,

                        NonCommissionable = GetNonCommissionable(item.Amounts),
                        Commission = item.Amounts?.TotalPrice == null || item.Amounts?.NettPrice == null ? 0 : item.Amounts.TotalPrice - item.Amounts.NettPrice,
                        FormOfPaymentId = -1,
                        SaleTypeId = GetSaleTypeId(lazyContext, customerId, item.Departs.City, TripLineType.Transport),
                        CurrencyId = currencyId,
                        ForeignAmount = foreignAmount,
                        ExhangeRate = 1
                    });
                }
                else if (row.Item.GetType() == typeof(ItineraryModuleCT)) {
                    var item = row.Item as ItineraryModuleCT;

                    item.GetPaxValues(ref serviceTypeRateBasis, ref passengerClassification, ref duration, ref paxAdultNo, ref paxChildNo, ref paxInfantNo, ref paxAdultQty, ref paxChildQty, ref paxInfantQty, ref paxAdultRate, ref paxChildRate, ref paxInfantRate, ref totalAmount);
                    decimal foreignAmount = item.GetForeignAmount(lazyContext);

                    tripLineLandList.Add(new TripLineLand {
                        CrsRefId = tripLineLandId++,
                        TripLineType = TripLineType.OtherLand,
                        TripStatus = GetTripStatus(item.Status),
                        ConfirmationNo = string.Empty,
                        CreditorId = creditorAgencyLandId,
                        SupplierId = Supplier.GetSupplier(lazyContext, item?.Supplier?.Name ?? string.Empty).Id,
                        SupplierName = textInfo.ToTitleCase(item?.Supplier?.Name?.ToLower() ?? string.Empty),
                        SupplierChainId = -1,
                        SupplierCityCode = City.GetCity(lazyContext, item.Departs?.City?.Code).Code,
                        SupplierCrsCode = item.Supplier?.Code ?? string.Empty,
                        SupplierAddress1 = textInfo.ToTitleCase(item?.Supplier?.Address?.Line1?.ToLower() ?? string.Empty),
                        SupplierAddress2 = string.Empty,
                        SupplierLocality = string.Format("{0} {1}", textInfo.ToTitleCase(item?.Supplier?.Address?.Line2?.ToLower() ?? string.Empty), textInfo.ToTitleCase(item?.Supplier?.Address?.Line3?.ToLower() ?? string.Empty)).Trim(),
                        SupplierRegion = item.Supplier?.City ?? string.Empty,
                        SupplierPostCode = string.Empty,
                        SupplierCountryCode = string.Empty,
                        SupplierContactPhoneWork = item.Supplier?.Phone ?? string.Empty,

                        StartDate = item.Departs?.Date ?? DateTime.MinValue,
                        StartTime = item.Departs?.Date.ToString("HH:mm") ?? string.Empty,
                        StartDetails = string.Empty,
                        StartAddress1 = string.Empty,
                        StartAddress2 = string.Empty,
                        StartLocality = City.GetCity(lazyContext, item.Departs?.City?.Code).Name,
                        StartRegion = string.Empty,
                        StartPostCode = string.Empty,
                        StartCountryCode = Country.GetCountry(lazyContext, item.Departs?.City?.Country, true).Code,
                        EndDate = item.Arrives?.Date ?? DateTime.MinValue,
                        EndTime = item.Arrives?.Time.ToString("HH:mm") ?? string.Empty,
                        EndDetails = string.Empty,
                        EndAddress1 = string.Empty,
                        EndAddress2 = string.Empty,
                        EndLocality = City.GetCity(lazyContext, item.Arrives?.City?.Code).Name,
                        EndRegion = string.Empty,
                        EndPostCode = string.Empty,
                        EndCountryCode = Country.GetCountry(lazyContext, item.Arrives?.City?.Country, true).Code,
                        SupplierServiceDescription = textInfo.ToTitleCase(item.ProductDetails?.Description?.ToLower() ?? item?.ProductDetails?.Description?.ToLower() ?? string.Empty),
                        Inclusions = item.GetInclusions(paxAdultRate, totalAmount),
                        Comments = item.GetComments(row.ItineraryComment, paxAdultRate, totalAmount),

                        DurationCoverageType = DurationCoverageType.Days,
                        Duration = duration,
                        PayForDuration = duration,
                        ServiceTypeRateBasis = serviceTypeRateBasis,
                        PassengerClassification = passengerClassification,

                        PaxAdultNo = paxAdultNo,
                        PaxAdultQty = paxAdultQty,
                        PaxAdultRate = paxAdultRate,
                        PaxChildNo = paxChildNo,
                        PaxChildQty = paxChildQty,
                        PaxChildRate = paxChildRate,
                        PaxInfantNo = paxInfantNo,
                        PaxInfantQty = paxInfantQty,
                        PaxInfantRate = paxInfantRate,

                        NonCommissionable = GetNonCommissionable(item.Amounts),
                        Commission = item.Amounts?.TotalPrice == null || item.Amounts?.NettPrice == null ? 0 : item.Amounts.TotalPrice - item.Amounts.NettPrice,
                        FormOfPaymentId = -1,
                        SaleTypeId = GetSaleTypeId(lazyContext, customerId, item.Arrives.City, TripLineType.Tour),
                        CurrencyId = currencyId,
                        ForeignAmount = foreignAmount,
                        ExhangeRate = 1
                    });
                }
            }

            id = tripLineLandList.Max(t => (int?)t.CrsRefId) ?? 0;
            return tripLineLandList;
        }

        private static int GetSaleTypeId(AppLazyContext lazyContext, int customerId, CityCT city, TripLineType tripLineType) {
            return city?.Code == null ? AppSettings.Setting(customerId).CrsDomesticAccommodationSaleTypeId
                : City.GetCity(lazyContext, city.Code).Country.Code == AppSettings.Setting(customerId).CountryCode ? tripLineType == TripLineType.Transport ? AppSettings.Setting(customerId).CrsDomesticTransportSaleTypeId : AppSettings.Setting(customerId).CrsDomesticAccommodationSaleTypeId
                : tripLineType == TripLineType.Transport ? AppSettings.Setting(customerId).CrsInternationalTransportSaleTypeId : AppSettings.Setting(customerId).CrsInternationalAccommodationSaleTypeId;
        }

        private static TripStatus GetTripStatus(ComponentInventoryStatusST status) {
            return status == ComponentInventoryStatusST.Confirmed ? TripStatus.Confirmed
                : status == ComponentInventoryStatusST.OnRequest ? TripStatus.OnRequest
                : status == ComponentInventoryStatusST.Waitlisted ? TripStatus.Waitlisted
                : status == ComponentInventoryStatusST.Pending ? TripStatus.Pending
                : status == ComponentInventoryStatusST.Unable || status == ComponentInventoryStatusST.NotAvailable ? TripStatus.CannotConfirm
                : TripStatus.NotSpecified;
        }

        private static decimal GetNonCommissionable(ItineraryItemPriceCT amounts) {
            return (amounts?.TicketTaxes ?? 0) + (amounts?.NonCommissionableRoomTax ?? 0) + (amounts?.NonCommissionableMealPrice ?? 0) + (amounts?.NonCommissionableMealTax ?? 0) + (amounts?.NonCommissionableRounding ?? 0);
        }

        private static void GetAddressDetails<T>(this T source, ref string startAddress1, ref string startLocality, ref string startRegion, ref string endAddress1, ref string endLocality, ref string endRegion) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            if (source.GetType() == typeof(ItineraryCarRentalCT)) {
                var item = source as ItineraryCarRentalCT;

                startAddress1 = textInfo.ToTitleCase(item.Depots?[0]?.Address?.Line2?.ToLower() ?? string.Empty);
                startLocality = textInfo.ToTitleCase(item.Depots?[0]?.Address?.Line2?.ToLower() ?? string.Empty);
                startRegion = item.Depots?[0]?.Address?.Line3 ?? string.Empty;

                if (item.Depots?.Length > 1) {
                    endAddress1 = textInfo.ToTitleCase(item.Depots?[1]?.Address?.Line2?.ToLower() ?? string.Empty);
                    endLocality = textInfo.ToTitleCase(item.Depots?[1]?.Address?.Line2?.ToLower() ?? string.Empty);
                    endRegion = item.Depots?[1]?.Address?.Line3 ?? string.Empty;
                }
                else {
                    endAddress1 = startAddress1;
                    endLocality = startLocality;
                    endRegion = startRegion;
                }
            }
            else if (source.GetType() == typeof(ItineraryVanRentalCT)) {
                var item = source as ItineraryVanRentalCT;

                startAddress1 = textInfo.ToTitleCase(item.Depots?[0]?.Address?.Line2?.ToLower() ?? string.Empty);
                startLocality = textInfo.ToTitleCase(item.Depots?[0]?.Address?.Line2?.ToLower() ?? string.Empty);
                startRegion = item.Depots?[0]?.Address?.Line3?.ToLower() ?? string.Empty;

                if (item.Depots?.Length > 1) {
                    endAddress1 = textInfo.ToTitleCase(item.Depots?[1]?.Address?.Line2?.ToLower() ?? string.Empty);
                    endLocality = textInfo.ToTitleCase(item.Depots?[1]?.Address?.Line2?.ToLower() ?? string.Empty);
                    endRegion = item.Depots?[1]?.Address?.Line3 ?? string.Empty;
                }
                else {
                    endAddress1 = startAddress1;
                    endLocality = startLocality;
                    endRegion = startRegion;
                }
            }
        }

        private static void GetPaxValues<T>(this T source, ref ServiceTypeRateBasisBase serviceTypeRateBasis, ref PassengerClassification passengerClassification, ref int duration, ref int paxAdultNo, ref int paxChildNo, ref int paxInfantNo, ref int paxAdultQty, ref int paxChildQty, ref int paxInfantQty, ref decimal paxAdultRate, ref decimal paxChildRate, ref decimal paxInfantRate, ref decimal totalAmount) {
            paxAdultNo = 0;
            paxChildNo = 0;
            paxInfantNo = 0;

            paxAdultQty = 0;
            paxChildQty = 0;
            paxInfantQty = 0;

            paxAdultRate = 0;
            paxChildRate = 0;
            paxInfantRate = 0;

            if (source.GetType() == typeof(ItineraryHotelStayCT)) {
                var item = source as ItineraryHotelStayCT;

                int roomCount = (item.StayDetails?.Rooms ?? "0").ToInt();
                decimal amount = (item.Amounts?.TotalPrice ?? 0) - GetNonCommissionable(item.Amounts);

                serviceTypeRateBasis = roomCount == 0 ? ServiceTypeRateBasisBase.AccommodationPackage : ServiceTypeRateBasisBase.AccommodationPerRoom;
                passengerClassification = PassengerClassification.Group;

                duration = item.StayDetails?.Duration.ToInt() ?? 0;

                if (duration == 0)
                    duration = 1;

                switch (serviceTypeRateBasis) {
                    case ServiceTypeRateBasisBase.AccommodationPackage:
                        paxAdultNo = item.ComponentPassengers.Length;
                        paxAdultRate = paxAdultNo == 0 ? 0 : amount / (paxAdultNo * (duration == 0 ? 1 : duration));
                        totalAmount = paxAdultNo * paxAdultRate;
                        break;
                    case ServiceTypeRateBasisBase.AccommodationPerRoom:
                        paxAdultQty = roomCount;
                        paxAdultRate = paxAdultQty == 0 ? 0 : amount / (paxAdultQty * (duration == 0 ? 1 : duration));
                        totalAmount = paxAdultQty * paxAdultRate;
                        break;
                }
            }
            else if (source.GetType() == typeof(ItineraryCarRentalCT)) {
                var item = source as ItineraryCarRentalCT;

                serviceTypeRateBasis = ServiceTypeRateBasisBase.TransportPackage;
                passengerClassification = PassengerClassification.Group;

                duration = item.RentalDetails?.Duration.ToInt() ?? 0;

                if (duration == 0)
                    duration = 1;

                paxAdultQty = item.RentalDetails?.NoOfVehicles.ToInt() ?? 0;
                paxAdultRate = paxAdultQty == 0 ? 0 : ((item.Amounts?.TotalPrice ?? 0) - GetNonCommissionable(item.Amounts)) / paxAdultQty;
                totalAmount = paxAdultQty * paxAdultRate;
            }
            else if (source.GetType() == typeof(ItineraryVanRentalCT)) {
                var item = source as ItineraryVanRentalCT;

                serviceTypeRateBasis = ServiceTypeRateBasisBase.TransportPackage;
                passengerClassification = PassengerClassification.Group;

                duration = item.RentalDetails?.Duration.ToInt() ?? 0;

                if (duration == 0)
                    duration = 1;

                paxAdultQty = item.RentalDetails?.NoOfVehicles.ToInt() ?? 0;
                paxAdultRate = paxAdultQty == 0 ? 0 : ((item.Amounts?.TotalPrice ?? 0) - GetNonCommissionable(item.Amounts)) / paxAdultQty;
                totalAmount = paxAdultQty * paxAdultRate;
            }
            else if (source.GetType() == typeof(ItineraryTransferCT)) {
                var item = source as ItineraryTransferCT;

                serviceTypeRateBasis = ServiceTypeRateBasisBase.TransportPackage;
                passengerClassification = PassengerClassification.Group;

                duration = 1;

                paxAdultQty = item.ComponentPassengers.Length;
                paxAdultRate = paxAdultQty == 0 ? 0 : ((item.Amounts?.TotalPrice ?? 0) - GetNonCommissionable(item.Amounts)) / paxAdultQty;
                totalAmount = paxAdultQty * paxAdultRate;
            }
            else if (source.GetType() == typeof(ItineraryModuleCT)) {
                var item = source as ItineraryModuleCT;

                serviceTypeRateBasis = ServiceTypeRateBasisBase.OtherLandPackage;
                passengerClassification = PassengerClassification.Group;

                duration = item.StayDetails?.Duration.ToInt() ?? 0;

                if (duration == 0)
                    duration = 1;

                paxAdultNo = item.ComponentPassengers.Length;
                paxAdultRate = paxAdultNo == 0 ? 0 : ((item.Amounts?.TotalPrice ?? 0) - GetNonCommissionable(item.Amounts)) / paxAdultNo;
                totalAmount = paxAdultNo * paxAdultRate;
            }
        }

        private static decimal GetForeignAmount<T>(this T source, AppLazyContext lazyContext) {
            var serviceTypeRateBasis = ServiceTypeRateBasisBase.NotSpecified;
            var passengerClassification = PassengerClassification.Individual;

            int duration = 0;

            int paxAdultNo = 0;
            int paxChildNo = 0;
            int paxInfantNo = 0;

            int paxAdultQty = 0;
            int paxChildQty = 0;
            int paxInfantQty = 0;

            decimal paxAdultRate = 0;
            decimal paxChildRate = 0;
            decimal paxInfantRate = 0;

            decimal totalAmount = 0;

            source.GetPaxValues(ref serviceTypeRateBasis, ref passengerClassification, ref duration, ref paxAdultNo, ref paxChildNo, ref paxInfantNo, ref paxAdultQty, ref paxChildQty, ref paxInfantQty, ref paxAdultRate, ref paxChildRate, ref paxInfantRate, ref totalAmount);

            var rateBasis = lazyContext.ServiceTypeRateBasis.Find((int)serviceTypeRateBasis);

            if (rateBasis == null)
                return 0;

            if (rateBasis.IsPaxNoApplicable) {
                return paxAdultNo * paxAdultRate + paxChildNo * paxChildRate + paxInfantNo * paxInfantRate;
            }
            else {
                return paxAdultQty * paxAdultRate + paxChildQty * paxChildRate + paxInfantQty * paxInfantRate;
            }
        }

        private static string GetInclusions<T>(this T source, decimal rate, decimal totalAmount) {
            var sb = new StringBuilder();

            sb.AppendFormat("Rate: {0:c2} per person; Total: {1:c2}.{2}", rate, totalAmount, Environment.NewLine);
            sb.AppendLine();

            if (source.GetType() == typeof(ItineraryHotelStayCT)) {
                var item = source as ItineraryHotelStayCT;

                if (item.Meals?.Meal?.Any() ?? false) {
                    sb.AppendFormat("Meals: {0}.{1}", string.Join("; ", item.Meals.Meal.Select(t => t.Description)), Environment.NewLine);
                    sb.AppendLine();
                }

                if (item.DescriptiveItineraryText?.Text?.Any() ?? false) {
                    foreach (var row in item.DescriptiveItineraryText.Text) {
                        sb.AppendLine(row.Value);
                    }
                }
            }
            else if (source.GetType() == typeof(ItineraryCarRentalCT)) {
                var item = source as ItineraryCarRentalCT;

                if (item.ProductDetails?.ProductNotes?.Any() ?? false) {
                    foreach (var row in item.ProductDetails.ProductNotes) {
                        if (row.Text.Length <= 1)
                            continue;

                        if (row.Text == "OPERATED BY" || row.Text == "TRANSFER TYPE" || row.Text == "PRODUCT INFORMATION")
                            sb.AppendLine();

                        sb.AppendLine(row.Text);
                    }

                    sb.AppendLine();
                }

                if (item.DescriptiveItineraryText?.Text?.Any() ?? false) {
                    foreach (var row in item.DescriptiveItineraryText.Text) {
                        sb.AppendLine(row.Value);
                    }
                }
            }
            else if (source.GetType() == typeof(ItineraryVanRentalCT)) {
                var item = source as ItineraryVanRentalCT;

                if (item.ProductDetails?.ProductNotes?.Any() ?? false) {
                    foreach (var row in item.ProductDetails.ProductNotes) {
                        if (row.Text.Length <= 1)
                            continue;

                        if (row.Text == "OPERATED BY" || row.Text == "TRANSFER TYPE" || row.Text == "PRODUCT INFORMATION")
                            sb.AppendLine();

                        sb.AppendLine(row.Text);
                    }

                    sb.AppendLine();
                }

                if (item.DescriptiveItineraryText?.Text?.Any() ?? false) {
                    foreach (var row in item.DescriptiveItineraryText.Text) {
                        sb.AppendLine(row.Value);
                    }
                }
            }
            else if (source.GetType() == typeof(ItineraryTransferCT)) {
                var item = source as ItineraryTransferCT;

                if (item.ProductDetails?.ProductNotes?.Any() ?? false) {
                    foreach (var row in item.ProductDetails.ProductNotes) {
                        if (row.Text.Length <= 1)
                            continue;

                        if (row.Text == "OPERATED BY" || row.Text == "TRANSFER TYPE" || row.Text == "PRODUCT INFORMATION")
                            sb.AppendLine();

                        sb.AppendLine(row.Text);
                    }

                    sb.AppendLine();
                }

                if (item.DescriptiveItineraryText?.Text?.Any() ?? false) {
                    foreach (var row in item.DescriptiveItineraryText.Text) {
                        sb.AppendLine(row.Value);
                    }
                }
            }
            else if (source.GetType() == typeof(ItineraryModuleCT)) {
                var item = source as ItineraryModuleCT;

                if (item.DescriptiveItineraryText?.Text?.Any() ?? false) {
                    foreach (var row in item.DescriptiveItineraryText.Text) {
                        sb.AppendLine(row.Value);
                    }
                }
            }

            return string.Format("{0}.", sb.ToString().Replace(" :", ":").TrimEnd(Environment.NewLine).TrimEnd('.'));
        }

        private static string GetComments<T>(this T source, ItineraryCommentCT comment, decimal rate, decimal totalAmount) {
            var sb = new StringBuilder();

            sb.AppendFormat("Rate: {0:c2} per person; Total: {1:c2}.{2}", rate, totalAmount, Environment.NewLine);
            sb.AppendLine();

            if (!string.IsNullOrEmpty(comment?.Text)) {
                sb.AppendLine(comment.Text);
                sb.AppendLine();
            }

            if (source.GetType() == typeof(ItineraryHotelStayCT)) {
                var item = source as ItineraryHotelStayCT;

                if (item.VoucherText?.Text?.Any() ?? false) {
                    foreach (var row in item.VoucherText.Text) {
                        sb.AppendLine(row.Value);
                    }
                }
            }
            else if (source.GetType() == typeof(ItineraryCarRentalCT)) {
                var item = source as ItineraryCarRentalCT;

                if (item.VoucherText?.Text?.Any() ?? false) {
                    foreach (var row in item.VoucherText.Text) {
                        sb.AppendLine(row.Value);
                    }
                }
            }
            else if (source.GetType() == typeof(ItineraryVanRentalCT)) {
                var item = source as ItineraryVanRentalCT;

                if (item.VoucherText?.Text?.Any() ?? false) {
                    foreach (var row in item.VoucherText.Text) {
                        sb.AppendLine(row.Value);
                    }
                }
            }
            else if (source.GetType() == typeof(ItineraryTransferCT)) {
                var item = source as ItineraryTransferCT;

                if (item.VoucherText?.Text?.Any() ?? false) {
                    foreach (var row in item.VoucherText.Text) {
                        sb.AppendLine(row.Value);
                    }
                }
            }
            else if (source.GetType() == typeof(ItineraryModuleCT)) {
                var item = source as ItineraryModuleCT;

                if (item.VoucherText?.Text?.Any() ?? false) {
                    foreach (var row in item.VoucherText.Text) {
                        sb.AppendLine(row.Value);
                    }
                }
            }

            return string.Format("{0}.", sb.ToString().Replace(" :", ":").TrimEnd(Environment.NewLine).TrimEnd('.'));
        }
    }
}