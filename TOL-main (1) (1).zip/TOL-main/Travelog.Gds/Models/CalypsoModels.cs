﻿using System.Collections.Generic;

namespace Travelog.Gds.Models.Calypso {
	public class Address {
		public string Location { get; set; }
		public string Soap12 { get; set; }
	}

	public class Annotation {
		public string Documentation { get; set; }
	}

	public class Attribute {
		public Annotation Annotation { get; set; }
		public string Default { get; set; }
		public string Name { get; set; }
		public SimpleType SimpleType { get; set; }
		public string Type { get; set; }
		public string Use { get; set; }
	}

	public class AttributeGroup {
		public List<Attribute> Attribute { get; set; }
		public string Name { get; set; }
		public string Ref { get; set; }
	}

	public class Binding {
		public string Soap12 { get; set; }
		public string Style { get; set; }
		public string Transport { get; set; }
	}

	public class Binding2 {
		public Binding Binding { get; set; }
		public string Name { get; set; }
		public List<Operation> Operation { get; set; }
		public string Type { get; set; }
	}

	public class Body {
		public string Parts { get; set; }
		public string Soap12 { get; set; }
		public string Use { get; set; }
	}

	public class Choice {
		public List<Element> Element { get; set; }
		public string MinOccurs { get; set; }
	}

	public class ComplexContent {
		public Extension Extension { get; set; }
		public Restriction Restriction { get; set; }
	}

	public class ComplexType {
		public Annotation Annotation { get; set; }
		public List<Attribute> Attribute { get; set; }
		public AttributeGroup AttributeGroup { get; set; }
		public Choice Choice { get; set; }
		public ComplexContent ComplexContent { get; set; }
		public string Name { get; set; }
		public Sequence Sequence { get; set; }
		public SimpleContent SimpleContent { get; set; }
	}

	public class Definitions {
		public Binding2 Binding2 { get; set; }
		public List<Message> Message { get; set; }
		public string Name { get; set; }
		public PortType PortType { get; set; }
		public Service Service { get; set; }
		public string TargetNamespace { get; set; }
		public string Tns { get; set; }
		public Types Types { get; set; }
		public string Xmlns { get; set; }
	}

	public class Element {
		public ComplexType ComplexType { get; set; }
		public string Default { get; set; }
		public string MaxOccurs { get; set; }
		public string MinOccurs { get; set; }
		public string Name { get; set; }
		public SimpleType SimpleType { get; set; }
		public string Type { get; set; }
	}

	public class Enumeration {
		public string Value { get; set; }
	}

	public class Extension {
		public List<Attribute> Attribute { get; set; }
		public string Base { get; set; }
		public Sequence Sequence { get; set; }
	}

	public class FractionDigits {
		public string Value { get; set; }
	}

	public class Group {
		public string Name { get; set; }
		public string Ref { get; set; }
		public Sequence Sequence { get; set; }
	}

	public class Header {
		public string Message { get; set; }
		public string Part { get; set; }
		public string Soap12 { get; set; }
		public string Use { get; set; }
	}

	public class Input {
		public Body Body { get; set; }
		public List<Header> Header { get; set; }
		public string Message { get; set; }
	}

	public class Length {
		public string Value { get; set; }
	}

	public class List {
		public string ItemType { get; set; }
	}

	public class MaxInclusive {
		public string Value { get; set; }
	}

	public class MaxLength {
		public string Value { get; set; }
	}

	public class Message {
		public string Name { get; set; }
		public List<Part> Part { get; set; }
	}

	public class MinInclusive {
		public string Value { get; set; }
	}

	public class MinLength {
		public string Value { get; set; }
	}

	public class Operation {
		public Input Input { get; set; }
		public string Name { get; set; }
		public Operation2 Operation2 { get; set; }
		public Output Output { get; set; }
		public string ParameterOrder { get; set; }
	}

	public class Operation2 {
		public string Soap12 { get; set; }
		public string SoapAction { get; set; }
	}

	public class Output {
		public Body Body { get; set; }
		public string Message { get; set; }
	}

	public class Part {
		public string Element { get; set; }
		public string Name { get; set; }
	}

	public class Pattern {
		public string Value { get; set; }
	}

	public class Port {
		public Address Address { get; set; }
		public string Binding { get; set; }
		public string Name { get; set; }
	}

	public class PortType {
		public string Name { get; set; }
		public List<Operation> Operation { get; set; }
	}

	public class Restriction {
		public string Base { get; set; }
		public List<Enumeration> Enumeration { get; set; }
		public FractionDigits FractionDigits { get; set; }
		public Length Length { get; set; }
		public MaxInclusive MaxInclusive { get; set; }
		public MaxLength MaxLength { get; set; }
		public MinInclusive MinInclusive { get; set; }
		public MinLength MinLength { get; set; }
		public Pattern Pattern { get; set; }
		public TotalDigits TotalDigits { get; set; }
	}

	public class Schema {
		public string AttributeFormDefault { get; set; }
		public List<AttributeGroup> AttributeGroup { get; set; }
		public List<ComplexType> ComplexType { get; set; }
		public List<Element> Element { get; set; }
		public string ElementFormDefault { get; set; }
		public List<Group> Group { get; set; }
		public List<SimpleType> SimpleType { get; set; }
		public string TargetNamespace { get; set; }
		public string Xmlns { get; set; }
		public string Xs { get; set; }
	}

	public class Sequence {
		public Choice Choice { get; set; }
		public List<Element> Element { get; set; }
		public Group Group { get; set; }
		public string MaxOccurs { get; set; }
		public string MinOccurs { get; set; }
	}

	public class Service {
		public string Name { get; set; }
		public Port Port { get; set; }
	}

	public class SimpleContent {
		public Extension Extension { get; set; }
	}

	public class SimpleType {
		public Annotation Annotation { get; set; }
		public List List { get; set; }
		public string Name { get; set; }
		public Restriction Restriction { get; set; }
		public Union Union { get; set; }
	}

	public class TotalDigits {
		public string Value { get; set; }
	}

	public class Types {
		public Schema Schema { get; set; }
	}

	public class Union {
		public string MemberTypes { get; set; }
	}
}
