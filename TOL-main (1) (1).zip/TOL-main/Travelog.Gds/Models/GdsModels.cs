﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Travelog.Biz;
using Travelog.Biz.Enums;

namespace Travelog.Gds.Models {
    public class CrsImportModel {
        public CrsImportModel() {
            ErrorMessage = string.Empty;
        }

        public int CrsAgencyId { get; set; }
        public int CrsProfileId { get; set; }
        public int CrsTripId { get; set; }
        public string GalileoPcc { get; set; }
        public string ErrorMessage { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(6, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Booking No")]
        public string CalypsoCrsPnrRef { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Calypso Company")]
        public string CalypsoCompany { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(50, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "Last Name")]
        public string CalypsoLastName { get; set; }

        [Display(Name = "Remove spaces from Last Name")]
        public bool CalypsoRemoveSpaces { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(6, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "PNR Ref")]
        public string EtgCrsPnrRef { get; set; }

        [DataType(DataType.Text, ErrorMessage = "{0} is invalid.")]
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(DataValidation.AlphaNumericExt, ErrorMessage = "{0} is invalid.")]
        [StringLength(6, ErrorMessage = "{0} can be no longer than {1} characters.")]
        [Display(Name = "PNR Ref")]
        public string GalileoCrsPnrRef { get; set; }

        [Display(Name = "PCC")]
        public int GalileoPccId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Creditor (Air)")]
        public int CrsCreditorAirId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier (Air)")]
        public int CrsSupplierAirId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Creditor (Land)")]
        public int CrsCreditorLandId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "Supplier (Land)")]
        public int CrsSupplierLandId { get; set; }

        [Required(ErrorMessage = "{0} is required.")]
        [Display(Name = "For existing trip lines")]
        public CrsImportOption CrsImportOption { get; set; }

        [Display(Name = "Import Air trip lines")]
        public bool CrsImportAirTripLines { get; set; }

        [Display(Name = "Update existing Land trip lines")]
        public bool CrsUpdateExistingLandTripLines { get; set; }

        [Display(Name = "Existing Air segments have been updated*")]
        public bool CrsAirSegmentsUpdated { get; set; }

        public void Validate() {
            if (CrsCreditorAirId <= 0)
                throw new UnreportedException("Creditor (Air) is required.");

            if (CrsSupplierAirId <= 0)
                throw new UnreportedException("Supplier (Air) is required.");

            if (CrsCreditorLandId <= 0)
                throw new UnreportedException("Creditor (Land) is required.");

            if (CrsSupplierLandId <= 0)
                throw new UnreportedException("Supplier (Land) is required.");
        }
    }

    public class CrsModel {
        public CrsModel() {
            PassengerList = new List<Passenger>();
            TripLineAirList = new List<TripLineAir>();
            TripLineLandList = new List<TripLineLand>();
            TripLineServiceFeeList = new List<TripLineServiceFee>();
            TripLineRemarkList = new List<TripLineRemark>();
            NewPassengers = new Dictionary<string, string>();
        }

        public Crs Crs { get; set; }
        public string CrsPnrRef { get; set; }
        public DateTime CrsPnrDate { get; set; }
        public string FileName { get; set; }
        public string RouteInfo { get; set; }
        public string Passengers { get { return string.Join("; ", PassengerList.Select(t => string.Format("{0} {1} {2}", t.Title, t.FirstName, t.LastName).Trim())); } }
        public string PnrCreatorAgent { get; set; }
        public string PnrTicketingAgent { get; set; }
        public bool IsTicketed { get; set; }
        public bool IsValid { get; set; }
        public ClientDetail ClientDetail { get; set; }
        public List<Passenger> PassengerList { get; set; }
        public List<TripLineAir> TripLineAirList { get; set; }
        public List<TripLineLand> TripLineLandList { get; set; }
        public List<TripLineServiceFee> TripLineServiceFeeList { get; set; }
        public List<TripLineRemark> TripLineRemarkList { get; set; }
        public Dictionary<string, string> NewPassengers { get; set; }
    }

    public class ClientDetail {
        public int AgencyId { get; set; }
        public int TripId { get; set; }
        public int ProfileId { get; set; }
        public int ConsultantId { get; set; }
        public int CurrencyId { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneHome { get; set; }
        public string PhoneWork { get; set; }
        public string Mobile { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Locality { get; set; }
        public string Region { get; set; }
        public string PostCode { get; set; }
        public string CountryCode { get; set; }
        public int PaxAdult { get; set; }
        public int PaxChild { get; set; }
        public int PaxInfant { get; set; }
        public DateTime DepartureDate { get; set; }
        public DateTime BalanceDueDate { get; set; }
    }

    public class Passenger {
        public Passenger() {
            PassengerDocumentList = new List<PassengerDocument>();
            PassengerClubMembershipList = new List<PassengerClubMembership>();
        }

        public int EtgTicketId { get; set; }
        public string EtgTransactionType { get; set; }
        public string CrsKey { get; set; }
        public string OriginalPassengerNo { get; set; }
        public string PassengerNo { get; set; }
        public int PassengerId { get; set; }
        public PassengerType PassengerType { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNo { get; set; }
        public string PhoneHome { get; set; }
        public string PhoneWork { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public DateTime BirthDate { get; set; }
        public int Age { get; set; }
        public Gender Gender { get; set; }
        public decimal AirPrice { get; set; }
        public decimal LandPrice { get; set; }
        public decimal InsurancePrice { get; set; }
        public decimal TotalPrice { get; set; }
        public bool AccompaniedInfant { get; set; }
        public bool IsDuplicate { get; set; }
        public string FullName { get { return string.Format("{0} {1} {2}", Title, FirstName, LastName).Trim(); } }
        public List<PassengerDocument> PassengerDocumentList { get; set; }
        public List<PassengerClubMembership> PassengerClubMembershipList { get; set; }
    }

    public class PassengerDocument {
        public string CrsPassengerKey { get; set; }
        public int PassengerDocumentId { get; set; }
        public DocumentType DocumentType { get; set; }
        public string DocumentNo { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string PlaceOfIssue { get; set; }
        public int IssuingCountryId { get; set; }
        public int NationalityId { get; set; }
    }

    public class PassengerClubMembership {
        public string CrsPassengerKey { get; set; }
        public int PassengerClubMembershipId { get; set; }
        public int ClubMembershipId { get; set; }
        public string ClubMembershipNo { get; set; }
        public int AirlineId { get; set; }
    }

    public class TripLineAir {
        public TripLineAir() {
            TripLineAirSegmentList = new List<TripLineAirSegment>();
            TripLineAirPassengerList = new List<TripLineAirPassenger>();
        }

        public int CrsRefId { get; set; }
        public int TripLineId { get; set; }
        public DateTime ValidUntilDate { get; set; }
        public int AirlineId { get; set; }
        public string AirlineCode { get; set; }
        public string CrsPnrRef { get; set; }
        public List<TripLineAirSegment> TripLineAirSegmentList { get; set; }
        public List<TripLineAirPassenger> TripLineAirPassengerList { get; set; }
    }

    public class TripLineAirSegment {
        public TripLineAirSegment() {
            EtgTicketIds = new List<int>();
        }

        public List<int> EtgTicketIds { get; set; }
        public string CrsKey { get; set; }
        public int TripLineAirSegmentId { get; set; }
        public TripStatus TripStatus { get; set; }
        public int DepartureCityId { get; set; }
        public int ArrivalCityId { get; set; }
        public string DepartureCityCode { get; set; }
        public string ArrivalCityCode { get; set; }
        public string Class { get; set; }
        public string FlightNo { get; set; }
        public string CheckInTime { get; set; }
        public DateTime DepartureDate { get; set; }
        public string DepartureTime { get; set; }
        public DateTime ArrivalDate { get; set; }
        public string ArrivalTime { get; set; }
        public string FlightTime { get; set; }
        public InternationalDateOffset InternationalDateOffset { get; set; }
        public AirportType AirportType { get; set; }
        public string DepartureTerminal { get; set; }
        public string ArrivalTerminal { get; set; }
        public string AirlinePnr { get; set; }
        public int AircraftId { get; set; }
        public string Operator { get; set; }
        public int DistanceFlownKm { get; set; }
        public decimal CO2Emissions { get; set; }
        public string Meals { get; set; }
        public string TransitStops { get; set; }
        public int SeqNo { get; set; }
        public bool IsProcessed { get; set; }
        public string SegmentNo { get { return string.IsNullOrEmpty(CrsKey) ? string.Empty : string.Format("{0:d3}", int.Parse(CrsKey.Split('¶')[0])); } }
    }

    public class TripLineAirPassenger {
        public TripLineAirPassenger() {
            BspEntryType = BspEntryType.Ticket;
            SegmentNoList = new List<string>();
            PassengerNoList = new List<string>();
            TripLineAirPassengerAirSegmentList = new List<TripLineAirPassengerAirSegment>();
        }

        public int EtgTicketId { get; set; }
        public string CrsPassengerKey { get; set; }
        public int TripLineAirPassengerId { get; set; }
        public int TripLineAirSegmentId { get; set; }
        public int CreditorId { get; set; }
        public int SupplierId { get; set; }
        public int PassengerId { get; set; }
        public int SaleTypeId { get; set; }
        public int FormOfPaymentId { get; set; }
        public int AirlineId { get; set; }
        public DateTime IssueDate { get; set; }
        public BspEntryType BspEntryType { get; set; }
        public string TicketNo { get; set; }
        public string OriginalTicketNo { get; set; }
        public string ConnectingTicketNos { get; set; }
        public TicketMethod TicketMethod { get; set; }
        public string FareCalc { get; set; }
        public decimal Amount { get; set; }
        public decimal Tax { get; set; }
        public decimal TicketedFare { get; set; }
        public decimal NonCommissionable { get; set; }
        public decimal Commission { get; set; }
        public string Comments { get; set; }
        public bool AccompaniedInfant { get; set; }
        public string PassengerNo { get { return string.IsNullOrEmpty(CrsPassengerKey) ? string.Empty : CrsPassengerKey.Split('¶')[0]; } }
        public List<string> SegmentNoList { get; set; }
        public List<string> PassengerNoList { get; set; }
        public List<TripLineAirPassengerAirSegment> TripLineAirPassengerAirSegmentList { get; set; }
    }

    public class TripLineAirPassengerAirSegment {
        public TripLineAirPassengerAirSegment() {
            Comments = string.Empty;
            EmdSegmentNos = Array.Empty<string>();
        }

        public int EtgTicketId { get; set; }
        public string CrsAirSegmentKey { get; set; }
        public string CrsPassengerKey { get; set; }
        public string DepartureCityCode { get; set; }
        public string ArrivalCityCode { get; set; }
        public string SeatNo { get; set; }
        public SeatStatus SeatStatus { get; set; }
        public int BaggageAllowance { get; set; }
        public BaggageUnit BaggageUnit { get; set; }
        public string FareBasis { get; set; }
        public string TicketDesignator { get; set; }
        public string TourCode { get; set; }
        public TicketMethod TicketMethod { get; set; }
        public bool ExcludePassengerSegmentPricing { get; set; }
        public decimal Amount { get; set; }
        public decimal Tax { get; set; }
        public decimal TicketedFare { get; set; }
        public decimal NonCommissionable { get; set; }
        public decimal Commission { get; set; }
        public string Comments { get; set; }
        public string[] EmdSegmentNos { get; set; }
        public bool IsEmd { get; set; }
    }

    public class TripLineLand {
        public string CrsKey { get; set; }
        public int CrsRefId { get; set; }
        public int TripLineId { get; set; }
        public TripLineType TripLineType { get; set; }
        public TripStatus TripStatus { get; set; }
        public int CreditorId { get; set; }
        public int SupplierId { get; set; }
        public int SupplierChainId { get; set; }
        public string SupplierCityCode { get; set; }
        public string SupplierCrsCode { get; set; }
        public string ConfirmationNo { get; set; }
        public DurationCoverageType DurationCoverageType { get; set; }
        public int Duration { get; set; }
        public string SupplierName { get; set; }
        public string SupplierAddress1 { get; set; }
        public string SupplierAddress2 { get; set; }
        public string SupplierLocality { get; set; }
        public string SupplierRegion { get; set; }
        public string SupplierPostCode { get; set; }
        public string SupplierCountryCode { get; set; }
        public string SupplierContactPhoneWork { get; set; }
        public DateTime StartDate { get; set; }
        public string StartTime { get; set; }
        public string StartDetails { get; set; }
        public string StartAddress1 { get; set; }
        public string StartAddress2 { get; set; }
        public string StartLocality { get; set; }
        public string StartRegion { get; set; }
        public string StartPostCode { get; set; }
        public string StartCountryCode { get; set; }
        public DateTime EndDate { get; set; }
        public string EndTime { get; set; }
        public string EndDetails { get; set; }
        public string EndAddress1 { get; set; }
        public string EndAddress2 { get; set; }
        public string EndLocality { get; set; }
        public string EndRegion { get; set; }
        public string EndPostCode { get; set; }
        public string EndCountryCode { get; set; }
        public string SupplierServiceDescription { get; set; }
        public string Inclusions { get; set; }
        public string Comments { get; set; }
        public ServiceTypeRateBasisBase ServiceTypeRateBasis { get; set; }
        public PassengerClassification PassengerClassification { get; set; }
        public int PayForDuration { get; set; }
        public int PaxAdultNo { get; set; }
        public decimal PaxAdultRate { get; set; }
        public int PaxAdultQty { get; set; }
        public int PaxChildNo { get; set; }
        public decimal PaxChildRate { get; set; }
        public int PaxChildQty { get; set; }
        public int PaxInfantNo { get; set; }
        public decimal PaxInfantRate { get; set; }
        public int PaxInfantQty { get; set; }
        public int CurrencyId { get; set; }
        public decimal ForeignAmount { get; set; }
        public decimal ExhangeRate { get; set; }
        public int FormOfPaymentId { get; set; }
        public int SaleTypeId { get; set; }
        public decimal Commission { get; set; }
        public decimal NonCommissionable { get; set; }
    }

    public class TripLineServiceFee {
        public int ServiceFeeTypeId { get; set; }
        public int SaleTypeId { get; set; }
        public int FormOfPaymentId { get; set; }
        public string Description { get; set; }
        public int PaxNo { get; set; }
        public decimal ItemCost { get; set; }
    }

    public class TripLineRemark {
        public string CrsAirSegmentKey { get; set; }
        public string CrsPassengerKey { get; set; }
        public int CrsRefId { get; set; }
        public string CrsTripLineAirSegmentNo { get; set; }
        public string CrsPassengerNo { get; set; }
        public int TripLineId { get; set; }
        public int TripLineAirSegmentId { get; set; }
        public int PassengerId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Description { get; set; }
        public string Remark { get; set; }
    }

    public class CrsAmadeusExportModel {
        public int AmadeusExportTripId { get; set; }
        public string AmadeusConsultant { get; set; }
        public string AmadeusExportContent1 { get; set; }
        public string AmadeusExportContent2 { get; set; }
    }

    public class CrsGalileoExportModel {
        public int GalileoExportAgencyId { get; set; }
        public int GalileoExportProfileId { get; set; }
        public int GalileoExportTripId { get; set; }
        public string GalileoExportCrsPnrRef { get; set; }
        public string GalileoExportPassengerIds { get; set; }
        public string GalileoExportPassengerDocumentIds { get; set; }
        public string GalileoExportProfileAirlineIds { get; set; }
        public string GalileoExportProfileClubMembershipIds { get; set; }
        public string GalileoExportProfileSpecialRequestIds { get; set; }
        public bool GalileoExportClientAgency { get; set; }
        public bool GalileoExportDebtor { get; set; }

        [Display(Name = "Client Details")]
        public string GalileoExportClientDetails { get; set; }
    }
}