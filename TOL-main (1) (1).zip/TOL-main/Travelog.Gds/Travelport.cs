﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Internal;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Enums;
using Travelog.Gds.Models;
using Travelog.Gds.Services.Travelport.Air;
using Travelog.Gds.Services.Travelport.UniversalRecord;
using AirAvailInfo = Travelog.Gds.Services.Travelport.Air.AirAvailInfo;
using AirAvailInfoFareTokenInfo = Travelog.Gds.Services.Travelport.Air.AirAvailInfoFareTokenInfo;
using AirPricingInfo = Travelog.Gds.Services.Travelport.UniversalRecord.AirPricingInfo;
using AirPricingModifiers = Travelog.Gds.Services.Travelport.Air.AirPricingModifiers;
using AirReservation = Travelog.Gds.Services.Travelport.UniversalRecord.AirReservation;
using AirReservationLocatorCode = Travelog.Gds.Services.Travelport.Air.AirReservationLocatorCode;
using AirServiceResponse1 = Travelog.Gds.Services.Travelport.Air.serviceResponse;
using AirServiceResponse2 = Travelog.Gds.Services.Travelport.Air.serviceResponse1;
using AirServiceResponse3 = Travelog.Gds.Services.Travelport.Air.serviceResponse4;
using AirServiceResponse4 = Travelog.Gds.Services.Travelport.Air.serviceResponse18;
using BaseCoreReq = Travelog.Gds.Services.Travelport.Air.BaseCoreReq;
using BaseSearchReq = Travelog.Gds.Services.Travelport.Air.BaseSearchReq;
using BillingPointOfSaleInfo = Travelog.Gds.Services.Travelport.UniversalRecord.BillingPointOfSaleInfo;
using BookingCodeInfo = Travelog.Gds.Services.Travelport.Air.BookingCodeInfo;
using BookingTraveler = Travelog.Gds.Services.Travelport.UniversalRecord.BookingTraveler;
using BookingTravelerName = Travelog.Gds.Services.Travelport.UniversalRecord.BookingTravelerName;
using City = Travelog.Biz.Dao.Common.City;
using CreditCard = Travelog.Gds.Services.Travelport.UniversalRecord.CreditCard;
using CruisePricingInfo = Travelog.Gds.Services.Travelport.UniversalRecord.CruisePricingInfo;
using CruiseReservation = Travelog.Gds.Services.Travelport.UniversalRecord.CruiseReservation;
using Email = Travelog.Gds.Services.Travelport.UniversalRecord.Email;
using FareInfo = Travelog.Gds.Services.Travelport.UniversalRecord.FareInfo;
using GeneralRemark = Travelog.Gds.Services.Travelport.UniversalRecord.GeneralRemark;
using GuestInformation = Travelog.Gds.Services.Travelport.UniversalRecord.GuestInformation;
using HotelRateDetail = Travelog.Gds.Services.Travelport.UniversalRecord.HotelRateDetail;
using HotelReservation = Travelog.Gds.Services.Travelport.UniversalRecord.HotelReservation;
using ItemsChoiceType1 = Travelog.Gds.Services.Travelport.Air.ItemsChoiceType1;
using LoyaltyCard = Travelog.Gds.Services.Travelport.UniversalRecord.LoyaltyCard;
using OverridePCC = Travelog.Gds.Services.Travelport.UniversalRecord.OverridePCC;
using Passenger = Travelog.Gds.Models.Passenger;
using PassengerClubMembership = Travelog.Gds.Models.PassengerClubMembership;
using PassengerDocument = Travelog.Gds.Models.PassengerDocument;
using PassengerType = Travelog.Biz.Enums.PassengerType;
using PassiveSegment = Travelog.Gds.Services.Travelport.UniversalRecord.PassiveSegment;
using PhoneNumber = Travelog.Gds.Services.Travelport.UniversalRecord.PhoneNumber;
using PhoneNumberType = Travelog.Gds.Services.Travelport.UniversalRecord.PhoneNumberType;
using RailPricingInfo = Travelog.Gds.Services.Travelport.UniversalRecord.RailPricingInfo;
using RailReservation = Travelog.Gds.Services.Travelport.UniversalRecord.RailReservation;
using SearchPassenger = Travelog.Gds.Services.Travelport.Air.SearchPassenger;
using SSR = Travelog.Gds.Services.Travelport.UniversalRecord.SSR;
using State = Travelog.Gds.Services.Travelport.UniversalRecord.State;
using TicketInfo = Travelog.Gds.Services.Travelport.UniversalRecord.TicketInfo;
using TripLineAir = Travelog.Gds.Models.TripLineAir;
using TripLineAirPassenger = Travelog.Gds.Models.TripLineAirPassenger;
using TripLineAirPassengerAirSegment = Travelog.Gds.Models.TripLineAirPassengerAirSegment;
using TripLineAirSegment = Travelog.Gds.Models.TripLineAirSegment;
using TripLineLand = Travelog.Gds.Models.TripLineLand;
using typeAdjustmentType = Travelog.Gds.Services.Travelport.Air.typeAdjustmentType;
using typeBaseAirSegment = Travelog.Gds.Services.Travelport.Air.typeBaseAirSegment;
using typeDoorCount = Travelog.Gds.Services.Travelport.UniversalRecord.typeDoorCount;
using typeElementStatus = Travelog.Gds.Services.Travelport.UniversalRecord.typeElementStatus;
using typeEticketability = Travelog.Gds.Services.Travelport.UniversalRecord.typeEticketability;
using typeStructuredAddress = Travelog.Gds.Services.Travelport.UniversalRecord.typeStructuredAddress;
using typeUnitWeight = Travelog.Gds.Services.Travelport.UniversalRecord.typeUnitWeight;
using UniversalServiceResponse1 = Travelog.Gds.Services.Travelport.UniversalRecord.serviceResponse;
using UniversalServiceResponse2 = Travelog.Gds.Services.Travelport.UniversalRecord.serviceResponse22;
using Vehicle = Travelog.Gds.Services.Travelport.UniversalRecord.Vehicle;
using VehicleRate = Travelog.Gds.Services.Travelport.UniversalRecord.VehicleRate;
using VehicleReservation = Travelog.Gds.Services.Travelport.UniversalRecord.VehicleReservation;

namespace Travelog.Gds {
    public static class Travelport {
        private static IEnumerable<CityCodeModel> GetCityCodes(AppLazyContext lazyContext, int countryId) {
            return lazyContext.City.Where(t => t.CountryId == countryId && !t.HasAirport).Select(t => new CityCodeModel { CityCode = t.Code, CountryId = t.CountryId });
        }

        public static async Task<CrsModel> RetrievePnrAsync(AppLazyContext lazyContext, int customerId, CrsImportModel model, bool isDevelopmentMode) {
            model.Validate();
            model.GalileoCrsPnrRef = model.GalileoCrsPnrRef.ToUpper();

            UniversalServiceResponse1 pnr = null;
            AirServiceResponse4 airTicketPnr = null;

            try {
                pnr = await UniversalReq.RetrievePnr(model.GalileoCrsPnrRef, model.GalileoPcc, customerId, isDevelopmentMode);

                try {
                    airTicketPnr = await AirReq.RetrievePnr(pnr, customerId, isDevelopmentMode);
                }
                catch {
                }
            }
            catch (Exception ex) {
                if (ex.Message.Contains("the request channel timed out", StringComparison.OrdinalIgnoreCase))
                    throw new CrsException(string.Format("PNR {0}: The request timed out. Please try again.", model.GalileoCrsPnrRef), ex);

                if (ex.Message.Contains("pnr(s) sync failed", StringComparison.OrdinalIgnoreCase))
                    throw new CrsException(string.Format("PNR {0}: Synchronisation failed. Please try again later.", model.GalileoCrsPnrRef), ex);

                if (ex.Message.Contains("invalid record locator", StringComparison.OrdinalIgnoreCase) || ex.Message.Contains("unable to retrieve", StringComparison.OrdinalIgnoreCase))
                    throw new UnreportedException(string.Format("PNR {0} not found.", model.GalileoCrsPnrRef), ex);

                if (ex.Message.Contains("universal record has been archived", StringComparison.OrdinalIgnoreCase))
                    throw new UnreportedException(string.Format("PNR {0} has been archived.", model.GalileoCrsPnrRef), ex);

                if (ex.Message.Contains("user is not authorized to retrieve this pnr/ur", StringComparison.OrdinalIgnoreCase))
                    throw new CrsException(string.Format("Your are not authorised to retrieve PNR {0}.", model.GalileoCrsPnrRef), ex);

                if (ex.Message.Contains("unexpected system error", StringComparison.OrdinalIgnoreCase))
                    throw new CrsException(string.Format("PNR {0}: Unexpected system error. Please try again later.", model.GalileoCrsPnrRef), ex);

                if (ex.Message.Contains("procedure", StringComparison.OrdinalIgnoreCase) || ex.Message.Contains("one or more errors occurred", StringComparison.OrdinalIgnoreCase)) {
                    if (ex.Message.Contains("procedure", StringComparison.OrdinalIgnoreCase) || ex.InnerException?.Message.Contains("procedure", StringComparison.OrdinalIgnoreCase) == true)
                        throw new CrsException(string.Format("PNR {0} not found. This may be the result of an incorrect PCC.", model.GalileoCrsPnrRef), ex);

                    throw new CrsException(string.Format("One or more errors occurred when attempting to retrieve PNR {0}.", model.GalileoCrsPnrRef), ex);
                }

                if (!ex.Message.Contains("the reservation", StringComparison.OrdinalIgnoreCase) && !ex.Message.Contains("has no tickets yet", StringComparison.OrdinalIgnoreCase))
                    throw;
            }

            var passengerList = pnr.GetPassengerList(lazyContext);

            var crsModel = new CrsModel {
                Crs = Crs.Galileo,
                CrsPnrRef = model.GalileoCrsPnrRef,
                ClientDetail = pnr.GetClientDetail(lazyContext, model),
                PassengerList = passengerList,
                TripLineAirList = await pnr.GetTripLineAirListAsync(lazyContext, customerId, model, airTicketPnr, passengerList, isDevelopmentMode),
                TripLineLandList = pnr.GetTripLineLandList(lazyContext, customerId, model)
            };

            if (crsModel.ClientDetail.CurrencyId <= 0)
                crsModel.ClientDetail.CurrencyId = AppSettings.Setting(customerId).CurrencyId;

            return crsModel;
        }

        private static ClientDetail GetClientDetail(this UniversalServiceResponse1 pnr, AppLazyContext lazyContext, CrsImportModel model) {
            var bookingTraveler = pnr.UniversalRecordRetrieveRsp.UniversalRecord.BookingTraveler.FirstOrDefault();

            if (bookingTraveler == null)
                return new ClientDetail();

            var address = bookingTraveler.Address?.FirstOrDefault() ?? new typeStructuredAddress();

            string countryCode = address.Country;

            if (address.Country?.Length == 2)
                countryCode = Country.GetCountry(lazyContext, countryCode, true).Code;

            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            string phoneHome = GetPhoneNo(bookingTraveler.PhoneNumber, PhoneNumberType.Home);

            if (string.IsNullOrEmpty(phoneHome))
                phoneHome = GetPhoneNo(bookingTraveler.PhoneNumber, PhoneNumberType.Hotel);

            var clientDetail = new ClientDetail {
                TripId = model.CrsTripId,
                ProfileId = model.CrsProfileId,
                Address1 = textInfo.ToTitleCase((address.Street == null ? string.Empty : string.Join(" ", address.Street)).ToLower()),
                Address2 = string.Empty,
                Locality = textInfo.ToTitleCase((address.City ?? string.Empty).ToLower()),
                Region = address.State?.Value ?? string.Empty,
                PostCode = address.PostalCode,
                CountryCode = countryCode,
                Title = bookingTraveler.BookingTravelerName?.GetNamePart(lazyContext, "Title"),
                FirstName = bookingTraveler.BookingTravelerName?.GetNamePart(lazyContext, "FirstName"),
                LastName = textInfo.ToTitleCase(string.Format("{0} {1}", bookingTraveler.BookingTravelerName?.Last ?? string.Empty, bookingTraveler.BookingTravelerName?.Suffix ?? string.Empty).Trim().ToLower()),
                PhoneHome = phoneHome,
                PhoneWork = GetPhoneNo(bookingTraveler.PhoneNumber, PhoneNumberType.Business),
                Mobile = GetPhoneNo(bookingTraveler.PhoneNumber, PhoneNumberType.Mobile),
                Fax = GetPhoneNo(bookingTraveler.PhoneNumber, PhoneNumberType.Fax),
                Email = (bookingTraveler.Email?.FirstOrDefault()?.EmailID ?? string.Empty).ToLower(),
                PaxAdult = 0,
                PaxChild = 0,
                PaxInfant = 0,
                DepartureDate = DateTime.MinValue,
                BalanceDueDate = DateTime.MinValue,
                ConsultantId = -1,
                AgencyId = model.CrsAgencyId,
                CurrencyId = -1
            };

            if (string.IsNullOrEmpty(clientDetail.PhoneHome) && string.IsNullOrEmpty(clientDetail.PhoneWork) && string.IsNullOrEmpty(clientDetail.Mobile))
                clientDetail.PhoneHome = GetPhoneNo(bookingTraveler.PhoneNumber, PhoneNumberType.Other);

            return clientDetail;
        }

        private static List<Passenger> GetPassengerList(this UniversalServiceResponse1 pnr, AppLazyContext lazyContext) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;
            var passengerList = new List<Passenger>();

            var bookingTraveler = pnr.UniversalRecordRetrieveRsp.UniversalRecord.BookingTraveler;

            if (bookingTraveler == null)
                return passengerList;

            foreach (var row in bookingTraveler) {
                string firstName = row.BookingTravelerName?.GetNamePart(lazyContext, "FirstName");
                string lastName = textInfo.ToTitleCase(string.Format("{0} {1}", row.BookingTravelerName?.Last ?? string.Empty, row.BookingTravelerName?.Suffix ?? string.Empty).Trim().ToLower());

                if (firstName.Length == 0 && lastName.Length == 0)
                    continue;

                var passengerDocumentList = new List<PassengerDocument>();
                var passengerClubMembershipList = new List<PassengerClubMembership>();

                var passenger = new Passenger {
                    CrsKey = row.Key,
                    PassengerType = PassengerType.NotSpecified,
                    Title = row.BookingTravelerName?.GetNamePart(lazyContext, "Title")
                };

                row.ParseSsr(lazyContext, pnr.UniversalRecordRetrieveRsp.UniversalRecord.CreateDate, passenger, passengerDocumentList);

                if (row.LoyaltyCard != null) {
                    var membershipPrograms = row.LoyaltyCard.Where(t => !string.IsNullOrEmpty(t.MembershipProgram)).Select(t => t.MembershipProgram.ToLower()).Distinct().ToArray();
                    var clubMemberships = lazyContext.ClubMembership.Where(t => t.Id > 0 && membershipPrograms.Contains(t.Name.ToLower())).ToList();

                    passengerClubMembershipList.AddRange(row.LoyaltyCard.Select(t1 => new PassengerClubMembership {
                        CrsPassengerKey = row.Key,
                        ClubMembershipId = clubMemberships.SingleOrDefault(t2 => t2.Name.ToLower() == t1.MembershipProgram.ToLower())?.Id ?? -1,
                        ClubMembershipNo = t1.CardNumber,
                        AirlineId = Airline.GetAirline(lazyContext, t1.SupplierCode).Id
                    }));
                }

                passengerList.Add(new Passenger {
                    CrsKey = row.Key,
                    PassengerType = passenger.PassengerType == PassengerType.NotSpecified ? row.GetPassengerType(pnr.UniversalRecordRetrieveRsp.UniversalRecord.CreateDate) : passenger.PassengerType,
                    Title = passenger.Title,
                    FirstName = firstName,
                    LastName = lastName,
                    PhoneNo = GetPhoneNo(row.PhoneNumber, PhoneNumberType.Other),
                    Email = (row.Email?.FirstOrDefault()?.EmailID ?? string.Empty).ToLower(),
                    BirthDate = row.DOBSpecified ? row.DOB : passenger.BirthDate,
                    Age = row.Age.ToInt(),
                    Gender = row.Gender == "M" ? Gender.Male : row.Gender == "F" ? Gender.Female : passenger.Gender,
                    AirPrice = 0,
                    LandPrice = 0,
                    InsurancePrice = 0,
                    TotalPrice = 0,
                    PassengerDocumentList = passengerDocumentList,
                    PassengerClubMembershipList = passengerClubMembershipList
                });
            }

            return passengerList;
        }

        private static async Task<List<TripLineAir>> GetTripLineAirListAsync(this UniversalServiceResponse1 pnr, AppLazyContext lazyContext, int customerId, CrsImportModel model, AirServiceResponse4 airTicketPnr, List<Passenger> passengerList, bool isDevelopmentMode) {
            var tripLineAirList = new List<TripLineAir>();

            if (pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items == null)
                return tripLineAirList;

            int crsId = 1;

            foreach (var airReservation in pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items) {
                string airlineCode = airReservation.TicketingModifiers?.FirstOrDefault()?.PlatingCarrier
                    ?? airReservation.AirPricingInfo?.FirstOrDefault()?.FareInfo.FirstOrDefault()?.Brand?.Carrier
                    ?? airReservation.SupplierLocator?.FirstOrDefault()?.SupplierCode;

                int airlineId = Airline.GetAirline(lazyContext, airlineCode).Id;
                var airSegmentKeys = new List<AirSegmentModel>();

                DateTime.TryParse(pnr.UniversalRecordRetrieveRsp.UniversalRecord.ActionStatus?.FirstOrDefault()?.TicketDate, out DateTime validUntilDate);

                var tripLineAir = new TripLineAir {
                    CrsRefId = crsId++,
                    ValidUntilDate = validUntilDate.Date,
                    AirlineId = airlineId,
                    CrsPnrRef = model.GalileoCrsPnrRef,
                    TripLineAirSegmentList = await pnr.UniversalRecordRetrieveRsp.GetTripLineAirSegmentListAsync(lazyContext, customerId, airReservation, airSegmentKeys, model.GalileoPcc, isDevelopmentMode),
                    TripLineAirPassengerList = airReservation.GetTripLineAirPassengerList(lazyContext, customerId, airlineId, model, pnr, airTicketPnr, airSegmentKeys, passengerList)
                };

                tripLineAirList.Add(tripLineAir);
            }

            return tripLineAirList;
        }

        private static async Task<List<TripLineAirSegment>> GetTripLineAirSegmentListAsync(this UniversalRecordRetrieveRsp pnr, AppLazyContext lazyContext, int customerId, AirReservation airReservation, List<AirSegmentModel> airSegmentKeys, string pseudoCityCode, bool isDevelopmentMode) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;
            var tripLineAirSegmentList = new List<TripLineAirSegment>();

            if (airReservation.AirSegment == null)
                return tripLineAirSegmentList;

            AirServiceResponse1 flightDetails = null;
            var airSegmentList = new List<typeBaseAirSegment>();

            try {
                foreach (var airSegment in airReservation.AirSegment) {
                    string departureTime = airSegment.DepartureTime;
                    string arrivalTime = airSegment.ArrivalTime;

                    DateTime departureDate = Utils.GetIso8601DateTime(departureTime);
                    DateTime arrivalDate = Utils.GetIso8601DateTime(arrivalTime);

                    if (departureDate.Date <= DateTime.Today || arrivalDate.Date <= DateTime.Today) {
                        var dayOfWeek = arrivalDate.DayOfWeek;
                        int days = (DateTime.Today - arrivalDate).Days + 1;

                        departureDate = departureDate.AddDays(days);
                        arrivalDate = arrivalDate.AddDays(days);

                        days = (int)dayOfWeek - (int)arrivalDate.DayOfWeek;

                        if (days <= 0)
                            days += 7;

                        departureDate = departureDate.AddDays(days);
                        arrivalDate = arrivalDate.AddDays(days);

                        departureTime = Utils.FormatIso8601DateTime(departureDate, true);
                        arrivalTime = Utils.FormatIso8601DateTime(arrivalDate, true);
                    }

                    airSegmentList.Add(new typeBaseAirSegment {
                        Key = airSegment.Key,
                        Status = airSegment.Status,
                        Group = airSegment.Group,
                        Carrier = airSegment.Carrier,
                        FlightNumber = airSegment.FlightNumber,
                        Origin = airSegment.Origin,
                        Destination = airSegment.Destination,
                        Distance = airSegment.Distance,
                        DepartureTime = departureTime,
                        ArrivalTime = arrivalTime,
                        FlightTime = airSegment.FlightTime,
                        FlightDetailsRef = airSegment.FlightDetailsRef?.Select(t => new Services.Travelport.Air.FlightDetailsRef { Key = t.Key }).ToArray(),
                        ParticipantLevel = airSegment.ParticipantLevel,
                        LinkAvailability = airSegment.LinkAvailability,
                        PolledAvailabilityOption = airSegment.PolledAvailabilityOption,
                        OptionalServicesIndicator = airSegment.OptionalServicesIndicator,
                        AvailabilitySource = airSegment.AvailabilitySource,
                        AvailabilityDisplayType = airSegment.AvailabilityDisplayType,
                        ETicketability = airSegment.ETicketability == typeEticketability.Yes ? Services.Travelport.Air.typeEticketability.Yes : airSegment.ETicketability == typeEticketability.No ? Services.Travelport.Air.typeEticketability.No : airSegment.ETicketability == typeEticketability.Required ? Services.Travelport.Air.typeEticketability.Required : Services.Travelport.Air.typeEticketability.Ticketless,
                        Equipment = airSegment.Equipment,
                        ClassOfService = airSegment.ClassOfService,
                        ChangeOfPlane = airSegment.ChangeOfPlane,
                        ProviderCode = airSegment.ProviderCode,
                        HostTokenRef = airSegment.HostTokenRef,
                        FlownSegment = airSegment.FlownSegment,
                        AirAvailInfo = airSegment.AirAvailInfo?.Select(row => new AirAvailInfo {
                            ProviderCode = airSegment.ProviderCode,
                            HostTokenRef = airSegment.HostTokenRef,
                            BookingCodeInfo = row.BookingCodeInfo.Select(t => new BookingCodeInfo {
                                BookingCounts = t.BookingCounts,
                                CabinClass = t.CabinClass
                            }).ToArray(),
                            FareTokenInfo = row.FareTokenInfo.Select(t => new AirAvailInfoFareTokenInfo {
                                FareInfoRef = t.FareInfoRef,
                                HostTokenRef = t.HostTokenRef
                            }).ToArray()
                        }).ToArray()
                    });
                }

                flightDetails = await AirReq.RetrieveFlightDetails(airSegmentList.ToArray(), customerId, pseudoCityCode, isDevelopmentMode);
            }
            catch (Exception ex) {
                if (!ex.Message.Contains("SERVICE DATA NOT AVAILABLE", StringComparison.OrdinalIgnoreCase)) {
                    if (ex.Message.Contains("the request channel timed out", StringComparison.OrdinalIgnoreCase))
                        throw new CrsException("The request timed out. Please try again.", ex);

                    throw;
                }
            }

            AirServiceResponse3 airPrice = null;
            int count = -1;

            try {
                airPrice = await AirReq.RetrieveAirPrice(pnr, airSegmentList.ToArray(), customerId, isDevelopmentMode);
            }
            catch {
            }

            foreach (var airSegment in airReservation.AirSegment) {
                count++;

                var departureCity = City.GetCity(lazyContext, airSegment.Origin);
                var arrivalCity = City.GetCity(lazyContext, airSegment.Destination);

                airSegmentKeys.Add(new AirSegmentModel {
                    Key = airSegment.Key,
                    FlightNo = airSegment.FlightNumber,
                    Class = airSegment.ClassOfService,
                    DepartureCityCode = departureCity.Code,
                    DepartureCountryId = departureCity.CountryId,
                    DepartureTime = airSegment.DepartureTime,
                    ArrivalCityCode = arrivalCity.Code,
                    ArrivalCountryId = arrivalCity.CountryId,
                    AirlineCode = airSegment.Carrier,
                    ArrivalTime = airSegment.ArrivalTime
                });

                var airportType = departureCity.Country.Code == AppSettings.Setting(customerId).CountryCode && arrivalCity.Country.Code == AppSettings.Setting(customerId).CountryCode ? AirportType.Domestic : AirportType.International;

                int distance = 0;
                string flightTime = string.Empty;
                string transitStops = "Non-Stop";

                DateTime departureDate = Utils.GetIso8601DateTime(airSegment.DepartureTime);
                DateTime arrivalDate = Utils.GetIso8601DateTime(airSegment.ArrivalTime);

                var baseAirSegment = flightDetails?.FlightDetailsRsp.AirSegment?.Where(t => t.Key == airSegment.Key).SingleOrDefault(t1 => t1.FlightDetails?.Any(t2 => t2.Origin == airSegment.Origin) == true && t1.FlightDetails.Any(t2 => t2.Destination == airSegment.Destination));
                decimal co2Emissions = flightDetails?.FlightDetailsRsp.CO2Emissions.Sum(t1 => t1.CO2Emission.Where(t2 => t2.AirSegmentRef == airSegment.Key).Sum(t2 => (decimal?)t2.Value) ?? 0) ?? 0;

                if (airPrice != null)
                    distance = Math.Round(decimal.Parse(airPrice.AirPriceRsp.AirItinerary?.AirSegment?.FirstOrDefault(t => t.Origin == airSegment.Origin && t.Destination == airSegment.Destination)?.Distance ?? "0") * AppConstants.MilesToKm).ToInt();

                if (!string.IsNullOrEmpty(baseAirSegment?.FlightDetails[0].FlightTime))
                    flightTime = baseAirSegment.FlightDetails.Sum(t => t.FlightTime.ToInt()).MinutesToHoursMinutes();

                if (string.IsNullOrEmpty(flightTime) && !string.IsNullOrEmpty(airSegment?.FlightTime))
                    flightTime = airSegment.FlightTime.MinutesToHoursMinutes();

                string meals = string.Join("; ", baseAirSegment?.FlightDetails?.Where(t => t.Meals != null)?.SelectMany(t => t.Meals)?.Select(t => MealServed.GetMealServed(lazyContext, Crs.Galileo, t.ToString()).Name).Where(t => t?.Length > 0) ?? Array.Empty<string>());

                if (meals?.Length == 0)
                    meals = string.Join("; ", airSegment.FlightDetails.Where(t => t.Meals != null)?.SelectMany(t => t.Meals)?.Select(t => MealServed.GetMealServed(lazyContext, Crs.Galileo, t.ToString()).Name).Where(t => t?.Length > 0) ?? Array.Empty<string>());

                DateTime.TryParse(airSegment.DepartureTime.Substring(0, airSegment.DepartureTime.Length - 6), out departureDate);
                DateTime.TryParse(airSegment.ArrivalTime.Substring(0, airSegment.ArrivalTime.Length - 6), out arrivalDate);

                int days = (arrivalDate.Date - departureDate.Date).Days;
                Enum.TryParse(days.ToStringExt(), out InternationalDateOffset internationalDateOffset);

                if (baseAirSegment?.FlightDetails?.Length > 1) {
                    bool firstRow = true;

                    foreach (var row in baseAirSegment.FlightDetails) {
                        if (firstRow) {
                            transitStops = string.Format("Arrive {0} Terminal {1} at {2}", row.Destination, row.DestinationTerminal, row.ArrivalTime.Split('T')[1].Substring(0, 5));
                        }
                        else {
                            transitStops = string.Format("{0}; Depart {1} Terminal {2} at {3}{4}", transitStops, row.Origin, row.OriginTerminal, row.DepartureTime.Split('T')[1].Substring(0, 5), Environment.NewLine);
                        }

                        firstRow = !firstRow;
                    }

                    transitStops = transitStops.TrimEnd(Environment.NewLine);
                }

                string operatingAirline = Airline.GetAirline(lazyContext, airSegment.CodeshareInfo?.OperatingCarrier).Name.Replace("Not Specified", string.Empty);

                if (operatingAirline.Length == 0 && airSegment.SegmentRemark?.Length > 0)
                    operatingAirline = textInfo.ToTitleCase(airSegment.SegmentRemark[0].Value.ToLower());

                tripLineAirSegmentList.Add(new TripLineAirSegment {
                    CrsKey = airSegment.Key,
                    TripStatus = Trip.GetTripStatus(airSegment.Status),
                    DepartureCityId = departureCity.Id,
                    ArrivalCityId = arrivalCity.Id,
                    Class = airSegment.ClassOfService,
                    FlightNo = string.Concat(airSegment.Carrier, airSegment.FlightNumber),
                    CheckInTime = string.Empty,
                    DepartureDate = departureDate.Date,
                    DepartureTime = airSegment.DepartureTime.Split('T')[1].Substring(0, 5),
                    ArrivalDate = arrivalDate.Date,
                    ArrivalTime = airSegment.ArrivalTime.Split('T')[1].Substring(0, 5),
                    FlightTime = flightTime,
                    InternationalDateOffset = internationalDateOffset,
                    AirportType = airportType,
                    DepartureTerminal = baseAirSegment?.FlightDetails.First()?.OriginTerminal ?? string.Empty,
                    ArrivalTerminal = baseAirSegment?.FlightDetails.Last()?.DestinationTerminal ?? string.Empty,
                    AirlinePnr = airReservation?.SupplierLocator?.FirstOrDefault(t => t.SupplierCode == airSegment.Carrier)?.SupplierLocatorCode ?? string.Empty,
                    AircraftId = Aircraft.GetAircraft(lazyContext, airSegment.Equipment).Id,
                    Operator = operatingAirline,
                    DistanceFlownKm = distance,
                    CO2Emissions = co2Emissions,
                    Meals = meals,
                    TransitStops = transitStops
                });
            }

            return tripLineAirSegmentList;
        }

        private static List<TripLineAirPassenger> GetTripLineAirPassengerList(this AirReservation airReservation, AppLazyContext lazyContext, int customerId, int airlineId, CrsImportModel model, UniversalServiceResponse1 pnr, AirServiceResponse4 airTicketPnr, List<AirSegmentModel> airSegmentKeys, List<Passenger> passengerList) {
            var tripLineAirPassengerList = new List<TripLineAirPassenger>();

            if (airReservation.DocumentInfo == null && airReservation.AirPricingInfo == null) {
                pnr.AddTripLineAirPassenger(lazyContext, airlineId, model, tripLineAirPassengerList, airSegmentKeys, passengerList);
            }
            else if (airReservation.DocumentInfo == null) {
                foreach (var airPricingInfo in airReservation.AirPricingInfo) {
                    foreach (var fareInfo in airPricingInfo.FareInfo) {
                        airReservation.AddTripLineAirPassenger(lazyContext, customerId, airlineId, model, airPricingInfo, fareInfo, pnr, airTicketPnr, tripLineAirPassengerList, airSegmentKeys);
                    }
                }
            }
            else if (airReservation.AirPricingInfo != null) {
                foreach (var ticketInfo in airReservation.DocumentInfo.TicketInfo) {
                    var airPricingInfo = airReservation.AirPricingInfo.Single(t => t.Key == ticketInfo.AirPricingInfoRef);

                    foreach (var fareInfo in airPricingInfo.FareInfo) {
                        airReservation.AddTripLineAirPassenger(lazyContext, customerId, airlineId, model, airPricingInfo, fareInfo, pnr, airTicketPnr, tripLineAirPassengerList, airSegmentKeys, ticketInfo);
                    }
                }
            }

            string[] crsPassengerKeys = tripLineAirPassengerList.SelectMany(t => t.TripLineAirPassengerAirSegmentList).Select(t => t.CrsPassengerKey).Distinct().ToArray();
            string[] crsAirSegmentKeys = tripLineAirPassengerList.SelectMany(t => t.TripLineAirPassengerAirSegmentList).Select(t => t.CrsAirSegmentKey).Distinct().ToArray();
            crsAirSegmentKeys = airSegmentKeys.Where(t => !crsAirSegmentKeys.Contains(t.Key)).Select(t => t.Key).Distinct().ToArray();

            if (crsAirSegmentKeys.Length > 0) {
                foreach (var tripLineAirPassenger in tripLineAirPassengerList) {
                    tripLineAirPassenger.TripLineAirPassengerAirSegmentList = tripLineAirPassenger.TripLineAirPassengerAirSegmentList.Where(t => !crsAirSegmentKeys.Contains(t.CrsAirSegmentKey)).ToList();
                }

                if (crsPassengerKeys.Length > 0)
                    pnr.AddTripLineAirPassenger(lazyContext, airlineId, model, tripLineAirPassengerList, airSegmentKeys.Where(t => crsAirSegmentKeys.Contains(t.Key)).ToList(), passengerList.Where(t => crsPassengerKeys.Contains(t.CrsKey)).ToList());
            }

            return tripLineAirPassengerList;
        }

        private static void AddTripLineAirPassenger(this UniversalServiceResponse1 pnr, AppLazyContext lazyContext, int airlineId, CrsImportModel model, List<TripLineAirPassenger> tripLineAirPassengerList, List<AirSegmentModel> airSegmentKeys, List<Passenger> passengerList) {
            foreach (var passenger in passengerList) {
                tripLineAirPassengerList.Add(new TripLineAirPassenger {
                    CrsPassengerKey = passenger.CrsKey,
                    CreditorId = model.CrsCreditorAirId,
                    SupplierId = model.CrsSupplierAirId,
                    AirlineId = airlineId,
                    SaleTypeId = -1,
                    FormOfPaymentId = Biz.Dao.Common.FormOfPayment.GetFormOfPayment(lazyContext, Crs.Galileo, (pnr.UniversalRecordRetrieveRsp.UniversalRecord.FormOfPayment?.FirstOrDefault()?.Item as CreditCard)?.Type).Id,
                    IssueDate = DateTime.MinValue,
                    TicketNo = string.Empty,
                    FareCalc = string.Empty
                });

                var tripLineAirPassengerAirSegmentList = tripLineAirPassengerList.Last().TripLineAirPassengerAirSegmentList;

                foreach (var airSegment in airSegmentKeys) {
                    tripLineAirPassengerAirSegmentList.Add(new TripLineAirPassengerAirSegment {
                        CrsAirSegmentKey = airSegment.Key,
                        CrsPassengerKey = passenger.CrsKey,
                        DepartureCityCode = airSegment.DepartureCityCode,
                        ArrivalCityCode = airSegment.ArrivalCityCode,
                        SeatNo = string.Empty,
                        SeatStatus = SeatStatus.NotSpecified,
                        BaggageAllowance = 0,
                        BaggageUnit = BaggageUnit.Piece,
                        FareBasis = string.Empty,
                        TicketDesignator = string.Empty,
                        TourCode = string.Empty,
                        Amount = 0,
                        Tax = 0,
                        TicketedFare = 0,
                        NonCommissionable = 0,
                        Commission = 0,
                        TicketMethod = TicketMethod.ETicket
                    });
                }
            }
        }

        private static void AddTripLineAirPassenger(this AirReservation airReservation, AppLazyContext lazyContext, int customerId, int airlineId, CrsImportModel model, AirPricingInfo airPricingInfo, FareInfo fareInfo, UniversalServiceResponse1 pnr, AirServiceResponse4 airTicketPnr, List<TripLineAirPassenger> tripLineAirPassengers, List<AirSegmentModel> airSegmentKeys, TicketInfo ticketInfo = null) {
            string currencyCode = string.Empty;
            string ticketNo = string.Empty;
            string fareBasis = string.Empty;
            string ticketDesignator = string.Empty;
            string tourCode = string.Empty;

            string seatNo = string.Empty;
            var seatStatus = SeatStatus.NotSpecified;

            int baggageAllowance = 0;
            var baggageUnit = BaggageUnit.Piece;

            int saleTypeId;
            decimal taxRate = 0;

            if (airReservation.AirSegment.All(t => t.Origin == fareInfo.Origin && t.Destination == fareInfo.Destination && City.GetCity(lazyContext, t.Origin).Country.CountryZone == CountryZone.Domestic && City.GetCity(lazyContext, t.Destination).Country.CountryZone == CountryZone.Domestic)) {
                saleTypeId = AppSettings.Setting(customerId).CrsDomesticAirSaleTypeId;
            }
            else {
                saleTypeId = AppSettings.Setting(customerId).CrsInternationalAirSaleTypeId;
            }

            if (lazyContext.SaleType.Find(saleTypeId).IsTaxApplicable)
                taxRate = CustomerSettings.GetTaxRate(customerId, DateTime.Parse(airReservation.CreateDate));

            int currencyId = fareInfo.GetCurrency(lazyContext, ref currencyCode).Id;

            if (currencyId <= 0)
                currencyId = airPricingInfo.GetCurrency(lazyContext, ref currencyCode).Id;

            decimal exchangeRate = fareInfo.GetExchangeRate(lazyContext, currencyCode);

            if (exchangeRate == 0)
                exchangeRate = airPricingInfo.GetExchangeRate(lazyContext, currencyCode);

            baggageAllowance = fareInfo.BaggageAllowance?.NumberOfPieces.ToInt() ?? 0;

            if (baggageAllowance == 0 && fareInfo.BaggageAllowance?.MaxWeight != null) {
                baggageAllowance = fareInfo.BaggageAllowance.MaxWeight.Value.ToInt();
                baggageUnit = fareInfo.BaggageAllowance.MaxWeight.Unit == typeUnitWeight.Kilograms ? BaggageUnit.Kilogram : BaggageUnit.Piece;
            }

            fareBasis = fareInfo.FareBasis;
            ticketDesignator = fareInfo.FareTicketDesignator?[0]?.Value ?? string.Empty;
            baggageAllowance = fareInfo.BaggageAllowance?.NumberOfPieces.ToInt() ?? 0;

            if (baggageAllowance == 0 && fareInfo.BaggageAllowance?.MaxWeight != null) {
                baggageAllowance = fareInfo.BaggageAllowance.MaxWeight.Value.ToInt();
                baggageUnit = fareInfo.BaggageAllowance.MaxWeight.Unit == typeUnitWeight.Kilograms ? BaggageUnit.Kilogram : BaggageUnit.Piece;
            }

            string fareCalc = airPricingInfo.FareCalc;
            bool isTicketed = false;

            foreach (var passengerType in airPricingInfo.PassengerType) {
                var bookingTraveler = pnr.UniversalRecordRetrieveRsp.UniversalRecord.BookingTraveler.FirstOrDefault(t => t.Key == passengerType.BookingTravelerRef);
                var tripLineAirPassenger = tripLineAirPassengers.SingleOrDefault(t => t.CrsPassengerKey == passengerType.BookingTravelerRef && t.FareCalc == fareCalc);

                var etr = airTicketPnr?.AirRetrieveDocumentRsp.ETR?.FirstOrDefault(t => t.BookingTraveler.Key == passengerType.BookingTravelerRef);

                if (etr?.Ticket?.Length > 0) {
                    isTicketed = true;
                    ticketNo = etr.Ticket.GetTicketNo();
                }

                if (tripLineAirPassenger == null) {
                    if (etr == null && ticketInfo != null) {
                        ticketNo = ticketInfo.Number ?? string.Empty;

                        if (ticketInfo.ConjunctedTicketInfo?.Length > 0)
                            ticketNo = string.Format("{0}/{1}", ticketNo, ticketInfo.ConjunctedTicketInfo[ticketInfo.ConjunctedTicketInfo.Length - 1]?.Number ?? string.Empty).TrimEnd('/');
                    }

                    tripLineAirPassenger = new TripLineAirPassenger {
                        CrsPassengerKey = passengerType.BookingTravelerRef,
                        CreditorId = model.CrsCreditorAirId,
                        SupplierId = model.CrsSupplierAirId,
                        AirlineId = airlineId,
                        SaleTypeId = saleTypeId,
                        FormOfPaymentId = Biz.Dao.Common.FormOfPayment.GetFormOfPayment(lazyContext, Crs.Galileo, (pnr.UniversalRecordRetrieveRsp.UniversalRecord.FormOfPayment?.FirstOrDefault()?.Item as CreditCard)?.Type).Id,
                        IssueDate = DateTime.MinValue,
                        TicketNo = ticketNo,
                        FareCalc = fareCalc
                    };

                    tripLineAirPassengers.Add(tripLineAirPassenger);
                }

                var coupons = Array.Empty<Coupon>().ToList();

                if (isTicketed) {
                    fareCalc = etr.FareCalc ?? fareCalc;
                    tourCode = etr.TourCode ?? string.Empty;
                    coupons = etr.Ticket.SelectMany(t => t.Coupon ?? Array.Empty<Coupon>()).ToList();
                }

                foreach (var airSegment in airSegmentKeys.Where(t => t.DepartureCityCode == fareInfo.Origin && t.ArrivalCityCode == fareInfo.Destination)) {
                    if (tripLineAirPassenger.TripLineAirPassengerAirSegmentList.Any(t => t.CrsAirSegmentKey == airSegment.Key && t.DepartureCityCode == airSegment.DepartureCityCode && t.ArrivalCityCode == airSegment.ArrivalCityCode))
                        continue;

                    decimal airExchangeRate = 0;
                    decimal ticketedFare = 0;
                    decimal nonCommissionable = 0;
                    decimal commission = 0;

                    TicketMethod ticketMethod;

                    var airSeatAssignment = pnr.UniversalRecordRetrieveRsp.UniversalRecord.BookingTraveler.FirstOrDefault(t => t.Key == passengerType.BookingTravelerRef)?.AirSeatAssignment?.FirstOrDefault(t => t.SegmentRef == airSegment.Key);

                    if (airSeatAssignment != null) {
                        seatNo = airSeatAssignment.Seat;
                        seatStatus = Biz.Dao.ClientLedger.TripLineAirPassengerAirSegment.GetSeatStatus(airSeatAssignment.Status);
                    }

                    if (isTicketed) {
                        var coupon = coupons?.FirstOrDefault(t => t.MarketingFlightNumber == airSegment.FlightNo && t.BookingClass == airSegment.Class && t.Origin == airSegment.DepartureCityCode && t.Destination == airSegment.ArrivalCityCode && t.DepartureTime == airSegment.DepartureTime);

                        fareBasis = coupon?.FareBasis ?? fareBasis;
                        ticketDesignator = coupon?.TicketDesignator?[0].Value ?? ticketDesignator;

                        ticketedFare = etr.AirPricingInfo.GetAmount(exchangeRate, ref airExchangeRate);
                        ticketedFare += etr.AirPricingInfo.GetLocalTax(customerId, airExchangeRate, taxRate);

                        nonCommissionable = etr.AirPricingInfo.GetNonCommissionable(customerId, exchangeRate, taxRate);
                        commission = etr.AirPricingInfo.GetCommission(exchangeRate);

                        ticketMethod = etr.AirPricingInfo.ETicketabilitySpecified && airPricingInfo.ETicketability == typeEticketability.No ? TicketMethod.Hand : TicketMethod.ETicket;
                    }
                    else {
                        ticketedFare = airPricingInfo.GetAmount(exchangeRate, ref airExchangeRate);
                        ticketedFare += airPricingInfo.GetLocalTax(customerId, airExchangeRate, taxRate);

                        nonCommissionable = airPricingInfo.GetNonCommissionable(customerId, exchangeRate, taxRate);
                        commission = airPricingInfo.GetCommission(exchangeRate);

                        ticketMethod = airPricingInfo.ETicketabilitySpecified && airPricingInfo.ETicketability == typeEticketability.No ? TicketMethod.Hand : TicketMethod.ETicket;
                    }

                    decimal amount = airExchangeRate == 0 ? 0 : Math.Round(GetAirSegmentAmount(lazyContext, airPricingInfo.FareCalc, fareBasis, airSegment.ArrivalCityCode, airSegment.ArrivalCountryId, airSegment.AirlineCode) / airExchangeRate, 2);
                    decimal tax = Math.Round(amount * taxRate, 2);

                    tripLineAirPassenger.TripLineAirPassengerAirSegmentList.Add(new TripLineAirPassengerAirSegment {
                        CrsAirSegmentKey = airSegment.Key,
                        CrsPassengerKey = tripLineAirPassenger.CrsPassengerKey,
                        DepartureCityCode = airSegment.DepartureCityCode,
                        ArrivalCityCode = airSegment.ArrivalCityCode,
                        SeatNo = seatNo,
                        SeatStatus = seatStatus,
                        BaggageAllowance = baggageAllowance,
                        BaggageUnit = baggageUnit,
                        FareBasis = fareBasis,
                        TicketDesignator = ticketDesignator,
                        TourCode = tourCode,
                        Amount = amount,
                        Tax = tax,
                        TicketedFare = ticketedFare,
                        NonCommissionable = nonCommissionable,
                        Commission = commission,
                        TicketMethod = ticketMethod
                    });
                }
            }
        }

        private static List<TripLineLand> GetTripLineLandList(this UniversalServiceResponse1 pnr, AppLazyContext lazyContext, int customerId, CrsImportModel model) {
            var tripLineLands = new List<TripLineLand>();
            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            var serviceTypeRateBasis = ServiceTypeRateBasisBase.AccommodationPerPerson;
            var passengerClassification = PassengerClassification.Individual;

            int crsId = -1;

            int paxAdultNo = 0;
            int paxChildNo = 0;
            int paxInfantNo = 0;

            int paxAdultQty = 0;
            int paxChildQty = 0;
            int paxInfantQty = 0;

            decimal paxAdultRate = 0;
            decimal paxChildRate = 0;
            decimal paxInfantRate = 0;

            if (pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items1 != null) {
                foreach (var row in pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items1) {
                    var hotelRateDetail = row.HotelRateDetail?.FirstOrDefault();

                    var supplier = Supplier.GetSupplier(lazyContext, Crs.Galileo, row.HotelProperty?.HotelCode, row.HotelProperty?.Name);
                    var city = City.GetCity(lazyContext, row.HotelProperty?.HotelLocation);

                    string supplierCityCode = city.Code;
                    string countryCode = city.Country.Code;
                    string currencyCode = null;

                    int currencyId = hotelRateDetail?.GetCurrency(lazyContext, ref currencyCode).Id ?? -1;
                    decimal exchangeRate = hotelRateDetail?.GetExchangeRate(lazyContext, currencyCode) ?? 0;

                    int saleTypeId;

                    if (countryCode == AppSettings.Setting(customerId).CountryCode) {
                        saleTypeId = AppSettings.Setting(customerId).CrsDomesticAccommodationSaleTypeId;
                    }
                    else {
                        saleTypeId = AppSettings.Setting(customerId).CrsInternationalAccommodationSaleTypeId;
                    }

                    decimal taxRate = 0;

                    if (lazyContext.SaleType.Find(saleTypeId).IsTaxApplicable)
                        taxRate = CustomerSettings.GetTaxRate(customerId, DateTime.Parse(row.CreateDate));

                    DateTime startDate = row.HotelStay?.CheckinDate.Date ?? DateTime.MinValue;
                    string startTime = row.HotelStay?.CheckinDate.ToString("HH:mm") ?? string.Empty;

                    DateTime endDate = row.HotelStay?.CheckoutDate.Date ?? DateTime.MinValue;
                    string endTime = row.HotelStay?.CheckoutDate.ToString("HH:mm") ?? string.Empty;

                    int duration = Common.GetDuration(TripLineType.Accommodation, startDate, endDate, DurationCoverageType.Nights);

                    row.GetPaxValues(exchangeRate, duration, ref serviceTypeRateBasis, ref passengerClassification, ref paxAdultNo, ref paxChildNo, ref paxInfantNo, ref paxAdultQty, ref paxChildQty, ref paxInfantQty, ref paxAdultRate, ref paxChildRate, ref paxInfantRate);
                    decimal foreignAmount = row.GetForeignAmount(lazyContext, duration);

                    tripLineLands.Add(new TripLineLand {
                        CrsRefId = crsId--,
                        CrsKey = row.HotelProperty?.Key ?? string.Empty,
                        TripLineType = TripLineType.Accommodation,
                        TripStatus = Trip.GetTripStatus(row.Status),
                        ConfirmationNo = row.BookingConfirmation ?? string.Empty,
                        CreditorId = model.CrsCreditorLandId,
                        SupplierId = supplier.Id,
                        SupplierName = supplier.Id <= 0 ? textInfo.ToTitleCase((row.HotelProperty?.Name ?? string.Empty).ToLower()) : supplier.Name,
                        SupplierChainId = SupplierChain.GetSupplierChain(lazyContext, Crs.Galileo, row.HotelProperty?.HotelChain, row.HotelProperty?.HotelChain).Id,
                        SupplierCityCode = supplierCityCode,
                        SupplierCrsCode = row.HotelProperty?.HotelCode ?? string.Empty,
                        SupplierAddress1 = row.HotelProperty?.PropertyAddress?.Length > 0 ? textInfo.ToTitleCase((row.HotelProperty?.PropertyAddress?[0] ?? string.Empty).ToLower()) : string.Empty,
                        SupplierAddress2 = string.Empty,
                        SupplierLocality = row.HotelProperty?.PropertyAddress?.Length > 1 ? textInfo.ToTitleCase((row.HotelProperty?.PropertyAddress?[1] ?? string.Empty).ToLower()) : string.Empty,
                        SupplierRegion = row.HotelProperty?.PropertyAddress?.Length > 2 ? row.HotelProperty?.PropertyAddress?[2] : string.Empty,
                        SupplierPostCode = string.Empty,
                        SupplierCountryCode = countryCode,
                        SupplierContactPhoneWork = GetPhoneNo(row.HotelProperty?.PhoneNumber, PhoneNumberType.Other),

                        StartDate = startDate,
                        StartTime = startTime,
                        StartDetails = string.Empty,
                        StartAddress1 = string.Empty,
                        StartAddress2 = string.Empty,
                        StartLocality = string.Empty,
                        StartRegion = string.Empty,
                        StartPostCode = string.Empty,
                        StartCountryCode = string.Empty,
                        EndDate = endDate,
                        EndTime = endTime,
                        EndDetails = string.Empty,
                        EndAddress1 = string.Empty,
                        EndAddress2 = string.Empty,
                        EndLocality = string.Empty,
                        EndRegion = string.Empty,
                        EndPostCode = string.Empty,
                        EndCountryCode = string.Empty,
                        SupplierServiceDescription = hotelRateDetail?.GetSupplierService() ?? string.Empty,
                        Comments = GetComments(row.GeneralRemark),
                        Inclusions = hotelRateDetail?.GetInclusions() ?? string.Empty,

                        DurationCoverageType = DurationCoverageType.Nights,
                        Duration = duration,
                        PayForDuration = duration,
                        ServiceTypeRateBasis = serviceTypeRateBasis,
                        PassengerClassification = passengerClassification,
                        PaxAdultNo = paxAdultNo,
                        PaxAdultQty = paxAdultQty,
                        PaxAdultRate = paxAdultRate,
                        PaxChildNo = paxChildNo,
                        PaxChildQty = paxChildQty,
                        PaxChildRate = paxChildRate,
                        PaxInfantNo = paxInfantNo,
                        PaxInfantQty = paxInfantQty,
                        PaxInfantRate = paxInfantRate,
                        NonCommissionable = hotelRateDetail?.GetNonCommissionable(customerId, exchangeRate, taxRate) ?? 0,
                        Commission = row.GetCommission(exchangeRate),
                        FormOfPaymentId = Biz.Dao.Common.FormOfPayment.GetFormOfPayment(lazyContext, Crs.Galileo, (pnr.UniversalRecordRetrieveRsp.UniversalRecord.FormOfPayment?.FirstOrDefault()?.Item as CreditCard)?.Type).Id,
                        SaleTypeId = saleTypeId,
                        CurrencyId = currencyId,
                        ForeignAmount = foreignAmount,
                        ExhangeRate = exchangeRate
                    });
                }
            }

            if (pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items2 != null) {
                foreach (var row in pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items2) {
                    var city = City.GetCity(lazyContext, row.VehicleDateLocation?.PickupLocation);

                    string cityName = city.Name;
                    string supplierCityCode = city.Code;
                    string pickupCountryCode = city.Country.Code;

                    city = City.GetCity(lazyContext, row.VehicleDateLocation?.ReturnLocation);
                    string returnCountryCode = city.Country.Code;

                    string currencyCode = null;

                    int currencyId = row.Vehicle?.VehicleRate?.GetCurrency(lazyContext, ref currencyCode).Id ?? -1;
                    decimal exchangeRate = row.Vehicle?.VehicleRate?.GetExchangeRate(lazyContext, currencyCode) ?? 0;

                    int saleTypeId;

                    if (pickupCountryCode == AppSettings.Setting(customerId).CountryCode) {
                        saleTypeId = AppSettings.Setting(customerId).CrsDomesticTransportSaleTypeId;
                    }
                    else {
                        saleTypeId = AppSettings.Setting(customerId).CrsInternationalTransportSaleTypeId;
                    }

                    decimal taxRate = 0;

                    if (lazyContext.SaleType.Find(saleTypeId).IsTaxApplicable)
                        taxRate = CustomerSettings.GetTaxRate(customerId, DateTime.Parse(row.CreateDate));

                    DateTime startDate = row.VehicleDateLocation?.PickupDateTime == null ? DateTime.MinValue : DateTime.Parse(row.VehicleDateLocation.PickupDateTime.Left(10)).Date;
                    string startTime = row.VehicleDateLocation?.PickupDateTime == null ? string.Empty : row.VehicleDateLocation.PickupDateTime.Substring(11, 5);

                    DateTime endDate = row.VehicleDateLocation?.ReturnDateTime == null ? DateTime.MinValue : DateTime.Parse(row.VehicleDateLocation.ReturnDateTime.Left(10)).Date;
                    string endTime = row.VehicleDateLocation?.ReturnDateTime == null ? string.Empty : row.VehicleDateLocation.ReturnDateTime.Substring(11, 5);

                    int duration = Common.GetDuration(TripLineType.Transport, startDate, endDate, DurationCoverageType.Days);

                    row.GetPaxValues(exchangeRate, duration, ref serviceTypeRateBasis, ref passengerClassification, ref paxAdultNo, ref paxChildNo, ref paxInfantNo, ref paxAdultQty, ref paxChildQty, ref paxInfantQty, ref paxAdultRate, ref paxChildRate, ref paxInfantRate);
                    decimal foreignAmount = row.GetForeignAmount(lazyContext, duration);

                    int supplierChainId = SupplierChain.GetSupplierChain(lazyContext, Crs.Galileo, row.Vehicle?.VendorCode).Id;
                    int supplierId = -1;
                    string supplierName = string.Empty;

                    string supplierCrsCode = string.Format("{0}{1}{2}{3:D2}", row.Vehicle?.VendorCode, row.VehicleDateLocation?.PickupLocation, row.VehicleDateLocation?.PickupLocationType.GetEnumDescription().Left(1), int.Parse(row.VehicleDateLocation?.PickupLocationNumber ?? "0"));
                    var supplier = Supplier.GetSupplier(lazyContext, Crs.Galileo, supplierCrsCode, row.Vehicle?.VendorName);

                    if (supplier.Id > 0) {
                        supplierId = supplier.Id;
                        supplierName = supplier.Name;
                    }
                    else {
                        supplier = Supplier.GetSupplier(lazyContext, Crs.Galileo, row.Vehicle?.VendorCode, row.Vehicle?.VendorName);

                        if (supplier.Id > 0) {
                            supplierId = supplier.Id;
                            supplierName = supplier.Name;
                        }
                    }

                    tripLineLands.Add(new TripLineLand {
                        CrsRefId = crsId--,
                        CrsKey = row.VehicleDateLocation?.Key ?? string.Empty,
                        TripLineType = TripLineType.Transport,
                        TripStatus = Trip.GetTripStatus(row.Status),
                        ConfirmationNo = row.BookingConfirmation ?? string.Empty,
                        CreditorId = model.CrsCreditorLandId,
                        SupplierId = supplierId,
                        SupplierName = supplierId <= 0 ? textInfo.ToTitleCase((row.Vehicle?.VendorName ?? string.Empty).ToLower()) : supplierName,
                        SupplierChainId = supplierChainId,
                        SupplierCityCode = supplierCityCode,
                        SupplierCrsCode = supplierCrsCode,
                        SupplierAddress1 = textInfo.ToTitleCase(row.CollectionAddress?.Street == null ? string.Empty : string.Join(" ", row.CollectionAddress.Street).ToLower()).Trim(),
                        SupplierAddress2 = string.Empty,
                        SupplierLocality = textInfo.ToTitleCase(row.CollectionAddress?.City == null ? cityName : string.Join(" ", row.CollectionAddress?.City).ToLower()).Trim(),
                        SupplierRegion = row.CollectionAddress?.State == null ? string.Empty : string.Join(" ", row.CollectionAddress?.State).Trim(),
                        SupplierPostCode = string.Empty,
                        SupplierCountryCode = pickupCountryCode,
                        SupplierContactPhoneWork = GetPhoneNo(row.CollectionAddress?.PhoneNumber),

                        StartDate = startDate,
                        StartTime = startTime,
                        StartDetails = string.Empty,
                        StartAddress1 = textInfo.ToTitleCase(row.CollectionAddress?.Street == null ? string.Empty : string.Join(" ", row.CollectionAddress.Street).ToLower()).Trim(),
                        StartAddress2 = string.Empty,
                        StartLocality = textInfo.ToTitleCase(row.CollectionAddress?.City == null ? cityName : string.Join(" ", row.CollectionAddress?.City).ToLower()).Trim(),
                        StartRegion = row.CollectionAddress?.State == null ? string.Empty : string.Join(" ", row.CollectionAddress?.State).Trim(),
                        StartPostCode = row.CollectionAddress?.PostalCode == null ? string.Empty : string.Join(" ", row.CollectionAddress?.PostalCode).Trim(),
                        StartCountryCode = pickupCountryCode,
                        EndDate = endDate,
                        EndTime = endTime,
                        EndDetails = string.Empty,
                        EndAddress1 = textInfo.ToTitleCase(row.DeliveryAddress?.Street == null ? string.Empty : string.Join(" ", row.DeliveryAddress.Street).ToLower()).Trim(),
                        EndAddress2 = string.Empty,
                        EndLocality = textInfo.ToTitleCase(row.DeliveryAddress?.City == null ? cityName : string.Join(" ", row.DeliveryAddress?.City).ToLower()).Trim(),
                        EndRegion = row.DeliveryAddress?.State == null ? string.Empty : string.Join(" ", row.DeliveryAddress?.State).Trim(),
                        EndPostCode = row.DeliveryAddress?.PostalCode == null ? string.Empty : string.Join(" ", row.DeliveryAddress?.PostalCode).Trim(),
                        EndCountryCode = returnCountryCode,
                        SupplierServiceDescription = GetSupplierService(row.Vehicle),
                        Comments = GetComments(row.GeneralRemark),
                        Inclusions = row.Vehicle.GetInclusions(),

                        DurationCoverageType = DurationCoverageType.Days,
                        Duration = duration,
                        PayForDuration = duration,
                        ServiceTypeRateBasis = serviceTypeRateBasis,
                        PassengerClassification = passengerClassification,
                        PaxAdultNo = paxAdultNo,
                        PaxAdultQty = paxAdultQty,
                        PaxAdultRate = paxAdultRate,
                        PaxChildNo = paxChildNo,
                        PaxChildQty = paxChildQty,
                        PaxChildRate = paxChildRate,
                        PaxInfantNo = paxInfantNo,
                        PaxInfantQty = paxInfantQty,
                        PaxInfantRate = paxInfantRate,
                        NonCommissionable = 0,
                        Commission = 0,
                        FormOfPaymentId = Biz.Dao.Common.FormOfPayment.GetFormOfPayment(lazyContext, Crs.Galileo, (pnr.UniversalRecordRetrieveRsp.UniversalRecord.FormOfPayment?.FirstOrDefault()?.Item as CreditCard)?.Type).Id,
                        SaleTypeId = saleTypeId,
                        CurrencyId = currencyId,
                        ForeignAmount = foreignAmount,
                        ExhangeRate = exchangeRate
                    });
                }
            }

            if (pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items3 != null) {
                foreach (var row in pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items3) {
                    foreach (var passiveSegment in row.PassiveSegment) {
                        string segmentType = passiveSegment.SegmentType;

                        if (segmentType != "Hotel" && segmentType != "Car" && segmentType != "Surface")
                            continue;

                        var passiveSegmentDetails = row.PassiveRemark?.FirstOrDefault(t => t.PassiveSegmentRef == passiveSegment.Key)?.Text?.GetPassiveSegmentDetails(lazyContext, customerId, segmentType);
                        var supplier = Supplier.GetSupplier(lazyContext, Crs.Galileo, row.PassiveInfo?.SupplierLocatorCode, passiveSegmentDetails.SupplierName);

                        string countryCode = Country.GetCountry(lazyContext, passiveSegmentDetails.IsoCountryCode, true).Code;
                        int currencyId = Currency.GetCurrency(lazyContext, passiveSegmentDetails.CurrencyCode).Id;

                        int saleTypeId;

                        if (countryCode == AppSettings.Setting(customerId).CountryCode) {
                            saleTypeId = AppSettings.Setting(customerId).CrsDomesticAccommodationSaleTypeId;
                        }
                        else {
                            saleTypeId = AppSettings.Setting(customerId).CrsInternationalAccommodationSaleTypeId;
                        }

                        decimal taxRate = 0;

                        if (lazyContext.SaleType.Find(saleTypeId).IsTaxApplicable)
                            taxRate = CustomerSettings.GetTaxRate(customerId, DateTime.Parse(row.CreateDate));

                        DateTime.TryParse(passiveSegment.StartDate, out DateTime startDate);
                        DateTime.TryParse(passiveSegment.EndDate, out DateTime endDate);

                        string startTime = Utils.GetIso8601DateTime(passiveSegment.StartDate).ToShortTimeString();
                        string endTime = Utils.GetIso8601DateTime(passiveSegment.EndDate).ToShortTimeString();

                        var tripLineType = segmentType == "Hotel" ? TripLineType.Accommodation : segmentType == "Car" ? TripLineType.Transport : TripLineType.OtherLand;
                        var durationCoverageType = segmentType == "Car" ? DurationCoverageType.Days : DurationCoverageType.Nights;

                        serviceTypeRateBasis = segmentType == "Hotel" ? ServiceTypeRateBasisBase.AccommodationPerRoom : segmentType == "Car" ? ServiceTypeRateBasisBase.TransportPerDay : ServiceTypeRateBasisBase.OtherLandPerService;

                        int duration = Common.GetDuration(tripLineType, startDate, endDate, durationCoverageType);

                        tripLineLands.Add(new TripLineLand {
                            CrsRefId = crsId--,
                            CrsKey = passiveSegment.Key,
                            TripLineType = tripLineType,
                            TripStatus = Trip.GetTripStatus(passiveSegment.Status),
                            ConfirmationNo = passiveSegmentDetails.ConfirmationNo,
                            CreditorId = model.CrsCreditorLandId,
                            SupplierId = supplier.Id,
                            SupplierName = supplier.Id <= 0 ? textInfo.ToTitleCase(passiveSegmentDetails.SupplierName.ToLower()) : supplier.Name,
                            SupplierChainId = -1,
                            SupplierCityCode = supplier.City.Code,
                            SupplierCrsCode = row.PassiveInfo?.SupplierLocatorCode ?? passiveSegmentDetails.SupplierCrsCode,
                            SupplierAddress1 = passiveSegmentDetails.Address,
                            SupplierAddress2 = string.Empty,
                            SupplierLocality = passiveSegmentDetails.Locality,
                            SupplierRegion = passiveSegmentDetails.Region,
                            SupplierPostCode = passiveSegmentDetails.PostCode,
                            SupplierCountryCode = countryCode,
                            SupplierContactPhoneWork = passiveSegmentDetails.PhoneNo,

                            StartDate = startDate,
                            StartTime = startTime,
                            StartDetails = string.Empty,
                            StartAddress1 = passiveSegmentDetails.PickupLocation,
                            StartAddress2 = string.Empty,
                            StartLocality = string.Empty,
                            StartRegion = string.Empty,
                            StartPostCode = string.Empty,
                            StartCountryCode = string.Empty,
                            EndDate = endDate,
                            EndTime = endTime,
                            EndDetails = string.Empty,
                            EndAddress1 = passiveSegmentDetails.DropoffLocation,
                            EndAddress2 = string.Empty,
                            EndLocality = string.Empty,
                            EndRegion = string.Empty,
                            EndPostCode = string.Empty,
                            EndCountryCode = string.Empty,
                            SupplierServiceDescription = string.Empty,
                            Comments = GetComments(row.GeneralRemark),
                            Inclusions = string.Format("{1}{0}{2}", AppConstants.HtmlLineBreak, passiveSegmentDetails.CarType.Length == 0 ? string.Empty : string.Format("Vehicle Code: {0}", passiveSegmentDetails.CarType), row.GetInclusions()).TrimStart(AppConstants.HtmlLineBreak),

                            DurationCoverageType = durationCoverageType,
                            Duration = duration,
                            PayForDuration = duration,
                            ServiceTypeRateBasis = serviceTypeRateBasis,
                            PassengerClassification = PassengerClassification.Group,
                            PaxAdultNo = 0,
                            PaxAdultQty = int.Parse(passiveSegment.NumberOfItems),
                            PaxAdultRate = passiveSegmentDetails.Rate,
                            PaxChildNo = 0,
                            PaxChildQty = 0,
                            PaxChildRate = 0,
                            PaxInfantNo = 0,
                            PaxInfantQty = 0,
                            PaxInfantRate = 0,
                            NonCommissionable = 0,
                            Commission = 0,
                            FormOfPaymentId = Biz.Dao.Common.FormOfPayment.GetFormOfPayment(lazyContext, Crs.Galileo, (pnr.UniversalRecordRetrieveRsp.UniversalRecord.FormOfPayment?.FirstOrDefault()?.Item as CreditCard)?.Type).Id,
                            SaleTypeId = saleTypeId,
                            CurrencyId = currencyId,
                            ForeignAmount = passiveSegmentDetails.ForeignAmount,
                            ExhangeRate = passiveSegmentDetails.ExchangeRate
                        });
                    }
                }
            }

            if (pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items4 != null) {
                foreach (var row in pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items4) {
                    var railJourney = row.RailJourney?.FirstOrDefault();
                    var railPricingInfo = row.RailPricingInfo?.FirstOrDefault();

                    string countryCode = string.Empty;
                    string currencyCode = null;

                    var supplier = Supplier.GetSupplier(lazyContext, Crs.Galileo, railJourney?.SupplierCode, string.Empty);

                    int currencyId = row.RailJourney?.GetCurrency(lazyContext, ref currencyCode).Id ?? -1;
                    decimal exchangeRate = row.RailJourney?.GetExchangeRate(lazyContext, currencyCode) ?? 0;

                    int saleTypeId;

                    if (countryCode == AppSettings.Setting(customerId).CountryCode) {
                        saleTypeId = AppSettings.Setting(customerId).CrsDomesticTransportSaleTypeId;
                    }
                    else {
                        saleTypeId = AppSettings.Setting(customerId).CrsInternationalTransportSaleTypeId;
                    }

                    decimal taxRate = 0;

                    if (lazyContext.SaleType.Find(saleTypeId).IsTaxApplicable)
                        taxRate = CustomerSettings.GetTaxRate(customerId, DateTime.Parse(row.CreateDate));

                    DateTime startDate = railJourney?.DepartureTime == null ? DateTime.MinValue : DateTime.Parse(railJourney.DepartureTime).Date;
                    string startTime = railJourney == null ? string.Empty : DateTime.Parse(railJourney.DepartureTime).ToString("HH:mm");

                    DateTime endDate = railJourney?.ArrivalTime == null ? DateTime.MinValue : DateTime.Parse(railJourney.ArrivalTime).Date;
                    string endTime = railJourney == null ? string.Empty : DateTime.Parse(railJourney.ArrivalTime).ToString("HH:mm");

                    int duration = Common.GetDuration(TripLineType.Transport, startDate, endDate, DurationCoverageType.Days);

                    row.GetPaxValues(exchangeRate, duration, ref serviceTypeRateBasis, ref passengerClassification, ref paxAdultNo, ref paxChildNo, ref paxInfantNo, ref paxAdultQty, ref paxChildQty, ref paxInfantQty, ref paxAdultRate, ref paxChildRate, ref paxInfantRate);
                    decimal foreignAmount = row.GetForeignAmount(lazyContext, duration);

                    tripLineLands.Add(new TripLineLand {
                        CrsRefId = crsId--,
                        CrsKey = railJourney?.Key ?? string.Empty,
                        TripLineType = TripLineType.Transport,
                        ConfirmationNo = string.Empty,
                        TripStatus = Trip.GetTripStatus(row.BookingStatus),
                        CreditorId = model.CrsCreditorLandId,
                        SupplierId = supplier.Id,
                        SupplierName = supplier.Id <= 0 ? string.Empty : supplier.Name,
                        SupplierChainId = -1,
                        SupplierCityCode = string.Empty,
                        SupplierCrsCode = railJourney?.SupplierCode ?? string.Empty,
                        SupplierAddress1 = string.Empty,
                        SupplierAddress2 = string.Empty,
                        SupplierLocality = string.Empty,
                        SupplierRegion = string.Empty,
                        SupplierPostCode = string.Empty,
                        SupplierCountryCode = countryCode,
                        SupplierContactPhoneWork = string.Empty,

                        StartDate = startDate,
                        StartTime = startTime,
                        StartDetails = string.Empty,
                        StartAddress1 = string.Empty,
                        StartAddress2 = string.Empty,
                        StartLocality = string.Empty,
                        StartRegion = string.Empty,
                        StartPostCode = string.Empty,
                        StartCountryCode = string.Empty,
                        EndDate = endDate,
                        EndTime = endTime,
                        EndDetails = string.Empty,
                        EndAddress1 = string.Empty,
                        EndAddress2 = string.Empty,
                        EndLocality = string.Empty,
                        EndRegion = string.Empty,
                        EndPostCode = string.Empty,
                        EndCountryCode = string.Empty,
                        SupplierServiceDescription = railPricingInfo?.GetSupplierService() ?? string.Empty,
                        Comments = GetComments(row.GeneralRemark),
                        Inclusions = row.GetInclusions(),

                        DurationCoverageType = DurationCoverageType.Days,
                        Duration = duration,
                        PayForDuration = duration,
                        ServiceTypeRateBasis = serviceTypeRateBasis,
                        PassengerClassification = passengerClassification,
                        PaxAdultNo = paxAdultNo,
                        PaxAdultQty = paxAdultQty,
                        PaxAdultRate = paxAdultRate,
                        PaxChildNo = paxChildNo,
                        PaxChildQty = paxChildQty,
                        PaxChildRate = paxChildRate,
                        PaxInfantNo = paxInfantNo,
                        PaxInfantQty = paxInfantQty,
                        PaxInfantRate = paxInfantRate,
                        NonCommissionable = row.RailPricingInfo.GetNonCommissionable(customerId, exchangeRate, taxRate),
                        Commission = row.GetCommission(exchangeRate),
                        FormOfPaymentId = Biz.Dao.Common.FormOfPayment.GetFormOfPayment(lazyContext, Crs.Galileo, (pnr.UniversalRecordRetrieveRsp.UniversalRecord.FormOfPayment?.FirstOrDefault()?.Item as CreditCard)?.Type).Id,
                        SaleTypeId = saleTypeId,
                        CurrencyId = currencyId,
                        ForeignAmount = foreignAmount,
                        ExhangeRate = exchangeRate
                    });
                }
            }

            if (pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items5 != null) {
                foreach (var row in pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items5) {
                    var cruiseItinerary = row.CruiseItinerary?.FirstOrDefault();

                    string countryCode = string.Empty;
                    string currencyCode = null;

                    var supplier = Supplier.GetSupplier(lazyContext, Crs.Galileo, row.CruiseSegment?.Vendor, row.CruiseSegment?.VendorName);

                    int currencyId = row.CruisePricingInfo?.GetCurrency(lazyContext, ref currencyCode).Id ?? -1;
                    decimal exchangeRate = row.CruisePricingInfo?.GetExchangeRate(lazyContext, currencyCode) ?? 0;

                    int saleTypeId;

                    if (countryCode == AppSettings.Setting(customerId).CountryCode) {
                        saleTypeId = AppSettings.Setting(customerId).CrsDomesticAccommodationSaleTypeId;
                    }
                    else {
                        saleTypeId = AppSettings.Setting(customerId).CrsInternationalAccommodationSaleTypeId;
                    }

                    decimal taxRate = 0;

                    if (lazyContext.SaleType.Find(saleTypeId).IsTaxApplicable)
                        taxRate = CustomerSettings.GetTaxRate(customerId, DateTime.Parse(row.CreateDate));

                    DateTime startDate = cruiseItinerary?.DepartureTime.Date ?? DateTime.MinValue;
                    string startTime = cruiseItinerary?.DepartureTime == null ? string.Empty : cruiseItinerary.DepartureTime.ToString("HH:mm");

                    DateTime endDate = cruiseItinerary?.ArrivalTime.Date ?? DateTime.MinValue;
                    string endTime = cruiseItinerary?.ArrivalTime == null ? string.Empty : cruiseItinerary.ArrivalTime.ToString("HH:mm");

                    int duration = Common.GetDuration(TripLineType.Cruise, startDate, endDate, DurationCoverageType.Days);

                    row.GetPaxValues(exchangeRate, duration, ref serviceTypeRateBasis, ref passengerClassification, ref paxAdultNo, ref paxChildNo, ref paxInfantNo, ref paxAdultQty, ref paxChildQty, ref paxInfantQty, ref paxAdultRate, ref paxChildRate, ref paxInfantRate);
                    decimal foreignAmount = row.GetForeignAmount(lazyContext, duration);

                    tripLineLands.Add(new TripLineLand {
                        CrsRefId = crsId--,
                        CrsKey = row.CruiseSegment?.Key ?? string.Empty,
                        TripLineType = TripLineType.Cruise,
                        TripStatus = Trip.GetTripStatus(row.CruiseSegment.Status),
                        ConfirmationNo = string.Empty,
                        CreditorId = model.CrsCreditorLandId,
                        SupplierId = supplier.Id,
                        SupplierName = supplier.Id <= 0 ? textInfo.ToTitleCase((row.CruiseSegment?.VendorName ?? string.Empty).ToLower()) : supplier.Name,
                        SupplierChainId = -1,
                        SupplierCityCode = string.Empty,
                        SupplierCrsCode = row.CruiseSegment?.Vendor ?? string.Empty,
                        SupplierAddress1 = string.Empty,
                        SupplierAddress2 = string.Empty,
                        SupplierLocality = string.Empty,
                        SupplierRegion = string.Empty,
                        SupplierPostCode = string.Empty,
                        SupplierCountryCode = countryCode,
                        SupplierContactPhoneWork = string.Empty,

                        StartDate = startDate,
                        StartTime = startTime,
                        StartDetails = string.Empty,
                        StartAddress1 = string.Empty,
                        StartAddress2 = string.Empty,
                        StartLocality = string.Empty,
                        StartRegion = string.Empty,
                        StartPostCode = string.Empty,
                        StartCountryCode = string.Empty,
                        EndDate = endDate,
                        EndTime = endTime,
                        EndDetails = string.Empty,
                        EndAddress1 = string.Empty,
                        EndAddress2 = string.Empty,
                        EndLocality = string.Empty,
                        EndRegion = string.Empty,
                        EndPostCode = string.Empty,
                        EndCountryCode = string.Empty,
                        SupplierServiceDescription = row.CruisePricingInfo.GetSupplierService(),
                        Comments = GetComments(row.GeneralRemark),
                        Inclusions = row.GetInclusions(),

                        DurationCoverageType = DurationCoverageType.Days,
                        Duration = duration,
                        PayForDuration = duration,
                        ServiceTypeRateBasis = serviceTypeRateBasis,
                        PassengerClassification = passengerClassification,
                        PaxAdultNo = paxAdultNo,
                        PaxAdultQty = paxAdultQty,
                        PaxAdultRate = paxAdultRate,
                        PaxChildNo = paxChildNo,
                        PaxChildQty = paxChildQty,
                        PaxChildRate = paxChildRate,
                        PaxInfantNo = paxInfantNo,
                        PaxInfantQty = paxInfantQty,
                        PaxInfantRate = paxInfantRate,
                        NonCommissionable = row.CruisePricingInfo.GetNonCommissionable(customerId, exchangeRate, taxRate),
                        Commission = row.CruisePricingInfo.GetCommission(exchangeRate),
                        FormOfPaymentId = Biz.Dao.Common.FormOfPayment.GetFormOfPayment(lazyContext, Crs.Galileo, (pnr.UniversalRecordRetrieveRsp.UniversalRecord.FormOfPayment?.FirstOrDefault()?.Item as CreditCard)?.Type).Id,
                        SaleTypeId = saleTypeId,
                        CurrencyId = currencyId,
                        ForeignAmount = foreignAmount,
                        ExhangeRate = exchangeRate
                    });
                }
            }

            return tripLineLands;
        }

        private static Currency GetCurrency<T>(this T source, AppLazyContext lazyContext, ref string code) where T : class {
            if (source == null)
                return Currency.GetCurrency(lazyContext, string.Empty);

            if (source is FareInfo) {
                code = (source as FareInfo).Amount?.Left(3) ?? string.Empty;
            }
            else if (source is AirPricingInfo) {
                var airPricingInfo = source as AirPricingInfo;
                code = (airPricingInfo.EquivalentBasePrice ?? airPricingInfo.ApproximateBasePrice)?.Left(3) ?? string.Empty;
            }
            else if (source is HotelRateDetail) {
                code = (source as HotelRateDetail).Total?.Left(3) ?? string.Empty;
            }
            else if (source is GuestInformation) {
                code = (source as GuestInformation).NumberOfAdults?.Amount?.Left(3) ?? string.Empty;
            }
            else if (source is VehicleRate) {
                code = (source as VehicleRate).SupplierRate?.RateForPeriod?.Left(3) ?? string.Empty;
            }
            else if (source is RailPricingInfo) {
                var railPricingInfo = source as RailPricingInfo;
                code = (railPricingInfo.EquivalentBasePrice ?? railPricingInfo.ApproximateBasePrice)?.Left(3) ?? string.Empty;
            }
            else if (source is CruisePricingInfo) {
                var cruisePricingInfo = source as CruisePricingInfo;
                code = (cruisePricingInfo.EquivalentBasePrice ?? cruisePricingInfo.ApproximateBasePrice)?.Left(3) ?? string.Empty;
            }
            else {
                throw new InvalidOperationException("The specified source type is not supported.");
            }

            return Currency.GetCurrency(lazyContext, code);
        }

        private static decimal GetExchangeRate<T>(this T source, AppLazyContext lazyContext, string currencyCode) where T : class {
            if (source == null)
                return 0;

            if (source is FareInfo) {
                return Currency.GetExchangeRate(lazyContext, currencyCode);
            }
            else if (source is AirPricingInfo) {
                var airPricingInfo = source as AirPricingInfo;

                if (airPricingInfo.BasePrice == null || (airPricingInfo.EquivalentBasePrice == null && airPricingInfo.ApproximateBasePrice == null))
                    return Currency.GetExchangeRate(lazyContext, currencyCode);

                decimal basePrice = Math.Round(decimal.Parse(airPricingInfo.BasePrice.Substring(3)), 2);
                decimal equivalentBasePrice = Math.Round(decimal.Parse((airPricingInfo.EquivalentBasePrice ?? airPricingInfo.ApproximateBasePrice).Substring(3)), 2);

                if (basePrice == 0 || equivalentBasePrice == 0)
                    return Currency.GetExchangeRate(lazyContext, currencyCode);

                return Math.Round(basePrice / equivalentBasePrice, 8);
            }
            else if (source is HotelRateDetail) {
                var hotelRateDetail = source as HotelRateDetail;

                if (hotelRateDetail.Base == null || hotelRateDetail.ApproximateBase == null)
                    return Currency.GetExchangeRate(lazyContext, currencyCode);

                decimal basePrice = Math.Round(decimal.Parse(hotelRateDetail.Base.Substring(3)), 2);
                decimal approximateBasePrice = Math.Round(decimal.Parse(hotelRateDetail.ApproximateBase.Substring(3)), 2);

                if (basePrice == 0 || approximateBasePrice == 0)
                    return Currency.GetExchangeRate(lazyContext, currencyCode);

                return Math.Round(basePrice / approximateBasePrice, 8);
            }
            else if (source is VehicleRate) {
                return Currency.GetExchangeRate(lazyContext, currencyCode);
            }
            else if (source is RailPricingInfo) {
                var railPricingInfo = source as RailPricingInfo;

                if (railPricingInfo.BasePrice == null || (railPricingInfo.EquivalentBasePrice == null && railPricingInfo.ApproximateBasePrice == null))
                    return Currency.GetExchangeRate(lazyContext, currencyCode);

                decimal basePrice = Math.Round(decimal.Parse(railPricingInfo.BasePrice.Substring(3)), 2);
                decimal equivalentBasePrice = Math.Round(decimal.Parse((railPricingInfo.EquivalentBasePrice ?? railPricingInfo.ApproximateBasePrice).Substring(3)), 2);

                if (basePrice == 0 || equivalentBasePrice == 0)
                    return Currency.GetExchangeRate(lazyContext, currencyCode);

                return Math.Round(basePrice / equivalentBasePrice, 8);
            }
            else if (source is CruisePricingInfo) {
                var cruisePricingInfo = source as CruisePricingInfo;

                if (cruisePricingInfo.BasePrice == null || (cruisePricingInfo.EquivalentBasePrice == null && cruisePricingInfo.ApproximateBasePrice == null))
                    return Currency.GetExchangeRate(lazyContext, currencyCode);

                decimal basePrice = Math.Round(decimal.Parse(cruisePricingInfo.BasePrice.Substring(3)), 2);
                decimal equivalentBasePrice = Math.Round(decimal.Parse((cruisePricingInfo.EquivalentBasePrice ?? cruisePricingInfo.ApproximateBasePrice).Substring(3)), 2);

                if (basePrice == 0 || equivalentBasePrice == 0)
                    return Currency.GetExchangeRate(lazyContext, currencyCode);

                return Math.Round(basePrice / equivalentBasePrice, 8);
            }
            else {
                throw new InvalidOperationException("The specified source type is not supported.");
            }
        }

        private static decimal GetAmount<T>(this T source, decimal exchangeRate) where T : class {
            if (source == null)
                return 0;

            decimal airExchangeRate = 0;
            return source.GetAmount(0, exchangeRate, ref airExchangeRate);
        }

        private static decimal GetAmount<T>(this T source, int duration, decimal exchangeRate) where T : class {
            if (source == null)
                return 0;

            decimal airExchangeRate = 0;
            return source.GetAmount(duration, exchangeRate, ref airExchangeRate);
        }

        private static decimal GetAmount<T>(this T source, decimal exchangeRate, ref decimal airExchangeRate) where T : class {
            if (source == null)
                return 0;

            return source.GetAmount(0, exchangeRate, ref airExchangeRate);
        }

        private static decimal GetAmount<T>(this T source, int duration, decimal exchangeRate, ref decimal airExchangeRate) where T : class {
            if (source == null)
                return 0;

            airExchangeRate = exchangeRate;

            if (source is AirPricingInfo) {
                var airPricingInfo = source as AirPricingInfo;

                decimal basePrice = decimal.Parse(airPricingInfo.BasePrice.Substring(3) ?? "0");
                string equivalentPrice = airPricingInfo.EquivalentBasePrice ?? airPricingInfo.ApproximateBasePrice;

                if (equivalentPrice != null) {
                    decimal equivalentBasePrice = decimal.Parse(equivalentPrice.Substring(3) ?? "0");

                    if (equivalentBasePrice != 0)
                        airExchangeRate = basePrice / equivalentBasePrice;

                    return Math.Round(equivalentBasePrice, 2);
                }

                return exchangeRate == 0 ? 0 : Math.Round(basePrice / exchangeRate, 2);
            }
            else if (source is Services.Travelport.Air.AirPricingInfo) {
                var airPricingInfo = source as Services.Travelport.Air.AirPricingInfo;

                decimal basePrice = decimal.Parse(airPricingInfo.BasePrice.Substring(3) ?? "0");
                string equivalentPrice = airPricingInfo.EquivalentBasePrice ?? airPricingInfo.ApproximateBasePrice;

                if (equivalentPrice != null) {
                    decimal equivalentBasePrice = decimal.Parse(equivalentPrice.Substring(3) ?? "0");

                    if (equivalentBasePrice != 0)
                        airExchangeRate = basePrice / equivalentBasePrice;

                    return Math.Round(equivalentBasePrice, 2);
                }

                return exchangeRate == 0 ? 0 : Math.Round(basePrice / exchangeRate, 2);
            }

            if (exchangeRate == 0)
                return 0;

            if (source is FareInfo) {
                var fareInfo = source as FareInfo;
                return Math.Round(decimal.Parse(fareInfo.Amount?.Substring(3) ?? "0") / exchangeRate, 2);
            }
            else if (source is HotelRateDetail) {
                var hotelRateDetail = source as HotelRateDetail;
                return Math.Round(decimal.Parse(hotelRateDetail.Total?.Substring(3) ?? "0") / duration / exchangeRate, 2);
            }
            else if (source is GuestInformation) {
                var guestInformation = source as GuestInformation;
                return Math.Round(decimal.Parse(guestInformation.NumberOfChildren?.Amount?.Substring(3) ?? "0") / exchangeRate, 2);
            }
            else if (source is VehicleRate) {
                var vehicleRate = source as VehicleRate;
                return Math.Round(decimal.Parse(vehicleRate.SupplierRate?.EstimatedTotalAmount?.Substring(3) ?? "0") / exchangeRate, 2);
            }
            else if (source is RailPricingInfo) {
                var railPricingInfo = source as RailPricingInfo;
                return Math.Round(decimal.Parse(railPricingInfo.TotalPrice?.Substring(3) ?? "0") / duration / exchangeRate, 2);
            }
            else if (source is CruisePricingInfo) {
                var cruisePricingInfo = source as CruisePricingInfo;
                return Math.Round(decimal.Parse(cruisePricingInfo.TotalPrice?.Substring(3) ?? "0") / duration / exchangeRate, 2);
            }
            else {
                throw new InvalidOperationException("The specified source type is not supported.");
            }
        }

        private static string GetLocalTaxCode(int customerId) {
            return AppSettings.CrsLocalTaxCodes.ContainsKey(AppSettings.Setting(customerId).CountryCode) ? AppSettings.CrsLocalTaxCodes[AppSettings.Setting(customerId).CountryCode] : string.Empty;
        }

        private static decimal GetLocalTax<T>(this T source, int customerId, decimal exchangeRate, decimal taxRate) where T : class {
            if (source == null)
                return 0;

            if (source is FareInfo) {
                var fareInfo = source as FareInfo;
                return Math.Round(decimal.Parse(fareInfo.Amount?.Substring(3) ?? "0") / exchangeRate * taxRate, 2);
            }
            else if (source is AirPricingInfo) {
                var airPricingInfo = source as AirPricingInfo;

                if (airPricingInfo.TaxInfo != null || airPricingInfo.FeeInfo != null)
                    return GetValidatedLocalTax(customerId, airPricingInfo, taxRate);

                decimal totalPrice = decimal.Parse(airPricingInfo?.TotalPrice?.Substring(3) ?? "0");
                decimal equivalentBasePrice = decimal.Parse((airPricingInfo?.EquivalentBasePrice ?? airPricingInfo?.ApproximateBasePrice)?.Substring(3) ?? "0");

                return exchangeRate == 0 ? 0 : Math.Round((totalPrice - equivalentBasePrice) / exchangeRate * taxRate, 2);
            }
            else if (source is Services.Travelport.Air.AirPricingInfo) {
                var airPricingInfo = source as Services.Travelport.Air.AirPricingInfo;

                if (airPricingInfo.TaxInfo != null || airPricingInfo.FeeInfo != null)
                    return GetValidatedLocalTax(customerId, airPricingInfo, taxRate);

                decimal totalPrice = decimal.Parse(airPricingInfo?.TotalPrice?.Substring(3) ?? "0");
                decimal equivalentBasePrice = decimal.Parse((airPricingInfo?.EquivalentBasePrice ?? airPricingInfo?.ApproximateBasePrice)?.Substring(3) ?? "0");

                return exchangeRate == 0 ? 0 : Math.Round((totalPrice - equivalentBasePrice) / exchangeRate * taxRate, 2);
            }
            else if (source is HotelRateDetail) {
                var hotelRateDetail = source as HotelRateDetail;
                return Math.Round(decimal.Parse(hotelRateDetail.Total?.Substring(3) ?? "0") / exchangeRate * taxRate, 2);
            }
            else if (source is VehicleRate) {
                var vehicleRate = source as VehicleRate;
                return Math.Round(decimal.Parse(vehicleRate.SupplierRate?.RateForPeriod?.Substring(3) ?? "0") / exchangeRate * taxRate, 2);
            }
            else if (source is RailPricingInfo) {
                var railPricingInfo = source as RailPricingInfo;
                return Math.Round(decimal.Parse((railPricingInfo.EquivalentBasePrice ?? railPricingInfo.ApproximateBasePrice)?.Substring(3) ?? "0") / exchangeRate * taxRate, 2);
            }
            else if (source is CruisePricingInfo) {
                var cruisePricingInfo = source as CruisePricingInfo;
                return Math.Round(decimal.Parse((cruisePricingInfo.EquivalentBasePrice ?? cruisePricingInfo.ApproximateBasePrice)?.Substring(3) ?? "0") / exchangeRate * taxRate, 2);
            }
            else {
                throw new InvalidOperationException("The specified source type is not supported.");
            }
        }

        private static decimal GetValidatedLocalTax(int customerId, AirPricingInfo airPricingInfo, decimal taxRate) {
            if (airPricingInfo.TaxInfo == null && airPricingInfo.FeeInfo == null)
                return 0;

            string crsTaxCode = GetLocalTaxCode(customerId);
            decimal localTax = 0;

            if (airPricingInfo.TaxInfo != null)
                localTax += airPricingInfo.TaxInfo.Where(t => t.Category == crsTaxCode).Sum(t => t.Amount == null ? 0 : decimal.Parse(t.Amount.Substring(3)));

            if (airPricingInfo.FeeInfo != null)
                localTax += airPricingInfo.FeeInfo.Where(t => t.Code == crsTaxCode).Sum(t => t.Amount == null ? 0 : decimal.Parse(t.Amount.Substring(3)));

            localTax = Math.Round(localTax, 2);

            if (localTax != 0) {
                decimal.TryParse((airPricingInfo.EquivalentBasePrice ?? airPricingInfo.ApproximateBasePrice).Substring(3), out decimal equivalentBasePrice);
                decimal tax = Math.Round(equivalentBasePrice * taxRate, 2);

                if (localTax >= tax + 0.02m || localTax <= tax - 0.02m)
                    localTax = tax;
            }

            return localTax;
        }

        private static decimal GetValidatedLocalTax(int customerId, Services.Travelport.Air.AirPricingInfo airPricingInfo, decimal taxRate) {
            if (airPricingInfo.TaxInfo == null && airPricingInfo.FeeInfo == null)
                return 0;

            string crsTaxCode = GetLocalTaxCode(customerId);
            decimal localTax = 0;

            if (airPricingInfo.TaxInfo != null)
                localTax += airPricingInfo.TaxInfo.Where(t => t.Category == crsTaxCode).Sum(t => t.Amount == null ? 0 : decimal.Parse(t.Amount.Substring(3)));

            if (airPricingInfo.FeeInfo != null)
                localTax += airPricingInfo.FeeInfo.Where(t => t.Code == crsTaxCode).Sum(t => t.Amount == null ? 0 : decimal.Parse(t.Amount.Substring(3)));

            localTax = Math.Round(localTax, 2);

            if (localTax != 0) {
                decimal.TryParse((airPricingInfo.EquivalentBasePrice ?? airPricingInfo.ApproximateBasePrice).Substring(3), out decimal equivalentBasePrice);
                decimal tax = Math.Round(equivalentBasePrice * taxRate, 2);

                if (localTax >= tax + 0.02m || localTax <= tax - 0.02m)
                    localTax = tax;
            }

            return localTax;
        }

        private static decimal GetNonCommissionable<T>(this T source, int customerId, decimal exchangeRate, decimal taxRate) where T : class {
            if (source == null)
                return 0;

            if (source is AirPricingInfo) {
                var airPricingInfo = source as AirPricingInfo;

                if (airPricingInfo.TaxInfo == null && airPricingInfo.FeeInfo == null)
                    return 0;

                decimal amount = 0;

                if (airPricingInfo.TaxInfo != null)
                    amount += airPricingInfo.TaxInfo.Sum(t => t.Amount == null ? 0 : decimal.Parse(t.Amount.Substring(3)));

                if (airPricingInfo.FeeInfo != null)
                    amount += airPricingInfo.FeeInfo.Sum(t => t.Amount == null ? 0 : decimal.Parse(t.Amount.Substring(3)));

                amount = Math.Round(amount, 2);

                decimal localTax = GetValidatedLocalTax(customerId, airPricingInfo, taxRate);
                return amount - localTax;
            }
            else if (source is Services.Travelport.Air.AirPricingInfo) {
                var airPricingInfo = source as Services.Travelport.Air.AirPricingInfo;

                if (airPricingInfo.TaxInfo == null && airPricingInfo.FeeInfo == null)
                    return 0;

                decimal amount = 0;

                if (airPricingInfo.TaxInfo != null)
                    amount += airPricingInfo.TaxInfo.Sum(t => t.Amount == null ? 0 : decimal.Parse(t.Amount.Substring(3)));

                if (airPricingInfo.FeeInfo != null)
                    amount += airPricingInfo.FeeInfo.Sum(t => t.Amount == null ? 0 : decimal.Parse(t.Amount.Substring(3)));

                amount = Math.Round(amount, 2);

                decimal localTax = GetValidatedLocalTax(customerId, airPricingInfo, taxRate);
                return amount - localTax;
            }

            if (exchangeRate == 0)
                return 0;

            if (source is FareInfo) {
                var fareInfo = source as FareInfo;

                if (fareInfo.Amount == null || fareInfo.TaxAmount == null)
                    return 0;

                return Math.Round(decimal.Parse(fareInfo.TaxAmount.Substring(3) ?? "0") - (decimal.Parse(fareInfo.Amount.Substring(3) ?? "0") / exchangeRate * taxRate), 2);
            }
            else if (source is HotelRateDetail) {
                var hotelRateDetail = source as HotelRateDetail;
                return Math.Round(decimal.Parse(hotelRateDetail.Tax?.Substring(3) ?? "0") / exchangeRate, 2);
            }
            else if (source is RailPricingInfo) {
                var railPricingInfo = source as RailPricingInfo;
                return Math.Round(decimal.Parse(railPricingInfo.Taxes?.Substring(3) ?? "0") / exchangeRate, 2);
            }
            else if (source is CruisePricingInfo) {
                var cruisePricingInfo = source as CruisePricingInfo;
                return Math.Round(decimal.Parse(cruisePricingInfo.Taxes?.Substring(3) ?? "0") / exchangeRate, 2);
            }
            else {
                throw new InvalidOperationException("The specified source type is not supported.");
            }
        }

        private static decimal GetCommission<T>(this T source, decimal exchangeRate) where T : class {
            if (source == null || exchangeRate == 0)
                return 0;

            if (source is FareInfo) {
                var fareInfo = source as FareInfo;

                if (fareInfo.Commission == null)
                    return 0;

                return Math.Round(decimal.Parse(fareInfo.Commission.Amount.Substring(3)) / exchangeRate, 2);
            }
            else if (source is AirPricingInfo) {
                var airPricingInfo = source as AirPricingInfo;

                if (airPricingInfo.Commission == null)
                    return 0;

                return Math.Round(airPricingInfo.Commission.Sum(t => t.Amount == null ? 0 : decimal.Parse(t.Amount.Substring(3))) / exchangeRate, 2);
            }
            else if (source is Services.Travelport.Air.AirPricingInfo) {
                var airPricingInfo = source as Services.Travelport.Air.AirPricingInfo;

                if (airPricingInfo.Commission == null)
                    return 0;

                return Math.Round(airPricingInfo.Commission.Sum(t => t.Amount == null ? 0 : decimal.Parse(t.Amount.Substring(3))) / exchangeRate, 2);
            }
            else if (source is HotelReservation) {
                var hotelReservation = source as HotelReservation;
                return Math.Round(hotelReservation.HotelRateDetail.Sum(t => t.Commission == null ? 0 : decimal.Parse(t.Commission.CommissionAmount.Substring(3))) / exchangeRate, 2);
            }
            else if (source is CruisePricingInfo) {
                var cruisePricingInfo = source as CruisePricingInfo;
                return Math.Round(decimal.Parse(cruisePricingInfo.Commission?.Amount?.Substring(3) ?? "0") / exchangeRate, 2);
            }
            else {
                throw new InvalidOperationException("The specified source type is not supported.");
            }
        }

        private static decimal GetAirSegmentAmount(AppLazyContext lazyContext, string fareCalc, string fareBasis, string arrivalCityCode, int arrivalCountryId, string airlineCode) {
            string[] fareCalcs = fareCalc.SplitFareCalc(fareBasis);

            if (fareCalcs.Length == 0)
                return 0;

            for (int i = 0; i < fareCalcs.Length; i++) {
                string[] fareCalcParts = fareCalcs[i].Replace("/-", "¶").Split("/", StringSplitOptions.RemoveEmptyEntries);
                string segmentFareCalc;

                for (int j = 0; j < fareCalcParts.Length; j++) {
                    segmentFareCalc = fareCalcParts[j].Replace("¶", "/-");

                    var arrivalCityCodes = new List<CityCodeModel> { new CityCodeModel { CityCode = arrivalCityCode } };

                    if (!segmentFareCalc.Contains(string.Format(" {0} ", arrivalCityCode))) {
                        arrivalCityCodes.AddRange(GetCityCodes(lazyContext, arrivalCountryId).Select(t => new CityCodeModel { CityCode = t.CityCode, CountryId = t.CountryId }));

                        if (!arrivalCityCodes.Any(t => segmentFareCalc.Contains(string.Format(" {0} ", t.CityCode))))
                            continue;
                    }

                    string[] matches = segmentFareCalc.SplitFareCalc(fareBasis)[0].Split(new string[] { string.Format(" {0} ", airlineCode) }, StringSplitOptions.RemoveEmptyEntries).Where(t => t.Contains(fareBasis)).ToArray();

                    if (matches.Length == 0 || !arrivalCityCodes.Any(t => matches[matches.Length - 1].StartsWith(t.CityCode)))
                        continue;

                    if (j == 0)
                        segmentFareCalc = fareCalc;

                    int index = segmentFareCalc.IndexOf(fareBasis);

                    if (index == -1)
                        continue;

                    string[] segmentAmounts = segmentFareCalc.Substring(0, index).Split(" ", StringSplitOptions.RemoveEmptyEntries);
                    string[] segmentsRoe = segmentFareCalc.Substring(index).Split(" ", StringSplitOptions.RemoveEmptyEntries);

                    string segmentAmount = segmentAmounts[segmentAmounts.Length - 1];
                    string segmentRoe = segmentsRoe[segmentsRoe.Length - 1];

                    string segmentFuelSurcharge = segmentAmounts.FirstOrDefault(t => t.StartsWith("Q") && t.Substring(1).IsNumeric());

                    decimal.TryParse(segmentAmount.GetDigitsAndPunctuation(), out decimal amount);

                    if (segmentFuelSurcharge != null) {
                        decimal.TryParse(segmentFuelSurcharge.GetDigitsAndPunctuation(), out decimal fuelSurcharge);
                        amount += fuelSurcharge;
                    }

                    if (!segmentRoe.StartsWith("ROE"))
                        return amount;

                    decimal.TryParse(segmentRoe.Substring(3), out decimal roe);
                    return Math.Round(amount * roe, 2);
                }
            }

            return 0;
        }

        private static string[] SplitFareCalc(this string fareCalc, string fareBasis) {
            if (fareBasis.Length == 0)
                return new string[] { fareCalc };

            int count = new Regex(Regex.Escape(fareBasis)).Matches(fareCalc).Count;

            if (count <= 1)
                return new string[] { fareCalc };

            string[] items = fareCalc.Split(new string[] { fareBasis }, StringSplitOptions.None);

            var result = new List<string>();

            for (int i = 0; i <= items.Length - 2; i++) {
                if (i == items.Length - 2) {
                    result.Add(string.Format("{0}{1}{2}", items[i], fareBasis, items[i + 1]));
                }
                else {
                    result.Add(string.Format("{0}{1}", items[i], fareBasis));
                }
            }

            return result.ToArray();
        }

        private static void GetPaxValues<T>(this T source, decimal exchangeRate, int duration, ref ServiceTypeRateBasisBase serviceTypeRateBasis, ref PassengerClassification passengerClassification, ref int paxAdultNo, ref int paxChildNo, ref int paxInfantNo, ref int paxAdultQty, ref int paxChildQty, ref int paxInfantQty, ref decimal paxAdultRate, ref decimal paxChildRate, ref decimal paxInfantRate) {
            paxAdultNo = 0;
            paxChildNo = 0;
            paxInfantNo = 0;

            paxAdultQty = 0;
            paxChildQty = 0;
            paxInfantQty = 0;

            paxAdultRate = 0;
            paxChildRate = 0;
            paxInfantRate = 0;

            if (source == null)
                return;

            if (source is HotelReservation) {
                var item = source as HotelReservation;

                serviceTypeRateBasis = (item.GuestInformation?.NumberOfRoomsSpecified ?? false) ? ServiceTypeRateBasisBase.AccommodationPerRoom : ServiceTypeRateBasisBase.AccommodationPerPerson;
                passengerClassification = serviceTypeRateBasis == ServiceTypeRateBasisBase.AccommodationPerPerson ? PassengerClassification.Individual : PassengerClassification.Group;

                switch (serviceTypeRateBasis) {
                    case ServiceTypeRateBasisBase.AccommodationPerPerson:
                        paxAdultNo = item.GuestInformation?.NumberOfAdults?.Value.ToInt() ?? 0;
                        paxChildNo = item.GuestInformation?.NumberOfChildren?.Count.ToInt() ?? 0;

                        if (passengerClassification == PassengerClassification.Group) {
                            paxAdultNo += paxChildNo;
                            paxChildNo = 0;
                        }

                        break;
                    case ServiceTypeRateBasisBase.AccommodationPerRoom:
                        if (passengerClassification == PassengerClassification.Group)
                            paxAdultQty = item.GuestInformation?.NumberOfRooms ?? 0;

                        break;
                }

                paxAdultRate = item.HotelRateDetail?.FirstOrDefault()?.GetAmount(duration, exchangeRate) ?? 0;
                paxChildRate = item.GuestInformation.GetAmount(duration, exchangeRate);
            }
            else if (source is VehicleReservation) {
                var item = source as VehicleReservation;

                serviceTypeRateBasis = ServiceTypeRateBasisBase.TransportPackage;
                passengerClassification = PassengerClassification.Group;
                paxAdultQty = 1;
                paxAdultRate = item.Vehicle.VehicleRate.GetAmount(exchangeRate);
            }
            else if (source is RailReservation) {
                var item = source as RailReservation;

                serviceTypeRateBasis = ServiceTypeRateBasisBase.TransportPackage;
                passengerClassification = PassengerClassification.Group;
                paxAdultQty = 1;
                paxAdultRate = item.RailPricingInfo?.FirstOrDefault()?.GetAmount(duration, exchangeRate) ?? 0;
            }
            else if (source is CruiseReservation) {
                var item = source as CruiseReservation;

                serviceTypeRateBasis = ServiceTypeRateBasisBase.CruisePerCruise;
                passengerClassification = PassengerClassification.Group;
                paxAdultQty = 1;
                paxAdultRate = item.CruisePricingInfo.GetAmount(duration, exchangeRate);
            }
        }

        private static decimal GetForeignAmount<T>(this T source, AppLazyContext lazyContext, int duration) {
            var serviceTypeRateBasis = ServiceTypeRateBasisBase.NotSpecified;
            var passengerClassification = PassengerClassification.Individual;

            int paxAdultNo = 0;
            int paxChildNo = 0;
            int paxInfantNo = 0;

            int paxAdultQty = 0;
            int paxChildQty = 0;
            int paxInfantQty = 0;

            decimal paxAdultRate = 0;
            decimal paxChildRate = 0;
            decimal paxInfantRate = 0;

            source.GetPaxValues(1, duration, ref serviceTypeRateBasis, ref passengerClassification, ref paxAdultNo, ref paxChildNo, ref paxInfantNo, ref paxAdultQty, ref paxChildQty, ref paxInfantQty, ref paxAdultRate, ref paxChildRate, ref paxInfantRate);

            var rateBasis = lazyContext.ServiceTypeRateBasis.Find((int)serviceTypeRateBasis);

            if (rateBasis == null)
                return 0;

            if (serviceTypeRateBasis == ServiceTypeRateBasisBase.AirPackage || serviceTypeRateBasis == ServiceTypeRateBasisBase.AccommodationPackage || serviceTypeRateBasis == ServiceTypeRateBasisBase.TransportPackage || serviceTypeRateBasis == ServiceTypeRateBasisBase.InsurancePackage || serviceTypeRateBasis == ServiceTypeRateBasisBase.OtherLandPackage)
                duration = 1;

            if (rateBasis.IsPaxNoApplicable) {
                return (paxAdultNo * paxAdultRate + paxChildNo * paxChildRate + paxInfantNo * paxInfantRate) * duration;
            }
            else {
                return (paxAdultQty * paxAdultRate + paxChildQty * paxChildRate + paxInfantQty * paxInfantRate) * duration;
            }
        }

        private static string GetSupplierService<T>(this T source) {
            if (source == null)
                return string.Empty;

            string supplierService = string.Empty;

            if (source is HotelRateDetail) {
                if (source is not HotelRateDetail hotelRateDetail)
                    return string.Empty;

                if (hotelRateDetail.Inclusions?.BedTypes != null)
                    supplierService += string.Format("{0}", string.Join("; ", hotelRateDetail.Inclusions.BedTypes.Select(t => string.Format("{0} x {1}", t.Quantity, t.Code))));
            }
            else if (source is Vehicle) {
                if (source is not Vehicle vehicle)
                    return string.Empty;

                supplierService += string.Format("{0} {1} Door Vehicle", vehicle.VehicleClass, vehicle.DoorCount == typeDoorCount.TwoToThreeDoors ? "2/3" : vehicle.DoorCount == typeDoorCount.TwoToFourDoors ? "2/4" : "4/5");
            }

            return supplierService.Trim();
        }

        private static string GetInclusions<T>(this T source) {
            if (source == null)
                return string.Empty;

            string inclusions = string.Empty;

            if (source is HotelRateDetail) {
                var hotelRateDetail = source as HotelRateDetail;

                if (hotelRateDetail.HotelRateByDate != null) {
                    foreach (var row in hotelRateDetail.HotelRateByDate) {
                        int nights = (DateTime.Parse(row.ExpireDate) - DateTime.Parse(row.EffectiveDate)).TotalDays.ToInt();
                        inclusions += string.Format("Rate starting {0:d} for {1} {2}: {3}; ", DateTime.Parse(row.EffectiveDate), nights, nights == 1 ? "night" : "nights", row.Base);
                    }
                }

                inclusions += string.Format(" Total: {0}; ", hotelRateDetail.Total);
            }
            else if (source is Vehicle) {
                var vehicle = source as Vehicle;

                inclusions += string.Format("{0} {1} Door Vehicle; ", vehicle.VehicleClass, vehicle.DoorCount == typeDoorCount.TwoToThreeDoors ? "2/3" : vehicle.DoorCount == typeDoorCount.TwoToFourDoors ? "2/4" : "4/5");

                if (!string.IsNullOrEmpty(vehicle.AcrissVehicleCode))
                    inclusions += string.Format("Vehicle Code: {0}; ", vehicle.AcrissVehicleCode);

                if (vehicle.VehicleRate.NumberOfPeriodsSpecified)
                    inclusions += string.Format("Periods: {0}; ", vehicle.VehicleRate.NumberOfPeriods);

                if (vehicle.FuelTypeSpecified)
                    inclusions += string.Format("Fuel Type: {0}; ", Utils.SplitStringByCapitals(vehicle.FuelType.ToString()));

                if (vehicle?.TransmissionType != null)
                    inclusions += string.Format("Transmission Type: {0}; ", Utils.SplitStringByCapitals(vehicle.TransmissionType.ToString()));

                inclusions += string.Format("Air Conditioning: {0}; ", vehicle.AirConditioning ? "Yes" : "No");

                if (vehicle.VehicleRate.UnlimitedMileageSpecified)
                    inclusions += string.Format("Unlimited Mileage: {0}; ", vehicle.VehicleRate.UnlimitedMileage ? "Yes" : "No");

                if (vehicle.VehicleRate.MileageAllowanceSpecified)
                    inclusions += string.Format("Mileage Allowance: {0}{1}; ", vehicle.VehicleRate.MileageAllowance, vehicle.VehicleRate.UnitsSpecified ? vehicle.VehicleRate.Units.ToString().ToLower() == "km" ? " km" : " miles" : string.Empty);

                inclusions = string.Format("{0}.{1}{1}", inclusions.Trim().TrimEnd(";"), AppConstants.HtmlLineBreak);

                if (vehicle.VehicleRate.SupplierRate?.RateForPeriod != null)
                    inclusions += string.Format("Rate: {0} {1}; ", vehicle.VehicleRate.SupplierRate?.RateForPeriod, (vehicle.VehicleRate.RatePeriodSpecified ? Utils.SplitStringByCapitals(vehicle.VehicleRate.RatePeriod.ToString()) : string.Empty).Trim());

                if (vehicle.VehicleRate.RequiredCharges != null)
                    inclusions += string.Format("Required Charges: {0}; ", vehicle.VehicleRate.RequiredCharges);

                if (vehicle.VehicleRate?.HourlyLateCharge?.RateForPeriod != null && decimal.Parse(vehicle.VehicleRate.HourlyLateCharge.RateForPeriod.Substring(3)) != 0)
                    inclusions += string.Format("Extra Hour Charge: {0}; ", vehicle.VehicleRate.HourlyLateCharge.RateForPeriod);

                if (vehicle.VehicleRate?.DailyLateCharge?.RateForPeriod != null && decimal.Parse(vehicle.VehicleRate.DailyLateCharge.RateForPeriod.Substring(3)) != 0)
                    inclusions += string.Format("Extra Day Charge: {0}; ", vehicle.VehicleRate.DailyLateCharge.RateForPeriod);

                if (vehicle.VehicleRate?.HourlyLateCharge?.ExtraMileageCharge != null && decimal.Parse(vehicle.VehicleRate.HourlyLateCharge.ExtraMileageCharge.Substring(3)) != 0)
                    inclusions += string.Format("Extra Mileage Charge: {0}; ", vehicle.VehicleRate.HourlyLateCharge.ExtraMileageCharge);

                if (vehicle.VehicleRate?.SupplierRate?.EstimatedTotalAmount != null && decimal.Parse(vehicle.VehicleRate?.SupplierRate.EstimatedTotalAmount.Substring(3)) != 0)
                    inclusions += string.Format("Estimated Total: {0}; ", vehicle.VehicleRate.SupplierRate.EstimatedTotalAmount);
            }
            else if (source is PassiveReservation) {
                var passiveReservation = source as PassiveReservation;

                if (passiveReservation.AssociatedRemark != null)
                    inclusions += string.Join(" ", passiveReservation.AssociatedRemark.Select(t => t.RemarkData));

                if (passiveReservation.AccountingRemark != null)
                    inclusions += string.Join(" ", passiveReservation.AccountingRemark.Select(t => t.RemarkData));
            }
            else if (source is RailReservation) {
                var railReservation = source as RailReservation;

                if (railReservation.AccountingRemark != null)
                    inclusions += string.Join(" ", railReservation.AccountingRemark.Select(t => t.RemarkData));
            }
            else if (source is CruiseReservation) {
                var cruiseReservation = source as CruiseReservation;

                if (cruiseReservation.AccountingRemark != null)
                    inclusions += string.Join(" ", cruiseReservation.AccountingRemark.Select(t => t.RemarkData));
            }

            inclusions = inclusions.Trim().TrimEnd(';').TrimEnd('.').TrimEnd(AppConstants.HtmlLineBreak.ToCharArray()).TrimEnd(';').TrimEnd('.');

            if (inclusions.Length == 0)
                return string.Empty;

            return string.Format("{0}.", inclusions);
        }

        private static string GetComments(GeneralRemark[] remark) {
            return remark == null ? string.Empty : string.Format("{0}.", string.Join(" ", remark.Select(t => t.RemarkData)));
        }

        private static PassengerType GetPassengerType(this BookingTraveler bookingTraveler, DateTime startDate) {
            string travelerType = string.Empty;

            if (string.IsNullOrEmpty(bookingTraveler.TravelerType)) {
                if (bookingTraveler.NameRemark != null) {
                    foreach (var nameRemark in bookingTraveler.NameRemark) {
                        if (!string.IsNullOrEmpty(nameRemark.RemarkData) && nameRemark.RemarkData.Length == 5) {
                            travelerType = nameRemark.RemarkData.Substring(2);
                            break;
                        }
                    }
                }
            }
            else {
                travelerType = bookingTraveler.TravelerType;
            }

            var passengerType = Biz.Dao.ClientLedger.Passenger.GetPassengerType(travelerType);

            if (passengerType == PassengerType.NotSpecified) {
                if (travelerType.Length > 1 && travelerType.StartsWith("C") && DataValidation.IsNumber(travelerType.Substring(1)))
                    return PassengerType.Child;

                if (bookingTraveler.SSR?.Any(t => t.Key == bookingTraveler.Key && t.Type == "INFT") == true)
                    return PassengerType.Infant;

                return bookingTraveler.DOBSpecified && startDate > DateTime.MinValue ? Biz.Dao.ClientLedger.Passenger.GetPassengerType(bookingTraveler.DOB, startDate) : PassengerType.NotSpecified;
            }

            return passengerType;
        }

        private static string GetTravelerType(this PassengerType passengerType) {
            switch (passengerType) {
                default:
                    return string.Empty;
                case PassengerType.Adult:
                    return "ADT";
                case PassengerType.Child:
                    return "CHD";
                case PassengerType.Infant:
                    return "INF";
                case PassengerType.Senior:
                    return "SCF";
                case PassengerType.Student:
                    return "STU";
                case PassengerType.Youth:
                    return "YTH";
            }
        }

        private static string GetNamePart(this BookingTravelerName bookingTravelerName, AppLazyContext lazyContext, string namePart) {
            var textInfo = CultureInfo.CurrentCulture.TextInfo;
            string name = Utils.RemoveExtraSpaces(string.Format("{0} {1} {2}", bookingTravelerName?.Prefix ?? string.Empty, bookingTravelerName?.First ?? string.Empty, bookingTravelerName?.Middle ?? string.Empty));

            if (string.IsNullOrEmpty(name))
                return string.Empty;

            foreach (var row in lazyContext.ContactTitle.Where(t => t.CrsCode.Length > 0)) {
                if (name.EndsWith(row.CrsCode, StringComparison.OrdinalIgnoreCase)) {
                    if (namePart == "Title")
                        return row.Name;

                    return textInfo.ToTitleCase(name.Left(bookingTravelerName.First.Length - row.CrsCode.Length).ToLower());
                }
            }

            if (namePart == "Title")
                return string.Empty;

            return textInfo.ToTitleCase(name.ToLower());
        }

        private static string GetPhoneNo(PhoneNumber phoneNumber) {
            string result = phoneNumber == null ? string.Empty : string.Format("{0} {1} {2}", phoneNumber.CountryCode, phoneNumber.AreaCode, phoneNumber.Number).Trim();
            return new string(result.Where(t => char.IsDigit(t) || char.IsWhiteSpace(t)).ToArray());
        }

        private static string GetPhoneNo(PhoneNumber[] phoneNumber, PhoneNumberType type) {
            PhoneNumber phoneNo = null;

            if (type == PhoneNumberType.Other) {
                phoneNo = phoneNumber?.FirstOrDefault();
            }
            else {
                phoneNo = phoneNumber?.FirstOrDefault(t => t.Type == type);
            }

            return GetPhoneNo(phoneNo);
        }

        private static string GetTicketNo(this Ticket[] ticket) {
            if (ticket == null || ticket.Length == 0)
                return string.Empty;

            string ticketNo = ticket[0].TicketNumber;

            if (ticket.Length == 1)
                return ticketNo;

            string ticketNoConjunction = ticket[ticket.Length - 1].TicketNumber.Right(3);

            if (ticketNoConjunction != ticketNo.Right(3))
                ticketNo = string.Format("{0}/{1}", ticketNo, ticketNoConjunction);

            return ticketNo;
        }

        private static string GetAirlineSeatingSsrCode(AirlineSeating airlineSeating, string seatNo) {
            if (!string.IsNullOrEmpty(seatNo))
                return "NSST";

            switch (airlineSeating) {
                default:
                    throw new InvalidOperationException("Invalid Airline Seating option.");
                case AirlineSeating.FrontAisle:
                case AirlineSeating.MiddleAisle:
                case AirlineSeating.RearAisle:
                    return "NSSA";
                case AirlineSeating.FrontWindow:
                case AirlineSeating.MiddleWindow:
                case AirlineSeating.RearWindow:
                    return "NSSW";
                case AirlineSeating.BulkheadAisle:
                case AirlineSeating.BulkheadWindow:
                case AirlineSeating.BulkheadCentre:
                    return "NSSB";
            }
        }

        private static PassiveSegmentDetailsModel GetPassiveSegmentDetails(this string text, AppLazyContext lazyContext, int customerId, string segmentType) {
            var passiveSegmentDetails = new PassiveSegmentDetailsModel();

            if (string.IsNullOrEmpty(text))
                return passiveSegmentDetails;

            var textInfo = CultureInfo.CurrentCulture.TextInfo;

            if (segmentType == "Hotel") {
                foreach (string value in text.Split("/", StringSplitOptions.RemoveEmptyEntries)) {
                    if (value.StartsWith("H-")) {
                        passiveSegmentDetails.SupplierName = textInfo.ToTitleCase(value.TrimStart("H-").Trim().ToLower());
                    }
                    else if (value.StartsWith("P-")) {
                        passiveSegmentDetails.SupplierCrsCode = value.TrimStart("P-").Trim();
                    }
                    else if (value.StartsWith("CF-")) {
                        passiveSegmentDetails.ConfirmationNo = value.TrimStart("CF-").Trim();
                    }
                    else if (value.StartsWith("W-")) {
                        string[] textParts = value.Split('*');
                        int i = 0;

                        if (passiveSegmentDetails.SupplierName.Length == 0) {
                            passiveSegmentDetails.SupplierName = textInfo.ToTitleCase(textParts[0].TrimStart("W-").Trim().ToLower());
                            i = 1;
                        }

                        if (textParts.Length > i)
                            passiveSegmentDetails.Address = textInfo.ToTitleCase(textParts[i].TrimStart("W-").Trim().ToLower());

                        if (textParts.Length > i + 1)
                            passiveSegmentDetails.Locality = textInfo.ToTitleCase(textParts[i + 1].Trim().ToLower());

                        if (textParts.Length >= 4)
                            passiveSegmentDetails.Region = textParts[textParts.Length - 4].Trim();

                        passiveSegmentDetails.IsoCountryCode = textParts[textParts.Length - 3].Trim().Length == 2 ? textParts[textParts.Length - 3].Trim() : string.Empty;

                        if (passiveSegmentDetails.IsoCountryCode.Length == 0)
                            passiveSegmentDetails.IsoCountryCode = textParts[textParts.Length - 2].Trim().Length == 2 ? textParts[textParts.Length - 2].Trim() : string.Empty;

                        passiveSegmentDetails.PostCode = textParts[textParts.Length - 2].Trim();
                        passiveSegmentDetails.PhoneNo = textParts[textParts.Length - 1].Trim();

                        if (passiveSegmentDetails.Locality == passiveSegmentDetails.Region || passiveSegmentDetails.Locality == passiveSegmentDetails.IsoCountryCode)
                            passiveSegmentDetails.Locality = string.Empty;

                        if (passiveSegmentDetails.Region == passiveSegmentDetails.Address || passiveSegmentDetails.Region == passiveSegmentDetails.IsoCountryCode)
                            passiveSegmentDetails.Region = string.Empty;
                    }
                    else if (value.StartsWith("R-")) {
                        passiveSegmentDetails.RateBasis = value.TrimStart("R-").Trim();
                    }
                    else if (value.StartsWith("RQ-")) {
                        passiveSegmentDetails.CurrencyCode = value.TrimStart("RQ-").Trim().Left(3);
                        passiveSegmentDetails.Rate = decimal.Parse(value.TrimStart("RQ-").Trim().Substring(3));
                    }
                }
            }
            else if (segmentType == "Car") {
                bool isFirst = true;

                foreach (string value in text.Split("/", StringSplitOptions.RemoveEmptyEntries)) {
                    if (isFirst) {
                        passiveSegmentDetails.CarType = value.Substring(5).Trim();
                        isFirst = false;
                    }
                    else if (value.StartsWith("CF-")) {
                        passiveSegmentDetails.ConfirmationNo = value.TrimStart("CF-").Trim();
                    }
                    else if (value.StartsWith("PUP-")) {
                        passiveSegmentDetails.PickupLocation = value.TrimStart("PUP-").Trim();
                    }
                    else if (value.StartsWith("RT-")) {
                        passiveSegmentDetails.CurrencyCode = value.TrimStart("RT-").Trim().Left(3);

                        string rate = value.TrimStart("RT-").Trim().Substring(3);
                        rate = rate.Substring(0, rate.IndexOf(".") + 2);
                        passiveSegmentDetails.Rate = decimal.Parse(rate);
                    }
                }
            }
            else if (segmentType == "Surface") {
                foreach (string value in text.Split("/", StringSplitOptions.RemoveEmptyEntries)) {
                    if (value.StartsWith("BA-")) {
                        passiveSegmentDetails.SupplierName = textInfo.ToTitleCase(value.TrimStart("BA-").Trim().ToLower());
                    }
                    else if (value.StartsWith("CF-")) {
                        passiveSegmentDetails.ConfirmationNo = value.TrimStart("CF-").Trim();
                    }
                    else if (value.StartsWith("PU-")) {
                        string[] parts = value.TrimStart("PU-").Trim().Split('-');
                        passiveSegmentDetails.PickupLocation = parts.Length == 2 ? parts[1] : parts[0];
                    }
                    else if (value.StartsWith("DO-")) {
                        string[] parts = value.TrimStart("DO-").Trim().Split('-');
                        passiveSegmentDetails.DropoffLocation = parts.Length == 2 ? parts[1] : parts[0];
                    }
                    else if (value.StartsWith("RQ-")) {
                        passiveSegmentDetails.CurrencyCode = value.TrimStart("RQ-").Left(3);
                        passiveSegmentDetails.Rate = decimal.Parse(value.TrimStart("RQ-").Right(value.TrimStart("RQ-").Length - 3));
                    }
                    else if (value.Left(value.Length - 3).IsNumeric() && !value.Right(3).IsNumeric()) {
                        passiveSegmentDetails.CurrencyCode = value.Right(3);
                        passiveSegmentDetails.Rate = decimal.Parse(value.Left(value.Length - 3));
                    }
                }
            }

            if (passiveSegmentDetails.CurrencyCode != AppSettings.Setting(customerId).CurrencyCode) {
                decimal exchangeRate = Currency.GetExchangeRate(lazyContext, passiveSegmentDetails.CurrencyCode);

                passiveSegmentDetails.ForeignAmount = passiveSegmentDetails.Rate;
                passiveSegmentDetails.ExchangeRate = exchangeRate;

                if (exchangeRate != 0)
                    passiveSegmentDetails.Rate = Math.Round(passiveSegmentDetails.Rate / exchangeRate, 2);
            }

            return passiveSegmentDetails;
        }

        private static void ParseSsr(this BookingTraveler bookingTraveler, AppLazyContext lazyContext, DateTime startDate, Passenger passenger, List<PassengerDocument> passengerDocumentList) {
            if (bookingTraveler.SSR == null)
                return;

            DateTime birthDate = DateTime.MinValue;

            foreach (var ssr in bookingTraveler.SSR.Where(t => !string.IsNullOrEmpty(t.FreeText))) {
                var ssrValues = ssr.FreeText.Split('/');

                if (ssrValues.Length == 2) {
                    if (ssr.Type == "CHLD" || ssr.Type == "INFT") {
                        if (bookingTraveler.BookingTravelerName.First != ssrValues[1].Substring(0, ssrValues[1].Length - 7).Trim() || bookingTraveler.BookingTravelerName.Last != ssrValues[0])
                            return;

                        DateTime.TryParse(ssr.FreeText.Right(7), out birthDate);

                        if (birthDate > DateTime.MinValue) {
                            passenger.BirthDate = birthDate;

                            if (passenger.PassengerType == PassengerType.NotSpecified && startDate > DateTime.MinValue)
                                passenger.PassengerType = Biz.Dao.ClientLedger.Passenger.GetPassengerType(passenger.BirthDate, startDate);
                        }
                    }

                    return;
                }

                if (ssr.Type != "DOCS")
                    continue;

                DateTime.TryParse(ssrValues[4], out birthDate);

                if (birthDate > DateTime.Today)
                    birthDate = birthDate.AddYears(-100);

                if (birthDate > DateTime.MinValue) {
                    passenger.BirthDate = birthDate;

                    if (startDate > DateTime.MinValue) {
                        if (passenger.Age == 0)
                            passenger.Age = Biz.Dao.ClientLedger.Passenger.GetAge(passenger.BirthDate, startDate);

                        if (passenger.PassengerType == PassengerType.NotSpecified)
                            passenger.PassengerType = Biz.Dao.ClientLedger.Passenger.GetPassengerType(passenger.BirthDate, startDate);
                    }
                }

                passenger.Gender = ssrValues[5] == "M" ? Gender.Male : ssrValues[5] == "F" ? Gender.Female : ContactTitle.GetContactTitle(lazyContext, passenger.Title).Gender;

                if (passengerDocumentList == null) {
                    if (passenger.BirthDate > DateTime.MinValue)
                        return;

                    continue;
                }

                DateTime.TryParse(ssrValues[6], out DateTime expiryDate);

                var documentType = ssrValues[0] == "P" ? DocumentType.Passport : DocumentType.Visa;
                string documentNo = ssrValues[2];

                var issuingCountry = Country.GetCountry(lazyContext, ssrValues[1], true);

                if (issuingCountry.Id == -1)
                    issuingCountry = Country.GetCountry(lazyContext, ssrValues[1]);

                var nationality = Country.GetCountry(lazyContext, ssrValues[3], true);

                if (nationality.Id == -1)
                    nationality = Country.GetCountry(lazyContext, ssrValues[3]);

                if (passengerDocumentList.Any(t => t.DocumentType == documentType && t.DocumentNo.ToLower() == documentNo.ToLower() && t.IssuingCountryId == issuingCountry.Id))
                    continue;

                passengerDocumentList.Add(new PassengerDocument {
                    CrsPassengerKey = passenger.CrsKey,
                    DocumentType = documentType,
                    DocumentNo = documentNo,
                    IssuingCountryId = issuingCountry.Id,
                    NationalityId = nationality.Id,
                    ExpiryDate = expiryDate,
                    IssueDate = expiryDate > DateTime.MinValue && issuingCountry.Code == "AU" ? expiryDate.AddYears(-10) : DateTime.MinValue
                });
            }
        }

        private class AirSegmentModel {
            public string Key { get; set; }
            public string FlightNo { get; set; }
            public string Class { get; set; }
            public string DepartureCityCode { get; set; }
            public int DepartureCountryId { get; set; }
            public string DepartureTime { get; set; }
            public string ArrivalCityCode { get; set; }
            public string ArrivalTime { get; set; }
            public int ArrivalCountryId { get; set; }
            public string AirlineCode { get; set; }
        }

        private class PassiveSegmentDetailsModel {
            public PassiveSegmentDetailsModel() {
                SupplierName = string.Empty;
                SupplierCrsCode = string.Empty;
                ConfirmationNo = string.Empty;
                Address = string.Empty;
                Locality = string.Empty;
                Region = string.Empty;
                PostCode = string.Empty;
                IsoCountryCode = string.Empty;
                PhoneNo = string.Empty;
                RateBasis = string.Empty;
                CurrencyCode = string.Empty;
                CarType = string.Empty;
                PickupLocation = string.Empty;
                DropoffLocation = string.Empty;
            }

            public string SupplierName { get; set; }
            public string SupplierCrsCode { get; set; }
            public string ConfirmationNo { get; set; }
            public string Address { get; set; }
            public string Locality { get; set; }
            public string Region { get; set; }
            public string PostCode { get; set; }
            public string IsoCountryCode { get; set; }
            public string PhoneNo { get; set; }
            public string RateBasis { get; set; }
            public string CurrencyCode { get; set; }
            public string CarType { get; set; }
            public string PickupLocation { get; set; }
            public string DropoffLocation { get; set; }
            public decimal Rate { get; set; }
            public decimal ExchangeRate { get; set; }
            public decimal ForeignAmount { get; set; }
        }

        [Serializable]
        private class CityCodeModel {
            public string CityCode { get; set; }
            public int CountryId { get; set; }
        }

        public static class UnitTest {
            public static decimal GetAirSegmentAmount(AppLazyContext lazyContext, string fareCalc, string fareBasis, string arrivalCityCode, int arrivalCountryId, string airlineCode) {
                return Travelport.GetAirSegmentAmount(lazyContext, fareCalc, fareBasis, arrivalCityCode, arrivalCountryId, airlineCode);
            }

            public static object GetPassiveSegmentDetails(AppLazyContext lazyContext, int customerId, string text, string segmentType) {
                return text.GetPassiveSegmentDetails(lazyContext, customerId, segmentType);
            }
        }
    }

    internal static class UniversalReq {
        public static async Task<UniversalServiceResponse2> CreatePnr(PassiveCreateReservationReq request, bool isDevelopmentMode) {
            var client = new PassiveReservationServicePortTypeClient(PassiveReservationServicePortTypeClient.EndpointConfiguration.PassiveReservationServicePort, string.Format("{0}PassiveService", TravelportCommon.Endpoint(isDevelopmentMode)));

            client.ClientCredentials.UserName.UserName = TravelportCommon.UserName(isDevelopmentMode);
            client.ClientCredentials.UserName.Password = TravelportCommon.Password(isDevelopmentMode);

            client.Endpoint.Binding = TravelportCommon.HttpBinding;

            try {
                var httpHeaders = TravelportCommon.GetHttpHeaders(isDevelopmentMode);
                client.Endpoint.EndpointBehaviors.Add(new HttpHeadersEndpointBehavior(httpHeaders));
                return await client.serviceAsync(null, request);
            }
            catch {
                client?.Abort();
                throw;
            }
        }

        public static async Task<UniversalServiceResponse1> RetrievePnr(string pnrRef, string pseudoCityCode, int customerId, bool isDevelopmentMode) {
            var request = new UniversalRecordRetrieveReq {
                TraceId = Guid.NewGuid().ToString(),
                TargetBranch = TravelportCommon.TargetBranch(customerId, isDevelopmentMode),
                ReturnUnmaskedData = isDevelopmentMode,
                BillingPointOfSaleInfo = new BillingPointOfSaleInfo {
                    OriginApplication = TravelportCommon.OriginApplication
                },
                Item = new UniversalRecordRetrieveReqProviderReservationInfo {
                    ProviderCode = TravelportCommon.ProviderCode,
                    ProviderLocatorCode = pnrRef
                }
            };

            if (!string.IsNullOrEmpty(pseudoCityCode)) {
                request.OverridePCC = new OverridePCC {
                    ProviderCode = TravelportCommon.ProviderCode,
                    PseudoCityCode = pseudoCityCode
                };
            }

            var client = new UniversalRecordRetrieveServicePortTypeClient(UniversalRecordRetrieveServicePortTypeClient.EndpointConfiguration.UniversalRecordRetrieveServicePort, string.Format("{0}UniversalRecordService", TravelportCommon.Endpoint(isDevelopmentMode)));

            client.ClientCredentials.UserName.UserName = TravelportCommon.UserName(isDevelopmentMode);
            client.ClientCredentials.UserName.Password = TravelportCommon.Password(isDevelopmentMode);

            client.Endpoint.Binding = TravelportCommon.HttpBinding;

            try {
                var httpHeaders = TravelportCommon.GetHttpHeaders(isDevelopmentMode);
                client.Endpoint.EndpointBehaviors.Add(new HttpHeadersEndpointBehavior(httpHeaders));
                return await client.serviceAsync(null, null, request);
            }
            catch {
                client?.Abort();
                throw;
            }
        }
    }

    internal static class AirReq {
        internal static async Task<AirServiceResponse4> RetrievePnr(UniversalServiceResponse1 pnr, int customerId, bool isDevelopmentMode) {
            var request = new AirRetrieveDocumentReq {
                TraceId = Guid.NewGuid().ToString(),
                AuthorizedBy = "TRAVELOG",
                TargetBranch = TravelportCommon.TargetBranch(customerId, isDevelopmentMode),
                ProviderCode = TravelportCommon.ProviderCode,
                BillingPointOfSaleInfo = new Services.Travelport.Air.BillingPointOfSaleInfo {
                    OriginApplication = TravelportCommon.OriginApplication,
                },
                ItemsElementName = new ItemsChoiceType1[] { ItemsChoiceType1.AirReservationLocatorCode },
                Items = pnr.UniversalRecordRetrieveRsp.UniversalRecord.Items?.Select(t => new AirReservationLocatorCode { Value = t.LocatorCode })?.ToArray()
            };

            var client = new AirRetrieveDocumentPortTypeClient(AirRetrieveDocumentPortTypeClient.EndpointConfiguration.AirRetrieveDocumentBindingPort, string.Format("{0}AirService", TravelportCommon.Endpoint(isDevelopmentMode)));

            client.ClientCredentials.UserName.UserName = TravelportCommon.UserName(isDevelopmentMode);
            client.ClientCredentials.UserName.Password = TravelportCommon.Password(isDevelopmentMode);

            client.Endpoint.Binding = TravelportCommon.HttpBinding;

            try {
                var httpHeaders = TravelportCommon.GetHttpHeaders(isDevelopmentMode);
                client.Endpoint.EndpointBehaviors.Add(new HttpHeadersEndpointBehavior(httpHeaders));
                return await client.serviceAsync(request);
            }
            catch {
                client?.Abort();
                throw;
            }
        }

        internal static async Task<AirServiceResponse1> RetrieveFlightDetails(typeBaseAirSegment[] airSegments, int customerId, string pseudoCityCode, bool isDevelopmentMode) {
            var request = new FlightDetailsReq {
                TraceId = Guid.NewGuid().ToString(),
                TargetBranch = TravelportCommon.TargetBranch(customerId, isDevelopmentMode),
                AirSegment = airSegments,
                BillingPointOfSaleInfo = new Services.Travelport.Air.BillingPointOfSaleInfo {
                    OriginApplication = TravelportCommon.OriginApplication
                }
            };

            if (!string.IsNullOrEmpty(pseudoCityCode)) {
                request.OverridePCC = new Services.Travelport.Air.OverridePCC {
                    ProviderCode = TravelportCommon.ProviderCode,
                    PseudoCityCode = pseudoCityCode
                };
            }

            var client = new FlightDetailsPortTypeClient(FlightDetailsPortTypeClient.EndpointConfiguration.FlightDetailsPort, string.Format("{0}FlightService", TravelportCommon.Endpoint(isDevelopmentMode)));

            client.ClientCredentials.UserName.UserName = TravelportCommon.UserName(isDevelopmentMode);
            client.ClientCredentials.UserName.Password = TravelportCommon.Password(isDevelopmentMode);

            client.Endpoint.Binding = TravelportCommon.HttpBinding;

            try {
                var httpHeaders = TravelportCommon.GetHttpHeaders(isDevelopmentMode);
                client.Endpoint.EndpointBehaviors.Add(new HttpHeadersEndpointBehavior(httpHeaders));
                return await client.serviceAsync(request);
            }
            catch {
                client?.Abort();
                throw;
            }
        }

        internal static async Task<AirServiceResponse3> RetrieveAirPrice(UniversalRecordRetrieveRsp pnr, typeBaseAirSegment[] airSegments, int customerId, bool isDevelopmentMode) {
            var request = new AirPriceReq {
                TraceId = Guid.NewGuid().ToString(),
                TargetBranch = TravelportCommon.TargetBranch(customerId, isDevelopmentMode),
                CheckFlightDetails = false,
                BillingPointOfSaleInfo = new Services.Travelport.Air.BillingPointOfSaleInfo {
                    OriginApplication = TravelportCommon.OriginApplication
                },
                AirItinerary = new AirItinerary {
                    AirSegment = airSegments
                },
                AirPricingCommand = airSegments.Select(t => new AirPricingCommand {
                    CabinClass = t.CabinClass,
                    AirPricingModifiers = new AirPricingModifiers {
                        PlatingCarrier = t.Carrier
                    }
                }).ToArray(),
                SearchPassenger = pnr.UniversalRecord.BookingTraveler.Select(t => new SearchPassenger {
                    Key = t.Key,
                    Code = t.TravelerType ?? "ADT",
                    Age = t.Age
                }).Take(1).ToArray()
            };

            AddPointOfSale(request, TravelportCommon.OriginApplication);

            var client = new AirPricePortTypeClient(AirPricePortTypeClient.EndpointConfiguration.AirPricePort, string.Format("{0}AirService", TravelportCommon.Endpoint(isDevelopmentMode)));

            client.ClientCredentials.UserName.UserName = TravelportCommon.UserName(isDevelopmentMode);
            client.ClientCredentials.UserName.Password = TravelportCommon.Password(isDevelopmentMode);

            client.Endpoint.Binding = TravelportCommon.HttpBinding;

            try {
                var httpHeaders = TravelportCommon.GetHttpHeaders(isDevelopmentMode);
                client.Endpoint.EndpointBehaviors.Add(new HttpHeadersEndpointBehavior(httpHeaders));
                return await client.serviceAsync(null, request);
            }
            catch {
                client?.Abort();
                throw;
            }
        }

        internal static async Task<AirServiceResponse2> LowFareShop(int customerId, string originAirportCode, string destinationAirportCode, bool solutionResult, bool isDevelopmentMode) {
            var request = new LowFareSearchReq {
                TraceId = Guid.NewGuid().ToString(),
                TargetBranch = TravelportCommon.TargetBranch(customerId, isDevelopmentMode),
                BillingPointOfSaleInfo = new Services.Travelport.Air.BillingPointOfSaleInfo {
                    OriginApplication = TravelportCommon.OriginApplication
                },
                SearchPassenger = AddSearchPassenger(),
                AirSearchModifiers = CreateModifiersWithProviders(new string[] { TravelportCommon.ProviderCode }, 25),
                SolutionResult = solutionResult
            };

            AddPointOfSale(request, TravelportCommon.OriginApplication);

            var outbound = CreateSearchLeg(originAirportCode, destinationAirportCode);

            request.Items = new SearchAirLeg[1];
            request.Items.SetValue(outbound, 0);

            var client = new AirLowFareSearchPortTypeClient(AirLowFareSearchPortTypeClient.EndpointConfiguration.AirLowFareSearchPort, string.Format("{0}AirService", TravelportCommon.Endpoint(isDevelopmentMode)));

            client.ClientCredentials.UserName.UserName = TravelportCommon.UserName(isDevelopmentMode);
            client.ClientCredentials.UserName.Password = TravelportCommon.Password(isDevelopmentMode);

            client.Endpoint.Binding = TravelportCommon.HttpBinding;

            try {
                var httpHeaders = TravelportCommon.GetHttpHeaders(isDevelopmentMode);
                client.Endpoint.EndpointBehaviors.Add(new HttpHeadersEndpointBehavior(httpHeaders));
                return await client.serviceAsync(null, request);
            }
            catch {
                client?.Abort();
                throw;
            }
        }

        internal static SearchAirLeg CreateSearchLeg(string originAirportCode, string destinationAirportCode) {
            var origin = new typeSearchLocation {
                Item = new Airport {
                    Code = originAirportCode
                }
            };

            var destination = new typeSearchLocation {
                Item = new Airport {
                    Code = destinationAirportCode
                }
            };

            return CreateSearchLeg(origin, destination);
        }

        private static SearchAirLeg CreateSearchLeg(typeSearchLocation origin, typeSearchLocation destination) {
            var leg = new SearchAirLeg {
                SearchOrigin = new typeSearchLocation[1],
                SearchDestination = new typeSearchLocation[1]
            };

            leg.SearchOrigin.SetValue(origin, 0);
            leg.SearchDestination.SetValue(destination, 0);

            return leg;
        }

        internal static typeSearchLocation CreateLocationNear(string cityOrAirportCode) {
            return new typeSearchLocation {
                Item = new CityOrAirport {
                    Code = cityOrAirportCode,
                    PreferCity = true
                },
                Distance = new Services.Travelport.Air.Distance {
                    Units = Services.Travelport.Air.DistanceUnits.KM,
                    Value = "80"
                }
            };
        }

        internal static AirSearchModifiers CreateModifiersWithProviders(string[] providerCode, int maxSolutions = 0) {
            var providers = new List<Services.Travelport.Air.Provider>();

            for (int i = 0; i < providerCode.Length; i++) {
                providers.Add(new Services.Travelport.Air.Provider {
                    Code = providerCode[i]
                });
            }

            return new AirSearchModifiers {
                PreferredProviders = providers.ToArray(),
                MaxSolutions = maxSolutions == 0 ? string.Empty : maxSolutions.ToString()
            };
        }

        internal static AirPricingModifiers AddAirPriceModifiers(typeAdjustmentType adjustmentType, int amount) {
            var fareAdjustment = new Services.Travelport.Air.ManualFareAdjustment {
                PassengerRef = "1",
                AppliedOn = Services.Travelport.Air.typeAdjustmentTarget.Base,
                Value = amount
            };

            if (typeAdjustmentType.Amount.CompareTo(adjustmentType) == 0) {
                fareAdjustment.AdjustmentType = typeAdjustmentType.Amount;
            }
            else if (typeAdjustmentType.Percentage.CompareTo(adjustmentType) == 0) {
                fareAdjustment.AdjustmentType = typeAdjustmentType.Percentage;
            }

            return new AirPricingModifiers {
                ManualFareAdjustment = new Services.Travelport.Air.ManualFareAdjustment[] {
                    fareAdjustment
                }
            };
        }

        internal static void AddPointOfSale(BaseSearchReq request, string appName) {
            request.BillingPointOfSaleInfo = new Services.Travelport.Air.BillingPointOfSaleInfo {
                OriginApplication = appName
            };
        }

        internal static void AddPointOfSale(BaseCoreReq request, string appName) {
            request.BillingPointOfSaleInfo = new Services.Travelport.Air.BillingPointOfSaleInfo {
                OriginApplication = appName
            };
        }

        internal static void AddEconomyPreferred(SearchAirLeg outbound) {
            outbound.AirLegModifiers = new AirLegModifiers {
                PreferredCabins = new Services.Travelport.Air.PreferredCabins {
                    CabinClass = new Services.Travelport.Air.CabinClass {
                        Type = "Economy"
                    }
                }
            };
        }

        internal static void AddDepartureDate(SearchAirLeg outbound, string departureDate) {
            outbound.Items = new typeFlexibleTimeSpec[] {
                new typeFlexibleTimeSpec {
                    PreferredTime = departureDate
                }
            };
        }

        internal static void AddSearchPassengers(BaseLowFareSearchReq request, int n) {
            var passengerList = new List<SearchPassenger>();

            for (int i = 0; i < n; i++) {
                passengerList.Add(new SearchPassenger {
                    Code = "ADT"
                });
            }

            request.SearchPassenger = passengerList.ToArray();
        }

        internal static SearchPassenger[] AddSearchPassenger() {
            return new SearchPassenger[] {
                new SearchPassenger {
                    Code = "ADT",
                    BookingTravelerRef = "gr8AVWGCR064r57Jt0+8bA=="
                }
            };
        }
    }

    internal class HttpHeadersEndpointBehavior : IEndpointBehavior {
        private readonly Dictionary<string, string> HttpHeaders;

        internal HttpHeadersEndpointBehavior(Dictionary<string, string> httpHeaders) {
            HttpHeaders = httpHeaders;
        }

        public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters) {
        }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime) {
            var inspector = new HttpHeaderMessageInspector(HttpHeaders);
            clientRuntime.ClientMessageInspectors.Add(inspector);
        }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher) {
        }

        public void Validate(ServiceEndpoint endpoint) {
        }
    }

    internal class HttpHeaderMessageInspector : IClientMessageInspector {
        private readonly Dictionary<string, string> HttpHeaders;

        public HttpHeaderMessageInspector() {
        }

        public HttpHeaderMessageInspector(Dictionary<string, string> httpHeaders) {
            HttpHeaders = httpHeaders;
        }

        public void AfterReceiveReply(ref Message reply, object correlationState) {
        }

        public object BeforeSendRequest(ref Message request, IClientChannel channel) {
            if (request.Properties.TryGetValue(HttpRequestMessageProperty.Name, out object httpRequestMessageObject)) {
                var httpRequestMessage = httpRequestMessageObject as HttpRequestMessageProperty;

                string userName = string.Empty;
                string passWord = string.Empty;

                foreach (var httpHeader in HttpHeaders) {
                    //httpRequestMessage.Headers[httpHeader.Key] = httpHeader.Value;

                    if (httpHeader.Key.CompareTo("Username") == 0) {
                        userName = httpHeader.Value;
                    }
                    else if (httpHeader.Key.CompareTo("Password") == 0) {
                        passWord = httpHeader.Value;
                    }
                }

                httpRequestMessage.Headers[HttpRequestHeader.Authorization] = "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes(userName + ":" + passWord));
            }
            else {
                var httpRequestMessage = new HttpRequestMessageProperty();

                foreach (var httpHeader in HttpHeaders) {
                    httpRequestMessage.Headers.Add(httpHeader.Key, httpHeader.Value);
                }

                request.Properties.Add(HttpRequestMessageProperty.Name, httpRequestMessage);
            }

            return null;
        }
    }

    internal static class TravelportCommon {
        public const string OriginApplication = "UAPI";
        public const string ProviderCode = "1G";

        public static string Endpoint(bool isDevelopmentMode) {
            return isDevelopmentMode ? "https://apac.universal-api.pp.travelport.com/B2BGateway/connect/uAPI/" : "https://apac.universal-api.travelport.com/B2BGateway/connect/uAPI/";
        }

        public static string UserName(bool isDevelopmentMode) {
            return isDevelopmentMode ? "Universal API/uAPI1597841436-5075a99d" : "Universal API/uAPI3152111232-4dcd72fa";
        }

        public static string Password(bool isDevelopmentMode) {
            return isDevelopmentMode ? "nK+56mQ%-4" : "T&c2+3Db7p";
        }

        public static string TargetBranch(int customerId, bool isDevelopmentMode) {
            if (isDevelopmentMode)
                return "P7117887";

            switch (AppSettings.Setting(customerId).CountryCode) {
                default:
                    throw new InvalidOperationException("Invalid Country Code.");
                case "AUS":
                    return "P3455669";
                case "NZL":
                    return "P3455668";
            }
        }

        public static Dictionary<string, string> GetHttpHeaders(bool isDevelopmentMode) {
            string authorization = string.Format("Basic {0}", Convert.ToBase64String(Encoding.ASCII.GetBytes(string.Format("{0}:{1}", UserName(isDevelopmentMode), Password(isDevelopmentMode)))));

            return new Dictionary<string, string> {
                { "Authorization", authorization },
                { "Accept-Encoding", "gzip" },
                { "Content-Type", "text/xml;charset=utf-8" }
            };
        }

        public static BasicHttpBinding HttpBinding {
            get {
                var binding = new BasicHttpBinding {
                    MaxBufferSize = int.MaxValue,
                    ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max,
                    MaxReceivedMessageSize = int.MaxValue,
                    AllowCookies = true
                };

                binding.Security.Mode = BasicHttpSecurityMode.Transport;
                binding.TransferMode = TransferMode.Buffered;
                binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;

                return binding;
            }
        }
    }
}