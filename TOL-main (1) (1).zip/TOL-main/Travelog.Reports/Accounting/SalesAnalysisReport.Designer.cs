namespace Travelog.Reports.Accounting {
	partial class SalesAnalysisReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SalesAnalysisReport));
			Telerik.Reporting.Drawing.FormattingRule formattingRule1 = new Telerik.Reporting.Drawing.FormattingRule();
			this.CashTotal = new Telerik.Reporting.TextBox();
			this.CashNonCommissionableTotal = new Telerik.Reporting.TextBox();
			this.CreditCardNonCommissionableTotal = new Telerik.Reporting.TextBox();
			this.CreditCardTotal = new Telerik.Reporting.TextBox();
			this.AmountGrossTotal = new Telerik.Reporting.TextBox();
			this.NonCommissionableTotal = new Telerik.Reporting.TextBox();
			this.AmountNetTotal = new Telerik.Reporting.TextBox();
			this.CommissionTotal = new Telerik.Reporting.TextBox();
			this.YieldTotal = new Telerik.Reporting.TextBox();
			this.CashYtd = new Telerik.Reporting.TextBox();
			this.CashNonCommissionableYtd = new Telerik.Reporting.TextBox();
			this.CreditCardNonCommissionableYtd = new Telerik.Reporting.TextBox();
			this.CreditCardYtd = new Telerik.Reporting.TextBox();
			this.AmountGrossYtd = new Telerik.Reporting.TextBox();
			this.NonCommissionableYtd = new Telerik.Reporting.TextBox();
			this.AmountNetYtd = new Telerik.Reporting.TextBox();
			this.CommissionYtd = new Telerik.Reporting.TextBox();
			this.YieldYtd = new Telerik.Reporting.TextBox();
			this.TransactionType = new Telerik.Reporting.TextBox();
			this.DepartureDate = new Telerik.Reporting.TextBox();
			this.CashNonCommissionable = new Telerik.Reporting.TextBox();
			this.Category = new Telerik.Reporting.TextBox();
			this.Consultant = new Telerik.Reporting.TextBox();
			this.Cash = new Telerik.Reporting.TextBox();
			this.Source = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.DocumentType = new Telerik.Reporting.TextBox();
			this.DocumentNo = new Telerik.Reporting.TextBox();
			this.DocumentDate = new Telerik.Reporting.TextBox();
			this.Account = new Telerik.Reporting.TextBox();
			this.Airline = new Telerik.Reporting.TextBox();
			this.Passenger = new Telerik.Reporting.TextBox();
			this.Reference = new Telerik.Reporting.TextBox();
			this.Debtor = new Telerik.Reporting.TextBox();
			this.Creditor = new Telerik.Reporting.TextBox();
			this.Supplier = new Telerik.Reporting.TextBox();
			this.SaleType = new Telerik.Reporting.TextBox();
			this.DiscountReason = new Telerik.Reporting.TextBox();
			this.Group = new Telerik.Reporting.TextBox();
			this.Class = new Telerik.Reporting.TextBox();
			this.Agency = new Telerik.Reporting.TextBox();
			this.Destination = new Telerik.Reporting.TextBox();
			this.Region = new Telerik.Reporting.TextBox();
			this.Location = new Telerik.Reporting.TextBox();
			this.Agent = new Telerik.Reporting.TextBox();
			this.CreditCardNonCommissionable = new Telerik.Reporting.TextBox();
			this.CreditCard = new Telerik.Reporting.TextBox();
			this.NonCommissionable = new Telerik.Reporting.TextBox();
			this.AmountGross = new Telerik.Reporting.TextBox();
			this.AmountNet = new Telerik.Reporting.TextBox();
			this.Commission = new Telerik.Reporting.TextBox();
			this.Yield = new Telerik.Reporting.TextBox();
			this.OfferedFare = new Telerik.Reporting.TextBox();
			this.OfferedReason = new Telerik.Reporting.TextBox();
			this.PaxNo = new Telerik.Reporting.TextBox();
			this.ReportFooterSection1 = new Telerik.Reporting.ReportFooterSection();
			this.LabelTotal = new Telerik.Reporting.TextBox();
			this.LabelYtd = new Telerik.Reporting.TextBox();
			this.ReportHeaderSection1 = new Telerik.Reporting.ReportHeaderSection();
			this.DepartureDateHeader = new Telerik.Reporting.TextBox();
			this.DocumentTypeHeader = new Telerik.Reporting.TextBox();
			this.DocumentNoHeader = new Telerik.Reporting.TextBox();
			this.DocumentDateHeader = new Telerik.Reporting.TextBox();
			this.AccountHeader = new Telerik.Reporting.TextBox();
			this.AirlineHeader = new Telerik.Reporting.TextBox();
			this.PassengerHeader = new Telerik.Reporting.TextBox();
			this.ReferenceHeader = new Telerik.Reporting.TextBox();
			this.DebtorHeader = new Telerik.Reporting.TextBox();
			this.CreditorHeader = new Telerik.Reporting.TextBox();
			this.TransactionTypeHeader = new Telerik.Reporting.TextBox();
			this.SupplierHeader = new Telerik.Reporting.TextBox();
			this.SourceHeader = new Telerik.Reporting.TextBox();
			this.GroupHeader = new Telerik.Reporting.TextBox();
			this.DiscountReasonHeader = new Telerik.Reporting.TextBox();
			this.SaleTypeHeader = new Telerik.Reporting.TextBox();
			this.CategoryHeader = new Telerik.Reporting.TextBox();
			this.ClassHeader = new Telerik.Reporting.TextBox();
			this.DestinationHeader = new Telerik.Reporting.TextBox();
			this.LocationHeader = new Telerik.Reporting.TextBox();
			this.AgencyHeader = new Telerik.Reporting.TextBox();
			this.ConsultantHeader = new Telerik.Reporting.TextBox();
			this.RegionHeader = new Telerik.Reporting.TextBox();
			this.CashHeader = new Telerik.Reporting.TextBox();
			this.CashNonCommissionableHeader = new Telerik.Reporting.TextBox();
			this.AgentHeader = new Telerik.Reporting.TextBox();
			this.CreditCardHeader = new Telerik.Reporting.TextBox();
			this.CreditCardNonCommissionableHeader = new Telerik.Reporting.TextBox();
			this.AmountGrossHeader = new Telerik.Reporting.TextBox();
			this.NonCommissionableHeader = new Telerik.Reporting.TextBox();
			this.CommissionHeader = new Telerik.Reporting.TextBox();
			this.AmountNetHeader = new Telerik.Reporting.TextBox();
			this.YieldHeader = new Telerik.Reporting.TextBox();
			this.OfferedFareHeader = new Telerik.Reporting.TextBox();
			this.OfferedReasonHeader = new Telerik.Reporting.TextBox();
			this.PaxNoHeader = new Telerik.Reporting.TextBox();
			this.ReturnDateHeader = new Telerik.Reporting.TextBox();
			this.ReturnDate = new Telerik.Reporting.TextBox();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// CashTotal
			// 
			this.CashTotal.CanGrow = false;
			this.CashTotal.Format = "{0:C2}";
			this.CashTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(113.3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CashTotal.Name = "CashTotal";
			this.CashTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CashTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CashTotal.Style.Font.Bold = true;
			this.CashTotal.Style.Font.Name = "Calibri";
			this.CashTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CashTotal.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(0.6D);
			this.CashTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CashTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CashTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CashTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CashTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CashTotal.StyleName = "Normal.TableBody";
			this.CashTotal.Value = "= Sum(Fields.Cash)";
			// 
			// CashNonCommissionableTotal
			// 
			this.CashNonCommissionableTotal.CanGrow = false;
			this.CashNonCommissionableTotal.Format = "{0:C2}";
			this.CashNonCommissionableTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(116D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CashNonCommissionableTotal.Name = "CashNonCommissionableTotal";
			this.CashNonCommissionableTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CashNonCommissionableTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CashNonCommissionableTotal.Style.Font.Bold = true;
			this.CashNonCommissionableTotal.Style.Font.Name = "Calibri";
			this.CashNonCommissionableTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CashNonCommissionableTotal.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(0.6D);
			this.CashNonCommissionableTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CashNonCommissionableTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CashNonCommissionableTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CashNonCommissionableTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CashNonCommissionableTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CashNonCommissionableTotal.StyleName = "Normal.TableBody";
			this.CashNonCommissionableTotal.Value = "= Sum(Fields.CashNonCommissionable)";
			// 
			// CreditCardNonCommissionableTotal
			// 
			this.CreditCardNonCommissionableTotal.CanGrow = false;
			this.CreditCardNonCommissionableTotal.Format = "{0:C2}";
			this.CreditCardNonCommissionableTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(121.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CreditCardNonCommissionableTotal.Name = "CreditCardNonCommissionableTotal";
			this.CreditCardNonCommissionableTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditCardNonCommissionableTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditCardNonCommissionableTotal.Style.Font.Bold = true;
			this.CreditCardNonCommissionableTotal.Style.Font.Name = "Calibri";
			this.CreditCardNonCommissionableTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditCardNonCommissionableTotal.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(0.6D);
			this.CreditCardNonCommissionableTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditCardNonCommissionableTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditCardNonCommissionableTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditCardNonCommissionableTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditCardNonCommissionableTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CreditCardNonCommissionableTotal.StyleName = "Normal.TableBody";
			this.CreditCardNonCommissionableTotal.Value = "= Sum(Fields.CreditCardNonCommissionable)";
			// 
			// CreditCardTotal
			// 
			this.CreditCardTotal.CanGrow = false;
			this.CreditCardTotal.Format = "{0:C2}";
			this.CreditCardTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(118.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CreditCardTotal.Name = "CreditCardTotal";
			this.CreditCardTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditCardTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditCardTotal.Style.Font.Bold = true;
			this.CreditCardTotal.Style.Font.Name = "Calibri";
			this.CreditCardTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditCardTotal.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(0.6D);
			this.CreditCardTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditCardTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditCardTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditCardTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditCardTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CreditCardTotal.StyleName = "Normal.TableBody";
			this.CreditCardTotal.Value = "= Sum(Fields.CreditCard)";
			// 
			// AmountGrossTotal
			// 
			this.AmountGrossTotal.CanGrow = false;
			this.AmountGrossTotal.Format = "{0:C2}";
			this.AmountGrossTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(124.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountGrossTotal.Name = "AmountGrossTotal";
			this.AmountGrossTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGrossTotal.Style.Font.Bold = true;
			this.AmountGrossTotal.Style.Font.Name = "Calibri";
			this.AmountGrossTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGrossTotal.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(0.6D);
			this.AmountGrossTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountGrossTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGrossTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountGrossTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountGrossTotal.StyleName = "Normal.TableBody";
			this.AmountGrossTotal.Value = "= Sum(Fields.AmountGross)";
			// 
			// NonCommissionableTotal
			// 
			this.NonCommissionableTotal.CanGrow = false;
			this.NonCommissionableTotal.Format = "{0:C2}";
			this.NonCommissionableTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(126.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.NonCommissionableTotal.Name = "NonCommissionableTotal";
			this.NonCommissionableTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NonCommissionableTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NonCommissionableTotal.Style.Font.Bold = true;
			this.NonCommissionableTotal.Style.Font.Name = "Calibri";
			this.NonCommissionableTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NonCommissionableTotal.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(0.6D);
			this.NonCommissionableTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NonCommissionableTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NonCommissionableTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.NonCommissionableTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.NonCommissionableTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.NonCommissionableTotal.StyleName = "Normal.TableBody";
			this.NonCommissionableTotal.Value = "= Sum(Fields.NonCommissionable)";
			// 
			// AmountNetTotal
			// 
			this.AmountNetTotal.CanGrow = false;
			this.AmountNetTotal.Format = "{0:C2}";
			this.AmountNetTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(132.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountNetTotal.Name = "AmountNetTotal";
			this.AmountNetTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountNetTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountNetTotal.Style.Font.Bold = true;
			this.AmountNetTotal.Style.Font.Name = "Calibri";
			this.AmountNetTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountNetTotal.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(0.6D);
			this.AmountNetTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountNetTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountNetTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountNetTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountNetTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountNetTotal.StyleName = "Normal.TableBody";
			this.AmountNetTotal.Value = "= Sum(Fields.AmountNet)";
			// 
			// CommissionTotal
			// 
			this.CommissionTotal.CanGrow = false;
			this.CommissionTotal.Format = "{0:C2}";
			this.CommissionTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(129.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CommissionTotal.Name = "CommissionTotal";
			this.CommissionTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CommissionTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CommissionTotal.Style.Font.Bold = true;
			this.CommissionTotal.Style.Font.Name = "Calibri";
			this.CommissionTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CommissionTotal.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(0.6D);
			this.CommissionTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CommissionTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CommissionTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CommissionTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CommissionTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CommissionTotal.StyleName = "Normal.TableBody";
			this.CommissionTotal.Value = "= Sum(Fields.Commission)";
			// 
			// YieldTotal
			// 
			this.YieldTotal.CanGrow = false;
			this.YieldTotal.Format = "{0:P3}";
			this.YieldTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(134.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.YieldTotal.Name = "YieldTotal";
			this.YieldTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.YieldTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.YieldTotal.Style.Font.Bold = true;
			this.YieldTotal.Style.Font.Name = "Calibri";
			this.YieldTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.YieldTotal.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(0.6D);
			this.YieldTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.YieldTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.YieldTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.YieldTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.YieldTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.YieldTotal.StyleName = "Normal.TableBody";
			this.YieldTotal.Value = resources.GetString("YieldTotal.Value");
			// 
			// CashYtd
			// 
			this.CashYtd.CanGrow = false;
			this.CashYtd.Format = "";
			this.CashYtd.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(113.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CashYtd.Name = "CashYtd";
			this.CashYtd.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CashYtd.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CashYtd.Style.Font.Bold = true;
			this.CashYtd.Style.Font.Name = "Calibri";
			this.CashYtd.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CashYtd.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CashYtd.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CashYtd.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CashYtd.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CashYtd.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CashYtd.StyleName = "Normal.TableBody";
			this.CashYtd.Value = "";
			// 
			// CashNonCommissionableYtd
			// 
			this.CashNonCommissionableYtd.CanGrow = false;
			this.CashNonCommissionableYtd.Format = "";
			this.CashNonCommissionableYtd.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(116D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CashNonCommissionableYtd.Name = "CashNonCommissionableYtd";
			this.CashNonCommissionableYtd.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CashNonCommissionableYtd.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CashNonCommissionableYtd.Style.Font.Bold = true;
			this.CashNonCommissionableYtd.Style.Font.Name = "Calibri";
			this.CashNonCommissionableYtd.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CashNonCommissionableYtd.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CashNonCommissionableYtd.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CashNonCommissionableYtd.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CashNonCommissionableYtd.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CashNonCommissionableYtd.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CashNonCommissionableYtd.StyleName = "Normal.TableBody";
			this.CashNonCommissionableYtd.Value = "";
			// 
			// CreditCardNonCommissionableYtd
			// 
			this.CreditCardNonCommissionableYtd.CanGrow = false;
			this.CreditCardNonCommissionableYtd.Format = "";
			this.CreditCardNonCommissionableYtd.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(121.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditCardNonCommissionableYtd.Name = "CreditCardNonCommissionableYtd";
			this.CreditCardNonCommissionableYtd.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditCardNonCommissionableYtd.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditCardNonCommissionableYtd.Style.Font.Bold = true;
			this.CreditCardNonCommissionableYtd.Style.Font.Name = "Calibri";
			this.CreditCardNonCommissionableYtd.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditCardNonCommissionableYtd.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditCardNonCommissionableYtd.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditCardNonCommissionableYtd.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditCardNonCommissionableYtd.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditCardNonCommissionableYtd.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CreditCardNonCommissionableYtd.StyleName = "Normal.TableBody";
			this.CreditCardNonCommissionableYtd.Value = "";
			// 
			// CreditCardYtd
			// 
			this.CreditCardYtd.CanGrow = false;
			this.CreditCardYtd.Format = "";
			this.CreditCardYtd.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(118.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditCardYtd.Name = "CreditCardYtd";
			this.CreditCardYtd.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditCardYtd.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditCardYtd.Style.Font.Bold = true;
			this.CreditCardYtd.Style.Font.Name = "Calibri";
			this.CreditCardYtd.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditCardYtd.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditCardYtd.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditCardYtd.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditCardYtd.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditCardYtd.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CreditCardYtd.StyleName = "Normal.TableBody";
			this.CreditCardYtd.Value = "";
			// 
			// AmountGrossYtd
			// 
			this.AmountGrossYtd.CanGrow = false;
			this.AmountGrossYtd.Format = "";
			this.AmountGrossYtd.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(124.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossYtd.Name = "AmountGrossYtd";
			this.AmountGrossYtd.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossYtd.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGrossYtd.Style.Font.Bold = true;
			this.AmountGrossYtd.Style.Font.Name = "Calibri";
			this.AmountGrossYtd.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGrossYtd.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountGrossYtd.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossYtd.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGrossYtd.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountGrossYtd.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountGrossYtd.StyleName = "Normal.TableBody";
			this.AmountGrossYtd.Value = "";
			// 
			// NonCommissionableYtd
			// 
			this.NonCommissionableYtd.CanGrow = false;
			this.NonCommissionableYtd.Format = "";
			this.NonCommissionableYtd.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(126.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NonCommissionableYtd.Name = "NonCommissionableYtd";
			this.NonCommissionableYtd.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NonCommissionableYtd.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NonCommissionableYtd.Style.Font.Bold = true;
			this.NonCommissionableYtd.Style.Font.Name = "Calibri";
			this.NonCommissionableYtd.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NonCommissionableYtd.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NonCommissionableYtd.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NonCommissionableYtd.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.NonCommissionableYtd.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.NonCommissionableYtd.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.NonCommissionableYtd.StyleName = "Normal.TableBody";
			this.NonCommissionableYtd.Value = "";
			// 
			// AmountNetYtd
			// 
			this.AmountNetYtd.CanGrow = false;
			this.AmountNetYtd.Format = "";
			this.AmountNetYtd.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(132.2D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountNetYtd.Name = "AmountNetYtd";
			this.AmountNetYtd.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountNetYtd.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountNetYtd.Style.Font.Bold = true;
			this.AmountNetYtd.Style.Font.Name = "Calibri";
			this.AmountNetYtd.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountNetYtd.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountNetYtd.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountNetYtd.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountNetYtd.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountNetYtd.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountNetYtd.StyleName = "Normal.TableBody";
			this.AmountNetYtd.Value = "";
			// 
			// CommissionYtd
			// 
			this.CommissionYtd.CanGrow = false;
			this.CommissionYtd.Format = "";
			this.CommissionYtd.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(129.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CommissionYtd.Name = "CommissionYtd";
			this.CommissionYtd.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CommissionYtd.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CommissionYtd.Style.Font.Bold = true;
			this.CommissionYtd.Style.Font.Name = "Calibri";
			this.CommissionYtd.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CommissionYtd.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CommissionYtd.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CommissionYtd.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CommissionYtd.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CommissionYtd.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CommissionYtd.StyleName = "Normal.TableBody";
			this.CommissionYtd.Value = "";
			// 
			// YieldYtd
			// 
			this.YieldYtd.CanGrow = false;
			this.YieldYtd.Format = "{0:P3}";
			this.YieldYtd.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(134.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.YieldYtd.Name = "YieldYtd";
			this.YieldYtd.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.YieldYtd.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.YieldYtd.Style.Font.Bold = true;
			this.YieldYtd.Style.Font.Name = "Calibri";
			this.YieldYtd.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.YieldYtd.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.YieldYtd.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.YieldYtd.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.YieldYtd.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.YieldYtd.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.YieldYtd.StyleName = "Normal.TableBody";
			this.YieldYtd.Value = "";
			// 
			// TransactionType
			// 
			this.TransactionType.CanGrow = false;
			this.TransactionType.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TransactionType.Name = "TransactionType";
			this.TransactionType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TransactionType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TransactionType.Style.Font.Name = "Calibri";
			this.TransactionType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TransactionType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TransactionType.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TransactionType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TransactionType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TransactionType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TransactionType.StyleName = "Normal.TableBody";
			this.TransactionType.Value = "= Fields.TransactionTypeDescription";
			// 
			// DepartureDate
			// 
			this.DepartureDate.CanGrow = false;
			this.DepartureDate.Format = "{0:dd-MMM-yyyy}";
			this.DepartureDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(34.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DepartureDate.Name = "DepartureDate";
			this.DepartureDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DepartureDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DepartureDate.Style.Font.Name = "Calibri";
			this.DepartureDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DepartureDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DepartureDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DepartureDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DepartureDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DepartureDate.StyleName = "Normal.TableBody";
			this.DepartureDate.Value = "= Fields.DepartureDate";
			// 
			// CashNonCommissionable
			// 
			this.CashNonCommissionable.CanGrow = false;
			this.CashNonCommissionable.Format = "{0:C2}";
			this.CashNonCommissionable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(116D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CashNonCommissionable.Name = "CashNonCommissionable";
			this.CashNonCommissionable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CashNonCommissionable.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CashNonCommissionable.Style.Font.Name = "Calibri";
			this.CashNonCommissionable.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CashNonCommissionable.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CashNonCommissionable.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CashNonCommissionable.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CashNonCommissionable.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CashNonCommissionable.StyleName = "Normal.TableBody";
			this.CashNonCommissionable.Value = "= Fields.CashNonCommissionable";
			// 
			// Category
			// 
			this.Category.CanGrow = false;
			this.Category.Format = "{0:C2}";
			this.Category.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(83.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Category.Name = "Category";
			this.Category.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Category.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Category.Style.Font.Name = "Calibri";
			this.Category.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Category.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Category.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Category.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Category.StyleName = "Normal.TableBody";
			this.Category.Value = "= Fields.Category";
			// 
			// Consultant
			// 
			this.Consultant.CanGrow = false;
			this.Consultant.Format = "{0:C2}";
			this.Consultant.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(103.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Consultant.Name = "Consultant";
			this.Consultant.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Consultant.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Consultant.Style.Font.Name = "Calibri";
			this.Consultant.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Consultant.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Consultant.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Consultant.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Consultant.StyleName = "Normal.TableBody";
			this.Consultant.Value = "= Fields.Consultant";
			// 
			// Cash
			// 
			this.Cash.CanGrow = false;
			this.Cash.Format = "{0:C2}";
			this.Cash.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(113.3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Cash.Name = "Cash";
			this.Cash.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Cash.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Cash.Style.Font.Name = "Calibri";
			this.Cash.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Cash.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Cash.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Cash.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Cash.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Cash.StyleName = "Normal.TableBody";
			this.Cash.Value = "= Fields.Cash";
			// 
			// Source
			// 
			this.Source.CanGrow = false;
			this.Source.Format = "{0:C2}";
			this.Source.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(79.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Source.Name = "Source";
			this.Source.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Source.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Source.Style.Font.Name = "Calibri";
			this.Source.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Source.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Source.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Source.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Source.StyleName = "Normal.TableBody";
			this.Source.Value = "= Fields.Source";
			// 
			// Detail
			// 
			formattingRule1.Filters.Add(new Telerik.Reporting.Filter("= RowNumber()%2", Telerik.Reporting.FilterOperator.Equal, "1"));
			formattingRule1.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Detail.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule1});
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DepartureDate,
            this.Source,
            this.Category,
            this.Consultant,
            this.TransactionType,
            this.DocumentType,
            this.DocumentNo,
            this.DocumentDate,
            this.Account,
            this.Airline,
            this.Passenger,
            this.Reference,
            this.Debtor,
            this.Creditor,
            this.Supplier,
            this.SaleType,
            this.DiscountReason,
            this.Group,
            this.Class,
            this.Agency,
            this.Destination,
            this.Region,
            this.Location,
            this.CashNonCommissionable,
            this.Agent,
            this.Cash,
            this.CreditCardNonCommissionable,
            this.CreditCard,
            this.NonCommissionable,
            this.AmountGross,
            this.AmountNet,
            this.Commission,
            this.Yield,
            this.OfferedFare,
            this.OfferedReason,
            this.PaxNo,
            this.ReturnDate});
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Detail.ItemDataBinding += new System.EventHandler(this.Detail_ItemDataBinding);
			// 
			// DocumentType
			// 
			this.DocumentType.CanGrow = false;
			this.DocumentType.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentType.Name = "DocumentType";
			this.DocumentType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentType.Style.Font.Name = "Calibri";
			this.DocumentType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentType.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentType.StyleName = "Normal.TableBody";
			this.DocumentType.Value = "= Fields.DocumentType";
			// 
			// DocumentNo
			// 
			this.DocumentNo.CanGrow = false;
			this.DocumentNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentNo.Name = "DocumentNo";
			this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNo.Style.Font.Name = "Calibri";
			this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentNo.StyleName = "Normal.TableBody";
			this.DocumentNo.Value = "= Fields.DocumentNo";
			// 
			// DocumentDate
			// 
			this.DocumentDate.CanGrow = false;
			this.DocumentDate.Format = "{0:dd-MMM-yyyy}";
			this.DocumentDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentDate.Name = "DocumentDate";
			this.DocumentDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDate.Style.Font.Name = "Calibri";
			this.DocumentDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentDate.StyleName = "Normal.TableBody";
			this.DocumentDate.Value = "= Fields.DocumentDate";
			// 
			// Account
			// 
			this.Account.CanGrow = false;
			this.Account.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Account.Name = "Account";
			this.Account.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Account.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Account.Style.Font.Name = "Calibri";
			this.Account.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Account.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Account.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Account.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Account.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Account.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Account.StyleName = "Normal.TableBody";
			this.Account.Value = "= Fields.Account";
			// 
			// Airline
			// 
			this.Airline.CanGrow = false;
			this.Airline.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Airline.Name = "Airline";
			this.Airline.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Airline.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Airline.Style.Font.Name = "Calibri";
			this.Airline.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Airline.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Airline.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Airline.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Airline.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Airline.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Airline.StyleName = "Normal.TableBody";
			this.Airline.Value = "= Fields.Airline";
			// 
			// Passenger
			// 
			this.Passenger.CanGrow = false;
			this.Passenger.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Passenger.Name = "Passenger";
			this.Passenger.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Passenger.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Passenger.Style.Font.Name = "Calibri";
			this.Passenger.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Passenger.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Passenger.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Passenger.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Passenger.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Passenger.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Passenger.StyleName = "Normal.TableBody";
			this.Passenger.Value = "= Fields.Passenger";
			// 
			// Reference
			// 
			this.Reference.CanGrow = false;
			this.Reference.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(39.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Reference.Name = "Reference";
			this.Reference.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Reference.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Reference.Style.Font.Name = "Calibri";
			this.Reference.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Reference.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Reference.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Reference.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Reference.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Reference.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Reference.StyleName = "Normal.TableBody";
			this.Reference.Value = "= Fields.Reference";
			// 
			// Debtor
			// 
			this.Debtor.CanGrow = false;
			this.Debtor.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(43.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Debtor.Name = "Debtor";
			this.Debtor.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Debtor.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Debtor.Style.Font.Name = "Calibri";
			this.Debtor.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Debtor.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Debtor.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Debtor.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Debtor.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Debtor.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Debtor.StyleName = "Normal.TableBody";
			this.Debtor.Value = "= Fields.Debtor";
			// 
			// Creditor
			// 
			this.Creditor.CanGrow = false;
			this.Creditor.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(49.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Creditor.Name = "Creditor";
			this.Creditor.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Creditor.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Creditor.Style.Font.Name = "Calibri";
			this.Creditor.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Creditor.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Creditor.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Creditor.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Creditor.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Creditor.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Creditor.StyleName = "Normal.TableBody";
			this.Creditor.Value = "= Fields.Creditor";
			// 
			// Supplier
			// 
			this.Supplier.CanGrow = false;
			this.Supplier.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(55.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Supplier.Name = "Supplier";
			this.Supplier.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Supplier.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Supplier.Style.Font.Name = "Calibri";
			this.Supplier.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Supplier.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Supplier.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Supplier.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Supplier.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Supplier.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Supplier.StyleName = "Normal.TableBody";
			this.Supplier.Value = "= Fields.Supplier";
			// 
			// SaleType
			// 
			this.SaleType.CanGrow = false;
			this.SaleType.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(61.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.SaleType.Name = "SaleType";
			this.SaleType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.SaleType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.SaleType.Style.Font.Name = "Calibri";
			this.SaleType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.SaleType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.SaleType.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.SaleType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.SaleType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.SaleType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.SaleType.StyleName = "Normal.TableBody";
			this.SaleType.Value = "= Fields.SaleType";
			// 
			// DiscountReason
			// 
			this.DiscountReason.CanGrow = false;
			this.DiscountReason.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(66.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DiscountReason.Name = "DiscountReason";
			this.DiscountReason.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DiscountReason.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DiscountReason.Style.Font.Name = "Calibri";
			this.DiscountReason.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DiscountReason.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DiscountReason.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DiscountReason.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DiscountReason.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DiscountReason.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DiscountReason.StyleName = "Normal.TableBody";
			this.DiscountReason.Value = "= Fields.DiscountReason";
			// 
			// Group
			// 
			this.Group.CanGrow = false;
			this.Group.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(71.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Group.Name = "Group";
			this.Group.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Group.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Group.Style.Font.Name = "Calibri";
			this.Group.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Group.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Group.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Group.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Group.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Group.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Group.StyleName = "Normal.TableBody";
			this.Group.Value = "= Fields.Group";
			// 
			// Class
			// 
			this.Class.CanGrow = false;
			this.Class.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(75.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Class.Name = "Class";
			this.Class.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Class.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Class.Style.Font.Name = "Calibri";
			this.Class.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Class.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Class.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Class.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Class.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Class.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Class.StyleName = "Normal.TableBody";
			this.Class.Value = "= Fields.Class";
			// 
			// Agency
			// 
			this.Agency.CanGrow = false;
			this.Agency.Format = "{0:C2}";
			this.Agency.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(99.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Agency.Name = "Agency";
			this.Agency.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Agency.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Agency.Style.Font.Name = "Calibri";
			this.Agency.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Agency.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Agency.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Agency.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Agency.StyleName = "Normal.TableBody";
			this.Agency.Value = "= Fields.Agency";
			// 
			// Destination
			// 
			this.Destination.CanGrow = false;
			this.Destination.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(87.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Destination.Name = "Destination";
			this.Destination.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Destination.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Destination.Style.Font.Name = "Calibri";
			this.Destination.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Destination.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Destination.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Destination.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Destination.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Destination.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Destination.StyleName = "Normal.TableBody";
			this.Destination.Value = "= Fields.Destination";
			// 
			// Region
			// 
			this.Region.CanGrow = false;
			this.Region.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(91.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Region.Name = "Region";
			this.Region.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Region.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Region.Style.Font.Name = "Calibri";
			this.Region.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Region.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Region.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Region.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Region.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Region.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Region.StyleName = "Normal.TableBody";
			this.Region.Value = "= Fields.Region";
			// 
			// Location
			// 
			this.Location.CanGrow = false;
			this.Location.Format = "{0:C2}";
			this.Location.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(95.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Location.Name = "Location";
			this.Location.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Location.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Location.Style.Font.Name = "Calibri";
			this.Location.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Location.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Location.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Location.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Location.StyleName = "Normal.TableBody";
			this.Location.Value = "= Fields.Location";
			// 
			// Agent
			// 
			this.Agent.CanGrow = false;
			this.Agent.Format = "{0:C2}";
			this.Agent.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(107.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Agent.Name = "Agent";
			this.Agent.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Agent.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Agent.Style.Font.Name = "Calibri";
			this.Agent.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Agent.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Agent.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Agent.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Agent.StyleName = "Normal.TableBody";
			this.Agent.Value = "= Fields.Agent";
			// 
			// CreditCardNonCommissionable
			// 
			this.CreditCardNonCommissionable.CanGrow = false;
			this.CreditCardNonCommissionable.Format = "{0:C2}";
			this.CreditCardNonCommissionable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(121.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CreditCardNonCommissionable.Name = "CreditCardNonCommissionable";
			this.CreditCardNonCommissionable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditCardNonCommissionable.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditCardNonCommissionable.Style.Font.Name = "Calibri";
			this.CreditCardNonCommissionable.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditCardNonCommissionable.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditCardNonCommissionable.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditCardNonCommissionable.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditCardNonCommissionable.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditCardNonCommissionable.StyleName = "Normal.TableBody";
			this.CreditCardNonCommissionable.Value = "= Fields.CreditCardNonCommissionable";
			// 
			// CreditCard
			// 
			this.CreditCard.CanGrow = false;
			this.CreditCard.Format = "{0:C2}";
			this.CreditCard.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(118.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CreditCard.Name = "CreditCard";
			this.CreditCard.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditCard.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditCard.Style.Font.Name = "Calibri";
			this.CreditCard.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditCard.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditCard.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditCard.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditCard.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditCard.StyleName = "Normal.TableBody";
			this.CreditCard.Value = "= Fields.CreditCard";
			// 
			// NonCommissionable
			// 
			this.NonCommissionable.CanGrow = false;
			this.NonCommissionable.Format = "{0:C2}";
			this.NonCommissionable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(126.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.NonCommissionable.Name = "NonCommissionable";
			this.NonCommissionable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NonCommissionable.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NonCommissionable.Style.Font.Name = "Calibri";
			this.NonCommissionable.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NonCommissionable.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.NonCommissionable.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NonCommissionable.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.NonCommissionable.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.NonCommissionable.StyleName = "Normal.TableBody";
			this.NonCommissionable.Value = "= Fields.NonCommissionable";
			// 
			// AmountGross
			// 
			this.AmountGross.CanGrow = false;
			this.AmountGross.Format = "{0:C2}";
			this.AmountGross.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(124.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountGross.Name = "AmountGross";
			this.AmountGross.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGross.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGross.Style.Font.Name = "Calibri";
			this.AmountGross.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGross.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGross.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountGross.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGross.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountGross.StyleName = "Normal.TableBody";
			this.AmountGross.Value = "= Fields.AmountGross";
			// 
			// AmountNet
			// 
			this.AmountNet.CanGrow = false;
			this.AmountNet.Format = "{0:C2}";
			this.AmountNet.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(132.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountNet.Name = "AmountNet";
			this.AmountNet.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountNet.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountNet.Style.Font.Name = "Calibri";
			this.AmountNet.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountNet.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountNet.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountNet.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountNet.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountNet.StyleName = "Normal.TableBody";
			this.AmountNet.Value = "= Fields.AmountNet";
			// 
			// Commission
			// 
			this.Commission.CanGrow = false;
			this.Commission.Format = "{0:C2}";
			this.Commission.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(129.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Commission.Name = "Commission";
			this.Commission.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Commission.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Commission.Style.Font.Name = "Calibri";
			this.Commission.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Commission.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Commission.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Commission.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Commission.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Commission.StyleName = "Normal.TableBody";
			this.Commission.Value = "= Fields.Commission";
			// 
			// Yield
			// 
			this.Yield.CanGrow = false;
			this.Yield.Format = "{0:P3}";
			this.Yield.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(134.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Yield.Name = "Yield";
			this.Yield.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Yield.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Yield.Style.Font.Name = "Calibri";
			this.Yield.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Yield.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Yield.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Yield.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Yield.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Yield.StyleName = "Normal.TableBody";
			this.Yield.Value = "= Round(Fields.Yield, 5)";
			// 
			// OfferedFare
			// 
			this.OfferedFare.CanGrow = false;
			this.OfferedFare.Format = "{0:C2}";
			this.OfferedFare.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.OfferedFare.Name = "OfferedFare";
			this.OfferedFare.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OfferedFare.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.OfferedFare.Style.Font.Name = "Calibri";
			this.OfferedFare.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.OfferedFare.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OfferedFare.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.OfferedFare.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OfferedFare.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.OfferedFare.StyleName = "Normal.TableBody";
			this.OfferedFare.Value = "= Fields.OfferedFare";
			// 
			// OfferedReason
			// 
			this.OfferedReason.CanGrow = false;
			this.OfferedReason.Format = "{0:C2}";
			this.OfferedReason.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(30.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.OfferedReason.Name = "OfferedReason";
			this.OfferedReason.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OfferedReason.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.OfferedReason.Style.Font.Name = "Calibri";
			this.OfferedReason.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.OfferedReason.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OfferedReason.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.OfferedReason.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OfferedReason.StyleName = "Normal.TableBody";
			this.OfferedReason.Value = "= Fields.OfferedReason";
			// 
			// PaxNo
			// 
			this.PaxNo.CanGrow = false;
			this.PaxNo.Format = "";
			this.PaxNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(111.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.PaxNo.Name = "PaxNo";
			this.PaxNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.PaxNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.PaxNo.Style.Font.Name = "Calibri";
			this.PaxNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PaxNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.PaxNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.PaxNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.PaxNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.PaxNo.StyleName = "Normal.TableBody";
			this.PaxNo.Value = "= Fields.PaxNo";
			// 
			// ReportFooterSection1
			// 
			this.ReportFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1.2D);
			this.ReportFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.CashTotal,
            this.CashNonCommissionableTotal,
            this.LabelTotal,
            this.CreditCardNonCommissionableTotal,
            this.CreditCardTotal,
            this.AmountGrossTotal,
            this.NonCommissionableTotal,
            this.AmountNetTotal,
            this.CommissionTotal,
            this.YieldTotal,
            this.CashYtd,
            this.CashNonCommissionableYtd,
            this.LabelYtd,
            this.CreditCardNonCommissionableYtd,
            this.CreditCardYtd,
            this.AmountGrossYtd,
            this.NonCommissionableYtd,
            this.AmountNetYtd,
            this.CommissionYtd,
            this.YieldYtd});
			this.ReportFooterSection1.Name = "ReportFooterSection1";
			this.ReportFooterSection1.ItemDataBinding += new System.EventHandler(this.ReportFooterSection1_ItemDataBinding);
			// 
			// LabelTotal
			// 
			this.LabelTotal.CanGrow = false;
			this.LabelTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(111.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.LabelTotal.Name = "LabelTotal";
			this.LabelTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LabelTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.LabelTotal.Style.Font.Bold = true;
			this.LabelTotal.Style.Font.Name = "Calibri";
			this.LabelTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.LabelTotal.Style.LineWidth = Telerik.Reporting.Drawing.Unit.Point(0.6D);
			this.LabelTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.LabelTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LabelTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.LabelTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.LabelTotal.StyleName = "Normal.TableBody";
			this.LabelTotal.Value = "Totals";
			// 
			// LabelYtd
			// 
			this.LabelYtd.CanGrow = false;
			this.LabelYtd.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(111.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LabelYtd.Name = "LabelYtd";
			this.LabelYtd.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LabelYtd.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.LabelYtd.Style.Font.Bold = true;
			this.LabelYtd.Style.Font.Name = "Calibri";
			this.LabelYtd.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.LabelYtd.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.LabelYtd.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LabelYtd.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.LabelYtd.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.LabelYtd.StyleName = "Normal.TableBody";
			this.LabelYtd.Value = "YTD";
			// 
			// ReportHeaderSection1
			// 
			this.ReportHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.ReportHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DepartureDateHeader,
            this.DocumentTypeHeader,
            this.DocumentNoHeader,
            this.DocumentDateHeader,
            this.AccountHeader,
            this.AirlineHeader,
            this.PassengerHeader,
            this.ReferenceHeader,
            this.DebtorHeader,
            this.CreditorHeader,
            this.TransactionTypeHeader,
            this.SupplierHeader,
            this.SourceHeader,
            this.GroupHeader,
            this.DiscountReasonHeader,
            this.SaleTypeHeader,
            this.CategoryHeader,
            this.ClassHeader,
            this.DestinationHeader,
            this.LocationHeader,
            this.AgencyHeader,
            this.ConsultantHeader,
            this.RegionHeader,
            this.CashHeader,
            this.CashNonCommissionableHeader,
            this.AgentHeader,
            this.CreditCardHeader,
            this.CreditCardNonCommissionableHeader,
            this.AmountGrossHeader,
            this.NonCommissionableHeader,
            this.CommissionHeader,
            this.AmountNetHeader,
            this.YieldHeader,
            this.OfferedFareHeader,
            this.OfferedReasonHeader,
            this.PaxNoHeader,
            this.ReturnDateHeader});
			this.ReportHeaderSection1.Name = "ReportHeaderSection1";
			this.ReportHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReportHeaderSection1.ItemDataBinding += new System.EventHandler(this.ReportHeaderSection1_ItemDataBinding);
			// 
			// DepartureDateHeader
			// 
			this.DepartureDateHeader.CanGrow = false;
			this.DepartureDateHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(34.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DepartureDateHeader.Name = "DepartureDateHeader";
			this.DepartureDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DepartureDateHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DepartureDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DepartureDateHeader.Style.Font.Bold = true;
			this.DepartureDateHeader.Style.Font.Name = "Calibri";
			this.DepartureDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DepartureDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DepartureDateHeader.StyleName = "Normal.TableHeader";
			this.DepartureDateHeader.Value = "Departure Date";
			// 
			// DocumentTypeHeader
			// 
			this.DocumentTypeHeader.CanGrow = false;
			this.DocumentTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentTypeHeader.Name = "DocumentTypeHeader";
			this.DocumentTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentTypeHeader.Style.Font.Bold = true;
			this.DocumentTypeHeader.Style.Font.Name = "Calibri";
			this.DocumentTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentTypeHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentTypeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentTypeHeader.StyleName = "Normal.TableHeader";
			this.DocumentTypeHeader.Value = "Document Type";
			// 
			// DocumentNoHeader
			// 
			this.DocumentNoHeader.CanGrow = false;
			this.DocumentNoHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentNoHeader.Name = "DocumentNoHeader";
			this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNoHeader.Style.Font.Bold = true;
			this.DocumentNoHeader.Style.Font.Name = "Calibri";
			this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNoHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentNoHeader.StyleName = "Normal.TableHeader";
			this.DocumentNoHeader.Value = "Document No";
			// 
			// DocumentDateHeader
			// 
			this.DocumentDateHeader.CanGrow = false;
			this.DocumentDateHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentDateHeader.Name = "DocumentDateHeader";
			this.DocumentDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDateHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDateHeader.Style.Font.Bold = true;
			this.DocumentDateHeader.Style.Font.Name = "Calibri";
			this.DocumentDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDateHeader.StyleName = "Normal.TableHeader";
			this.DocumentDateHeader.Value = "Document Date";
			// 
			// AccountHeader
			// 
			this.AccountHeader.CanGrow = false;
			this.AccountHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AccountHeader.Name = "AccountHeader";
			this.AccountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccountHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AccountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccountHeader.Style.Font.Bold = true;
			this.AccountHeader.Style.Font.Name = "Calibri";
			this.AccountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AccountHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AccountHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AccountHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AccountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AccountHeader.StyleName = "Normal.TableHeader";
			this.AccountHeader.Value = "Account";
			// 
			// AirlineHeader
			// 
			this.AirlineHeader.CanGrow = false;
			this.AirlineHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AirlineHeader.Name = "AirlineHeader";
			this.AirlineHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AirlineHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AirlineHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AirlineHeader.Style.Font.Bold = true;
			this.AirlineHeader.Style.Font.Name = "Calibri";
			this.AirlineHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AirlineHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AirlineHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AirlineHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AirlineHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AirlineHeader.StyleName = "Normal.TableHeader";
			this.AirlineHeader.Value = "Airline";
			// 
			// PassengerHeader
			// 
			this.PassengerHeader.CanGrow = false;
			this.PassengerHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.PassengerHeader.Name = "PassengerHeader";
			this.PassengerHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.PassengerHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.PassengerHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.PassengerHeader.Style.Font.Bold = true;
			this.PassengerHeader.Style.Font.Name = "Calibri";
			this.PassengerHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PassengerHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PassengerHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.PassengerHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PassengerHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.PassengerHeader.StyleName = "Normal.TableHeader";
			this.PassengerHeader.Value = "Passenger";
			// 
			// ReferenceHeader
			// 
			this.ReferenceHeader.CanGrow = false;
			this.ReferenceHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(39.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ReferenceHeader.Name = "ReferenceHeader";
			this.ReferenceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReferenceHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ReferenceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReferenceHeader.Style.Font.Bold = true;
			this.ReferenceHeader.Style.Font.Name = "Calibri";
			this.ReferenceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReferenceHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReferenceHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ReferenceHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReferenceHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReferenceHeader.StyleName = "Normal.TableHeader";
			this.ReferenceHeader.Value = "Reference";
			// 
			// DebtorHeader
			// 
			this.DebtorHeader.CanGrow = false;
			this.DebtorHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(43.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DebtorHeader.Name = "DebtorHeader";
			this.DebtorHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DebtorHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DebtorHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DebtorHeader.Style.Font.Bold = true;
			this.DebtorHeader.Style.Font.Name = "Calibri";
			this.DebtorHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DebtorHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DebtorHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DebtorHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DebtorHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DebtorHeader.StyleName = "Normal.TableHeader";
			this.DebtorHeader.Value = "Debtor";
			// 
			// CreditorHeader
			// 
			this.CreditorHeader.CanGrow = false;
			this.CreditorHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(49.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CreditorHeader.Name = "CreditorHeader";
			this.CreditorHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditorHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CreditorHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditorHeader.Style.Font.Bold = true;
			this.CreditorHeader.Style.Font.Name = "Calibri";
			this.CreditorHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditorHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditorHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditorHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditorHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreditorHeader.StyleName = "Normal.TableHeader";
			this.CreditorHeader.Value = "Creditor";
			// 
			// TransactionTypeHeader
			// 
			this.TransactionTypeHeader.CanGrow = false;
			this.TransactionTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TransactionTypeHeader.Name = "TransactionTypeHeader";
			this.TransactionTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TransactionTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TransactionTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TransactionTypeHeader.Style.Font.Bold = true;
			this.TransactionTypeHeader.Style.Font.Name = "Calibri";
			this.TransactionTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TransactionTypeHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TransactionTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TransactionTypeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TransactionTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TransactionTypeHeader.StyleName = "Normal.TableHeader";
			this.TransactionTypeHeader.Value = "Transaction Type";
			// 
			// SupplierHeader
			// 
			this.SupplierHeader.CanGrow = false;
			this.SupplierHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(55.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.SupplierHeader.Name = "SupplierHeader";
			this.SupplierHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.SupplierHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.SupplierHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.SupplierHeader.Style.Font.Bold = true;
			this.SupplierHeader.Style.Font.Name = "Calibri";
			this.SupplierHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.SupplierHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.SupplierHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.SupplierHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.SupplierHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.SupplierHeader.StyleName = "Normal.TableHeader";
			this.SupplierHeader.Value = "Supplier";
			// 
			// SourceHeader
			// 
			this.SourceHeader.CanGrow = false;
			this.SourceHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(79.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.SourceHeader.Name = "SourceHeader";
			this.SourceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.SourceHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.SourceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.SourceHeader.Style.Font.Bold = true;
			this.SourceHeader.Style.Font.Name = "Calibri";
			this.SourceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.SourceHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.SourceHeader.StyleName = "Normal.TableHeader";
			this.SourceHeader.Value = "Source";
			// 
			// GroupHeader
			// 
			this.GroupHeader.CanGrow = false;
			this.GroupHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(71.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.GroupHeader.Name = "GroupHeader";
			this.GroupHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.GroupHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.GroupHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeader.Style.Font.Bold = true;
			this.GroupHeader.Style.Font.Name = "Calibri";
			this.GroupHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.GroupHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.GroupHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.GroupHeader.StyleName = "Normal.TableHeader";
			this.GroupHeader.Value = "Group";
			// 
			// DiscountReasonHeader
			// 
			this.DiscountReasonHeader.CanGrow = false;
			this.DiscountReasonHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(66.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DiscountReasonHeader.Name = "DiscountReasonHeader";
			this.DiscountReasonHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DiscountReasonHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DiscountReasonHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DiscountReasonHeader.Style.Font.Bold = true;
			this.DiscountReasonHeader.Style.Font.Name = "Calibri";
			this.DiscountReasonHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DiscountReasonHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DiscountReasonHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DiscountReasonHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DiscountReasonHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DiscountReasonHeader.StyleName = "Normal.TableHeader";
			this.DiscountReasonHeader.Value = "Discount Reason";
			// 
			// SaleTypeHeader
			// 
			this.SaleTypeHeader.CanGrow = false;
			this.SaleTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(61.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.SaleTypeHeader.Name = "SaleTypeHeader";
			this.SaleTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.SaleTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.SaleTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.SaleTypeHeader.Style.Font.Bold = true;
			this.SaleTypeHeader.Style.Font.Name = "Calibri";
			this.SaleTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.SaleTypeHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.SaleTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.SaleTypeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.SaleTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.SaleTypeHeader.StyleName = "Normal.TableHeader";
			this.SaleTypeHeader.Value = "Type Of Sale";
			// 
			// CategoryHeader
			// 
			this.CategoryHeader.CanGrow = false;
			this.CategoryHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(83.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CategoryHeader.Name = "CategoryHeader";
			this.CategoryHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CategoryHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CategoryHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CategoryHeader.Style.Font.Bold = true;
			this.CategoryHeader.Style.Font.Name = "Calibri";
			this.CategoryHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CategoryHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CategoryHeader.StyleName = "Normal.TableHeader";
			this.CategoryHeader.Value = "Category";
			// 
			// ClassHeader
			// 
			this.ClassHeader.CanGrow = false;
			this.ClassHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(75.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ClassHeader.Name = "ClassHeader";
			this.ClassHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ClassHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ClassHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ClassHeader.Style.Font.Bold = true;
			this.ClassHeader.Style.Font.Name = "Calibri";
			this.ClassHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ClassHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ClassHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ClassHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ClassHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ClassHeader.StyleName = "Normal.TableHeader";
			this.ClassHeader.Value = "Class";
			// 
			// DestinationHeader
			// 
			this.DestinationHeader.CanGrow = false;
			this.DestinationHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(87.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DestinationHeader.Name = "DestinationHeader";
			this.DestinationHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DestinationHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DestinationHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DestinationHeader.Style.Font.Bold = true;
			this.DestinationHeader.Style.Font.Name = "Calibri";
			this.DestinationHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DestinationHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DestinationHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DestinationHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DestinationHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DestinationHeader.StyleName = "Normal.TableHeader";
			this.DestinationHeader.Value = "Destination";
			// 
			// LocationHeader
			// 
			this.LocationHeader.CanGrow = false;
			this.LocationHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(95.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.LocationHeader.Name = "LocationHeader";
			this.LocationHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LocationHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.LocationHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.LocationHeader.Style.Font.Bold = true;
			this.LocationHeader.Style.Font.Name = "Calibri";
			this.LocationHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.LocationHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.LocationHeader.StyleName = "Normal.TableHeader";
			this.LocationHeader.Value = "Location";
			// 
			// AgencyHeader
			// 
			this.AgencyHeader.CanGrow = false;
			this.AgencyHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(99.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AgencyHeader.Name = "AgencyHeader";
			this.AgencyHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AgencyHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AgencyHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AgencyHeader.Style.Font.Bold = true;
			this.AgencyHeader.Style.Font.Name = "Calibri";
			this.AgencyHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AgencyHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AgencyHeader.StyleName = "Normal.TableHeader";
			this.AgencyHeader.Value = "Agency";
			// 
			// ConsultantHeader
			// 
			this.ConsultantHeader.CanGrow = false;
			this.ConsultantHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(103.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ConsultantHeader.Name = "ConsultantHeader";
			this.ConsultantHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ConsultantHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ConsultantHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ConsultantHeader.Style.Font.Bold = true;
			this.ConsultantHeader.Style.Font.Name = "Calibri";
			this.ConsultantHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ConsultantHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ConsultantHeader.StyleName = "Normal.TableHeader";
			this.ConsultantHeader.Value = "Consultant";
			// 
			// RegionHeader
			// 
			this.RegionHeader.CanGrow = false;
			this.RegionHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(91.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.RegionHeader.Name = "RegionHeader";
			this.RegionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.RegionHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.RegionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.RegionHeader.Style.Font.Bold = true;
			this.RegionHeader.Style.Font.Name = "Calibri";
			this.RegionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.RegionHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.RegionHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.RegionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.RegionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.RegionHeader.StyleName = "Normal.TableHeader";
			this.RegionHeader.Value = "Region";
			// 
			// CashHeader
			// 
			this.CashHeader.CanGrow = false;
			this.CashHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(113.3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CashHeader.Name = "CashHeader";
			this.CashHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CashHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CashHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CashHeader.Style.Font.Bold = true;
			this.CashHeader.Style.Font.Name = "Calibri";
			this.CashHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CashHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CashHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CashHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CashHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CashHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CashHeader.StyleName = "Normal.TableHeader";
			this.CashHeader.Value = "Cash";
			// 
			// CashNonCommissionableHeader
			// 
			this.CashNonCommissionableHeader.CanGrow = false;
			this.CashNonCommissionableHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(116D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CashNonCommissionableHeader.Name = "CashNonCommissionableHeader";
			this.CashNonCommissionableHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CashNonCommissionableHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CashNonCommissionableHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CashNonCommissionableHeader.Style.Font.Bold = true;
			this.CashNonCommissionableHeader.Style.Font.Name = "Calibri";
			this.CashNonCommissionableHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CashNonCommissionableHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CashNonCommissionableHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CashNonCommissionableHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CashNonCommissionableHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CashNonCommissionableHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CashNonCommissionableHeader.StyleName = "Normal.TableHeader";
			this.CashNonCommissionableHeader.Value = "Cash NC";
			// 
			// AgentHeader
			// 
			this.AgentHeader.CanGrow = false;
			this.AgentHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(107.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AgentHeader.Name = "AgentHeader";
			this.AgentHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AgentHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AgentHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AgentHeader.Style.Font.Bold = true;
			this.AgentHeader.Style.Font.Name = "Calibri";
			this.AgentHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AgentHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AgentHeader.StyleName = "Normal.TableHeader";
			this.AgentHeader.Value = "Agent";
			// 
			// CreditCardHeader
			// 
			this.CreditCardHeader.CanGrow = false;
			this.CreditCardHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(118.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CreditCardHeader.Name = "CreditCardHeader";
			this.CreditCardHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditCardHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CreditCardHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditCardHeader.Style.Font.Bold = true;
			this.CreditCardHeader.Style.Font.Name = "Calibri";
			this.CreditCardHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditCardHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditCardHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditCardHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditCardHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditCardHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreditCardHeader.StyleName = "Normal.TableHeader";
			this.CreditCardHeader.Value = "Credit Card";
			// 
			// CreditCardNonCommissionableHeader
			// 
			this.CreditCardNonCommissionableHeader.CanGrow = false;
			this.CreditCardNonCommissionableHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(121.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CreditCardNonCommissionableHeader.Name = "CreditCardNonCommissionableHeader";
			this.CreditCardNonCommissionableHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditCardNonCommissionableHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CreditCardNonCommissionableHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditCardNonCommissionableHeader.Style.Font.Bold = true;
			this.CreditCardNonCommissionableHeader.Style.Font.Name = "Calibri";
			this.CreditCardNonCommissionableHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditCardNonCommissionableHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditCardNonCommissionableHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditCardNonCommissionableHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditCardNonCommissionableHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditCardNonCommissionableHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreditCardNonCommissionableHeader.StyleName = "Normal.TableHeader";
			this.CreditCardNonCommissionableHeader.Value = "Credit Card NC";
			// 
			// AmountGrossHeader
			// 
			this.AmountGrossHeader.CanGrow = false;
			this.AmountGrossHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(124.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountGrossHeader.Name = "AmountGrossHeader";
			this.AmountGrossHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AmountGrossHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGrossHeader.Style.Font.Bold = true;
			this.AmountGrossHeader.Style.Font.Name = "Calibri";
			this.AmountGrossHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGrossHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountGrossHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountGrossHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AmountGrossHeader.StyleName = "Normal.TableHeader";
			this.AmountGrossHeader.Value = "Gross";
			// 
			// NonCommissionableHeader
			// 
			this.NonCommissionableHeader.CanGrow = false;
			this.NonCommissionableHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(126.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.NonCommissionableHeader.Name = "NonCommissionableHeader";
			this.NonCommissionableHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NonCommissionableHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.NonCommissionableHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NonCommissionableHeader.Style.Font.Bold = true;
			this.NonCommissionableHeader.Style.Font.Name = "Calibri";
			this.NonCommissionableHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NonCommissionableHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NonCommissionableHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NonCommissionableHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NonCommissionableHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.NonCommissionableHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.NonCommissionableHeader.StyleName = "Normal.TableHeader";
			this.NonCommissionableHeader.Value = "Non-Comm";
			// 
			// CommissionHeader
			// 
			this.CommissionHeader.CanGrow = false;
			this.CommissionHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(129.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CommissionHeader.Name = "CommissionHeader";
			this.CommissionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CommissionHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CommissionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CommissionHeader.Style.Font.Bold = true;
			this.CommissionHeader.Style.Font.Name = "Calibri";
			this.CommissionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CommissionHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CommissionHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CommissionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CommissionHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CommissionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CommissionHeader.StyleName = "Normal.TableHeader";
			this.CommissionHeader.Value = "Commission";
			// 
			// AmountNetHeader
			// 
			this.AmountNetHeader.CanGrow = false;
			this.AmountNetHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(132.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountNetHeader.Name = "AmountNetHeader";
			this.AmountNetHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountNetHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AmountNetHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountNetHeader.Style.Font.Bold = true;
			this.AmountNetHeader.Style.Font.Name = "Calibri";
			this.AmountNetHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountNetHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountNetHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountNetHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountNetHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountNetHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AmountNetHeader.StyleName = "Normal.TableHeader";
			this.AmountNetHeader.Value = "Net";
			// 
			// YieldHeader
			// 
			this.YieldHeader.CanGrow = false;
			this.YieldHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(134.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.YieldHeader.Name = "YieldHeader";
			this.YieldHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.YieldHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.YieldHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.YieldHeader.Style.Font.Bold = true;
			this.YieldHeader.Style.Font.Name = "Calibri";
			this.YieldHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.YieldHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.YieldHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.YieldHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.YieldHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.YieldHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.YieldHeader.StyleName = "Normal.TableHeader";
			this.YieldHeader.Value = "Yield";
			// 
			// OfferedFareHeader
			// 
			this.OfferedFareHeader.CanGrow = false;
			this.OfferedFareHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.OfferedFareHeader.Name = "OfferedFareHeader";
			this.OfferedFareHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OfferedFareHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.OfferedFareHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.OfferedFareHeader.Style.Font.Bold = true;
			this.OfferedFareHeader.Style.Font.Name = "Calibri";
			this.OfferedFareHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.OfferedFareHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.OfferedFareHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OfferedFareHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OfferedFareHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.OfferedFareHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.OfferedFareHeader.StyleName = "Normal.TableHeader";
			this.OfferedFareHeader.Value = "Offered Fare";
			// 
			// OfferedReasonHeader
			// 
			this.OfferedReasonHeader.CanGrow = false;
			this.OfferedReasonHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(30.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.OfferedReasonHeader.Name = "OfferedReasonHeader";
			this.OfferedReasonHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OfferedReasonHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.OfferedReasonHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.OfferedReasonHeader.Style.Font.Bold = true;
			this.OfferedReasonHeader.Style.Font.Name = "Calibri";
			this.OfferedReasonHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.OfferedReasonHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.OfferedReasonHeader.StyleName = "Normal.TableHeader";
			this.OfferedReasonHeader.Value = "Reason Rejected";
			// 
			// PaxNoHeader
			// 
			this.PaxNoHeader.CanGrow = false;
			this.PaxNoHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(111.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.PaxNoHeader.Name = "PaxNoHeader";
			this.PaxNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.PaxNoHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.PaxNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.PaxNoHeader.Style.Font.Bold = true;
			this.PaxNoHeader.Style.Font.Name = "Calibri";
			this.PaxNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PaxNoHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.PaxNoHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PaxNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PaxNoHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.PaxNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.PaxNoHeader.StyleName = "Normal.TableHeader";
			this.PaxNoHeader.Value = "Pax";
			// 
			// ReturnDateHeader
			// 
			this.ReturnDateHeader.CanGrow = false;
			this.ReturnDateHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(37.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ReturnDateHeader.Name = "ReturnDateHeader";
			this.ReturnDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReturnDateHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ReturnDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReturnDateHeader.Style.Font.Bold = true;
			this.ReturnDateHeader.Style.Font.Name = "Calibri";
			this.ReturnDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReturnDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReturnDateHeader.StyleName = "Normal.TableHeader";
			this.ReturnDateHeader.Value = "Return Date";
			// 
			// ReturnDate
			// 
			this.ReturnDate.CanGrow = false;
			this.ReturnDate.Format = "{0:dd-MMM-yyyy}";
			this.ReturnDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(37.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ReturnDate.Name = "ReturnDate";
			this.ReturnDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReturnDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReturnDate.Style.Font.Name = "Calibri";
			this.ReturnDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReturnDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ReturnDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ReturnDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ReturnDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ReturnDate.StyleName = "Normal.TableBody";
			this.ReturnDate.Value = "= Fields.ReturnDate";
			// 
			// SalesAnalysisReport
			// 
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Detail,
            this.ReportHeaderSection1,
            this.ReportFooterSection1});
			this.Name = "SalesAnalysisReport";
			this.PageSettings.ContinuousPaper = true;
			this.PageSettings.Landscape = true;
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.Custom;
			this.PageSettings.PaperSize = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(128.2D), Telerik.Reporting.Drawing.Unit.Cm(21D));
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(137.6D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.TextBox TransactionType;
		private Telerik.Reporting.TextBox DepartureDate;
		private Telerik.Reporting.TextBox Source;
		private Telerik.Reporting.TextBox CashNonCommissionable;
		private Telerik.Reporting.TextBox Category;
		private Telerik.Reporting.TextBox Consultant;
		private Telerik.Reporting.TextBox CashNonCommissionableTotal;
		private Telerik.Reporting.TextBox Cash;
		private Telerik.Reporting.TextBox CashTotal;
		private Telerik.Reporting.TextBox DocumentType;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox DocumentDate;
		private Telerik.Reporting.TextBox Account;
		private Telerik.Reporting.TextBox Airline;
		private Telerik.Reporting.TextBox Passenger;
		private Telerik.Reporting.TextBox Reference;
		private Telerik.Reporting.TextBox Debtor;
		private Telerik.Reporting.TextBox Creditor;
		private Telerik.Reporting.TextBox Supplier;
		private Telerik.Reporting.TextBox SaleType;
		private Telerik.Reporting.TextBox DiscountReason;
		private Telerik.Reporting.TextBox Group;
		private Telerik.Reporting.TextBox Class;
		private Telerik.Reporting.TextBox Agency;
		private Telerik.Reporting.TextBox Destination;
		private Telerik.Reporting.TextBox Region;
		private Telerik.Reporting.TextBox Location;
		private Telerik.Reporting.TextBox Agent;
		private Telerik.Reporting.TextBox CreditCardNonCommissionable;
		private Telerik.Reporting.TextBox CreditCard;
		private Telerik.Reporting.TextBox NonCommissionable;
		private Telerik.Reporting.TextBox AmountGross;
		private Telerik.Reporting.TextBox AmountNet;
		private Telerik.Reporting.TextBox Commission;
		private Telerik.Reporting.TextBox Yield;
		private Telerik.Reporting.TextBox CreditCardNonCommissionableTotal;
		private Telerik.Reporting.TextBox CreditCardTotal;
		private Telerik.Reporting.TextBox AmountGrossTotal;
		private Telerik.Reporting.TextBox NonCommissionableTotal;
		private Telerik.Reporting.TextBox AmountNetTotal;
		private Telerik.Reporting.TextBox CommissionTotal;
		private Telerik.Reporting.TextBox YieldTotal;
		private Telerik.Reporting.TextBox CashYtd;
		private Telerik.Reporting.TextBox CashNonCommissionableYtd;
		private Telerik.Reporting.TextBox CreditCardNonCommissionableYtd;
		private Telerik.Reporting.TextBox CreditCardYtd;
		private Telerik.Reporting.TextBox AmountGrossYtd;
		private Telerik.Reporting.TextBox NonCommissionableYtd;
		private Telerik.Reporting.TextBox AmountNetYtd;
		private Telerik.Reporting.TextBox CommissionYtd;
		private Telerik.Reporting.TextBox YieldYtd;
		private Telerik.Reporting.ReportFooterSection ReportFooterSection1;
		private Telerik.Reporting.TextBox OfferedFare;
		private Telerik.Reporting.TextBox OfferedReason;
		private Telerik.Reporting.TextBox LabelTotal;
		private Telerik.Reporting.TextBox LabelYtd;
		private Telerik.Reporting.TextBox PaxNo;
		private Telerik.Reporting.TextBox ReturnDate;
		private Telerik.Reporting.ReportHeaderSection ReportHeaderSection1;
		private Telerik.Reporting.TextBox DepartureDateHeader;
		private Telerik.Reporting.TextBox DocumentTypeHeader;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox DocumentDateHeader;
		private Telerik.Reporting.TextBox AccountHeader;
		private Telerik.Reporting.TextBox AirlineHeader;
		private Telerik.Reporting.TextBox PassengerHeader;
		private Telerik.Reporting.TextBox ReferenceHeader;
		private Telerik.Reporting.TextBox DebtorHeader;
		private Telerik.Reporting.TextBox CreditorHeader;
		private Telerik.Reporting.TextBox TransactionTypeHeader;
		private Telerik.Reporting.TextBox SupplierHeader;
		private Telerik.Reporting.TextBox SourceHeader;
		private Telerik.Reporting.TextBox GroupHeader;
		private Telerik.Reporting.TextBox DiscountReasonHeader;
		private Telerik.Reporting.TextBox SaleTypeHeader;
		private Telerik.Reporting.TextBox CategoryHeader;
		private Telerik.Reporting.TextBox ClassHeader;
		private Telerik.Reporting.TextBox DestinationHeader;
		private Telerik.Reporting.TextBox LocationHeader;
		private Telerik.Reporting.TextBox AgencyHeader;
		private Telerik.Reporting.TextBox ConsultantHeader;
		private Telerik.Reporting.TextBox RegionHeader;
		private Telerik.Reporting.TextBox CashHeader;
		private Telerik.Reporting.TextBox CashNonCommissionableHeader;
		private Telerik.Reporting.TextBox AgentHeader;
		private Telerik.Reporting.TextBox CreditCardHeader;
		private Telerik.Reporting.TextBox CreditCardNonCommissionableHeader;
		private Telerik.Reporting.TextBox AmountGrossHeader;
		private Telerik.Reporting.TextBox NonCommissionableHeader;
		private Telerik.Reporting.TextBox CommissionHeader;
		private Telerik.Reporting.TextBox AmountNetHeader;
		private Telerik.Reporting.TextBox YieldHeader;
		private Telerik.Reporting.TextBox OfferedFareHeader;
		private Telerik.Reporting.TextBox OfferedReasonHeader;
		private Telerik.Reporting.TextBox PaxNoHeader;
		private Telerik.Reporting.TextBox ReturnDateHeader;
	}
}