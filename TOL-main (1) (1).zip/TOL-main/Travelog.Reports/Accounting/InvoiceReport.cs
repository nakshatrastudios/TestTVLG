using System;
using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Resources;

namespace Travelog.Reports.Accounting {
	public partial class InvoiceReport : TelerikReport {
		public InvoiceReport() {
			InitializeComponent();
		}

		private void TaxNo_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			if (textBox.Value?.ToString().Length > 0)
				textBox.Value = string.Format("{0}: {1}", Resource.TaxNoLabel, textBox.Value);
		}

		private void TotalTaxLabel_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			if (textBox.Report.Parameters["isTaxInInvoiceLineAmount"].Value.ToBool()) {
				textBox.Value = string.Format("{0} Included in Total", Resource.TaxLabel);
			}
			else {
				textBox.Value = Resource.TaxLabel;
			}
		}

		private void TaxTotal1_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("Total {0} Included", Resource.TaxLabel);
		}

		private void TaxAppliesLabel_ItemDataBinding(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format(@"=IIf(Fields.TotalTax = 0, """", ""*{0} Applies"")", Resource.TaxLabel);
		}
	}
}