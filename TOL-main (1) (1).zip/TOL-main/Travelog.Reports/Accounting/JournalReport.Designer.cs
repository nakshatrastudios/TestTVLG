namespace Travelog.Reports.Accounting {
	partial class JournalReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JournalReport));
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
            Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter11 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter12 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter13 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter14 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter15 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter16 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter17 = new Telerik.Reporting.ReportParameter();
            this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
            this.TotalsLabel = new Telerik.Reporting.TextBox();
            this.GrandTotalDebit = new Telerik.Reporting.TextBox();
            this.GrandTotalCredit = new Telerik.Reporting.TextBox();
            this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
            this.ManagementReportHeaderSubReport2 = new Telerik.Reporting.SubReport();
            this.AccountTypeHeader = new Telerik.Reporting.TextBox();
            this.AccountHeader = new Telerik.Reporting.TextBox();
            this.DebitHeader = new Telerik.Reporting.TextBox();
            this.CreditHeader = new Telerik.Reporting.TextBox();
            this.CommentsHeader = new Telerik.Reporting.TextBox();
            this.DocumentGroup = new Telerik.Reporting.TextBox();
            this.Detail = new Telerik.Reporting.DetailSection();
            this.DetailTable = new Telerik.Reporting.Table();
            this.AccountName = new Telerik.Reporting.TextBox();
            this.Debit = new Telerik.Reporting.TextBox();
            this.AccountType = new Telerik.Reporting.TextBox();
            this.Credit = new Telerik.Reporting.TextBox();
            this.DocumentTotals = new Telerik.Reporting.TextBox();
            this.TotalDebit = new Telerik.Reporting.TextBox();
            this.TotalCredit = new Telerik.Reporting.TextBox();
            this.Comments = new Telerik.Reporting.TextBox();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
            this.Pages = new Telerik.Reporting.TextBox();
            this.CreationTime = new Telerik.Reporting.TextBox();
            this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // GroupFooterSection1
            // 
            this.GroupFooterSection1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.journalId.Value>0,False,True)"));
            this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
            this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TotalsLabel,
            this.GrandTotalDebit,
            this.GrandTotalCredit});
            this.GroupFooterSection1.Name = "GroupFooterSection1";
            this.GroupFooterSection1.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.GroupFooterSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.GroupFooterSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            // 
            // TotalsLabel
            // 
            this.TotalsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TotalsLabel.Name = "TotalsLabel";
            this.TotalsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalsLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalsLabel.Style.Font.Bold = true;
            this.TotalsLabel.Style.Font.Name = "Calibri";
            this.TotalsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalsLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.TotalsLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalsLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TotalsLabel.StyleName = "Normal.TableBody";
            this.TotalsLabel.Value = "Grand Totals";
            // 
            // GrandTotalDebit
            // 
            this.GrandTotalDebit.Format = "{0:C2}";
            this.GrandTotalDebit.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.GrandTotalDebit.Name = "GrandTotalDebit";
            this.GrandTotalDebit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.GrandTotalDebit.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.GrandTotalDebit.Style.Font.Bold = true;
            this.GrandTotalDebit.Style.Font.Name = "Calibri";
            this.GrandTotalDebit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.GrandTotalDebit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.GrandTotalDebit.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.GrandTotalDebit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.GrandTotalDebit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.GrandTotalDebit.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.GrandTotalDebit.StyleName = "Normal.TableBody";
            this.GrandTotalDebit.Value = "= Sum(Fields.TotalDebit)";
            // 
            // GrandTotalCredit
            // 
            this.GrandTotalCredit.Format = "{0:C2}";
            this.GrandTotalCredit.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.GrandTotalCredit.Name = "GrandTotalCredit";
            this.GrandTotalCredit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.GrandTotalCredit.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.GrandTotalCredit.Style.Font.Bold = true;
            this.GrandTotalCredit.Style.Font.Name = "Calibri";
            this.GrandTotalCredit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.GrandTotalCredit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.GrandTotalCredit.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.GrandTotalCredit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.GrandTotalCredit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.GrandTotalCredit.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.GrandTotalCredit.StyleName = "Normal.TableBody";
            this.GrandTotalCredit.Value = "= Sum(Fields.TotalCredit)";
            // 
            // GroupHeaderSection1
            // 
            this.GroupHeaderSection1.CanShrink = true;
            this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1.6D);
            this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ManagementReportHeaderSubReport2,
            this.AccountTypeHeader,
            this.AccountHeader,
            this.DebitHeader,
            this.CreditHeader,
            this.CommentsHeader});
            this.GroupHeaderSection1.Name = "GroupHeaderSection1";
            this.GroupHeaderSection1.PrintOnEveryPage = true;
            this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.GroupHeaderSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            // 
            // ManagementReportHeaderSubReport2
            // 
            this.ManagementReportHeaderSubReport2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.ManagementReportHeaderSubReport2.Name = "ManagementReportHeaderSubReport2";
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerName", "= Parameters.customerName.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportName", "= Parameters.reportName.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportDate", "= Parameters.reportDate.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("headerContent", "= Parameters.headerContent.Value"));
            typeReportSource1.TypeName = "Travelog.Reports.Common.ManagementReportHeaderSubReport2, Travelog.Reports, Versi" +
    "on=1.0.0.0, Culture=neutral, PublicKeyToken=null";
            this.ManagementReportHeaderSubReport2.ReportSource = typeReportSource1;
            this.ManagementReportHeaderSubReport2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.ManagementReportHeaderSubReport2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            // 
            // AccountTypeHeader
            // 
            this.AccountTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.AccountTypeHeader.Name = "AccountTypeHeader";
            this.AccountTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AccountTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AccountTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AccountTypeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AccountTypeHeader.Style.Font.Bold = true;
            this.AccountTypeHeader.Style.Font.Name = "Calibri";
            this.AccountTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.AccountTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.AccountTypeHeader.StyleName = "Normal.TableHeader";
            this.AccountTypeHeader.Value = "Account Type";
            // 
            // AccountHeader
            // 
            this.AccountHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.AccountHeader.Name = "AccountHeader";
            this.AccountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AccountHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AccountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AccountHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AccountHeader.Style.Font.Bold = true;
            this.AccountHeader.Style.Font.Name = "Calibri";
            this.AccountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AccountHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.AccountHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.AccountHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.AccountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.AccountHeader.StyleName = "Normal.TableHeader";
            this.AccountHeader.Value = "Account";
            // 
            // DebitHeader
            // 
            this.DebitHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.DebitHeader.Name = "DebitHeader";
            this.DebitHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DebitHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.DebitHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DebitHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DebitHeader.Style.Font.Bold = true;
            this.DebitHeader.Style.Font.Name = "Calibri";
            this.DebitHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DebitHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.DebitHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DebitHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DebitHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.DebitHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DebitHeader.StyleName = "Normal.TableHeader";
            this.DebitHeader.Value = "Debit";
            // 
            // CreditHeader
            // 
            this.CreditHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.5D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.CreditHeader.Name = "CreditHeader";
            this.CreditHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CreditHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.CreditHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CreditHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CreditHeader.Style.Font.Bold = true;
            this.CreditHeader.Style.Font.Name = "Calibri";
            this.CreditHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CreditHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.CreditHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CreditHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CreditHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.CreditHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.CreditHeader.StyleName = "Normal.TableHeader";
            this.CreditHeader.Value = "Credit";
            // 
            // CommentsHeader
            // 
            this.CommentsHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.CommentsHeader.Name = "CommentsHeader";
            this.CommentsHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CommentsHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.CommentsHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CommentsHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CommentsHeader.Style.Font.Bold = true;
            this.CommentsHeader.Style.Font.Name = "Calibri";
            this.CommentsHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CommentsHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CommentsHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.CommentsHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CommentsHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.CommentsHeader.StyleName = "Normal.TableHeader";
            this.CommentsHeader.Value = "Comments";
            // 
            // DocumentGroup
            // 
            this.DocumentGroup.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.DocumentGroup.Name = "DocumentGroup";
            this.DocumentGroup.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DocumentGroup.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DocumentGroup.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DocumentGroup.Style.Font.Name = "Calibri";
            this.DocumentGroup.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DocumentGroup.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentGroup.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DocumentGroup.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.DocumentGroup.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentGroup.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DocumentGroup.StyleName = "Normal.TableBody";
            this.DocumentGroup.Value = resources.GetString("DocumentGroup.Value");
            // 
            // Detail
            // 
            this.Detail.CanShrink = true;
            this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(1.8D);
            this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailTable,
            this.DocumentGroup});
            this.Detail.Name = "Detail";
            this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Detail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            // 
            // DetailTable
            // 
            this.DetailTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.JournalDetailReportList"));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(6D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(4D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.5D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.5D)));
            this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
            this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
            this.DetailTable.Body.SetCellContent(0, 1, this.AccountName);
            this.DetailTable.Body.SetCellContent(0, 3, this.Debit);
            this.DetailTable.Body.SetCellContent(0, 0, this.AccountType);
            this.DetailTable.Body.SetCellContent(0, 4, this.Credit);
            this.DetailTable.Body.SetCellContent(1, 0, this.DocumentTotals, 1, 2);
            this.DetailTable.Body.SetCellContent(1, 3, this.TotalDebit);
            this.DetailTable.Body.SetCellContent(1, 4, this.TotalCredit);
            this.DetailTable.Body.SetCellContent(0, 2, this.Comments);
            this.DetailTable.Body.SetCellContent(1, 2, this.textBox2);
            tableGroup1.Name = "group1";
            tableGroup2.Name = "tableGroup";
            tableGroup3.Name = "group7";
            tableGroup4.Name = "group";
            tableGroup5.Name = "group3";
            this.DetailTable.ColumnGroups.Add(tableGroup1);
            this.DetailTable.ColumnGroups.Add(tableGroup2);
            this.DetailTable.ColumnGroups.Add(tableGroup3);
            this.DetailTable.ColumnGroups.Add(tableGroup4);
            this.DetailTable.ColumnGroups.Add(tableGroup5);
            this.DetailTable.ColumnHeadersPrintOnEveryPage = true;
            this.DetailTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AccountType,
            this.AccountName,
            this.Comments,
            this.Debit,
            this.Credit,
            this.DocumentTotals,
            this.textBox2,
            this.TotalDebit,
            this.TotalCredit});
            this.DetailTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DetailTable.Name = "DetailTable";
            tableGroup7.Name = "group2";
            tableGroup6.ChildGroups.Add(tableGroup7);
            tableGroup6.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup6.Name = "detailTableGroup";
            tableGroup9.Name = "group6";
            tableGroup8.ChildGroups.Add(tableGroup9);
            tableGroup8.Name = "group5";
            this.DetailTable.RowGroups.Add(tableGroup6);
            this.DetailTable.RowGroups.Add(tableGroup8);
            this.DetailTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.DetailTable.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            // 
            // AccountName
            // 
            this.AccountName.Name = "AccountName";
            this.AccountName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AccountName.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AccountName.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AccountName.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AccountName.Style.Font.Name = "Calibri";
            this.AccountName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AccountName.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccountName.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.AccountName.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.AccountName.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccountName.StyleName = "Normal.TableBody";
            this.AccountName.Value = "= Fields.AccountName";
            // 
            // Debit
            // 
            this.Debit.Format = "{0:C2}";
            this.Debit.Name = "Debit";
            this.Debit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Debit.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Debit.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Debit.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Debit.Style.Font.Name = "Calibri";
            this.Debit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Debit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Debit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Debit.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Debit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Debit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Debit.StyleName = "Normal.TableBody";
            this.Debit.Value = "= Fields.Debit";
            // 
            // AccountType
            // 
            this.AccountType.Name = "AccountType";
            this.AccountType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AccountType.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AccountType.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AccountType.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AccountType.Style.Font.Name = "Calibri";
            this.AccountType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccountType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.AccountType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccountType.StyleName = "Normal.TableBody";
            this.AccountType.Value = "= Fields.AccountType";
            // 
            // Credit
            // 
            this.Credit.Format = "{0:C2}";
            this.Credit.Name = "Credit";
            this.Credit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Credit.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Credit.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Credit.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Credit.Style.Font.Name = "Calibri";
            this.Credit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Credit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Credit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Credit.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Credit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Credit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Credit.StyleName = "Normal.TableBody";
            this.Credit.Value = "= Fields.Credit";
            // 
            // DocumentTotals
            // 
            this.DocumentTotals.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.DocumentTotals.Name = "DocumentTotals";
            this.DocumentTotals.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DocumentTotals.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DocumentTotals.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DocumentTotals.Style.Font.Name = "Calibri";
            this.DocumentTotals.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DocumentTotals.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DocumentTotals.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentTotals.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.DocumentTotals.StyleName = "Normal.TableBody";
            this.DocumentTotals.Value = "Totals";
            // 
            // TotalDebit
            // 
            this.TotalDebit.Format = "{0:C2}";
            this.TotalDebit.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TotalDebit.Name = "TotalDebit";
            this.TotalDebit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalDebit.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalDebit.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalDebit.Style.Font.Name = "Calibri";
            this.TotalDebit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalDebit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.TotalDebit.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.TotalDebit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDebit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalDebit.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.TotalDebit.StyleName = "Normal.TableBody";
            this.TotalDebit.Value = "= Sum(Fields.Debit)";
            // 
            // TotalCredit
            // 
            this.TotalCredit.Format = "{0:C2}";
            this.TotalCredit.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TotalCredit.Name = "TotalCredit";
            this.TotalCredit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalCredit.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalCredit.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalCredit.Style.Font.Name = "Calibri";
            this.TotalCredit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalCredit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.TotalCredit.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.TotalCredit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalCredit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalCredit.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.TotalCredit.StyleName = "Normal.TableBody";
            this.TotalCredit.Value = "= Sum(Fields.Credit)";
            // 
            // Comments
            // 
            this.Comments.Name = "Comments";
            this.Comments.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Comments.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Comments.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Comments.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Comments.Style.Font.Name = "Calibri";
            this.Comments.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Comments.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Comments.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Comments.StyleName = "Normal.TableBody";
            this.Comments.Value = "= Fields.Comments";
            // 
            // textBox2
            // 
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.textBox2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.textBox2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox2.Style.Font.Name = "Calibri";
            this.textBox2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.textBox2.StyleName = "Normal.TableBody";
            // 
            // PageFooterSection
            // 
            this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
            this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
            this.PageFooterSection.Name = "PageFooter";
            // 
            // Pages
            // 
            this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Pages.Name = "Pages";
            this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Pages.Style.Color = System.Drawing.Color.DarkGray;
            this.Pages.Style.Font.Name = "Calibri";
            this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Pages.Value = "= \"Page \" + PageNumber";
            // 
            // CreationTime
            // 
            this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.CreationTime.Name = "CreationTime";
            this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
            this.CreationTime.Style.Font.Name = "Calibri";
            this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy" +
    " HH:mm}\", Parameters.creationTime.Value)";
            // 
            // ReportDataSource
            // 
            this.ReportDataSource.DataMember = "JournalReport";
            this.ReportDataSource.DataSource = typeof(Travelog.Reports.Accounting.AccountingDataSources);
            this.ReportDataSource.Name = "ReportDataSource";
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("journalId", typeof(int), "= Parameters.journalId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateFrom", typeof(System.Nullable<System.DateTime>), "= Parameters.dateFrom.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateTo", typeof(System.Nullable<System.DateTime>), "= Parameters.dateTo.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("accountTypeId", typeof(int), "= Parameters.accountTypeId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("documentStatusId", typeof(System.Nullable<int>), "= Parameters.documentStatusId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("amountFrom", typeof(System.Nullable<decimal>), "= Parameters.amountFrom.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("amountTo", typeof(System.Nullable<decimal>), "= Parameters.amountTo.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("account", typeof(string), "= Parameters.account.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("text", typeof(string), "= Parameters.text.Value"));
            // 
            // JournalReport
            // 
            this.DataSource = this.ReportDataSource;
            group1.GroupFooter = this.GroupFooterSection1;
            group1.GroupHeader = this.GroupHeaderSection1;
            group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
            group1.Name = "Group1";
            this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1});
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail,
            this.PageFooterSection});
            this.Name = "JournalReport";
            this.PageSettings.ContinuousPaper = false;
            this.PageSettings.Landscape = false;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            reportParameter1.Name = "customerId";
            reportParameter2.Name = "agencyId";
            reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter3.Name = "customerName";
            reportParameter4.Name = "reportName";
            reportParameter5.Name = "reportDate";
            reportParameter6.Name = "headerContent";
            reportParameter7.Name = "creationUser";
            reportParameter8.Name = "creationTime";
            reportParameter8.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter9.Name = "journalId";
            reportParameter9.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter10.AllowNull = true;
            reportParameter10.Name = "dateFrom";
            reportParameter10.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter11.AllowNull = true;
            reportParameter11.Name = "dateTo";
            reportParameter11.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter12.Name = "accountTypeId";
            reportParameter12.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter13.AllowNull = true;
            reportParameter13.Name = "documentStatusId";
            reportParameter13.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter14.AllowNull = true;
            reportParameter14.Name = "amountFrom";
            reportParameter14.Type = Telerik.Reporting.ReportParameterType.Float;
            reportParameter15.AllowNull = true;
            reportParameter15.Name = "amountTo";
            reportParameter15.Type = Telerik.Reporting.ReportParameterType.Float;
            reportParameter16.AllowNull = true;
            reportParameter16.Name = "account";
            reportParameter17.AllowNull = true;
            reportParameter17.Name = "text";
            this.ReportParameters.Add(reportParameter1);
            this.ReportParameters.Add(reportParameter2);
            this.ReportParameters.Add(reportParameter3);
            this.ReportParameters.Add(reportParameter4);
            this.ReportParameters.Add(reportParameter5);
            this.ReportParameters.Add(reportParameter6);
            this.ReportParameters.Add(reportParameter7);
            this.ReportParameters.Add(reportParameter8);
            this.ReportParameters.Add(reportParameter9);
            this.ReportParameters.Add(reportParameter10);
            this.ReportParameters.Add(reportParameter11);
            this.ReportParameters.Add(reportParameter12);
            this.ReportParameters.Add(reportParameter13);
            this.ReportParameters.Add(reportParameter14);
            this.ReportParameters.Add(reportParameter15);
            this.ReportParameters.Add(reportParameter16);
            this.ReportParameters.Add(reportParameter17);
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(18D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.SubReport ManagementReportHeaderSubReport2;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.TextBox TotalsLabel;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.TextBox GrandTotalDebit;
		private Telerik.Reporting.TextBox GrandTotalCredit;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.TextBox DocumentGroup;
		private Telerik.Reporting.Table DetailTable;
		private Telerik.Reporting.TextBox AccountName;
		private Telerik.Reporting.TextBox Debit;
		private Telerik.Reporting.TextBox AccountType;
		private Telerik.Reporting.TextBox Credit;
		private Telerik.Reporting.TextBox AccountTypeHeader;
		private Telerik.Reporting.TextBox AccountHeader;
		private Telerik.Reporting.TextBox DebitHeader;
		private Telerik.Reporting.TextBox CreditHeader;
		private Telerik.Reporting.TextBox DocumentTotals;
		private Telerik.Reporting.TextBox TotalDebit;
		private Telerik.Reporting.TextBox TotalCredit;
		private Telerik.Reporting.TextBox CommentsHeader;
		private Telerik.Reporting.TextBox Comments;
		private Telerik.Reporting.TextBox textBox2;
	}
}