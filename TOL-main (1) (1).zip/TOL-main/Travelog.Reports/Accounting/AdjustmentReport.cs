using System;
using Telerik.Reporting;
using Travelog.Biz.Resources;

namespace Travelog.Reports.Accounting {
	public partial class AdjustmentReport : TelerikReport {
		public AdjustmentReport() {
			InitializeComponent();
		}

		private void TaxHeader_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = Resource.TaxLabel;
		}
	}
}