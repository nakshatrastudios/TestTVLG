using Telerik.Reporting;

namespace Travelog.Reports.DebtorLedger {

	public partial class ReceiptBankDepositReport : TelerikReport {
		public ReceiptBankDepositReport() {
			InitializeComponent();
		}
	}
}