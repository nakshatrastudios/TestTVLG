namespace Travelog.Reports.DebtorLedger {
	partial class ReceiptBankDepositReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup10 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup11 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
			this.DocumentNoHeader = new Telerik.Reporting.TextBox();
			this.DocumentDateHeader = new Telerik.Reporting.TextBox();
			this.AccountHeader = new Telerik.Reporting.TextBox();
			this.PaymentDetailsHeader = new Telerik.Reporting.TextBox();
			this.AmountHeader = new Telerik.Reporting.TextBox();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.PaymentOptionsPanel = new Telerik.Reporting.Panel();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.ReportNameLabel = new Telerik.Reporting.TextBox();
			this.BankAccountName = new Telerik.Reporting.TextBox();
			this.BankAccountBranch = new Telerik.Reporting.TextBox();
			this.BankAccountNo = new Telerik.Reporting.TextBox();
			this.ManagementReportHeaderSubReport2 = new Telerik.Reporting.SubReport();
			this.textBox1 = new Telerik.Reporting.TextBox();
			this.Agency = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.DetailTable = new Telerik.Reporting.Crosstab();
			this.PaymentDetails = new Telerik.Reporting.TextBox();
			this.DocumentNo = new Telerik.Reporting.TextBox();
			this.DocumentDate = new Telerik.Reporting.TextBox();
			this.Account = new Telerik.Reporting.TextBox();
			this.Amount = new Telerik.Reporting.TextBox();
			this.TotalAmount = new Telerik.Reporting.TextBox();
			this.TotalAmountLabel = new Telerik.Reporting.TextBox();
			this.FormOfPaymentType = new Telerik.Reporting.TextBox();
			this.FormOfPaymentTypeTotalLabel = new Telerik.Reporting.TextBox();
			this.FormOfPaymentTypeTotal = new Telerik.Reporting.TextBox();
			this.Pages = new Telerik.Reporting.TextBox();
			this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
			this.CreationTime = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// DocumentNoHeader
			// 
			this.DocumentNoHeader.Name = "DocumentNoHeader";
			this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNoHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentNoHeader.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNoHeader.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNoHeader.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNoHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNoHeader.Style.Font.Bold = true;
			this.DocumentNoHeader.Style.Font.Name = "Calibri";
			this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNoHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentNoHeader.StyleName = "Normal.TableHeader";
			this.DocumentNoHeader.Value = "Receipt No";
			// 
			// DocumentDateHeader
			// 
			this.DocumentDateHeader.Name = "DocumentDateHeader";
			this.DocumentDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDateHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDateHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentDateHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDateHeader.Style.Font.Bold = true;
			this.DocumentDateHeader.Style.Font.Name = "Calibri";
			this.DocumentDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDateHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDateHeader.StyleName = "Normal.TableHeader";
			this.DocumentDateHeader.Value = "Date";
			// 
			// AccountHeader
			// 
			this.AccountHeader.Name = "AccountHeader";
			this.AccountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccountHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AccountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccountHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AccountHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AccountHeader.Style.Font.Bold = true;
			this.AccountHeader.Style.Font.Name = "Calibri";
			this.AccountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AccountHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AccountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AccountHeader.StyleName = "Normal.TableHeader";
			this.AccountHeader.Value = "Account";
			// 
			// PaymentDetailsHeader
			// 
			this.PaymentDetailsHeader.Name = "PaymentDetailsHeader";
			this.PaymentDetailsHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.PaymentDetailsHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.PaymentDetailsHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.PaymentDetailsHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.PaymentDetailsHeader.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.PaymentDetailsHeader.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.PaymentDetailsHeader.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.PaymentDetailsHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.PaymentDetailsHeader.Style.Font.Bold = true;
			this.PaymentDetailsHeader.Style.Font.Name = "Calibri";
			this.PaymentDetailsHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PaymentDetailsHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PaymentDetailsHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.PaymentDetailsHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PaymentDetailsHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.PaymentDetailsHeader.StyleName = "Normal.TableHeader";
			this.PaymentDetailsHeader.Value = "Payment Details";
			// 
			// AmountHeader
			// 
			this.AmountHeader.Name = "AmountHeader";
			this.AmountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AmountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AmountHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AmountHeader.Style.Font.Bold = true;
			this.AmountHeader.Style.Font.Name = "Calibri";
			this.AmountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AmountHeader.StyleName = "Normal.TableHeader";
			this.AmountHeader.Value = "Amount";
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.PaymentOptionsPanel});
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			this.GroupFooterSection1.Style.Visible = false;
            // 
            // PaymentOptionsPanel
            // 
            this.PaymentOptionsPanel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.PaymentOptionsPanel.Name = "PaymentOptionsPanel";
			this.PaymentOptionsPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.PaymentOptionsPanel.Style.Visible = false;
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(3.5D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ReportNameLabel,
            this.BankAccountName,
            this.BankAccountBranch,
            this.BankAccountNo,
            this.ManagementReportHeaderSubReport2,
            this.textBox1,
            this.Agency});
			this.GroupHeaderSection1.KeepTogether = false;
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			// 
			// ReportNameLabel
			// 
			this.ReportNameLabel.CanShrink = true;
			this.ReportNameLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ReportNameLabel.Name = "ReportNameLabel";
			this.ReportNameLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.ReportNameLabel.Style.Font.Name = "Calibri";
			this.ReportNameLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(18D);
			this.ReportNameLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(0D);
			this.ReportNameLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReportNameLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ReportNameLabel.Value = "BANK DEPOSIT";
			// 
			// BankAccountName
			// 
			this.BankAccountName.Format = "";
			this.BankAccountName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.BankAccountName.Name = "BankAccountName";
			this.BankAccountName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BankAccountName.Style.Font.Name = "Calibri";
			this.BankAccountName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BankAccountName.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BankAccountName.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BankAccountName.Value = "= \"Bank: \" + Fields.BankAccountName";
			// 
			// BankAccountBranch
			// 
			this.BankAccountBranch.Format = "";
			this.BankAccountBranch.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(2D));
			this.BankAccountBranch.Name = "BankAccountBranch";
			this.BankAccountBranch.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BankAccountBranch.Style.Font.Name = "Calibri";
			this.BankAccountBranch.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BankAccountBranch.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BankAccountBranch.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BankAccountBranch.Value = "= \"Branch: \" + Fields.BankAccountBranch";
			// 
			// BankAccountNo
			// 
			this.BankAccountNo.Format = "";
			this.BankAccountNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(2.5D));
			this.BankAccountNo.Name = "BankAccountNo";
			this.BankAccountNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BankAccountNo.Style.Font.Name = "Calibri";
			this.BankAccountNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BankAccountNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BankAccountNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BankAccountNo.Value = "= \"Account No: \" + Fields.BankAccountNo";
			// 
			// ManagementReportHeaderSubReport2
			// 
			this.ManagementReportHeaderSubReport2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ManagementReportHeaderSubReport2.Name = "ManagementReportHeaderSubReport2";
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerName", "= Parameters.customerName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportName", "= Null"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportDate", "= Null"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("headerContent", "= Parameters.headerContent.Value"));
			typeReportSource1.TypeName = "Travelog.Reports.Common.ManagementReportHeaderSubReport2, Travelog.Reports, Versi" +
    "on=1.0.0.0, Culture=neutral, PublicKeyToken=null";
			this.ManagementReportHeaderSubReport2.ReportSource = typeReportSource1;
			this.ManagementReportHeaderSubReport2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ManagementReportHeaderSubReport2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// textBox1
			// 
			this.textBox1.Format = "";
			this.textBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.9D));
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.textBox1.Style.Font.Name = "Calibri";
			this.textBox1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.textBox1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.textBox1.Value = "= \"Deposit Date: \" + Fields.DepositDate";
			// 
			// Agency
			// 
			this.Agency.Format = "";
			this.Agency.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.Agency.Name = "Agency";
			this.Agency.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Agency.Style.Font.Name = "Calibri";
			this.Agency.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Agency.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Agency.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Agency.Value = "= \"Agency: \" + Fields.Agency";
			// 
			// Detail
			// 
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(3D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailTable});
			this.Detail.Name = "Detail";
			// 
			// DetailTable
			// 
			this.DetailTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.ReceiptDetailBankDepositReportList"));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.3D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(5.7D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(5.7D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.3D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.SetCellContent(1, 3, this.PaymentDetails);
			this.DetailTable.Body.SetCellContent(1, 0, this.DocumentNo);
			this.DetailTable.Body.SetCellContent(1, 1, this.DocumentDate);
			this.DetailTable.Body.SetCellContent(1, 2, this.Account);
			this.DetailTable.Body.SetCellContent(1, 4, this.Amount);
			this.DetailTable.Body.SetCellContent(3, 4, this.TotalAmount);
			this.DetailTable.Body.SetCellContent(3, 0, this.TotalAmountLabel, 1, 4);
			this.DetailTable.Body.SetCellContent(0, 0, this.FormOfPaymentType, 1, 5);
			this.DetailTable.Body.SetCellContent(2, 0, this.FormOfPaymentTypeTotalLabel, 1, 4);
			this.DetailTable.Body.SetCellContent(2, 4, this.FormOfPaymentTypeTotal);
			tableGroup1.Name = "tableGroup8";
			tableGroup1.ReportItem = this.DocumentNoHeader;
			tableGroup2.Name = "group";
			tableGroup2.ReportItem = this.DocumentDateHeader;
			tableGroup3.Name = "group1";
			tableGroup3.ReportItem = this.AccountHeader;
			tableGroup4.Name = "tableGroup9";
			tableGroup4.ReportItem = this.PaymentDetailsHeader;
			tableGroup5.Name = "group2";
			tableGroup5.ReportItem = this.AmountHeader;
			this.DetailTable.ColumnGroups.Add(tableGroup1);
			this.DetailTable.ColumnGroups.Add(tableGroup2);
			this.DetailTable.ColumnGroups.Add(tableGroup3);
			this.DetailTable.ColumnGroups.Add(tableGroup4);
			this.DetailTable.ColumnGroups.Add(tableGroup5);
			this.DetailTable.ColumnHeadersPrintOnEveryPage = true;
			this.DetailTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.FormOfPaymentType,
            this.DocumentNo,
            this.DocumentDate,
            this.Account,
            this.PaymentDetails,
            this.Amount,
            this.FormOfPaymentTypeTotalLabel,
            this.FormOfPaymentTypeTotal,
            this.TotalAmountLabel,
            this.TotalAmount,
            this.DocumentNoHeader,
            this.DocumentDateHeader,
            this.AccountHeader,
            this.PaymentDetailsHeader,
            this.AmountHeader});
			this.DetailTable.KeepTogether = false;
			this.DetailTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DetailTable.Name = "DetailTable";
			tableGroup7.Name = "group4";
			tableGroup8.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup8.Name = "detailTableGroup";
			tableGroup9.Name = "group6";
			tableGroup6.ChildGroups.Add(tableGroup7);
			tableGroup6.ChildGroups.Add(tableGroup8);
			tableGroup6.ChildGroups.Add(tableGroup9);
			tableGroup6.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.FormOfPaymentType"));
			tableGroup6.Name = "formOfPaymentType";
			tableGroup6.Sortings.Add(new Telerik.Reporting.Sorting("= Fields.FormOfPaymentType", Telerik.Reporting.SortDirection.Asc));
			tableGroup11.Name = "group3";
			tableGroup10.ChildGroups.Add(tableGroup11);
			tableGroup10.Name = "group5";
			this.DetailTable.RowGroups.Add(tableGroup6);
			this.DetailTable.RowGroups.Add(tableGroup10);
			this.DetailTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			// 
			// PaymentDetails
			// 
			this.PaymentDetails.Format = "";
			this.PaymentDetails.Name = "PaymentDetails";
			this.PaymentDetails.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.PaymentDetails.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.PaymentDetails.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.PaymentDetails.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.PaymentDetails.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.PaymentDetails.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.PaymentDetails.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.PaymentDetails.Style.Font.Name = "Calibri";
			this.PaymentDetails.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PaymentDetails.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.PaymentDetails.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PaymentDetails.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.PaymentDetails.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.PaymentDetails.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.PaymentDetails.StyleName = "Normal.TableBody";
			this.PaymentDetails.Value = "= Fields.PaymentDetails";
			// 
			// DocumentNo
			// 
			this.DocumentNo.Format = "";
			this.DocumentNo.Name = "DocumentNo";
			this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNo.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentNo.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNo.Style.Font.Name = "Calibri";
			this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentNo.StyleName = "Normal.TableBody";
			this.DocumentNo.Value = "= Fields.DocumentNo";
			// 
			// DocumentDate
			// 
			this.DocumentDate.Format = "{0:dd-MMM-yyyy}";
			this.DocumentDate.Name = "DocumentDate";
			this.DocumentDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDate.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentDate.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDate.Style.Font.Name = "Calibri";
			this.DocumentDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.StyleName = "Normal.TableBody";
			this.DocumentDate.Value = "= Fields.DocumentDate";
			// 
			// Account
			// 
			this.Account.Name = "Account";
			this.Account.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Account.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Account.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Account.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Account.Style.Font.Name = "Calibri";
			this.Account.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Account.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Account.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Account.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Account.StyleName = "Normal.TableBody";
			this.Account.Value = "= Fields.AccountName";
			// 
			// Amount
			// 
			this.Amount.Format = "{0:c2}";
			this.Amount.Name = "Amount";
			this.Amount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Amount.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Amount.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Amount.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Amount.Style.Font.Name = "Calibri";
			this.Amount.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Amount.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Amount.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Amount.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Amount.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Amount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Amount.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Amount.StyleName = "Normal.TableBody";
			this.Amount.Value = "= Fields.Amount";
			// 
			// TotalAmount
			// 
			this.TotalAmount.Format = "{0:c2}";
			this.TotalAmount.Name = "TotalAmount";
			this.TotalAmount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalAmount.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalAmount.Style.Font.Bold = true;
			this.TotalAmount.Style.Font.Name = "Calibri";
			this.TotalAmount.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalAmount.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TotalAmount.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalAmount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalAmount.StyleName = "Normal.TableBody";
			this.TotalAmount.Value = "= Sum(Amount)";
			// 
			// TotalAmountLabel
			// 
			this.TotalAmountLabel.Name = "TotalAmountLabel";
			this.TotalAmountLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalAmountLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalAmountLabel.Style.Font.Bold = true;
			this.TotalAmountLabel.Style.Font.Name = "Calibri";
			this.TotalAmountLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalAmountLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TotalAmountLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalAmountLabel.StyleName = "Normal.TableBody";
			this.TotalAmountLabel.Value = "Grand Total";
			// 
			// FormOfPaymentType
			// 
			this.FormOfPaymentType.Name = "FormOfPaymentType";
			this.FormOfPaymentType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.FormOfPaymentType.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.FormOfPaymentType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.FormOfPaymentType.Style.Font.Name = "Calibri";
			this.FormOfPaymentType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.FormOfPaymentType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.FormOfPaymentType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.FormOfPaymentType.Style.Visible = false;
			this.FormOfPaymentType.StyleName = "Normal.TableBody";
			this.FormOfPaymentType.Value = "= \"Form Of Payment Type: \" + Fields.FormOfPaymentType";
			// 
			// FormOfPaymentTypeTotalLabel
			// 
			this.FormOfPaymentTypeTotalLabel.Name = "FormOfPaymentTypeTotalLabel";
			this.FormOfPaymentTypeTotalLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.FormOfPaymentTypeTotalLabel.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.FormOfPaymentTypeTotalLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.FormOfPaymentTypeTotalLabel.Style.Font.Name = "Calibri";
			this.FormOfPaymentTypeTotalLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.FormOfPaymentTypeTotalLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.FormOfPaymentTypeTotalLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.FormOfPaymentTypeTotalLabel.StyleName = "Normal.TableBody";
			this.FormOfPaymentTypeTotalLabel.Value = "= Fields.FormOfPaymentType + \" Total\"";
			// 
			// FormOfPaymentTypeTotal
			// 
			this.FormOfPaymentTypeTotal.Format = "{0:c2}";
			this.FormOfPaymentTypeTotal.Name = "FormOfPaymentTypeTotal";
			this.FormOfPaymentTypeTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.FormOfPaymentTypeTotal.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.FormOfPaymentTypeTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.FormOfPaymentTypeTotal.Style.Font.Name = "Calibri";
			this.FormOfPaymentTypeTotal.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.FormOfPaymentTypeTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.FormOfPaymentTypeTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.FormOfPaymentTypeTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.FormOfPaymentTypeTotal.StyleName = "Normal.TableBody";
			this.FormOfPaymentTypeTotal.Value = "= Sum(Amount)";
			// 
			// Pages
			// 
			this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Name = "Pages";
			this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Style.Color = System.Drawing.Color.DarkGray;
			this.Pages.Style.Font.Name = "Calibri";
			this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Pages.Value = "= \"Page \" + PageNumber";
			// 
			// PageFooterSection
			// 
			this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
			this.PageFooterSection.Name = "PageFooterSection";
			// 
			// CreationTime
			// 
			this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Name = "CreationTime";
			this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
			this.CreationTime.Style.Font.Name = "Calibri";
			this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy" +
    " HH:mm}\", Parameters.creationTime.Value)";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "ReceiptBankDepositReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.Accounting.AccountingDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("depositDate", typeof(System.DateTime), "= Parameters.depositDate.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("bankAccountId", typeof(int), "= Parameters.bankAccountId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("receiptId", typeof(int), "= Parameters.receiptId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("receiptDetailIds", typeof(string), "= Parameters.receiptDetailIds.Value"));
			// 
			// ReceiptBankDepositReport
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.Name = "Group1";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail,
            this.PageFooterSection});
			this.Name = "ReceiptBankDepositReport";
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "customerId";
			reportParameter2.Name = "agencyId";
			reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter3.Name = "customerName";
			reportParameter4.Name = "headerContent";
			reportParameter5.Name = "creationUser";
			reportParameter6.Name = "creationTime";
			reportParameter6.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter7.Name = "depositDate";
			reportParameter7.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter8.Name = "bankAccountId";
			reportParameter8.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter9.Name = "receiptId";
			reportParameter9.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter10.AllowNull = true;
			reportParameter10.Name = "receiptDetailIds";
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.ReportParameters.Add(reportParameter9);
			this.ReportParameters.Add(reportParameter10);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(18D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.Crosstab DetailTable;
		private Telerik.Reporting.TextBox PaymentDetails;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox PaymentDetailsHeader;
		private Telerik.Reporting.TextBox DocumentDate;
		private Telerik.Reporting.TextBox DocumentDateHeader;
		private Telerik.Reporting.TextBox Account;
		private Telerik.Reporting.TextBox AccountHeader;
		private Telerik.Reporting.TextBox Amount;
		private Telerik.Reporting.TextBox AmountHeader;
		private Telerik.Reporting.TextBox TotalAmountLabel;
		private Telerik.Reporting.TextBox TotalAmount;
		private Telerik.Reporting.Panel PaymentOptionsPanel;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.SubReport ManagementReportHeaderSubReport2;
		private Telerik.Reporting.TextBox BankAccountNo;
		private Telerik.Reporting.TextBox BankAccountBranch;
		private Telerik.Reporting.TextBox BankAccountName;
		private Telerik.Reporting.TextBox ReportNameLabel;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.TextBox FormOfPaymentType;
		private Telerik.Reporting.TextBox FormOfPaymentTypeTotalLabel;
		private Telerik.Reporting.TextBox FormOfPaymentTypeTotal;
		private Telerik.Reporting.TextBox textBox1;
		private Telerik.Reporting.TextBox Agency;
	}
}