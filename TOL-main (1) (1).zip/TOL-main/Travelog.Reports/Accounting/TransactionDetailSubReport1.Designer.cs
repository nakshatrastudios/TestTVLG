namespace Travelog.Reports.Accounting {
	partial class TransactionDetailSubReport1 {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.DocumentTypeHeader = new Telerik.Reporting.TextBox();
			this.DocumentNoHeader = new Telerik.Reporting.TextBox();
			this.AmountHeader = new Telerik.Reporting.TextBox();
			this.ReferenceHeader = new Telerik.Reporting.TextBox();
			this.DescriptionHeader = new Telerik.Reporting.TextBox();
			this.DateHeader = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.DocumentNo = new Telerik.Reporting.TextBox();
			this.DocumentType = new Telerik.Reporting.TextBox();
			this.Amount = new Telerik.Reporting.TextBox();
			this.Reference = new Telerik.Reporting.TextBox();
			this.Description = new Telerik.Reporting.TextBox();
			this.Date = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.CanShrink = true;
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			this.GroupFooterSection1.Style.Visible = false;
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DocumentTypeHeader,
            this.DocumentNoHeader,
            this.AmountHeader,
            this.ReferenceHeader,
            this.DescriptionHeader,
            this.DateHeader});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = true;
			this.GroupHeaderSection1.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			// 
			// DocumentTypeHeader
			// 
			this.DocumentTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentTypeHeader.Name = "DocumentTypeHeader";
			this.DocumentTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentTypeHeader.Style.Font.Name = "Calibri";
			this.DocumentTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentTypeHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentTypeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentTypeHeader.StyleName = "Normal.TableHeader";
			this.DocumentTypeHeader.Value = "Type";
			// 
			// DocumentNoHeader
			// 
			this.DocumentNoHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentNoHeader.Name = "DocumentNoHeader";
			this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNoHeader.Style.Font.Name = "Calibri";
			this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNoHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNoHeader.StyleName = "Normal.TableHeader";
			this.DocumentNoHeader.Value = "Document No";
			// 
			// AmountHeader
			// 
			this.AmountHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountHeader.Name = "AmountHeader";
			this.AmountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AmountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountHeader.Style.Font.Name = "Calibri";
			this.AmountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountHeader.StyleName = "Normal.TableHeader";
			this.AmountHeader.Value = "Amount";
			// 
			// ReferenceHeader
			// 
			this.ReferenceHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ReferenceHeader.Name = "ReferenceHeader";
			this.ReferenceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReferenceHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ReferenceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReferenceHeader.Style.Font.Name = "Calibri";
			this.ReferenceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReferenceHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReferenceHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ReferenceHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ReferenceHeader.StyleName = "Normal.TableHeader";
			this.ReferenceHeader.Value = "Reference";
			// 
			// DescriptionHeader
			// 
			this.DescriptionHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DescriptionHeader.Name = "DescriptionHeader";
			this.DescriptionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DescriptionHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DescriptionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DescriptionHeader.Style.Font.Name = "Calibri";
			this.DescriptionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DescriptionHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DescriptionHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DescriptionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DescriptionHeader.StyleName = "Normal.TableHeader";
			this.DescriptionHeader.Value = "Description";
			// 
			// DateHeader
			// 
			this.DateHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DateHeader.Name = "DateHeader";
			this.DateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DateHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DateHeader.Style.Font.Name = "Calibri";
			this.DateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DateHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DateHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DateHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DateHeader.StyleName = "Normal.TableHeader";
			this.DateHeader.Value = "Date";
			// 
			// Detail
			// 
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DocumentNo,
            this.DocumentType,
            this.Amount,
            this.Reference,
            this.Description,
            this.Date});
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// DocumentNo
			// 
			this.DocumentNo.Format = "{0:C2}";
			this.DocumentNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentNo.Name = "DocumentNo";
			this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNo.Style.Font.Name = "Calibri";
			this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.StyleName = "Normal.TableBody";
			this.DocumentNo.Value = "= Fields.DocumentNo";
			// 
			// DocumentType
			// 
			this.DocumentType.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentType.Name = "DocumentType";
			this.DocumentType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentType.Style.Font.Name = "Calibri";
			this.DocumentType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentType.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentType.StyleName = "Normal.TableBody";
			this.DocumentType.Value = "= Fields.DocumentType";
			// 
			// Amount
			// 
			this.Amount.Format = "{0:C2}";
			this.Amount.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Amount.Name = "Amount";
			this.Amount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Amount.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Amount.Style.Font.Name = "Calibri";
			this.Amount.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Amount.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Amount.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Amount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Amount.StyleName = "Normal.TableBody";
			this.Amount.Value = "= Fields.AmountGross";
			// 
			// Reference
			// 
			this.Reference.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Reference.Name = "Reference";
			this.Reference.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Reference.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Reference.Style.Font.Name = "Calibri";
			this.Reference.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Reference.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Reference.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Reference.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Reference.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Reference.StyleName = "Normal.TableBody";
			this.Reference.Value = "= Fields.Reference";
			// 
			// Description
			// 
			this.Description.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Description.Name = "Description";
			this.Description.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Description.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Description.Style.Font.Name = "Calibri";
			this.Description.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Description.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Description.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Description.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Description.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Description.StyleName = "Normal.TableBody";
			this.Description.Value = "= Fields.Description";
			// 
			// Date
			// 
			this.Date.CanShrink = true;
			this.Date.Format = "{0:dd-MMM-yyyy}";
			this.Date.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Date.Name = "Date";
			this.Date.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Date.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Date.Style.Font.Name = "Calibri";
			this.Date.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Date.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Date.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Date.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Date.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Date.StyleName = "Normal.TableBody";
			this.Date.Value = "= Fields.DocumentDate";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "TransactionDetailReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.Accounting.AccountingDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("tripId", typeof(int), "= Parameters.tripId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("debtorId", typeof(int), "= Parameters.debtorId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("creditorId", typeof(int), "= Parameters.creditorId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("chartOfAccountId", typeof(int), "= Parameters.chartOfAccountId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("transactionDetailIds", typeof(string), "= Parameters.transactionDetailIds.Value"));
			// 
			// TransactionDetailSubReport1
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail});
			this.Name = "TransactionDetailSubReport1";
			this.PageSettings.Landscape = true;
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "customerId";
			reportParameter2.Name = "agencyId";
			reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter3.Name = "tripId";
			reportParameter3.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter4.Name = "debtorId";
			reportParameter4.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter5.Name = "creditorId";
			reportParameter5.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter6.Name = "chartOfAccountId";
			reportParameter6.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter7.Name = "transactionDetailIds";
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(27.7D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.TextBox DateHeader;
		private Telerik.Reporting.TextBox DocumentTypeHeader;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox AmountHeader;
		private Telerik.Reporting.TextBox Date;
		private Telerik.Reporting.TextBox DocumentType;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox Amount;
		private Telerik.Reporting.TextBox ReferenceHeader;
		private Telerik.Reporting.TextBox Reference;
		private Telerik.Reporting.TextBox DescriptionHeader;
		private Telerik.Reporting.TextBox Description;
	}
}