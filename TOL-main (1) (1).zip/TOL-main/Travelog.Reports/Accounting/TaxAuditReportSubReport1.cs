using System;
using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Resources;

namespace Travelog.Reports.Accounting {
	public partial class TaxAuditReportSubReport1 : TelerikReport {
		public TaxAuditReportSubReport1() {
			InitializeComponent();
		}

		private void GroupHeaderLabel_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			switch (textBox.Report.Parameters["reportGroupId"].Value.ToInt()) {
				case 0:
					textBox.Value = string.Format("{0}-Exempt Sales", Resource.TaxLabel);
					break;
				case 1:
					textBox.Value = string.Format("{0}-Applicable Sales", Resource.TaxLabel);
					break;
				case 2:
					textBox.Value = string.Format("{0}-Applicable Purchases", Resource.TaxLabel);
					break;
			}
		}

		private void TotalsLabel_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			switch (textBox.Report.Parameters["reportGroupId"].Value.ToInt()) {
				case 0:
					textBox.Value = string.Format("Total {0}-Exempt Sales", Resource.TaxLabel);
					break;
				case 1:
					textBox.Value = string.Format("Total {0}-Applicable Sales", Resource.TaxLabel);
					break;
				case 2:
					textBox.Value = string.Format("Total {0}-Applicable Purchases", Resource.TaxLabel);
					break;
			}
		}

		private void AmountGrossHeader_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("Gross (ex {0})", Resource.TaxLabel);
		}

		private void TaxHeader_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("Gross {0}", Resource.TaxLabel);
		}

		private void CommissionTaxHeader_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("Comm {0}", Resource.TaxLabel);
		}

		private void AmountNetHeader_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("Net (ex {0})", Resource.TaxLabel);
		}

		private void TaxNetHeader_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("Net {0}", Resource.TaxLabel);
		}

		private void Total_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			if (textBox.Value == null)
				textBox.Value = string.Format("{0:c2}", 0);
		}
	}
}