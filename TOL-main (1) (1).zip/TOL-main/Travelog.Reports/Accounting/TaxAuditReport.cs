using System;
using System.Globalization;
using Telerik.Reporting;
using Travelog.Biz.Resources;

namespace Travelog.Reports.Accounting {
	public partial class TaxAuditReport : TelerikReport {
		private string CountryCode { get; set; }
		private string SalesTaxAccountCode { get; set; }
		private decimal SalesTaxAccountValue { get; set; }
		private string PurchasesTaxAccountCode { get; set; }
		private decimal PurchasesTaxAccountValue { get; set; }

		private string AmountGrossTotalValue1;
		private string NonCommissionableTotalValue1;
		private string TaxTotalValue1;
		private string AmountNetTotalValue1;
		private string TaxNetTotalValue1;

		private string AmountGrossTotalValue2;
		private string NonCommissionableTotalValue2;
		private string TaxTotalValue2;
		private string AmountNetTotalValue2;
		private string TaxNetTotalValue2;

		private string AmountGrossTotalValue3;
		private string TaxTotalValue3;

		private string AmountGrossTotalValue4;
		private string AmountGrossTotalValue5;

		private decimal TaxSalesPurchases;

		public TaxAuditReport() {
			InitializeComponent();
			ItemDataBinding += Report_ItemDataBinding;
		}

		private void Report_ItemDataBinding(object sender, EventArgs e) {
			var report = sender as Telerik.Reporting.Processing.Report;
			CountryCode = report.Parameters["countryCode"].Value.ToString();
			SalesTaxAccountCode = report.Parameters["salesTaxAccountCode"].Value.ToString();
			SalesTaxAccountValue = decimal.Parse(report.Parameters["salesTaxAccountValue"].Value.ToString());
			PurchasesTaxAccountCode = report.Parameters["purchasesTaxAccountCode"].Value.ToString();
			PurchasesTaxAccountValue = decimal.Parse(report.Parameters["purchasesTaxAccountValue"].Value.ToString());
		}

		private void Label_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			string label = textBox.Value.ToString().Replace("Tax", Resource.TaxLabel);

			switch (textBox.Name) {
				case "ReconciliationLabel1":
					label = label.Replace("[0]", "[1A]").Replace("[1]", "[1B]");

					if (TaxSalesPurchases > 0) {
						label += " To Pay";
					}
					else if (TaxSalesPurchases < 0) {
						label += " Refund";
					}

					break;
				case "ReconciliationLabel2":
					label = label.Replace("[0]", string.Format("[{0}]", SalesTaxAccountCode)).Replace("[1]", string.Format("[{0}]", PurchasesTaxAccountCode));

					decimal amount = SalesTaxAccountValue + PurchasesTaxAccountValue;

					if (amount > 0) {
						label += " Refund";
					}
					else if (amount < 0) {
						label += " To Pay";
					}

					break;
			}

			if (CountryCode == "AUS") {
				switch (textBox.Name) {
					case "TaxExemptSalesLabel1":
						label = string.Format("{0} [G2]", label);
						break;
					case "TaxExemptSalesLabel2":
						label = string.Format("{0} [G3]", label);
						break;
					case "TotalSalesLabel":
						label = string.Format("{0} [G1]", label);
						break;
					case "TotalTaxSalesLabel":
						label = string.Format("{0} [1A]", label);
						break;
					case "TotalPurchasesAndCostOfSalesLabel":
						label = string.Format("{0} [G11]", label);
						break;
					case "TotalTaxPurchasesLabel":
						label = string.Format("{0} [1B]", label);
						break;
					case "SalaryWagesLabel1":
						label = string.Format("{0} [W1]", label);
						break;
					case "SalaryWagesLabel2":
						label = string.Format("{0} [W2]", label);
						break;
				}
			}
			else if (CountryCode == "NZL") {
				switch (textBox.Name) {
					case "TaxApplicableSalesLabel3":
						label = string.Format("{0} [Box 8]", label);
						break;
					case "TaxApplicableSalesLabel4":
						label = string.Format("{0} [Box 7]", label);
						break;
					case "TaxExemptSalesLabel3":
						label = string.Format("{0} [Box 6]", label);
						break;
					case "TotalSalesLabel":
						label = string.Format("{0} [Box 5]", label);
						break;
					case "TotalTaxSalesLabel":
						label = string.Format("{0} [Box 11]", label);
						break;
					case "TotalPurchasesAndCostOfSalesLabel":
						label = string.Format("{0} [Box 12]", label);
						break;
					case "TotalTaxPurchasesLabel":
						label = string.Format("{0} [Box 13]", label);
						break;
				}
			}

			textBox.Value = label;
		}

		private void TaxAuditReportSubReport1_ItemDataBound(object sender, EventArgs e) {
			var subReport = (Telerik.Reporting.Processing.SubReport)sender;

			var amountGrossTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "AmountGrossTotal", true)[0];
			var nonCommissionableTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "NonCommissionableTotal", true)[0];
			var taxTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "TaxTotal", true)[0];

			var amountNetTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "AmountNetTotal", true)[0];
			var taxNetTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "TaxNetTotal", true)[0];

			AmountGrossTotalValue1 = amountGrossTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : amountGrossTotal.Text;
			NonCommissionableTotalValue1 = nonCommissionableTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : nonCommissionableTotal.Text;
			TaxTotalValue1 = taxTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : taxTotal.Text;

			AmountNetTotalValue1 = amountNetTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : amountNetTotal.Text;
			TaxNetTotalValue1 = taxNetTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : taxNetTotal.Text;
		}

		private void TaxAuditReportSubReport2_ItemDataBound(object sender, EventArgs e) {
			var subReport = (Telerik.Reporting.Processing.SubReport)sender;

			var amountGrossTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "AmountGrossTotal", true)[0];
			var nonCommissionableTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "NonCommissionableTotal", true)[0];
			var taxTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "TaxTotal", true)[0];

			var amountNetTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "AmountNetTotal", true)[0];
			var taxNetTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "TaxNetTotal", true)[0];

			AmountGrossTotalValue2 = amountGrossTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : amountGrossTotal.Text;
			NonCommissionableTotalValue2 = nonCommissionableTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : nonCommissionableTotal.Text;
			TaxTotalValue2 = taxTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : taxTotal.Text;

			AmountNetTotalValue2 = amountNetTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : amountNetTotal.Text;
			TaxNetTotalValue2 = taxNetTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : taxNetTotal.Text;

			decimal.TryParse(taxTotal.Value.ToString(), NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount1);
			decimal.TryParse(taxNetTotal.Value.ToString(), NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount2);

			TaxSalesPurchases += amount1 - amount2;
		}

		private void TaxAuditReportSubReport3_ItemDataBound(object sender, EventArgs e) {
			var subReport = (Telerik.Reporting.Processing.SubReport)sender;
			var amountGrossTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "AmountGrossTotal", true)[0];
			var taxTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "TaxTotal", true)[0];

			AmountGrossTotalValue3 = amountGrossTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : amountGrossTotal.Text;
			TaxTotalValue3 = taxTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : taxTotal.Text;

			decimal.TryParse(taxTotal.Value.ToString(), NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount);
			TaxSalesPurchases -= amount;
		}

		private void TaxAuditReportSubReport4_ItemDataBound(object sender, EventArgs e) {
			var subReport = (Telerik.Reporting.Processing.SubReport)sender;
			var amountGrossTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "AmountGrossGrandTotal", true)[0];
			AmountGrossTotalValue4 = amountGrossTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : amountGrossTotal.Text;
		}

		private void TaxAuditReportSubReport5_ItemDataBound(object sender, EventArgs e) {
			var subReport = (Telerik.Reporting.Processing.SubReport)sender;
			var amountGrossTotal = (Telerik.Reporting.Processing.TextBox)Telerik.Reporting.Processing.ElementTreeHelper.FindChildByName(subReport.InnerReport, "AmountGrossGrandTotal", true)[0];
			AmountGrossTotalValue5 = amountGrossTotal.Text.Length == 0 ? string.Format("{0:c2}", 0) : amountGrossTotal.Text;
		}

		private void TaxApplicableSales1_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = AmountGrossTotalValue2;
		}

		private void TaxApplicableSales2_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = NonCommissionableTotalValue2;
		}

		private void TaxApplicableSales3_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = TaxTotalValue2;
		}

		private void TaxApplicableSales4_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			decimal.TryParse(AmountGrossTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount1);
			decimal.TryParse(TaxTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount2);
			decimal.TryParse(NonCommissionableTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount3);

			textBox.Value = amount1 + amount2 + amount3;
		}

		private void TaxExemptSales1_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = AmountGrossTotalValue1;
		}

		private void TaxExemptSales2_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = NonCommissionableTotalValue1;
		}

		private void TaxExemptSales3_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			decimal.TryParse(AmountGrossTotalValue1, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount1);
			decimal.TryParse(NonCommissionableTotalValue1, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount2);

			textBox.Value = amount1 + amount2;
		}

		private void TotalSales_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			decimal.TryParse(AmountGrossTotalValue1, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount1);
			decimal.TryParse(AmountGrossTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount2);
			decimal.TryParse(TaxTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount3);
			decimal.TryParse(NonCommissionableTotalValue1, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount4);
			decimal.TryParse(NonCommissionableTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount5);

			textBox.Value = amount1 + amount2 + amount3 + amount4 + amount5;
		}

		private void CostOfSales1_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			decimal.TryParse(AmountNetTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount);
			textBox.Value = amount;
		}

		private void CostOfSales2_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			decimal.TryParse(TaxNetTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount);
			textBox.Value = amount;
		}

		private void CostOfSales3_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			decimal.TryParse(AmountNetTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount1);
			decimal.TryParse(TaxNetTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount2);

			textBox.Value = amount1 + amount2;
		}

		private void CostOfSales4_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = AmountNetTotalValue1;
		}

		private void CostOfSales5_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			decimal.TryParse(AmountNetTotalValue1, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount1);
			decimal.TryParse(AmountNetTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount2);
			decimal.TryParse(TaxNetTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount3);

			textBox.Value = amount1 + amount2 + amount3;
		}

		private void TaxApplicablePurchases1_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = AmountGrossTotalValue3;
		}

		private void TaxApplicablePurchases2_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = TaxTotalValue3;
		}

		private void TaxApplicablePurchases3_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			decimal.TryParse(AmountGrossTotalValue3, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount1);
			decimal.TryParse(TaxTotalValue3, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount2);

			textBox.Value = amount1 + amount2;
		}

		private void TotalCostOfSalesAndPurchases_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			decimal.TryParse(AmountNetTotalValue1, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount1);
			decimal.TryParse(AmountNetTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount2);
			decimal.TryParse(AmountGrossTotalValue3, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount3);
			decimal.TryParse(TaxNetTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount4);
			decimal.TryParse(TaxTotalValue3, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount5);

			textBox.Value = amount1 + amount2 + amount3 + amount4 + amount5;
		}

		private void TotalTaxSales_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = TaxTotalValue2;
		}

		private void TotalTaxPurchases_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			decimal.TryParse(TaxNetTotalValue2, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount1);
			decimal.TryParse(TaxTotalValue3, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount2);

			textBox.Value = amount1 + amount2;
		}

		private void SalaryWages1_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			decimal.TryParse(AmountGrossTotalValue4, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount);
			textBox.Value = amount;
		}

		private void SalaryWages2_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			decimal.TryParse(AmountGrossTotalValue5, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal amount);
			textBox.Value = amount;
		}

		private void Reconciliation1_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = Math.Abs(TaxSalesPurchases);
		}

		private void Reconciliation2_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = Math.Abs(SalesTaxAccountValue + PurchasesTaxAccountValue);
		}

		private void Reconciliation3_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = Math.Abs(TaxSalesPurchases + SalesTaxAccountValue + PurchasesTaxAccountValue);
		}
	}
}