﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;
using Travelog.Biz.Resources;
using Travelog.Reports.DebtorLedger;

namespace Travelog.Reports.Accounting {
	public class AccountingDataSources {
		private const string ClassName = "Travelog.Reports.Accounting.AccountingDataSources";

		public List<TransactionDetailReportModel> TransactionDetailReport(int customerId, int agencyId, int tripId, int debtorId, int creditorId, int chartOfAccountId, string transactionDetailIds = null) {
			try {
				if (tripId <= 0 && debtorId <= 0 && creditorId <= 0 && chartOfAccountId <= 0 && string.IsNullOrEmpty(transactionDetailIds))
					return new List<TransactionDetailReportModel>();

				using (var lazyContext = new AppLazyContext(customerId, true)) {
					var q = lazyContext.TransactionDetail.Where(t => t.Id > 0);

					if (tripId > 0) {
						q = q.Where(t => t.LedgerType == LedgerType.ClientLedger && t.TripId == tripId);

						if (agencyId > 0)
							q = q.Where(t => t.Trip.AgencyId == agencyId);
					}

					if (debtorId > 0) {
						q = q.Where(t => t.LedgerType == LedgerType.DebtorLedger && t.DebtorId == debtorId);

						if (agencyId > 0)
							q = q.Where(t => t.AgencyId == agencyId);
					}

					if (creditorId > 0) {
						q = q.Where(t => t.LedgerType == LedgerType.CreditorLedger && t.CreditorId == creditorId);

						if (agencyId > 0)
							q = q.Where(t => t.AgencyId == agencyId);
					}

					if (chartOfAccountId > 0) {
						q = q.Where(t => t.LedgerType == LedgerType.GeneralLedger && t.ChartOfAccountId == chartOfAccountId);

						if (agencyId > 0)
							q = q.Where(t => t.AgencyId == agencyId);
					}

					if (!string.IsNullOrEmpty(transactionDetailIds)) {
						var ids = transactionDetailIds.Split(',').Select(long.Parse).ToArray();
						q = q.Where(t => ids.Contains(t.Id));
					}

					return q.OrderByDescending(t => t.Id).GroupBy(row => new {
						row.Transaction.EffectiveTransactionType,
						row.Transaction.DocumentType,
						row.Transaction.DocumentDate,
						row.Transaction.DocumentNo,
						row.Reference,
						row.Description,
						row.Trip,
						SignType = row.SignType.ToString()
					}).ToList().ConvertAll(row => new TransactionDetailReportModel {
						TransactionType = row.Key.EffectiveTransactionType.GetEnumDescription(),
						DocumentType = row.Key.DocumentType,
						DocumentDate = row.Key.DocumentDate,
						DocumentNo = row.Key.DocumentNo,
						Reference = row.Key.Reference,
						Description = row.Key.Description,
						SignType = row.Key.SignType,
						AmountGross = row.Sum(t => t.Amount + t.Tax)
					});
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "TransactionDetailReport", ex, customerId);
				return new List<TransactionDetailReportModel>();
			}
		}

		public List<BankStatementReconciliationReportModel> BankStatementReconciliationReport(int customerId, int ledgerDocumentTypeId, int bankAccountId, int statementNoFrom, int statementNoTo, DateTime periodTo, bool descendingDateOrder, bool unreconciledOnly) {
			try {
				using (var lazyContext = new AppLazyContext(customerId, true)) {
					var ledgerDocumentType = (LedgerDocumentType)ledgerDocumentTypeId;
					var bankReconciliationReportType = ledgerDocumentType == LedgerDocumentType.Standard ? BankReconciliationReportType.BankStatement : ledgerDocumentType == LedgerDocumentType.StandardDetail ? BankReconciliationReportType.CashBook : BankReconciliationReportType.Reconciliation;
					bool isReconciliation = bankReconciliationReportType == BankReconciliationReportType.Reconciliation;

					var q = lazyContext.BankAccountStatementView.Where(t => t.BankAccountId == bankAccountId && t.StatementNo >= statementNoFrom && t.StatementNo <= statementNoTo).ToList().ConvertAll(row => new BankStatementReconciliationReportModel {
						StatementId = row.Id,
						StatementNo = row.StatementNo,
						StatementOpeningBalance = row.OpeningBalance,
						StatementClosingBalance = row.ClosingBalance,
						StatementOpeningDate = row.OpeningDate,
						StatementClosingDate = row.ClosingDate,
						BankAccountId = row.BankAccountId,
						BankAccountName = row.BankAccountName,
						BankAccountBranch = row.BankAccountBranch,
						BankAccountNo = row.BankAccountNo,
						BankAccountDescription = row.BankAccountDescription,
						BankChartOfAccountId = row.BankChartOfAccountId,
						BankOpeningBalance = row.BankOpeningBalance,
						StatementAmountArchived = row.AmountArchived,
						GeneralLedgerAccount = string.Format("{0}: {1}", row.BankChartOfAccountCode, row.BankChartOfAccountName),
						BankStatementReconciliationDetailReportList = BankReconciliation.GetBankReconciliationQuery(lazyContext, row.BankAccountId, row.Id, TransactionType.All, isReconciliation ? DocumentStatus.Closed : DocumentStatus.None, bankReconciliationReportType, null, row.ClosingDate.AddDays(1).AddTicks(-1), null, null, null, descendingDateOrder).AsEnumerable().Where(t => (isReconciliation || t.StatementDocumentStatusDescription.Length > 0) && (t.Credit ?? 0) - (t.Debit ?? 0) != 0).ToList().ConvertAll(t1 => new BankStatementReconciliationDetailReportModel {
							GroupHeaderDescription = isReconciliation ? "¶" : string.Format("{0}{1}", bankReconciliationReportType == BankReconciliationReportType.BankStatement ? t1.TransactionType == TransactionType.Receipt ? "Plus: " : "Less: " : t1.TransactionType == TransactionType.Receipt ? "Less: " : "Plus: ", t1.StatementDocumentStatusDescription),
							GroupFooterDescription = isReconciliation ? "¶" : string.Format("{0} Total", t1.StatementDocumentStatusDescription),
							DocumentNo = t1.TransactionType == TransactionType.Receipt && !t1.Receipt.IsDeposit ? string.Format("{0} [{1}]", t1.DocumentNo, t1.FormOfPayment.FormOfPaymentCrs.SingleOrDefault(t2 => t2.Crs == Crs.NotSpecified)?.CrsCode).TrimEnd("[]") : t1.DocumentNo,
							DocumentDate = t1.DocumentDate == DateTime.MinValue ? (DateTime?)null : t1.DocumentDate,
							Description = t1.TransactionType == TransactionType.Receipt ? t1.Receipt.AccountName : t1.Payment.Payee.Length == 0 ? t1.Payment.AccountName : t1.Payment.Payee,
							Debit = t1.Debit,
							Credit = t1.Credit
						})
					});

					decimal? nextStatementOpeningBalance = null;

					foreach (var row in q) {
						int i = 0;

						if (isReconciliation) {
							if (ledgerDocumentType == LedgerDocumentType.ReconciliationDetail)
								nextStatementOpeningBalance = row.StatementOpeningBalance;

							if (row.StatementAmountArchived != 0) {
								row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
									Description = "Statement Amount Archived",
									DocumentDate = row.StatementOpeningDate == DateTime.MinValue ? (DateTime?)null : row.StatementOpeningDate,
									Debit = null,
									Credit = row.StatementAmountArchived
								});

								i++;
							}

							row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
								Description = "Statement Opening Balance",
								DocumentDate = row.StatementOpeningDate == DateTime.MinValue ? (DateTime?)null : row.StatementOpeningDate,
								Debit = null,
								Credit = row.StatementOpeningBalance
							});

							i++;

							/*row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
								Description = "Statement Closing Balance",
								DocumentDate = row.StatementClosingDate == DateTime.MinValue ? (DateTime?)null : row.StatementClosingDate,
								Debit = row.StatementClosingBalance,
								Credit = null
							});

							i++;
                            row.ExpectedBalance = row.BankStatementReconciliationDetailReportList.Where(t => t.Description != "Statement Closing Balance").Sum(t => (t.Credit ?? 0) - (t.Debit ?? 0));
							row.UnreconciledAmount = row.BankStatementReconciliationDetailReportList.Sum(t => (t.Credit ?? 0) - (t.Debit ?? 0));*/

							row.ExpectedBalance = row.BankStatementReconciliationDetailReportList.Sum(t => (t.Credit ?? 0) - (t.Debit ?? 0));
							row.UnreconciledAmount = row.BankStatementReconciliationDetailReportList.Sum(t => (t.Credit ?? 0) - (t.Debit ?? 0)) - row.StatementClosingBalance;
						}
						else {
							decimal expectedGlBalance = 0;
							DateTime? dateTo = null;

							var settingDetail = lazyContext.SettingDetail.OrderBy(t => t.FiscalPeriodEndDate).FirstOrDefault(t => t.FiscalPeriodEndDate >= periodTo);

							if (settingDetail != null)
								dateTo = settingDetail.FiscalPeriodEndDate.AddDays(1).AddTicks(-1);

							if (ledgerDocumentType == LedgerDocumentType.StandardDetail) {
								row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
									Description = "Opening Bank Balance",
									DocumentDate = row.StatementClosingDate == DateTime.MinValue ? (DateTime?)null : row.StatementClosingDate,
									Debit = null,
									Credit = row.BankOpeningBalance
								});

								i++;
								decimal totalReceipts = BankReconciliation.GetBankReconciliationQuery(lazyContext, row.BankAccountId, 0, TransactionType.Receipt, DocumentStatus.None, BankReconciliationReportType.Reconciliation, null, dateTo).Where(t => t.FormOfPayment.DebtorId <= 0).AsEnumerable().Sum(t => t.Credit) ?? 0;

								row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
									Description = "Total Receipts",
									DocumentDate = (dateTo ?? DateTime.MinValue) == DateTime.MinValue ? (DateTime?)null : ((DateTime)dateTo).Date,
									Debit = null,
									Credit = totalReceipts
								});

								i++;
								decimal totalPayments = BankReconciliation.GetBankReconciliationQuery(lazyContext, row.BankAccountId, 0, TransactionType.Payment, DocumentStatus.None, BankReconciliationReportType.Reconciliation, null, dateTo).Where(t => t.FormOfPayment.DebtorId <= 0).AsEnumerable().Sum(t => t.Debit) ?? 0;

								row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
									Description = "Total Payments",
									DocumentDate = (dateTo ?? DateTime.MinValue) == DateTime.MinValue ? (DateTime?)null : ((DateTime)dateTo).Date,
									Debit = totalPayments,
									Credit = null
								});

								i++;

								row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
									Description = string.Empty,
									DocumentNo = "¶",
									DocumentDate = null,
									Debit = null,
									Credit = null
								});

								i++;

								row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
									DocumentNo = "Reconciliation",
									DocumentDate = null,
									Debit = null,
									Credit = null
								});

								i++;
								expectedGlBalance = row.BankOpeningBalance + totalReceipts - totalPayments;

								row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
									Description = "Expected General Ledger Account Balance",
									DocumentDate = (dateTo ?? DateTime.MinValue) == DateTime.MinValue ? (DateTime?)null : ((DateTime)dateTo).Date,
									Debit = null,
									Credit = expectedGlBalance
								});

								i++;
							}
							else {
								row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
									Description = "Statement Closing Balance",
									DocumentDate = row.StatementClosingDate == DateTime.MinValue ? (DateTime?)null : row.StatementClosingDate,
									Debit = null,
									Credit = row.StatementClosingBalance
								});

								i++;
							}

							decimal glBalance = lazyContext.TransactionDetail.Where(t => t.LedgerType == LedgerType.GeneralLedger && t.ChartOfAccountId == row.BankChartOfAccountId && t.Transaction.DocumentDate <= row.StatementClosingDate).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;

							row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
								Description = ledgerDocumentType == LedgerDocumentType.StandardDetail ? "Actual General Ledger Account Balance" : "General Ledger Account Balance",
								DocumentDate = row.StatementClosingDate,
								Debit = ledgerDocumentType == LedgerDocumentType.StandardDetail ? (decimal?)null : glBalance,
								Credit = ledgerDocumentType == LedgerDocumentType.StandardDetail ? glBalance : (decimal?)null
							});

							i++;

							if (ledgerDocumentType == LedgerDocumentType.StandardDetail) {
								row.BankStatementReconciliationDetailReportList.Insert(i, new BankStatementReconciliationDetailReportModel {
									Description = "Variance",
									DocumentDate = null,
									Debit = null,
									Credit = expectedGlBalance - glBalance
								});

								row.BankStatementReconciliationDetailReportList.Add(new BankStatementReconciliationDetailReportModel {
									GroupHeaderDescription = "¶",
									DocumentNo = "Reconciliation",
									DocumentDate = null,
									Debit = null,
									Credit = null
								});

								decimal reconciledStatementBalance = expectedGlBalance + row.BankStatementReconciliationDetailReportList.Where(t => !string.IsNullOrEmpty(t.DocumentNo)).Sum(t => (t.Debit ?? 0) - (t.Credit ?? 0));

								row.BankStatementReconciliationDetailReportList.Add(new BankStatementReconciliationDetailReportModel {
									GroupHeaderDescription = "¶",
									Description = "Expected Statement Closing Balance",
									DocumentDate = (dateTo ?? DateTime.MinValue) == DateTime.MinValue ? (DateTime?)null : ((DateTime)dateTo).Date,
									Debit = null,
									Credit = reconciledStatementBalance
								});

								row.BankStatementReconciliationDetailReportList.Add(new BankStatementReconciliationDetailReportModel {
									GroupHeaderDescription = "¶",
									Description = "Actual Statement Closing Balance",
									DocumentDate = row.StatementClosingDate == DateTime.MinValue ? (DateTime?)null : row.StatementClosingDate,
									Debit = null,
									Credit = row.StatementClosingBalance
								});

								row.BankStatementReconciliationDetailReportList.Add(new BankStatementReconciliationDetailReportModel {
									GroupHeaderDescription = "¶",
									Description = "Variance",
									DocumentDate = null,
									Debit = null,
									Credit = reconciledStatementBalance - row.StatementClosingBalance
								});
							}

							row.ExpectedBalance = row.BankStatementReconciliationDetailReportList.Where(t => t.Description != "General Ledger Account Balance").Sum(t => (t.Credit ?? 0) - (t.Debit ?? 0));
							row.UnreconciledAmount = row.BankStatementReconciliationDetailReportList.Sum(t => (t.Credit ?? 0) - (t.Debit ?? 0));
						}
					}

					if (isReconciliation && unreconciledOnly)
						q = q.Where(t => t.UnreconciledAmount != 0).ToList();

					return q;
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "BankStatementReconciliationReport", ex, customerId);
				return new List<BankStatementReconciliationReportModel>();
			}
		}

		public ReceiptReportModel ReceiptReport(int customerId, string userName, int receiptId, string documentNo, int agencyId) {
			try {
				using (var lazyContext = new AppLazyContext(customerId, true)) {
					Receipt receipt;
					List<ReceiptDetail> receiptDetails;
					List<ReceiptDetailReportModel> receiptDetailReportList;

					var agency = lazyContext.Agency.Find(agencyId);

					string consultant;
					string standardComment;
					bool isCustomer;

					if (CustomerSettings.Setting(customerId).IsManagementCustomer) {
						receiptDetails = lazyContext.ReceiptDetail.Where(t => t.ReceiptId == receiptId).ToList();

						if (receiptDetails.Count == 0)
							return new ReceiptReportModel();

						receipt = receiptDetails[0].Receipt;
						consultant = Utils.GetIssuedBy(new Consultant(), userName, receipt.Debtor.CustomerId);
						standardComment = string.Empty;
						isCustomer = true;

						receiptDetailReportList = receiptDetails.ConvertAll(row => new ReceiptDetailReportModel {
							IsDebtor = true,
							AccountName = row.Receipt.AccountName,
							FormOfPayment = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name,
                            TripLine = row.DocumentReferences.Length == 0 ? "Payment" : row.DocumentReferences,
                            Comments = string.Join(AppConstants.HtmlLineBreak, row.TransactionDetailAllocations.Where(t => t.TransactionDetail.InvoiceDetailId > 0 && t.TransactionDetail.InvoiceDetail.Description.Length > 0).Select(t => t.TransactionDetail.InvoiceDetail.Description)),
							Amount = row.Amount,
							IsCustomer = true,
						});
					}
					else {
                        receipt = lazyContext.Receipt.Find(receiptId);

                        if (receipt == null)
                            return new ReceiptReportModel();

                        receiptDetails = lazyContext.ReceiptDetail.Where(t => t.ReceiptId == receiptId || (t.Receipt.ReceiptType == receipt.ReceiptType && t.Receipt.IsSplit && t.Receipt.DocumentNo == documentNo)).ToList();

						if (receiptDetails.Count == 0)
							return new ReceiptReportModel();

						consultant = Utils.GetIssuedBy(receipt.Consultant, receipt.CreationUser, customerId);
						standardComment = receipt.StandardComment.Comment;
						isCustomer = receipt.Debtor.CustomerId != 0;

						receiptDetailReportList = receiptDetails.ConvertAll(row => new ReceiptDetailReportModel {
							IsDebtor = row.Receipt.DebtorId > 0,
							AccountName = row.Receipt.AccountName,
							TripLine = row.Receipt.Debtor.CustomerId != 0 && row.DocumentReferences.Length > 0 ? string.Format("Invoice No(s) {0}", row.DocumentReferences.Replace("Invoice No ", string.Empty).Replace(Environment.NewLine, ", "))
								: row.TripLineId > 0 ? row.TripLine.Description
								: row.Receipt.AccountType == AccountType.Debtor && row.Receipt.TripId > 0 && row.Receipt.Trip.AccountName != row.Receipt.AccountName ? row.Receipt.Trip.AccountName
								: row.Receipt.ChartOfAccountId > 0 && row.Receipt.ChartOfAccount.AccountName != row.Receipt.AccountName ? row.Receipt.ChartOfAccount.AccountName
								: string.Empty,
							Reference = row.Receipt.Debtor.CustomerId != 0 ? string.Empty : row.Receipt.DebtorId > 0 ? row.DocumentReferences : row.PassengerId > 0 ? row.Passenger.FullName : row.TripLineAirPassengerId > 0 ? row.TripLineAirPassenger.Passenger.FullName : string.Empty,
							FormOfPayment = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name,
							Comments = row.Receipt.Debtor.CustomerId != 0 ? string.Join(AppConstants.HtmlLineBreak, row.TransactionDetailAllocations.Where(t => t.TransactionDetail.InvoiceDetailId > 0 && t.TransactionDetail.InvoiceDetail.Description.Length > 0).Select(t => t.TransactionDetail.InvoiceDetail.Description))
								: Utils.HtmlEncodeExceptTags(string.Format("{1}{0}{2}", AppConstants.HtmlLineBreak, row.LoyaltySchemeId <= 0 || row.LoyaltyScheme.LoyaltySchemeExcludeOnReceipt ? string.Empty : string.Format("Loyalty Scheme: {0}; Reference: {1}; Points: {2}; Value: {3:c2}", row.LoyaltyScheme.Name, row.LoyaltySchemeReference.Length == 0 ? "None" : row.LoyaltySchemeReference, row.LoyaltySchemePointsCollected, row.LoyaltySchemeValue), row.Comments).TrimStart(AppConstants.HtmlLineBreak).TrimEnd(AppConstants.HtmlLineBreak)),
							Amount = row.Amount,
							IsCustomer = row.Receipt.Debtor.CustomerId != 0,
						});
					}

					return new ReceiptReportModel {
						ReceiptType = receipt.ReceiptType.ToString(),
						TaxNo = agency.TaxNo,
						Consultant = consultant,
						DocumentNo = receipt.DocumentNo,
						DocumentDate = receipt.DocumentDate,
						TotalAmount = receiptDetails.Sum(t => t.Amount),
						TotalTax = receiptDetails.Sum(t => t.Tax),
						DocumentTotal = receiptDetails.Sum(t => t.Amount + t.Tax),
						StandardComment = standardComment,
						IsCustomer = isCustomer,
						ReceiptDetailReportList = receiptDetailReportList
					};
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "ReceiptReport", ex, customerId, userName);
				return new ReceiptReportModel();
			}
		}

		public ReceiptBankDepositReportModel ReceiptBankDepositReport(int customerId, int agencyId, DateTime depositDate, int bankAccountId, int receiptId, string receiptDetailIds) {
			try {
				using (var lazyContext = new AppLazyContext(customerId, true)) {
					IQueryable<ReceiptDetail> q = null;
					BankAccount bankAccount = null;

					if (receiptId > 0) {
						var receiptDetail = lazyContext.ReceiptDetail.Include(t => t.Receipt).ThenInclude(t => t.BankAccount).Single(t => t.ReceiptId == receiptId);
						q = lazyContext.ReceiptDetail.Include(t => t.Receipt).Include(t => t.FormOfPayment).Include(t => t.PaymentMethod).Where(t => t.DepositDetailId == receiptDetail.Id);

						if (!q.Any())
							return new ReceiptBankDepositReportModel();

						bankAccount = receiptDetail.Receipt.BankAccount;
					}
					else {
						q = lazyContext.ReceiptDetail.Include(t => t.Receipt).Include(t => t.FormOfPayment).Include(t => t.PaymentMethod).Where(t => t.FormOfPayment.IncludeInDeposit);
						var arrays = receiptDetailIds.Split(',').Select(int.Parse).ToArray().Split(2100).ToArray();

						var predicate = PredicateBuilder.False<ReceiptDetail>();

						foreach (var array in arrays) {
							predicate = predicate.Or(t => array.Contains(t.Id));
						}

						q = q.Where(predicate);

						if (!q.Any())
							return new ReceiptBankDepositReportModel();

						bankAccount = lazyContext.BankAccount.Find(bankAccountId);
					}

					return new ReceiptBankDepositReportModel {
						Agency = lazyContext.Agency.Find(agencyId).Name,
						DepositDate = string.Format(depositDate.Hour == 0 && depositDate.Minute == 0 ? "{0:dd-MMM-yyyy}" : "{0:dd-MMM-yyyy HH:mm}", depositDate),
						BankAccountName = bankAccount.Name,
						BankAccountBranch = bankAccount.Branch,
						BankAccountNo = bankAccount.AccountNo,
						ReceiptDetailBankDepositReportList = q.ToList().ConvertAll(row => new ReceiptDetailBankDepositReportModel {
							DocumentNo = row.Receipt.DocumentNo,
							DocumentDate = row.Receipt.DocumentDate,
							FormOfPaymentType = row.FormOfPayment.FormOfPaymentType.GetEnumDescription(),
							AccountName = row.Receipt.AccountName,
							PaymentDetails = row.PaymentMethodId <= 0 ? row.FormOfPayment.Name : string.Format("Account No: {0} | {1} | {2} | {3}", row.PaymentMethod.AccountNo, row.PaymentMethod.PaymentDetails1, row.PaymentMethod.PaymentDetails2, row.PaymentMethod.PaymentDetails3).TrimStart("Account No: ").TrimEnd(" | "),
							Amount = row.Amount + row.Tax
						})
					};
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "ReceiptBankDepositReport", ex, customerId);
				return new ReceiptBankDepositReportModel();
			}
		}

		public InvoiceReportModel InvoiceReport(int customerId, int id, int agencyId, string issuedDocumentType, int quoteNo, string tripLineIds, string passengerIds, DateTime today) {
			try {
				issuedDocumentType = issuedDocumentType == "CreditNote" ? "Invoice" : issuedDocumentType;
				var issuedDocumentTypeValue = (IssuedDocumentType)Enum.Parse(typeof(IssuedDocumentType), issuedDocumentType, true);

				if (issuedDocumentTypeValue != IssuedDocumentType.Invoice && issuedDocumentTypeValue != IssuedDocumentType.ClientStatement && issuedDocumentTypeValue != IssuedDocumentType.PersonalStatement)
					throw new InvalidOperationException("Invalid Document Type.");

				using (var lazyContext = new AppLazyContext(customerId, true)) {
					List<InvoiceDetailReportModel> invoiceDetailReportList = null;
					IEnumerable<TripLineAirPassenger> tripLineAirPassengers = null;

					var paymentScheduleReportList = new List<TripPaymentScheduleReportModel>();

					DateTime documentDate = today;
					DateTime departureDate = DateTime.MinValue;
					DateTime dateDue = DateTime.MinValue;

					int[] tripIds = null;

					string documentType = string.Empty;
					string debtorCode = string.Empty;
					string debtor = string.Empty;
					string subDebtor = string.Empty;
					string address = string.Empty;
					string orderNo = string.Empty;
					string documentNo = string.Empty;
					string foreignCurrency = string.Empty;
					string depositDetails = string.Empty;
					string paymentTerms = string.Empty;
					string passengers = string.Empty;
					string contactName = string.Empty;

					decimal packageTotal = 0;
					decimal subTotal = 0;
					decimal totalDiscount = 0;
					decimal totalAgentCommission = 0;
					decimal totalTax = 0;
					decimal totalAmount = 0;
					decimal foreignCurrencyTotalAmount = 0;

					bool packageTaxApplies = false;

					var agency = lazyContext.Agency.Find(agencyId);

					IEnumerable<InvoiceDetailReportModel> invoiceDetailList = null;
					IEnumerable<InvoiceDetailReportModel> paymentDetailList = null;

					if (CustomerSettings.Setting(customerId).IsManagementCustomer) {
						var invoice = lazyContext.Invoice.Find(id);
						var invoiceDetails = invoice.InvoiceDetails.OrderBy(t => t.IsPayment ? 1 : 0).ThenBy(t => t.TripLine.TripLineSelections.OrderBy(t2 => t2.QuoteNo == 0 ? 0 : 1).FirstOrDefault()?.SeqNo ?? 0);

						documentType = invoice.InvoiceType.ToString();
						debtorCode = invoice.Debtor.Code;
						debtor = string.IsNullOrEmpty(invoice.DebtorName) ? invoice.Debtor.Name : invoice.DebtorName;
						subDebtor = "None";
						contactName = invoice.DebtorContactId <= 0 ? string.Empty : invoice.DebtorContact.Name;
						orderNo = string.IsNullOrEmpty(invoice.DebtorOrderNo) ? "None" : invoice.DebtorOrderNo;
						documentNo = invoice.DocumentNo;
						documentDate = invoice.DocumentDate;
						foreignCurrency = invoice.DebtorCurrency.Code;
						dateDue = invoice.BalanceDueDate;
						paymentTerms = invoice.PaymentTerms;

						address = invoice.GetDebtorAddress(lazyContext).Replace(AppConstants.HtmlLineBreak, Environment.NewLine);

						if (string.IsNullOrEmpty(address))
							address = invoice.Debtor.GetAddress(lazyContext).Replace(AppConstants.HtmlLineBreak, Environment.NewLine);

						if (invoice.Deposit != 0)
							depositDetails = string.Format("Amount: {0:c2}{1}{2}", invoice.Deposit, invoice.DepositDueDate > DateTime.MinValue ? string.Format("     Due On: {0:dd-MMM-yyyy}", invoice.DepositDueDate) : string.Empty, invoice.DepositPaidDate > DateTime.MinValue ? string.Format("     Paid On: {0:dd-MMM-yyyy}", invoice.DepositPaidDate) : string.Empty);

						invoiceDetailList = invoice.InvoiceDetails.OrderBy(t => t.IsPayment ? 1 : 0).Select(row => new InvoiceDetailReportModel {
							TripId = -1,
							TripLineId = -1,
							TripLineAirPassengerId = -1,
							ChartOfAccountCode = string.Empty,
							AccountNo = string.Empty,
							Description = row.Description,
							Amount = row.Amount - row.Discount + (row.Invoice.Debtor.IsTaxInInvoiceLineAmount ? row.Tax - row.DiscountTax : 0) + row.PaymentTax,
							Tax = row.Tax - row.DiscountTax + row.PaymentTax,
							Discount = row.Discount + row.DiscountTax,
							AgentCommission = 0,
							IsPayment = false,
							PackageNo = 0
						}).ToList();

						paymentDetailList = new List<InvoiceDetailReportModel>();

						subTotal = invoiceDetailList.Where(t => !t.IsPayment).Sum(t => t.Amount);
						totalTax = invoiceDetailList.Where(t => !t.IsPayment).Sum(t => t.Tax);
						totalAmount = subTotal + totalTax;
						totalDiscount = invoiceDetailList.Where(t => !t.IsPayment).Sum(t => t.Discount);

						totalAmount = subTotal + totalTax;
					}
					else {
						if (issuedDocumentTypeValue == IssuedDocumentType.Invoice) {
							var invoice = lazyContext.Invoice.Find(id);
							var invoiceDetails = invoice.InvoiceDetails.OrderBy(t => t.IsPayment ? 1 : 0).ThenBy(t => t.TripLine.TripLineSelections.OrderBy(t2 => t2.QuoteNo == 0 ? 0 : 1).FirstOrDefault()?.SeqNo ?? 0);

							tripIds = invoiceDetails.Where(t => t.TripLineId > 0).Select(t => t.TripLine.TripId).ToArray();

							documentType = invoice.InvoiceType.ToString();
							debtorCode = invoice.Debtor.Code;
							debtor = string.IsNullOrEmpty(invoice.DebtorName) ? invoice.Debtor.Name : invoice.DebtorName;
							subDebtor = invoice.SubDebtorId <= 0 ? "None" : string.Format("{0}: {1}", invoice.SubDebtor.Code, invoice.SubDebtor.Name);
							contactName = invoice.DebtorContactId <= 0 ? string.Empty : invoice.DebtorContact.Name;
							orderNo = string.IsNullOrEmpty(invoice.DebtorOrderNo) ? "None" : invoice.DebtorOrderNo;
							documentNo = invoice.DocumentNo;
							documentDate = invoice.DocumentDate;
							foreignCurrency = invoice.DebtorCurrency.Code;
							dateDue = invoice.BalanceDueDate == DateTime.MinValue ? invoice.DocumentDate.AddDays(invoice.Debtor.PaymentTerm.Term) : invoice.BalanceDueDate;
							paymentTerms = invoice.PaymentTerms;

							address = invoice.GetDebtorAddress(lazyContext).Replace(AppConstants.HtmlLineBreak, Environment.NewLine);

							if (string.IsNullOrEmpty(address))
								address = invoice.Debtor.GetAddress(lazyContext).Replace(AppConstants.HtmlLineBreak, Environment.NewLine);

							if (invoice.Deposit != 0)
								depositDetails = string.Format("Amount: {0:c2}{1}{2}", invoice.Deposit, invoice.DepositDueDate > DateTime.MinValue ? string.Format("     Due On: {0:dd-MMM-yyyy}", invoice.DepositDueDate) : string.Empty, invoice.DepositPaidDate > DateTime.MinValue ? string.Format("     Paid On: {0:dd-MMM-yyyy}", invoice.DepositPaidDate) : string.Empty);

							invoiceDetailReportList = invoiceDetails.Select(row => new InvoiceDetailReportModel {
								TripId = row.TripLine.Trip.Id,
								TripLineId = row.TripLineId,
								TripLineAirPassengerId = row.TripLineAirPassengerId,
                                TripLineAirPassenger = row.TripLineAirPassenger,
                                TripLineType = row.TripLine.TripLineType,
								ChartOfAccountCode = row.ChartOfAccount.Code,
								AccountNo = row.TripId <= 0 ? string.Empty : row.Trip.TripNo,
								Description = string.IsNullOrEmpty(row.Description) ? row.TripLine.DetailedDescription : row.Description,
								Amount = (row.IsPayment ? -1 : 1) * (row.Amount - row.Discount + (row.Invoice.Debtor.IsTaxInInvoiceLineAmount ? row.Tax - row.DiscountTax : 0) + row.PaymentTax),
								Tax = (row.IsPayment ? -1 : 1) * (row.Tax - row.DiscountTax),
								Discount = row.GetDiscountLessAgentCommission(customerId),
								AgentCommission = row.GetAgentCommission(customerId),
								PersonalTravelAmount = row.TripLine.TripLineType == TripLineType.Air ? row.TripLineAirPassenger.PersonalTravelAmount : row.TripLine.PersonalTravelAmount,
								IsPayment = row.IsPayment,
								PackageNo = 0
							}).ToList();

							foreach (var invoiceDetail in invoiceDetailReportList.Where(t => !t.IsPayment && t.PersonalTravelAmount != 0).ToList()) {
								int index = invoiceDetailReportList.IndexOf(invoiceDetail) + 1;
								invoiceDetail.Amount += invoiceDetail.PersonalTravelAmount;

                                string description = "Personal Amount";

                                if (invoiceDetail.TripLineType == TripLineType.Air && invoiceDetail.TripLineAirPassenger.PassengerId > 0)
                                    description = string.Format("{0}: {1}", description, invoiceDetail.TripLineAirPassenger.Passenger.FullName);
                                
								invoiceDetailReportList.Insert(index, new InvoiceDetailReportModel {
									TripId = invoiceDetail.TripId,
									TripLineId = invoiceDetail.TripLineId,
									TripLineAirPassengerId = invoiceDetail.TripLineAirPassengerId,
									TripLineType = invoiceDetail.TripLineType,
									ChartOfAccountCode = invoiceDetail.ChartOfAccountCode,
									AccountNo = invoiceDetail.AccountNo,
                                    Description = description,
                                    Amount = -invoiceDetail.PersonalTravelAmount,
									Tax = 0,
									Discount = 0,
									AgentCommission = 0,
									PersonalTravelAmount = 0,
									IsPayment = false,
									PackageNo = invoiceDetail.PackageNo
								});
							}

							subTotal = invoiceDetailReportList.Where(t => !t.IsPayment).Sum(t => t.Amount);
							totalDiscount = invoiceDetailReportList.Where(t => !t.IsPayment).Sum(t => t.Discount);
							totalAgentCommission = invoiceDetailReportList.Where(t => !t.IsPayment).Sum(t => t.AgentCommission);
							totalTax = invoiceDetailReportList.Where(t => !t.IsPayment).Sum(t => t.Tax);
							totalAmount = subTotal + totalTax;
							foreignCurrencyTotalAmount = invoice.DebtorExchangeRate == 0 ? 0 : Math.Round(totalAmount * invoice.DebtorExchangeRate, 2);

                            passengers = string.Join(Environment.NewLine, invoice.InvoiceDetails.SelectMany(t => t.InvoiceDetailPassengers).Select(t => t.Passenger.FullName).Distinct()).TrimEnd(Environment.NewLine);
                            tripLineAirPassengers = lazyContext.TripLineAirPassenger.Where(t => tripIds.Contains(t.TripLineAir.TripLine.TripId)).Distinct().ToList();
						}
						else {
							int[] tripLineIdList = null;
							int[] passengerIdList = passengerIds.Split(',').Select(int.Parse).ToArray();

							bool allTripLinesSelected = false;
							var tripLineAllIds = lazyContext.TripLine.Where(t1 => t1.Trip.TripPassengers.Any(t2 => passengerIdList.Contains(t2.Id))).Select(t => t.Id).ToArray();

							if (string.IsNullOrEmpty(tripLineIds) || tripLineIds == "0") {
								tripLineIdList = tripLineAllIds;
								allTripLinesSelected = true;
							}
							else {
								tripLineIdList = tripLineIds.Split(',').Select(int.Parse).ToArray();
								allTripLinesSelected = tripLineAllIds.Length == tripLineIdList.Length;
							}

							var trip = lazyContext.Trip.Find(id);
							var tripLines = lazyContext.TripLine.Where(t1 => t1.TripId == id && t1.TripLineType != TripLineType.Remark && t1.PrintOnStatement && tripLineIdList.Contains(t1.Id) && t1.Trip.TripPassengers.Any(t2 => passengerIdList.Contains(t2.Id))).AsEnumerable();

							if (quoteNo != -1)
								tripLines = tripLines.Where(t1 => t1.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo)).OrderBy(t => t.GetSeqNo(quoteNo));

							if (issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement) {
								tripLines = tripLines.Where(t => t.PersonalTravelAmount != 0);
								allTripLinesSelected = false;
							}

							if (!tripLines.Any()) {
								return new InvoiceReportModel {
									InvoiceDetailReportList = new List<InvoiceDetailReportModel>(),
									PaymentDetailReportList = new List<InvoiceDetailReportModel>()
								};
							}

							tripIds = tripLines.Select(t => t.TripId).ToArray();
							tripLineIdList = tripLines.Select(t => t.Id).ToArray();

							var receiptDetails = lazyContext.ReceiptDetail.Where(t => t.Receipt.TripId == trip.Id).AsEnumerable().GroupBy(t => t.Receipt);
							var bspDetails = lazyContext.BspDetail.Where(t => t.Bsp.TripId == trip.Id).AsEnumerable().GroupBy(t => t.Bsp);
							var nonBspDetails = lazyContext.NonBspDetail.Where(t => t.NonBsp.TripId == trip.Id).AsEnumerable().GroupBy(t => t.NonBsp);
							var paymentDetails = lazyContext.PaymentDetail.Where(t => t.Payment.TripId == trip.Id && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).AsEnumerable().GroupBy(t => t.Payment);
							var invoiceDetails = lazyContext.InvoiceDetail.Where(t => t.TripId == trip.Id && t.Invoice.AccountType == AccountType.Client).AsEnumerable().GroupBy(t => t.Invoice);

							documentType = issuedDocumentTypeValue.ToString();
							debtorCode = string.Empty;
							debtor = trip.FullName;
							subDebtor = string.Empty;
							address = trip.GetAddress(lazyContext).Replace(AppConstants.HtmlLineBreak, Environment.NewLine);
							contactName = trip.Consultant.Name;
							documentNo = string.IsNullOrEmpty(trip.Code) ? trip.TripNo : trip.Code;
							departureDate = trip.DepartureDate;
							dateDue = trip.BalanceDueDate;

							orderNo = string.Join("; ", tripLines.Select(t => t.Trip.DebtorOrderNo).Distinct());

							if (string.IsNullOrEmpty(orderNo))
								orderNo = "None";

							invoiceDetailReportList = tripLines.ToList().ConvertAll(row => new InvoiceDetailReportModel {
								TripLineType = row.TripLineType,
								TripId = row.TripId,
								AccountNo = row.Trip.TripNo,
								Description = row.DetailedDescription,
								Amount = row.Voucher.PaymentClass == PaymentClass.PaidDirect ? 0
									: issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement ? row.PersonalTravelAmount
									: (row.TripLineType == TripLineType.Air ? (row.TripLineAir.TripLineAirPassengers.Sum(t => (decimal?)t.GetCostToClient(customerId, passengerIdList)) ?? 0)
									: row.GetCostToClient()) + row.GetAgentCommission(customerId),

								Tax = row.Voucher.PaymentClass == PaymentClass.PaidDirect ? 0
									: issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement ? (row.TripLineType == TripLineType.Air ? (row.TripLineAir.TripLineAirPassengers.Sum(t => (decimal?)t.GetPersonalTravelAmountTax(customerId, row.StartDate == DateTime.MinValue ? row.Trip.DepartureDate : row.StartDate)) ?? 0) : row.GetPersonalTravelAmountTax(customerId, row.StartDate == DateTime.MinValue ? row.Trip.DepartureDate : row.StartDate))
									: (row.TripLineType == TripLineType.Air ? (row.TripLineAir.TripLineAirPassengers.Sum(t => (decimal?)t.GetCostToClientTax(customerId, row.StartDate == DateTime.MinValue ? row.Trip.DepartureDate : row.StartDate, passengerIdList)) ?? 0) : row.GetCostToClientTax(customerId, row.StartDate == DateTime.MinValue ? row.Trip.DepartureDate : row.StartDate)),

								Discount = issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement ? 0 : row.GetDiscountLessAgentCommission(customerId),
								AgentCommission = row.GetAgentCommission(customerId),
								PackageNo = issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement ? 0 : row.PackageNo,
								PersonalTravelAmount = 0,
								IsDebtor = row.Trip.DebtorId > 0,
								IsPayment = false
							});

							if (issuedDocumentTypeValue != IssuedDocumentType.PersonalStatement) {
								invoiceDetailReportList = invoiceDetailReportList.Concat(invoiceDetails.ToList().ConvertAll(row => new InvoiceDetailReportModel {
									TripLineType = TripLineType.All,
									TripId = row.First().TripId,
									AccountNo = row.First().Trip.TripNo,
									Description = string.Format("{0} No {1}", row.Key.InvoiceType.GetEnumDescription(), row.Key.DocumentNo, row.Key.BalanceDueDate == DateTime.MinValue ? string.Empty : string.Format(": Due on {0}", row.Key.BalanceDueDate.ToShortDateStringExt())),
									Amount = (row.Key.InvoiceType == InvoiceType.CreditNote ? -1 : 1) * (row.Sum(t => (decimal?)(t.Amount + t.Tax - t.Discount - t.DiscountTax)) ?? 0),
									Tax = (row.Key.InvoiceType == InvoiceType.CreditNote ? -1 : 1) * (row.Sum(t => (decimal?)(t.Tax - t.DiscountTax)) ?? 0),
									Discount = 0,
									AgentCommission = 0,
									PackageNo = 0,
									PersonalTravelAmount = 0,
									IsDebtor = true,
									IsPayment = true
								}).Where(t => t.Amount != 0 || t.Tax != 0))
								.Concat(bspDetails.ToList().ConvertAll(row => new InvoiceDetailReportModel {
									TripLineType = TripLineType.All,
									TripId = row.Key.TripId,
									AccountNo = row.Key.Trip.TripNo,
									Description = row.Key.GetFormOfPaymentDetails(),
									Amount = (row.Key.BspType == BspType.Refund || (row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? -1 : 1) * (row.Sum(t => (decimal?)(t.CreditCard + t.CreditCardTax)) ?? 0),
									Tax = (row.Key.BspType == BspType.Refund || (row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? -1 : 1) * (row.Sum(t => (decimal?)t.CreditCardTax) ?? 0),
									Discount = 0,
									AgentCommission = 0,
									PersonalTravelAmount = 0,
									PackageNo = 0,
									IsDebtor = row.Key.Trip.DebtorId > 0,
									IsPayment = true
								}).Where(t => t.Amount != 0 || t.Tax != 0))
								.Concat(nonBspDetails.ToList().ConvertAll(row => new InvoiceDetailReportModel {
									TripLineType = TripLineType.All,
									TripId = row.Key.TripId,
									AccountNo = row.Key.Trip.TripNo,
									Description = row.Key.GetFormOfPaymentDetails(),
									Amount = (row.Key.NonBspType == NonBspType.Refund || (row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? -1 : 1) * (row.Sum(t => (decimal?)(t.CreditCard + t.CreditCardTax)) ?? 0),
									Tax = (row.Key.NonBspType == NonBspType.Refund || (row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? -1 : 1) * (row.Sum(t => (decimal?)t.CreditCardTax) ?? 0),
									Discount = 0,
									AgentCommission = 0,
									PersonalTravelAmount = 0,
									PackageNo = 0,
									IsPayment = true
								}).Where(t => t.Amount != 0 || t.Tax != 0))
								.Concat(paymentDetails.ToList().ConvertAll(row => new InvoiceDetailReportModel {
									TripLineType = TripLineType.All,
									TripId = row.Key.TripId,
									AccountNo = row.Key.Trip.TripNo,
									Description = row.Key.GetFormOfPaymentDetails(),
									Amount = (row.Key.PaymentType == PaymentType.ClientRefund || (row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? -1 : 1) * (row.Sum(t => (decimal?)(t.CreditCard + t.CreditCardTax)) ?? 0),
									Tax = (row.Key.PaymentType == PaymentType.ClientRefund || (row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? -1 : 1) * (row.Sum(t => (decimal?)t.CreditCardTax) ?? 0),
									Discount = 0,
									AgentCommission = 0,
									PersonalTravelAmount = 0,
									PackageNo = 0,
									IsDebtor = row.Key.Trip.DebtorId > 0,
									IsPayment = true
								}).Where(t => t.Amount != 0 || t.Tax != 0)).ToList();
							}

							invoiceDetailReportList = invoiceDetailReportList.Concat(receiptDetails.Select(row => new InvoiceDetailReportModel {
								TripLineType = TripLineType.All,
								TripId = row.Key.TripId,
								AccountNo = row.Key.Trip.TripNo,
								Description = row.Key.GetFormOfPaymentDetails(),
								Amount = (row.Key.ReceiptType == ReceiptType.Refund ? -1 : 1) * (row.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0),
								Tax = (row.Key.ReceiptType == ReceiptType.Refund ? -1 : 1) * (row.Sum(t => (decimal?)t.Tax) ?? 0),
								Discount = 0,
								AgentCommission = 0,
								PersonalTravelAmount = (row.Key.ReceiptType == ReceiptType.Refund ? -1 : 1) * row.Sum(t => (decimal?)t.TripLine.PersonalTravelAmount) ?? 0,
								PackageNo = 0,
								IsDebtor = row.Key.Trip.DebtorId > 0,
								IsPayment = true
							}).Where(t => t.Amount != 0 || t.Tax != 0)).ToList();

							if (issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement) {
								foreach (var row in invoiceDetailReportList.Where(t => t.IsPayment && Math.Abs(t.Amount) > Math.Abs(t.PersonalTravelAmount)).ToList()) {
									row.Amount = row.PersonalTravelAmount;
								}
							}

							invoiceDetailReportList = invoiceDetailReportList.Where(t => t.Amount != 0).ToList();

							packageTotal = invoiceDetailReportList.Where(t => !t.IsPayment && t.PackageNo > 0).Sum(t => t.Amount);
							subTotal = invoiceDetailReportList.Where(t => !t.IsPayment).Sum(t => t.Amount);
							totalDiscount = invoiceDetailReportList.Where(t => !t.IsPayment).Sum(t => t.Discount);
							totalAgentCommission = invoiceDetailReportList.Where(t => !t.IsPayment).Sum(t => t.AgentCommission);
							totalTax = invoiceDetailReportList.Where(t => !t.IsPayment).Sum(t => t.Tax);
							totalAmount = subTotal - totalAgentCommission;

							packageTaxApplies = invoiceDetailReportList.Where(t => !t.IsPayment && t.PackageNo > 0).Sum(t => t.Tax) != 0;

							tripLineAirPassengers = lazyContext.TripLineAirPassenger.Where(t => tripIds.Contains(t.TripLineAir.TripLine.TripId) && passengerIdList.Contains(t.PassengerId)).Distinct().ToList();

							foreach (var passenger in trip.TripPassengers.Where(t => passengerIdList.Contains(t.Id)).OrderBy(t => t.SeqNo).ThenBy(t => t.Id)) {
								int age = passenger.GetAge();
								string ticketNos = string.Join("; ", tripLineAirPassengers.Where(t => t.Passenger.Id == passenger.Id).Select(t => t.TicketNo).Where(t => !string.IsNullOrEmpty(t)).Distinct());
								passengers += string.Format("{0}{1}{2}{3}", passenger.FullName, passenger.PassengerType == PassengerType.NotSpecified ? string.Empty : string.Format(" [{0}]", passenger.PassengerType == PassengerType.Child && age > 0 ? string.Format("{0} years", age) : passenger.PassengerType == PassengerType.Infant && age > 0 ? string.Format("{0} months", age) : passenger.PassengerType.GetEnumDescription()), string.IsNullOrEmpty(ticketNos) ? string.Empty : string.Format(" [E-Ticket(s): {0}]", ticketNos), Environment.NewLine);
							}

							passengers = passengers.TrimEnd(Environment.NewLine);

							paymentScheduleReportList = lazyContext.TripPaymentSchedule.Where(t => t.TripId == trip.Id && !t.IsCompleted).OrderBy(t => t.TransactionDate).Select(row => new TripPaymentScheduleReportModel {
								TripPaymentScheduleId = row.Id,
								TransactionDate = row.TransactionDate,
								Amount = row.Amount,
								Description = row.Description,
								IsCompleted = row.IsCompleted
							}).ToList();
						}

						if (invoiceDetailReportList.Any(t => t.PackageNo > 0)) {
							invoiceDetailList = invoiceDetailReportList.Where(t => t.PackageNo > 0).GroupBy(t => new { t.TripId, t.TripLineType, t.PackageNo, t.IsPayment }).OrderBy(t => t.Key.PackageNo).ThenBy(t => t.Key.IsPayment ? 1 : 0).ThenBy(t => t.Key.TripId).Select(row => new InvoiceDetailReportModel {
								TripId = row.Key.TripId,
								TripLineType = row.Key.TripLineType,
								PackageNo = row.Key.PackageNo,
								Description = string.Format("Package {0} Total", row.Key.PackageNo),
								Amount = row.Sum(t => t.Amount),
								Tax = row.Sum(t => t.Tax),
								Discount = row.Sum(t => t.Discount),
								AgentCommission = row.Sum(t => t.AgentCommission)
							}).Concat(invoiceDetailReportList.Where(t => t.PackageNo == 0)).Select(row => new InvoiceDetailReportModel {
								TripId = row.TripId,
								TripLineType = row.TripLineType,
								PackageNo = row.PackageNo,
								Description = row.Description,
								Amount = row.Amount,
								Tax = row.Tax,
								Discount = row.Discount,
								AgentCommission = row.AgentCommission
							});
						}
						else {
							invoiceDetailList = invoiceDetailReportList.ToList();
						}

						paymentDetailList = invoiceDetailList.Where(t => t.IsPayment);
						invoiceDetailList = invoiceDetailList.Where(t => !t.IsPayment);
					}

					return new InvoiceReportModel {
						DocumentType = documentType,
						TaxNo = agency.TaxNo,
						Code = debtorCode,
						Debtor = debtor,
						SubDebtor = subDebtor,
						Address = address,
						ContactName = contactName,
						OrderNo = orderNo,
						DocumentNo = documentNo,
						DocumentDate = documentDate,
						DepartureDate = departureDate,
						DateDue = dateDue,
						ForeignCurrency = foreignCurrency,
						PackageTotal = packageTotal,
						SubTotal = subTotal,
						DiscountTotal = totalDiscount,
						AgentCommissionTotal = totalAgentCommission,
						TotalAmount = totalAmount,
						TotalTax = totalTax,
						BalanceDue = totalAmount - paymentDetailList.Sum(t => (decimal?)t.Amount) ?? 0,
						ForeignCurrencyTotalAmount = foreignCurrencyTotalAmount,
						PackageTaxApplies = packageTaxApplies,
						Passengers = passengers,
						DepositDetails = depositDetails,
						PaymentTerms = paymentTerms,
						PaymentOptions = agency.PaymentOptions,
						PayIdLabel = agency.PayIdType.GetEnumDescription(),
						PayId = agency.PayId,
						TravelPayUrl = agency.TravelPayUrl,
						MintUrl = agency.MintUrl,
						InvoiceDetailReportList = invoiceDetailList.ToList(),
						PaymentDetailReportList = paymentDetailList.ToList(),
						PaymentScheduleReportList = paymentScheduleReportList
					};
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "InvoiceReport", ex, customerId);
				return new InvoiceReportModel();
			}
		}

		public List<JournalReportModel> JournalReport(int customerId, int agencyId, int journalId, DateTime? dateFrom, DateTime? dateTo, int accountTypeId, int? documentStatusId, decimal? amountFrom, decimal? amountTo, string account, string text) {
			try {
				using (var lazyContext = new AppLazyContext(customerId, true)) {
					var q = Journal.GetJournalQuery(lazyContext, agencyId, journalId, dateFrom, dateTo, accountTypeId, documentStatusId, amountFrom, amountTo, account, text);

					return q.Select(row => new JournalReportModel {
						DocumentNo = row.DocumentNo,
						DocumentDate = row.DocumentDate,
						DocumentStatus = row.DocumentStatus,
						ReversalStatus = row.ReversalStatus,
						TotalDebit = row.JournalDetails.Sum(t => (decimal?)(t.SignType == SignType.Debit ? t.Amount : 0)) ?? 0,
						TotalCredit = row.JournalDetails.Sum(t => (decimal?)(t.SignType == SignType.Debit ? 0 : -t.Amount)) ?? 0,
						Balance = row.JournalDetails.Sum(t => (decimal?)(t.SignType == SignType.Debit ? t.Amount : -t.Amount)) ?? 0,
						JournalDetailReportList = row.JournalDetails.Select(t => new JournalDetailReportModel {
							AccountType = t.AccountType.GetEnumDescription(),
							AccountName = t.AccountName,
							Debit = t.SignType == SignType.Debit ? t.Amount : (decimal?)null,
							Credit = t.SignType == SignType.Debit ? (decimal?)null : -t.Amount,
							Comments = t.Comments
						}).ToList()
					}).ToList();
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "JournalReport", ex, customerId);
				return new List<JournalReportModel>();
			}
		}

		public List<AdjustmentReportModel> AdjustmentReport(int customerId, int agencyId, int ledgerDocumentTypeId, DateTime? dateFrom, DateTime? dateTo, string adjustmentTypeIds, string consultantIds) {
			try {
				using (var lazyContext = new AppLazyContext(customerId, true)) {
					var ledgerDocumentType = (LedgerDocumentType)ledgerDocumentTypeId;
					var q = lazyContext.Adjustment.Where(t => t.Id > 0);

					if (agencyId != -1) {
						q = q.Where(t => (t.DebitType == DebitCreditType.Client && (t.DebitTrip.AgencyId == agencyId || t.CreditTrip.AgencyId == agencyId))
							|| (t.DebitType == DebitCreditType.Debtor && (t.DebitDebtor.AgencyId == agencyId || t.CreditDebtor.AgencyId == agencyId))
							|| (t.DebitType == DebitCreditType.Creditor && (t.DebitCreditor.AgencyId == agencyId || t.CreditCreditor.AgencyId == agencyId))
							|| (t.DebitType == DebitCreditType.GeneralLedger && (t.DebitChartOfAccount.AgencyId == agencyId || t.CreditChartOfAccount.AgencyId == agencyId)));
					}

					if (!string.IsNullOrEmpty(adjustmentTypeIds)) {
						var adjustmentTypeIdList = adjustmentTypeIds.Split(',').Select(int.Parse).ToArray();
						q = q.Where(t => adjustmentTypeIdList.Contains(t.AdjustmentTypeId));
					}

					if (!string.IsNullOrEmpty(consultantIds)) {
						var consultantIdList = consultantIds.Split(',').Select(int.Parse).ToArray();
						q = q.Where(t => consultantIdList.Contains(t.ConsultantId));
					}

					if (dateFrom != null)
						q = q.Where(t => t.DocumentDate >= dateFrom);

					if (dateTo != null)
						q = q.Where(t => t.DocumentDate <= dateTo);

					return q.OrderBy(t => t.AdjustmentType.Name).ThenBy(t => t.DocumentNo).Select(row => new AdjustmentReportModel {
						AdjustmentType = row.AdjustmentType.Name,
						DocumentNo = row.DocumentNo,
						DocumentDate = row.DocumentDate,
						DebitType = row.DebitType,
						DebitAccountName = row.DebitAccountName,
						CreditType = row.CreditType,
						CreditAccountName = row.CreditAccountName,
						Consultant = Utils.GetIssuedBy(row.Consultant, row.CreationUser, customerId),
						Comments = row.Comments,
						Amount = row.Amount + row.Tax,
						Tax = row.Tax
					}).ToList();
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "AdjustmentReport", ex, customerId);
				return new List<AdjustmentReportModel>();
			}
		}

		public List<TransactionDetailReportModel> TaxAuditReport(int reportGroupId, int customerId, int agencyId, DateTime dateFrom, DateTime dateTo, bool descendingDateOrder) {
			try {
				const bool useGroupNo = false;

                using (var lazyContext = new AppLazyContext(customerId, true)) {
					var reportGroup = (TaxAuditReportGroup)reportGroupId;
					int sign = 1;

					switch (reportGroup) {
						default:
							return new List<TransactionDetailReportModel>();
						case TaxAuditReportGroup.TaxExemptSales:
							var q1 = TransactionDetail.GetTransactionAnalysisQuery(lazyContext, agencyId, dateFrom, dateTo).Where(t => t.TransactionAnalysisType == TransactionAnalysisType.SalesAnalysisAndTaxAuditReport).AsEnumerable()
								.Where(t1 => ((t1.ReceiptDetailId <= 0 || t1.ReceiptDetail.MerchantFee == 0) && !t1.IsTaxApplicable)
								|| lazyContext.TransactionDetail.Where(t2 => t2.TransactionId == t1.TransactionId && t2.TransactionDetailType == TransactionDetailType.Markup).AsEnumerable().Any(t2 => !t2.IsTaxApplicable));

							return q1.GroupBy(row => new {
								row.AccountName,
								row.TransactionId,
								row.Transaction.DocumentNo,
								row.Transaction.DocumentDate,
								TransactionType = row.Transaction.EffectiveTransactionType.GetEnumDescription(),
							}).OrderBy(t => descendingDateOrder ? DateTime.MinValue : t.Key.DocumentDate).ThenByDescending(t => descendingDateOrder ? t.Key.DocumentDate : DateTime.MinValue).ThenBy(t => t.Key.DocumentNo).Select(row => new TransactionDetailReportModel {
								DocumentNo = row.Key.DocumentNo,
								DocumentDate = row.Key.DocumentDate,
								TransactionType = row.Key.TransactionType,
								AmountGross = sign * row.Sum(t => t.CashLessNonCommissionable + t.CreditCardLessNonCommissionable),
								NonCommissionable = sign * row.Sum(t => t.CashNonCommissionable + t.CreditCardNonCommissionable),
								Tax = 0,
								Commission = sign * row.Sum(t => t.TaxAuditCommissionLessDiscount),
								CommissionTax = 0,
								AmountNet = sign * row.Sum(t => t.Cash + t.CreditCard - t.TaxAuditCommissionLessDiscount),
								TaxNet = 0
							}).ToList();
						case TaxAuditReportGroup.TaxApplicableSales:
						case TaxAuditReportGroup.TaxApplicablePurchases:
							var q2 = TransactionDetail.GetTransactionAnalysisQuery(lazyContext, agencyId, dateFrom, dateTo).Where(t => t.TransactionAnalysisType == TransactionAnalysisType.TaxAuditReport || t.TransactionAnalysisType == TransactionAnalysisType.SalesAnalysisAndTaxAuditReport);

							switch (reportGroup) {
								case TaxAuditReportGroup.TaxApplicableSales:
									q2 = q2.Where(t1 => t1.Transaction.TransactionDetails.Any(t2 => lazyContext.GeneralLedgerSettingDetailView.Any(t3 => t3.SalesTaxAccount.Id == t2.ChartOfAccountId && t3.FiscalPeriodStartDate <= t1.Transaction.DocumentDate && t3.FiscalPeriodEndDate >= t1.Transaction.DocumentDate)));
									break;
								case TaxAuditReportGroup.TaxApplicablePurchases:
									q2 = q2.Where(t1 => t1.Transaction.TransactionDetails.Any(t2 => lazyContext.GeneralLedgerSettingDetailView.Any(t3 => t3.PurchasesTaxAccount.Id == t2.ChartOfAccountId && t3.FiscalPeriodStartDate <= t1.Transaction.DocumentDate && t3.FiscalPeriodEndDate >= t1.Transaction.DocumentDate)));
									break;
							}

							var txnDetailList = new List<TransactionDetailReportModel>();

							var groupNos = new List<int>();
							var receiptIds = new List<int>();

							foreach (var txnDetail in q2.OrderBy(t => descendingDateOrder ? DateTime.MinValue : t.Transaction.DocumentDate).ThenByDescending(t => descendingDateOrder ? t.Transaction.DocumentDate : DateTime.MinValue).ThenBy(t => t.Transaction.DocumentNo).ToList()) {
								if (txnDetail.TransactionDetailType == TransactionDetailType.MerchantFee || txnDetail.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission) {
									if (useGroupNo) {
                                        foreach (int groupNo in lazyContext.TransactionDetailAllocation.Where(t => t.ReceiptDetailId == txnDetail.ReceiptDetailId).Select(t => t.GroupNo).Distinct().ToArray()) {
                                            if (groupNos.Contains(groupNo))
                                                continue;

                                            groupNos.Add(groupNo);

                                            txnDetailList.AddRange(Receipt.GetReceiptMerchantFeeTxnDetailList(lazyContext, groupNo).ConvertAll(row => new TransactionDetailReportModel {
                                                AccountName = txnDetail.AccountName,
                                                DocumentNo = row.DebtorReceiptNo,
                                                DocumentDate = row.DebtorReceiptDate,
                                                TransactionType = txnDetail.Transaction.EffectiveTransactionType.GetEnumDescription(),
                                                Commission = 0,
                                                CommissionTax = 0,
                                                NonCommissionable = 0,
                                                AmountGross = row.Amount,
                                                AmountNet = row.Amount,
                                                Tax = row.Tax,
                                                TaxNet = row.Tax
                                            }));
                                        }
                                    }
                                    else {
                                        txnDetailList.Add(new TransactionDetailReportModel {
                                            AccountName = txnDetail.AccountName,
                                            DocumentNo = txnDetail.ReceiptDetail.Receipt.DocumentNo,
                                            DocumentDate = txnDetail.ReceiptDetail.Receipt.DocumentDate,
                                            TransactionType = txnDetail.Transaction.EffectiveTransactionType.GetEnumDescription(),
                                            Commission = 0,
                                            CommissionTax = 0,
                                            NonCommissionable = 0,
                                            AmountGross = txnDetail.ReceiptDetail.MerchantFee,
                                            AmountNet = txnDetail.ReceiptDetail.MerchantFee,
                                            Tax = txnDetail.ReceiptDetail.MerchantFeeTax,
                                            TaxNet = txnDetail.ReceiptDetail.MerchantFeeTax
                                        });
                                    }
								}
								else {
									sign = reportGroup == TaxAuditReportGroup.TaxApplicablePurchases && txnDetail.TransactionDetailType != TransactionDetailType.MerchantFee && txnDetail.TransactionAnalysisType == TransactionAnalysisType.TaxAuditReport ? -1 : 1;

									decimal cancellationFee = 0;
									decimal cancellationFeeTax = 0;

									bool isAdmin = (txnDetail.NonBspDetail.NonBsp.NonBspType == NonBspType.Admin && txnDetail.NonBspDetail.NonBsp.ChartOfAccount.AccountCategory == AccountCategory.Income)
										|| (txnDetail.PaymentDetail.Payment.PaymentType == PaymentType.Admin && txnDetail.PaymentDetail.Payment.ChartOfAccount.AccountCategory == AccountCategory.Income);

									if (txnDetail.ReceiptDetail.ReceiptId > 0 && txnDetail.ReceiptDetail.Receipt.ReceiptType == ReceiptType.Refund) {
										if (!receiptIds.Contains(txnDetail.ReceiptDetail.ReceiptId)) {
											cancellationFee = txnDetail.ReceiptDetail.Receipt.CancellationFee;
											cancellationFeeTax = txnDetail.ReceiptDetail.Receipt.CancellationFeeTax;
										}

										receiptIds.Add(txnDetail.ReceiptDetail.ReceiptId);
									}

									txnDetailList.Add(new TransactionDetailReportModel {
										AccountName = txnDetail.AccountName,
										DocumentNo = txnDetail.Transaction.DocumentNo,
										DocumentDate = txnDetail.Transaction.DocumentDate,
										TransactionType = txnDetail.Transaction.EffectiveTransactionType.GetEnumDescription(),
										Commission = sign * txnDetail.TaxAuditCommissionLessDiscount,
										CommissionTax = sign * txnDetail.TaxAuditCommissionLessDiscountTax,
										NonCommissionable = sign * (txnDetail.CashNonCommissionable + txnDetail.CreditCardNonCommissionable),
										AmountGross = sign * (txnDetail.CashLessNonCommissionable + txnDetail.CreditCardLessNonCommissionable + cancellationFee),
										AmountNet = isAdmin ? 0 : sign * (txnDetail.Cash + txnDetail.CreditCard - txnDetail.TaxAuditCommissionLessDiscount + cancellationFee),
										Tax = sign * (txnDetail.TransactionDetailType == TransactionDetailType.MerchantFee ? txnDetail.GetMerchantFeeTax(customerId) : txnDetail.CashTaxAudit + txnDetail.CreditCardTaxAudit + cancellationFeeTax),
										TaxNet = isAdmin ? 0 : sign * (txnDetail.TransactionDetailType == TransactionDetailType.MerchantFee ? txnDetail.GetMerchantFeeTax(customerId) : txnDetail.CashTaxAudit + txnDetail.CreditCardTaxAudit - txnDetail.TaxAuditCommissionLessDiscountTax + cancellationFeeTax)
									});
								}
							}

							return txnDetailList.GroupBy(row => new {
								row.AccountName,
								row.DocumentNo,
								row.DocumentDate,
								row.TransactionType
							}).Select(row => new TransactionDetailReportModel {
								DocumentNo = row.Key.DocumentNo,
								DocumentDate = row.Key.DocumentDate,
								TransactionType = row.Key.TransactionType,
								AmountGross = row.Sum(t => t.AmountGross),
								NonCommissionable = row.Sum(t => t.NonCommissionable),
								Tax = row.Sum(t => t.Tax),
								Commission = row.Sum(t => t.Commission),
								CommissionTax = row.Sum(t => t.CommissionTax),
								AmountNet = row.Sum(t => t.AmountNet),
								TaxNet = row.Sum(t => t.TaxNet)
							}).ToList();
						case TaxAuditReportGroup.Salary:
						case TaxAuditReportGroup.PAYEG:
							IQueryable<TransactionDetail> q3 = null;
							var glSetting = Setting.GetRow(lazyContext, dateFrom);

							switch (reportGroup) {
								case TaxAuditReportGroup.Salary:
									q3 = lazyContext.TransactionDetail.Where(t => t.ChartOfAccount.AccountCategory == AccountCategory.Salary);
									break;
								case TaxAuditReportGroup.PAYEG:
									q3 = lazyContext.TransactionDetail.Where(t => t.ChartOfAccount.AccountCategory == AccountCategory.PAYEG);
									sign = -1;
									break;
							}

							q3 = q3.Where(t => t.Transaction.DocumentDate >= dateFrom && t.Transaction.DocumentDate <= dateTo);

							if (agencyId > 0)
								q3 = q3.Where(t => t.AgencyId == agencyId);

							var q4 = q3.OrderBy(t => t.ChartOfAccount.Code).ThenBy(t => descendingDateOrder ? DateTime.MinValue : t.Transaction.DocumentDate).ThenByDescending(t => descendingDateOrder ? t.Transaction.DocumentDate : DateTime.MinValue).ThenBy(t => t.Transaction.DocumentNo).Select(row => new TransactionDetailReportModel {
								GroupHeader = row.ChartOfAccount.AccountCategory == AccountCategory.Salary ? "Salaries & Wages" : "PAYG Withholding",
								FiscalPeriodName = Setting.GetRow(lazyContext, row.Transaction.DocumentDate, false, true).FiscalPeriodEndDateName,
								ChartOfAccountCode = row.ChartOfAccount.Code,
								ChartOfAccountName = row.ChartOfAccount.Name,
								TransactionType = row.Transaction.EffectiveTransactionType.GetEnumDescription(),
								DocumentNo = row.Transaction.DocumentNo,
								DocumentDate = row.Transaction.DocumentDate,
								Payee = row.PaymentDetail.Payment.Payee,
								AmountGross = sign * (row.CashLessNonCommissionable + row.CreditCardLessNonCommissionable),
								NonCommissionable = 0,
								Tax = 0,
								Commission = 0,
								CommissionTax = 0,
								AmountNet = 0,
								TaxNet = 0
							}).ToList();

							foreach (var row in q4) {
								var fiscalPeriod = Setting.GetRow(lazyContext, row.DocumentDate);
								row.FiscalPeriod = fiscalPeriod.FiscalPeriodEndDate;
								row.FiscalPeriodName = fiscalPeriod.FiscalPeriodEndDateName;
							}

							if (q4.Count == 0) {
								q4.Add(new TransactionDetailReportModel {
									GroupHeader = reportGroup == TaxAuditReportGroup.Salary ? "Salaries & Wages" : "PAYG Withholding",
									FiscalPeriod = DateTime.MinValue,
									FiscalPeriodName = string.Empty,
									ChartOfAccountCode = string.Empty,
									ChartOfAccountName = string.Empty,
									TransactionType = string.Empty,
									DocumentNo = string.Empty,
									DocumentDate = DateTime.MinValue,
									Payee = string.Empty,
									AmountGross = 0,
									NonCommissionable = 0,
									Tax = 0,
									Commission = 0,
									CommissionTax = 0,
									AmountNet = 0,
									TaxNet = 0
								});
							}

							return q4;
					}
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "TaxAuditReport", ex, customerId);
				return new List<TransactionDetailReportModel>();
			}
		}

		public List<VoucherReportModel> VoucherReport(int customerId, int voucherId, int agencyId) {
			try {
				using (var lazyContext = new AppLazyContext(customerId, true)) {
					var q = lazyContext.Voucher.Find(voucherId);
					var agencyHeader = lazyContext.AgencyHeader.Single(t => t.AgencyId == agencyId && t.IssuedDocumentType == IssuedDocumentType.Voucher);

					string serviceLabel = null;
					string startDateLabel = null;
					string endDateLabel = null;
					string startDetailsLabel = null;
					string endDetailsLabel = null;

					switch (q.TripLine.TripLineType) {
						default:
							serviceLabel = "Service Type:";
							startDateLabel = "Start Date:";
							endDateLabel = "End Date:";
							startDetailsLabel = "Start Details:";
							endDetailsLabel = "End Details:";
							break;
						case TripLineType.Accommodation:
							serviceLabel = "Room Type:";
							startDateLabel = "Arrival Date:";
							endDateLabel = "Departure Date:";
							startDetailsLabel = "Arrival Details:";
							endDetailsLabel = "Departure Details:";
							break;
						case TripLineType.Transport:
							serviceLabel = "Vehicle Type:";
							startDateLabel = "Pickup Date:";
							endDateLabel = "Dropoff Date:";
							startDetailsLabel = "Pickup Details:";
							endDetailsLabel = "Dropoff Details:";
							break;
						case TripLineType.Cruise:
							serviceLabel = "Service Type:";
							startDateLabel = "Arrival Date:";
							endDateLabel = "Departure Date:";
							startDetailsLabel = "Arrival Details:";
							endDetailsLabel = "Departure Details:";
							break;
					}

					string phoneLabel = string.IsNullOrEmpty(q.SupplierContactPhoneNo) ? string.Empty : "Phone: ";
					string emailLabel = string.IsNullOrEmpty(q.SupplierContactEmail) ? string.Empty : "Email: ";
					string supplierAddress = q.GetSupplierAddress(lazyContext);

					var model1 = new VoucherReportModel {
						Logo = agencyHeader.Logo?.BytesToImage().CopyImage(),
						HeaderContent = agencyHeader.HeaderContent,
						Copy = "Client Copy",
						VoucherId = q.Id,
						VoucherNo = q.DocumentNo,
						TripId = q.TripId,
						TripNo = q.Trip.TripNo,
						ConfirmationNo = string.IsNullOrEmpty(q.ConfirmationNo) ? "Not Specified" : q.ConfirmationNo,
						TaxNo = agencyHeader.IncludeTaxNo ? agencyHeader.Agency.TaxNo : string.Empty,
						Passengers = string.Join("; ", q.VoucherDetails.Select(t => t.Passenger.FullName)),
						ServiceLabel = serviceLabel,
						Service = q.SupplierService.Name,
						ServiceComments = string.IsNullOrEmpty(q.ServiceComments) ? "Not Specified" : q.ServiceComments,
						StartDateLabel = startDateLabel,
						StartDate = q.StartDate,
						EndDateLabel = endDateLabel,
						EndDate = q.EndDate,
						StartDetailsLabel = string.IsNullOrEmpty(q.StartDetails) ? string.Empty : startDetailsLabel,
						StartDetails = string.IsNullOrEmpty(q.StartDetails) ? string.Empty : q.StartDetails,
						EndDetailsLabel = string.IsNullOrEmpty(q.EndDetails) ? string.Empty : endDetailsLabel,
						EndDetails = string.IsNullOrEmpty(q.EndDetails) ? string.Empty : q.EndDetails,
						ServiceProvider = string.Format("{1}{2}{0}{3}{4}{0}{5}{6}", Environment.NewLine, q.SupplierName, string.IsNullOrEmpty(supplierAddress) ? string.Empty : string.Format("{0}{1}", Environment.NewLine, supplierAddress.Replace(AppConstants.HtmlLineBreak, Environment.NewLine)), phoneLabel, q.SupplierContactPhoneNo, emailLabel, q.SupplierContactEmail),
						PaymentDetails = q.VoucherType.GetEnumDescription(),
						RateDescription = q.IncludePricing ? string.Format("<em>{0}</em>", Utils.HtmlEncodeExceptTags(q.GetServiceTypeRateBasisDescription(q.TripLine.TripLineLand, customerId))) : string.Empty
					};

					var model2 = model1.Clone() as VoucherReportModel;
					model2.Copy = "Service Provider Copy";

					var model3 = model1.Clone() as VoucherReportModel;
					model3.Copy = "File Copy";

					return new List<VoucherReportModel> {
						model1,
						model2,
						model3
					};
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "VoucherReport", ex, customerId);
				return new List<VoucherReportModel>();
			}
		}

		public static TypeReportSource GetReportSource(AppMainContext context, IPrincipal principal, AccountingReportSourceModel model) {
			string typeName;

			BankAccountStatement statementFrom = null;
			BankAccountStatement statementTo = null;

			int statementNoFrom = 0;
			int statementNoTo = 0;

			var sb = new StringBuilder();

			switch (model.ReportSource) {
				default:
					throw new InvalidOperationException("Invalid Report Source.");
				case ReportSourceAccounting.Adjustments:
					typeName = typeof(AdjustmentReport).AssemblyQualifiedName;
					break;
				case ReportSourceAccounting.BankReconciliation:
					typeName = typeof(BankReconciliationReport).AssemblyQualifiedName;
					break;
				case ReportSourceAccounting.TaxAudit:
					typeName = typeof(TaxAuditReport).AssemblyQualifiedName;

					var glSetting1 = Setting.GetRow(context, model.DateFrom ?? DateTime.MinValue);
					var glSetting2 = Setting.GetRow(context, model.DateTo ?? DateTime.MinValue);

					if (glSetting1.SettingId != glSetting2.SettingId)
						throw new UnreportedException("This report cannot be run across multiple fiscal years.");

					break;
			}

			string reportName = GetReportName(model.ReportSource);

			switch (model.ReportSource) {
                case ReportSourceAccounting.Adjustments:
                    sb.AppendFormat("Agency: {0}", (model.AgencyId ?? 0) <= 0 ? "All Agencies" : context.Agency.Find(model.AgencyId).Name);

                    string description = "Document Date:";

                    if (model.DateFrom == null && model.DateTo == null) {
                        description = string.Format("{0} All Dates", description);
                    }
                    else if (model.DateTo == null) {
                        description = string.Format("{0} From {1:dd-MMM-yyyy}", description, model.DateFrom);
                    }
                    else if (model.DateFrom == null) {
                        description = string.Format("{0} To {1:dd-MMM-yyyy}", description, model.DateTo);
                    }
                    else {
                        description = string.Format("{0} From {1:dd-MMM-yyyy} To {2:dd-MMM-yyyy}", description, model.DateFrom, model.DateTo);
                    }

                    sb.AppendFormat(" | {0}", description);
                    break;
                case ReportSourceAccounting.BankReconciliation:
					switch (model.LedgerDocumentType) {
						case LedgerDocumentType.Standard:
							reportName = string.Format("{0} - Bank Statement", reportName);
							model.BankAccountStatementIdFrom = model.BankAccountStatementIdTo;
							break;
						case LedgerDocumentType.StandardDetail:
							reportName = string.Format("{0} - Cash Book", reportName);
							model.BankAccountStatementIdFrom = model.BankAccountStatementIdTo;
							break;
						case LedgerDocumentType.Reconciliation:
							reportName = string.Format("{0} - {1}", reportName, model.UnreconciledOnly ? "Unreconciled Summary" : "Summary");
							break;
						case LedgerDocumentType.ReconciliationDetail:
							reportName = string.Format("{0} - {1}", reportName, model.UnreconciledOnly ? "Unreconciled Detail" : "Detail");
							break;
					}

					statementFrom = context.BankAccountStatement.Find(model.BankAccountStatementIdFrom) ?? new BankAccountStatement();
					statementTo = context.BankAccountStatement.Find(model.BankAccountStatementIdTo) ?? new BankAccountStatement();

					statementNoFrom = statementFrom.StatementNo;
					statementNoTo = statementTo.StatementNo;

					if ((statementNoFrom == 0 && statementNoTo > 0) || (statementNoFrom > 0 && statementNoTo == 0) || (statementNoFrom > 0 && statementNoFrom == statementNoTo)) {
						sb.AppendFormat("Statement No {0}", statementNoFrom == 0 ? statementNoTo : statementNoFrom);
					}
					else {
						sb.AppendFormat("Statement No From {0} To {1}", statementNoFrom, statementNoTo);
					}

					if (model.LedgerDocumentType == LedgerDocumentType.Standard || model.LedgerDocumentType == LedgerDocumentType.StandardDetail)
						sb.AppendFormat(" | Period: {0:MMM-yyyy}", model.PeriodTo);

					break;
				case ReportSourceAccounting.TaxAudit:
					sb.AppendFormat("Agency: {0}", (model.AgencyId ?? 0) <= 0 ? "All Agencies" : context.Agency.Find(model.AgencyId).Name);

					description = "Document Date:";

					if (model.DateFrom == null && model.DateTo == null) {
						description = string.Format("{0} All Dates", description);
					}
					else if (model.DateTo == null) {
						description = string.Format("{0} From {1:dd-MMM-yyyy}", description, model.DateFrom);
					}
					else if (model.DateFrom == null) {
						description = string.Format("{0} To {1:dd-MMM-yyyy}", description, model.DateTo);
					}
					else {
						description = string.Format("{0} From {1:dd-MMM-yyyy} To {2:dd-MMM-yyyy}", description, model.DateFrom, model.DateTo);
					}

					sb.AppendFormat(" | {0}", description);
					break;
			}

			var reportSource = new TypeReportSource {
				TypeName = typeName
			};

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = model.CustomerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = model.AgencyId ?? -1 });
			reportSource.Parameters.Add(new Parameter { Name = "customerName", Value = Utils.GetCustomerName(model.CustomerId, model.DefaultAgency) });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = model.CreationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = model.CreationTime });
			reportSource.Parameters.Add(new Parameter { Name = "reportName", Value = reportName });
			reportSource.Parameters.Add(new Parameter { Name = "reportDate", Value = model.CreationTime.Date.ToShortDateStringExt() });
			reportSource.Parameters.Add(new Parameter { Name = "headerContent", Value = Utils.HtmlEncodeExceptTags(sb.ToString()) });
			reportSource.Parameters.Add(new Parameter { Name = "dateFrom", Value = model.DateFrom });
			reportSource.Parameters.Add(new Parameter { Name = "dateTo", Value = model.DateTo });

			switch (model.ReportSource) {
				case ReportSourceAccounting.Adjustments:
					reportSource.Parameters.Add(new Parameter { Name = "ledgerDocumentTypeId", Value = (int)model.LedgerDocumentType });
					reportSource.Parameters.Add(new Parameter { Name = "reportGroupingId", Value = model.ReportGroupingId ?? 0 });
					reportSource.Parameters.Add(new Parameter { Name = "adjustmentTypeIds", Value = model.AdjustmentTypeIds == null ? string.Empty : string.Join(",", model.AdjustmentTypeIds) });
					reportSource.Parameters.Add(new Parameter { Name = "consultantIds", Value = model.ConsultantIds == null ? string.Empty : string.Join(",", model.ConsultantIds) });
					break;
				case ReportSourceAccounting.BankReconciliation:
					bool isSummary = model.LedgerDocumentType == LedgerDocumentType.Reconciliation;

					reportSource.Parameters.Add(new Parameter { Name = "ledgerDocumentTypeId", Value = (int)model.LedgerDocumentType });
					reportSource.Parameters.Add(new Parameter { Name = "bankAccountId", Value = model.BankAccountId ?? 0 });
					reportSource.Parameters.Add(new Parameter { Name = "statementNoFrom", Value = statementNoFrom });
					reportSource.Parameters.Add(new Parameter { Name = "statementNoTo", Value = statementNoTo });
					reportSource.Parameters.Add(new Parameter { Name = "periodTo", Value = (model.PeriodTo ?? DateTime.MinValue).Date });
					reportSource.Parameters.Add(new Parameter { Name = "descendingDateOrder", Value = model.DescendingDateOrder });
					reportSource.Parameters.Add(new Parameter { Name = "unreconciledOnly", Value = model.UnreconciledOnly });
					reportSource.Parameters.Add(new Parameter { Name = "isSummary", Value = isSummary });
					break;
				case ReportSourceAccounting.TaxAudit:
					decimal salesTaxAccountValue = 0;
					decimal purchasesTaxAccountValue = 0;

					var glSetting = Setting.GetRow(model.CustomerId, model.DateFrom ?? DateTime.Today);

					if (glSetting.SalesTaxAccount != null) {
						salesTaxAccountValue = context.TransactionDetail.Where(t => t.ChartOfAccount.Code == glSetting.SalesTaxAccount.Code && t.Transaction.DocumentDate >= model.DateFrom && t.Transaction.DocumentDate <= model.DateTo).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
						purchasesTaxAccountValue = context.TransactionDetail.Where(t => t.ChartOfAccount.Code == glSetting.PurchasesTaxAccount.Code && t.Transaction.DocumentDate >= model.DateFrom && t.Transaction.DocumentDate <= model.DateTo).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
					}

					reportSource.Parameters.Add(new Parameter { Name = "userName", Value = principal.Identity.Name });
					reportSource.Parameters.Add(new Parameter { Name = "countryCode", Value = AppSettings.Setting(model.CustomerId).CountryCode });
					reportSource.Parameters.Add(new Parameter { Name = "descendingDateOrder", Value = model.DescendingDateOrder });
					reportSource.Parameters.Add(new Parameter { Name = "salesTaxAccountCode", Value = glSetting.SalesTaxAccount?.Code });
					reportSource.Parameters.Add(new Parameter { Name = "salesTaxAccountValue", Value = salesTaxAccountValue });
					reportSource.Parameters.Add(new Parameter { Name = "purchasesTaxAccountCode", Value = glSetting.PurchasesTaxAccount?.Code });
					reportSource.Parameters.Add(new Parameter { Name = "purchasesTaxAccountValue", Value = purchasesTaxAccountValue });
					break;
			}

			return reportSource;
		}

		public static TypeReportSource GetReceiptReportSource(AppMainContext context, int customerId, string userName, int receiptId, string documentNo, DateTime creationTime, string creationUser) {
			var reportSource = new TypeReportSource {
				TypeName = typeof(ReceiptReport).AssemblyQualifiedName
			};

			var receipt = context.Receipt.Find(receiptId);

			reportSource.Parameters.Add(new Parameter { Name = "userName", Value = userName });
			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = customerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = receipt.AgencyId });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = creationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = creationTime });
			reportSource.Parameters.Add(new Parameter { Name = "receiptId", Value = receiptId });
			reportSource.Parameters.Add(new Parameter { Name = "documentNo", Value = documentNo });
			reportSource.Parameters.Add(new Parameter { Name = "issuedDocumentType", Value = nameof(IssuedDocumentType.Receipt) });
			reportSource.Parameters.Add(new Parameter { Name = "accountType", Value = receipt.AccountType });

			return reportSource;
		}

		public static TypeReportSource GetCustomerReceiptReportSource(int customerId, string userName, Receipt receipt) {
			var reportSource = new TypeReportSource {
				TypeName = typeof(ReceiptReport).AssemblyQualifiedName
			};

			reportSource.Parameters.Add(new Parameter { Name = "userName", Value = userName });
			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = customerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = receipt.AgencyId });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = "System" });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = DateTime.Now });
			reportSource.Parameters.Add(new Parameter { Name = "receiptId", Value = receipt.Id });
			reportSource.Parameters.Add(new Parameter { Name = "documentNo", Value = receipt.DocumentNo });
			reportSource.Parameters.Add(new Parameter { Name = "issuedDocumentType", Value = "Receipt" });
			reportSource.Parameters.Add(new Parameter { Name = "accountType", Value = receipt.AccountType });

			return reportSource;
		}

		public static TypeReportSource GetReceiptBankDepositReportSource(AppMainContext context, int customerId, DateTime? depositDate, int bankAccountId, int receiptId, string receiptDetailIds, DateTime creationTime, string creationUser) {
			var reportSource = new TypeReportSource {
				TypeName = typeof(ReceiptBankDepositReport).AssemblyQualifiedName
			};

			Agency agency;

			if (receiptId > 0) {
				var receipt = context.Receipt.Include(t => t.Agency).Single(t => t.Id == receiptId);
				depositDate = receipt.DocumentDate;
				agency = receipt.Agency;
			}
			else {
				agency = context.Agency.Single(t => t.IsHeadOffice);
			}

			var sb = new StringBuilder();

			sb.AppendFormat("Agency: {0}", agency.Name);
			sb.AppendFormat(" | Deposit Date: {0:dd-MMM-yyyy HH:mm}", depositDate);

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = customerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = agency.Id });
			reportSource.Parameters.Add(new Parameter { Name = "customerName", Value = Utils.GetCustomerName(customerId, agency.Name) });
			reportSource.Parameters.Add(new Parameter { Name = "headerContent", Value = string.Empty });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = creationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = creationTime });
			reportSource.Parameters.Add(new Parameter { Name = "depositDate", Value = string.Format("{0:dd-MMM-yyyy HH:mm}", depositDate) });
			reportSource.Parameters.Add(new Parameter { Name = "bankAccountId", Value = bankAccountId });
			reportSource.Parameters.Add(new Parameter { Name = "receiptId", Value = receiptId });
			reportSource.Parameters.Add(new Parameter { Name = "receiptDetailIds", Value = receiptDetailIds });

			return reportSource;
		}

		public static TypeReportSource GetInvoiceReportSource(AppMainContext context, int customerId, IssuedDocumentType issuedDocumentType, TimeFormat timeFormat, int invoiceId, int tripId, int quoteNo, string tripLineIds, string passengerIds, bool isTaxInInvoiceLineAmount, DateTime creationTime, string creationUser, DateTime today) {
			if ((issuedDocumentType == IssuedDocumentType.ClientStatement || issuedDocumentType == IssuedDocumentType.PersonalStatement) && quoteNo != 0)
				throw new UnreportedException("This document can only be printed from a booking.");

			if ((issuedDocumentType == IssuedDocumentType.ClientStatement || issuedDocumentType == IssuedDocumentType.PersonalStatement) && !context.TripAddress.Where(t => t.TripId == tripId).AsEnumerable().Any(t => t.Address.Length > 0))
				throw new UnreportedException("A client address is required.");

			string invoiceType = string.Empty;
			int agencyId;

			if (issuedDocumentType == IssuedDocumentType.Invoice || issuedDocumentType == IssuedDocumentType.DebtorStatement) {
				var invoice = context.Invoice.Include(t => t.Debtor).ThenInclude(t => t.DebtorAddresses).Single(t => t.Id == invoiceId);
				agencyId = invoice.AgencyId;

				if (issuedDocumentType == IssuedDocumentType.Invoice)
					invoiceType = invoice.InvoiceType.ToString();

				string address = invoice.GetDebtorAddress(context).Replace(AppConstants.HtmlLineBreak, Environment.NewLine);

				if (string.IsNullOrEmpty(address))
					address = invoice.Debtor.GetAddress(context).Replace(AppConstants.HtmlLineBreak, Environment.NewLine);

				if (string.IsNullOrEmpty(address))
					throw new UnreportedException("A debtor address is required.");
			}
			else {
				var trip = context.Trip.Find(tripId);
				agencyId = trip.AgencyId;
			}

			var reportSource = new TypeReportSource {
				TypeName = typeof(InvoiceReport).AssemblyQualifiedName
			};

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = customerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = agencyId });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = creationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = creationTime });
			reportSource.Parameters.Add(new Parameter { Name = "timeFormat", Value = issuedDocumentType == IssuedDocumentType.ClientStatement || issuedDocumentType == IssuedDocumentType.PersonalStatement ? timeFormat.ToString() : nameof(TimeFormat.Military) });
			reportSource.Parameters.Add(new Parameter { Name = "id", Value = invoiceId > 0 ? invoiceId : tripId });
			reportSource.Parameters.Add(new Parameter { Name = "invoiceType", Value = invoiceType });
			reportSource.Parameters.Add(new Parameter { Name = "issuedDocumentType", Value = issuedDocumentType.ToString() });
			reportSource.Parameters.Add(new Parameter { Name = "quoteNo", Value = quoteNo });
			reportSource.Parameters.Add(new Parameter { Name = "tripLineIds", Value = tripLineIds.ToStringExt() });
			reportSource.Parameters.Add(new Parameter { Name = "passengerIds", Value = passengerIds.ToStringExt() });
			reportSource.Parameters.Add(new Parameter { Name = "isTaxInInvoiceLineAmount", Value = isTaxInInvoiceLineAmount });
			reportSource.Parameters.Add(new Parameter { Name = "today", Value = today });

			return reportSource;
		}

		public static TypeReportSource GetCustomerInvoiceReportSource(int customerId, Invoice invoice) {
			var reportSource = new TypeReportSource {
				TypeName = typeof(InvoiceReport).AssemblyQualifiedName
			};

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = customerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = invoice.AgencyId });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = "System" });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = DateTime.Now });
			reportSource.Parameters.Add(new Parameter { Name = "timeFormat", Value = nameof(TimeFormat.Military) });
			reportSource.Parameters.Add(new Parameter { Name = "id", Value = invoice.Id });
			reportSource.Parameters.Add(new Parameter { Name = "invoiceType", Value = invoice.InvoiceType.ToString() });
			reportSource.Parameters.Add(new Parameter { Name = "issuedDocumentType", Value = "Invoice" });
			reportSource.Parameters.Add(new Parameter { Name = "quoteNo", Value = 0 });
			reportSource.Parameters.Add(new Parameter { Name = "tripLineIds", Value = string.Empty });
			reportSource.Parameters.Add(new Parameter { Name = "passengerIds", Value = string.Empty });
			reportSource.Parameters.Add(new Parameter { Name = "isTaxInInvoiceLineAmount", Value = invoice.Debtor.IsTaxInInvoiceLineAmount });
			reportSource.Parameters.Add(new Parameter { Name = "today", Value = DateTime.Today });

			return reportSource;
		}

		public static TypeReportSource GetJournalReportSource(AppMainContext context, int customerId, string defaultAgency, int agencyId, int journalId, DateTime? dateFrom, DateTime? dateTo, int accountTypeId, int? documentStatusId, decimal? amountFrom, decimal? amountTo, string account, string text, DateTime creationTime, string creationUser) {
			var reportSource = new TypeReportSource {
				TypeName = typeof(JournalReport).AssemblyQualifiedName
			};

			var accountType = (AccountType)accountTypeId;
			var documentStatus = (DocumentStatus?)documentStatusId;

			var sb = new StringBuilder();

			sb.AppendFormat("Agency: {0}", context.Agency.Find(agencyId).Name);

			if (dateFrom != null)
				sb.AppendFormat(" | Date From: {0:dd-MMM-yyyy}", dateFrom);

			if (dateTo != null)
				sb.AppendFormat(" | Date To: {0:dd-MMM-yyyy}", dateTo);

			if (accountType != AccountType.None)
				sb.AppendFormat(" | Account Type: {0}", accountType.GetEnumDescription());

			if (documentStatus != null)
				sb.AppendFormat(" | Status: {0}", documentStatus.GetEnumDescription());

			if (amountFrom != null)
				sb.AppendFormat(" | Amount From: {0:c2}", amountFrom);

			if (amountTo != null)
				sb.AppendFormat(" | Amount To: {0:c2}", amountTo);

			if (!string.IsNullOrEmpty(account))
				sb.AppendFormat(" | Account: {0}", account);

			if (!string.IsNullOrEmpty(text))
				sb.AppendFormat(" | Document No or Comments: {0}", text);

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = customerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = agencyId });
			reportSource.Parameters.Add(new Parameter { Name = "customerName", Value = Utils.GetCustomerName(customerId, defaultAgency) });
			reportSource.Parameters.Add(new Parameter { Name = "reportName", Value = "Journals" });
			reportSource.Parameters.Add(new Parameter { Name = "reportDate", Value = creationTime.Date.ToShortDateStringExt() });
			reportSource.Parameters.Add(new Parameter { Name = "headerContent", Value = Utils.HtmlEncodeExceptTags(sb.ToString()) });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = creationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = creationTime });
			reportSource.Parameters.Add(new Parameter { Name = "journalId", Value = journalId });
			reportSource.Parameters.Add(new Parameter { Name = "dateFrom", Value = dateFrom });
			reportSource.Parameters.Add(new Parameter { Name = "dateTo", Value = dateTo });
			reportSource.Parameters.Add(new Parameter { Name = "accountTypeId", Value = accountTypeId });
			reportSource.Parameters.Add(new Parameter { Name = "documentStatusId", Value = documentStatusId });
			reportSource.Parameters.Add(new Parameter { Name = "amountFrom", Value = amountFrom });
			reportSource.Parameters.Add(new Parameter { Name = "amountTo", Value = amountTo });
			reportSource.Parameters.Add(new Parameter { Name = "account", Value = account });
			reportSource.Parameters.Add(new Parameter { Name = "text", Value = text });

			return reportSource;
		}

		public static TypeReportSource GetVoucherReportSource(AppMainContext context, int customerId, int voucherId) {
			var reportSource = new TypeReportSource {
				TypeName = typeof(VoucherReport).AssemblyQualifiedName
			};

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = customerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = context.Voucher.Include(t => t.Trip).Single(t => t.Id == voucherId).Trip.AgencyId });
			reportSource.Parameters.Add(new Parameter { Name = "voucherId", Value = voucherId });

			return reportSource;
		}

		public static string GetReportName(ReportSourceAccounting reportSource) {
			switch (reportSource) {
				default:
					throw new InvalidOperationException("Invalid Report Source.");
				case ReportSourceAccounting.Adjustments:
					return "Adjustments";
				case ReportSourceAccounting.BankReconciliation:
					return "Bank Reconciliation";
				case ReportSourceAccounting.TaxAudit:
					return string.Format("{0} Audit", Resource.TaxLabel);
			}
		}

		public static string GetReportFileName(ReportSourceAccounting reportSource) {
			return WebUtility.HtmlDecode(GetReportName(reportSource));
		}
	}
}