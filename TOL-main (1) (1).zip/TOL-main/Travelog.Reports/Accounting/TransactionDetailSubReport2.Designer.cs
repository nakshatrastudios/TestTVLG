namespace Travelog.Reports.Accounting {
	partial class TransactionDetailSubReport2 {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.DocumentTypeHeader = new Telerik.Reporting.TextBox();
			this.DocumentNoHeader = new Telerik.Reporting.TextBox();
			this.CreditHeader = new Telerik.Reporting.TextBox();
			this.ReferenceHeader = new Telerik.Reporting.TextBox();
			this.DateHeader = new Telerik.Reporting.TextBox();
			this.DebitHeader = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.DocumentType = new Telerik.Reporting.TextBox();
			this.Credit = new Telerik.Reporting.TextBox();
			this.DocumentNo = new Telerik.Reporting.TextBox();
			this.Reference = new Telerik.Reporting.TextBox();
			this.Date = new Telerik.Reporting.TextBox();
			this.Debit = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.CanShrink = true;
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			this.GroupFooterSection1.Style.Visible = false;
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DocumentTypeHeader,
            this.DocumentNoHeader,
            this.CreditHeader,
            this.ReferenceHeader,
            this.DateHeader,
            this.DebitHeader});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = true;
			this.GroupHeaderSection1.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			// 
			// DocumentTypeHeader
			// 
			this.DocumentTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentTypeHeader.Name = "DocumentTypeHeader";
			this.DocumentTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentTypeHeader.Style.Font.Name = "Calibri";
			this.DocumentTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentTypeHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentTypeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentTypeHeader.StyleName = "Normal.TableHeader";
			this.DocumentTypeHeader.Value = "Type";
			// 
			// DocumentNoHeader
			// 
			this.DocumentNoHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentNoHeader.Name = "DocumentNoHeader";
			this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNoHeader.Style.Font.Name = "Calibri";
			this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNoHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNoHeader.StyleName = "Normal.TableHeader";
			this.DocumentNoHeader.Value = "Document No";
			// 
			// CreditHeader
			// 
			this.CreditHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CreditHeader.Name = "CreditHeader";
			this.CreditHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CreditHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditHeader.Style.Font.Name = "Calibri";
			this.CreditHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditHeader.StyleName = "Normal.TableHeader";
			this.CreditHeader.Value = "Credit";
			// 
			// ReferenceHeader
			// 
			this.ReferenceHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ReferenceHeader.Name = "ReferenceHeader";
			this.ReferenceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReferenceHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ReferenceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReferenceHeader.Style.Font.Name = "Calibri";
			this.ReferenceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReferenceHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReferenceHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ReferenceHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ReferenceHeader.StyleName = "Normal.TableHeader";
			this.ReferenceHeader.Value = "Reference";
			// 
			// DateHeader
			// 
			this.DateHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DateHeader.Name = "DateHeader";
			this.DateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DateHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DateHeader.Style.Font.Name = "Calibri";
			this.DateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DateHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DateHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DateHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DateHeader.StyleName = "Normal.TableHeader";
			this.DateHeader.Value = "Date";
			// 
			// DebitHeader
			// 
			this.DebitHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DebitHeader.Name = "DebitHeader";
			this.DebitHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DebitHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DebitHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DebitHeader.Style.Font.Name = "Calibri";
			this.DebitHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DebitHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DebitHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DebitHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DebitHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.DebitHeader.StyleName = "Normal.TableHeader";
			this.DebitHeader.Value = "Debit";
			// 
			// Detail
			// 
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DocumentType,
            this.Credit,
            this.DocumentNo,
            this.Reference,
            this.Date,
            this.Debit});
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// DocumentType
			// 
			this.DocumentType.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentType.Name = "DocumentType";
			this.DocumentType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentType.Style.Font.Name = "Calibri";
			this.DocumentType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentType.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentType.StyleName = "Normal.TableBody";
			this.DocumentType.Value = "= Fields.DocumentType";
			// 
			// Credit
			// 
			this.Credit.Format = "{0:C2}";
			this.Credit.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Credit.Name = "Credit";
			this.Credit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Credit.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Credit.Style.Font.Name = "Calibri";
			this.Credit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Credit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Credit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Credit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Credit.StyleName = "Normal.TableBody";
			this.Credit.Value = "= IIf(Fields.SignType = \"Debit\", Null, Fields.Amount)";
			// 
			// DocumentNo
			// 
			this.DocumentNo.Format = "{0:C2}";
			this.DocumentNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentNo.Name = "DocumentNo";
			this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNo.Style.Font.Name = "Calibri";
			this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.StyleName = "Normal.TableBody";
			this.DocumentNo.Value = "= Fields.DocumentNo";
			// 
			// Reference
			// 
			this.Reference.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Reference.Name = "Reference";
			this.Reference.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Reference.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Reference.Style.Font.Name = "Calibri";
			this.Reference.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Reference.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Reference.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Reference.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Reference.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Reference.StyleName = "Normal.TableBody";
			this.Reference.Value = "= Fields.Reference";
			// 
			// Date
			// 
			this.Date.CanShrink = true;
			this.Date.Format = "{0:dd-MMM-yyyy}";
			this.Date.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Date.Name = "Date";
			this.Date.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Date.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Date.Style.Font.Name = "Calibri";
			this.Date.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Date.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Date.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Date.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Date.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Date.StyleName = "Normal.TableBody";
			this.Date.Value = "= Fields.DocumentDate";
			// 
			// Debit
			// 
			this.Debit.Format = "{0:C2}";
			this.Debit.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Debit.Name = "Debit";
			this.Debit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Debit.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Debit.Style.Font.Name = "Calibri";
			this.Debit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Debit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Debit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Debit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Debit.StyleName = "Normal.TableBody";
			this.Debit.Value = "= IIf(Fields.SignType = \"Debit\", Fields.Amount, Null)";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "TransactionDetailReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.Accounting.AccountingDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("tripId", typeof(int), "= Parameters.tripId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("debtorId", typeof(int), "= Parameters.debtorId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("creditorId", typeof(int), "= Parameters.creditorId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("chartOfAccountId", typeof(int), "= Parameters.chartOfAccountId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("transactionDetailIds", typeof(string), "= Parameters.transactionDetailIds.Value"));
			// 
			// TransactionDetailSubReport2
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail});
			this.Name = "TransactionDetailSubReport2";
			this.PageSettings.Landscape = true;
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "customerId";
			reportParameter2.Name = "agencyId";
			reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter3.Name = "tripId";
			reportParameter3.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter4.Name = "debtorId";
			reportParameter4.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter5.Name = "creditorId";
			reportParameter5.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter6.Name = "chartOfAccountId";
			reportParameter6.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter7.Name = "transactionDetailIds";
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(19D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.TextBox DateHeader;
		private Telerik.Reporting.TextBox DocumentTypeHeader;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox CreditHeader;
		private Telerik.Reporting.TextBox Date;
		private Telerik.Reporting.TextBox DocumentType;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox Credit;
		private Telerik.Reporting.TextBox ReferenceHeader;
		private Telerik.Reporting.TextBox Reference;
		private Telerik.Reporting.TextBox DebitHeader;
		private Telerik.Reporting.TextBox Debit;
	}
}