namespace Travelog.Reports.DebtorLedger {
	partial class BankReconciliationReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup10 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup11 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup12 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup13 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup14 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup15 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup16 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter11 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter12 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter13 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter14 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter15 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter16 = new Telerik.Reporting.ReportParameter();
			this.DocumentNoHeader = new Telerik.Reporting.TextBox();
			this.DocumentDateHeader = new Telerik.Reporting.TextBox();
			this.DescriptionHeader = new Telerik.Reporting.TextBox();
			this.DebitHeader = new Telerik.Reporting.TextBox();
			this.CreditHeader = new Telerik.Reporting.TextBox();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.PaymentOptionsPanel = new Telerik.Reporting.Panel();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.BankAccountName = new Telerik.Reporting.TextBox();
			this.BankAccountBranch = new Telerik.Reporting.TextBox();
			this.BankAccountNo = new Telerik.Reporting.TextBox();
			this.ManagementReportHeaderSubReport2 = new Telerik.Reporting.SubReport();
			this.GeneralLedgerAccount = new Telerik.Reporting.TextBox();
			this.BankAccountDescription = new Telerik.Reporting.TextBox();
			this.StatementLabel = new Telerik.Reporting.TextBox();
			this.UnreconciledAmountLabel1 = new Telerik.Reporting.TextBox();
			this.Spacer1 = new Telerik.Reporting.TextBox();
			this.ClosingDateLabel = new Telerik.Reporting.TextBox();
			this.GroupFooterSection2 = new Telerik.Reporting.GroupFooterSection();
			this.GroupHeaderSection2 = new Telerik.Reporting.GroupHeaderSection();
			this.StatementNo = new Telerik.Reporting.TextBox();
			this.UnreconciledAmount1 = new Telerik.Reporting.TextBox();
			this.StatementClosingDate = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.DetailTable = new Telerik.Reporting.Crosstab();
			this.DocumentNo = new Telerik.Reporting.TextBox();
			this.DocumentDate = new Telerik.Reporting.TextBox();
			this.Description = new Telerik.Reporting.TextBox();
			this.Debit = new Telerik.Reporting.TextBox();
			this.Credit = new Telerik.Reporting.TextBox();
			this.CreditTotal = new Telerik.Reporting.TextBox();
			this.GroupHeaderDescription = new Telerik.Reporting.TextBox();
			this.Panel1 = new Telerik.Reporting.Panel();
			this.GroupFooterDescription = new Telerik.Reporting.TextBox();
			this.Panel2 = new Telerik.Reporting.Panel();
			this.GroupDescriptionCreditTotal = new Telerik.Reporting.TextBox();
			this.GroupDescriptionDebitTotal = new Telerik.Reporting.TextBox();
			this.Spacer2 = new Telerik.Reporting.TextBox();
			this.TotalsLabel = new Telerik.Reporting.TextBox();
			this.DebitTotal = new Telerik.Reporting.TextBox();
			this.ExpectedBalanceLabel = new Telerik.Reporting.TextBox();
			this.ExpectedBalance = new Telerik.Reporting.TextBox();
			this.UnreconciledAmountLabel = new Telerik.Reporting.TextBox();
			this.UnreconciledAmount = new Telerik.Reporting.TextBox();
			this.ClosingBalanceLabel = new Telerik.Reporting.TextBox();
			this.ClosingBalance = new Telerik.Reporting.TextBox();
			this.Pages = new Telerik.Reporting.TextBox();
			this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
			this.CreationTime = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// DocumentNoHeader
			// 
			this.DocumentNoHeader.Name = "DocumentNoHeader";
			this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNoHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentNoHeader.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNoHeader.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNoHeader.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNoHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNoHeader.Style.Font.Bold = true;
			this.DocumentNoHeader.Style.Font.Name = "Calibri";
			this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNoHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentNoHeader.StyleName = "Normal.TableHeader";
			this.DocumentNoHeader.Value = "Document No";
			// 
			// DocumentDateHeader
			// 
			this.DocumentDateHeader.Name = "DocumentDateHeader";
			this.DocumentDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDateHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDateHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentDateHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDateHeader.Style.Font.Bold = true;
			this.DocumentDateHeader.Style.Font.Name = "Calibri";
			this.DocumentDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDateHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDateHeader.StyleName = "Normal.TableHeader";
			this.DocumentDateHeader.Value = "Date";
			// 
			// DescriptionHeader
			// 
			this.DescriptionHeader.Name = "DescriptionHeader";
			this.DescriptionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DescriptionHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DescriptionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DescriptionHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DescriptionHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DescriptionHeader.Style.Font.Bold = true;
			this.DescriptionHeader.Style.Font.Name = "Calibri";
			this.DescriptionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DescriptionHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DescriptionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DescriptionHeader.StyleName = "Normal.TableHeader";
			this.DescriptionHeader.Value = "Description";
			// 
			// DebitHeader
			// 
			this.DebitHeader.Format = "";
			this.DebitHeader.Name = "DebitHeader";
			this.DebitHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DebitHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DebitHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DebitHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DebitHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DebitHeader.Style.Font.Bold = true;
			this.DebitHeader.Style.Font.Name = "Calibri";
			this.DebitHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DebitHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DebitHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.DebitHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DebitHeader.StyleName = "Normal.TableHeader";
			this.DebitHeader.Value = "Debit";
			// 
			// CreditHeader
			// 
			this.CreditHeader.Name = "CreditHeader";
			this.CreditHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CreditHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CreditHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CreditHeader.Style.Font.Bold = true;
			this.CreditHeader.Style.Font.Name = "Calibri";
			this.CreditHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreditHeader.StyleName = "Normal.TableHeader";
			this.CreditHeader.Value = "Credit";
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.PaymentOptionsPanel});
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			this.GroupFooterSection1.Style.Visible = false;
            // 
            // PaymentOptionsPanel
            // 
            this.PaymentOptionsPanel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.PaymentOptionsPanel.Name = "PaymentOptionsPanel";
			this.PaymentOptionsPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.PaymentOptionsPanel.Style.Visible = false;
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(3.6D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.BankAccountName,
            this.BankAccountBranch,
            this.BankAccountNo,
            this.ManagementReportHeaderSubReport2,
            this.GeneralLedgerAccount,
            this.BankAccountDescription,
            this.StatementLabel,
            this.UnreconciledAmountLabel1,
            this.Spacer1,
            this.ClosingDateLabel});
			this.GroupHeaderSection1.KeepTogether = false;
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = true;
			// 
			// BankAccountName
			// 
			this.BankAccountName.Format = "";
			this.BankAccountName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.BankAccountName.Name = "BankAccountName";
			this.BankAccountName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BankAccountName.Style.Font.Name = "Calibri";
			this.BankAccountName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BankAccountName.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BankAccountName.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BankAccountName.Value = "= \"Bank: \" + Fields.BankAccountName";
			// 
			// BankAccountBranch
			// 
			this.BankAccountBranch.Format = "";
			this.BankAccountBranch.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.BankAccountBranch.Name = "BankAccountBranch";
			this.BankAccountBranch.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BankAccountBranch.Style.Font.Name = "Calibri";
			this.BankAccountBranch.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BankAccountBranch.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BankAccountBranch.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BankAccountBranch.Value = "= \"Branch: \" + Fields.BankAccountBranch";
			// 
			// BankAccountNo
			// 
			this.BankAccountNo.Format = "";
			this.BankAccountNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(2D));
			this.BankAccountNo.Name = "BankAccountNo";
			this.BankAccountNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BankAccountNo.Style.Font.Name = "Calibri";
			this.BankAccountNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BankAccountNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BankAccountNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BankAccountNo.Value = "= \"Account No: \" + Fields.BankAccountNo";
			// 
			// ManagementReportHeaderSubReport2
			// 
			this.ManagementReportHeaderSubReport2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ManagementReportHeaderSubReport2.Name = "ManagementReportHeaderSubReport2";
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerName", "= Parameters.customerName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportName", "= Parameters.reportName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportDate", "= Parameters.reportDate.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("headerContent", "= Parameters.headerContent.Value"));
			typeReportSource1.TypeName = "Travelog.Reports.Common.ManagementReportHeaderSubReport2, Travelog.Reports, Versi" +
    "on=1.0.0.0, Culture=neutral, PublicKeyToken=null";
			this.ManagementReportHeaderSubReport2.ReportSource = typeReportSource1;
			this.ManagementReportHeaderSubReport2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ManagementReportHeaderSubReport2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// GeneralLedgerAccount
			// 
			this.GeneralLedgerAccount.Format = "";
			this.GeneralLedgerAccount.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.501D));
			this.GeneralLedgerAccount.Name = "GeneralLedgerAccount";
			this.GeneralLedgerAccount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.GeneralLedgerAccount.Style.Font.Name = "Calibri";
			this.GeneralLedgerAccount.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.GeneralLedgerAccount.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.GeneralLedgerAccount.Value = "= \"GL Account: \" + Fields.GeneralLedgerAccount";
			// 
			// BankAccountDescription
			// 
			this.BankAccountDescription.Format = "";
			this.BankAccountDescription.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.001D));
			this.BankAccountDescription.Name = "BankAccountDescription";
			this.BankAccountDescription.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BankAccountDescription.Style.Font.Name = "Calibri";
			this.BankAccountDescription.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BankAccountDescription.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BankAccountDescription.Value = "= \"Bank Account: \" + Fields.BankAccountDescription";
			// 
			// StatementLabel
			// 
			this.StatementLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.isSummary.Value, True, False)"));
			this.StatementLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.StatementLabel.Name = "StatementLabel";
			this.StatementLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.StatementLabel.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.StatementLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.StatementLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.StatementLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.StatementLabel.Style.Font.Bold = true;
			this.StatementLabel.Style.Font.Name = "Calibri";
			this.StatementLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.StatementLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.StatementLabel.StyleName = "Normal.TableHeader";
			this.StatementLabel.Value = "Statement";
			// 
			// UnreconciledAmountLabel1
			// 
			this.UnreconciledAmountLabel1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.isSummary.Value, True, False)"));
			this.UnreconciledAmountLabel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.6D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.UnreconciledAmountLabel1.Name = "UnreconciledAmountLabel1";
			this.UnreconciledAmountLabel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.UnreconciledAmountLabel1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.UnreconciledAmountLabel1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.UnreconciledAmountLabel1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.UnreconciledAmountLabel1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.UnreconciledAmountLabel1.Style.Font.Bold = true;
			this.UnreconciledAmountLabel1.Style.Font.Name = "Calibri";
			this.UnreconciledAmountLabel1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.UnreconciledAmountLabel1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.UnreconciledAmountLabel1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.UnreconciledAmountLabel1.StyleName = "Normal.TableHeader";
			this.UnreconciledAmountLabel1.Value = "Unreconciled Amount";
			// 
			// Spacer1
			// 
			this.Spacer1.Format = "";
			this.Spacer1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.5D));
			this.Spacer1.Name = "Spacer1";
			this.Spacer1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Spacer1.Style.Font.Name = "Calibri";
			this.Spacer1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Spacer1.Value = "";
			// 
			// ClosingDateLabel
			// 
			this.ClosingDateLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.isSummary.Value, True, False)"));
			this.ClosingDateLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.ClosingDateLabel.Name = "ClosingDateLabel";
			this.ClosingDateLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ClosingDateLabel.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ClosingDateLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ClosingDateLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ClosingDateLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ClosingDateLabel.Style.Font.Bold = true;
			this.ClosingDateLabel.Style.Font.Name = "Calibri";
			this.ClosingDateLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ClosingDateLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ClosingDateLabel.StyleName = "Normal.TableHeader";
			this.ClosingDateLabel.Value = "Closing Date";
			// 
			// GroupFooterSection2
			// 
			this.GroupFooterSection2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.BankStatementReconciliationDetailReportList.Count = 0 Or Parameters." +
            "isSummary.Value, False, True)"));
			this.GroupFooterSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupFooterSection2.Name = "GroupFooterSection2";
			this.GroupFooterSection2.PageBreak = Telerik.Reporting.PageBreak.After;
			// 
			// GroupHeaderSection2
			// 
			this.GroupHeaderSection2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.BankStatementReconciliationDetailReportList.Count = 0, False, True)"));
			this.GroupHeaderSection2.Bindings.Add(new Telerik.Reporting.Binding("Style.BackgroundColor", "= IIf(Parameters.isSummary.Value, \"Transparent\", \"WhiteSmoke\")"));
			this.GroupHeaderSection2.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Parameters.isSummary.Value, \"Solid\", \"None\")"));
			this.GroupHeaderSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupHeaderSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.StatementNo,
            this.UnreconciledAmount1,
            this.StatementClosingDate});
			this.GroupHeaderSection2.Name = "GroupHeaderSection2";
			this.GroupHeaderSection2.PrintOnEveryPage = true;
			this.GroupHeaderSection2.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupHeaderSection2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// StatementNo
			// 
			this.StatementNo.Bindings.Add(new Telerik.Reporting.Binding("Width", "= IIf(Parameters.isSummary.Value, \"8cm\", \"18cm\")"));
			this.StatementNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.StatementNo.Name = "StatementNo";
			this.StatementNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.StatementNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.StatementNo.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.StatementNo.Style.Font.Name = "Calibri";
			this.StatementNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.StatementNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.StatementNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.StatementNo.StyleName = "Normal.TableBody";
			this.StatementNo.Value = "= \"Statement No \" + Fields.StatementNo + \" - Closing Date: \" + Format(\"{0:dd-MMM-" +
    "yyyy}\", Fields.StatementClosingDate)";
			// 
			// UnreconciledAmount1
			// 
			this.UnreconciledAmount1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.isSummary.Value, True, False)"));
			this.UnreconciledAmount1.Format = "{0:c2}";
			this.UnreconciledAmount1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.6D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.UnreconciledAmount1.Name = "UnreconciledAmount1";
			this.UnreconciledAmount1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.UnreconciledAmount1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.UnreconciledAmount1.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.UnreconciledAmount1.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.UnreconciledAmount1.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.UnreconciledAmount1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.UnreconciledAmount1.Style.Font.Name = "Calibri";
			this.UnreconciledAmount1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.UnreconciledAmount1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.UnreconciledAmount1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.UnreconciledAmount1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.UnreconciledAmount1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.UnreconciledAmount1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.UnreconciledAmount1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.UnreconciledAmount1.StyleName = "Normal.TableBody";
			this.UnreconciledAmount1.Value = "= Fields.UnreconciledAmount";
			// 
			// StatementClosingDate
			// 
			this.StatementClosingDate.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.isSummary.Value, True, False)"));
			this.StatementClosingDate.Format = "{0:dd-MMM-yyyy}";
			this.StatementClosingDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.StatementClosingDate.Name = "StatementClosingDate";
			this.StatementClosingDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.StatementClosingDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.StatementClosingDate.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.StatementClosingDate.Style.Font.Name = "Calibri";
			this.StatementClosingDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.StatementClosingDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.StatementClosingDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.StatementClosingDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.StatementClosingDate.StyleName = "Normal.TableBody";
			this.StatementClosingDate.Value = "= Fields.StatementClosingDate";
			// 
			// Detail
			// 
			this.Detail.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.isSummary.Value Or Fields.BankStatementReconciliationDetailRepor" +
            "tList.Count = 0, False, True)"));
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(5.3D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailTable,
            this.ExpectedBalanceLabel,
            this.ExpectedBalance,
            this.UnreconciledAmountLabel,
            this.UnreconciledAmount,
            this.ClosingBalanceLabel,
            this.ClosingBalance});
			this.Detail.KeepTogether = false;
			this.Detail.Name = "Detail";
			// 
			// DetailTable
			// 
			this.DetailTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.BankStatementReconciliationDetailReportList"));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.1D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.5D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(7D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.7D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.7D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.5D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.SetCellContent(1, 0, this.DocumentNo);
			this.DetailTable.Body.SetCellContent(1, 1, this.DocumentDate);
			this.DetailTable.Body.SetCellContent(1, 2, this.Description);
			this.DetailTable.Body.SetCellContent(1, 3, this.Debit);
			this.DetailTable.Body.SetCellContent(1, 4, this.Credit);
			this.DetailTable.Body.SetCellContent(4, 4, this.CreditTotal);
			this.DetailTable.Body.SetCellContent(0, 0, this.GroupHeaderDescription, 1, 5);
			this.DetailTable.Body.SetCellContent(2, 0, this.Panel1, 1, 3);
			this.DetailTable.Body.SetCellContent(2, 4, this.Panel2);
			this.DetailTable.Body.SetCellContent(2, 3, this.GroupDescriptionDebitTotal);
			this.DetailTable.Body.SetCellContent(3, 0, this.Spacer2, 1, 5);
			this.DetailTable.Body.SetCellContent(4, 0, this.TotalsLabel, 1, 3);
			this.DetailTable.Body.SetCellContent(4, 3, this.DebitTotal);
			tableGroup1.Name = "tableGroup8";
			tableGroup1.ReportItem = this.DocumentNoHeader;
			tableGroup2.Name = "group";
			tableGroup2.ReportItem = this.DocumentDateHeader;
			tableGroup3.Name = "group1";
			tableGroup3.ReportItem = this.DescriptionHeader;
			tableGroup4.Name = "group2";
			tableGroup4.ReportItem = this.DebitHeader;
			tableGroup5.Name = "group7";
			tableGroup5.ReportItem = this.CreditHeader;
			this.DetailTable.ColumnGroups.Add(tableGroup1);
			this.DetailTable.ColumnGroups.Add(tableGroup2);
			this.DetailTable.ColumnGroups.Add(tableGroup3);
			this.DetailTable.ColumnGroups.Add(tableGroup4);
			this.DetailTable.ColumnGroups.Add(tableGroup5);
			this.DetailTable.ColumnHeadersPrintOnEveryPage = true;
			this.DetailTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderDescription,
            this.DocumentNo,
            this.DocumentDate,
            this.Description,
            this.Debit,
            this.Credit,
            this.Panel1,
            this.GroupDescriptionDebitTotal,
            this.Panel2,
            this.Spacer2,
            this.TotalsLabel,
            this.DebitTotal,
            this.CreditTotal,
            this.DocumentNoHeader,
            this.DocumentDateHeader,
            this.DescriptionHeader,
            this.DebitHeader,
            this.CreditHeader});
			this.DetailTable.KeepTogether = false;
			this.DetailTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DetailTable.Name = "DetailTable";
			this.DetailTable.NoDataMessage = "No records available.";
			tableGroup8.Name = "group9";
			tableGroup7.ChildGroups.Add(tableGroup8);
			tableGroup7.Name = "group8";
			tableGroup10.Name = "group6";
			tableGroup9.ChildGroups.Add(tableGroup10);
			tableGroup9.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup9.Name = "detailTableGroup";
			tableGroup12.Name = "group10";
			tableGroup11.ChildGroups.Add(tableGroup12);
			tableGroup11.Name = "group4";
			tableGroup14.Name = "group12";
			tableGroup13.ChildGroups.Add(tableGroup14);
			tableGroup13.Name = "group11";
			tableGroup6.ChildGroups.Add(tableGroup7);
			tableGroup6.ChildGroups.Add(tableGroup9);
			tableGroup6.ChildGroups.Add(tableGroup11);
			tableGroup6.ChildGroups.Add(tableGroup13);
			tableGroup6.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.GroupHeaderDescription"));
			tableGroup6.Name = "GroupHeaderDescriptionTable";
			tableGroup16.Name = "group3";
			tableGroup15.ChildGroups.Add(tableGroup16);
			tableGroup15.Name = "group5";
			this.DetailTable.RowGroups.Add(tableGroup6);
			this.DetailTable.RowGroups.Add(tableGroup15);
			this.DetailTable.RowHeadersPrintOnEveryPage = true;
			this.DetailTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(3.5D));
			// 
			// DocumentNo
			// 
			this.DocumentNo.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.DocumentNo = \"�\", \"None\", \"Solid\")"));
			this.DocumentNo.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Bold", "= IIf(Fields.DocumentNo = \"Reconciliation\", True, False)"));
			this.DocumentNo.Format = "";
			this.DocumentNo.Name = "DocumentNo";
			this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNo.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentNo.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNo.Style.Font.Name = "Calibri";
			this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentNo.StyleName = "Normal.TableBody";
			this.DocumentNo.Value = "= IIf(Fields.DocumentNo = \"�\", \"\", Fields.DocumentNo)";
			// 
			// DocumentDate
			// 
			this.DocumentDate.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.DocumentNo = \"�\", \"None\", \"Solid\")"));
			this.DocumentDate.Format = "{0:dd-MMM-yyyy}";
			this.DocumentDate.Name = "DocumentDate";
			this.DocumentDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDate.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentDate.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDate.Style.Font.Name = "Calibri";
			this.DocumentDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.StyleName = "Normal.TableBody";
			this.DocumentDate.Value = "= Fields.DocumentDate";
			// 
			// Description
			// 
			this.Description.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.DocumentNo = \"�\", \"None\", \"Solid\")"));
			this.Description.Name = "Description";
			this.Description.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Description.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Description.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Description.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Description.Style.Font.Name = "Calibri";
			this.Description.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Description.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Description.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Description.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Description.StyleName = "Normal.TableBody";
			this.Description.Value = "= Fields.Description";
			// 
			// Debit
			// 
			this.Debit.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.DocumentNo = \"�\", \"None\", \"Solid\")"));
			this.Debit.Format = "{0:c2}";
			this.Debit.Name = "Debit";
			this.Debit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Debit.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Debit.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Debit.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.Debit.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.Debit.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.Debit.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Debit.Style.Font.Name = "Calibri";
			this.Debit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Debit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Debit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Debit.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Debit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Debit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Debit.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Debit.StyleName = "Normal.TableBody";
			this.Debit.Value = "= Fields.Debit";
			// 
			// Credit
			// 
			this.Credit.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.DocumentNo = \"�\", \"None\", \"Solid\")"));
			this.Credit.Format = "{0:c2}";
			this.Credit.Name = "Credit";
			this.Credit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Credit.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Credit.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Credit.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.Credit.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.Credit.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.Credit.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Credit.Style.Font.Name = "Calibri";
			this.Credit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Credit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Credit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Credit.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Credit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Credit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Credit.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Credit.StyleName = "Normal.TableBody";
			this.Credit.Value = "= Fields.Credit";
			// 
			// CreditTotal
			// 
			this.CreditTotal.Format = "{0:c2}";
			this.CreditTotal.Name = "CreditTotal";
			this.CreditTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditTotal.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CreditTotal.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CreditTotal.Style.Font.Bold = true;
			this.CreditTotal.Style.Font.Name = "Calibri";
			this.CreditTotal.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditTotal.Style.Visible = false;
			this.CreditTotal.StyleName = "Normal.TableBody";
			this.CreditTotal.Value = "= Sum(IsNull(Fields.Credit, 0.00))";
			// 
			// GroupHeaderDescription
			// 
			this.GroupHeaderDescription.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.GroupHeaderDescription, \"\") = \"\" Or Fields.GroupHeaderDescrip" +
            "tion = \"�\", False, True)"));
			this.GroupHeaderDescription.Name = "GroupHeaderDescription";
			this.GroupHeaderDescription.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.GroupHeaderDescription.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupHeaderDescription.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderDescription.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.GroupHeaderDescription.Style.Font.Bold = true;
			this.GroupHeaderDescription.Style.Font.Name = "Calibri";
			this.GroupHeaderDescription.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.GroupHeaderDescription.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.GroupHeaderDescription.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.GroupHeaderDescription.StyleName = "Normal.TableBody";
			this.GroupHeaderDescription.Value = "= Fields.GroupHeaderDescription";
			// 
			// Panel1
			// 
			this.Panel1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.GroupHeaderDescription, \"\") = \"\" Or Fields.GroupHeaderDescrip" +
            "tion = \"�\", False, True)"));
			this.Panel1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupFooterDescription});
			this.Panel1.Name = "Panel1";
			this.Panel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			// 
			// GroupFooterDescription
			// 
			this.GroupFooterDescription.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.GroupFooterDescription.Name = "GroupFooterDescription";
			this.GroupFooterDescription.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.GroupFooterDescription.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupFooterDescription.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupFooterDescription.Style.Font.Bold = true;
			this.GroupFooterDescription.Style.Font.Name = "Calibri";
			this.GroupFooterDescription.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.GroupFooterDescription.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.GroupFooterDescription.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.GroupFooterDescription.StyleName = "Normal.TableBody";
			this.GroupFooterDescription.Value = "= Fields.GroupFooterDescription";
			// 
			// Panel2
			// 
			this.Panel2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.GroupHeaderDescription, \"\") = \"\" Or Fields.GroupHeaderDescrip" +
            "tion = \"�\", False, True)"));
			this.Panel2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupDescriptionCreditTotal});
			this.Panel2.Name = "Panel2";
			this.Panel2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			// 
			// GroupDescriptionCreditTotal
			// 
			this.GroupDescriptionCreditTotal.Format = "{0:c2}";
			this.GroupDescriptionCreditTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(-0.025D));
			this.GroupDescriptionCreditTotal.Name = "GroupDescriptionCreditTotal";
			this.GroupDescriptionCreditTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.GroupDescriptionCreditTotal.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupDescriptionCreditTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupDescriptionCreditTotal.Style.Font.Bold = true;
			this.GroupDescriptionCreditTotal.Style.Font.Name = "Calibri";
			this.GroupDescriptionCreditTotal.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.GroupDescriptionCreditTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.GroupDescriptionCreditTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.GroupDescriptionCreditTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.GroupDescriptionCreditTotal.StyleName = "Normal.TableBody";
			this.GroupDescriptionCreditTotal.Value = "= Sum(IsNull(Fields.Credit, 0.00))";
			// 
			// GroupDescriptionDebitTotal
			// 
			this.GroupDescriptionDebitTotal.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.GroupHeaderDescription, \"\") = \"\" Or Fields.GroupHeaderDescrip" +
            "tion = \"�\", False, True)"));
			this.GroupDescriptionDebitTotal.Format = "{0:c2}";
			this.GroupDescriptionDebitTotal.Name = "GroupDescriptionDebitTotal";
			this.GroupDescriptionDebitTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.GroupDescriptionDebitTotal.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupDescriptionDebitTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupDescriptionDebitTotal.Style.Font.Bold = true;
			this.GroupDescriptionDebitTotal.Style.Font.Name = "Calibri";
			this.GroupDescriptionDebitTotal.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.GroupDescriptionDebitTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.GroupDescriptionDebitTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.GroupDescriptionDebitTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.GroupDescriptionDebitTotal.StyleName = "Normal.TableBody";
			this.GroupDescriptionDebitTotal.Value = "= Sum(IsNull(Fields.Debit, 0.00))";
			// 
			// Spacer2
			// 
			this.Spacer2.Name = "Spacer2";
			this.Spacer2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Spacer2.StyleName = "";
			// 
			// TotalsLabel
			// 
			this.TotalsLabel.Name = "TotalsLabel";
			this.TotalsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalsLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalsLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TotalsLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TotalsLabel.Style.Font.Bold = true;
			this.TotalsLabel.Style.Font.Name = "Calibri";
			this.TotalsLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalsLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TotalsLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalsLabel.Style.Visible = false;
			this.TotalsLabel.StyleName = "Normal.TableBody";
			this.TotalsLabel.Value = "Totals";
			// 
			// DebitTotal
			// 
			this.DebitTotal.Format = "{0:c2}";
			this.DebitTotal.Name = "DebitTotal";
			this.DebitTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DebitTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DebitTotal.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DebitTotal.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DebitTotal.Style.Font.Bold = true;
			this.DebitTotal.Style.Font.Name = "Calibri";
			this.DebitTotal.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DebitTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DebitTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DebitTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.DebitTotal.Style.Visible = false;
			this.DebitTotal.StyleName = "Normal.TableBody";
			this.DebitTotal.Value = "= Sum(IsNull(Fields.Debit, 0.00))";
			// 
			// ExpectedBalanceLabel
			// 
			this.ExpectedBalanceLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 1, False, True)"));
			this.ExpectedBalanceLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.5D));
			this.ExpectedBalanceLabel.Name = "ExpectedBalanceLabel";
			this.ExpectedBalanceLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ExpectedBalanceLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ExpectedBalanceLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ExpectedBalanceLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ExpectedBalanceLabel.Style.Font.Bold = true;
			this.ExpectedBalanceLabel.Style.Font.Name = "Calibri";
			this.ExpectedBalanceLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ExpectedBalanceLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ExpectedBalanceLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ExpectedBalanceLabel.StyleName = "Normal.TableBody";
			this.ExpectedBalanceLabel.Value = "= IIf(Parameters.ledgerDocumentTypeId.Value = 3, \"Reconciled Closing Balance at \"" +
    ", \"Expected General Ledger Account Balance at \") + Format(\"{0:dd-MMM-yyyy}\", Fie" +
    "lds.StatementClosingDate)";
			// 
			// ExpectedBalance
			// 
			this.ExpectedBalance.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 1, False, True)"));
			this.ExpectedBalance.Format = "{0:c2}";
			this.ExpectedBalance.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.3D), Telerik.Reporting.Drawing.Unit.Cm(3.5D));
			this.ExpectedBalance.Name = "ExpectedBalance";
			this.ExpectedBalance.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ExpectedBalance.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ExpectedBalance.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ExpectedBalance.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ExpectedBalance.Style.Font.Bold = true;
			this.ExpectedBalance.Style.Font.Name = "Calibri";
			this.ExpectedBalance.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ExpectedBalance.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ExpectedBalance.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ExpectedBalance.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ExpectedBalance.StyleName = "Normal.TableBody";
			this.ExpectedBalance.Value = "= Fields.ExpectedBalance";
			// 
			// UnreconciledAmountLabel
			// 
			this.UnreconciledAmountLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 1, False, True)"));
			this.UnreconciledAmountLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.7D));
			this.UnreconciledAmountLabel.Name = "UnreconciledAmountLabel";
			this.UnreconciledAmountLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.UnreconciledAmountLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.UnreconciledAmountLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.UnreconciledAmountLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.UnreconciledAmountLabel.Style.Font.Bold = true;
			this.UnreconciledAmountLabel.Style.Font.Name = "Calibri";
			this.UnreconciledAmountLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.UnreconciledAmountLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.UnreconciledAmountLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.UnreconciledAmountLabel.StyleName = "Normal.TableBody";
			this.UnreconciledAmountLabel.Value = "Unreconciled Amount";
			// 
			// UnreconciledAmount
			// 
			this.UnreconciledAmount.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 1, False, True)"));
			this.UnreconciledAmount.Format = "{0:c2}";
			this.UnreconciledAmount.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.3D), Telerik.Reporting.Drawing.Unit.Cm(4.7D));
			this.UnreconciledAmount.Name = "UnreconciledAmount";
			this.UnreconciledAmount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.UnreconciledAmount.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.UnreconciledAmount.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.UnreconciledAmount.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.UnreconciledAmount.Style.Font.Bold = true;
			this.UnreconciledAmount.Style.Font.Name = "Calibri";
			this.UnreconciledAmount.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.UnreconciledAmount.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.UnreconciledAmount.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.UnreconciledAmount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.UnreconciledAmount.StyleName = "Normal.TableBody";
			this.UnreconciledAmount.Value = "= Fields.UnreconciledAmount";
			// 
			// ClosingBalanceLabel
			// 
			this.ClosingBalanceLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 3, True, False)"));
			this.ClosingBalanceLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.1D));
			this.ClosingBalanceLabel.Name = "ClosingBalanceLabel";
			this.ClosingBalanceLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ClosingBalanceLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ClosingBalanceLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ClosingBalanceLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ClosingBalanceLabel.Style.Font.Bold = true;
			this.ClosingBalanceLabel.Style.Font.Name = "Calibri";
			this.ClosingBalanceLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ClosingBalanceLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ClosingBalanceLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ClosingBalanceLabel.StyleName = "Normal.TableBody";
			this.ClosingBalanceLabel.Value = "= \"Actual Statement Closing Balance at \" + Format(\"{0:dd-MMM-yyyy}\", Fields.State" +
    "mentClosingDate)";
			// 
			// ClosingBalance
			// 
			this.ClosingBalance.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 3, True, False)"));
			this.ClosingBalance.Format = "{0:c2}";
			this.ClosingBalance.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.3D), Telerik.Reporting.Drawing.Unit.Cm(4.1D));
			this.ClosingBalance.Name = "ClosingBalance";
			this.ClosingBalance.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ClosingBalance.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ClosingBalance.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ClosingBalance.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ClosingBalance.Style.Font.Bold = true;
			this.ClosingBalance.Style.Font.Name = "Calibri";
			this.ClosingBalance.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ClosingBalance.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ClosingBalance.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ClosingBalance.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ClosingBalance.StyleName = "Normal.TableBody";
			this.ClosingBalance.Value = "= Fields.StatementClosingBalance";
			// 
			// Pages
			// 
			this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Name = "Pages";
			this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Style.Color = System.Drawing.Color.DarkGray;
			this.Pages.Style.Font.Name = "Calibri";
			this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Pages.Value = "= \"Page \" + PageNumber";
			// 
			// PageFooterSection
			// 
			this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
			this.PageFooterSection.Name = "PageFooterSection";
			// 
			// CreationTime
			// 
			this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Name = "CreationTime";
			this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
			this.CreationTime.Style.Font.Name = "Calibri";
			this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy" +
    " HH:mm}\", Parameters.creationTime.Value)";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "BankStatementReconciliationReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.Accounting.AccountingDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("ledgerDocumentTypeId", typeof(int), "= Parameters.ledgerDocumentTypeId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("bankAccountId", typeof(int), "= Parameters.bankAccountId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("statementNoFrom", typeof(int), "= Parameters.statementNoFrom.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("statementNoTo", typeof(int), "= Parameters.statementNoTo.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("periodTo", typeof(System.DateTime), "= Parameters.periodTo.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("descendingDateOrder", typeof(bool), "= Parameters.descendingDateOrder.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("unreconciledOnly", typeof(bool), "= Parameters.unreconciledOnly.Value"));
			// 
			// BankReconciliationReport
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.Name = "Group1";
			group1.Sortings.Add(new Telerik.Reporting.Sorting("= Fields.StatementNo", Telerik.Reporting.SortDirection.Desc));
			group2.GroupFooter = this.GroupFooterSection2;
			group2.GroupHeader = this.GroupHeaderSection2;
			group2.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.StatementNo"));
			group2.Name = "Group2";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.GroupHeaderSection2,
            this.GroupFooterSection2,
            this.Detail,
            this.PageFooterSection});
			this.Name = "BankReconciliationReport";
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "customerId";
			reportParameter2.Name = "agencyId";
			reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter3.Name = "customerName";
			reportParameter4.Name = "reportName";
			reportParameter5.Name = "reportDate";
			reportParameter6.Name = "headerContent";
			reportParameter7.Name = "creationUser";
			reportParameter8.Name = "creationTime";
			reportParameter8.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter9.Name = "ledgerDocumentTypeId";
			reportParameter9.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter10.Name = "bankAccountId";
			reportParameter10.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter11.Name = "statementNoFrom";
			reportParameter11.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter12.Name = "statementNoTo";
			reportParameter12.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter13.Name = "periodTo";
			reportParameter13.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter14.Name = "descendingDateOrder";
			reportParameter14.Type = Telerik.Reporting.ReportParameterType.Boolean;
			reportParameter15.Name = "unreconciledOnly";
			reportParameter15.Type = Telerik.Reporting.ReportParameterType.Boolean;
			reportParameter16.Name = "isSummary";
			reportParameter16.Type = Telerik.Reporting.ReportParameterType.Boolean;
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.ReportParameters.Add(reportParameter9);
			this.ReportParameters.Add(reportParameter10);
			this.ReportParameters.Add(reportParameter11);
			this.ReportParameters.Add(reportParameter12);
			this.ReportParameters.Add(reportParameter13);
			this.ReportParameters.Add(reportParameter14);
			this.ReportParameters.Add(reportParameter15);
			this.ReportParameters.Add(reportParameter16);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(18D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.Crosstab DetailTable;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox DocumentDate;
		private Telerik.Reporting.TextBox DocumentDateHeader;
		private Telerik.Reporting.TextBox Description;
		private Telerik.Reporting.TextBox Debit;
		private Telerik.Reporting.TextBox DebitHeader;
		private Telerik.Reporting.TextBox TotalsLabel;
		private Telerik.Reporting.Panel PaymentOptionsPanel;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.SubReport ManagementReportHeaderSubReport2;
		private Telerik.Reporting.TextBox BankAccountNo;
		private Telerik.Reporting.TextBox BankAccountBranch;
		private Telerik.Reporting.TextBox BankAccountName;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.TextBox CreditHeader;
		private Telerik.Reporting.TextBox Credit;
		private Telerik.Reporting.TextBox CreditTotal;
		private Telerik.Reporting.TextBox StatementNo;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection2;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection2;
		private Telerik.Reporting.TextBox GroupHeaderDescription;
		private Telerik.Reporting.Panel Panel1;
		private Telerik.Reporting.TextBox GroupFooterDescription;
		private Telerik.Reporting.Panel Panel2;
		private Telerik.Reporting.TextBox GroupDescriptionCreditTotal;
		private Telerik.Reporting.TextBox GroupDescriptionDebitTotal;
		private Telerik.Reporting.TextBox Spacer2;
		private Telerik.Reporting.TextBox GeneralLedgerAccount;
		private Telerik.Reporting.TextBox BankAccountDescription;
		private Telerik.Reporting.TextBox UnreconciledAmount1;
		private Telerik.Reporting.TextBox StatementClosingDate;
		private Telerik.Reporting.TextBox StatementLabel;
		private Telerik.Reporting.TextBox ClosingDateLabel;
		private Telerik.Reporting.TextBox UnreconciledAmountLabel1;
		private Telerik.Reporting.TextBox Spacer1;
		private Telerik.Reporting.TextBox DescriptionHeader;
		private Telerik.Reporting.TextBox ExpectedBalanceLabel;
		private Telerik.Reporting.TextBox ExpectedBalance;
		private Telerik.Reporting.TextBox UnreconciledAmount;
		private Telerik.Reporting.TextBox UnreconciledAmountLabel;
		private Telerik.Reporting.TextBox DebitTotal;
		private Telerik.Reporting.TextBox ClosingBalanceLabel;
		private Telerik.Reporting.TextBox ClosingBalance;
	}
}