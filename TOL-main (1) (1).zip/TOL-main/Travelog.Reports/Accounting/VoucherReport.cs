using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Resources;

namespace Travelog.Reports.Accounting {
	public partial class VoucherReport : TelerikReport {
		public VoucherReport() {
			InitializeComponent();
		}

		private void TaxNo_ItemDataBound(object sender, System.EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			if (textBox.Value.ToStringExt() != string.Empty)
				textBox.Value = string.Format("{0}: {1}", Resource.TaxNoLabel, textBox.Value);
		}
	}
}