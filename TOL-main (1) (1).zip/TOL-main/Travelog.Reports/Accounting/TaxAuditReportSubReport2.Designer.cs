namespace Travelog.Reports.Accounting {
	partial class TaxAuditReportSubReport2 {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.AmountGrossGrandTotal = new Telerik.Reporting.TextBox();
			this.AmountGrossGrandTotalLabel = new Telerik.Reporting.TextBox();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.GroupHeaderLabel = new Telerik.Reporting.TextBox();
			this.ChartOfAccountCodeHeader = new Telerik.Reporting.TextBox();
			this.ChartOfAccountHeader = new Telerik.Reporting.TextBox();
			this.TransactionTypeHeader = new Telerik.Reporting.TextBox();
			this.DocumentNoHeader = new Telerik.Reporting.TextBox();
			this.DocumentDateHeader = new Telerik.Reporting.TextBox();
			this.PayeeHeader = new Telerik.Reporting.TextBox();
			this.AmountGrossHeader = new Telerik.Reporting.TextBox();
			this.GroupFooterSection2 = new Telerik.Reporting.GroupFooterSection();
			this.AmountGrossTotal = new Telerik.Reporting.TextBox();
			this.AmountGrossTotalLabel = new Telerik.Reporting.TextBox();
			this.GroupHeaderSection2 = new Telerik.Reporting.GroupHeaderSection();
			this.FiscalPeriodName = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.TransactionType = new Telerik.Reporting.TextBox();
			this.DocumentNo = new Telerik.Reporting.TextBox();
			this.DocumentDate = new Telerik.Reporting.TextBox();
			this.AmountGross = new Telerik.Reporting.TextBox();
			this.Payee = new Telerik.Reporting.TextBox();
			this.ChartOfAccountCode = new Telerik.Reporting.TextBox();
			this.ChartOfAccountName = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AmountGrossGrandTotal,
            this.AmountGrossGrandTotalLabel});
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			this.GroupFooterSection1.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupFooterSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupFooterSection1.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupFooterSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// AmountGrossGrandTotal
			// 
			this.AmountGrossGrandTotal.Format = "{0:C2}";
			this.AmountGrossGrandTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountGrossGrandTotal.Name = "AmountGrossGrandTotal";
			this.AmountGrossGrandTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossGrandTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGrossGrandTotal.Style.Font.Bold = true;
			this.AmountGrossGrandTotal.Style.Font.Name = "Calibri";
			this.AmountGrossGrandTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGrossGrandTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountGrossGrandTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossGrandTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGrossGrandTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountGrossGrandTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountGrossGrandTotal.StyleName = "Normal.TableBody";
			this.AmountGrossGrandTotal.Value = "= Sum(Fields.AmountGross)";
			// 
			// AmountGrossGrandTotalLabel
			// 
			this.AmountGrossGrandTotalLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountGrossGrandTotalLabel.Name = "AmountGrossGrandTotalLabel";
			this.AmountGrossGrandTotalLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossGrandTotalLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGrossGrandTotalLabel.Style.Font.Bold = true;
			this.AmountGrossGrandTotalLabel.Style.Font.Name = "Calibri";
			this.AmountGrossGrandTotalLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGrossGrandTotalLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossGrandTotalLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGrossGrandTotalLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountGrossGrandTotalLabel.StyleName = "Normal.TableBody";
			this.AmountGrossGrandTotalLabel.Value = "= GroupHeader + \" Total\"";
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1.2D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderLabel,
            this.ChartOfAccountCodeHeader,
            this.ChartOfAccountHeader,
            this.TransactionTypeHeader,
            this.DocumentNoHeader,
            this.DocumentDateHeader,
            this.PayeeHeader,
            this.AmountGrossHeader});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = true;
			this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupHeaderSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.GroupHeaderSection1.Style.Font.Bold = false;
			// 
			// GroupHeaderLabel
			// 
			this.GroupHeaderLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.GroupHeaderLabel.Name = "GroupHeaderLabel";
			this.GroupHeaderLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.GroupHeaderLabel.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.GroupHeaderLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderLabel.Style.Font.Bold = true;
			this.GroupHeaderLabel.Style.Font.Name = "Calibri";
			this.GroupHeaderLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.GroupHeaderLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupHeaderLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.GroupHeaderLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupHeaderLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.GroupHeaderLabel.StyleName = "Normal.TableHeader";
			this.GroupHeaderLabel.Value = "= GroupHeader";
			// 
			// ChartOfAccountCodeHeader
			// 
			this.ChartOfAccountCodeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountCodeHeader.Name = "ChartOfAccountCodeHeader";
			this.ChartOfAccountCodeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountCodeHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.ChartOfAccountCodeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountCodeHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ChartOfAccountCodeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ChartOfAccountCodeHeader.Style.Font.Name = "Calibri";
			this.ChartOfAccountCodeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountCodeHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ChartOfAccountCodeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountCodeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ChartOfAccountCodeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ChartOfAccountCodeHeader.StyleName = "Normal.TableHeader";
			this.ChartOfAccountCodeHeader.Value = "Code";
			// 
			// ChartOfAccountHeader
			// 
			this.ChartOfAccountHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountHeader.Name = "ChartOfAccountHeader";
			this.ChartOfAccountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.ChartOfAccountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ChartOfAccountHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ChartOfAccountHeader.Style.Font.Name = "Calibri";
			this.ChartOfAccountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ChartOfAccountHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ChartOfAccountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ChartOfAccountHeader.StyleName = "Normal.TableHeader";
			this.ChartOfAccountHeader.Value = "Account";
			// 
			// TransactionTypeHeader
			// 
			this.TransactionTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TransactionTypeHeader.Name = "TransactionTypeHeader";
			this.TransactionTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TransactionTypeHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.TransactionTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TransactionTypeHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TransactionTypeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TransactionTypeHeader.Style.Font.Name = "Calibri";
			this.TransactionTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TransactionTypeHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TransactionTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TransactionTypeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TransactionTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TransactionTypeHeader.StyleName = "Normal.TableHeader";
			this.TransactionTypeHeader.Value = "Transaction Type";
			// 
			// DocumentNoHeader
			// 
			this.DocumentNoHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Name = "DocumentNoHeader";
			this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNoHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentNoHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNoHeader.Style.Font.Name = "Calibri";
			this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNoHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentNoHeader.StyleName = "Normal.TableHeader";
			this.DocumentNoHeader.Value = "Document No";
			// 
			// DocumentDateHeader
			// 
			this.DocumentDateHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDateHeader.Name = "DocumentDateHeader";
			this.DocumentDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDateHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.DocumentDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDateHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentDateHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDateHeader.Style.Font.Name = "Calibri";
			this.DocumentDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDateHeader.StyleName = "Normal.TableHeader";
			this.DocumentDateHeader.Value = "Document Date";
			// 
			// PayeeHeader
			// 
			this.PayeeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.PayeeHeader.Name = "PayeeHeader";
			this.PayeeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.PayeeHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.PayeeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.PayeeHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.PayeeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.PayeeHeader.Style.Font.Name = "Calibri";
			this.PayeeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PayeeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.PayeeHeader.StyleName = "Normal.TableHeader";
			this.PayeeHeader.Value = "Payee";
			// 
			// AmountGrossHeader
			// 
			this.AmountGrossHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossHeader.Name = "AmountGrossHeader";
			this.AmountGrossHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.AmountGrossHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGrossHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AmountGrossHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AmountGrossHeader.Style.Font.Name = "Calibri";
			this.AmountGrossHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGrossHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountGrossHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountGrossHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AmountGrossHeader.StyleName = "Normal.TableHeader";
			this.AmountGrossHeader.Value = "Gross (ex Tax)";
			this.AmountGrossHeader.ItemDataBound += new System.EventHandler(this.AmountGrossHeader_ItemDataBound);
			// 
			// GroupFooterSection2
			// 
			this.GroupFooterSection2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.FiscalPeriodName = \"\", False, True)"));
			this.GroupFooterSection2.CanShrink = true;
			this.GroupFooterSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupFooterSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AmountGrossTotal,
            this.AmountGrossTotalLabel});
			this.GroupFooterSection2.Name = "GroupFooterSection2";
			this.GroupFooterSection2.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupFooterSection2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupFooterSection2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupFooterSection2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// AmountGrossTotal
			// 
			this.AmountGrossTotal.Format = "{0:C2}";
			this.AmountGrossTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountGrossTotal.Name = "AmountGrossTotal";
			this.AmountGrossTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGrossTotal.Style.Font.Bold = false;
			this.AmountGrossTotal.Style.Font.Name = "Calibri";
			this.AmountGrossTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGrossTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountGrossTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGrossTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountGrossTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountGrossTotal.StyleName = "Normal.TableBody";
			this.AmountGrossTotal.Value = "= Sum(Fields.AmountGross)";
			// 
			// AmountGrossTotalLabel
			// 
			this.AmountGrossTotalLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountGrossTotalLabel.Name = "AmountGrossTotalLabel";
			this.AmountGrossTotalLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossTotalLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGrossTotalLabel.Style.Font.Bold = false;
			this.AmountGrossTotalLabel.Style.Font.Name = "Calibri";
			this.AmountGrossTotalLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGrossTotalLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossTotalLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGrossTotalLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountGrossTotalLabel.StyleName = "Normal.TableBody";
			this.AmountGrossTotalLabel.Value = "= Fields.FiscalPeriodName + \" Total\"";
			// 
			// GroupHeaderSection2
			// 
			this.GroupHeaderSection2.Bindings.Add(new Telerik.Reporting.Binding("Style.TextAlign", "= IIf(Fields.FiscalPeriodName = \"\", 1, 0)"));
			this.GroupHeaderSection2.Bindings.Add(new Telerik.Reporting.Binding("Style.BackgroundColor", "= IIf(Fields.FiscalPeriodName = \"\", \"White\", \"WhiteSmoke\")"));
			this.GroupHeaderSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupHeaderSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.FiscalPeriodName});
			this.GroupHeaderSection2.Name = "GroupHeaderSection2";
			this.GroupHeaderSection2.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupHeaderSection2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupHeaderSection2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// FiscalPeriodName
			// 
			this.FiscalPeriodName.CanShrink = true;
			this.FiscalPeriodName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.FiscalPeriodName.Name = "FiscalPeriodName";
			this.FiscalPeriodName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.FiscalPeriodName.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.FiscalPeriodName.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.FiscalPeriodName.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.FiscalPeriodName.Style.Font.Bold = false;
			this.FiscalPeriodName.Style.Font.Name = "Calibri";
			this.FiscalPeriodName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.FiscalPeriodName.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.FiscalPeriodName.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.FiscalPeriodName.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.FiscalPeriodName.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.FiscalPeriodName.Value = "= IIf(Fields.FiscalPeriodName = \"\", \"NO DATA AVAILABLE\", Fields.FiscalPeriodName)" +
    "";
			// 
			// Detail
			// 
			this.Detail.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.FiscalPeriodName = \"\", False, True)"));
			this.Detail.CanShrink = true;
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TransactionType,
            this.DocumentNo,
            this.DocumentDate,
            this.AmountGross,
            this.Payee,
            this.ChartOfAccountCode,
            this.ChartOfAccountName});
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// TransactionType
			// 
			this.TransactionType.CanShrink = true;
			this.TransactionType.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TransactionType.Name = "TransactionType";
			this.TransactionType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TransactionType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TransactionType.Style.Font.Bold = false;
			this.TransactionType.Style.Font.Name = "Calibri";
			this.TransactionType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TransactionType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TransactionType.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TransactionType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TransactionType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TransactionType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TransactionType.StyleName = "Normal.TableBody";
			this.TransactionType.Value = "= Fields.TransactionType";
			// 
			// DocumentNo
			// 
			this.DocumentNo.CanShrink = true;
			this.DocumentNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentNo.Name = "DocumentNo";
			this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNo.Style.Font.Bold = false;
			this.DocumentNo.Style.Font.Name = "Calibri";
			this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentNo.StyleName = "Normal.TableBody";
			this.DocumentNo.Value = "= Fields.DocumentNo";
			// 
			// DocumentDate
			// 
			this.DocumentDate.Format = "{0:dd-MMM-yyyy}";
			this.DocumentDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentDate.Name = "DocumentDate";
			this.DocumentDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDate.Style.Font.Bold = false;
			this.DocumentDate.Style.Font.Name = "Calibri";
			this.DocumentDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentDate.StyleName = "Normal.TableBody";
			this.DocumentDate.Value = "= IIf(Fields.DocumentDate = Date(1, 1, 1), Null, Fields.DocumentDate)";
			// 
			// AmountGross
			// 
			this.AmountGross.Format = "{0:C2}";
			this.AmountGross.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountGross.Name = "AmountGross";
			this.AmountGross.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGross.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGross.Style.Font.Bold = false;
			this.AmountGross.Style.Font.Name = "Calibri";
			this.AmountGross.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGross.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGross.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountGross.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGross.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountGross.StyleName = "Normal.TableBody";
			this.AmountGross.Value = "= Fields.AmountGross";
			// 
			// Payee
			// 
			this.Payee.Format = "{0:dd-MMM-yyyy}";
			this.Payee.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Payee.Name = "Payee";
			this.Payee.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Payee.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Payee.Style.Font.Bold = false;
			this.Payee.Style.Font.Name = "Calibri";
			this.Payee.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Payee.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Payee.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Payee.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Payee.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Payee.StyleName = "Normal.TableBody";
			this.Payee.Value = "= Fields.Payee";
			// 
			// ChartOfAccountCode
			// 
			this.ChartOfAccountCode.CanShrink = true;
			this.ChartOfAccountCode.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ChartOfAccountCode.Name = "ChartOfAccountCode";
			this.ChartOfAccountCode.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountCode.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountCode.Style.Font.Bold = false;
			this.ChartOfAccountCode.Style.Font.Name = "Calibri";
			this.ChartOfAccountCode.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountCode.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ChartOfAccountCode.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountCode.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ChartOfAccountCode.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ChartOfAccountCode.StyleName = "Normal.TableBody";
			this.ChartOfAccountCode.TextWrap = false;
			this.ChartOfAccountCode.Value = "= Fields.ChartOfAccountCode";
			// 
			// ChartOfAccountName
			// 
			this.ChartOfAccountName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ChartOfAccountName.Name = "ChartOfAccountName";
			this.ChartOfAccountName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountName.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountName.Style.Font.Bold = false;
			this.ChartOfAccountName.Style.Font.Name = "Calibri";
			this.ChartOfAccountName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountName.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ChartOfAccountName.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountName.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ChartOfAccountName.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ChartOfAccountName.StyleName = "Normal.TableBody";
			this.ChartOfAccountName.TextWrap = false;
			this.ChartOfAccountName.Value = "= Fields.ChartOfAccountName";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "TaxAuditReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.Accounting.AccountingDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("reportGroupId", typeof(int), "= Parameters.reportGroupId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateFrom", typeof(System.DateTime), "= Parameters.dateFrom.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateTo", typeof(System.DateTime), "= Parameters.dateTo.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("descendingDateOrder", typeof(bool), "= Parameters.descendingDateOrder.Value"));
			// 
			// TaxAuditReportSubReport2
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			group2.GroupFooter = this.GroupFooterSection2;
			group2.GroupHeader = this.GroupHeaderSection2;
			group2.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.FiscalPeriod"));
			group2.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group2.Name = "Group2";
			group2.Sortings.Add(new Telerik.Reporting.Sorting("= Fields.FiscalPeriod", Telerik.Reporting.SortDirection.Asc));
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.GroupHeaderSection2,
            this.GroupFooterSection2,
            this.Detail});
			this.Name = "TaxAuditReportSubReport2";
			this.PageSettings.Landscape = true;
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "userName";
			reportParameter3.Name = "customerId";
			reportParameter3.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter4.Name = "agencyId";
			reportParameter4.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter5.Name = "reportGroupId";
			reportParameter5.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter6.AllowNull = true;
			reportParameter6.Name = "dateFrom";
			reportParameter6.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter7.AllowNull = true;
			reportParameter7.Name = "dateTo";
			reportParameter7.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter8.Name = "descendingDateOrder";
			reportParameter8.Type = Telerik.Reporting.ReportParameterType.Boolean;
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.Style.Font.Bold = true;
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(27.7D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.TextBox AmountGrossGrandTotalLabel;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox DocumentDateHeader;
		private Telerik.Reporting.TextBox TransactionTypeHeader;
		private Telerik.Reporting.TextBox TransactionType;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox DocumentDate;
		private Telerik.Reporting.TextBox AmountGrossHeader;
		private Telerik.Reporting.TextBox AmountGrossGrandTotal;
		private Telerik.Reporting.TextBox AmountGross;
		private Telerik.Reporting.TextBox GroupHeaderLabel;
		private Telerik.Reporting.TextBox PayeeHeader;
		private Telerik.Reporting.TextBox Payee;
		private Telerik.Reporting.TextBox ChartOfAccountHeader;
		private Telerik.Reporting.TextBox ChartOfAccountCodeHeader;
		private Telerik.Reporting.TextBox ChartOfAccountCode;
		private Telerik.Reporting.TextBox ChartOfAccountName;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection2;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection2;
		private Telerik.Reporting.TextBox FiscalPeriodName;
		private Telerik.Reporting.TextBox AmountGrossTotalLabel;
		private Telerik.Reporting.TextBox AmountGrossTotal;
	}
}