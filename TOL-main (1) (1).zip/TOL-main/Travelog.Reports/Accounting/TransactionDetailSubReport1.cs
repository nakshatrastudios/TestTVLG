using Telerik.Reporting;

namespace Travelog.Reports.Accounting {

	public partial class TransactionDetailSubReport1 : TelerikReport {
		public TransactionDetailSubReport1() {
			InitializeComponent();
		}
	}
}