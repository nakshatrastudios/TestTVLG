using Telerik.Reporting;

namespace Travelog.Reports.DebtorLedger {
	public partial class BankReconciliationReport : TelerikReport {
		public BankReconciliationReport() {
			InitializeComponent();
		}
	}
}