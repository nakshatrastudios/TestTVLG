using System.Drawing;

namespace Travelog.Reports.Accounting {
	partial class InvoiceReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
            Telerik.Reporting.NavigateToUrlAction navigateToUrlAction1 = new Telerik.Reporting.NavigateToUrlAction();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InvoiceReport));
            Telerik.Reporting.NavigateToUrlAction navigateToUrlAction2 = new Telerik.Reporting.NavigateToUrlAction();
            Telerik.Reporting.TypeReportSource typeReportSource2 = new Telerik.Reporting.TypeReportSource();
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup10 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup11 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup12 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup13 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup14 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TypeReportSource typeReportSource3 = new Telerik.Reporting.TypeReportSource();
            Telerik.Reporting.TypeReportSource typeReportSource4 = new Telerik.Reporting.TypeReportSource();
            Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
            Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
            Telerik.Reporting.Group group3 = new Telerik.Reporting.Group();
            Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter11 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter12 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter13 = new Telerik.Reporting.ReportParameter();
            this.AccountNoHeader = new Telerik.Reporting.TextBox();
            this.DescriptionHeader = new Telerik.Reporting.TextBox();
            this.AmountHeader = new Telerik.Reporting.TextBox();
            this.TaxAppliesHeader = new Telerik.Reporting.TextBox();
            this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
            this.AgencyFooterSubReport = new Telerik.Reporting.SubReport();
            this.DepositLabel = new Telerik.Reporting.TextBox();
            this.Deposit = new Telerik.Reporting.TextBox();
            this.PaymentTerms = new Telerik.Reporting.TextBox();
            this.PaymentTermsLabel = new Telerik.Reporting.TextBox();
            this.PaymentOptions = new Telerik.Reporting.TextBox();
            this.PayId = new Telerik.Reporting.TextBox();
            this.PaymentOptionsLabel = new Telerik.Reporting.TextBox();
            this.TravelPayLogo = new Telerik.Reporting.PictureBox();
            this.PayIdLogo = new Telerik.Reporting.PictureBox();
            this.MintLogo = new Telerik.Reporting.PictureBox();
            this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
            this.AgencyHeaderSubReport1 = new Telerik.Reporting.SubReport();
            this.HeaderPanel1 = new Telerik.Reporting.Panel();
            this.ReportNameLabel = new Telerik.Reporting.TextBox();
            this.BookingNo = new Telerik.Reporting.TextBox();
            this.HeaderPanel2 = new Telerik.Reporting.Panel();
            this.TaxNo = new Telerik.Reporting.TextBox();
            this.OrderNo = new Telerik.Reporting.TextBox();
            this.InvoiceDate = new Telerik.Reporting.TextBox();
            this.DueDate = new Telerik.Reporting.TextBox();
            this.DepartureDate = new Telerik.Reporting.TextBox();
            this.ContactName = new Telerik.Reporting.TextBox();
            this.GroupFooterSection2 = new Telerik.Reporting.GroupFooterSection();
            this.BalanceDueLabel = new Telerik.Reporting.TextBox();
            this.BalanceDue = new Telerik.Reporting.TextBox();
            this.InvoiceSummaryPanel = new Telerik.Reporting.Panel();
            this.DetailTable = new Telerik.Reporting.Table();
            this.Description = new Telerik.Reporting.TextBox();
            this.AccountNo = new Telerik.Reporting.TextBox();
            this.Amount = new Telerik.Reporting.TextBox();
            this.TaxApplies = new Telerik.Reporting.TextBox();
            this.SubTotalLabel = new Telerik.Reporting.TextBox();
            this.SubTotal = new Telerik.Reporting.TextBox();
            this.TotalDiscountLabel = new Telerik.Reporting.TextBox();
            this.DiscountTotal = new Telerik.Reporting.TextBox();
            this.TotalTaxLabel = new Telerik.Reporting.TextBox();
            this.TotalTax = new Telerik.Reporting.TextBox();
            this.TotalAmountLabel = new Telerik.Reporting.TextBox();
            this.TotalAmount = new Telerik.Reporting.TextBox();
            this.ForeignCurrencyTotalAmountLabel = new Telerik.Reporting.TextBox();
            this.ForeignCurrencyTotalAmount = new Telerik.Reporting.TextBox();
            this.AgentCommissionTotalLabel = new Telerik.Reporting.TextBox();
            this.AgentCommissionTotal = new Telerik.Reporting.TextBox();
            this.PaymentTable = new Telerik.Reporting.Table();
            this.PaymentDescription = new Telerik.Reporting.TextBox();
            this.PaymentAmount = new Telerik.Reporting.TextBox();
            this.InvoicesPaymentsReceiptsHeader1 = new Telerik.Reporting.TextBox();
            this.InvoicesPaymentsReceiptsHeader2 = new Telerik.Reporting.TextBox();
            this.StatementSummaryPanel = new Telerik.Reporting.Panel();
            this.SubTotal2 = new Telerik.Reporting.TextBox();
            this.SubTotal1 = new Telerik.Reporting.TextBox();
            this.TotalDiscount1 = new Telerik.Reporting.TextBox();
            this.TotalDiscount2 = new Telerik.Reporting.TextBox();
            this.TaxTotal1 = new Telerik.Reporting.TextBox();
            this.TaxTotal2 = new Telerik.Reporting.TextBox();
            this.OtherInclusionTotal1 = new Telerik.Reporting.TextBox();
            this.OtherInclusionTotal2 = new Telerik.Reporting.TextBox();
            this.ServiceFeeTotal1 = new Telerik.Reporting.TextBox();
            this.ServiceFeeTotal2 = new Telerik.Reporting.TextBox();
            this.ForeignCurrencyTotal1 = new Telerik.Reporting.TextBox();
            this.ForeignCurrencyTotal2 = new Telerik.Reporting.TextBox();
            this.AccommodationTotal1 = new Telerik.Reporting.TextBox();
            this.AirTotal1 = new Telerik.Reporting.TextBox();
            this.AccommodationTotal2 = new Telerik.Reporting.TextBox();
            this.AirTotal2 = new Telerik.Reporting.TextBox();
            this.InsuranceTotal2 = new Telerik.Reporting.TextBox();
            this.InsuranceTotal1 = new Telerik.Reporting.TextBox();
            this.CruiseTotal1 = new Telerik.Reporting.TextBox();
            this.CruiseTotal2 = new Telerik.Reporting.TextBox();
            this.TransportTotal1 = new Telerik.Reporting.TextBox();
            this.TransportTotal2 = new Telerik.Reporting.TextBox();
            this.OtherLandTotal1 = new Telerik.Reporting.TextBox();
            this.OtherLandTotal2 = new Telerik.Reporting.TextBox();
            this.TourTotal1 = new Telerik.Reporting.TextBox();
            this.TourTotal2 = new Telerik.Reporting.TextBox();
            this.TotalsHeader = new Telerik.Reporting.TextBox();
            this.StatementTotal2 = new Telerik.Reporting.TextBox();
            this.StatementTotal1 = new Telerik.Reporting.TextBox();
            this.TaxAppliesLabel = new Telerik.Reporting.TextBox();
            this.AgentCommission1 = new Telerik.Reporting.TextBox();
            this.AgentCommission2 = new Telerik.Reporting.TextBox();
            this.PackageTotal1 = new Telerik.Reporting.TextBox();
            this.PackageTotal2 = new Telerik.Reporting.TextBox();
            this.TransportTotal3 = new Telerik.Reporting.TextBox();
            this.CruiseTotal3 = new Telerik.Reporting.TextBox();
            this.InsuranceTotal3 = new Telerik.Reporting.TextBox();
            this.ForeignCurrencyTotal3 = new Telerik.Reporting.TextBox();
            this.TourTotal3 = new Telerik.Reporting.TextBox();
            this.OtherLandTotal3 = new Telerik.Reporting.TextBox();
            this.ServiceFeeTotal3 = new Telerik.Reporting.TextBox();
            this.OtherInclusionTotal3 = new Telerik.Reporting.TextBox();
            this.AccommodationTotal3 = new Telerik.Reporting.TextBox();
            this.AirTotal3 = new Telerik.Reporting.TextBox();
            this.PackageTotal3 = new Telerik.Reporting.TextBox();
            this.PaymentScheduleTable = new Telerik.Reporting.Table();
            this.PaymentScheduleTransactionDate = new Telerik.Reporting.TextBox();
            this.PaymentScheduleCredit = new Telerik.Reporting.TextBox();
            this.PaymentScheduleHeader1 = new Telerik.Reporting.TextBox();
            this.PaymentScheduleHeader3 = new Telerik.Reporting.TextBox();
            this.PaymentScheduleHeader2 = new Telerik.Reporting.TextBox();
            this.PaymentScheduleDescription = new Telerik.Reporting.TextBox();
            this.GroupHeaderSection2 = new Telerik.Reporting.GroupHeaderSection();
            this.AgencyHeaderSubReport2 = new Telerik.Reporting.SubReport();
            this.DebtorCodePanel = new Telerik.Reporting.Panel();
            this.Code = new Telerik.Reporting.TextBox();
            this.SubDebtor = new Telerik.Reporting.TextBox();
            this.DebtorNameAddressPanel = new Telerik.Reporting.Panel();
            this.Debtor = new Telerik.Reporting.TextBox();
            this.Address = new Telerik.Reporting.TextBox();
            this.PassengersLabel = new Telerik.Reporting.TextBox();
            this.Passengers = new Telerik.Reporting.TextBox();
            this.GroupFooterSection3 = new Telerik.Reporting.GroupFooterSection();
            this.GroupHeaderSection3 = new Telerik.Reporting.GroupHeaderSection();
            this.ConfirmationSubReport = new Telerik.Reporting.SubReport();
            this.Detail = new Telerik.Reporting.DetailSection();
            this.Pages = new Telerik.Reporting.TextBox();
            this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
            this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // AccountNoHeader
            // 
            this.AccountNoHeader.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AccountNo = \"\", False, True)"));
            this.AccountNoHeader.Name = "AccountNoHeader";
            this.AccountNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AccountNoHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AccountNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AccountNoHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AccountNoHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AccountNoHeader.Style.Font.Bold = true;
            this.AccountNoHeader.Style.Font.Name = "Calibri";
            this.AccountNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AccountNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.AccountNoHeader.StyleName = "Normal.TableHeader";
            this.AccountNoHeader.Value = "Account No";
            // 
            // DescriptionHeader
            // 
            this.DescriptionHeader.Bindings.Add(new Telerik.Reporting.Binding("Width", "= IIf(Fields.AccountNo = \"\", \"15cm\", \"12cm\")"));
            this.DescriptionHeader.Name = "DescriptionHeader";
            this.DescriptionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DescriptionHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.DescriptionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DescriptionHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DescriptionHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DescriptionHeader.Style.Font.Bold = true;
            this.DescriptionHeader.Style.Font.Name = "Calibri";
            this.DescriptionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DescriptionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DescriptionHeader.StyleName = "Normal.TableHeader";
            this.DescriptionHeader.Value = "Description";
            // 
            // AmountHeader
            // 
            this.AmountHeader.Name = "AmountHeader";
            this.AmountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AmountHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AmountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AmountHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AmountHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AmountHeader.Style.Font.Bold = true;
            this.AmountHeader.Style.Font.Name = "Calibri";
            this.AmountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AmountHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AmountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.AmountHeader.StyleName = "Normal.TableHeader";
            this.AmountHeader.Value = "Amount";
            // 
            // TaxAppliesHeader
            // 
            this.TaxAppliesHeader.Name = "TaxAppliesHeader";
            this.TaxAppliesHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TaxAppliesHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TaxAppliesHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TaxAppliesHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TaxAppliesHeader.Style.Font.Bold = true;
            this.TaxAppliesHeader.Style.Font.Name = "Calibri";
            this.TaxAppliesHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TaxAppliesHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TaxAppliesHeader.StyleName = "Normal.TableHeader";
            // 
            // GroupFooterSection1
            // 
            this.GroupFooterSection1.CanShrink = true;
            this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(7D);
            this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AgencyFooterSubReport,
            this.DepositLabel,
            this.Deposit,
            this.PaymentTerms,
            this.PaymentTermsLabel,
            this.PaymentOptions,
            this.PayId,
            this.PaymentOptionsLabel,
            this.TravelPayLogo,
            this.PayIdLogo,
            this.MintLogo});
            this.GroupFooterSection1.Name = "GroupFooterSection1";
            // 
            // AgencyFooterSubReport
            // 
            this.AgencyFooterSubReport.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(6D));
            this.AgencyFooterSubReport.Name = "AgencyFooterSubReport";
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
            typeReportSource1.TypeName = "Travelog.Reports.Common.AgencyFooterSubReport, Travelog.Reports, Version=1.0.0.0," +
    " Culture=neutral, PublicKeyToken=null";
            this.AgencyFooterSubReport.ReportSource = typeReportSource1;
            this.AgencyFooterSubReport.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.AgencyFooterSubReport.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AgencyFooterSubReport.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.25D);
            // 
            // DepositLabel
            // 
            this.DepositLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.DepositDetails, \"\") = \"\", False, True)"));
            this.DepositLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.DepositLabel.Name = "DepositLabel";
            this.DepositLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.DepositLabel.Style.Font.Bold = true;
            this.DepositLabel.Style.Font.Name = "Calibri";
            this.DepositLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DepositLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.DepositLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DepositLabel.Value = "Deposit";
            // 
            // Deposit
            // 
            this.Deposit.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.DepositDetails, \"\") = \"\", False, True)"));
            this.Deposit.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Deposit.Name = "Deposit";
            this.Deposit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.Deposit.Style.Font.Name = "Calibri";
            this.Deposit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Deposit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
            this.Deposit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.Deposit.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Deposit.Value = "= Fields.DepositDetails";
            // 
            // PaymentTerms
            // 
            this.PaymentTerms.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.PaymentTerms, \"\") = \"\", False, True)"));
            this.PaymentTerms.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2D));
            this.PaymentTerms.Name = "PaymentTerms";
            this.PaymentTerms.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PaymentTerms.Style.Font.Name = "Calibri";
            this.PaymentTerms.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PaymentTerms.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
            this.PaymentTerms.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.PaymentTerms.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PaymentTerms.Value = "= Fields.PaymentTerms";
            // 
            // PaymentTermsLabel
            // 
            this.PaymentTermsLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.PaymentTerms, \"\") = \"\", False, True)"));
            this.PaymentTermsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
            this.PaymentTermsLabel.Name = "PaymentTermsLabel";
            this.PaymentTermsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.PaymentTermsLabel.Style.Font.Bold = true;
            this.PaymentTermsLabel.Style.Font.Name = "Calibri";
            this.PaymentTermsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PaymentTermsLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.PaymentTermsLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PaymentTermsLabel.Value = "Payment Terms";
            // 
            // PaymentOptions
            // 
            this.PaymentOptions.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.PaymentOptions, \"\") = \"\", False, True)"));
            this.PaymentOptions.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.5D));
            this.PaymentOptions.Name = "PaymentOptions";
            this.PaymentOptions.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PaymentOptions.Style.Font.Name = "Calibri";
            this.PaymentOptions.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PaymentOptions.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
            this.PaymentOptions.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.PaymentOptions.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PaymentOptions.Value = "= Fields.PaymentOptions";
            // 
            // PayId
            // 
            this.PayId.CanGrow = false;
            this.PayId.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.5D));
            this.PayId.Name = "PayId";
            this.PayId.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.PayId.Style.Font.Italic = true;
            this.PayId.Style.Font.Name = "Calibri";
            this.PayId.Value = "= IIf(IsNull(Fields.PayId, \"\")=\"\", \"\", Fields.PayIdLabel + \": \" + Fields.PayId)";
            // 
            // PaymentOptionsLabel
            // 
            this.PaymentOptionsLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.PaymentOptions, \"\")=\"\" And IsNull(Fields.PayId, \"\")=\"\" And Is" +
            "Null(Fields.TravelPayUrl, \"\")=\"\" And IsNull(Fields.MintUrl, \"\")=\"\", False, True)" +
            ""));
            this.PaymentOptionsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.PaymentOptionsLabel.Name = "PaymentOptionsLabel";
            this.PaymentOptionsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.PaymentOptionsLabel.Style.Font.Bold = true;
            this.PaymentOptionsLabel.Style.Font.Name = "Calibri";
            this.PaymentOptionsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PaymentOptionsLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.PaymentOptionsLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PaymentOptionsLabel.Value = "Payment Options";
            // 
            // TravelPayLogo
            // 
            navigateToUrlAction1.Url = "= Fields.TravelPayUrl";
            this.TravelPayLogo.Action = navigateToUrlAction1;
            this.TravelPayLogo.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.TravelPayUrl,\"\")=\"\", False, True)"));
            this.TravelPayLogo.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(IsNull(Fields.PayId,\"\")=\"\", \"0cm\", \"2.4cm\")"));
            this.TravelPayLogo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(4.5D));
            this.TravelPayLogo.MimeType = "image/png";
            this.TravelPayLogo.Name = "TravelPayLogo";
            this.TravelPayLogo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.TravelPayLogo.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.TravelPayLogo.Value = ((object)(resources.GetObject("TravelPayLogo.Value")));
            // 
            // PayIdLogo
            // 
            this.PayIdLogo.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.PayId,\"\")=\"\", False, True)"));
            this.PayIdLogo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.7D));
            this.PayIdLogo.MimeType = "image/png";
            this.PayIdLogo.Name = "PayIdLogo";
            this.PayIdLogo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.38D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PayIdLogo.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.PayIdLogo.Value = ((object)(resources.GetObject("PayIdLogo.Value")));
            // 
            // MintLogo
            // 
            navigateToUrlAction2.Url = "= Fields.MintUrl";
            this.MintLogo.Action = navigateToUrlAction2;
            this.MintLogo.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.MintUrl,\"\")=\"\", False, True)"));
            this.MintLogo.Bindings.Add(new Telerik.Reporting.Binding("Left", resources.GetString("MintLogo.Bindings")));
            this.MintLogo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.6D), Telerik.Reporting.Drawing.Unit.Cm(4.7D));
            this.MintLogo.MimeType = "image/png";
            this.MintLogo.Name = "MintLogo";
            this.MintLogo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.MintLogo.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
            this.MintLogo.Value = ((object)(resources.GetObject("MintLogo.Value")));
            // 
            // GroupHeaderSection1
            // 
            this.GroupHeaderSection1.CanShrink = true;
            this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(4.25D);
            this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AgencyHeaderSubReport1,
            this.HeaderPanel1,
            this.HeaderPanel2});
            this.GroupHeaderSection1.Name = "GroupHeaderSection1";
            this.GroupHeaderSection1.PrintOnEveryPage = false;
            this.GroupHeaderSection1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.25D);
            // 
            // AgencyHeaderSubReport1
            // 
            this.AgencyHeaderSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.AgencyHeaderSubReport1.Name = "AgencyHeaderSubReport1";
            typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
            typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
            typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
            typeReportSource2.TypeName = "Travelog.Reports.Common.AgencyHeaderSubReport1, Travelog.Reports, Version=1.0.0.0" +
    ", Culture=neutral, PublicKeyToken=null";
            this.AgencyHeaderSubReport1.ReportSource = typeReportSource2;
            this.AgencyHeaderSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.AgencyHeaderSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            // 
            // HeaderPanel1
            // 
            this.HeaderPanel1.CanShrink = true;
            this.HeaderPanel1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ReportNameLabel,
            this.BookingNo});
            this.HeaderPanel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.HeaderPanel1.Name = "HeaderPanel1";
            this.HeaderPanel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            // 
            // ReportNameLabel
            // 
            this.ReportNameLabel.CanShrink = true;
            this.ReportNameLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.ReportNameLabel.Name = "ReportNameLabel";
            this.ReportNameLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(0.75D));
            this.ReportNameLabel.Style.Font.Name = "Calibri";
            this.ReportNameLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(18D);
            this.ReportNameLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.ReportNameLabel.Value = "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\", IIf(Fields.DocumentType = " +
    "\"Invoice\", \"TAX INVOICE NO \", \"CREDIT NOTE NO \") + Fields.DocumentNo, \"STATEMENT" +
    " OF ACCOUNT/TAX INVOICE\")";
            // 
            // BookingNo
            // 
            this.BookingNo.CanShrink = true;
            this.BookingNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.75D));
            this.BookingNo.Name = "BookingNo";
            this.BookingNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(0.65D));
            this.BookingNo.Style.Font.Name = "Calibri";
            this.BookingNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(14D);
            this.BookingNo.Value = "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\", \"\", \"BOOKING NO \" + Fields" +
    ".DocumentNo)";
            // 
            // HeaderPanel2
            // 
            this.HeaderPanel2.CanShrink = true;
            this.HeaderPanel2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TaxNo,
            this.OrderNo,
            this.InvoiceDate,
            this.DueDate,
            this.DepartureDate,
            this.ContactName});
            this.HeaderPanel2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.HeaderPanel2.Name = "HeaderPanel2";
            this.HeaderPanel2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            // 
            // TaxNo
            // 
            this.TaxNo.CanShrink = true;
            this.TaxNo.Format = "";
            this.TaxNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TaxNo.Name = "TaxNo";
            this.TaxNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.TaxNo.Style.Font.Bold = true;
            this.TaxNo.Style.Font.Name = "Calibri";
            this.TaxNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TaxNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.TaxNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.TaxNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TaxNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TaxNo.Value = "= Fields.TaxNo";
            this.TaxNo.ItemDataBound += new System.EventHandler(this.TaxNo_ItemDataBound);
            // 
            // OrderNo
            // 
            this.OrderNo.CanShrink = true;
            this.OrderNo.Format = "";
            this.OrderNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.OrderNo.Name = "OrderNo";
            this.OrderNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.OrderNo.Style.Font.Name = "Calibri";
            this.OrderNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.OrderNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.OrderNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.OrderNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.OrderNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.OrderNo.Value = "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\", \"Order No: \", \"Order No(s)" +
    ": \") + Fields.OrderNo";
            // 
            // InvoiceDate
            // 
            this.InvoiceDate.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.DocumentDate = \"01-Jan-0001\", False, True)"));
            this.InvoiceDate.CanShrink = true;
            this.InvoiceDate.Format = "";
            this.InvoiceDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.InvoiceDate.Name = "InvoiceDate";
            this.InvoiceDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.InvoiceDate.Style.Font.Name = "Calibri";
            this.InvoiceDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.InvoiceDate.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.InvoiceDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.InvoiceDate.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.InvoiceDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.InvoiceDate.Value = "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\", \"Invoice Date: \", \"Stateme" +
    "nt Date: \") + Format(\"{0:dd-MMM-yyyy}\", Fields.DocumentDate)";
            // 
            // DueDate
            // 
            this.DueDate.CanShrink = true;
            this.DueDate.Format = "";
            this.DueDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
            this.DueDate.Name = "DueDate";
            this.DueDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.DueDate.Style.Font.Name = "Calibri";
            this.DueDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DueDate.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DueDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DueDate.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.DueDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DueDate.Value = "= IIf(Fields.DateDue = \"01-Jan-0001\", \"\", \"Date Due: \" + Format(\"{0:dd-MMM-yyyy}\"" +
    ", Fields.DateDue))";
            // 
            // DepartureDate
            // 
            this.DepartureDate.CanShrink = true;
            this.DepartureDate.Format = "";
            this.DepartureDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2D));
            this.DepartureDate.Name = "DepartureDate";
            this.DepartureDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.DepartureDate.Style.Font.Name = "Calibri";
            this.DepartureDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DepartureDate.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DepartureDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DepartureDate.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.DepartureDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DepartureDate.Value = "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\" Or Fields.DepartureDate = \"" +
    "01-Jan-0001\", \"\", Format(\"Departure Date: {0:dd-MMM-yyyy}\", Fields.DepartureDate" +
    "))";
            // 
            // ContactName
            // 
            this.ContactName.CanShrink = true;
            this.ContactName.Format = "";
            this.ContactName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.5D));
            this.ContactName.Name = "ContactName";
            this.ContactName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.ContactName.Style.Font.Name = "Calibri";
            this.ContactName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ContactName.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.ContactName.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.ContactName.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.ContactName.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.ContactName.Value = "= IIf(Fields.ContactName = \"\", \"\", \"Contact: \" + Fields.ContactName)";
            // 
            // GroupFooterSection2
            // 
            this.GroupFooterSection2.CanShrink = true;
            this.GroupFooterSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(19.55D);
            this.GroupFooterSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.BalanceDueLabel,
            this.BalanceDue,
            this.InvoiceSummaryPanel,
            this.PaymentTable,
            this.StatementSummaryPanel,
            this.PaymentScheduleTable});
            this.GroupFooterSection2.KeepTogether = false;
            this.GroupFooterSection2.Name = "GroupFooterSection2";
            this.GroupFooterSection2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
            // 
            // BalanceDueLabel
            // 
            this.BalanceDueLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.invoiceType.Value = \"CreditNote\", False, True)"));
            this.BalanceDueLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(16.75D));
            this.BalanceDueLabel.Name = "BalanceDueLabel";
            this.BalanceDueLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.BalanceDueLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.BalanceDueLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.BalanceDueLabel.Style.Font.Bold = true;
            this.BalanceDueLabel.Style.Font.Name = "Calibri";
            this.BalanceDueLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.BalanceDueLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.BalanceDueLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.BalanceDueLabel.StyleName = "Normal.TableBody";
            this.BalanceDueLabel.Value = "= \"Balance Due\" + IIf(Fields.DateDue = \"01-Jan-0001\", \"\", Format(\" On {0:dd-MMM-y" +
    "yyy}\", Fields.DateDue))";
            // 
            // BalanceDue
            // 
            this.BalanceDue.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.invoiceType.Value = \"CreditNote\", False, True)"));
            this.BalanceDue.Format = "";
            this.BalanceDue.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(16.75D));
            this.BalanceDue.Name = "BalanceDue";
            this.BalanceDue.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.BalanceDue.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.BalanceDue.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.BalanceDue.Style.Font.Bold = true;
            this.BalanceDue.Style.Font.Name = "Calibri";
            this.BalanceDue.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.BalanceDue.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.BalanceDue.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.BalanceDue.StyleName = "Normal.TableBody";
            this.BalanceDue.Value = "= Format(\"{0:c2}\", Fields.BalanceDue)";
            // 
            // InvoiceSummaryPanel
            // 
            this.InvoiceSummaryPanel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\", True, False)"));
            this.InvoiceSummaryPanel.CanShrink = true;
            this.InvoiceSummaryPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailTable,
            this.SubTotalLabel,
            this.SubTotal,
            this.TotalDiscountLabel,
            this.DiscountTotal,
            this.TotalTaxLabel,
            this.TotalTax,
            this.TotalAmountLabel,
            this.TotalAmount,
            this.ForeignCurrencyTotalAmountLabel,
            this.ForeignCurrencyTotalAmount,
            this.AgentCommissionTotalLabel,
            this.AgentCommissionTotal});
            this.InvoiceSummaryPanel.KeepTogether = false;
            this.InvoiceSummaryPanel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.05D));
            this.InvoiceSummaryPanel.Name = "InvoiceSummaryPanel";
            this.InvoiceSummaryPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.3D), Telerik.Reporting.Drawing.Unit.Cm(4.8D));
            // 
            // DetailTable
            // 
            this.DetailTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.InvoiceDetailReportList"));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(12D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.3D)));
            this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
            this.DetailTable.Body.SetCellContent(0, 1, this.Description);
            this.DetailTable.Body.SetCellContent(0, 0, this.AccountNo);
            this.DetailTable.Body.SetCellContent(0, 2, this.Amount);
            this.DetailTable.Body.SetCellContent(0, 3, this.TaxApplies);
            tableGroup1.Name = "tableGroup8";
            tableGroup1.ReportItem = this.AccountNoHeader;
            tableGroup2.Name = "tableGroup9";
            tableGroup2.ReportItem = this.DescriptionHeader;
            tableGroup3.Name = "tableGroup10";
            tableGroup3.ReportItem = this.AmountHeader;
            tableGroup4.Name = "group";
            tableGroup4.ReportItem = this.TaxAppliesHeader;
            this.DetailTable.ColumnGroups.Add(tableGroup1);
            this.DetailTable.ColumnGroups.Add(tableGroup2);
            this.DetailTable.ColumnGroups.Add(tableGroup3);
            this.DetailTable.ColumnGroups.Add(tableGroup4);
            this.DetailTable.ColumnHeadersPrintOnEveryPage = true;
            this.DetailTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AccountNo,
            this.Description,
            this.Amount,
            this.TaxApplies,
            this.AccountNoHeader,
            this.DescriptionHeader,
            this.AmountHeader,
            this.TaxAppliesHeader});
            this.DetailTable.KeepTogether = false;
            this.DetailTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.DetailTable.Name = "DetailTable";
            tableGroup5.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup5.Name = "detailTableGroup";
            this.DetailTable.RowGroups.Add(tableGroup5);
            this.DetailTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.3D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            // 
            // Description
            // 
            this.Description.Bindings.Add(new Telerik.Reporting.Binding("Width", "= IIf(Fields.AccountNo = \"\", \"15cm\", \"12cm\")"));
            this.Description.Format = "";
            this.Description.Name = "Description";
            this.Description.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Description.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Description.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Description.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Description.Style.Font.Name = "Calibri";
            this.Description.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Description.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.Description.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.Description.StyleName = "Normal.TableBody";
            this.Description.Value = "= Fields.Description";
            // 
            // AccountNo
            // 
            this.AccountNo.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AccountNo = \"\", False, True)"));
            this.AccountNo.Format = "";
            this.AccountNo.Name = "AccountNo";
            this.AccountNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AccountNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AccountNo.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AccountNo.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AccountNo.Style.Font.Name = "Calibri";
            this.AccountNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AccountNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.AccountNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.AccountNo.StyleName = "Normal.TableBody";
            this.AccountNo.Value = "= Fields.AccountNo";
            // 
            // Amount
            // 
            this.Amount.Format = "";
            this.Amount.Name = "Amount";
            this.Amount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Amount.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Amount.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Amount.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Amount.Style.Font.Name = "Calibri";
            this.Amount.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Amount.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.Amount.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.Amount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Amount.StyleName = "Normal.TableBody";
            this.Amount.Value = "= Format(\"{0:c2}\", Fields.Amount)";
            // 
            // TaxApplies
            // 
            this.TaxApplies.Format = "";
            this.TaxApplies.Name = "TaxApplies";
            this.TaxApplies.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TaxApplies.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TaxApplies.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TaxApplies.Style.Font.Name = "Calibri";
            this.TaxApplies.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TaxApplies.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.TaxApplies.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.TaxApplies.StyleName = "Normal.TableBody";
            this.TaxApplies.Value = "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\" Or Fields.Tax=0, \"\", \"*\")";
            // 
            // SubTotalLabel
            // 
            this.SubTotalLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.SubTotalLabel.Name = "SubTotalLabel";
            this.SubTotalLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.SubTotalLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.SubTotalLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.SubTotalLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.SubTotalLabel.Style.Font.Name = "Calibri";
            this.SubTotalLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.SubTotalLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.SubTotalLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.SubTotalLabel.StyleName = "Normal.TableBody";
            this.SubTotalLabel.Value = "= IIf(Parameters.isTaxInInvoiceLineAmount.Value = \"True\", \"Total\", \"Sub-Total\")";
            // 
            // SubTotal
            // 
            this.SubTotal.Format = "";
            this.SubTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.SubTotal.Name = "SubTotal";
            this.SubTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.SubTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.SubTotal.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.SubTotal.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.SubTotal.Style.Font.Name = "Calibri";
            this.SubTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.SubTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.SubTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.SubTotal.StyleName = "Normal.TableBody";
            this.SubTotal.Value = "= Format(\"{0:c2}\", Fields.SubTotal)";
            // 
            // TotalDiscountLabel
            // 
            this.TotalDiscountLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.DiscountTotal = 0 Or Parameters.invoiceType.Value = \"CreditNote\", Fa" +
            "lse, True)"));
            this.TotalDiscountLabel.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\", \"Solid\", \"None\")"));
            this.TotalDiscountLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
            this.TotalDiscountLabel.Name = "TotalDiscountLabel";
            this.TotalDiscountLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalDiscountLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalDiscountLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalDiscountLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalDiscountLabel.Style.Font.Name = "Calibri";
            this.TotalDiscountLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalDiscountLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalDiscountLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TotalDiscountLabel.StyleName = "Normal.TableBody";
            this.TotalDiscountLabel.Value = "Total Discounts Included";
            // 
            // DiscountTotal
            // 
            this.DiscountTotal.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.DiscountTotal = 0 Or Parameters.invoiceType.Value = \"CreditNote\", Fa" +
            "lse, True)"));
            this.DiscountTotal.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\", \"Solid\", \"None\")"));
            this.DiscountTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
            this.DiscountTotal.Name = "DiscountTotal";
            this.DiscountTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DiscountTotal.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.DiscountTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DiscountTotal.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DiscountTotal.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DiscountTotal.Style.Font.Name = "Calibri";
            this.DiscountTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DiscountTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.DiscountTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DiscountTotal.StyleName = "Normal.TableBody";
            this.DiscountTotal.Value = "= Format(\"{0:c2}\", Fields.DiscountTotal)";
            // 
            // TotalTaxLabel
            // 
            this.TotalTaxLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.TotalTaxLabel.Name = "TotalTaxLabel";
            this.TotalTaxLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalTaxLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalTaxLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalTaxLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalTaxLabel.Style.Font.Name = "Calibri";
            this.TotalTaxLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalTaxLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalTaxLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TotalTaxLabel.StyleName = "Normal.TableBody";
            this.TotalTaxLabel.Value = "Tax";
            this.TotalTaxLabel.ItemDataBound += new System.EventHandler(this.TotalTaxLabel_ItemDataBound);
            // 
            // TotalTax
            // 
            this.TotalTax.Format = "";
            this.TotalTax.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.TotalTax.Name = "TotalTax";
            this.TotalTax.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalTax.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalTax.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalTax.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalTax.Style.Font.Name = "Calibri";
            this.TotalTax.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalTax.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalTax.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TotalTax.StyleName = "Normal.TableBody";
            this.TotalTax.Value = "= Format(\"{0:c2}\", Fields.TotalTax)";
            // 
            // TotalAmountLabel
            // 
            this.TotalAmountLabel.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Parameters.invoiceType.Value = \"Invoice\", \"Solid\", \"None\")"));
            this.TotalAmountLabel.Format = "";
            this.TotalAmountLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
            this.TotalAmountLabel.Name = "TotalAmountLabel";
            this.TotalAmountLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalAmountLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalAmountLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalAmountLabel.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.TotalAmountLabel.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.TotalAmountLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalAmountLabel.Style.Font.Name = "Calibri";
            this.TotalAmountLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalAmountLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalAmountLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TotalAmountLabel.StyleName = "Normal.TableBody";
            this.TotalAmountLabel.Value = "= IIf(Parameters.invoiceType.Value = \"CreditNote\", \"Credit Total\", \"Invoice Total" +
    "\")";
            // 
            // TotalAmount
            // 
            this.TotalAmount.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Parameters.invoiceType.Value = \"Invoice\", \"Solid\", \"None\")"));
            this.TotalAmount.Format = "";
            this.TotalAmount.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
            this.TotalAmount.Name = "TotalAmount";
            this.TotalAmount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalAmount.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalAmount.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalAmount.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalAmount.Style.Font.Name = "Calibri";
            this.TotalAmount.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalAmount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalAmount.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TotalAmount.StyleName = "Normal.TableBody";
            this.TotalAmount.Value = "= Format(\"{0:c2}\", IIf(Parameters.isTaxInInvoiceLineAmount.Value = \"True\", Fields" +
    ".SubTotal - Fields.DiscountTotal, Fields.TotalAmount))";
            // 
            // ForeignCurrencyTotalAmountLabel
            // 
            this.ForeignCurrencyTotalAmountLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.invoiceType.Value = \"CreditNote\", False, True)"));
            this.ForeignCurrencyTotalAmountLabel.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Top", "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\" And Fields.ForeignCurrency " +
            "<> \"\", \"Solid\", \"None\")"));
            this.ForeignCurrencyTotalAmountLabel.CanShrink = true;
            this.ForeignCurrencyTotalAmountLabel.Format = "";
            this.ForeignCurrencyTotalAmountLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.2D));
            this.ForeignCurrencyTotalAmountLabel.Name = "ForeignCurrencyTotalAmountLabel";
            this.ForeignCurrencyTotalAmountLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ForeignCurrencyTotalAmountLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ForeignCurrencyTotalAmountLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ForeignCurrencyTotalAmountLabel.Style.Font.Name = "Calibri";
            this.ForeignCurrencyTotalAmountLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ForeignCurrencyTotalAmountLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.ForeignCurrencyTotalAmountLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.ForeignCurrencyTotalAmountLabel.StyleName = "Normal.TableBody";
            this.ForeignCurrencyTotalAmountLabel.Value = "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\" And Fields.ForeignCurrency " +
    "<> \"\", \"Foreign Currency Value\", \"\")";
            // 
            // ForeignCurrencyTotalAmount
            // 
            this.ForeignCurrencyTotalAmount.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.invoiceType.Value = \"CreditNote\", False, True)"));
            this.ForeignCurrencyTotalAmount.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Top", "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\" And Fields.ForeignCurrency " +
            "<> \"\", \"Solid\", \"None\")"));
            this.ForeignCurrencyTotalAmount.CanShrink = true;
            this.ForeignCurrencyTotalAmount.Format = "";
            this.ForeignCurrencyTotalAmount.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(4.2D));
            this.ForeignCurrencyTotalAmount.Name = "ForeignCurrencyTotalAmount";
            this.ForeignCurrencyTotalAmount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ForeignCurrencyTotalAmount.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ForeignCurrencyTotalAmount.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ForeignCurrencyTotalAmount.Style.Font.Name = "Calibri";
            this.ForeignCurrencyTotalAmount.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ForeignCurrencyTotalAmount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.ForeignCurrencyTotalAmount.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.ForeignCurrencyTotalAmount.StyleName = "Normal.TableBody";
            this.ForeignCurrencyTotalAmount.Value = "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\" And Fields.ForeignCurrency " +
    "<> \"\", Format(\"{0} {1:n2}\", Fields.ForeignCurrency, Fields.ForeignCurrencyTotalA" +
    "mount), \"\")";
            // 
            // AgentCommissionTotalLabel
            // 
            this.AgentCommissionTotalLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AgentCommissionTotal = 0 Or Parameters.invoiceType.Value = \"CreditNo" +
            "te\", False, True)"));
            this.AgentCommissionTotalLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.AgentCommissionTotalLabel.Name = "AgentCommissionTotalLabel";
            this.AgentCommissionTotalLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AgentCommissionTotalLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AgentCommissionTotalLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AgentCommissionTotalLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AgentCommissionTotalLabel.Style.Font.Name = "Calibri";
            this.AgentCommissionTotalLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AgentCommissionTotalLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AgentCommissionTotalLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.AgentCommissionTotalLabel.StyleName = "Normal.TableBody";
            this.AgentCommissionTotalLabel.Value = "Total Agent Commission Included";
            // 
            // AgentCommissionTotal
            // 
            this.AgentCommissionTotal.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AgentCommissionTotal = 0 Or Parameters.invoiceType.Value = \"CreditNo" +
            "te\", False, True)"));
            this.AgentCommissionTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.AgentCommissionTotal.Name = "AgentCommissionTotal";
            this.AgentCommissionTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AgentCommissionTotal.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AgentCommissionTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AgentCommissionTotal.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AgentCommissionTotal.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AgentCommissionTotal.Style.Font.Name = "Calibri";
            this.AgentCommissionTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AgentCommissionTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AgentCommissionTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.AgentCommissionTotal.StyleName = "Normal.TableBody";
            this.AgentCommissionTotal.Value = "= Format(\"{0:c2}\", Fields.AgentCommissionTotal)";
            // 
            // PaymentTable
            // 
            this.PaymentTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.PaymentDetailReportList"));
            this.PaymentTable.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PaymentDetailReportList.Count = 0, False, True)"));
            this.PaymentTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(15D)));
            this.PaymentTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3D)));
            this.PaymentTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
            this.PaymentTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
            this.PaymentTable.Body.SetCellContent(1, 0, this.PaymentDescription);
            this.PaymentTable.Body.SetCellContent(1, 1, this.PaymentAmount);
            this.PaymentTable.Body.SetCellContent(0, 0, this.InvoicesPaymentsReceiptsHeader1);
            this.PaymentTable.Body.SetCellContent(0, 1, this.InvoicesPaymentsReceiptsHeader2);
            tableGroup6.Name = "tableGroup9";
            tableGroup7.Name = "tableGroup10";
            this.PaymentTable.ColumnGroups.Add(tableGroup6);
            this.PaymentTable.ColumnGroups.Add(tableGroup7);
            this.PaymentTable.ColumnHeadersPrintOnEveryPage = true;
            this.PaymentTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.InvoicesPaymentsReceiptsHeader1,
            this.InvoicesPaymentsReceiptsHeader2,
            this.PaymentDescription,
            this.PaymentAmount});
            this.PaymentTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(15.05D));
            this.PaymentTable.Name = "PaymentTable";
            tableGroup8.Name = "group1";
            tableGroup9.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup9.Name = "detailTableGroup";
            this.PaymentTable.RowGroups.Add(tableGroup8);
            this.PaymentTable.RowGroups.Add(tableGroup9);
            this.PaymentTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1.7D));
            this.PaymentTable.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
            // 
            // PaymentDescription
            // 
            this.PaymentDescription.Format = "";
            this.PaymentDescription.Name = "PaymentDescription";
            this.PaymentDescription.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PaymentDescription.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PaymentDescription.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PaymentDescription.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PaymentDescription.Style.Font.Name = "Calibri";
            this.PaymentDescription.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PaymentDescription.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentDescription.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentDescription.StyleName = "Normal.TableBody";
            this.PaymentDescription.Value = "= Fields.Description";
            // 
            // PaymentAmount
            // 
            this.PaymentAmount.Format = "";
            this.PaymentAmount.Name = "PaymentAmount";
            this.PaymentAmount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PaymentAmount.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PaymentAmount.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PaymentAmount.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PaymentAmount.Style.Font.Name = "Calibri";
            this.PaymentAmount.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PaymentAmount.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentAmount.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentAmount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PaymentAmount.StyleName = "Normal.TableBody";
            this.PaymentAmount.Value = "= Format(\"{0:c2}\", Fields.Amount)";
            // 
            // InvoicesPaymentsReceiptsHeader1
            // 
            this.InvoicesPaymentsReceiptsHeader1.Name = "InvoicesPaymentsReceiptsHeader1";
            this.InvoicesPaymentsReceiptsHeader1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.InvoicesPaymentsReceiptsHeader1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.InvoicesPaymentsReceiptsHeader1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.InvoicesPaymentsReceiptsHeader1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.InvoicesPaymentsReceiptsHeader1.Style.Font.Bold = true;
            this.InvoicesPaymentsReceiptsHeader1.Style.Font.Name = "Calibri";
            this.InvoicesPaymentsReceiptsHeader1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.InvoicesPaymentsReceiptsHeader1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.InvoicesPaymentsReceiptsHeader1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Bottom;
            this.InvoicesPaymentsReceiptsHeader1.StyleName = "Normal.TableBody";
            this.InvoicesPaymentsReceiptsHeader1.Value = "= IIf(Parameters.issuedDocumentType.Value = \"PersonalStatement\", \"Receipts\", IIf(" +
    "Fields.IsDebtor, \"Invoices, Payments & Receipts\", \"Payments & Receipts\"))";
            // 
            // InvoicesPaymentsReceiptsHeader2
            // 
            this.InvoicesPaymentsReceiptsHeader2.Name = "InvoicesPaymentsReceiptsHeader2";
            this.InvoicesPaymentsReceiptsHeader2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.InvoicesPaymentsReceiptsHeader2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.InvoicesPaymentsReceiptsHeader2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.InvoicesPaymentsReceiptsHeader2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.InvoicesPaymentsReceiptsHeader2.Style.Font.Bold = true;
            this.InvoicesPaymentsReceiptsHeader2.Style.Font.Name = "Calibri";
            this.InvoicesPaymentsReceiptsHeader2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.InvoicesPaymentsReceiptsHeader2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.InvoicesPaymentsReceiptsHeader2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.InvoicesPaymentsReceiptsHeader2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Bottom;
            this.InvoicesPaymentsReceiptsHeader2.StyleName = "Normal.TableBody";
            this.InvoicesPaymentsReceiptsHeader2.Value = "";
            // 
            // StatementSummaryPanel
            // 
            this.StatementSummaryPanel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\", False, True)"));
            this.StatementSummaryPanel.CanShrink = true;
            this.StatementSummaryPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.SubTotal2,
            this.SubTotal1,
            this.TotalDiscount1,
            this.TotalDiscount2,
            this.TaxTotal1,
            this.TaxTotal2,
            this.OtherInclusionTotal1,
            this.OtherInclusionTotal2,
            this.ServiceFeeTotal1,
            this.ServiceFeeTotal2,
            this.ForeignCurrencyTotal1,
            this.ForeignCurrencyTotal2,
            this.AccommodationTotal1,
            this.AirTotal1,
            this.AccommodationTotal2,
            this.AirTotal2,
            this.InsuranceTotal2,
            this.InsuranceTotal1,
            this.CruiseTotal1,
            this.CruiseTotal2,
            this.TransportTotal1,
            this.TransportTotal2,
            this.OtherLandTotal1,
            this.OtherLandTotal2,
            this.TourTotal1,
            this.TourTotal2,
            this.TotalsHeader,
            this.StatementTotal2,
            this.StatementTotal1,
            this.TaxAppliesLabel,
            this.AgentCommission1,
            this.AgentCommission2,
            this.PackageTotal1,
            this.PackageTotal2,
            this.TransportTotal3,
            this.CruiseTotal3,
            this.InsuranceTotal3,
            this.ForeignCurrencyTotal3,
            this.TourTotal3,
            this.OtherLandTotal3,
            this.ServiceFeeTotal3,
            this.OtherInclusionTotal3,
            this.AccommodationTotal3,
            this.AirTotal3,
            this.PackageTotal3});
            this.StatementSummaryPanel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.85D));
            this.StatementSummaryPanel.Name = "StatementSummaryPanel";
            this.StatementSummaryPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.3D), Telerik.Reporting.Drawing.Unit.Cm(10.2D));
            // 
            // SubTotal2
            // 
            this.SubTotal2.CanShrink = true;
            this.SubTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(7.2D));
            this.SubTotal2.Name = "SubTotal2";
            this.SubTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.SubTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.SubTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.SubTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.SubTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.SubTotal2.Style.Font.Bold = true;
            this.SubTotal2.Style.Font.Name = "Calibri";
            this.SubTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.SubTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.SubTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.SubTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.SubTotal2.StyleName = "";
            this.SubTotal2.Value = "= Format(\"{0:c2}\", Fields.SubTotal)";
            // 
            // SubTotal1
            // 
            this.SubTotal1.CanShrink = true;
            this.SubTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(7.2D));
            this.SubTotal1.Name = "SubTotal1";
            this.SubTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.SubTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.SubTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.SubTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.SubTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.SubTotal1.Style.Font.Bold = true;
            this.SubTotal1.Style.Font.Name = "Calibri";
            this.SubTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.SubTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.SubTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.SubTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.SubTotal1.StyleName = "";
            this.SubTotal1.Value = "Total";
            // 
            // TotalDiscount1
            // 
            this.TotalDiscount1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.DiscountTotal = 0, False, True)"));
            this.TotalDiscount1.CanShrink = true;
            this.TotalDiscount1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(8.4D));
            this.TotalDiscount1.Name = "TotalDiscount1";
            this.TotalDiscount1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalDiscount1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TotalDiscount1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalDiscount1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalDiscount1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalDiscount1.Style.Font.Bold = true;
            this.TotalDiscount1.Style.Font.Name = "Calibri";
            this.TotalDiscount1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalDiscount1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalDiscount1.StyleName = "";
            this.TotalDiscount1.Value = "Total Discounts Included";
            // 
            // TotalDiscount2
            // 
            this.TotalDiscount2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.DiscountTotal = 0, False, True)"));
            this.TotalDiscount2.CanShrink = true;
            this.TotalDiscount2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(8.4D));
            this.TotalDiscount2.Name = "TotalDiscount2";
            this.TotalDiscount2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalDiscount2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TotalDiscount2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalDiscount2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalDiscount2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalDiscount2.Style.Font.Bold = true;
            this.TotalDiscount2.Style.Font.Name = "Calibri";
            this.TotalDiscount2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalDiscount2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalDiscount2.StyleName = "";
            this.TotalDiscount2.Value = "= Format(\"{0:c2}\", Fields.DiscountTotal)";
            // 
            // TaxTotal1
            // 
            this.TaxTotal1.CanShrink = true;
            this.TaxTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(7.8D));
            this.TaxTotal1.Name = "TaxTotal1";
            this.TaxTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TaxTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TaxTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TaxTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TaxTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TaxTotal1.Style.Font.Bold = true;
            this.TaxTotal1.Style.Font.Name = "Calibri";
            this.TaxTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TaxTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TaxTotal1.StyleName = "";
            this.TaxTotal1.Value = "Total Tax Included";
            this.TaxTotal1.ItemDataBound += new System.EventHandler(this.TaxTotal1_ItemDataBound);
            // 
            // TaxTotal2
            // 
            this.TaxTotal2.CanShrink = true;
            this.TaxTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(7.8D));
            this.TaxTotal2.Name = "TaxTotal2";
            this.TaxTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TaxTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TaxTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TaxTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TaxTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TaxTotal2.Style.Font.Bold = true;
            this.TaxTotal2.Style.Font.Name = "Calibri";
            this.TaxTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TaxTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TaxTotal2.StyleName = "";
            this.TaxTotal2.Value = "= Format(\"{0:c2}\", Fields.TotalTax)";
            // 
            // OtherInclusionTotal1
            // 
            this.OtherInclusionTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.OtherInclusionTotal=0,False,True)"));
            this.OtherInclusionTotal1.CanShrink = true;
            this.OtherInclusionTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(6.6D));
            this.OtherInclusionTotal1.Name = "OtherInclusionTotal1";
            this.OtherInclusionTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.OtherInclusionTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.OtherInclusionTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.OtherInclusionTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.OtherInclusionTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.OtherInclusionTotal1.Style.Font.Name = "Calibri";
            this.OtherInclusionTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.OtherInclusionTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherInclusionTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherInclusionTotal1.StyleName = "";
            this.OtherInclusionTotal1.Value = "Other Inclusions";
            // 
            // OtherInclusionTotal2
            // 
            this.OtherInclusionTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.OtherInclusionTotal=0,False,True)"));
            this.OtherInclusionTotal2.CanShrink = true;
            this.OtherInclusionTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(6.6D));
            this.OtherInclusionTotal2.Name = "OtherInclusionTotal2";
            this.OtherInclusionTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.OtherInclusionTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.OtherInclusionTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.OtherInclusionTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.OtherInclusionTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.OtherInclusionTotal2.Style.Font.Name = "Calibri";
            this.OtherInclusionTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.OtherInclusionTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherInclusionTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherInclusionTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.OtherInclusionTotal2.StyleName = "";
            this.OtherInclusionTotal2.Value = "= Format(\"{0:c2}\", Fields.OtherInclusionTotal)";
            // 
            // ServiceFeeTotal1
            // 
            this.ServiceFeeTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.ServiceFeeTotal=0,False,True)"));
            this.ServiceFeeTotal1.CanShrink = true;
            this.ServiceFeeTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(6D));
            this.ServiceFeeTotal1.Name = "ServiceFeeTotal1";
            this.ServiceFeeTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ServiceFeeTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.ServiceFeeTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ServiceFeeTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ServiceFeeTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ServiceFeeTotal1.Style.Font.Name = "Calibri";
            this.ServiceFeeTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ServiceFeeTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ServiceFeeTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ServiceFeeTotal1.StyleName = "";
            this.ServiceFeeTotal1.Value = "Service Fees";
            // 
            // ServiceFeeTotal2
            // 
            this.ServiceFeeTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.ServiceFeeTotal=0,False,True)"));
            this.ServiceFeeTotal2.CanShrink = true;
            this.ServiceFeeTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(6D));
            this.ServiceFeeTotal2.Name = "ServiceFeeTotal2";
            this.ServiceFeeTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ServiceFeeTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.ServiceFeeTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ServiceFeeTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ServiceFeeTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ServiceFeeTotal2.Style.Font.Name = "Calibri";
            this.ServiceFeeTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ServiceFeeTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ServiceFeeTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ServiceFeeTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.ServiceFeeTotal2.StyleName = "";
            this.ServiceFeeTotal2.Value = "= Format(\"{0:c2}\", Fields.ServiceFeeTotal)";
            // 
            // ForeignCurrencyTotal1
            // 
            this.ForeignCurrencyTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.ForeignCurrencyTotal=0,False,True)"));
            this.ForeignCurrencyTotal1.CanShrink = true;
            this.ForeignCurrencyTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.4D));
            this.ForeignCurrencyTotal1.Name = "ForeignCurrencyTotal1";
            this.ForeignCurrencyTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ForeignCurrencyTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.ForeignCurrencyTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ForeignCurrencyTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ForeignCurrencyTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ForeignCurrencyTotal1.Style.Font.Name = "Calibri";
            this.ForeignCurrencyTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ForeignCurrencyTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ForeignCurrencyTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ForeignCurrencyTotal1.StyleName = "";
            this.ForeignCurrencyTotal1.Value = "Foreign Currency";
            // 
            // ForeignCurrencyTotal2
            // 
            this.ForeignCurrencyTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.ForeignCurrencyTotal=0,False,True)"));
            this.ForeignCurrencyTotal2.CanShrink = true;
            this.ForeignCurrencyTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(5.4D));
            this.ForeignCurrencyTotal2.Name = "ForeignCurrencyTotal2";
            this.ForeignCurrencyTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ForeignCurrencyTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.ForeignCurrencyTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ForeignCurrencyTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ForeignCurrencyTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ForeignCurrencyTotal2.Style.Font.Name = "Calibri";
            this.ForeignCurrencyTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ForeignCurrencyTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ForeignCurrencyTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ForeignCurrencyTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.ForeignCurrencyTotal2.StyleName = "";
            this.ForeignCurrencyTotal2.Value = "= Format(\"{0:c2}\", Fields.ForeignCurrencyTotal)";
            // 
            // AccommodationTotal1
            // 
            this.AccommodationTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AccommodationTotal=0,False,True)"));
            this.AccommodationTotal1.CanShrink = true;
            this.AccommodationTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.AccommodationTotal1.Name = "AccommodationTotal1";
            this.AccommodationTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AccommodationTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AccommodationTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AccommodationTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AccommodationTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AccommodationTotal1.Style.Font.Name = "Calibri";
            this.AccommodationTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AccommodationTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccommodationTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccommodationTotal1.StyleName = "";
            this.AccommodationTotal1.Value = "Accommodation";
            // 
            // AirTotal1
            // 
            this.AirTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AirTotal=0,False,True)"));
            this.AirTotal1.CanShrink = true;
            this.AirTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.AirTotal1.Name = "AirTotal1";
            this.AirTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AirTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AirTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AirTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AirTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AirTotal1.Style.Font.Name = "Calibri";
            this.AirTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AirTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AirTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AirTotal1.StyleName = "";
            this.AirTotal1.Value = "Air";
            // 
            // AccommodationTotal2
            // 
            this.AccommodationTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AccommodationTotal=0,False,True)"));
            this.AccommodationTotal2.CanShrink = true;
            this.AccommodationTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.AccommodationTotal2.Name = "AccommodationTotal2";
            this.AccommodationTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AccommodationTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AccommodationTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AccommodationTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AccommodationTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AccommodationTotal2.Style.Font.Name = "Calibri";
            this.AccommodationTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AccommodationTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccommodationTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccommodationTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AccommodationTotal2.StyleName = "";
            this.AccommodationTotal2.Value = "= Format(\"{0:c2}\", Fields.AccommodationTotal)";
            // 
            // AirTotal2
            // 
            this.AirTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AirTotal=0,False,True)"));
            this.AirTotal2.CanShrink = true;
            this.AirTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.AirTotal2.Name = "AirTotal2";
            this.AirTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AirTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AirTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AirTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AirTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AirTotal2.Style.Font.Name = "Calibri";
            this.AirTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AirTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AirTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AirTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AirTotal2.StyleName = "";
            this.AirTotal2.Value = "= Format(\"{0:c2}\", Fields.AirTotal)";
            // 
            // InsuranceTotal2
            // 
            this.InsuranceTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.InsuranceTotal=0,False,True)"));
            this.InsuranceTotal2.CanShrink = true;
            this.InsuranceTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(4.8D));
            this.InsuranceTotal2.Name = "InsuranceTotal2";
            this.InsuranceTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.InsuranceTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.InsuranceTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.InsuranceTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.InsuranceTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.InsuranceTotal2.Style.Font.Name = "Calibri";
            this.InsuranceTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.InsuranceTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.InsuranceTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.InsuranceTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.InsuranceTotal2.StyleName = "";
            this.InsuranceTotal2.Value = "= Format(\"{0:c2}\", Fields.InsuranceTotal)";
            // 
            // InsuranceTotal1
            // 
            this.InsuranceTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.InsuranceTotal=0,False,True)"));
            this.InsuranceTotal1.CanShrink = true;
            this.InsuranceTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.8D));
            this.InsuranceTotal1.Name = "InsuranceTotal1";
            this.InsuranceTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.InsuranceTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.InsuranceTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.InsuranceTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.InsuranceTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.InsuranceTotal1.Style.Font.Name = "Calibri";
            this.InsuranceTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.InsuranceTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.InsuranceTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.InsuranceTotal1.StyleName = "";
            this.InsuranceTotal1.Value = "Insurance";
            // 
            // CruiseTotal1
            // 
            this.CruiseTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.CruiseTotal=0,False,True)"));
            this.CruiseTotal1.CanShrink = true;
            this.CruiseTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.CruiseTotal1.Name = "CruiseTotal1";
            this.CruiseTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CruiseTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.CruiseTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CruiseTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.CruiseTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CruiseTotal1.Style.Font.Name = "Calibri";
            this.CruiseTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CruiseTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CruiseTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CruiseTotal1.StyleName = "";
            this.CruiseTotal1.Value = "Cruise";
            // 
            // CruiseTotal2
            // 
            this.CruiseTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.CruiseTotal=0,False,True)"));
            this.CruiseTotal2.CanShrink = true;
            this.CruiseTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.CruiseTotal2.Name = "CruiseTotal2";
            this.CruiseTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CruiseTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.CruiseTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CruiseTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.CruiseTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CruiseTotal2.Style.Font.Name = "Calibri";
            this.CruiseTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CruiseTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CruiseTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CruiseTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.CruiseTotal2.StyleName = "";
            this.CruiseTotal2.Value = "= Format(\"{0:c2}\", Fields.CruiseTotal)";
            // 
            // TransportTotal1
            // 
            this.TransportTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.TransportTotal=0,False,True)"));
            this.TransportTotal1.CanShrink = true;
            this.TransportTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
            this.TransportTotal1.Name = "TransportTotal1";
            this.TransportTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TransportTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TransportTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TransportTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TransportTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TransportTotal1.Style.Font.Name = "Calibri";
            this.TransportTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TransportTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TransportTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TransportTotal1.StyleName = "";
            this.TransportTotal1.Value = "Transport";
            // 
            // TransportTotal2
            // 
            this.TransportTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.TransportTotal=0,False,True)"));
            this.TransportTotal2.CanShrink = true;
            this.TransportTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
            this.TransportTotal2.Name = "TransportTotal2";
            this.TransportTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TransportTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TransportTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TransportTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TransportTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TransportTotal2.Style.Font.Name = "Calibri";
            this.TransportTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TransportTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TransportTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TransportTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TransportTotal2.StyleName = "";
            this.TransportTotal2.Value = "= Format(\"{0:c2}\", Fields.TransportTotal)";
            // 
            // OtherLandTotal1
            // 
            this.OtherLandTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.OtherLandTotal=0,False,True)"));
            this.OtherLandTotal1.CanShrink = true;
            this.OtherLandTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.2D));
            this.OtherLandTotal1.Name = "OtherLandTotal1";
            this.OtherLandTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.OtherLandTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.OtherLandTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.OtherLandTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.OtherLandTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.OtherLandTotal1.Style.Font.Name = "Calibri";
            this.OtherLandTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.OtherLandTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherLandTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherLandTotal1.StyleName = "";
            this.OtherLandTotal1.Value = "Other Land";
            // 
            // OtherLandTotal2
            // 
            this.OtherLandTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.OtherLandTotal=0,False,True)"));
            this.OtherLandTotal2.CanShrink = true;
            this.OtherLandTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(4.2D));
            this.OtherLandTotal2.Name = "OtherLandTotal2";
            this.OtherLandTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.OtherLandTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.OtherLandTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.OtherLandTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.OtherLandTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.OtherLandTotal2.Style.Font.Name = "Calibri";
            this.OtherLandTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.OtherLandTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherLandTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherLandTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.OtherLandTotal2.StyleName = "";
            this.OtherLandTotal2.Value = "= Format(\"{0:c2}\", Fields.OtherLandTotal)";
            // 
            // TourTotal1
            // 
            this.TourTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.TourTotal=0,False,True)"));
            this.TourTotal1.CanShrink = true;
            this.TourTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
            this.TourTotal1.Name = "TourTotal1";
            this.TourTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TourTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TourTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TourTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TourTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TourTotal1.Style.Font.Name = "Calibri";
            this.TourTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TourTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TourTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TourTotal1.StyleName = "";
            this.TourTotal1.Value = "Tour";
            // 
            // TourTotal2
            // 
            this.TourTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.TourTotal=0,False,True)"));
            this.TourTotal2.CanShrink = true;
            this.TourTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
            this.TourTotal2.Name = "TourTotal2";
            this.TourTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TourTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TourTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TourTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TourTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TourTotal2.Style.Font.Name = "Calibri";
            this.TourTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TourTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TourTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TourTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TourTotal2.StyleName = "";
            this.TourTotal2.Value = "= Format(\"{0:c2}\", Fields.TourTotal)";
            // 
            // TotalsHeader
            // 
            this.TotalsHeader.CanShrink = true;
            this.TotalsHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TotalsHeader.Name = "TotalsHeader";
            this.TotalsHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalsHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TotalsHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalsHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalsHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalsHeader.Style.Font.Bold = true;
            this.TotalsHeader.Style.Font.Name = "Calibri";
            this.TotalsHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalsHeader.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalsHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalsHeader.StyleName = "Normal.TableHeader";
            this.TotalsHeader.Value = "Statement Summary";
            // 
            // StatementTotal2
            // 
            this.StatementTotal2.CanShrink = true;
            this.StatementTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(9.6D));
            this.StatementTotal2.Name = "StatementTotal2";
            this.StatementTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.StatementTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.StatementTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.StatementTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.StatementTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.StatementTotal2.Style.Font.Bold = true;
            this.StatementTotal2.Style.Font.Name = "Calibri";
            this.StatementTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.StatementTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.StatementTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.StatementTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.StatementTotal2.StyleName = "";
            this.StatementTotal2.Value = "= Format(\"{0:c2}\", Fields.TotalAmount)";
            // 
            // StatementTotal1
            // 
            this.StatementTotal1.CanShrink = true;
            this.StatementTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(9.6D));
            this.StatementTotal1.Name = "StatementTotal1";
            this.StatementTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.StatementTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.StatementTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.StatementTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.StatementTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.StatementTotal1.Style.Font.Bold = true;
            this.StatementTotal1.Style.Font.Name = "Calibri";
            this.StatementTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.StatementTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.StatementTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.StatementTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.StatementTotal1.StyleName = "";
            this.StatementTotal1.Value = "Statement Total";
            // 
            // TaxAppliesLabel
            // 
            this.TaxAppliesLabel.CanShrink = true;
            this.TaxAppliesLabel.Format = "";
            this.TaxAppliesLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(9.6D));
            this.TaxAppliesLabel.Name = "TaxAppliesLabel";
            this.TaxAppliesLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TaxAppliesLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TaxAppliesLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TaxAppliesLabel.Style.Font.Italic = true;
            this.TaxAppliesLabel.Style.Font.Name = "Calibri";
            this.TaxAppliesLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TaxAppliesLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.TaxAppliesLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TaxAppliesLabel.StyleName = "Normal.TableBody";
            this.TaxAppliesLabel.Value = "= IIf(Fields.TotalTax = 0, \"\", \"*Tax Applies\")";
            this.TaxAppliesLabel.ItemDataBinding += new System.EventHandler(this.TaxAppliesLabel_ItemDataBinding);
            // 
            // AgentCommission1
            // 
            this.AgentCommission1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value <> \"ClientStatement\" Or Fields.AgentCom" +
            "missionTotal = 0, False, True)"));
            this.AgentCommission1.CanShrink = true;
            this.AgentCommission1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(9D));
            this.AgentCommission1.Name = "AgentCommission1";
            this.AgentCommission1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AgentCommission1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AgentCommission1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AgentCommission1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AgentCommission1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AgentCommission1.Style.Font.Bold = true;
            this.AgentCommission1.Style.Font.Name = "Calibri";
            this.AgentCommission1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AgentCommission1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AgentCommission1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AgentCommission1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AgentCommission1.StyleName = "";
            this.AgentCommission1.Value = "Less Agent Commission";
            // 
            // AgentCommission2
            // 
            this.AgentCommission2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value <> \"ClientStatement\" Or Fields.AgentCom" +
            "missionTotal = 0, False, True)"));
            this.AgentCommission2.CanShrink = true;
            this.AgentCommission2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(9D));
            this.AgentCommission2.Name = "AgentCommission2";
            this.AgentCommission2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AgentCommission2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AgentCommission2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AgentCommission2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AgentCommission2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AgentCommission2.Style.Font.Bold = true;
            this.AgentCommission2.Style.Font.Name = "Calibri";
            this.AgentCommission2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AgentCommission2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AgentCommission2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AgentCommission2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AgentCommission2.StyleName = "";
            this.AgentCommission2.Value = "= Format(\"{0:c2}\", Fields.AgentCommissionTotal)";
            // 
            // PackageTotal1
            // 
            this.PackageTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageTotal = 0, False, True)"));
            this.PackageTotal1.CanShrink = true;
            this.PackageTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageTotal1.Name = "PackageTotal1";
            this.PackageTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PackageTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageTotal1.Style.Font.Name = "Calibri";
            this.PackageTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal1.StyleName = "";
            this.PackageTotal1.Value = "Package Total";
            // 
            // PackageTotal2
            // 
            this.PackageTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageTotal = 0, False, True)"));
            this.PackageTotal2.CanShrink = true;
            this.PackageTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageTotal2.Name = "PackageTotal2";
            this.PackageTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PackageTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageTotal2.Style.Font.Name = "Calibri";
            this.PackageTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PackageTotal2.StyleName = "";
            this.PackageTotal2.Value = "= Format(\"{0:c2}\", Fields.PackageTotal)";
            // 
            // TransportTotal3
            // 
            this.TransportTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.TransportTotal=0,False,True)"));
            this.TransportTotal3.Format = "";
            this.TransportTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
            this.TransportTotal3.Name = "TransportTotal3";
            this.TransportTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TransportTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TransportTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TransportTotal3.Style.Font.Name = "Calibri";
            this.TransportTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TransportTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.TransportTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.TransportTotal3.StyleName = "Normal.TableBody";
            this.TransportTotal3.Value = "= IIf(Fields.TransportTotalTax=0, \"\", \"*\")";
            // 
            // CruiseTotal3
            // 
            this.CruiseTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.CruiseTotal=0,False,True)"));
            this.CruiseTotal3.Format = "";
            this.CruiseTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.CruiseTotal3.Name = "CruiseTotal3";
            this.CruiseTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CruiseTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CruiseTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CruiseTotal3.Style.Font.Name = "Calibri";
            this.CruiseTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CruiseTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.CruiseTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.CruiseTotal3.StyleName = "Normal.TableBody";
            this.CruiseTotal3.Value = "= IIf(Fields.CruiseTotalTax=0, \"\", \"*\")";
            // 
            // InsuranceTotal3
            // 
            this.InsuranceTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.InsuranceTotal=0,False,True)"));
            this.InsuranceTotal3.Format = "";
            this.InsuranceTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(4.8D));
            this.InsuranceTotal3.Name = "InsuranceTotal3";
            this.InsuranceTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.InsuranceTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.InsuranceTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.InsuranceTotal3.Style.Font.Name = "Calibri";
            this.InsuranceTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.InsuranceTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.InsuranceTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.InsuranceTotal3.StyleName = "Normal.TableBody";
            this.InsuranceTotal3.Value = "= IIf(Fields.InsuranceTotalTax=0, \"\", \"*\")";
            // 
            // ForeignCurrencyTotal3
            // 
            this.ForeignCurrencyTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.ForeignCurrencyTotal=0,False,True)"));
            this.ForeignCurrencyTotal3.Format = "";
            this.ForeignCurrencyTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(5.4D));
            this.ForeignCurrencyTotal3.Name = "ForeignCurrencyTotal3";
            this.ForeignCurrencyTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ForeignCurrencyTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ForeignCurrencyTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ForeignCurrencyTotal3.Style.Font.Name = "Calibri";
            this.ForeignCurrencyTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ForeignCurrencyTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.ForeignCurrencyTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.ForeignCurrencyTotal3.StyleName = "Normal.TableBody";
            this.ForeignCurrencyTotal3.Value = "= IIf(Fields.ForeignCurrencyTotalTax=0, \"\", \"*\")";
            // 
            // TourTotal3
            // 
            this.TourTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.TourTotal=0,False,True)"));
            this.TourTotal3.Format = "";
            this.TourTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
            this.TourTotal3.Name = "TourTotal3";
            this.TourTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TourTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TourTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TourTotal3.Style.Font.Name = "Calibri";
            this.TourTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TourTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.TourTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.TourTotal3.StyleName = "Normal.TableBody";
            this.TourTotal3.Value = "= IIf(Fields.TourTotalTax=0, \"\", \"*\")";
            // 
            // OtherLandTotal3
            // 
            this.OtherLandTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.OtherLandTotal=0,False,True)"));
            this.OtherLandTotal3.Format = "";
            this.OtherLandTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(4.2D));
            this.OtherLandTotal3.Name = "OtherLandTotal3";
            this.OtherLandTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.OtherLandTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.OtherLandTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.OtherLandTotal3.Style.Font.Name = "Calibri";
            this.OtherLandTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.OtherLandTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.OtherLandTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.OtherLandTotal3.StyleName = "Normal.TableBody";
            this.OtherLandTotal3.Value = "= IIf(Fields.OtherLandTotalTax=0, \"\", \"*\")";
            // 
            // ServiceFeeTotal3
            // 
            this.ServiceFeeTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.ServiceFeeTotal=0,False,True)"));
            this.ServiceFeeTotal3.Format = "";
            this.ServiceFeeTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(6.001D));
            this.ServiceFeeTotal3.Name = "ServiceFeeTotal3";
            this.ServiceFeeTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ServiceFeeTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ServiceFeeTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ServiceFeeTotal3.Style.Font.Name = "Calibri";
            this.ServiceFeeTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ServiceFeeTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.ServiceFeeTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.ServiceFeeTotal3.StyleName = "Normal.TableBody";
            this.ServiceFeeTotal3.Value = "= IIf(Fields.ServiceFeeTotalTax=0, \"\", \"*\")";
            // 
            // OtherInclusionTotal3
            // 
            this.OtherInclusionTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.OtherInclusionTotal=0,False,True)"));
            this.OtherInclusionTotal3.Format = "";
            this.OtherInclusionTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(6.601D));
            this.OtherInclusionTotal3.Name = "OtherInclusionTotal3";
            this.OtherInclusionTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.OtherInclusionTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.OtherInclusionTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.OtherInclusionTotal3.Style.Font.Name = "Calibri";
            this.OtherInclusionTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.OtherInclusionTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.OtherInclusionTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.OtherInclusionTotal3.StyleName = "Normal.TableBody";
            this.OtherInclusionTotal3.Value = "= IIf(Fields.OtherInclusionTotalTax=0, \"\", \"*\")";
            // 
            // AccommodationTotal3
            // 
            this.AccommodationTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AccommodationTotal=0,False,True)"));
            this.AccommodationTotal3.Format = "";
            this.AccommodationTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.AccommodationTotal3.Name = "AccommodationTotal3";
            this.AccommodationTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AccommodationTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AccommodationTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AccommodationTotal3.Style.Font.Name = "Calibri";
            this.AccommodationTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AccommodationTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.AccommodationTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.AccommodationTotal3.StyleName = "Normal.TableBody";
            this.AccommodationTotal3.Value = "= IIf(Fields.AccommodationTotalTax=0, \"\", \"*\")";
            // 
            // AirTotal3
            // 
            this.AirTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AirTotal=0,False,True)"));
            this.AirTotal3.Format = "";
            this.AirTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.AirTotal3.Name = "AirTotal3";
            this.AirTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AirTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AirTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AirTotal3.Style.Font.Name = "Calibri";
            this.AirTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AirTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.AirTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.AirTotal3.StyleName = "Normal.TableBody";
            this.AirTotal3.Value = "= IIf(Fields.AirTotalTax=0, \"\", \"*\")";
            // 
            // PackageTotal3
            // 
            this.PackageTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageTotal <> 0 And Fields.PackageTaxApplies, True, False)"));
            this.PackageTotal3.CanShrink = true;
            this.PackageTotal3.Format = "";
            this.PackageTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageTotal3.Name = "PackageTotal3";
            this.PackageTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageTotal3.Style.Font.Name = "Calibri";
            this.PackageTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.PackageTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.PackageTotal3.StyleName = "Normal.TableBody";
            this.PackageTotal3.Value = "= IIf(Fields.PackageTotal <> 0 And Fields.PackageTaxApplies, \"*\", \"\")";
            // 
            // PaymentScheduleTable
            // 
            this.PaymentScheduleTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.PaymentScheduleReportList"));
            this.PaymentScheduleTable.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PaymentScheduleReportList.Count = 0, False, True)"));
            this.PaymentScheduleTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3D)));
            this.PaymentScheduleTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(12D)));
            this.PaymentScheduleTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3D)));
            this.PaymentScheduleTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
            this.PaymentScheduleTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
            this.PaymentScheduleTable.Body.SetCellContent(1, 0, this.PaymentScheduleTransactionDate);
            this.PaymentScheduleTable.Body.SetCellContent(1, 2, this.PaymentScheduleCredit);
            this.PaymentScheduleTable.Body.SetCellContent(0, 0, this.PaymentScheduleHeader1);
            this.PaymentScheduleTable.Body.SetCellContent(0, 2, this.PaymentScheduleHeader3);
            this.PaymentScheduleTable.Body.SetCellContent(0, 1, this.PaymentScheduleHeader2);
            this.PaymentScheduleTable.Body.SetCellContent(1, 1, this.PaymentScheduleDescription);
            tableGroup10.Name = "tableGroup9";
            tableGroup11.Name = "group4";
            tableGroup12.Name = "tableGroup10";
            this.PaymentScheduleTable.ColumnGroups.Add(tableGroup10);
            this.PaymentScheduleTable.ColumnGroups.Add(tableGroup11);
            this.PaymentScheduleTable.ColumnGroups.Add(tableGroup12);
            this.PaymentScheduleTable.ColumnHeadersPrintOnEveryPage = true;
            this.PaymentScheduleTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.PaymentScheduleHeader1,
            this.PaymentScheduleHeader2,
            this.PaymentScheduleHeader3,
            this.PaymentScheduleTransactionDate,
            this.PaymentScheduleDescription,
            this.PaymentScheduleCredit});
            this.PaymentScheduleTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(17.35D));
            this.PaymentScheduleTable.Name = "PaymentScheduleTable";
            tableGroup13.Name = "group1";
            tableGroup14.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup14.Name = "detailTableGroup";
            this.PaymentScheduleTable.RowGroups.Add(tableGroup13);
            this.PaymentScheduleTable.RowGroups.Add(tableGroup14);
            this.PaymentScheduleTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1.7D));
            this.PaymentScheduleTable.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
            // 
            // PaymentScheduleTransactionDate
            // 
            this.PaymentScheduleTransactionDate.Format = "";
            this.PaymentScheduleTransactionDate.Name = "PaymentScheduleTransactionDate";
            this.PaymentScheduleTransactionDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PaymentScheduleTransactionDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PaymentScheduleTransactionDate.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PaymentScheduleTransactionDate.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PaymentScheduleTransactionDate.Style.Font.Name = "Calibri";
            this.PaymentScheduleTransactionDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PaymentScheduleTransactionDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleTransactionDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleTransactionDate.StyleName = "Normal.TableBody";
            this.PaymentScheduleTransactionDate.Value = "= Format(\"{0:dd-MMM-yyyy}\", Fields.TransactionDate)";
            // 
            // PaymentScheduleCredit
            // 
            this.PaymentScheduleCredit.Format = "";
            this.PaymentScheduleCredit.Name = "PaymentScheduleCredit";
            this.PaymentScheduleCredit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PaymentScheduleCredit.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PaymentScheduleCredit.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PaymentScheduleCredit.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PaymentScheduleCredit.Style.Font.Name = "Calibri";
            this.PaymentScheduleCredit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PaymentScheduleCredit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleCredit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleCredit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PaymentScheduleCredit.StyleName = "Normal.TableBody";
            this.PaymentScheduleCredit.Value = "= Format(\"{0:c2}\", Fields.Amount)";
            // 
            // PaymentScheduleHeader1
            // 
            this.PaymentScheduleHeader1.Name = "PaymentScheduleHeader1";
            this.PaymentScheduleHeader1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PaymentScheduleHeader1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PaymentScheduleHeader1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PaymentScheduleHeader1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PaymentScheduleHeader1.Style.Font.Bold = true;
            this.PaymentScheduleHeader1.Style.Font.Name = "Calibri";
            this.PaymentScheduleHeader1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleHeader1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleHeader1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Bottom;
            this.PaymentScheduleHeader1.StyleName = "Normal.TableBody";
            this.PaymentScheduleHeader1.Value = "Payment Schedule";
            // 
            // PaymentScheduleHeader3
            // 
            this.PaymentScheduleHeader3.Name = "PaymentScheduleHeader3";
            this.PaymentScheduleHeader3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PaymentScheduleHeader3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PaymentScheduleHeader3.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PaymentScheduleHeader3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PaymentScheduleHeader3.Style.Font.Bold = true;
            this.PaymentScheduleHeader3.Style.Font.Name = "Calibri";
            this.PaymentScheduleHeader3.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleHeader3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleHeader3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PaymentScheduleHeader3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Bottom;
            this.PaymentScheduleHeader3.StyleName = "Normal.TableBody";
            this.PaymentScheduleHeader3.Value = "Amount";
            // 
            // PaymentScheduleHeader2
            // 
            this.PaymentScheduleHeader2.Name = "PaymentScheduleHeader2";
            this.PaymentScheduleHeader2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PaymentScheduleHeader2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PaymentScheduleHeader2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PaymentScheduleHeader2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PaymentScheduleHeader2.Style.Font.Bold = true;
            this.PaymentScheduleHeader2.Style.Font.Name = "Calibri";
            this.PaymentScheduleHeader2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleHeader2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleHeader2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PaymentScheduleHeader2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Bottom;
            this.PaymentScheduleHeader2.StyleName = "Normal.TableBody";
            // 
            // PaymentScheduleDescription
            // 
            this.PaymentScheduleDescription.Name = "PaymentScheduleDescription";
            this.PaymentScheduleDescription.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PaymentScheduleDescription.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PaymentScheduleDescription.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PaymentScheduleDescription.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PaymentScheduleDescription.Style.Font.Name = "Calibri";
            this.PaymentScheduleDescription.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleDescription.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.08D);
            this.PaymentScheduleDescription.StyleName = "Normal.TableBody";
            this.PaymentScheduleDescription.Value = "= Fields.Description";
            // 
            // GroupHeaderSection2
            // 
            this.GroupHeaderSection2.CanShrink = true;
            this.GroupHeaderSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(3.5D);
            this.GroupHeaderSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AgencyHeaderSubReport2,
            this.DebtorCodePanel,
            this.DebtorNameAddressPanel,
            this.PassengersLabel,
            this.Passengers});
            this.GroupHeaderSection2.KeepTogether = false;
            this.GroupHeaderSection2.Name = "GroupHeaderSection2";
            // 
            // AgencyHeaderSubReport2
            // 
            this.AgencyHeaderSubReport2.KeepTogether = false;
            this.AgencyHeaderSubReport2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.AgencyHeaderSubReport2.Name = "AgencyHeaderSubReport2";
            typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
            typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
            typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
            typeReportSource3.TypeName = "Travelog.Reports.Common.AgencyHeaderSubReport2, Travelog.Reports, Version=1.0.0.0" +
    ", Culture=neutral, PublicKeyToken=null";
            this.AgencyHeaderSubReport2.ReportSource = typeReportSource3;
            this.AgencyHeaderSubReport2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.AgencyHeaderSubReport2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            // 
            // DebtorCodePanel
            // 
            this.DebtorCodePanel.CanShrink = true;
            this.DebtorCodePanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Code,
            this.SubDebtor});
            this.DebtorCodePanel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.DebtorCodePanel.Name = "DebtorCodePanel";
            this.DebtorCodePanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            // 
            // Code
            // 
            this.Code.CanShrink = true;
            this.Code.Format = "";
            this.Code.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.Code.Name = "Code";
            this.Code.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Code.Style.Font.Name = "Calibri";
            this.Code.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Code.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Code.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Code.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Code.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Code.Value = "= IIf(Fields.Code = \"\", \"\", \"Debtor Code: \" + Fields.Code)";
            // 
            // SubDebtor
            // 
            this.SubDebtor.CanShrink = true;
            this.SubDebtor.Format = "";
            this.SubDebtor.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.SubDebtor.Name = "SubDebtor";
            this.SubDebtor.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.SubDebtor.Style.Font.Name = "Calibri";
            this.SubDebtor.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.SubDebtor.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.SubDebtor.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.SubDebtor.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.SubDebtor.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.SubDebtor.Value = "= IIf(Fields.SubDebtor = \"\", \"\", \"Cost Centre: \" + Fields.SubDebtor)";
            // 
            // DebtorNameAddressPanel
            // 
            this.DebtorNameAddressPanel.CanShrink = true;
            this.DebtorNameAddressPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Debtor,
            this.Address});
            this.DebtorNameAddressPanel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.DebtorNameAddressPanel.Name = "DebtorNameAddressPanel";
            this.DebtorNameAddressPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            // 
            // Debtor
            // 
            this.Debtor.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.Debtor.Name = "Debtor";
            this.Debtor.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Debtor.Style.Font.Bold = true;
            this.Debtor.Style.Font.Name = "Calibri";
            this.Debtor.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(11D);
            this.Debtor.Value = "= Fields.Debtor";
            // 
            // Address
            // 
            this.Address.CanShrink = true;
            this.Address.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Address.Name = "Address";
            this.Address.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Address.Style.Font.Name = "Calibri";
            this.Address.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Address.Value = "= Fields.Address";
            // 
            // PassengersLabel
            // 
            this.PassengersLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.Passengers, \"\") = \"\", False, True)"));
            this.PassengersLabel.CanShrink = true;
            this.PassengersLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.25D));
            this.PassengersLabel.Name = "PassengersLabel";
            this.PassengersLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.PassengersLabel.Style.Font.Bold = true;
            this.PassengersLabel.Style.Font.Name = "Calibri";
            this.PassengersLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PassengersLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.PassengersLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PassengersLabel.Value = "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\", \"Passengers\", \"Passengers " +
    "& Ticket Nos\")";
            // 
            // Passengers
            // 
            this.Passengers.CanShrink = true;
            this.Passengers.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.75D));
            this.Passengers.Name = "Passengers";
            this.Passengers.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.75D));
            this.Passengers.Style.Font.Name = "Calibri";
            this.Passengers.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Passengers.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.25D);
            this.Passengers.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.Passengers.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Passengers.Value = "= Fields.Passengers";
            // 
            // GroupFooterSection3
            // 
            this.GroupFooterSection3.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.GroupFooterSection3.Name = "GroupFooterSection3";
            this.GroupFooterSection3.Style.Visible = false;
            // 
            // GroupHeaderSection3
            // 
            this.GroupHeaderSection3.CanShrink = true;
            this.GroupHeaderSection3.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.GroupHeaderSection3.KeepTogether = false;
            this.GroupHeaderSection3.Name = "GroupHeaderSection3";
            this.GroupHeaderSection3.Style.Visible = false;
            // 
            // ConfirmationSubReport
            // 
            this.ConfirmationSubReport.KeepTogether = false;
            this.ConfirmationSubReport.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.ConfirmationSubReport.Name = "ConfirmationSubReport";
            typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
            typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("imagePath", "= \"\""));
            typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("tripLineIds", "= Parameters.tripLineIds.Value"));
            typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("passengerIds", "= Parameters.passengerIds.Value"));
            typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("quoteNo", "= Parameters.quoteNo.Value"));
            typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("tripItineraryId", "= 0"));
            typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
            typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("timeFormat", "= Parameters.timeFormat.Value"));
            typeReportSource4.TypeName = "Travelog.Reports.ClientLedger.ConfirmationSubReport, Travelog.Reports, Version=1." +
    "0.0.0, Culture=neutral, PublicKeyToken=null";
            this.ConfirmationSubReport.ReportSource = typeReportSource4;
            this.ConfirmationSubReport.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.3D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.ConfirmationSubReport.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            // 
            // Detail
            // 
            this.Detail.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value = \"ClientStatement\" Or Parameters.issue" +
            "dDocumentType.Value = \"PersonalStatement\", True, False)"));
            this.Detail.CanShrink = true;
            this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
            this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ConfirmationSubReport});
            this.Detail.KeepTogether = false;
            this.Detail.Name = "Detail";
            this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            // 
            // Pages
            // 
            this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Pages.Name = "Pages";
            this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Pages.Style.Color = System.Drawing.Color.DarkGray;
            this.Pages.Style.Font.Name = "Calibri";
            this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Pages.Value = "= \"Page \" + PageNumber + \" of \" + PageCount";
            // 
            // PageFooterSection
            // 
            this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
            this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages});
            this.PageFooterSection.Name = "PageFooterSection";
            // 
            // ReportDataSource
            // 
            this.ReportDataSource.DataMember = "InvoiceReport";
            this.ReportDataSource.DataSource = typeof(Travelog.Reports.Accounting.AccountingDataSources);
            this.ReportDataSource.Name = "ReportDataSource";
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("id", typeof(int), "= Parameters.id.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("issuedDocumentType", typeof(string), "= Parameters.issuedDocumentType.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("quoteNo", typeof(int), "= Parameters.quoteNo.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("tripLineIds", typeof(string), "= Parameters.tripLineIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("passengerIds", typeof(string), "= Parameters.passengerIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("today", typeof(System.DateTime), "= Parameters.today.Value"));
            // 
            // InvoiceReport
            // 
            this.DataSource = this.ReportDataSource;
            group1.GroupFooter = this.GroupFooterSection1;
            group1.GroupHeader = this.GroupHeaderSection1;
            group1.Name = "Group1";
            group2.GroupFooter = this.GroupFooterSection2;
            group2.GroupHeader = this.GroupHeaderSection2;
            group2.Name = "Group2";
            group3.GroupFooter = this.GroupFooterSection3;
            group3.GroupHeader = this.GroupHeaderSection3;
            group3.Name = "Group3";
            this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2,
            group3});
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.GroupHeaderSection2,
            this.GroupFooterSection2,
            this.GroupHeaderSection3,
            this.GroupFooterSection3,
            this.Detail,
            this.PageFooterSection});
            this.Name = "InvoiceReport";
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.35D), Telerik.Reporting.Drawing.Unit.Cm(1.35D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            reportParameter1.Name = "customerId";
            reportParameter1.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter2.Name = "agencyId";
            reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter3.Name = "creationUser";
            reportParameter4.Name = "creationTime";
            reportParameter4.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter5.Name = "id";
            reportParameter5.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter6.Name = "invoiceType";
            reportParameter7.Name = "issuedDocumentType";
            reportParameter8.Name = "timeFormat";
            reportParameter9.Name = "passengerIds";
            reportParameter10.Name = "tripLineIds";
            reportParameter11.Name = "isTaxInInvoiceLineAmount";
            reportParameter11.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter12.Name = "quoteNo";
            reportParameter13.Name = "today";
            reportParameter13.Type = Telerik.Reporting.ReportParameterType.DateTime;
            this.ReportParameters.Add(reportParameter1);
            this.ReportParameters.Add(reportParameter2);
            this.ReportParameters.Add(reportParameter3);
            this.ReportParameters.Add(reportParameter4);
            this.ReportParameters.Add(reportParameter5);
            this.ReportParameters.Add(reportParameter6);
            this.ReportParameters.Add(reportParameter7);
            this.ReportParameters.Add(reportParameter8);
            this.ReportParameters.Add(reportParameter9);
            this.ReportParameters.Add(reportParameter10);
            this.ReportParameters.Add(reportParameter11);
            this.ReportParameters.Add(reportParameter12);
            this.ReportParameters.Add(reportParameter13);
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(18.3D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.SubReport AgencyHeaderSubReport1;
		private Telerik.Reporting.TextBox ReportNameLabel;
		private Telerik.Reporting.TextBox TaxNo;
		private Telerik.Reporting.SubReport AgencyFooterSubReport;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection2;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection2;
		private Telerik.Reporting.SubReport AgencyHeaderSubReport2;
		private Telerik.Reporting.TextBox OrderNo;
		private Telerik.Reporting.TextBox InvoiceDate;
		private Telerik.Reporting.TextBox DueDate;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection3;
		private Telerik.Reporting.SubReport ConfirmationSubReport;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection3;
		private Telerik.Reporting.TextBox BookingNo;
		private Telerik.Reporting.TextBox DepartureDate;
		private Telerik.Reporting.TextBox ContactName;
		private Telerik.Reporting.Panel HeaderPanel1;
		private Telerik.Reporting.Panel HeaderPanel2;
		private Telerik.Reporting.TextBox DepositLabel;
		private Telerik.Reporting.TextBox Deposit;
		private Telerik.Reporting.TextBox PaymentTerms;
		private Telerik.Reporting.TextBox PaymentTermsLabel;
		private Telerik.Reporting.TextBox PaymentOptions;
		private Telerik.Reporting.TextBox Code;
		private Telerik.Reporting.TextBox SubDebtor;
		private Telerik.Reporting.Panel DebtorCodePanel;
		private Telerik.Reporting.Panel DebtorNameAddressPanel;
		private Telerik.Reporting.TextBox Debtor;
		private Telerik.Reporting.TextBox Address;
		private Telerik.Reporting.TextBox PassengersLabel;
		private Telerik.Reporting.TextBox Passengers;
		private Telerik.Reporting.Panel InvoiceSummaryPanel;
		private Telerik.Reporting.Table DetailTable;
		private Telerik.Reporting.TextBox Description;
		private Telerik.Reporting.TextBox AccountNo;
		private Telerik.Reporting.TextBox Amount;
		private Telerik.Reporting.TextBox TaxApplies;
		private Telerik.Reporting.TextBox AccountNoHeader;
		private Telerik.Reporting.TextBox DescriptionHeader;
		private Telerik.Reporting.TextBox AmountHeader;
		private Telerik.Reporting.TextBox TaxAppliesHeader;
		private Telerik.Reporting.TextBox SubTotalLabel;
		private Telerik.Reporting.TextBox SubTotal;
		private Telerik.Reporting.TextBox TotalDiscountLabel;
		private Telerik.Reporting.TextBox DiscountTotal;
		private Telerik.Reporting.TextBox TotalTaxLabel;
		private Telerik.Reporting.TextBox TotalTax;
		private Telerik.Reporting.TextBox AgentCommissionTotalLabel;
		private Telerik.Reporting.TextBox AgentCommissionTotal;
		private Telerik.Reporting.TextBox TotalAmountLabel;
		private Telerik.Reporting.TextBox TotalAmount;
		private Telerik.Reporting.TextBox ForeignCurrencyTotalAmountLabel;
		private Telerik.Reporting.TextBox ForeignCurrencyTotalAmount;
		private Telerik.Reporting.TextBox BalanceDue;
		private Telerik.Reporting.TextBox BalanceDueLabel;
		private Telerik.Reporting.Table PaymentTable;
		private Telerik.Reporting.TextBox PaymentDescription;
		private Telerik.Reporting.TextBox PaymentAmount;
		private Telerik.Reporting.TextBox InvoicesPaymentsReceiptsHeader1;
		private Telerik.Reporting.TextBox InvoicesPaymentsReceiptsHeader2;
		private Telerik.Reporting.Panel StatementSummaryPanel;
		private Telerik.Reporting.TextBox TotalDiscount1;
		private Telerik.Reporting.TextBox TotalDiscount2;
		private Telerik.Reporting.TextBox SubTotal2;
		private Telerik.Reporting.TextBox SubTotal1;
		private Telerik.Reporting.TextBox TaxTotal1;
		private Telerik.Reporting.TextBox TaxTotal2;
		private Telerik.Reporting.TextBox OtherInclusionTotal1;
		private Telerik.Reporting.TextBox OtherInclusionTotal2;
		private Telerik.Reporting.TextBox ServiceFeeTotal1;
		private Telerik.Reporting.TextBox ServiceFeeTotal2;
		private Telerik.Reporting.TextBox ForeignCurrencyTotal1;
		private Telerik.Reporting.TextBox ForeignCurrencyTotal2;
		private Telerik.Reporting.TextBox AccommodationTotal1;
		private Telerik.Reporting.TextBox AirTotal1;
		private Telerik.Reporting.TextBox AccommodationTotal2;
		private Telerik.Reporting.TextBox AirTotal2;
		private Telerik.Reporting.TextBox InsuranceTotal2;
		private Telerik.Reporting.TextBox InsuranceTotal1;
		private Telerik.Reporting.TextBox CruiseTotal1;
		private Telerik.Reporting.TextBox CruiseTotal2;
		private Telerik.Reporting.TextBox TransportTotal1;
		private Telerik.Reporting.TextBox TransportTotal2;
		private Telerik.Reporting.TextBox OtherLandTotal1;
		private Telerik.Reporting.TextBox OtherLandTotal2;
		private Telerik.Reporting.TextBox TourTotal1;
		private Telerik.Reporting.TextBox TourTotal2;
		private Telerik.Reporting.TextBox TotalsHeader;
		private Telerik.Reporting.TextBox StatementTotal2;
		private Telerik.Reporting.TextBox StatementTotal1;
		private Telerik.Reporting.TextBox TaxAppliesLabel;
        private Telerik.Reporting.Table PaymentScheduleTable;
        private Telerik.Reporting.TextBox PaymentScheduleTransactionDate;
        private Telerik.Reporting.TextBox PaymentScheduleCredit;
        private Telerik.Reporting.TextBox PaymentScheduleHeader1;
        private Telerik.Reporting.TextBox PaymentScheduleHeader3;
		private Telerik.Reporting.TextBox PaymentScheduleHeader2;
		private Telerik.Reporting.TextBox PaymentScheduleDescription;
		private Telerik.Reporting.TextBox AgentCommission1;
		private Telerik.Reporting.TextBox AgentCommission2;
		private Telerik.Reporting.TextBox PackageTotal1;
		private Telerik.Reporting.TextBox PackageTotal2;
		private Telerik.Reporting.TextBox TransportTotal3;
		private Telerik.Reporting.TextBox CruiseTotal3;
		private Telerik.Reporting.TextBox InsuranceTotal3;
		private Telerik.Reporting.TextBox ForeignCurrencyTotal3;
		private Telerik.Reporting.TextBox TourTotal3;
		private Telerik.Reporting.TextBox OtherLandTotal3;
		private Telerik.Reporting.TextBox ServiceFeeTotal3;
		private Telerik.Reporting.TextBox OtherInclusionTotal3;
		private Telerik.Reporting.TextBox AccommodationTotal3;
		private Telerik.Reporting.TextBox AirTotal3;
		private Telerik.Reporting.TextBox PackageTotal3;
		private Telerik.Reporting.TextBox PayId;
        private Telerik.Reporting.TextBox PaymentOptionsLabel;
        private Telerik.Reporting.PictureBox TravelPayLogo;
        private Telerik.Reporting.PictureBox PayIdLogo;
        private Telerik.Reporting.PictureBox MintLogo;
    }
}