using Telerik.Reporting;

namespace Travelog.Reports.Accounting {
	public partial class JournalReport : TelerikReport {
		public JournalReport() {
			InitializeComponent();
		}
	}
}