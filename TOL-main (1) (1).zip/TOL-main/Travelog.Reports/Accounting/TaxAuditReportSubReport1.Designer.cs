namespace Travelog.Reports.Accounting {
	partial class TaxAuditReportSubReport1 {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.Drawing.FormattingRule formattingRule1 = new Telerik.Reporting.Drawing.FormattingRule();
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.TotalsLabel = new Telerik.Reporting.TextBox();
			this.AmountNetTotal = new Telerik.Reporting.TextBox();
			this.TaxNetTotal = new Telerik.Reporting.TextBox();
			this.AmountGrossTotal = new Telerik.Reporting.TextBox();
			this.NonCommissionableTotal = new Telerik.Reporting.TextBox();
			this.TaxTotal = new Telerik.Reporting.TextBox();
			this.CommissionTotal = new Telerik.Reporting.TextBox();
			this.CommissionTaxTotal = new Telerik.Reporting.TextBox();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.AmountNetHeader = new Telerik.Reporting.TextBox();
			this.TaxNetHeader = new Telerik.Reporting.TextBox();
			this.DocumentNoHeader = new Telerik.Reporting.TextBox();
			this.DocumentDateHeader = new Telerik.Reporting.TextBox();
			this.TransactionTypeHeader = new Telerik.Reporting.TextBox();
			this.AmountGrossHeader = new Telerik.Reporting.TextBox();
			this.NonCommissionableHeader = new Telerik.Reporting.TextBox();
			this.TaxHeader = new Telerik.Reporting.TextBox();
			this.CommissionHeader = new Telerik.Reporting.TextBox();
			this.CommissionTaxHeader = new Telerik.Reporting.TextBox();
			this.GroupHeaderLabel = new Telerik.Reporting.TextBox();
			this.NoData = new Telerik.Reporting.TextBox();
			this.AmountNet = new Telerik.Reporting.TextBox();
			this.TaxNet = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.TransactionType = new Telerik.Reporting.TextBox();
			this.DocumentNo = new Telerik.Reporting.TextBox();
			this.DocumentDate = new Telerik.Reporting.TextBox();
			this.AmountGross = new Telerik.Reporting.TextBox();
			this.NonCommissionable = new Telerik.Reporting.TextBox();
			this.Commission = new Telerik.Reporting.TextBox();
			this.Tax = new Telerik.Reporting.TextBox();
			this.CommissionTax = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TotalsLabel,
            this.AmountNetTotal,
            this.TaxNetTotal,
            this.AmountGrossTotal,
            this.NonCommissionableTotal,
            this.TaxTotal,
            this.CommissionTotal,
            this.CommissionTaxTotal});
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			this.GroupFooterSection1.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupFooterSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupFooterSection1.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupFooterSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// TotalsLabel
			// 
			this.TotalsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TotalsLabel.Name = "TotalsLabel";
			this.TotalsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalsLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalsLabel.Style.Font.Name = "Calibri";
			this.TotalsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalsLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TotalsLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalsLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TotalsLabel.StyleName = "Normal.TableBody";
			this.TotalsLabel.Value = "Totals";
			this.TotalsLabel.ItemDataBound += new System.EventHandler(this.TotalsLabel_ItemDataBound);
			// 
			// AmountNetTotal
			// 
			this.AmountNetTotal.Format = "{0:C2}";
			this.AmountNetTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountNetTotal.Name = "AmountNetTotal";
			this.AmountNetTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountNetTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountNetTotal.Style.Font.Name = "Calibri";
			this.AmountNetTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountNetTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountNetTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountNetTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountNetTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountNetTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountNetTotal.StyleName = "Normal.TableBody";
			this.AmountNetTotal.Value = "= Sum(Fields.AmountNet)";
			this.AmountNetTotal.ItemDataBound += new System.EventHandler(this.Total_ItemDataBound);
			// 
			// TaxNetTotal
			// 
			this.TaxNetTotal.Format = "{0:C2}";
			this.TaxNetTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TaxNetTotal.Name = "TaxNetTotal";
			this.TaxNetTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxNetTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxNetTotal.Style.Font.Name = "Calibri";
			this.TaxNetTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxNetTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TaxNetTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxNetTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TaxNetTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxNetTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TaxNetTotal.StyleName = "Normal.TableBody";
			this.TaxNetTotal.Value = "= Sum(Fields.TaxNet)";
			this.TaxNetTotal.ItemDataBound += new System.EventHandler(this.Total_ItemDataBound);
			// 
			// AmountGrossTotal
			// 
			this.AmountGrossTotal.Format = "{0:C2}";
			this.AmountGrossTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountGrossTotal.Name = "AmountGrossTotal";
			this.AmountGrossTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGrossTotal.Style.Font.Name = "Calibri";
			this.AmountGrossTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGrossTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountGrossTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGrossTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountGrossTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountGrossTotal.StyleName = "Normal.TableBody";
			this.AmountGrossTotal.Value = "= Sum(Fields.AmountGross)";
			this.AmountGrossTotal.ItemDataBound += new System.EventHandler(this.Total_ItemDataBound);
			// 
			// NonCommissionableTotal
			// 
			this.NonCommissionableTotal.Format = "{0:C2}";
			this.NonCommissionableTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.NonCommissionableTotal.Name = "NonCommissionableTotal";
			this.NonCommissionableTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NonCommissionableTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NonCommissionableTotal.Style.Font.Name = "Calibri";
			this.NonCommissionableTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NonCommissionableTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NonCommissionableTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NonCommissionableTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.NonCommissionableTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.NonCommissionableTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.NonCommissionableTotal.StyleName = "Normal.TableBody";
			this.NonCommissionableTotal.Value = "= Sum(Fields.NonCommissionable)";
			this.NonCommissionableTotal.ItemDataBound += new System.EventHandler(this.Total_ItemDataBound);
			// 
			// TaxTotal
			// 
			this.TaxTotal.Format = "{0:C2}";
			this.TaxTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TaxTotal.Name = "TaxTotal";
			this.TaxTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxTotal.Style.Font.Name = "Calibri";
			this.TaxTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TaxTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TaxTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TaxTotal.StyleName = "Normal.TableBody";
			this.TaxTotal.Value = "= Sum(Fields.Tax)";
			this.TaxTotal.ItemDataBound += new System.EventHandler(this.Total_ItemDataBound);
			// 
			// CommissionTotal
			// 
			this.CommissionTotal.Format = "{0:C2}";
			this.CommissionTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CommissionTotal.Name = "CommissionTotal";
			this.CommissionTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CommissionTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CommissionTotal.Style.Font.Name = "Calibri";
			this.CommissionTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CommissionTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CommissionTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CommissionTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CommissionTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CommissionTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CommissionTotal.StyleName = "Normal.TableBody";
			this.CommissionTotal.Value = "= Sum(Fields.Commission)";
			this.CommissionTotal.ItemDataBound += new System.EventHandler(this.Total_ItemDataBound);
			// 
			// CommissionTaxTotal
			// 
			this.CommissionTaxTotal.Format = "{0:C2}";
			this.CommissionTaxTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(19.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CommissionTaxTotal.Name = "CommissionTaxTotal";
			this.CommissionTaxTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CommissionTaxTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CommissionTaxTotal.Style.Font.Name = "Calibri";
			this.CommissionTaxTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CommissionTaxTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CommissionTaxTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CommissionTaxTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CommissionTaxTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CommissionTaxTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CommissionTaxTotal.StyleName = "Normal.TableBody";
			this.CommissionTaxTotal.Value = "= Sum(Fields.CommissionTax)";
			this.CommissionTaxTotal.ItemDataBound += new System.EventHandler(this.Total_ItemDataBound);
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1.8D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AmountNetHeader,
            this.TaxNetHeader,
            this.DocumentNoHeader,
            this.DocumentDateHeader,
            this.TransactionTypeHeader,
            this.AmountGrossHeader,
            this.NonCommissionableHeader,
            this.TaxHeader,
            this.CommissionHeader,
            this.CommissionTaxHeader,
            this.GroupHeaderLabel,
            this.NoData});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = true;
			this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupHeaderSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// AmountNetHeader
			// 
			this.AmountNetHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountNetHeader.Name = "AmountNetHeader";
			this.AmountNetHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountNetHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.AmountNetHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountNetHeader.Style.Font.Name = "Calibri";
			this.AmountNetHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountNetHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountNetHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountNetHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountNetHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountNetHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AmountNetHeader.StyleName = "Normal.TableHeader";
			this.AmountNetHeader.Value = "Net (ex Tax)";
			this.AmountNetHeader.ItemDataBound += new System.EventHandler(this.AmountNetHeader_ItemDataBound);
			// 
			// TaxNetHeader
			// 
			this.TaxNetHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxNetHeader.Name = "TaxNetHeader";
			this.TaxNetHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxNetHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.TaxNetHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxNetHeader.Style.Font.Name = "Calibri";
			this.TaxNetHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxNetHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TaxNetHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxNetHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxNetHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxNetHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxNetHeader.StyleName = "Normal.TableHeader";
			this.TaxNetHeader.Value = "Net Tax";
			this.TaxNetHeader.ItemDataBound += new System.EventHandler(this.TaxNetHeader_ItemDataBound);
			// 
			// DocumentNoHeader
			// 
			this.DocumentNoHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Name = "DocumentNoHeader";
			this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNoHeader.Style.Font.Name = "Calibri";
			this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNoHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentNoHeader.StyleName = "Normal.TableHeader";
			this.DocumentNoHeader.Value = "Document No";
			// 
			// DocumentDateHeader
			// 
			this.DocumentDateHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDateHeader.Name = "DocumentDateHeader";
			this.DocumentDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDateHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.DocumentDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDateHeader.Style.Font.Name = "Calibri";
			this.DocumentDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDateHeader.StyleName = "Normal.TableHeader";
			this.DocumentDateHeader.Value = "Document Date";
			// 
			// TransactionTypeHeader
			// 
			this.TransactionTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TransactionTypeHeader.Name = "TransactionTypeHeader";
			this.TransactionTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TransactionTypeHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.TransactionTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TransactionTypeHeader.Style.Font.Name = "Calibri";
			this.TransactionTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TransactionTypeHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TransactionTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TransactionTypeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TransactionTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TransactionTypeHeader.StyleName = "Normal.TableHeader";
			this.TransactionTypeHeader.Value = "Transaction Type";
			// 
			// AmountGrossHeader
			// 
			this.AmountGrossHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossHeader.Name = "AmountGrossHeader";
			this.AmountGrossHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGrossHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.AmountGrossHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGrossHeader.Style.Font.Name = "Calibri";
			this.AmountGrossHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGrossHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountGrossHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountGrossHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountGrossHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AmountGrossHeader.StyleName = "Normal.TableHeader";
			this.AmountGrossHeader.Value = "Gross (ex Tax)";
			this.AmountGrossHeader.ItemDataBound += new System.EventHandler(this.AmountGrossHeader_ItemDataBound);
			// 
			// NonCommissionableHeader
			// 
			this.NonCommissionableHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NonCommissionableHeader.Name = "NonCommissionableHeader";
			this.NonCommissionableHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NonCommissionableHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.NonCommissionableHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NonCommissionableHeader.Style.Font.Name = "Calibri";
			this.NonCommissionableHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NonCommissionableHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NonCommissionableHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NonCommissionableHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NonCommissionableHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.NonCommissionableHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.NonCommissionableHeader.StyleName = "Normal.TableHeader";
			this.NonCommissionableHeader.Value = "Non-Comm";
			// 
			// TaxHeader
			// 
			this.TaxHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxHeader.Name = "TaxHeader";
			this.TaxHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.TaxHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxHeader.Style.Font.Name = "Calibri";
			this.TaxHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TaxHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxHeader.StyleName = "Normal.TableHeader";
			this.TaxHeader.Value = "Gross Tax";
			this.TaxHeader.ItemDataBound += new System.EventHandler(this.TaxHeader_ItemDataBound);
			// 
			// CommissionHeader
			// 
			this.CommissionHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.2D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CommissionHeader.Name = "CommissionHeader";
			this.CommissionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CommissionHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.CommissionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CommissionHeader.Style.Font.Name = "Calibri";
			this.CommissionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CommissionHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CommissionHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CommissionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CommissionHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CommissionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CommissionHeader.StyleName = "Normal.TableHeader";
			this.CommissionHeader.Value = "Commission";
			// 
			// CommissionTaxHeader
			// 
			this.CommissionTaxHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(19.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CommissionTaxHeader.Name = "CommissionTaxHeader";
			this.CommissionTaxHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CommissionTaxHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.CommissionTaxHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CommissionTaxHeader.Style.Font.Name = "Calibri";
			this.CommissionTaxHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CommissionTaxHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CommissionTaxHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CommissionTaxHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CommissionTaxHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CommissionTaxHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CommissionTaxHeader.StyleName = "Normal.TableHeader";
			this.CommissionTaxHeader.Value = "Comm Tax";
			this.CommissionTaxHeader.ItemDataBound += new System.EventHandler(this.CommissionTaxHeader_ItemDataBound);
			// 
			// GroupHeaderLabel
			// 
			this.GroupHeaderLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.GroupHeaderLabel.Name = "GroupHeaderLabel";
			this.GroupHeaderLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.GroupHeaderLabel.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.GroupHeaderLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderLabel.Style.Font.Bold = true;
			this.GroupHeaderLabel.Style.Font.Name = "Calibri";
			this.GroupHeaderLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.GroupHeaderLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupHeaderLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.GroupHeaderLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupHeaderLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.GroupHeaderLabel.StyleName = "Normal.TableHeader";
			this.GroupHeaderLabel.Value = "";
			this.GroupHeaderLabel.ItemDataBound += new System.EventHandler(this.GroupHeaderLabel_ItemDataBound);
			// 
			// NoData
			// 
			formattingRule1.Filters.Add(new Telerik.Reporting.Filter("= Count(1)", Telerik.Reporting.FilterOperator.Equal, "0"));
			formattingRule1.Style.Visible = true;
			this.NoData.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule1});
			this.NoData.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.NoData.Name = "NoData";
			this.NoData.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NoData.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NoData.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.NoData.Style.Font.Name = "Calibri";
			this.NoData.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NoData.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
			this.NoData.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.NoData.Style.Visible = false;
			this.NoData.StyleName = "Normal.TableHeader";
			this.NoData.Value = "NO DATA AVAILABLE";
			// 
			// AmountNet
			// 
			this.AmountNet.Format = "{0:C2}";
			this.AmountNet.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountNet.Name = "AmountNet";
			this.AmountNet.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountNet.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountNet.Style.Font.Name = "Calibri";
			this.AmountNet.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountNet.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountNet.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountNet.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountNet.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountNet.StyleName = "Normal.TableBody";
			this.AmountNet.Value = "= Fields.AmountNet";
			// 
			// TaxNet
			// 
			this.TaxNet.Format = "{0:C2}";
			this.TaxNet.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TaxNet.Name = "TaxNet";
			this.TaxNet.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxNet.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxNet.Style.Font.Name = "Calibri";
			this.TaxNet.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxNet.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TaxNet.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TaxNet.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TaxNet.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxNet.StyleName = "Normal.TableBody";
			this.TaxNet.Value = "= Fields.TaxNet";
			// 
			// Detail
			// 
			this.Detail.CanShrink = true;
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AmountNet,
            this.TaxNet,
            this.TransactionType,
            this.DocumentNo,
            this.DocumentDate,
            this.AmountGross,
            this.NonCommissionable,
            this.Commission,
            this.Tax,
            this.CommissionTax});
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// TransactionType
			// 
			this.TransactionType.CanShrink = true;
			this.TransactionType.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TransactionType.Name = "TransactionType";
			this.TransactionType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TransactionType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TransactionType.Style.Font.Name = "Calibri";
			this.TransactionType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TransactionType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TransactionType.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TransactionType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TransactionType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TransactionType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TransactionType.StyleName = "Normal.TableBody";
			this.TransactionType.Value = "= Fields.TransactionType";
			// 
			// DocumentNo
			// 
			this.DocumentNo.CanShrink = true;
			this.DocumentNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentNo.Name = "DocumentNo";
			this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNo.Style.Font.Name = "Calibri";
			this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentNo.StyleName = "Normal.TableBody";
			this.DocumentNo.Value = "= Fields.DocumentNo";
			// 
			// DocumentDate
			// 
			this.DocumentDate.Format = "{0:dd-MMM-yyyy}";
			this.DocumentDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentDate.Name = "DocumentDate";
			this.DocumentDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDate.Style.Font.Name = "Calibri";
			this.DocumentDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentDate.StyleName = "Normal.TableBody";
			this.DocumentDate.Value = "= Fields.DocumentDate";
			// 
			// AmountGross
			// 
			this.AmountGross.Format = "{0:C2}";
			this.AmountGross.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountGross.Name = "AmountGross";
			this.AmountGross.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountGross.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountGross.Style.Font.Name = "Calibri";
			this.AmountGross.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountGross.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGross.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountGross.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountGross.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountGross.StyleName = "Normal.TableBody";
			this.AmountGross.Value = "= Fields.AmountGross";
			// 
			// NonCommissionable
			// 
			this.NonCommissionable.Format = "{0:C2}";
			this.NonCommissionable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.NonCommissionable.Name = "NonCommissionable";
			this.NonCommissionable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NonCommissionable.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NonCommissionable.Style.Font.Name = "Calibri";
			this.NonCommissionable.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NonCommissionable.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.NonCommissionable.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NonCommissionable.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.NonCommissionable.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.NonCommissionable.StyleName = "Normal.TableBody";
			this.NonCommissionable.Value = "= Fields.NonCommissionable";
			// 
			// Commission
			// 
			this.Commission.Format = "{0:C2}";
			this.Commission.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Commission.Name = "Commission";
			this.Commission.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Commission.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Commission.Style.Font.Name = "Calibri";
			this.Commission.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Commission.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Commission.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Commission.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Commission.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Commission.StyleName = "Normal.TableBody";
			this.Commission.Value = "= Fields.Commission";
			// 
			// Tax
			// 
			this.Tax.Format = "{0:C2}";
			this.Tax.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.6D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Tax.Name = "Tax";
			this.Tax.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Tax.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Tax.Style.Font.Name = "Calibri";
			this.Tax.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Tax.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Tax.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Tax.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Tax.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Tax.StyleName = "Normal.TableBody";
			this.Tax.Value = "= Fields.Tax";
			// 
			// CommissionTax
			// 
			this.CommissionTax.Format = "{0:C2}";
			this.CommissionTax.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(19.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CommissionTax.Name = "CommissionTax";
			this.CommissionTax.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CommissionTax.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CommissionTax.Style.Font.Name = "Calibri";
			this.CommissionTax.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CommissionTax.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CommissionTax.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CommissionTax.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CommissionTax.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CommissionTax.StyleName = "Normal.TableBody";
			this.CommissionTax.Value = "= Fields.CommissionTax";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "TaxAuditReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.Accounting.AccountingDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("reportGroupId", typeof(int), "= Parameters.reportGroupId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateFrom", typeof(System.DateTime), "= Parameters.dateFrom.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateTo", typeof(System.DateTime), "= Parameters.dateTo.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("descendingDateOrder", typeof(bool), "= Parameters.descendingDateOrder.Value"));
			// 
			// TaxAuditReportSubReport1
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail});
			this.Name = "TaxAuditReportSubReport1";
			this.PageSettings.Landscape = true;
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "userName";
			reportParameter3.Name = "customerId";
			reportParameter3.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter4.Name = "agencyId";
			reportParameter4.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter5.Name = "reportGroupId";
			reportParameter5.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter6.AllowNull = true;
			reportParameter6.Name = "dateFrom";
			reportParameter6.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter7.AllowNull = true;
			reportParameter7.Name = "dateTo";
			reportParameter7.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter8.Name = "descendingDateOrder";
			reportParameter8.Type = Telerik.Reporting.ReportParameterType.Boolean;
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.Style.BorderColor.Default = System.Drawing.Color.Transparent;
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(27.7D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.TextBox TotalsLabel;
		private Telerik.Reporting.TextBox AmountNetHeader;
		private Telerik.Reporting.TextBox TaxNetHeader;
		private Telerik.Reporting.TextBox AmountNet;
		private Telerik.Reporting.TextBox TaxNet;
		private Telerik.Reporting.TextBox AmountNetTotal;
		private Telerik.Reporting.TextBox TaxNetTotal;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox DocumentDateHeader;
		private Telerik.Reporting.TextBox TransactionTypeHeader;
		private Telerik.Reporting.TextBox TransactionType;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox DocumentDate;
		private Telerik.Reporting.TextBox AmountGrossHeader;
		private Telerik.Reporting.TextBox NonCommissionableHeader;
		private Telerik.Reporting.TextBox TaxHeader;
		private Telerik.Reporting.TextBox CommissionHeader;
		private Telerik.Reporting.TextBox CommissionTaxHeader;
		private Telerik.Reporting.TextBox AmountGrossTotal;
		private Telerik.Reporting.TextBox NonCommissionableTotal;
		private Telerik.Reporting.TextBox TaxTotal;
		private Telerik.Reporting.TextBox CommissionTotal;
		private Telerik.Reporting.TextBox CommissionTaxTotal;
		private Telerik.Reporting.TextBox AmountGross;
		private Telerik.Reporting.TextBox NonCommissionable;
		private Telerik.Reporting.TextBox Commission;
		private Telerik.Reporting.TextBox Tax;
		private Telerik.Reporting.TextBox CommissionTax;
		private Telerik.Reporting.TextBox GroupHeaderLabel;
		private Telerik.Reporting.TextBox NoData;
		Telerik.Reporting.Drawing.FormattingRule formattingRule1 = new Telerik.Reporting.Drawing.FormattingRule();
	}
}