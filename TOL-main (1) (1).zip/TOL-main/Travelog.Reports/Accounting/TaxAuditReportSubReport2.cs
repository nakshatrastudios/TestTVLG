using System;
using Telerik.Reporting;
using Travelog.Biz.Resources;

namespace Travelog.Reports.Accounting {
	public partial class TaxAuditReportSubReport2 : TelerikReport {
		public TaxAuditReportSubReport2() {
			InitializeComponent();
		}

		private void AmountGrossHeader_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("Gross (ex {0})", Resource.TaxLabel);
		}
	}
}