namespace Travelog.Reports.Accounting {
	partial class TaxAuditReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TypeReportSource typeReportSource2 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TypeReportSource typeReportSource3 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TypeReportSource typeReportSource4 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TypeReportSource typeReportSource5 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TypeReportSource typeReportSource6 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter11 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter12 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter13 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter14 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter15 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter16 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter17 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter18 = new Telerik.Reporting.ReportParameter();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.TaxApplicableSalesHeader = new Telerik.Reporting.TextBox();
			this.TaxApplicableSales1 = new Telerik.Reporting.TextBox();
			this.TaxApplicableSalesLabel2 = new Telerik.Reporting.TextBox();
			this.TaxApplicableSales2 = new Telerik.Reporting.TextBox();
			this.TaxApplicableSalesLabel3 = new Telerik.Reporting.TextBox();
			this.TaxApplicableSales3 = new Telerik.Reporting.TextBox();
			this.TaxApplicableSalesLabel4 = new Telerik.Reporting.TextBox();
			this.TaxApplicableSales4 = new Telerik.Reporting.TextBox();
			this.TaxApplicableSalesLabel1 = new Telerik.Reporting.TextBox();
			this.TaxExemptSalesLabel1 = new Telerik.Reporting.TextBox();
			this.TaxExemptSales1 = new Telerik.Reporting.TextBox();
			this.TaxExemptSalesLabel2 = new Telerik.Reporting.TextBox();
			this.TaxExemptSales2 = new Telerik.Reporting.TextBox();
			this.TotalSalesLabel = new Telerik.Reporting.TextBox();
			this.TotalSales = new Telerik.Reporting.TextBox();
			this.TaxExemptSalesLabel3 = new Telerik.Reporting.TextBox();
			this.TaxExemptSales3 = new Telerik.Reporting.TextBox();
			this.TaxExemptSalesHeader = new Telerik.Reporting.TextBox();
			this.CostOfSalesLabel1 = new Telerik.Reporting.TextBox();
			this.CostOfSales1 = new Telerik.Reporting.TextBox();
			this.CostOfSalesLabel2 = new Telerik.Reporting.TextBox();
			this.CostOfSales2 = new Telerik.Reporting.TextBox();
			this.CostOfSalesLabel3 = new Telerik.Reporting.TextBox();
			this.CostOfSales3 = new Telerik.Reporting.TextBox();
			this.CostOfSalesLabel4 = new Telerik.Reporting.TextBox();
			this.CostOfSales4 = new Telerik.Reporting.TextBox();
			this.CostOfSalesHeader = new Telerik.Reporting.TextBox();
			this.CostOfSalesLabel5 = new Telerik.Reporting.TextBox();
			this.CostOfSales5 = new Telerik.Reporting.TextBox();
			this.TaxApplicablePurchasesLabel1 = new Telerik.Reporting.TextBox();
			this.TaxApplicablePurchases1 = new Telerik.Reporting.TextBox();
			this.TaxApplicablePurchasesLabel2 = new Telerik.Reporting.TextBox();
			this.TaxApplicablePurchases2 = new Telerik.Reporting.TextBox();
			this.TaxApplicablePurchasesLabel3 = new Telerik.Reporting.TextBox();
			this.TaxApplicablePurchases3 = new Telerik.Reporting.TextBox();
			this.PurchasesHeader = new Telerik.Reporting.TextBox();
			this.TotalPurchasesAndCostOfSalesLabel = new Telerik.Reporting.TextBox();
			this.TotalCostOfSalesAndPurchases = new Telerik.Reporting.TextBox();
			this.TotalTaxSalesLabel = new Telerik.Reporting.TextBox();
			this.TotalTaxSales = new Telerik.Reporting.TextBox();
			this.TotalTaxPurchasesLabel = new Telerik.Reporting.TextBox();
			this.TotalTaxPurchases = new Telerik.Reporting.TextBox();
			this.SalaryWagesHeader = new Telerik.Reporting.TextBox();
			this.SalaryWagesLabel1 = new Telerik.Reporting.TextBox();
			this.SalaryWages1 = new Telerik.Reporting.TextBox();
			this.SalaryWagesLabel2 = new Telerik.Reporting.TextBox();
			this.SalaryWages2 = new Telerik.Reporting.TextBox();
			this.SalaryWagesFooter = new Telerik.Reporting.TextBox();
			this.ReconciliationHeader = new Telerik.Reporting.TextBox();
			this.ReconciliationLabel1 = new Telerik.Reporting.TextBox();
			this.Reconciliation1 = new Telerik.Reporting.TextBox();
			this.ReconciliationLabel2 = new Telerik.Reporting.TextBox();
			this.Reconciliation2 = new Telerik.Reporting.TextBox();
			this.ReconciliationLabel3 = new Telerik.Reporting.TextBox();
			this.Reconciliation3 = new Telerik.Reporting.TextBox();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.ManagementReportHeaderSubReport1 = new Telerik.Reporting.SubReport();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.TaxAuditReportSubReport1 = new Telerik.Reporting.SubReport();
			this.TaxAuditReportSubReport2 = new Telerik.Reporting.SubReport();
			this.TaxAuditReportSubReport3 = new Telerik.Reporting.SubReport();
			this.TaxAuditReportSubReport4 = new Telerik.Reporting.SubReport();
			this.TaxAuditReportSubReport5 = new Telerik.Reporting.SubReport();
			this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
			this.Pages = new Telerik.Reporting.TextBox();
			this.CreationTime = new Telerik.Reporting.TextBox();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.CanShrink = true;
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(11.1D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TaxApplicableSalesHeader,
            this.TaxApplicableSales1,
            this.TaxApplicableSalesLabel2,
            this.TaxApplicableSales2,
            this.TaxApplicableSalesLabel3,
            this.TaxApplicableSales3,
            this.TaxApplicableSalesLabel4,
            this.TaxApplicableSales4,
            this.TaxApplicableSalesLabel1,
            this.TaxExemptSalesLabel1,
            this.TaxExemptSales1,
            this.TaxExemptSalesLabel2,
            this.TaxExemptSales2,
            this.TotalSalesLabel,
            this.TotalSales,
            this.TaxExemptSalesLabel3,
            this.TaxExemptSales3,
            this.TaxExemptSalesHeader,
            this.CostOfSalesLabel1,
            this.CostOfSales1,
            this.CostOfSalesLabel2,
            this.CostOfSales2,
            this.CostOfSalesLabel3,
            this.CostOfSales3,
            this.CostOfSalesLabel4,
            this.CostOfSales4,
            this.CostOfSalesHeader,
            this.CostOfSalesLabel5,
            this.CostOfSales5,
            this.TaxApplicablePurchasesLabel1,
            this.TaxApplicablePurchases1,
            this.TaxApplicablePurchasesLabel2,
            this.TaxApplicablePurchases2,
            this.TaxApplicablePurchasesLabel3,
            this.TaxApplicablePurchases3,
            this.PurchasesHeader,
            this.TotalPurchasesAndCostOfSalesLabel,
            this.TotalCostOfSalesAndPurchases,
            this.TotalTaxSalesLabel,
            this.TotalTaxSales,
            this.TotalTaxPurchasesLabel,
            this.TotalTaxPurchases,
            this.SalaryWagesHeader,
            this.SalaryWagesLabel1,
            this.SalaryWages1,
            this.SalaryWagesLabel2,
            this.SalaryWages2,
            this.SalaryWagesFooter,
            this.ReconciliationHeader,
            this.ReconciliationLabel1,
            this.Reconciliation1,
            this.ReconciliationLabel2,
            this.Reconciliation2,
            this.ReconciliationLabel3,
            this.Reconciliation3});
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			this.GroupFooterSection1.PageBreak = Telerik.Reporting.PageBreak.Before;
			this.GroupFooterSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupFooterSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// TaxApplicableSalesHeader
			// 
			this.TaxApplicableSalesHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TaxApplicableSalesHeader.Name = "TaxApplicableSalesHeader";
			this.TaxApplicableSalesHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicableSalesHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicableSalesHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicableSalesHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxApplicableSalesHeader.Style.Font.Bold = true;
			this.TaxApplicableSalesHeader.Style.Font.Name = "Calibri";
			this.TaxApplicableSalesHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicableSalesHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicableSalesHeader.StyleName = "Normal.TableHeader";
			this.TaxApplicableSalesHeader.Value = "Tax-Applicable Sales";
			this.TaxApplicableSalesHeader.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TaxApplicableSales1
			// 
			this.TaxApplicableSales1.Format = "{0:C2}";
			this.TaxApplicableSales1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicableSales1.Name = "TaxApplicableSales1";
			this.TaxApplicableSales1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicableSales1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicableSales1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicableSales1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxApplicableSales1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxApplicableSales1.Style.Font.Name = "Calibri";
			this.TaxApplicableSales1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicableSales1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicableSales1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicableSales1.StyleName = "Normal.TableHeader";
			this.TaxApplicableSales1.Value = "";
			this.TaxApplicableSales1.ItemDataBound += new System.EventHandler(this.TaxApplicableSales1_ItemDataBound);
			// 
			// TaxApplicableSalesLabel2
			// 
			this.TaxApplicableSalesLabel2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.TaxApplicableSalesLabel2.Name = "TaxApplicableSalesLabel2";
			this.TaxApplicableSalesLabel2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicableSalesLabel2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicableSalesLabel2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicableSalesLabel2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxApplicableSalesLabel2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxApplicableSalesLabel2.Style.Font.Name = "Calibri";
			this.TaxApplicableSalesLabel2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicableSalesLabel2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicableSalesLabel2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicableSalesLabel2.StyleName = "Normal.TableHeader";
			this.TaxApplicableSalesLabel2.Value = "Tax-Applicable Non-Comm Sales";
			this.TaxApplicableSalesLabel2.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TaxApplicableSales2
			// 
			this.TaxApplicableSales2.Format = "{0:C2}";
			this.TaxApplicableSales2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.TaxApplicableSales2.Name = "TaxApplicableSales2";
			this.TaxApplicableSales2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicableSales2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicableSales2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicableSales2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxApplicableSales2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxApplicableSales2.Style.Font.Name = "Calibri";
			this.TaxApplicableSales2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicableSales2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicableSales2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicableSales2.StyleName = "Normal.TableHeader";
			this.TaxApplicableSales2.Value = "";
			this.TaxApplicableSales2.ItemDataBound += new System.EventHandler(this.TaxApplicableSales2_ItemDataBound);
			// 
			// TaxApplicableSalesLabel3
			// 
			this.TaxApplicableSalesLabel3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			this.TaxApplicableSalesLabel3.Name = "TaxApplicableSalesLabel3";
			this.TaxApplicableSalesLabel3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicableSalesLabel3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicableSalesLabel3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicableSalesLabel3.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxApplicableSalesLabel3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxApplicableSalesLabel3.Style.Font.Name = "Calibri";
			this.TaxApplicableSalesLabel3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicableSalesLabel3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicableSalesLabel3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicableSalesLabel3.StyleName = "Normal.TableHeader";
			this.TaxApplicableSalesLabel3.Value = "Tax on Sales";
			this.TaxApplicableSalesLabel3.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TaxApplicableSales3
			// 
			this.TaxApplicableSales3.Format = "{0:C2}";
			this.TaxApplicableSales3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			this.TaxApplicableSales3.Name = "TaxApplicableSales3";
			this.TaxApplicableSales3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicableSales3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicableSales3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicableSales3.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxApplicableSales3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxApplicableSales3.Style.Font.Name = "Calibri";
			this.TaxApplicableSales3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicableSales3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicableSales3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicableSales3.StyleName = "Normal.TableHeader";
			this.TaxApplicableSales3.Value = "";
			this.TaxApplicableSales3.ItemDataBound += new System.EventHandler(this.TaxApplicableSales3_ItemDataBound);
			// 
			// TaxApplicableSalesLabel4
			// 
			this.TaxApplicableSalesLabel4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
			this.TaxApplicableSalesLabel4.Name = "TaxApplicableSalesLabel4";
			this.TaxApplicableSalesLabel4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicableSalesLabel4.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicableSalesLabel4.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicableSalesLabel4.Style.Font.Name = "Calibri";
			this.TaxApplicableSalesLabel4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicableSalesLabel4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicableSalesLabel4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicableSalesLabel4.StyleName = "Normal.TableHeader";
			this.TaxApplicableSalesLabel4.Value = "Total Tax-Applicable Sales";
			this.TaxApplicableSalesLabel4.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TaxApplicableSales4
			// 
			this.TaxApplicableSales4.Format = "{0:C2}";
			this.TaxApplicableSales4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
			this.TaxApplicableSales4.Name = "TaxApplicableSales4";
			this.TaxApplicableSales4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicableSales4.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicableSales4.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicableSales4.Style.Font.Name = "Calibri";
			this.TaxApplicableSales4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicableSales4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicableSales4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicableSales4.StyleName = "Normal.TableHeader";
			this.TaxApplicableSales4.Value = "";
			this.TaxApplicableSales4.ItemDataBound += new System.EventHandler(this.TaxApplicableSales4_ItemDataBound);
			// 
			// TaxApplicableSalesLabel1
			// 
			this.TaxApplicableSalesLabel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicableSalesLabel1.Name = "TaxApplicableSalesLabel1";
			this.TaxApplicableSalesLabel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicableSalesLabel1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicableSalesLabel1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicableSalesLabel1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxApplicableSalesLabel1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxApplicableSalesLabel1.Style.Font.Name = "Calibri";
			this.TaxApplicableSalesLabel1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicableSalesLabel1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicableSalesLabel1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicableSalesLabel1.StyleName = "Normal.TableHeader";
			this.TaxApplicableSalesLabel1.Value = "Net Tax-Applicable Sales";
			this.TaxApplicableSalesLabel1.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TaxExemptSalesLabel1
			// 
			this.TaxExemptSalesLabel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.7D));
			this.TaxExemptSalesLabel1.Name = "TaxExemptSalesLabel1";
			this.TaxExemptSalesLabel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxExemptSalesLabel1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxExemptSalesLabel1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxExemptSalesLabel1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxExemptSalesLabel1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxExemptSalesLabel1.Style.Font.Name = "Calibri";
			this.TaxExemptSalesLabel1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxExemptSalesLabel1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxExemptSalesLabel1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxExemptSalesLabel1.StyleName = "Normal.TableHeader";
			this.TaxExemptSalesLabel1.Value = "Gross Tax-Exempt Sales";
			this.TaxExemptSalesLabel1.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TaxExemptSales1
			// 
			this.TaxExemptSales1.Format = "{0:C2}";
			this.TaxExemptSales1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(4.7D));
			this.TaxExemptSales1.Name = "TaxExemptSales1";
			this.TaxExemptSales1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxExemptSales1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxExemptSales1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxExemptSales1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxExemptSales1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxExemptSales1.Style.Font.Name = "Calibri";
			this.TaxExemptSales1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxExemptSales1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxExemptSales1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxExemptSales1.StyleName = "Normal.TableHeader";
			this.TaxExemptSales1.Value = "";
			this.TaxExemptSales1.ItemDataBound += new System.EventHandler(this.TaxExemptSales1_ItemDataBound);
			// 
			// TaxExemptSalesLabel2
			// 
			this.TaxExemptSalesLabel2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.3D));
			this.TaxExemptSalesLabel2.Name = "TaxExemptSalesLabel2";
			this.TaxExemptSalesLabel2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxExemptSalesLabel2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxExemptSalesLabel2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxExemptSalesLabel2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxExemptSalesLabel2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxExemptSalesLabel2.Style.Font.Name = "Calibri";
			this.TaxExemptSalesLabel2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxExemptSalesLabel2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxExemptSalesLabel2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxExemptSalesLabel2.StyleName = "Normal.TableHeader";
			this.TaxExemptSalesLabel2.Value = "Tax-Exempt Non-Comm Sales";
			this.TaxExemptSalesLabel2.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TaxExemptSales2
			// 
			this.TaxExemptSales2.Format = "{0:C2}";
			this.TaxExemptSales2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(5.3D));
			this.TaxExemptSales2.Name = "TaxExemptSales2";
			this.TaxExemptSales2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxExemptSales2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxExemptSales2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxExemptSales2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxExemptSales2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxExemptSales2.Style.Font.Name = "Calibri";
			this.TaxExemptSales2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxExemptSales2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxExemptSales2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxExemptSales2.StyleName = "Normal.TableHeader";
			this.TaxExemptSales2.Value = "";
			this.TaxExemptSales2.ItemDataBound += new System.EventHandler(this.TaxExemptSales2_ItemDataBound);
			// 
			// TotalSalesLabel
			// 
			this.TotalSalesLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(7D));
			this.TotalSalesLabel.Name = "TotalSalesLabel";
			this.TotalSalesLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalSalesLabel.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TotalSalesLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalSalesLabel.Style.Font.Bold = true;
			this.TotalSalesLabel.Style.Font.Name = "Calibri";
			this.TotalSalesLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalSalesLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalSalesLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalSalesLabel.StyleName = "Normal.TableHeader";
			this.TotalSalesLabel.Value = "Total Sales";
			this.TotalSalesLabel.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TotalSales
			// 
			this.TotalSales.Format = "{0:C2}";
			this.TotalSales.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(7D));
			this.TotalSales.Name = "TotalSales";
			this.TotalSales.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalSales.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TotalSales.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalSales.Style.Font.Bold = true;
			this.TotalSales.Style.Font.Name = "Calibri";
			this.TotalSales.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalSales.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalSales.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalSales.StyleName = "Normal.TableHeader";
			this.TotalSales.Value = "";
			this.TotalSales.ItemDataBound += new System.EventHandler(this.TotalSales_ItemDataBound);
			// 
			// TaxExemptSalesLabel3
			// 
			this.TaxExemptSalesLabel3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.9D));
			this.TaxExemptSalesLabel3.Name = "TaxExemptSalesLabel3";
			this.TaxExemptSalesLabel3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxExemptSalesLabel3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxExemptSalesLabel3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxExemptSalesLabel3.Style.Font.Name = "Calibri";
			this.TaxExemptSalesLabel3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxExemptSalesLabel3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxExemptSalesLabel3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxExemptSalesLabel3.StyleName = "Normal.TableHeader";
			this.TaxExemptSalesLabel3.Value = "Total Tax-Exempt Sales";
			this.TaxExemptSalesLabel3.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TaxExemptSales3
			// 
			this.TaxExemptSales3.Format = "{0:C2}";
			this.TaxExemptSales3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(5.9D));
			this.TaxExemptSales3.Name = "TaxExemptSales3";
			this.TaxExemptSales3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxExemptSales3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxExemptSales3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxExemptSales3.Style.Font.Name = "Calibri";
			this.TaxExemptSales3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxExemptSales3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxExemptSales3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxExemptSales3.StyleName = "Normal.TableHeader";
			this.TaxExemptSales3.Value = "";
			this.TaxExemptSales3.ItemDataBound += new System.EventHandler(this.TaxExemptSales3_ItemDataBound);
			// 
			// TaxExemptSalesHeader
			// 
			this.TaxExemptSalesHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.1D));
			this.TaxExemptSalesHeader.Name = "TaxExemptSalesHeader";
			this.TaxExemptSalesHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxExemptSalesHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxExemptSalesHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxExemptSalesHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxExemptSalesHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxExemptSalesHeader.Style.Font.Bold = true;
			this.TaxExemptSalesHeader.Style.Font.Name = "Calibri";
			this.TaxExemptSalesHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxExemptSalesHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxExemptSalesHeader.StyleName = "Normal.TableHeader";
			this.TaxExemptSalesHeader.Value = "Tax-Exempt Sales";
			this.TaxExemptSalesHeader.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// CostOfSalesLabel1
			// 
			this.CostOfSalesLabel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSalesLabel1.Name = "CostOfSalesLabel1";
			this.CostOfSalesLabel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSalesLabel1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CostOfSalesLabel1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CostOfSalesLabel1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CostOfSalesLabel1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CostOfSalesLabel1.Style.Font.Name = "Calibri";
			this.CostOfSalesLabel1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CostOfSalesLabel1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CostOfSalesLabel1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CostOfSalesLabel1.StyleName = "Normal.TableHeader";
			this.CostOfSalesLabel1.Value = "Net Tax-Applicable Cost of Sales";
			this.CostOfSalesLabel1.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// CostOfSales1
			// 
			this.CostOfSales1.Format = "{0:C2}";
			this.CostOfSales1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSales1.Name = "CostOfSales1";
			this.CostOfSales1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSales1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CostOfSales1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CostOfSales1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CostOfSales1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CostOfSales1.Style.Font.Name = "Calibri";
			this.CostOfSales1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CostOfSales1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CostOfSales1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CostOfSales1.StyleName = "Normal.TableHeader";
			this.CostOfSales1.Value = "";
			this.CostOfSales1.ItemDataBound += new System.EventHandler(this.CostOfSales1_ItemDataBound);
			// 
			// CostOfSalesLabel2
			// 
			this.CostOfSalesLabel2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.CostOfSalesLabel2.Name = "CostOfSalesLabel2";
			this.CostOfSalesLabel2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSalesLabel2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CostOfSalesLabel2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CostOfSalesLabel2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CostOfSalesLabel2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CostOfSalesLabel2.Style.Font.Name = "Calibri";
			this.CostOfSalesLabel2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CostOfSalesLabel2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CostOfSalesLabel2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CostOfSalesLabel2.StyleName = "Normal.TableHeader";
			this.CostOfSalesLabel2.Value = "Tax on Cost of Sales";
			this.CostOfSalesLabel2.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// CostOfSales2
			// 
			this.CostOfSales2.Format = "{0:C2}";
			this.CostOfSales2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.CostOfSales2.Name = "CostOfSales2";
			this.CostOfSales2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSales2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CostOfSales2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CostOfSales2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CostOfSales2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CostOfSales2.Style.Font.Name = "Calibri";
			this.CostOfSales2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CostOfSales2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CostOfSales2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CostOfSales2.StyleName = "Normal.TableHeader";
			this.CostOfSales2.Value = "";
			this.CostOfSales2.ItemDataBound += new System.EventHandler(this.CostOfSales2_ItemDataBound);
			// 
			// CostOfSalesLabel3
			// 
			this.CostOfSalesLabel3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			this.CostOfSalesLabel3.Name = "CostOfSalesLabel3";
			this.CostOfSalesLabel3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSalesLabel3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CostOfSalesLabel3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CostOfSalesLabel3.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CostOfSalesLabel3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CostOfSalesLabel3.Style.Font.Name = "Calibri";
			this.CostOfSalesLabel3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CostOfSalesLabel3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CostOfSalesLabel3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CostOfSalesLabel3.StyleName = "Normal.TableHeader";
			this.CostOfSalesLabel3.Value = "Total Tax-Applicable Cost of Sales";
			this.CostOfSalesLabel3.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// CostOfSales3
			// 
			this.CostOfSales3.Format = "{0:C2}";
			this.CostOfSales3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			this.CostOfSales3.Name = "CostOfSales3";
			this.CostOfSales3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSales3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CostOfSales3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CostOfSales3.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CostOfSales3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CostOfSales3.Style.Font.Name = "Calibri";
			this.CostOfSales3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CostOfSales3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CostOfSales3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CostOfSales3.StyleName = "Normal.TableHeader";
			this.CostOfSales3.Value = "";
			this.CostOfSales3.ItemDataBound += new System.EventHandler(this.CostOfSales3_ItemDataBound);
			// 
			// CostOfSalesLabel4
			// 
			this.CostOfSalesLabel4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
			this.CostOfSalesLabel4.Name = "CostOfSalesLabel4";
			this.CostOfSalesLabel4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSalesLabel4.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CostOfSalesLabel4.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CostOfSalesLabel4.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CostOfSalesLabel4.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CostOfSalesLabel4.Style.Font.Name = "Calibri";
			this.CostOfSalesLabel4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CostOfSalesLabel4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CostOfSalesLabel4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CostOfSalesLabel4.StyleName = "Normal.TableHeader";
			this.CostOfSalesLabel4.Value = "Tax-Exempt Cost of Sales";
			this.CostOfSalesLabel4.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// CostOfSales4
			// 
			this.CostOfSales4.Format = "{0:C2}";
			this.CostOfSales4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
			this.CostOfSales4.Name = "CostOfSales4";
			this.CostOfSales4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSales4.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CostOfSales4.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CostOfSales4.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CostOfSales4.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CostOfSales4.Style.Font.Name = "Calibri";
			this.CostOfSales4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CostOfSales4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CostOfSales4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CostOfSales4.StyleName = "Normal.TableHeader";
			this.CostOfSales4.Value = "";
			this.CostOfSales4.ItemDataBound += new System.EventHandler(this.CostOfSales4_ItemDataBound);
			// 
			// CostOfSalesHeader
			// 
			this.CostOfSalesHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CostOfSalesHeader.Name = "CostOfSalesHeader";
			this.CostOfSalesHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSalesHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CostOfSalesHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CostOfSalesHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CostOfSalesHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CostOfSalesHeader.Style.Font.Bold = true;
			this.CostOfSalesHeader.Style.Font.Name = "Calibri";
			this.CostOfSalesHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CostOfSalesHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CostOfSalesHeader.StyleName = "Normal.TableHeader";
			this.CostOfSalesHeader.Value = "Cost of Sales";
			// 
			// CostOfSalesLabel5
			// 
			this.CostOfSalesLabel5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.CostOfSalesLabel5.Name = "CostOfSalesLabel5";
			this.CostOfSalesLabel5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSalesLabel5.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CostOfSalesLabel5.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CostOfSalesLabel5.Style.Font.Name = "Calibri";
			this.CostOfSalesLabel5.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CostOfSalesLabel5.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CostOfSalesLabel5.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CostOfSalesLabel5.StyleName = "Normal.TableHeader";
			this.CostOfSalesLabel5.Value = "Total Cost of Sales";
			// 
			// CostOfSales5
			// 
			this.CostOfSales5.Format = "{0:C2}";
			this.CostOfSales5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.CostOfSales5.Name = "CostOfSales5";
			this.CostOfSales5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CostOfSales5.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CostOfSales5.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CostOfSales5.Style.Font.Name = "Calibri";
			this.CostOfSales5.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CostOfSales5.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CostOfSales5.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CostOfSales5.StyleName = "Normal.TableHeader";
			this.CostOfSales5.Value = "";
			this.CostOfSales5.ItemDataBound += new System.EventHandler(this.CostOfSales5_ItemDataBound);
			// 
			// TaxApplicablePurchasesLabel1
			// 
			this.TaxApplicablePurchasesLabel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(4.7D));
			this.TaxApplicablePurchasesLabel1.Name = "TaxApplicablePurchasesLabel1";
			this.TaxApplicablePurchasesLabel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicablePurchasesLabel1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicablePurchasesLabel1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicablePurchasesLabel1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxApplicablePurchasesLabel1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxApplicablePurchasesLabel1.Style.Font.Name = "Calibri";
			this.TaxApplicablePurchasesLabel1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicablePurchasesLabel1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicablePurchasesLabel1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicablePurchasesLabel1.StyleName = "Normal.TableHeader";
			this.TaxApplicablePurchasesLabel1.Value = "Net Purchases";
			// 
			// TaxApplicablePurchases1
			// 
			this.TaxApplicablePurchases1.Format = "{0:C2}";
			this.TaxApplicablePurchases1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(4.7D));
			this.TaxApplicablePurchases1.Name = "TaxApplicablePurchases1";
			this.TaxApplicablePurchases1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicablePurchases1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicablePurchases1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicablePurchases1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxApplicablePurchases1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxApplicablePurchases1.Style.Font.Name = "Calibri";
			this.TaxApplicablePurchases1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicablePurchases1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicablePurchases1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicablePurchases1.StyleName = "Normal.TableHeader";
			this.TaxApplicablePurchases1.Value = "";
			this.TaxApplicablePurchases1.ItemDataBound += new System.EventHandler(this.TaxApplicablePurchases1_ItemDataBound);
			// 
			// TaxApplicablePurchasesLabel2
			// 
			this.TaxApplicablePurchasesLabel2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(5.3D));
			this.TaxApplicablePurchasesLabel2.Name = "TaxApplicablePurchasesLabel2";
			this.TaxApplicablePurchasesLabel2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicablePurchasesLabel2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicablePurchasesLabel2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicablePurchasesLabel2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxApplicablePurchasesLabel2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxApplicablePurchasesLabel2.Style.Font.Name = "Calibri";
			this.TaxApplicablePurchasesLabel2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicablePurchasesLabel2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicablePurchasesLabel2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicablePurchasesLabel2.StyleName = "Normal.TableHeader";
			this.TaxApplicablePurchasesLabel2.Value = "Tax on Purchases";
			this.TaxApplicablePurchasesLabel2.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TaxApplicablePurchases2
			// 
			this.TaxApplicablePurchases2.Format = "{0:C2}";
			this.TaxApplicablePurchases2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(5.3D));
			this.TaxApplicablePurchases2.Name = "TaxApplicablePurchases2";
			this.TaxApplicablePurchases2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicablePurchases2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicablePurchases2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicablePurchases2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TaxApplicablePurchases2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxApplicablePurchases2.Style.Font.Name = "Calibri";
			this.TaxApplicablePurchases2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicablePurchases2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicablePurchases2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicablePurchases2.StyleName = "Normal.TableHeader";
			this.TaxApplicablePurchases2.Value = "";
			this.TaxApplicablePurchases2.ItemDataBound += new System.EventHandler(this.TaxApplicablePurchases2_ItemDataBound);
			// 
			// TaxApplicablePurchasesLabel3
			// 
			this.TaxApplicablePurchasesLabel3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(5.9D));
			this.TaxApplicablePurchasesLabel3.Name = "TaxApplicablePurchasesLabel3";
			this.TaxApplicablePurchasesLabel3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicablePurchasesLabel3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicablePurchasesLabel3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicablePurchasesLabel3.Style.Font.Name = "Calibri";
			this.TaxApplicablePurchasesLabel3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicablePurchasesLabel3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicablePurchasesLabel3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicablePurchasesLabel3.StyleName = "Normal.TableHeader";
			this.TaxApplicablePurchasesLabel3.Value = "Total Purchases";
			// 
			// TaxApplicablePurchases3
			// 
			this.TaxApplicablePurchases3.Format = "{0:C2}";
			this.TaxApplicablePurchases3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(5.9D));
			this.TaxApplicablePurchases3.Name = "TaxApplicablePurchases3";
			this.TaxApplicablePurchases3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxApplicablePurchases3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxApplicablePurchases3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxApplicablePurchases3.Style.Font.Name = "Calibri";
			this.TaxApplicablePurchases3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxApplicablePurchases3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxApplicablePurchases3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxApplicablePurchases3.StyleName = "Normal.TableHeader";
			this.TaxApplicablePurchases3.Value = "";
			this.TaxApplicablePurchases3.ItemDataBound += new System.EventHandler(this.TaxApplicablePurchases3_ItemDataBound);
			// 
			// PurchasesHeader
			// 
			this.PurchasesHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(4.1D));
			this.PurchasesHeader.Name = "PurchasesHeader";
			this.PurchasesHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.PurchasesHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.PurchasesHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.PurchasesHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.PurchasesHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.PurchasesHeader.Style.Font.Bold = true;
			this.PurchasesHeader.Style.Font.Name = "Calibri";
			this.PurchasesHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PurchasesHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.PurchasesHeader.StyleName = "Normal.TableHeader";
			this.PurchasesHeader.Value = "Purchases";
			// 
			// TotalPurchasesAndCostOfSalesLabel
			// 
			this.TotalPurchasesAndCostOfSalesLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(7D));
			this.TotalPurchasesAndCostOfSalesLabel.Name = "TotalPurchasesAndCostOfSalesLabel";
			this.TotalPurchasesAndCostOfSalesLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalPurchasesAndCostOfSalesLabel.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TotalPurchasesAndCostOfSalesLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalPurchasesAndCostOfSalesLabel.Style.Font.Bold = true;
			this.TotalPurchasesAndCostOfSalesLabel.Style.Font.Name = "Calibri";
			this.TotalPurchasesAndCostOfSalesLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalPurchasesAndCostOfSalesLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalPurchasesAndCostOfSalesLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalPurchasesAndCostOfSalesLabel.StyleName = "Normal.TableHeader";
			this.TotalPurchasesAndCostOfSalesLabel.Value = "Total Cost of Sales & Purchases";
			this.TotalPurchasesAndCostOfSalesLabel.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TotalCostOfSalesAndPurchases
			// 
			this.TotalCostOfSalesAndPurchases.Format = "{0:C2}";
			this.TotalCostOfSalesAndPurchases.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(7D));
			this.TotalCostOfSalesAndPurchases.Name = "TotalCostOfSalesAndPurchases";
			this.TotalCostOfSalesAndPurchases.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalCostOfSalesAndPurchases.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TotalCostOfSalesAndPurchases.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalCostOfSalesAndPurchases.Style.Font.Bold = true;
			this.TotalCostOfSalesAndPurchases.Style.Font.Name = "Calibri";
			this.TotalCostOfSalesAndPurchases.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalCostOfSalesAndPurchases.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalCostOfSalesAndPurchases.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalCostOfSalesAndPurchases.StyleName = "Normal.TableHeader";
			this.TotalCostOfSalesAndPurchases.Value = "";
			this.TotalCostOfSalesAndPurchases.ItemDataBound += new System.EventHandler(this.TotalCostOfSalesAndPurchases_ItemDataBound);
			// 
			// TotalTaxSalesLabel
			// 
			this.TotalTaxSalesLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(7.6D));
			this.TotalTaxSalesLabel.Name = "TotalTaxSalesLabel";
			this.TotalTaxSalesLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalTaxSalesLabel.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TotalTaxSalesLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalTaxSalesLabel.Style.Font.Bold = true;
			this.TotalTaxSalesLabel.Style.Font.Name = "Calibri";
			this.TotalTaxSalesLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalTaxSalesLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalTaxSalesLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalTaxSalesLabel.StyleName = "Normal.TableHeader";
			this.TotalTaxSalesLabel.Value = "Total Tax on Sales";
			this.TotalTaxSalesLabel.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TotalTaxSales
			// 
			this.TotalTaxSales.Format = "{0:C2}";
			this.TotalTaxSales.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(7.6D));
			this.TotalTaxSales.Name = "TotalTaxSales";
			this.TotalTaxSales.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalTaxSales.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TotalTaxSales.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalTaxSales.Style.Font.Bold = true;
			this.TotalTaxSales.Style.Font.Name = "Calibri";
			this.TotalTaxSales.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalTaxSales.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalTaxSales.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalTaxSales.StyleName = "Normal.TableHeader";
			this.TotalTaxSales.Value = "";
			this.TotalTaxSales.ItemDataBound += new System.EventHandler(this.TotalTaxSales_ItemDataBound);
			// 
			// TotalTaxPurchasesLabel
			// 
			this.TotalTaxPurchasesLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(7.6D));
			this.TotalTaxPurchasesLabel.Name = "TotalTaxPurchasesLabel";
			this.TotalTaxPurchasesLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalTaxPurchasesLabel.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TotalTaxPurchasesLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalTaxPurchasesLabel.Style.Font.Bold = true;
			this.TotalTaxPurchasesLabel.Style.Font.Name = "Calibri";
			this.TotalTaxPurchasesLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalTaxPurchasesLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalTaxPurchasesLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalTaxPurchasesLabel.StyleName = "Normal.TableHeader";
			this.TotalTaxPurchasesLabel.Value = "Total Tax on Cost of Sales & Purchases";
			this.TotalTaxPurchasesLabel.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// TotalTaxPurchases
			// 
			this.TotalTaxPurchases.Format = "{0:C2}";
			this.TotalTaxPurchases.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(7.6D));
			this.TotalTaxPurchases.Name = "TotalTaxPurchases";
			this.TotalTaxPurchases.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalTaxPurchases.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TotalTaxPurchases.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalTaxPurchases.Style.Font.Bold = true;
			this.TotalTaxPurchases.Style.Font.Name = "Calibri";
			this.TotalTaxPurchases.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalTaxPurchases.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalTaxPurchases.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalTaxPurchases.StyleName = "Normal.TableHeader";
			this.TotalTaxPurchases.Value = "";
			this.TotalTaxPurchases.ItemDataBound += new System.EventHandler(this.TotalTaxPurchases_ItemDataBound);
			// 
			// SalaryWagesHeader
			// 
			this.SalaryWagesHeader.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.countryCode.Value = \"AUS\", True, False)"));
			this.SalaryWagesHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(8.7D));
			this.SalaryWagesHeader.Name = "SalaryWagesHeader";
			this.SalaryWagesHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.SalaryWagesHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.SalaryWagesHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.SalaryWagesHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.SalaryWagesHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.SalaryWagesHeader.Style.Font.Bold = true;
			this.SalaryWagesHeader.Style.Font.Name = "Calibri";
			this.SalaryWagesHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.SalaryWagesHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.SalaryWagesHeader.StyleName = "Normal.TableHeader";
			this.SalaryWagesHeader.Value = "Salaries & Wages/PAYG Withholding";
			// 
			// SalaryWagesLabel1
			// 
			this.SalaryWagesLabel1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.countryCode.Value = \"AUS\", True, False)"));
			this.SalaryWagesLabel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(9.3D));
			this.SalaryWagesLabel1.Name = "SalaryWagesLabel1";
			this.SalaryWagesLabel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.SalaryWagesLabel1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.SalaryWagesLabel1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.SalaryWagesLabel1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.SalaryWagesLabel1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.SalaryWagesLabel1.Style.Font.Name = "Calibri";
			this.SalaryWagesLabel1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.SalaryWagesLabel1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.SalaryWagesLabel1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.SalaryWagesLabel1.StyleName = "Normal.TableHeader";
			this.SalaryWagesLabel1.Value = "Salaries & Wages";
			this.SalaryWagesLabel1.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// SalaryWages1
			// 
			this.SalaryWages1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.countryCode.Value = \"AUS\", True, False)"));
			this.SalaryWages1.Format = "{0:C2}";
			this.SalaryWages1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(9.3D));
			this.SalaryWages1.Name = "SalaryWages1";
			this.SalaryWages1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.SalaryWages1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.SalaryWages1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.SalaryWages1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.SalaryWages1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.SalaryWages1.Style.Font.Name = "Calibri";
			this.SalaryWages1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.SalaryWages1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.SalaryWages1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.SalaryWages1.StyleName = "Normal.TableHeader";
			this.SalaryWages1.Value = "";
			this.SalaryWages1.ItemDataBound += new System.EventHandler(this.SalaryWages1_ItemDataBound);
			// 
			// SalaryWagesLabel2
			// 
			this.SalaryWagesLabel2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.countryCode.Value = \"AUS\", True, False)"));
			this.SalaryWagesLabel2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(9.9D));
			this.SalaryWagesLabel2.Name = "SalaryWagesLabel2";
			this.SalaryWagesLabel2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.SalaryWagesLabel2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.SalaryWagesLabel2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.SalaryWagesLabel2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.SalaryWagesLabel2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.SalaryWagesLabel2.Style.Font.Name = "Calibri";
			this.SalaryWagesLabel2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.SalaryWagesLabel2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.SalaryWagesLabel2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.SalaryWagesLabel2.StyleName = "Normal.TableHeader";
			this.SalaryWagesLabel2.Value = "PAYG Withholding";
			this.SalaryWagesLabel2.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// SalaryWages2
			// 
			this.SalaryWages2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.countryCode.Value = \"AUS\", True, False)"));
			this.SalaryWages2.Format = "{0:C2}";
			this.SalaryWages2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(9.9D));
			this.SalaryWages2.Name = "SalaryWages2";
			this.SalaryWages2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.SalaryWages2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.SalaryWages2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.SalaryWages2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.SalaryWages2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.SalaryWages2.Style.Font.Name = "Calibri";
			this.SalaryWages2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.SalaryWages2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.SalaryWages2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.SalaryWages2.StyleName = "Normal.TableHeader";
			this.SalaryWages2.Value = "";
			this.SalaryWages2.ItemDataBound += new System.EventHandler(this.SalaryWages2_ItemDataBound);
			// 
			// SalaryWagesFooter
			// 
			this.SalaryWagesFooter.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.countryCode.Value = \"AUS\", True, False)"));
			this.SalaryWagesFooter.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(10.5D));
			this.SalaryWagesFooter.Name = "SalaryWagesFooter";
			this.SalaryWagesFooter.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.SalaryWagesFooter.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.SalaryWagesFooter.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.SalaryWagesFooter.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.SalaryWagesFooter.Style.Font.Name = "Calibri";
			this.SalaryWagesFooter.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(9D);
			this.SalaryWagesFooter.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.SalaryWagesFooter.StyleName = "Normal.TableHeader";
			this.SalaryWagesFooter.Value = "Please verify these values against your STP report prior to BAS/IAS lodgement";
			// 
			// ReconciliationHeader
			// 
			this.ReconciliationHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(8.7D));
			this.ReconciliationHeader.Name = "ReconciliationHeader";
			this.ReconciliationHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReconciliationHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ReconciliationHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReconciliationHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ReconciliationHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ReconciliationHeader.Style.Font.Bold = true;
			this.ReconciliationHeader.Style.Font.Name = "Calibri";
			this.ReconciliationHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReconciliationHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReconciliationHeader.StyleName = "Normal.TableHeader";
			this.ReconciliationHeader.Value = "Tax Reconciliation";
			this.ReconciliationHeader.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// ReconciliationLabel1
			// 
			this.ReconciliationLabel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(9.3D));
			this.ReconciliationLabel1.Name = "ReconciliationLabel1";
			this.ReconciliationLabel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReconciliationLabel1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ReconciliationLabel1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReconciliationLabel1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ReconciliationLabel1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ReconciliationLabel1.Style.Font.Name = "Calibri";
			this.ReconciliationLabel1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReconciliationLabel1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ReconciliationLabel1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReconciliationLabel1.StyleName = "Normal.TableHeader";
			this.ReconciliationLabel1.Value = "Tax on Sales [0] - Tax on Purchases [1]";
			this.ReconciliationLabel1.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// Reconciliation1
			// 
			this.Reconciliation1.Format = "{0:C2}";
			this.Reconciliation1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(9.3D));
			this.Reconciliation1.Name = "Reconciliation1";
			this.Reconciliation1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Reconciliation1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.Reconciliation1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Reconciliation1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Reconciliation1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Reconciliation1.Style.Font.Name = "Calibri";
			this.Reconciliation1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Reconciliation1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Reconciliation1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Reconciliation1.StyleName = "Normal.TableHeader";
			this.Reconciliation1.Value = "";
			this.Reconciliation1.ItemDataBound += new System.EventHandler(this.Reconciliation1_ItemDataBound);
			// 
			// ReconciliationLabel2
			// 
			this.ReconciliationLabel2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(9.9D));
			this.ReconciliationLabel2.Name = "ReconciliationLabel2";
			this.ReconciliationLabel2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReconciliationLabel2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ReconciliationLabel2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReconciliationLabel2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ReconciliationLabel2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ReconciliationLabel2.Style.Font.Name = "Calibri";
			this.ReconciliationLabel2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReconciliationLabel2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ReconciliationLabel2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReconciliationLabel2.StyleName = "Normal.TableHeader";
			this.ReconciliationLabel2.Value = "GL Account: Sales [0] + Purchases [1]";
			this.ReconciliationLabel2.ItemDataBound += new System.EventHandler(this.Label_ItemDataBound);
			// 
			// Reconciliation2
			// 
			this.Reconciliation2.Format = "{0:C2}";
			this.Reconciliation2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(9.9D));
			this.Reconciliation2.Name = "Reconciliation2";
			this.Reconciliation2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Reconciliation2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.Reconciliation2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Reconciliation2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Reconciliation2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Reconciliation2.Style.Font.Name = "Calibri";
			this.Reconciliation2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Reconciliation2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Reconciliation2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Reconciliation2.StyleName = "Normal.TableHeader";
			this.Reconciliation2.Value = "";
			this.Reconciliation2.ItemDataBound += new System.EventHandler(this.Reconciliation2_ItemDataBound);
			// 
			// ReconciliationLabel3
			// 
			this.ReconciliationLabel3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.9D), Telerik.Reporting.Drawing.Unit.Cm(10.5D));
			this.ReconciliationLabel3.Name = "ReconciliationLabel3";
			this.ReconciliationLabel3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReconciliationLabel3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ReconciliationLabel3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReconciliationLabel3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ReconciliationLabel3.Style.Font.Name = "Calibri";
			this.ReconciliationLabel3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReconciliationLabel3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ReconciliationLabel3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReconciliationLabel3.StyleName = "Normal.TableHeader";
			this.ReconciliationLabel3.Value = "Difference";
			// 
			// Reconciliation3
			// 
			this.Reconciliation3.Format = "{0:C2}";
			this.Reconciliation3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(10.5D));
			this.Reconciliation3.Name = "Reconciliation3";
			this.Reconciliation3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Reconciliation3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.Reconciliation3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Reconciliation3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Reconciliation3.Style.Font.Name = "Calibri";
			this.Reconciliation3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Reconciliation3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Reconciliation3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Reconciliation3.StyleName = "Normal.TableHeader";
			this.Reconciliation3.Value = "";
			this.Reconciliation3.ItemDataBound += new System.EventHandler(this.Reconciliation3_ItemDataBound);
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ManagementReportHeaderSubReport1});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = true;
			this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// ManagementReportHeaderSubReport1
			// 
			this.ManagementReportHeaderSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ManagementReportHeaderSubReport1.Name = "ManagementReportHeaderSubReport1";
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerName", "= Parameters.customerName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportName", "= Parameters.reportName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportDate", "= Parameters.reportDate.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("headerContent", "= Parameters.headerContent.Value"));
			typeReportSource1.TypeName = "Travelog.Reports.Common.ManagementReportHeaderSubReport1, Travelog.Reports, Versi" +
    "on=1.0.0.0, Culture=neutral, PublicKeyToken=null";
			this.ManagementReportHeaderSubReport1.ReportSource = typeReportSource1;
			this.ManagementReportHeaderSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ManagementReportHeaderSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// Detail
			// 
			this.Detail.CanShrink = true;
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(7D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TaxAuditReportSubReport1,
            this.TaxAuditReportSubReport2,
            this.TaxAuditReportSubReport3,
            this.TaxAuditReportSubReport4,
            this.TaxAuditReportSubReport5});
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// TaxAuditReportSubReport1
			// 
			this.TaxAuditReportSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TaxAuditReportSubReport1.Name = "TaxAuditReportSubReport1";
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("userName", "= Parameters.userName.Value"));
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("dateFrom", "= Parameters.dateFrom.Value"));
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("dateTo", "= Parameters.dateTo.Value"));
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("descendingDateOrder", "= Parameters.descendingDateOrder.Value"));
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("reportGroupId", "= 0"));
			typeReportSource2.TypeName = "Travelog.Reports.Accounting.TaxAuditReportSubReport1, Travelog.Reports, Version=1" +
    ".0.0.0, Culture=neutral, PublicKeyToken=null";
			this.TaxAuditReportSubReport1.ReportSource = typeReportSource2;
			this.TaxAuditReportSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.TaxAuditReportSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxAuditReportSubReport1.ItemDataBound += new System.EventHandler(this.TaxAuditReportSubReport1_ItemDataBound);
			// 
			// TaxAuditReportSubReport2
			// 
			this.TaxAuditReportSubReport2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.TaxAuditReportSubReport2.Name = "TaxAuditReportSubReport2";
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("userName", "= Parameters.userName.Value"));
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("dateFrom", "= Parameters.dateFrom.Value"));
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("dateTo", "= Parameters.dateTo.Value"));
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("descendingDateOrder", "= Parameters.descendingDateOrder.Value"));
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("reportGroupId", "= 1"));
			typeReportSource3.TypeName = "Travelog.Reports.Accounting.TaxAuditReportSubReport1, Travelog.Reports, Version=1" +
    ".0.0.0, Culture=neutral, PublicKeyToken=null";
			this.TaxAuditReportSubReport2.ReportSource = typeReportSource3;
			this.TaxAuditReportSubReport2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.TaxAuditReportSubReport2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxAuditReportSubReport2.ItemDataBound += new System.EventHandler(this.TaxAuditReportSubReport2_ItemDataBound);
			// 
			// TaxAuditReportSubReport3
			// 
			this.TaxAuditReportSubReport3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.TaxAuditReportSubReport3.Name = "TaxAuditReportSubReport3";
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("userName", "= Parameters.userName.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("dateFrom", "= Parameters.dateFrom.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("dateTo", "= Parameters.dateTo.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("descendingDateOrder", "= Parameters.descendingDateOrder.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("reportGroupId", "= 2"));
			typeReportSource4.TypeName = "Travelog.Reports.Accounting.TaxAuditReportSubReport1, Travelog.Reports, Version=1" +
    ".0.0.0, Culture=neutral, PublicKeyToken=null";
			this.TaxAuditReportSubReport3.ReportSource = typeReportSource4;
			this.TaxAuditReportSubReport3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.TaxAuditReportSubReport3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxAuditReportSubReport3.ItemDataBound += new System.EventHandler(this.TaxAuditReportSubReport3_ItemDataBound);
			// 
			// TaxAuditReportSubReport4
			// 
			this.TaxAuditReportSubReport4.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.countryCode.Value = \"AUS\", True, False)"));
			this.TaxAuditReportSubReport4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.5D));
			this.TaxAuditReportSubReport4.Name = "TaxAuditReportSubReport4";
			typeReportSource5.Parameters.Add(new Telerik.Reporting.Parameter("userName", "= Parameters.userName.Value"));
			typeReportSource5.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource5.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
			typeReportSource5.Parameters.Add(new Telerik.Reporting.Parameter("dateFrom", "= Parameters.dateFrom.Value"));
			typeReportSource5.Parameters.Add(new Telerik.Reporting.Parameter("dateTo", "= Parameters.dateTo.Value"));
			typeReportSource5.Parameters.Add(new Telerik.Reporting.Parameter("descendingDateOrder", "= Parameters.descendingDateOrder.Value"));
			typeReportSource5.Parameters.Add(new Telerik.Reporting.Parameter("reportGroupId", "= 3"));
			typeReportSource5.TypeName = "Travelog.Reports.Accounting.TaxAuditReportSubReport2, Travelog.Reports, Version=1" +
    ".0.0.0, Culture=neutral, PublicKeyToken=null";
			this.TaxAuditReportSubReport4.ReportSource = typeReportSource5;
			this.TaxAuditReportSubReport4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.TaxAuditReportSubReport4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxAuditReportSubReport4.ItemDataBound += new System.EventHandler(this.TaxAuditReportSubReport4_ItemDataBound);
			// 
			// TaxAuditReportSubReport5
			// 
			this.TaxAuditReportSubReport5.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.countryCode.Value = \"AUS\", True, False)"));
			this.TaxAuditReportSubReport5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(6D));
			this.TaxAuditReportSubReport5.Name = "TaxAuditReportSubReport5";
			typeReportSource6.Parameters.Add(new Telerik.Reporting.Parameter("userName", "= Parameters.userName.Value"));
			typeReportSource6.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource6.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
			typeReportSource6.Parameters.Add(new Telerik.Reporting.Parameter("dateFrom", "= Parameters.dateFrom.Value"));
			typeReportSource6.Parameters.Add(new Telerik.Reporting.Parameter("dateTo", "= Parameters.dateTo.Value"));
			typeReportSource6.Parameters.Add(new Telerik.Reporting.Parameter("descendingDateOrder", "= Parameters.descendingDateOrder.Value"));
			typeReportSource6.Parameters.Add(new Telerik.Reporting.Parameter("reportGroupId", "= 4"));
			typeReportSource6.TypeName = "Travelog.Reports.Accounting.TaxAuditReportSubReport2, Travelog.Reports, Version=1" +
    ".0.0.0, Culture=neutral, PublicKeyToken=null";
			this.TaxAuditReportSubReport5.ReportSource = typeReportSource6;
			this.TaxAuditReportSubReport5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.TaxAuditReportSubReport5.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxAuditReportSubReport5.ItemDataBound += new System.EventHandler(this.TaxAuditReportSubReport5_ItemDataBound);
			// 
			// PageFooterSection
			// 
			this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
			this.PageFooterSection.Name = "PageFooter";
			// 
			// Pages
			// 
			this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.7D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Name = "Pages";
			this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Style.Color = System.Drawing.Color.DarkGray;
			this.Pages.Style.Font.Name = "Calibri";
			this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Pages.Value = "= \"Page \" + PageNumber";
			// 
			// CreationTime
			// 
			this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Name = "CreationTime";
			this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
			this.CreationTime.Style.Font.Name = "Calibri";
			this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy" +
    " HH:mm}\", Parameters.creationTime.Value)";
			// 
			// TaxAuditReport
			// 
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail,
            this.PageFooterSection});
			this.Name = "TaxAuditReport";
			this.PageSettings.Landscape = true;
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "userName";
			reportParameter3.Name = "countryCode";
			reportParameter4.Name = "customerId";
			reportParameter4.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter5.Name = "agencyId";
			reportParameter5.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter6.Name = "customerName";
			reportParameter7.Name = "reportName";
			reportParameter8.Name = "reportDate";
			reportParameter9.Name = "headerContent";
			reportParameter10.Name = "creationUser";
			reportParameter11.Name = "creationTime";
			reportParameter11.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter12.Name = "dateFrom";
			reportParameter12.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter13.Name = "dateTo";
			reportParameter13.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter14.Name = "descendingDateOrder";
			reportParameter14.Type = Telerik.Reporting.ReportParameterType.Boolean;
			reportParameter15.Name = "salesTaxAccountCode";
			reportParameter16.Name = "salesTaxAccountValue";
			reportParameter17.Name = "purchasesTaxAccountCode";
			reportParameter18.Name = "purchasesTaxAccountValue";
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.ReportParameters.Add(reportParameter9);
			this.ReportParameters.Add(reportParameter10);
			this.ReportParameters.Add(reportParameter11);
			this.ReportParameters.Add(reportParameter12);
			this.ReportParameters.Add(reportParameter13);
			this.ReportParameters.Add(reportParameter14);
			this.ReportParameters.Add(reportParameter15);
			this.ReportParameters.Add(reportParameter16);
			this.ReportParameters.Add(reportParameter17);
			this.ReportParameters.Add(reportParameter18);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(27.7D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.SubReport ManagementReportHeaderSubReport1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.SubReport TaxAuditReportSubReport1;
		private Telerik.Reporting.SubReport TaxAuditReportSubReport2;
		private Telerik.Reporting.SubReport TaxAuditReportSubReport3;
		private Telerik.Reporting.TextBox TaxApplicableSalesLabel1;
		private Telerik.Reporting.TextBox TaxApplicableSales1;
		private Telerik.Reporting.TextBox TaxApplicableSalesLabel2;
		private Telerik.Reporting.TextBox TaxApplicableSales2;
		private Telerik.Reporting.TextBox TaxApplicableSalesLabel3;
		private Telerik.Reporting.TextBox TaxApplicableSales3;
		private Telerik.Reporting.TextBox TaxApplicableSalesLabel4;
		private Telerik.Reporting.TextBox TaxApplicableSales4;
		private Telerik.Reporting.TextBox TaxApplicableSalesHeader;
		private Telerik.Reporting.TextBox TaxExemptSalesLabel1;
		private Telerik.Reporting.TextBox TaxExemptSales1;
		private Telerik.Reporting.TextBox TaxExemptSalesLabel2;
		private Telerik.Reporting.TextBox TaxExemptSales2;
		private Telerik.Reporting.TextBox TotalSalesLabel;
		private Telerik.Reporting.TextBox TotalSales;
		private Telerik.Reporting.TextBox TaxExemptSalesLabel3;
		private Telerik.Reporting.TextBox TaxExemptSales3;
		private Telerik.Reporting.TextBox TaxExemptSalesHeader;
		private Telerik.Reporting.TextBox CostOfSalesLabel1;
		private Telerik.Reporting.TextBox CostOfSales1;
		private Telerik.Reporting.TextBox CostOfSalesLabel2;
		private Telerik.Reporting.TextBox CostOfSales2;
		private Telerik.Reporting.TextBox CostOfSalesLabel3;
		private Telerik.Reporting.TextBox CostOfSales3;
		private Telerik.Reporting.TextBox CostOfSalesLabel4;
		private Telerik.Reporting.TextBox CostOfSales4;
		private Telerik.Reporting.TextBox CostOfSalesHeader;
		private Telerik.Reporting.TextBox CostOfSalesLabel5;
		private Telerik.Reporting.TextBox CostOfSales5;
		private Telerik.Reporting.TextBox TaxApplicablePurchasesLabel1;
		private Telerik.Reporting.TextBox TaxApplicablePurchases1;
		private Telerik.Reporting.TextBox TaxApplicablePurchasesLabel2;
		private Telerik.Reporting.TextBox TaxApplicablePurchases2;
		private Telerik.Reporting.TextBox TaxApplicablePurchasesLabel3;
		private Telerik.Reporting.TextBox TaxApplicablePurchases3;
		private Telerik.Reporting.TextBox PurchasesHeader;
		private Telerik.Reporting.TextBox TotalPurchasesAndCostOfSalesLabel;
		private Telerik.Reporting.TextBox TotalCostOfSalesAndPurchases;
		private Telerik.Reporting.TextBox TotalTaxSalesLabel;
		private Telerik.Reporting.TextBox TotalTaxSales;
		private Telerik.Reporting.TextBox TotalTaxPurchasesLabel;
		private Telerik.Reporting.TextBox TotalTaxPurchases;
		private Telerik.Reporting.SubReport TaxAuditReportSubReport4;
		private Telerik.Reporting.SubReport TaxAuditReportSubReport5;
		private Telerik.Reporting.TextBox SalaryWagesHeader;
		private Telerik.Reporting.TextBox SalaryWagesLabel1;
		private Telerik.Reporting.TextBox SalaryWages1;
		private Telerik.Reporting.TextBox SalaryWagesLabel2;
		private Telerik.Reporting.TextBox SalaryWages2;
		private Telerik.Reporting.TextBox SalaryWagesFooter;
		private Telerik.Reporting.TextBox ReconciliationHeader;
		private Telerik.Reporting.TextBox ReconciliationLabel1;
		private Telerik.Reporting.TextBox Reconciliation1;
		private Telerik.Reporting.TextBox ReconciliationLabel2;
		private Telerik.Reporting.TextBox Reconciliation2;
		private Telerik.Reporting.TextBox ReconciliationLabel3;
		private Telerik.Reporting.TextBox Reconciliation3;
	}
}