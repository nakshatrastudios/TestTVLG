namespace Travelog.Reports.Accounting {
	partial class VoucherReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.HeaderContent = new Telerik.Reporting.HtmlTextBox();
			this.Logo = new Telerik.Reporting.PictureBox();
			this.Panel = new Telerik.Reporting.Panel();
			this.Passengers = new Telerik.Reporting.TextBox();
			this.ReportNameLabel = new Telerik.Reporting.TextBox();
			this.BookingNo = new Telerik.Reporting.TextBox();
			this.VoucherNo = new Telerik.Reporting.TextBox();
			this.ConfirmationNo = new Telerik.Reporting.TextBox();
			this.PassengersLabel = new Telerik.Reporting.TextBox();
			this.ServiceLabel = new Telerik.Reporting.TextBox();
			this.Service = new Telerik.Reporting.TextBox();
			this.ServiceCommentsLabel = new Telerik.Reporting.TextBox();
			this.ServiceComments = new Telerik.Reporting.TextBox();
			this.StartDateLabel = new Telerik.Reporting.TextBox();
			this.StartDate = new Telerik.Reporting.TextBox();
			this.EndDateLabel = new Telerik.Reporting.TextBox();
			this.EndDate = new Telerik.Reporting.TextBox();
			this.StartDetailsLabel = new Telerik.Reporting.TextBox();
			this.StartDetails = new Telerik.Reporting.TextBox();
			this.EndDetailsLabel = new Telerik.Reporting.TextBox();
			this.EndDetails = new Telerik.Reporting.TextBox();
			this.ServiceProvider = new Telerik.Reporting.TextBox();
			this.PaymentDetails = new Telerik.Reporting.TextBox();
			this.ServiceProviderLabel = new Telerik.Reporting.TextBox();
			this.PaymentDetailsLabel = new Telerik.Reporting.TextBox();
			this.Copy = new Telerik.Reporting.TextBox();
			this.RateDescription = new Telerik.Reporting.HtmlTextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// Detail
			// 
			this.Detail.CanShrink = true;
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(9.5D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.HeaderContent,
            this.Logo,
            this.Panel});
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Dotted;
			this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Detail.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.25D);
			this.Detail.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.25D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// HeaderContent
			// 
			this.HeaderContent.CanGrow = false;
			this.HeaderContent.CanShrink = true;
			this.HeaderContent.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(2.3D));
			this.HeaderContent.Name = "HeaderContent";
			this.HeaderContent.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(6.7D));
			this.HeaderContent.Style.Font.Name = "Calibri";
			this.HeaderContent.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.HeaderContent.Value = "= Fields.HeaderContent";
			// 
			// Logo
			// 
			this.Logo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Logo.MimeType = "";
			this.Logo.Name = "Logo";
			this.Logo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(2D));
			this.Logo.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
			this.Logo.Style.BackgroundImage.Repeat = Telerik.Reporting.Drawing.BackgroundRepeat.NoRepeat;
			this.Logo.Value = "=Fields.Logo";
			// 
			// Panel
			// 
			this.Panel.CanShrink = true;
			this.Panel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Passengers,
            this.ReportNameLabel,
            this.BookingNo,
            this.VoucherNo,
            this.ConfirmationNo,
            this.PassengersLabel,
            this.ServiceLabel,
            this.Service,
            this.ServiceCommentsLabel,
            this.ServiceComments,
            this.StartDateLabel,
            this.StartDate,
            this.EndDateLabel,
            this.EndDate,
            this.StartDetailsLabel,
            this.StartDetails,
            this.EndDetailsLabel,
            this.EndDetails,
            this.ServiceProvider,
            this.PaymentDetails,
            this.ServiceProviderLabel,
            this.PaymentDetailsLabel,
            this.Copy,
            this.RateDescription});
			this.Panel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Panel.Name = "Panel";
			this.Panel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.5D), Telerik.Reporting.Drawing.Unit.Cm(9D));
			// 
			// Passengers
			// 
			this.Passengers.CanShrink = true;
			this.Passengers.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(1.75D));
			this.Passengers.Name = "Passengers";
			this.Passengers.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Passengers.Style.Font.Name = "Calibri";
			this.Passengers.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Passengers.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Passengers.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Passengers.Value = "= Fields.Passengers";
			// 
			// ReportNameLabel
			// 
			this.ReportNameLabel.CanShrink = true;
			this.ReportNameLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ReportNameLabel.Name = "ReportNameLabel";
			this.ReportNameLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ReportNameLabel.Style.Font.Bold = false;
			this.ReportNameLabel.Style.Font.Name = "Calibri";
			this.ReportNameLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(18D);
			this.ReportNameLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(0D);
			this.ReportNameLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReportNameLabel.Value = "SERVICE VOUCHER";
			// 
			// BookingNo
			// 
			this.BookingNo.CanShrink = true;
			this.BookingNo.Format = "";
			this.BookingNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BookingNo.Name = "BookingNo";
			this.BookingNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BookingNo.Style.Font.Name = "Calibri";
			this.BookingNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BookingNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BookingNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BookingNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BookingNo.Value = "= \"Booking No: \" + Fields.TripNo";
			// 
			// VoucherNo
			// 
			this.VoucherNo.CanShrink = true;
			this.VoucherNo.Format = "";
			this.VoucherNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.VoucherNo.Name = "VoucherNo";
			this.VoucherNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.VoucherNo.Style.Font.Name = "Calibri";
			this.VoucherNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.VoucherNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.VoucherNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.VoucherNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.VoucherNo.Value = "= \"Voucher No: \" + Fields.VoucherNo";
			// 
			// ConfirmationNo
			// 
			this.ConfirmationNo.CanShrink = true;
			this.ConfirmationNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ConfirmationNo.Name = "ConfirmationNo";
			this.ConfirmationNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.ConfirmationNo.Style.Font.Name = "Calibri";
			this.ConfirmationNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ConfirmationNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ConfirmationNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ConfirmationNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ConfirmationNo.Value = "= \"Confirmation No: \" + Fields.ConfirmationNo";
			// 
			// PassengersLabel
			// 
			this.PassengersLabel.CanShrink = true;
			this.PassengersLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.75D));
			this.PassengersLabel.Name = "PassengersLabel";
			this.PassengersLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.PassengersLabel.Style.Font.Name = "Calibri";
			this.PassengersLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PassengersLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PassengersLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PassengersLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.PassengersLabel.Value = "Clients:";
			// 
			// ServiceLabel
			// 
			this.ServiceLabel.CanShrink = true;
			this.ServiceLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.25D));
			this.ServiceLabel.Name = "ServiceLabel";
			this.ServiceLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.ServiceLabel.Style.Font.Name = "Calibri";
			this.ServiceLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ServiceLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.ServiceLabel.Value = "= Fields.ServiceLabel";
			// 
			// Service
			// 
			this.Service.CanShrink = true;
			this.Service.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(2.25D));
			this.Service.Name = "Service";
			this.Service.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Service.Style.Font.Name = "Calibri";
			this.Service.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Service.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Service.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Service.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.Service.Value = "= Fields.Service";
			// 
			// ServiceCommentsLabel
			// 
			this.ServiceCommentsLabel.CanGrow = false;
			this.ServiceCommentsLabel.CanShrink = true;
			this.ServiceCommentsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.75D));
			this.ServiceCommentsLabel.Name = "ServiceCommentsLabel";
			this.ServiceCommentsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.ServiceCommentsLabel.Style.Font.Name = "Calibri";
			this.ServiceCommentsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ServiceCommentsLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceCommentsLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceCommentsLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.ServiceCommentsLabel.Value = "Service Comments:";
			// 
			// ServiceComments
			// 
			this.ServiceComments.CanGrow = false;
			this.ServiceComments.CanShrink = true;
			this.ServiceComments.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(2.75D));
			this.ServiceComments.Name = "ServiceComments";
			this.ServiceComments.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.ServiceComments.Style.Font.Name = "Calibri";
			this.ServiceComments.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ServiceComments.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceComments.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceComments.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.ServiceComments.Value = "= Fields.ServiceComments";
			// 
			// StartDateLabel
			// 
			this.StartDateLabel.CanShrink = true;
			this.StartDateLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.25D));
			this.StartDateLabel.Name = "StartDateLabel";
			this.StartDateLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.StartDateLabel.Style.Font.Name = "Calibri";
			this.StartDateLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.StartDateLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.StartDateLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.StartDateLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.StartDateLabel.Value = "= Fields.StartDateLabel";
			// 
			// StartDate
			// 
			this.StartDate.CanShrink = true;
			this.StartDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(4.25D));
			this.StartDate.Name = "StartDate";
			this.StartDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.StartDate.Style.Font.Name = "Calibri";
			this.StartDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.StartDate.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.StartDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.StartDate.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.StartDate.Value = "= Format(\"{0:dd-MMM-yyyy}\", Fields.StartDate)";
			// 
			// EndDateLabel
			// 
			this.EndDateLabel.CanShrink = true;
			this.EndDateLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.75D));
			this.EndDateLabel.Name = "EndDateLabel";
			this.EndDateLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.EndDateLabel.Style.Font.Name = "Calibri";
			this.EndDateLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.EndDateLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.EndDateLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.EndDateLabel.Value = "= Fields.EndDateLabel";
			// 
			// EndDate
			// 
			this.EndDate.CanShrink = true;
			this.EndDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(4.75D));
			this.EndDate.Name = "EndDate";
			this.EndDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.EndDate.Style.Font.Name = "Calibri";
			this.EndDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.EndDate.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.EndDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.EndDate.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.EndDate.Value = "= Format(\"{0:dd-MMM-yyyy}\", Fields.EndDate)";
			// 
			// StartDetailsLabel
			// 
			this.StartDetailsLabel.CanShrink = true;
			this.StartDetailsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.25D));
			this.StartDetailsLabel.Name = "StartDetailsLabel";
			this.StartDetailsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.StartDetailsLabel.Style.Font.Name = "Calibri";
			this.StartDetailsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.StartDetailsLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.StartDetailsLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.StartDetailsLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.StartDetailsLabel.Value = "= Fields.StartDetailsLabel";
			// 
			// StartDetails
			// 
			this.StartDetails.CanShrink = true;
			this.StartDetails.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(5.25D));
			this.StartDetails.Name = "StartDetails";
			this.StartDetails.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.StartDetails.Style.Font.Name = "Calibri";
			this.StartDetails.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.StartDetails.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.StartDetails.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.StartDetails.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.StartDetails.Value = "= Fields.StartDetails";
			// 
			// EndDetailsLabel
			// 
			this.EndDetailsLabel.CanShrink = true;
			this.EndDetailsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.75D));
			this.EndDetailsLabel.Name = "EndDetailsLabel";
			this.EndDetailsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.EndDetailsLabel.Style.Font.Name = "Calibri";
			this.EndDetailsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.EndDetailsLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.EndDetailsLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.EndDetailsLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.EndDetailsLabel.Value = "= Fields.EndDetailsLabel";
			// 
			// EndDetails
			// 
			this.EndDetails.CanShrink = true;
			this.EndDetails.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(5.75D));
			this.EndDetails.Name = "EndDetails";
			this.EndDetails.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.EndDetails.Style.Font.Name = "Calibri";
			this.EndDetails.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.EndDetails.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.EndDetails.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.EndDetails.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.EndDetails.Value = "= Fields.EndDetails";
			// 
			// ServiceProvider
			// 
			this.ServiceProvider.CanShrink = true;
			this.ServiceProvider.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(6.25D));
			this.ServiceProvider.Name = "ServiceProvider";
			this.ServiceProvider.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.ServiceProvider.Style.Font.Name = "Calibri";
			this.ServiceProvider.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ServiceProvider.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceProvider.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceProvider.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.ServiceProvider.Value = "= Fields.ServiceProvider";
			// 
			// PaymentDetails
			// 
			this.PaymentDetails.CanShrink = true;
			this.PaymentDetails.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(6.75D));
			this.PaymentDetails.Name = "PaymentDetails";
			this.PaymentDetails.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.PaymentDetails.Style.Font.Name = "Calibri";
			this.PaymentDetails.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PaymentDetails.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PaymentDetails.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PaymentDetails.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.PaymentDetails.Value = "= Fields.PaymentDetails";
			// 
			// ServiceProviderLabel
			// 
			this.ServiceProviderLabel.CanShrink = true;
			this.ServiceProviderLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(6.25D));
			this.ServiceProviderLabel.Name = "ServiceProviderLabel";
			this.ServiceProviderLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.ServiceProviderLabel.Style.Font.Name = "Calibri";
			this.ServiceProviderLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ServiceProviderLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceProviderLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceProviderLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.ServiceProviderLabel.Value = "Service Provider:";
			// 
			// PaymentDetailsLabel
			// 
			this.PaymentDetailsLabel.CanShrink = true;
			this.PaymentDetailsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(6.75D));
			this.PaymentDetailsLabel.Name = "PaymentDetailsLabel";
			this.PaymentDetailsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.PaymentDetailsLabel.Style.Font.Name = "Calibri";
			this.PaymentDetailsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PaymentDetailsLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PaymentDetailsLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.PaymentDetailsLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.PaymentDetailsLabel.Value = "Payment Details:";
			// 
			// Copy
			// 
			this.Copy.CanShrink = true;
			this.Copy.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.Copy.Name = "Copy";
			this.Copy.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Copy.Style.Font.Name = "Calibri";
			this.Copy.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Copy.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Copy.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Copy.Value = "= Fields.Copy";
			// 
			// RateDescription
			// 
			this.RateDescription.CanGrow = false;
			this.RateDescription.CanShrink = true;
			this.RateDescription.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(7.5D));
			this.RateDescription.Name = "RateDescription";
			this.RateDescription.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.RateDescription.Style.Font.Name = "Calibri";
			this.RateDescription.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.RateDescription.Value = "= Fields.RateDescription";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "VoucherReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.Accounting.AccountingDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("voucherId", typeof(int), "= Parameters.voucherId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			// 
			// VoucherReport
			// 
			this.DataSource = this.ReportDataSource;
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Detail});
			this.Name = "VoucherReport";
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "customerId";
			reportParameter1.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter2.Name = "agencyId";
			reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter3.Name = "voucherId";
			reportParameter3.Type = Telerik.Reporting.ReportParameterType.Integer;
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(18D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.HtmlTextBox HeaderContent;
		private Telerik.Reporting.Panel Panel;
		private Telerik.Reporting.TextBox Passengers;
		private Telerik.Reporting.TextBox BookingNo;
		private Telerik.Reporting.TextBox VoucherNo;
		private Telerik.Reporting.TextBox ConfirmationNo;
		private Telerik.Reporting.TextBox PassengersLabel;
		private Telerik.Reporting.TextBox ServiceLabel;
		private Telerik.Reporting.TextBox Service;
		private Telerik.Reporting.TextBox ServiceCommentsLabel;
		private Telerik.Reporting.TextBox ServiceComments;
		private Telerik.Reporting.TextBox StartDateLabel;
		private Telerik.Reporting.TextBox StartDate;
		private Telerik.Reporting.TextBox EndDateLabel;
		private Telerik.Reporting.TextBox EndDate;
		private Telerik.Reporting.TextBox StartDetailsLabel;
		private Telerik.Reporting.TextBox StartDetails;
		private Telerik.Reporting.TextBox EndDetailsLabel;
		private Telerik.Reporting.TextBox EndDetails;
		private Telerik.Reporting.TextBox ServiceProvider;
		private Telerik.Reporting.TextBox PaymentDetails;
		private Telerik.Reporting.TextBox ServiceProviderLabel;
		private Telerik.Reporting.TextBox PaymentDetailsLabel;
		private Telerik.Reporting.TextBox ReportNameLabel;
		private Telerik.Reporting.TextBox Copy;
		private Telerik.Reporting.HtmlTextBox RateDescription;
		private Telerik.Reporting.PictureBox Logo;
	}
}