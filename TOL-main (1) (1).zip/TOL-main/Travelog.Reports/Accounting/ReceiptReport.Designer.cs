namespace Travelog.Reports.Accounting {
	partial class ReceiptReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TypeReportSource typeReportSource2 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TypeReportSource typeReportSource3 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup10 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
			this.AccountHeader = new Telerik.Reporting.TextBox();
			this.ReferenceHeader = new Telerik.Reporting.TextBox();
			this.FormOfPaymentHeader = new Telerik.Reporting.TextBox();
			this.AmountHeader = new Telerik.Reporting.TextBox();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.AgencyFooterSubReport = new Telerik.Reporting.SubReport();
			this.StandardComment = new Telerik.Reporting.TextBox();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.AgencyHeaderSubReport1 = new Telerik.Reporting.SubReport();
			this.ReportNameLabel = new Telerik.Reporting.TextBox();
			this.ReceiptDate = new Telerik.Reporting.TextBox();
			this.TaxNo = new Telerik.Reporting.TextBox();
			this.Consultant = new Telerik.Reporting.TextBox();
			this.GroupFooterSection2 = new Telerik.Reporting.GroupFooterSection();
			this.GroupHeaderSection2 = new Telerik.Reporting.GroupHeaderSection();
			this.AgencyHeaderSubReport2 = new Telerik.Reporting.SubReport();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.TotalAmountLabel = new Telerik.Reporting.TextBox();
			this.ReceiptSubTotal = new Telerik.Reporting.TextBox();
			this.ReceiptTax = new Telerik.Reporting.TextBox();
			this.ReceiptTotalLabel = new Telerik.Reporting.TextBox();
			this.ReceiptTotal = new Telerik.Reporting.TextBox();
			this.TotalTaxLabel = new Telerik.Reporting.TextBox();
			this.DetailTable = new Telerik.Reporting.Crosstab();
			this.TripLine = new Telerik.Reporting.TextBox();
			this.Reference = new Telerik.Reporting.TextBox();
			this.FormOfPayment = new Telerik.Reporting.TextBox();
			this.Amount = new Telerik.Reporting.TextBox();
			this.AccountNameHeader = new Telerik.Reporting.TextBox();
			this.Comments = new Telerik.Reporting.HtmlTextBox();
			this.Pages = new Telerik.Reporting.TextBox();
			this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
			this.CreationTime = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// AccountHeader
			// 
			this.AccountHeader.Bindings.Add(new Telerik.Reporting.Binding("Width", "= IIf(Fields.IsCustomer, \"11cm\", \"7cm\")"));
			this.AccountHeader.Name = "AccountHeader";
			this.AccountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccountHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AccountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccountHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AccountHeader.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.AccountHeader.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.AccountHeader.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.AccountHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AccountHeader.Style.Font.Bold = true;
			this.AccountHeader.Style.Font.Name = "Calibri";
			this.AccountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AccountHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AccountHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AccountHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AccountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AccountHeader.StyleName = "Normal.TableHeader";
			this.AccountHeader.Value = "= IIf(Fields.IsCustomer, \"Description\", \"Account\")";
			// 
			// ReferenceHeader
			// 
			this.ReferenceHeader.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.IsCustomer, False, True)"));
			this.ReferenceHeader.Name = "ReferenceHeader";
			this.ReferenceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReferenceHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ReferenceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReferenceHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ReferenceHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ReferenceHeader.Style.Font.Bold = true;
			this.ReferenceHeader.Style.Font.Name = "Calibri";
			this.ReferenceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReferenceHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ReferenceHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReferenceHeader.StyleName = "Normal.TableHeader";
			this.ReferenceHeader.Value = "Reference";
			// 
			// FormOfPaymentHeader
			// 
			this.FormOfPaymentHeader.Name = "FormOfPaymentHeader";
			this.FormOfPaymentHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.FormOfPaymentHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.FormOfPaymentHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.FormOfPaymentHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.FormOfPaymentHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.FormOfPaymentHeader.Style.Font.Bold = true;
			this.FormOfPaymentHeader.Style.Font.Name = "Calibri";
			this.FormOfPaymentHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.FormOfPaymentHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.FormOfPaymentHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.FormOfPaymentHeader.StyleName = "Normal.TableHeader";
			this.FormOfPaymentHeader.Value = "Form of Payment";
			// 
			// AmountHeader
			// 
			this.AmountHeader.Name = "AmountHeader";
			this.AmountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AmountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AmountHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AmountHeader.Style.Font.Bold = true;
			this.AmountHeader.Style.Font.Name = "Calibri";
			this.AmountHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AmountHeader.StyleName = "Normal.TableHeader";
			this.AmountHeader.Value = "Amount";
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.CanShrink = true;
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1.6D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AgencyFooterSubReport,
            this.StandardComment});
			this.GroupFooterSection1.KeepTogether = false;
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			// 
			// AgencyFooterSubReport
			// 
			this.AgencyFooterSubReport.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AgencyFooterSubReport.Name = "AgencyFooterSubReport";
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
			typeReportSource1.TypeName = "Travelog.Reports.Common.AgencyFooterSubReport, Travelog.Reports, Version=1.0.0.0," +
    " Culture=neutral, PublicKeyToken=null";
			this.AgencyFooterSubReport.ReportSource = typeReportSource1;
			this.AgencyFooterSubReport.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.AgencyFooterSubReport.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// StandardComment
			// 
			this.StandardComment.Bindings.Add(new Telerik.Reporting.Binding("Style.Padding.Bottom", "=IIf(IsNull(Fields.StandardComment,\"\")=\"\",\"0\",\"0.5cm\")"));
			this.StandardComment.CanShrink = true;
			this.StandardComment.KeepTogether = false;
			this.StandardComment.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.StandardComment.Name = "StandardComment";
			this.StandardComment.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.StandardComment.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.StandardComment.Style.Font.Name = "Calibri";
			this.StandardComment.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.StandardComment.StyleName = "Normal.TableBody";
			this.StandardComment.Value = "= Fields.StandardComment";
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(2.5D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AgencyHeaderSubReport1,
            this.ReportNameLabel,
            this.ReceiptDate,
            this.TaxNo,
            this.Consultant});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = false;
			// 
			// AgencyHeaderSubReport1
			// 
			this.AgencyHeaderSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AgencyHeaderSubReport1.Name = "AgencyHeaderSubReport1";
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
			typeReportSource2.TypeName = "Travelog.Reports.Common.AgencyHeaderSubReport1, Travelog.Reports, Version=1.0.0.0" +
    ", Culture=neutral, PublicKeyToken=null";
			this.AgencyHeaderSubReport1.ReportSource = typeReportSource2;
			this.AgencyHeaderSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.AgencyHeaderSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// ReportNameLabel
			// 
			this.ReportNameLabel.CanShrink = true;
			this.ReportNameLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ReportNameLabel.Name = "ReportNameLabel";
			this.ReportNameLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.ReportNameLabel.Style.Font.Bold = false;
			this.ReportNameLabel.Style.Font.Name = "Calibri";
			this.ReportNameLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(18D);
			this.ReportNameLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(0D);
			this.ReportNameLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReportNameLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ReportNameLabel.Value = "= IIf(Fields.ReceiptType = \"Refund\", \"REFUND NO \", \"RECEIPT NO \") + Fields.Docume" +
    "ntNo";
			// 
			// ReceiptDate
			// 
			this.ReceiptDate.CanShrink = true;
			this.ReceiptDate.Format = "";
			this.ReceiptDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.ReceiptDate.Name = "ReceiptDate";
			this.ReceiptDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.ReceiptDate.Style.Font.Name = "Calibri";
			this.ReceiptDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReceiptDate.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReceiptDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReceiptDate.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ReceiptDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReceiptDate.Value = "= \"Receipt Date: \" + Format(\"{0:dd-MMM-yyyy}\", Fields.DocumentDate)";
			// 
			// TaxNo
			// 
			this.TaxNo.CanShrink = true;
			this.TaxNo.Format = "";
			this.TaxNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.TaxNo.Name = "TaxNo";
			this.TaxNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.TaxNo.Style.Font.Name = "Calibri";
			this.TaxNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxNo.Value = "= Fields.TaxNo";
			this.TaxNo.ItemDataBound += new System.EventHandler(this.TaxNo_ItemDataBound);
			// 
			// Consultant
			// 
			this.Consultant.CanShrink = true;
			this.Consultant.Format = "";
			this.Consultant.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(2D));
			this.Consultant.Name = "Consultant";
			this.Consultant.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Consultant.Style.Font.Name = "Calibri";
			this.Consultant.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Consultant.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Consultant.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Consultant.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Consultant.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Consultant.Value = "= \"Issued By: \" + Fields.Consultant";
			// 
			// GroupFooterSection2
			// 
			this.GroupFooterSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupFooterSection2.Name = "GroupFooterSection2";
			this.GroupFooterSection2.Style.Visible = false;
			// 
			// GroupHeaderSection2
			// 
			this.GroupHeaderSection2.CanShrink = true;
			this.GroupHeaderSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.GroupHeaderSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AgencyHeaderSubReport2});
			this.GroupHeaderSection2.KeepTogether = false;
			this.GroupHeaderSection2.Name = "GroupHeaderSection2";
			this.GroupHeaderSection2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0D);
			// 
			// AgencyHeaderSubReport2
			// 
			this.AgencyHeaderSubReport2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AgencyHeaderSubReport2.Name = "AgencyHeaderSubReport2";
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
			typeReportSource3.TypeName = "Travelog.Reports.Common.AgencyHeaderSubReport2, Travelog.Reports, Version=1.0.0.0" +
    ", Culture=neutral, PublicKeyToken=null";
			this.AgencyHeaderSubReport2.ReportSource = typeReportSource3;
			this.AgencyHeaderSubReport2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.AgencyHeaderSubReport2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// Detail
			// 
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(4.7D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TotalAmountLabel,
            this.ReceiptSubTotal,
            this.ReceiptTax,
            this.ReceiptTotalLabel,
            this.ReceiptTotal,
            this.TotalTaxLabel,
            this.DetailTable});
			this.Detail.Name = "Detail";
			this.Detail.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// TotalAmountLabel
			// 
			this.TotalAmountLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
			this.TotalAmountLabel.Name = "TotalAmountLabel";
			this.TotalAmountLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalAmountLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalAmountLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TotalAmountLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TotalAmountLabel.Style.Font.Name = "Calibri";
			this.TotalAmountLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalAmountLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TotalAmountLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalAmountLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalAmountLabel.StyleName = "Normal.TableBody";
			this.TotalAmountLabel.Value = "Sub-Total";
			// 
			// ReceiptSubTotal
			// 
			this.ReceiptSubTotal.Format = "{0:C2}";
			this.ReceiptSubTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
			this.ReceiptSubTotal.Name = "ReceiptSubTotal";
			this.ReceiptSubTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReceiptSubTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReceiptSubTotal.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ReceiptSubTotal.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ReceiptSubTotal.Style.Font.Name = "Calibri";
			this.ReceiptSubTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReceiptSubTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ReceiptSubTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReceiptSubTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ReceiptSubTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReceiptSubTotal.StyleName = "Normal.TableBody";
			this.ReceiptSubTotal.Value = "= Fields.TotalAmount";
			// 
			// ReceiptTax
			// 
			this.ReceiptTax.Bindings.Add(new Telerik.Reporting.Binding("Visible", "=IIf(Parameters.accountType.Value = \"Client\" Or Parameters.accountType.Value = \"D" +
            "ebtor\", False, True)"));
			this.ReceiptTax.Format = "{0:C2}";
			this.ReceiptTax.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.ReceiptTax.Name = "ReceiptTax";
			this.ReceiptTax.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReceiptTax.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReceiptTax.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ReceiptTax.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ReceiptTax.Style.Font.Name = "Calibri";
			this.ReceiptTax.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReceiptTax.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ReceiptTax.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReceiptTax.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ReceiptTax.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReceiptTax.StyleName = "Normal.TableBody";
			this.ReceiptTax.Value = "= Fields.TotalTax";
			// 
			// ReceiptTotalLabel
			// 
			this.ReceiptTotalLabel.Format = "";
			this.ReceiptTotalLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
			this.ReceiptTotalLabel.Name = "ReceiptTotalLabel";
			this.ReceiptTotalLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReceiptTotalLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReceiptTotalLabel.Style.Font.Name = "Calibri";
			this.ReceiptTotalLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReceiptTotalLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReceiptTotalLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ReceiptTotalLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReceiptTotalLabel.StyleName = "Normal.TableBody";
			this.ReceiptTotalLabel.Value = "Receipt Total";
			// 
			// ReceiptTotal
			// 
			this.ReceiptTotal.Format = "{0:C2}";
			this.ReceiptTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
			this.ReceiptTotal.Name = "ReceiptTotal";
			this.ReceiptTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReceiptTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReceiptTotal.Style.Font.Name = "Calibri";
			this.ReceiptTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReceiptTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ReceiptTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReceiptTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ReceiptTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReceiptTotal.StyleName = "Normal.TableBody";
			this.ReceiptTotal.Value = "= Fields.DocumentTotal";
			// 
			// TotalTaxLabel
			// 
			this.TotalTaxLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "=IIf(Parameters.accountType.Value = \"Client\" Or Parameters.accountType.Value = \"D" +
            "ebtor\", False, True)"));
			this.TotalTaxLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.TotalTaxLabel.Name = "TotalTaxLabel";
			this.TotalTaxLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalTaxLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalTaxLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TotalTaxLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TotalTaxLabel.Style.Font.Name = "Calibri";
			this.TotalTaxLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalTaxLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalTaxLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalTaxLabel.StyleName = "Normal.TableBody";
			this.TotalTaxLabel.Value = "Tax";
			this.TotalTaxLabel.ItemDataBound += new System.EventHandler(this.TotalTaxLabel_ItemDataBound);
			// 
			// DetailTable
			// 
			this.DetailTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.ReceiptDetailReportList"));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(7D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(4D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(4D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.SetCellContent(1, 0, this.TripLine);
			this.DetailTable.Body.SetCellContent(1, 1, this.Reference);
			this.DetailTable.Body.SetCellContent(1, 2, this.FormOfPayment);
			this.DetailTable.Body.SetCellContent(1, 3, this.Amount);
			this.DetailTable.Body.SetCellContent(0, 0, this.AccountNameHeader, 1, 4);
			this.DetailTable.Body.SetCellContent(2, 0, this.Comments, 1, 4);
			tableGroup1.Name = "tableGroup8";
			tableGroup1.ReportItem = this.AccountHeader;
			tableGroup2.Name = "group";
			tableGroup2.ReportItem = this.ReferenceHeader;
			tableGroup3.Name = "group1";
			tableGroup3.ReportItem = this.FormOfPaymentHeader;
			tableGroup4.Name = "group7";
			tableGroup4.ReportItem = this.AmountHeader;
			this.DetailTable.ColumnGroups.Add(tableGroup1);
			this.DetailTable.ColumnGroups.Add(tableGroup2);
			this.DetailTable.ColumnGroups.Add(tableGroup3);
			this.DetailTable.ColumnGroups.Add(tableGroup4);
			this.DetailTable.ColumnHeadersPrintOnEveryPage = true;
			this.DetailTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AccountNameHeader,
            this.TripLine,
            this.Reference,
            this.FormOfPayment,
            this.Amount,
            this.Comments,
            this.AccountHeader,
            this.ReferenceHeader,
            this.FormOfPaymentHeader,
            this.AmountHeader});
			this.DetailTable.KeepTogether = false;
			this.DetailTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DetailTable.Name = "DetailTable";
			this.DetailTable.NoDataMessage = "No records available.";
			tableGroup7.Name = "group9";
			tableGroup6.ChildGroups.Add(tableGroup7);
			tableGroup6.Name = "group8";
			tableGroup9.Name = "group6";
			tableGroup10.Name = "group2";
			tableGroup8.ChildGroups.Add(tableGroup9);
			tableGroup8.ChildGroups.Add(tableGroup10);
			tableGroup8.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup8.Name = "detailTableGroup";
			tableGroup5.ChildGroups.Add(tableGroup6);
			tableGroup5.ChildGroups.Add(tableGroup8);
			tableGroup5.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.AccountName"));
			tableGroup5.Name = "AccountName";
			this.DetailTable.RowGroups.Add(tableGroup5);
			this.DetailTable.RowHeadersPrintOnEveryPage = true;
			this.DetailTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
			// 
			// TripLine
			// 
			this.TripLine.Bindings.Add(new Telerik.Reporting.Binding("Width", "= IIf(Fields.IsCustomer, \"11cm\", \"7cm\")"));
			this.TripLine.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.Comments=\"\",\"Solid\", \"None\")"));
			this.TripLine.Format = "";
			this.TripLine.Name = "TripLine";
			this.TripLine.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TripLine.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TripLine.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TripLine.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.TripLine.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.TripLine.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.TripLine.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TripLine.Style.Font.Name = "Calibri";
			this.TripLine.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TripLine.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TripLine.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TripLine.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TripLine.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TripLine.StyleName = "Normal.TableBody";
			this.TripLine.Value = "= Fields.TripLine";
			// 
			// Reference
			// 
			this.Reference.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.IsCustomer, False, True)"));
			this.Reference.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.Comments=\"\",\"Solid\", \"None\")"));
			this.Reference.Format = "{0:dd-MMM-yyyy}";
			this.Reference.Name = "Reference";
			this.Reference.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Reference.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Reference.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Reference.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Reference.Style.Font.Name = "Calibri";
			this.Reference.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Reference.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Reference.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Reference.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Reference.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Reference.Style.Visible = true;
			this.Reference.StyleName = "Normal.TableBody";
			this.Reference.Value = "= Fields.Reference";
			// 
			// FormOfPayment
			// 
			this.FormOfPayment.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.Comments=\"\",\"Solid\", \"None\")"));
			this.FormOfPayment.Name = "FormOfPayment";
			this.FormOfPayment.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.FormOfPayment.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.FormOfPayment.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.FormOfPayment.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.FormOfPayment.Style.Font.Name = "Calibri";
			this.FormOfPayment.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.FormOfPayment.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.FormOfPayment.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.FormOfPayment.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.FormOfPayment.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.FormOfPayment.Style.Visible = true;
			this.FormOfPayment.StyleName = "Normal.TableBody";
			this.FormOfPayment.Value = "= Fields.FormOfPayment";
			// 
			// Amount
			// 
			this.Amount.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.Comments=\"\",\"Solid\", \"None\")"));
			this.Amount.Format = "{0:c2}";
			this.Amount.Name = "Amount";
			this.Amount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Amount.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Amount.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Amount.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Amount.Style.Font.Name = "Calibri";
			this.Amount.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Amount.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Amount.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Amount.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Amount.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Amount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Amount.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Amount.Style.Visible = true;
			this.Amount.StyleName = "Normal.TableBody";
			this.Amount.Value = "= Fields.Amount";
			// 
			// AccountNameHeader
			// 
			this.AccountNameHeader.Bindings.Add(new Telerik.Reporting.Binding("Width", "= IIf(Fields.IsCustomer, \"11cm\", \"7cm\")"));
			this.AccountNameHeader.Name = "AccountNameHeader";
			this.AccountNameHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccountNameHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.AccountNameHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccountNameHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AccountNameHeader.Style.Font.Italic = true;
			this.AccountNameHeader.Style.Font.Name = "Calibri";
			this.AccountNameHeader.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AccountNameHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AccountNameHeader.StyleName = "Normal.TableBody";
			this.AccountNameHeader.Value = "= Fields.AccountName";
			// 
			// Comments
			// 
			this.Comments.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.Comments=\"\", False, True)"));
			this.Comments.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Italic", "= IIf(Fields.IsCustomer, False, True)"));
			this.Comments.Name = "Comments";
			this.Comments.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Comments.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Comments.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Comments.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Comments.Style.Font.Italic = true;
			this.Comments.Style.Font.Name = "Calibri";
			this.Comments.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Comments.StyleName = "";
			this.Comments.Value = "= Fields.Comments";
			// 
			// Pages
			// 
			this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Name = "Pages";
			this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Style.Color = System.Drawing.Color.DarkGray;
			this.Pages.Style.Font.Name = "Calibri";
			this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Pages.Value = "= \"Page \" + PageNumber + \" of \" + PageCount";
			// 
			// PageFooterSection
			// 
			this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
			this.PageFooterSection.Name = "PageFooterSection";
			// 
			// CreationTime
			// 
			this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Name = "CreationTime";
			this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
			this.CreationTime.Style.Font.Name = "Calibri";
			this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy" +
    " HH:mm}\", Parameters.creationTime.Value)";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "ReceiptReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.Accounting.AccountingDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("userName", typeof(string), "= Parameters.userName.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("receiptId", typeof(int), "= Parameters.receiptId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("documentNo", typeof(string), "= Parameters.documentNo.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			// 
			// ReceiptReport
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			group2.GroupFooter = this.GroupFooterSection2;
			group2.GroupHeader = this.GroupHeaderSection2;
			group2.Name = "Group2";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.GroupHeaderSection2,
            this.GroupFooterSection2,
            this.Detail,
            this.PageFooterSection});
			this.Name = "ReceiptReport";
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "userName";
			reportParameter3.Name = "customerId";
			reportParameter3.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter4.Name = "agencyId";
			reportParameter4.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter5.Name = "creationUser";
			reportParameter6.Name = "creationTime";
			reportParameter6.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter7.Name = "issuedDocumentType";
			reportParameter8.Name = "accountType";
			reportParameter9.Name = "receiptId";
			reportParameter9.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter10.Name = "documentNo";
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.ReportParameters.Add(reportParameter9);
			this.ReportParameters.Add(reportParameter10);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(18D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.SubReport AgencyHeaderSubReport1;
		private Telerik.Reporting.TextBox ReportNameLabel;
		private Telerik.Reporting.SubReport AgencyFooterSubReport;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection2;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection2;
		private Telerik.Reporting.SubReport AgencyHeaderSubReport2;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.TextBox ReceiptDate;
		private Telerik.Reporting.TextBox TaxNo;
		private Telerik.Reporting.TextBox Consultant;
		private Telerik.Reporting.TextBox TotalAmountLabel;
		private Telerik.Reporting.TextBox ReceiptSubTotal;
		private Telerik.Reporting.TextBox ReceiptTax;
		private Telerik.Reporting.TextBox ReceiptTotalLabel;
		private Telerik.Reporting.TextBox ReceiptTotal;
		private Telerik.Reporting.TextBox TotalTaxLabel;
		private Telerik.Reporting.TextBox StandardComment;
		private Telerik.Reporting.Crosstab DetailTable;
		private Telerik.Reporting.TextBox TripLine;
		private Telerik.Reporting.TextBox Reference;
		private Telerik.Reporting.TextBox FormOfPayment;
		private Telerik.Reporting.TextBox Amount;
		private Telerik.Reporting.TextBox AccountNameHeader;
		private Telerik.Reporting.TextBox AccountHeader;
		private Telerik.Reporting.TextBox ReferenceHeader;
		private Telerik.Reporting.TextBox FormOfPaymentHeader;
		private Telerik.Reporting.TextBox AmountHeader;
		private Telerik.Reporting.HtmlTextBox Comments;
	}
}