using Telerik.Reporting;

namespace Travelog.Reports.Accounting {

	public partial class TransactionDetailSubReport2 : TelerikReport {
		public TransactionDetailSubReport2() {
			InitializeComponent();
		}
	}
}