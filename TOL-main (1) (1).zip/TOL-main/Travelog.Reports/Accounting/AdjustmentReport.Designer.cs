namespace Travelog.Reports.Accounting {
	partial class AdjustmentReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.Drawing.FormattingRule formattingRule1 = new Telerik.Reporting.Drawing.FormattingRule();
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
			Telerik.Reporting.Group group3 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter11 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter12 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter13 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter14 = new Telerik.Reporting.ReportParameter();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.TotalsLabel = new Telerik.Reporting.TextBox();
			this.AmountTotal = new Telerik.Reporting.TextBox();
			this.TaxTotal = new Telerik.Reporting.TextBox();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.ManagementReportHeaderSubReport1 = new Telerik.Reporting.SubReport();
			this.DocumentDateHeader = new Telerik.Reporting.TextBox();
			this.AmountHeader = new Telerik.Reporting.TextBox();
			this.TaxHeader = new Telerik.Reporting.TextBox();
			this.DebitTypeDescriptionHeader = new Telerik.Reporting.TextBox();
			this.DebitAccountNameHeader = new Telerik.Reporting.TextBox();
			this.CreditTypeDescriptionHeader = new Telerik.Reporting.TextBox();
			this.CreditAccountNameHeader = new Telerik.Reporting.TextBox();
			this.AdjustmentTypeHeader = new Telerik.Reporting.TextBox();
			this.DocumentNoHeader = new Telerik.Reporting.TextBox();
			this.NoData = new Telerik.Reporting.TextBox();
			this.GroupFooterSection2 = new Telerik.Reporting.GroupFooterSection();
			this.ConsultantTotalMessage = new Telerik.Reporting.TextBox();
			this.ConsultantTaxTotal = new Telerik.Reporting.TextBox();
			this.ConsultantTotal = new Telerik.Reporting.TextBox();
			this.GroupHeaderSection2 = new Telerik.Reporting.GroupHeaderSection();
			this.ConsultantGroup = new Telerik.Reporting.TextBox();
			this.GroupFooterSection3 = new Telerik.Reporting.GroupFooterSection();
			this.AmountSubTotalMessage = new Telerik.Reporting.TextBox();
			this.TaxSubTotal = new Telerik.Reporting.TextBox();
			this.AmountSubTotal = new Telerik.Reporting.TextBox();
			this.GroupHeaderSection3 = new Telerik.Reporting.GroupHeaderSection();
			this.AdjustmentTypeGroup = new Telerik.Reporting.TextBox();
			this.TotalTaxHeader = new Telerik.Reporting.TextBox();
			this.TotalAmountHeader = new Telerik.Reporting.TextBox();
			this.DocumentDate = new Telerik.Reporting.TextBox();
			this.DocumentNo = new Telerik.Reporting.TextBox();
			this.Amount = new Telerik.Reporting.TextBox();
			this.Tax = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.CreditTypeDescription = new Telerik.Reporting.TextBox();
			this.DebitTypeDescription = new Telerik.Reporting.TextBox();
			this.DebitAccountName = new Telerik.Reporting.TextBox();
			this.CreditAccountName = new Telerik.Reporting.TextBox();
			this.AdjustmentType = new Telerik.Reporting.TextBox();
			this.Comments = new Telerik.Reporting.TextBox();
			this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
			this.Pages = new Telerik.Reporting.TextBox();
			this.CreationTime = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Top", "= IIf(Parameters.reportGroupingId.Value = 0, \"Solid\", \"None\")"));
			this.GroupFooterSection1.CanShrink = true;
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TotalsLabel,
            this.AmountTotal,
            this.TaxTotal});
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			this.GroupFooterSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupFooterSection1.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupFooterSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// TotalsLabel
			// 
			this.TotalsLabel.CanShrink = true;
			this.TotalsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TotalsLabel.Name = "TotalsLabel";
			this.TotalsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(22.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalsLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalsLabel.Style.Font.Bold = true;
			this.TotalsLabel.Style.Font.Name = "Calibri";
			this.TotalsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalsLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TotalsLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalsLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalsLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TotalsLabel.StyleName = "Normal.TableBody";
			this.TotalsLabel.Value = "Totals";
			// 
			// AmountTotal
			// 
			this.AmountTotal.CanShrink = true;
			this.AmountTotal.Format = "{0:C2}";
			this.AmountTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountTotal.Name = "AmountTotal";
			this.AmountTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountTotal.Style.Font.Bold = true;
			this.AmountTotal.Style.Font.Name = "Calibri";
			this.AmountTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountTotal.StyleName = "Normal.TableBody";
			this.AmountTotal.Value = "= Sum(Fields.Amount)";
			// 
			// TaxTotal
			// 
			this.TaxTotal.CanShrink = true;
			this.TaxTotal.Format = "{0:C2}";
			this.TaxTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TaxTotal.Name = "TaxTotal";
			this.TaxTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxTotal.Style.Font.Bold = true;
			this.TaxTotal.Style.Font.Name = "Calibri";
			this.TaxTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TaxTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TaxTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TaxTotal.StyleName = "Normal.TableBody";
			this.TaxTotal.Value = "= Sum(Fields.Tax)";
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Count(1) = 0, \"None\", \"Solid\")"));
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(2.2D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ManagementReportHeaderSubReport1,
            this.DocumentDateHeader,
            this.AmountHeader,
            this.TaxHeader,
            this.DebitTypeDescriptionHeader,
            this.DebitAccountNameHeader,
            this.CreditTypeDescriptionHeader,
            this.CreditAccountNameHeader,
            this.AdjustmentTypeHeader,
            this.DocumentNoHeader,
            this.NoData});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = true;
			this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupHeaderSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// ManagementReportHeaderSubReport1
			// 
			this.ManagementReportHeaderSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ManagementReportHeaderSubReport1.Name = "ManagementReportHeaderSubReport1";
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerName", "= Parameters.customerName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportName", "= Parameters.reportName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportDate", "= Parameters.reportDate.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("headerContent", "= Parameters.headerContent.Value"));
			typeReportSource1.TypeName = "Travelog.Reports.Common.ManagementReportHeaderSubReport1, Travelog.Reports, Versi" +
    "on=1.0.0.0, Culture=neutral, PublicKeyToken=null";
			this.ManagementReportHeaderSubReport1.ReportSource = typeReportSource1;
			this.ManagementReportHeaderSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ManagementReportHeaderSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// DocumentDateHeader
			// 
			this.DocumentDateHeader.Bindings.Add(new Telerik.Reporting.Binding("Style.Color", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, \"White\", \"Black\")"));
			this.DocumentDateHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.9D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.DocumentDateHeader.Name = "DocumentDateHeader";
			this.DocumentDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDateHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDateHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDateHeader.Style.Font.Bold = true;
			this.DocumentDateHeader.Style.Font.Name = "Calibri";
			this.DocumentDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDateHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentDateHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDateHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDateHeader.StyleName = "Normal.TableHeader";
			this.DocumentDateHeader.Value = "Date";
			// 
			// AmountHeader
			// 
			this.AmountHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.AmountHeader.Name = "AmountHeader";
			this.AmountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AmountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AmountHeader.Style.Font.Bold = true;
			this.AmountHeader.Style.Font.Name = "Calibri";
			this.AmountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AmountHeader.StyleName = "Normal.TableHeader";
			this.AmountHeader.Value = "Amount";
			// 
			// TaxHeader
			// 
			this.TaxHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.2D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.TaxHeader.Name = "TaxHeader";
			this.TaxHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.TaxHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TaxHeader.Style.Font.Bold = true;
			this.TaxHeader.Style.Font.Name = "Calibri";
			this.TaxHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TaxHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxHeader.StyleName = "Normal.TableHeader";
			this.TaxHeader.Value = "Tax";
			this.TaxHeader.ItemDataBound += new System.EventHandler(this.TaxHeader_ItemDataBound);
			// 
			// DebitTypeDescriptionHeader
			// 
			this.DebitTypeDescriptionHeader.Bindings.Add(new Telerik.Reporting.Binding("Style.Color", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, \"White\", \"Black\")"));
			this.DebitTypeDescriptionHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.2D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.DebitTypeDescriptionHeader.Name = "DebitTypeDescriptionHeader";
			this.DebitTypeDescriptionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DebitTypeDescriptionHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DebitTypeDescriptionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DebitTypeDescriptionHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DebitTypeDescriptionHeader.Style.Font.Bold = true;
			this.DebitTypeDescriptionHeader.Style.Font.Name = "Calibri";
			this.DebitTypeDescriptionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DebitTypeDescriptionHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DebitTypeDescriptionHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DebitTypeDescriptionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DebitTypeDescriptionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DebitTypeDescriptionHeader.StyleName = "Normal.TableHeader";
			this.DebitTypeDescriptionHeader.Value = "Debit Type";
			// 
			// DebitAccountNameHeader
			// 
			this.DebitAccountNameHeader.Bindings.Add(new Telerik.Reporting.Binding("Style.Color", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, \"White\", \"Black\")"));
			this.DebitAccountNameHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.DebitAccountNameHeader.Name = "DebitAccountNameHeader";
			this.DebitAccountNameHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DebitAccountNameHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DebitAccountNameHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DebitAccountNameHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DebitAccountNameHeader.Style.Font.Bold = true;
			this.DebitAccountNameHeader.Style.Font.Name = "Calibri";
			this.DebitAccountNameHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DebitAccountNameHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DebitAccountNameHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DebitAccountNameHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DebitAccountNameHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DebitAccountNameHeader.StyleName = "Normal.TableHeader";
			this.DebitAccountNameHeader.Value = "Debit Account";
			// 
			// CreditTypeDescriptionHeader
			// 
			this.CreditTypeDescriptionHeader.Bindings.Add(new Telerik.Reporting.Binding("Style.Color", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, \"White\", \"Black\")"));
			this.CreditTypeDescriptionHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.2D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.CreditTypeDescriptionHeader.Name = "CreditTypeDescriptionHeader";
			this.CreditTypeDescriptionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditTypeDescriptionHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CreditTypeDescriptionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditTypeDescriptionHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CreditTypeDescriptionHeader.Style.Font.Bold = true;
			this.CreditTypeDescriptionHeader.Style.Font.Name = "Calibri";
			this.CreditTypeDescriptionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditTypeDescriptionHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditTypeDescriptionHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditTypeDescriptionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditTypeDescriptionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreditTypeDescriptionHeader.StyleName = "Normal.TableHeader";
			this.CreditTypeDescriptionHeader.Value = "Credit Type";
			// 
			// CreditAccountNameHeader
			// 
			this.CreditAccountNameHeader.Bindings.Add(new Telerik.Reporting.Binding("Style.Color", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, \"White\", \"Black\")"));
			this.CreditAccountNameHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.CreditAccountNameHeader.Name = "CreditAccountNameHeader";
			this.CreditAccountNameHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditAccountNameHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CreditAccountNameHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditAccountNameHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CreditAccountNameHeader.Style.Font.Bold = true;
			this.CreditAccountNameHeader.Style.Font.Name = "Calibri";
			this.CreditAccountNameHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditAccountNameHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditAccountNameHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditAccountNameHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditAccountNameHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreditAccountNameHeader.StyleName = "Normal.TableHeader";
			this.CreditAccountNameHeader.Value = "Credit Account";
			// 
			// AdjustmentTypeHeader
			// 
			this.AdjustmentTypeHeader.Bindings.Add(new Telerik.Reporting.Binding("Style.Color", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, \"White\", \"Black\")"));
			this.AdjustmentTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.2D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.AdjustmentTypeHeader.Name = "AdjustmentTypeHeader";
			this.AdjustmentTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AdjustmentTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AdjustmentTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AdjustmentTypeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AdjustmentTypeHeader.Style.Font.Bold = true;
			this.AdjustmentTypeHeader.Style.Font.Name = "Calibri";
			this.AdjustmentTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AdjustmentTypeHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AdjustmentTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AdjustmentTypeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AdjustmentTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AdjustmentTypeHeader.StyleName = "Normal.TableHeader";
			this.AdjustmentTypeHeader.Value = "= IIf(Parameters.reportGroupingId.Value = 0, \"Consultant\", \"Adjustment Type\")";
			// 
			// DocumentNoHeader
			// 
			this.DocumentNoHeader.Bindings.Add(new Telerik.Reporting.Binding("Width", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, \"4.2cm\", \"1.9cm\")"));
			this.DocumentNoHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.DocumentNoHeader.Name = "DocumentNoHeader";
			this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNoHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNoHeader.Style.Font.Bold = true;
			this.DocumentNoHeader.Style.Font.Name = "Calibri";
			this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNoHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentNoHeader.StyleName = "Normal.TableHeader";
			this.DocumentNoHeader.Value = "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, \"Adjustment Type\", \"Doc No\")";
			// 
			// NoData
			// 
			formattingRule1.Filters.Add(new Telerik.Reporting.Filter("= Count(1)", Telerik.Reporting.FilterOperator.Equal, "0"));
			formattingRule1.Style.Visible = true;
			this.NoData.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule1});
			this.NoData.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.6D));
			this.NoData.Name = "NoData";
			this.NoData.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NoData.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.NoData.Style.BorderColor.Default = System.Drawing.Color.WhiteSmoke;
			this.NoData.Style.Font.Name = "Calibri";
			this.NoData.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NoData.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
			this.NoData.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.NoData.Style.Visible = false;
			this.NoData.StyleName = "Normal.TableHeader";
			this.NoData.Value = "NO DATA AVAILABLE";
			// 
			// GroupFooterSection2
			// 
			this.GroupFooterSection2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 1 Or Parameters.reportGroupingId.Va" +
            "lue = 0, False, True)"));
			this.GroupFooterSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupFooterSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ConsultantTotalMessage,
            this.ConsultantTaxTotal,
            this.ConsultantTotal});
			this.GroupFooterSection2.Name = "GroupFooterSection2";
			this.GroupFooterSection2.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupFooterSection2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupFooterSection2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupFooterSection2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// ConsultantTotalMessage
			// 
			this.ConsultantTotalMessage.CanShrink = true;
			this.ConsultantTotalMessage.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ConsultantTotalMessage.Name = "ConsultantTotalMessage";
			this.ConsultantTotalMessage.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(22.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ConsultantTotalMessage.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ConsultantTotalMessage.Style.Font.Name = "Calibri";
			this.ConsultantTotalMessage.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ConsultantTotalMessage.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ConsultantTotalMessage.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ConsultantTotalMessage.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ConsultantTotalMessage.StyleName = "Normal.TableBody";
			this.ConsultantTotalMessage.Value = "= Fields.Consultant + \" Totals\"";
			// 
			// ConsultantTaxTotal
			// 
			this.ConsultantTaxTotal.CanShrink = true;
			this.ConsultantTaxTotal.Format = "{0:C2}";
			this.ConsultantTaxTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ConsultantTaxTotal.Name = "ConsultantTaxTotal";
			this.ConsultantTaxTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ConsultantTaxTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ConsultantTaxTotal.Style.Font.Italic = false;
			this.ConsultantTaxTotal.Style.Font.Name = "Calibri";
			this.ConsultantTaxTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ConsultantTaxTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ConsultantTaxTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ConsultantTaxTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ConsultantTaxTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ConsultantTaxTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ConsultantTaxTotal.StyleName = "Normal.TableBody";
			this.ConsultantTaxTotal.Value = "= Sum(Fields.Tax)";
			// 
			// ConsultantTotal
			// 
			this.ConsultantTotal.CanShrink = true;
			this.ConsultantTotal.Format = "{0:C2}";
			this.ConsultantTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ConsultantTotal.Name = "ConsultantTotal";
			this.ConsultantTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ConsultantTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ConsultantTotal.Style.Font.Italic = false;
			this.ConsultantTotal.Style.Font.Name = "Calibri";
			this.ConsultantTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ConsultantTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ConsultantTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ConsultantTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ConsultantTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ConsultantTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ConsultantTotal.StyleName = "Normal.TableBody";
			this.ConsultantTotal.Value = "= Sum(Fields.Amount)";
			// 
			// GroupHeaderSection2
			// 
			this.GroupHeaderSection2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 1 Or Parameters.reportGroupingId.Va" +
            "lue = 0, False, True)"));
			this.GroupHeaderSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupHeaderSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ConsultantGroup});
			this.GroupHeaderSection2.Name = "GroupHeaderSection2";
			this.GroupHeaderSection2.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupHeaderSection2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection2.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupHeaderSection2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// ConsultantGroup
			// 
			this.ConsultantGroup.CanShrink = true;
			this.ConsultantGroup.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ConsultantGroup.Name = "ConsultantGroup";
			this.ConsultantGroup.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ConsultantGroup.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ConsultantGroup.Style.Font.Name = "Calibri";
			this.ConsultantGroup.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ConsultantGroup.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ConsultantGroup.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ConsultantGroup.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ConsultantGroup.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ConsultantGroup.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ConsultantGroup.StyleName = "Normal.TableBody";
			this.ConsultantGroup.Value = "= Fields.Consultant";
			// 
			// GroupFooterSection3
			// 
			this.GroupFooterSection3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, False, True)"));
			this.GroupFooterSection3.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupFooterSection3.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AmountSubTotalMessage,
            this.TaxSubTotal,
            this.AmountSubTotal});
			this.GroupFooterSection3.Name = "GroupFooterSection3";
			this.GroupFooterSection3.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupFooterSection3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupFooterSection3.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupFooterSection3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// AmountSubTotalMessage
			// 
			this.AmountSubTotalMessage.CanShrink = true;
			this.AmountSubTotalMessage.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountSubTotalMessage.Name = "AmountSubTotalMessage";
			this.AmountSubTotalMessage.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(22.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountSubTotalMessage.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountSubTotalMessage.Style.Font.Name = "Calibri";
			this.AmountSubTotalMessage.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountSubTotalMessage.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountSubTotalMessage.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountSubTotalMessage.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountSubTotalMessage.StyleName = "Normal.TableBody";
			this.AmountSubTotalMessage.Value = "= IIf(Parameters.ledgerDocumentTypeId.Value = 0 Or Parameters.reportGroupingId.Va" +
    "lue = 0, Fields.AdjustmentType, Fields.Consultant) + \" Totals\"";
			// 
			// TaxSubTotal
			// 
			this.TaxSubTotal.CanShrink = true;
			this.TaxSubTotal.Format = "{0:C2}";
			this.TaxSubTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TaxSubTotal.Name = "TaxSubTotal";
			this.TaxSubTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TaxSubTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TaxSubTotal.Style.Font.Italic = false;
			this.TaxSubTotal.Style.Font.Name = "Calibri";
			this.TaxSubTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxSubTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TaxSubTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TaxSubTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TaxSubTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxSubTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TaxSubTotal.StyleName = "Normal.TableBody";
			this.TaxSubTotal.Value = "= Sum(Fields.Tax)";
			// 
			// AmountSubTotal
			// 
			this.AmountSubTotal.CanShrink = true;
			this.AmountSubTotal.Format = "{0:C2}";
			this.AmountSubTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AmountSubTotal.Name = "AmountSubTotal";
			this.AmountSubTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountSubTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountSubTotal.Style.Font.Name = "Calibri";
			this.AmountSubTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountSubTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountSubTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AmountSubTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountSubTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountSubTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AmountSubTotal.StyleName = "Normal.TableBody";
			this.AmountSubTotal.Value = "= Sum(Fields.Amount)";
			// 
			// GroupHeaderSection3
			// 
			this.GroupHeaderSection3.Bindings.Add(new Telerik.Reporting.Binding("Style.BackgroundColor", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, \"White\", \"WhiteSmoke\")"));
			this.GroupHeaderSection3.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupHeaderSection3.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AdjustmentTypeGroup,
            this.TotalTaxHeader,
            this.TotalAmountHeader});
			this.GroupHeaderSection3.Name = "GroupHeaderSection3";
			this.GroupHeaderSection3.PrintOnEveryPage = true;
			this.GroupHeaderSection3.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.GroupHeaderSection3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection3.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupHeaderSection3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// AdjustmentTypeGroup
			// 
			this.AdjustmentTypeGroup.CanShrink = true;
			this.AdjustmentTypeGroup.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AdjustmentTypeGroup.Name = "AdjustmentTypeGroup";
			this.AdjustmentTypeGroup.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(22.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AdjustmentTypeGroup.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AdjustmentTypeGroup.Style.Font.Name = "Calibri";
			this.AdjustmentTypeGroup.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AdjustmentTypeGroup.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AdjustmentTypeGroup.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AdjustmentTypeGroup.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AdjustmentTypeGroup.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AdjustmentTypeGroup.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AdjustmentTypeGroup.StyleName = "Normal.TableBody";
			this.AdjustmentTypeGroup.Value = "= IIf(Parameters.ledgerDocumentTypeId.Value = 0 Or Parameters.reportGroupingId.Va" +
    "lue = 0, Fields.AdjustmentType, Fields.Consultant)";
			// 
			// TotalTaxHeader
			// 
			this.TotalTaxHeader.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, True, False)"));
			this.TotalTaxHeader.CanShrink = true;
			this.TotalTaxHeader.Format = "{0:C2}";
			this.TotalTaxHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TotalTaxHeader.Name = "TotalTaxHeader";
			this.TotalTaxHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalTaxHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalTaxHeader.Style.Font.Name = "Calibri";
			this.TotalTaxHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalTaxHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TotalTaxHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TotalTaxHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalTaxHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalTaxHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TotalTaxHeader.Style.Visible = false;
			this.TotalTaxHeader.StyleName = "Normal.TableBody";
			this.TotalTaxHeader.Value = "= Sum(Fields.Tax)";
			// 
			// TotalAmountHeader
			// 
			this.TotalAmountHeader.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, True, False)"));
			this.TotalAmountHeader.CanShrink = true;
			this.TotalAmountHeader.Format = "{0:C2}";
			this.TotalAmountHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TotalAmountHeader.Name = "TotalAmountHeader";
			this.TotalAmountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalAmountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalAmountHeader.Style.Font.Name = "Calibri";
			this.TotalAmountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalAmountHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TotalAmountHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TotalAmountHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalAmountHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalAmountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TotalAmountHeader.Style.Visible = false;
			this.TotalAmountHeader.StyleName = "Normal.TableBody";
			this.TotalAmountHeader.Value = "= Sum(Fields.Amount)";
			// 
			// DocumentDate
			// 
			this.DocumentDate.Format = "{0:dd-MMM-yyyy}";
			this.DocumentDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentDate.Name = "DocumentDate";
			this.DocumentDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDate.Style.Font.Name = "Calibri";
			this.DocumentDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentDate.StyleName = "Normal.TableBody";
			this.DocumentDate.Value = "= Fields.DocumentDate";
			// 
			// DocumentNo
			// 
			this.DocumentNo.CanShrink = true;
			this.DocumentNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DocumentNo.Name = "DocumentNo";
			this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNo.Style.Font.Name = "Calibri";
			this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentNo.StyleName = "Normal.TableBody";
			this.DocumentNo.Value = "= Fields.DocumentNo";
			// 
			// Amount
			// 
			this.Amount.Format = "{0:C2}";
			this.Amount.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Amount.Name = "Amount";
			this.Amount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Amount.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Amount.Style.Font.Name = "Calibri";
			this.Amount.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Amount.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Amount.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Amount.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Amount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Amount.StyleName = "Normal.TableBody";
			this.Amount.Value = "= Fields.Amount";
			// 
			// Tax
			// 
			this.Tax.Format = "{0:C2}";
			this.Tax.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Tax.Name = "Tax";
			this.Tax.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Tax.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Tax.Style.Font.Name = "Calibri";
			this.Tax.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Tax.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Tax.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Tax.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Tax.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Tax.StyleName = "Normal.TableBody";
			this.Tax.Value = "= Fields.Tax";
			// 
			// Detail
			// 
			this.Detail.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value = 0, False, True)"));
			this.Detail.CanShrink = true;
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(1.2D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.CreditTypeDescription,
            this.DocumentDate,
            this.DebitTypeDescription,
            this.DebitAccountName,
            this.DocumentNo,
            this.CreditAccountName,
            this.Amount,
            this.Tax,
            this.AdjustmentType,
            this.Comments});
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// CreditTypeDescription
			// 
			this.CreditTypeDescription.CanShrink = true;
			this.CreditTypeDescription.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CreditTypeDescription.Name = "CreditTypeDescription";
			this.CreditTypeDescription.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditTypeDescription.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditTypeDescription.Style.Font.Name = "Calibri";
			this.CreditTypeDescription.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditTypeDescription.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditTypeDescription.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditTypeDescription.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditTypeDescription.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditTypeDescription.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CreditTypeDescription.StyleName = "Normal.TableBody";
			this.CreditTypeDescription.Value = "= Fields.CreditTypeDescription";
			// 
			// DebitTypeDescription
			// 
			this.DebitTypeDescription.CanShrink = true;
			this.DebitTypeDescription.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DebitTypeDescription.Name = "DebitTypeDescription";
			this.DebitTypeDescription.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DebitTypeDescription.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DebitTypeDescription.Style.Font.Name = "Calibri";
			this.DebitTypeDescription.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DebitTypeDescription.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DebitTypeDescription.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DebitTypeDescription.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DebitTypeDescription.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DebitTypeDescription.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DebitTypeDescription.StyleName = "Normal.TableBody";
			this.DebitTypeDescription.Value = "= Fields.DebitTypeDescription";
			// 
			// DebitAccountName
			// 
			this.DebitAccountName.CanShrink = true;
			this.DebitAccountName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DebitAccountName.Name = "DebitAccountName";
			this.DebitAccountName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DebitAccountName.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DebitAccountName.Style.Font.Name = "Calibri";
			this.DebitAccountName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DebitAccountName.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DebitAccountName.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DebitAccountName.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DebitAccountName.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DebitAccountName.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DebitAccountName.StyleName = "Normal.TableBody";
			this.DebitAccountName.Value = "= Fields.DebitAccountName";
			// 
			// CreditAccountName
			// 
			this.CreditAccountName.CanShrink = true;
			this.CreditAccountName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CreditAccountName.Name = "CreditAccountName";
			this.CreditAccountName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditAccountName.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditAccountName.Style.Font.Name = "Calibri";
			this.CreditAccountName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditAccountName.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditAccountName.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditAccountName.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditAccountName.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditAccountName.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CreditAccountName.StyleName = "Normal.TableBody";
			this.CreditAccountName.Value = "= Fields.CreditAccountName";
			// 
			// AdjustmentType
			// 
			this.AdjustmentType.CanShrink = true;
			this.AdjustmentType.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AdjustmentType.Name = "AdjustmentType";
			this.AdjustmentType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AdjustmentType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AdjustmentType.Style.Font.Name = "Calibri";
			this.AdjustmentType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AdjustmentType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AdjustmentType.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AdjustmentType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AdjustmentType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AdjustmentType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AdjustmentType.StyleName = "Normal.TableBody";
			this.AdjustmentType.Value = "= IIf(Parameters.reportGroupingId.Value = 0, Fields.Consultant, Fields.Adjustment" +
    "Type)";
			// 
			// Comments
			// 
			this.Comments.CanShrink = true;
			this.Comments.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Comments.Name = "Comments";
			this.Comments.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Comments.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Comments.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Comments.Style.Font.Italic = true;
			this.Comments.Style.Font.Name = "Calibri";
			this.Comments.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Comments.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Comments.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Comments.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Comments.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Comments.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Comments.Style.Visible = false;
			this.Comments.StyleName = "Normal.TableBody";
			this.Comments.Value = "= Fields.Comments";
			// 
			// PageFooterSection
			// 
			this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
			this.PageFooterSection.Name = "PageFooter";
			// 
			// Pages
			// 
			this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.7D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Name = "Pages";
			this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Style.Color = System.Drawing.Color.DarkGray;
			this.Pages.Style.Font.Name = "Calibri";
			this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Pages.Value = "= \"Page \" + PageNumber";
			// 
			// CreationTime
			// 
			this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Name = "CreationTime";
			this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
			this.CreationTime.Style.Font.Name = "Calibri";
			this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy HH:mm}\", Parame" +
    "ters.creationTime.Value)";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "AdjustmentReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.Accounting.AccountingDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("ledgerDocumentTypeId", typeof(int), "= Parameters.ledgerDocumentTypeId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateFrom", typeof(System.Nullable<System.DateTime>), "= Parameters.dateFrom.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateTo", typeof(System.Nullable<System.DateTime>), "= Parameters.dateTo.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("adjustmentTypeIds", typeof(string), "= Parameters.adjustmentTypeIds.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("consultantIds", typeof(string), "= Parameters.consultantIds.Value"));
			// 
			// AdjustmentReport
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			group2.GroupFooter = this.GroupFooterSection2;
			group2.GroupHeader = this.GroupHeaderSection2;
			group2.Groupings.Add(new Telerik.Reporting.Grouping("= IIf(Parameters.ledgerDocumentTypeId.Value = 0 And Parameters.reportGroupingId.V" +
            "alue = 1, Fields.Consultant, 1)"));
			group2.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group2.Name = "Group2";
			group3.GroupFooter = this.GroupFooterSection3;
			group3.GroupHeader = this.GroupHeaderSection3;
			group3.Groupings.Add(new Telerik.Reporting.Grouping("= IIf(Parameters.ledgerDocumentTypeId.Value = 0 Or Parameters.reportGroupingId.Va" +
            "lue = 0, Fields.AdjustmentType, Fields.Consultant)"));
			group3.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group3.Name = "Group3";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2,
            group3});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.GroupHeaderSection2,
            this.GroupFooterSection2,
            this.GroupHeaderSection3,
            this.GroupFooterSection3,
            this.Detail,
            this.PageFooterSection});
			this.Name = "AdjustmentReport";
			this.PageSettings.Landscape = true;
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "customerId";
			reportParameter2.Name = "agencyId";
			reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter3.Name = "customerName";
			reportParameter4.Name = "reportName";
			reportParameter5.Name = "reportDate";
			reportParameter6.Name = "headerContent";
			reportParameter7.Name = "creationUser";
			reportParameter8.Name = "creationTime";
			reportParameter8.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter9.Name = "ledgerDocumentTypeId";
			reportParameter9.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter10.Name = "reportGroupingId";
			reportParameter10.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter11.AllowNull = true;
			reportParameter11.Name = "dateFrom";
			reportParameter11.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter12.AllowNull = true;
			reportParameter12.Name = "dateTo";
			reportParameter12.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter13.Name = "adjustmentTypeIds";
			reportParameter14.Name = "consultantIds";
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.ReportParameters.Add(reportParameter9);
			this.ReportParameters.Add(reportParameter10);
			this.ReportParameters.Add(reportParameter11);
			this.ReportParameters.Add(reportParameter12);
			this.ReportParameters.Add(reportParameter13);
			this.ReportParameters.Add(reportParameter14);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(27.7D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.SubReport ManagementReportHeaderSubReport1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.TextBox TotalsLabel;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox DocumentDateHeader;
		private Telerik.Reporting.TextBox AmountHeader;
		private Telerik.Reporting.TextBox TaxHeader;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox DocumentDate;
		private Telerik.Reporting.TextBox Amount;
		private Telerik.Reporting.TextBox Tax;
		private Telerik.Reporting.TextBox AmountTotal;
		private Telerik.Reporting.TextBox TaxTotal;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection3;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection3;
		private Telerik.Reporting.TextBox DebitTypeDescriptionHeader;
		private Telerik.Reporting.TextBox DebitTypeDescription;
		private Telerik.Reporting.TextBox DebitAccountNameHeader;
		private Telerik.Reporting.TextBox DebitAccountName;
		private Telerik.Reporting.TextBox CreditTypeDescriptionHeader;
		private Telerik.Reporting.TextBox CreditAccountNameHeader;
		private Telerik.Reporting.TextBox CreditTypeDescription;
		private Telerik.Reporting.TextBox CreditAccountName;
		private Telerik.Reporting.TextBox AdjustmentTypeGroup;
		private Telerik.Reporting.TextBox AmountSubTotalMessage;
		private Telerik.Reporting.TextBox TaxSubTotal;
		private Telerik.Reporting.TextBox AmountSubTotal;
		private Telerik.Reporting.TextBox AdjustmentTypeHeader;
		private Telerik.Reporting.TextBox AdjustmentType;
		private Telerik.Reporting.TextBox Comments;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection2;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection2;
		private Telerik.Reporting.TextBox ConsultantGroup;
		private Telerik.Reporting.TextBox ConsultantTotalMessage;
		private Telerik.Reporting.TextBox ConsultantTaxTotal;
		private Telerik.Reporting.TextBox ConsultantTotal;
		private Telerik.Reporting.TextBox TotalTaxHeader;
		private Telerik.Reporting.TextBox TotalAmountHeader;
		private Telerik.Reporting.TextBox NoData;
	}
}