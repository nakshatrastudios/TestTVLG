using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Telerik.Reporting;
using Telerik.Reporting.Drawing;
using Travelog.Biz;
using Travelog.Biz.Models;

namespace Travelog.Reports.Accounting {
	public partial class SalesAnalysisReport : TelerikReport {
		private Dictionary<string, double> ReportTotals { get; set; }
		private Dictionary<string, string> ReportColumns { get; set; }
		private string[] ReportGroups { get; set; }
		private double StartPosition { get; set; }

		public SalesAnalysisReport() {
		}

		public SalesAnalysisReport(List<SalesAnalysisReportModel> dataSource, string reportName, string[] columns, string[] groups, bool isSummary, decimal ytdCash, decimal ytdCashNonCommissionable, decimal ytdCreditCard, decimal ytdCreditCardNonCommissionable, decimal ytdGrossAmount, decimal ytdNonCommissionable, decimal ytdCommission, decimal ytdNetAmount, decimal ytdYield) {
			InitializeComponent();
			InitTotals();

			if (isSummary && groups.Length > 0) {
				columns = groups;
				Detail.Visible = false;
				PaxNoHeader.Value = string.Empty;
			}

			DataSource = dataSource;
			Report.Name = reportName;
			ReportGroups = groups;

			InitColumns(columns, isSummary);

			if (isSummary) {
				LabelTotal.Value = string.Empty;
				LabelYtd.Visible = false;
				CashYtd.Visible = false;
				CashNonCommissionableYtd.Visible = false;
				CreditCardYtd.Visible = false;
				CreditCardNonCommissionableYtd.Visible = false;
				AmountGrossYtd.Visible = false;
				NonCommissionableYtd.Visible = false;
				CommissionYtd.Visible = false;
				AmountNetYtd.Visible = false;
				YieldYtd.Visible = false;
			}
			else {
				CashYtd.Value = string.Format("{0:c2}", ytdCash);
				CashNonCommissionableYtd.Value = string.Format("{0:c2}", ytdCashNonCommissionable);
				CreditCardYtd.Value = string.Format("{0:c2}", ytdCreditCard);
				CreditCardNonCommissionableYtd.Value = string.Format("{0:c2}", ytdCreditCardNonCommissionable);
				AmountGrossYtd.Value = string.Format("{0:c2}", ytdGrossAmount);
				NonCommissionableYtd.Value = string.Format("{0:c2}", ytdNonCommissionable);
				CommissionYtd.Value = string.Format("{0:c2}", ytdCommission);
				AmountNetYtd.Value = string.Format("{0:c2}", ytdNetAmount);
				YieldYtd.Value = string.Format("{0:p3}", ytdYield);
			}

			if (ReportGroups?.Length > 0)
				InitGroups(isSummary);
		}

		private void InitTotals() {
			ReportTotals = new Dictionary<string, double>();

			double left = 0;
			ReportTotals.Add(PaxNo.Name, PaxNo.Width.Value);

			left += LabelTotal.Width.Value;
			ReportTotals.Add(Cash.Name, left);

			left += Cash.Width.Value;
			ReportTotals.Add(CashNonCommissionable.Name, left);

			left += CashNonCommissionable.Width.Value;
			ReportTotals.Add(CreditCard.Name, left);

			left += CreditCard.Width.Value;
			ReportTotals.Add(CreditCardNonCommissionable.Name, left);

			left += CreditCardNonCommissionable.Width.Value;
			ReportTotals.Add(AmountGross.Name, left);

			left += AmountGross.Width.Value;
			ReportTotals.Add(NonCommissionable.Name, left);

			left += NonCommissionable.Width.Value;
			ReportTotals.Add(Commission.Name, left);

			left += Commission.Width.Value;
			ReportTotals.Add(AmountNet.Name, left);

			left += AmountNet.Width.Value;
			ReportTotals.Add(Yield.Name, left);
		}

		private void InitColumns(string[] columns, bool isSummary) {
			ReportColumns = new Dictionary<string, string>();
			double position = 0;

			foreach (string columnName in columns) {
				ReportColumns.Add(columnName, columnName);

				switch (columnName) {
					case "TransactionType":
						if (isSummary) {
							TransactionTypeHeader.Value = string.Empty;
							TransactionTypeHeader.Width = Unit.Cm(6);
							TransactionType.Width = Unit.Cm(6);
						}

						TransactionTypeHeader.Left = Unit.Cm(position);
						TransactionType.Left = Unit.Cm(position);
						position += TransactionType.Width.Value;

						ReportColumns[columnName] = "Transaction Type";
						break;
					case "DocumentType":
						if (isSummary) {
							DocumentTypeHeader.Value = string.Empty;
							DocumentTypeHeader.Width = Unit.Cm(6);
							DocumentType.Width = Unit.Cm(6);
						}

						DocumentTypeHeader.Left = Unit.Cm(position);
						DocumentType.Left = Unit.Cm(position);
						position += DocumentType.Width.Value;

						ReportColumns[columnName] = "Document Type";
						break;
					case "DocumentNo":
						if (isSummary) {
							DocumentNoHeader.Value = string.Empty;
							DocumentNoHeader.Width = Unit.Cm(6);
							DocumentNo.Width = Unit.Cm(6);
						}

						DocumentNoHeader.Left = Unit.Cm(position);
						DocumentNo.Left = Unit.Cm(position);
						position += DocumentNo.Width.Value;

						ReportColumns[columnName] = "Document No";
						break;
					case "DocumentDate":
						if (isSummary) {
							DocumentDateHeader.Value = string.Empty;
							DocumentDateHeader.Width = Unit.Cm(6);
							DocumentDate.Width = Unit.Cm(6);
						}

						DocumentDateHeader.Left = Unit.Cm(position);
						DocumentDate.Left = Unit.Cm(position);
						position += DocumentDate.Width.Value;

						ReportColumns[columnName] = "Document Date";
						break;
					case "Account":
						if (isSummary) {
							AccountHeader.Value = string.Empty;
							AccountHeader.Width = Unit.Cm(6);
							Account.Width = Unit.Cm(6);
						}

						AccountHeader.Left = Unit.Cm(position);
						Account.Left = Unit.Cm(position);
						position += Account.Width.Value;
						break;
					case "Airline":
						if (isSummary) {
							AirlineHeader.Value = string.Empty;
							AirlineHeader.Width = Unit.Cm(6);
							Airline.Width = Unit.Cm(6);
						}

						AirlineHeader.Left = Unit.Cm(position);
						Airline.Left = Unit.Cm(position);
						position += Airline.Width.Value;
						break;
					case "Passenger":
						if (isSummary) {
							PassengerHeader.Value = string.Empty;
							PassengerHeader.Width = Unit.Cm(6);
							Passenger.Width = Unit.Cm(6);
						}

						PassengerHeader.Left = Unit.Cm(position);
						Passenger.Left = Unit.Cm(position);
						position += Passenger.Width.Value;
						break;
					case "OfferedFare":
						if (isSummary) {
							OfferedFareHeader.Value = string.Empty;
							OfferedFareHeader.Width = Unit.Cm(6);
							OfferedFare.Width = Unit.Cm(6);
						}

						OfferedFareHeader.Left = Unit.Cm(position);
						OfferedFare.Left = Unit.Cm(position);
						position += OfferedFare.Width.Value;

						ReportColumns[columnName] = "Offered Fare";
						break;
					case "OfferedReason":
						if (isSummary) {
							OfferedReasonHeader.Value = string.Empty;
							OfferedReasonHeader.Width = Unit.Cm(6);
							OfferedReason.Width = Unit.Cm(6);
						}

						OfferedReasonHeader.Left = Unit.Cm(position);
						OfferedReason.Left = Unit.Cm(position);
						position += OfferedReason.Width.Value;

						ReportColumns[columnName] = "Reason Rejected";
						break;
					case "DepartureDate":
						if (isSummary) {
							DepartureDateHeader.Value = string.Empty;
							DepartureDateHeader.Width = Unit.Cm(6);
							DepartureDate.Width = Unit.Cm(6);
						}

						DepartureDateHeader.Left = Unit.Cm(position);
						DepartureDate.Left = Unit.Cm(position);
						position += DepartureDate.Width.Value;

						ReportColumns[columnName] = "Departure Date";
						break;
					case "ReturnDate":
						if (isSummary) {
							ReturnDateHeader.Value = string.Empty;
							ReturnDateHeader.Width = Unit.Cm(6);
							ReturnDate.Width = Unit.Cm(6);
						}

						ReturnDateHeader.Left = Unit.Cm(position);
						ReturnDate.Left = Unit.Cm(position);
						position += ReturnDate.Width.Value;

						ReportColumns[columnName] = "Return Date";
						break;
					case "Reference":
						if (isSummary) {
							ReferenceHeader.Value = string.Empty;
							ReferenceHeader.Width = Unit.Cm(6);
							Reference.Width = Unit.Cm(6);
						}

						ReferenceHeader.Left = Unit.Cm(position);
						Reference.Left = Unit.Cm(position);
						position += Reference.Width.Value;
						break;
					case "Debtor":
						if (isSummary) {
							DebtorHeader.Value = string.Empty;
							DebtorHeader.Width = Unit.Cm(6);
							Debtor.Width = Unit.Cm(6);
						}

						DebtorHeader.Left = Unit.Cm(position);
						Debtor.Left = Unit.Cm(position);
						position += Debtor.Width.Value;
						break;
					case "Creditor":
						if (isSummary) {
							CreditorHeader.Value = string.Empty;
							CreditorHeader.Width = Unit.Cm(6);
							Creditor.Width = Unit.Cm(6);
						}

						CreditorHeader.Left = Unit.Cm(position);
						Creditor.Left = Unit.Cm(position);
						position += Creditor.Width.Value;
						break;
					case "Supplier":
						if (isSummary) {
							SupplierHeader.Value = string.Empty;
							SupplierHeader.Width = Unit.Cm(6);
							Supplier.Width = Unit.Cm(6);
						}

						SupplierHeader.Left = Unit.Cm(position);
						Supplier.Left = Unit.Cm(position);
						position += Supplier.Width.Value;
						break;
					case "SaleType":
						if (isSummary) {
							SaleTypeHeader.Value = string.Empty;
							SaleTypeHeader.Width = Unit.Cm(6);
							SaleType.Width = Unit.Cm(6);
						}

						SaleTypeHeader.Left = Unit.Cm(position);
						SaleType.Left = Unit.Cm(position);
						position += SaleType.Width.Value;

						ReportColumns[columnName] = "Type Of Sale";
						break;
					case "DiscountReason":
						if (isSummary) {
							DiscountReasonHeader.Value = string.Empty;
							DiscountReasonHeader.Width = Unit.Cm(6);
							DiscountReason.Width = Unit.Cm(6);
						}

						DiscountReasonHeader.Left = Unit.Cm(position);
						DiscountReason.Left = Unit.Cm(position);
						position += DiscountReason.Width.Value;

						ReportColumns[columnName] = "Discount Reason";
						break;
					case "Group":
						if (isSummary) {
							GroupHeader.Value = string.Empty;
							GroupHeader.Width = Unit.Cm(6);
							Group.Width = Unit.Cm(6);
						}

						GroupHeader.Left = Unit.Cm(position);
						Group.Left = Unit.Cm(position);
						position += Group.Width.Value;
						break;
					case "Class":
						if (isSummary) {
							ClassHeader.Value = string.Empty;
							ClassHeader.Width = Unit.Cm(6);
							Class.Width = Unit.Cm(6);
						}

						ClassHeader.Left = Unit.Cm(position);
						Class.Left = Unit.Cm(position);
						position += Class.Width.Value;
						break;
					case "Source":
						if (isSummary) {
							SourceHeader.Value = string.Empty;
							SourceHeader.Width = Unit.Cm(6);
							Source.Width = Unit.Cm(6);
						}

						SourceHeader.Left = Unit.Cm(position);
						Source.Left = Unit.Cm(position);
						position += Source.Width.Value;
						break;
					case "Category":
						if (isSummary) {
							CategoryHeader.Value = string.Empty;
							CategoryHeader.Width = Unit.Cm(6);
							Category.Width = Unit.Cm(6);
						}

						CategoryHeader.Left = Unit.Cm(position);
						Category.Left = Unit.Cm(position);
						position += Category.Width.Value;
						break;
					case "Destination":
						if (isSummary) {
							DestinationHeader.Value = string.Empty;
							DestinationHeader.Width = Unit.Cm(6);
							Destination.Width = Unit.Cm(6);
						}

						DestinationHeader.Left = Unit.Cm(position);
						Destination.Left = Unit.Cm(position);
						position += Destination.Width.Value;
						break;
					case "Region":
						if (isSummary) {
							RegionHeader.Value = string.Empty;
							RegionHeader.Width = Unit.Cm(6);
							Region.Width = Unit.Cm(6);
						}

						RegionHeader.Left = Unit.Cm(position);
						Region.Left = Unit.Cm(position);
						position += Region.Width.Value;
						break;
					case "Location":
						if (isSummary) {
							LocationHeader.Value = string.Empty;
							LocationHeader.Width = Unit.Cm(6);
							Location.Width = Unit.Cm(6);
						}

						LocationHeader.Left = Unit.Cm(position);
						Location.Left = Unit.Cm(position);
						position += Location.Width.Value;
						break;
					case "Agency":
						if (isSummary) {
							AgencyHeader.Value = string.Empty;
							AgencyHeader.Width = Unit.Cm(6);
							Agency.Width = Unit.Cm(6);
						}

						AgencyHeader.Left = Unit.Cm(position);
						Agency.Left = Unit.Cm(position);
						position += Agency.Width.Value;
						break;
					case "Consultant":
						if (isSummary) {
							ConsultantHeader.Value = string.Empty;
							ConsultantHeader.Width = Unit.Cm(6);
							Consultant.Width = Unit.Cm(6);
						}

						ConsultantHeader.Left = Unit.Cm(position);
						Consultant.Left = Unit.Cm(position);
						position += Consultant.Width.Value;
						break;
					case "Agent":
						if (isSummary) {
							AgentHeader.Value = string.Empty;
							AgentHeader.Width = Unit.Cm(6);
							Agent.Width = Unit.Cm(6);
						}

						AgentHeader.Left = Unit.Cm(position);
						Agent.Left = Unit.Cm(position);
						position += Agent.Width.Value;
						break;
				}
			}

			position = Math.Round(position, 1);
			StartPosition = position;

			PaxNoHeader.Left = Unit.Cm(position);
			PaxNo.Left = PaxNoHeader.Left;
			CashHeader.Left = Unit.Cm(position + 1.5);
			Cash.Left = CashHeader.Left;
			CashNonCommissionableHeader.Left = Unit.Cm(position + 4.2);
			CashNonCommissionable.Left = CashNonCommissionableHeader.Left;
			CreditCardHeader.Left = Unit.Cm(position + 6.9);
			CreditCard.Left = CreditCardHeader.Left;
			CreditCardNonCommissionableHeader.Left = Unit.Cm(position + 9.6);
			CreditCardNonCommissionable.Left = CreditCardNonCommissionableHeader.Left;
			AmountGrossHeader.Left = Unit.Cm(position + 12.3);
			AmountGross.Left = AmountGrossHeader.Left;
			NonCommissionableHeader.Left = Unit.Cm(position + 15);
			NonCommissionable.Left = NonCommissionableHeader.Left;
			CommissionHeader.Left = Unit.Cm(position + 17.7);
			Commission.Left = CommissionHeader.Left;
			AmountNetHeader.Left = Unit.Cm(position + 20.4);
			AmountNet.Left = AmountNetHeader.Left;
			YieldHeader.Left = Unit.Cm(position + 23.1);
			Yield.Left = YieldHeader.Left;

			Report.Width = Unit.Cm(Yield.Left.Value + Yield.Width.Value);
		}

		private void InitGroups(bool isSummary) {
			foreach (string groupName in ReportGroups) {
				HtmlTextBox htmlTextBox = null;

				int i = ReportGroups.IndexOf(groupName);
				bool hideHeader = isSummary && i == ReportGroups.Length - 1;

				string title = ReportColumns[groupName];

				string headerTitle = title;
				string footerTitle = string.Format("Totals for {0}", title);

				if (isSummary) {
					headerTitle = headerTitle.PadLeft(title.Length + i * 5).Replace(" ", AppConstants.HtmlSpace);
					footerTitle = footerTitle.PadLeft(title.Length + 11 + i * 5).Replace(" ", AppConstants.HtmlSpace);
				}

				if (hideHeader)
					footerTitle = headerTitle;

				var group = new Group {
					Name = string.Format("{0}Group", groupName),
					GroupKeepTogether = GroupKeepTogether.FirstDetail,
					GroupHeader = hideHeader ? null : new GroupHeaderSection {
						Name = string.Format("{0}GroupHeader", groupName),
						Height = Unit.Cm(0.6),
						PageBreak = PageBreak.None,
						PrintOnEveryPage = true
					},
					GroupFooter = new GroupFooterSection {
						Name = string.Format("{0}GroupFooter", groupName),
						Height = Unit.Cm(0.6),
						PageBreak = PageBreak.None,
					}
				};

				group.Groupings.Add(new Grouping(string.Format("=Fields.{0}", groupName)));
				group.Sortings.Add(new Sorting(string.Format("=Fields.{0}", groupName), SortDirection.Asc));

				if (!hideHeader) {
					htmlTextBox = new HtmlTextBox {
						Name = string.Format("{0}Header", groupName),
						Location = new PointU(new Unit(0, UnitType.Cm), new Unit(0, UnitType.Cm)),
						Size = new SizeU(new Unit(Report.Width.Value, UnitType.Cm), new Unit(0.6, UnitType.Cm)),
                        Value = string.Format(@"=""{0}: "" + IIf(CStr(IsNull(Fields.{1}, """")) = """" Or Replace(CStr(Fields.{1}), "" 00:00:00"", """") = ""01-Jan-0001"" Or Replace(CStr(Fields.{1}), "" 00:00:00"", """") = ""01-Jan-0002"", ""None"", Travelog.Reports.Utils.HtmlEncodeExceptTags(Replace(CStr(Fields.{1}), "" 00:00:00"", """")))", headerTitle, groupName == "TransactionType" ? "TransactionTypeDescription" : groupName)
                    };

					htmlTextBox.Style.Font.Name = "Calibri";
					htmlTextBox.Style.Font.Size = Unit.Point(10);

					htmlTextBox.Style.Padding.Top = Unit.Cm(0.05);
					htmlTextBox.Style.Padding.Bottom = Unit.Cm(0.05);
					htmlTextBox.Style.BackgroundColor = Color.WhiteSmoke;

					group.GroupHeader.Items.Add(htmlTextBox);
				}

				htmlTextBox = new HtmlTextBox {
					Name = string.Format("{0}Footer", groupName),
					Location = new PointU(new Unit(0, UnitType.Cm), new Unit(0, UnitType.Cm)),
					Size = new SizeU(Cash.Left, new Unit(0.6, UnitType.Cm)),
                    Value = string.Format(@"=""{0}: "" + IIf(CStr(IsNull(Fields.{1}, """")) = """" Or Replace(CStr(Fields.{1}), "" 00:00:00"", """") = ""01-Jan-0001"" Or Replace(CStr(Fields.{1}), "" 00:00:00"", """") = ""01-Jan-0002"", ""None"", Travelog.Reports.Utils.HtmlEncodeExceptTags(Replace(CStr(Fields.{1}), "" 00:00:00"", """")))", footerTitle, groupName == "TransactionType" ? "TransactionTypeDescription" : groupName)
                };

				htmlTextBox.Style.Font.Name = "Calibri";
				htmlTextBox.Style.Font.Size = Unit.Point(10);
				htmlTextBox.Style.Padding.Top = Unit.Cm(0.05);
				htmlTextBox.Style.Padding.Bottom = Unit.Cm(0.05);

				if (!hideHeader)
					htmlTextBox.Style.BackgroundColor = Color.WhiteSmoke;

				group.GroupFooter.Items.Add(htmlTextBox);

				string value = null;
				string format = null;

				foreach (var column in ReportTotals.Where(t => t.Key != "PaxNo")) {
					string name = string.Format("{0}{1}GroupTotal", groupName, column.Key);
					double position = StartPosition + column.Value;

					if (column.Key == "Yield") {
						value = "=Round(IIf(Sum(Fields.Cash + Fields.CreditCard) = 0, IIf(Sum(Fields.Commission) < 0, -1, 1), Sum(Fields.Commission)/IIf(Sum(Fields.Cash + Fields.CreditCard) = 0, 1, Sum(Fields.Cash + Fields.CreditCard))), 5)";
						format = "{0:p3}";
					}
					else {
						value = string.Format("=Sum(Fields.{0})", column.Key);
						format = "{0:c2}";
					}

					var textBox = new TextBox {
						Name = name,
						Location = new PointU(new Unit(position, UnitType.Cm), new Unit(0, UnitType.Cm)),
						Size = new SizeU(new Unit(2.7, UnitType.Cm), new Unit(0.6, UnitType.Cm)),
						Value = value
					};

					textBox.Style.Font.Name = "Calibri";
					textBox.Style.Font.Size = Unit.Point(10);
					textBox.Style.TextAlign = HorizontalAlign.Right;
					textBox.Format = format;

					if (!hideHeader)
						textBox.Style.BackgroundColor = Color.WhiteSmoke;

					group.GroupFooter.Items.Add(textBox);
				}

				Groups.Add(group);
			}
		}

		private void ReportHeaderSection1_ItemDataBinding(object sender, EventArgs e) {
			var section = sender as Telerik.Reporting.Processing.ReportSection;

			foreach (Telerik.Reporting.Processing.LayoutElement element in Telerik.Reporting.Processing.ElementTreeHelper.GetChildElements(section)) {
				if (element is Telerik.Reporting.Processing.TextBox textBox && !ReportColumns.Any(t => string.Format("{0}Header", t.Key) == textBox.Name) && !ReportTotals.Any(t => string.Format("{0}Header", t.Key) == textBox.Name))
					textBox.Visible = false;
			}
		}

		private void Detail_ItemDataBinding(object sender, EventArgs e) {
			var section = sender as Telerik.Reporting.Processing.DetailSection;

			if (ReportGroups.Length > 0)
				section.Style.BackgroundColor = Color.Transparent;

			foreach (Telerik.Reporting.Processing.LayoutElement element in Telerik.Reporting.Processing.ElementTreeHelper.GetChildElements(section)) {
				if (element is Telerik.Reporting.Processing.TextBox textBox && !ReportColumns.Any(t => t.Key == textBox.Name))
					textBox.Visible = false;
			}
		}

		private void ReportFooterSection1_ItemDataBinding(object sender, EventArgs e) {
			var section = sender as Telerik.Reporting.Processing.ReportSection;

			foreach (Telerik.Reporting.Processing.LayoutElement element in Telerik.Reporting.Processing.ElementTreeHelper.GetChildElements(section)) {
				var textBox = element as Telerik.Reporting.Processing.TextBox;

				string name = textBox.Name.Replace("Total", string.Empty).Replace("Ytd", string.Empty);

				if (name == "Label") {
					textBox.Location = new PointU(new Unit(StartPosition, UnitType.Cm), textBox.Location.Y);
				}
				else if (ReportTotals.Any(t => t.Key == name)) {
					textBox.Location = new PointU(new Unit(StartPosition + ReportTotals[name], UnitType.Cm), textBox.Location.Y);
				}
			}
		}
	}
}