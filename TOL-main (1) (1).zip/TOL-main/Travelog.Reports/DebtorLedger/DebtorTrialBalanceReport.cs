using Telerik.Reporting;

namespace Travelog.Reports.DebtorLedger {

	public partial class DebtorTrialBalanceReport : TelerikReport {
		public DebtorTrialBalanceReport() {
			InitializeComponent();
		}
	}
}