namespace Travelog.Reports.DebtorLedger {
	partial class DebtorStatementReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.NavigateToUrlAction navigateToUrlAction2 = new Telerik.Reporting.NavigateToUrlAction();
			Telerik.Reporting.NavigateToUrlAction navigateToUrlAction1 = new Telerik.Reporting.NavigateToUrlAction();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DebtorStatementReport));
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter11 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter12 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter13 = new Telerik.Reporting.ReportParameter();
			this.DocumentNoHeader = new Telerik.Reporting.TextBox();
			this.DocumentDateHeader = new Telerik.Reporting.TextBox();
			this.DocumentTypeHeader = new Telerik.Reporting.TextBox();
			this.DescriptionHeader = new Telerik.Reporting.TextBox();
			this.DebitHeader = new Telerik.Reporting.TextBox();
			this.IsMatchDebitHeader = new Telerik.Reporting.TextBox();
			this.CreditHeader = new Telerik.Reporting.TextBox();
			this.IsMatchCreditHeader = new Telerik.Reporting.TextBox();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.AgencyHeaderSubReport1 = new Telerik.Reporting.SubReport();
			this.ReportNameLabel = new Telerik.Reporting.TextBox();
			this.TaxNo = new Telerik.Reporting.TextBox();
			this.StatementDate = new Telerik.Reporting.TextBox();
			this.Debtor = new Telerik.Reporting.TextBox();
			this.Address = new Telerik.Reporting.TextBox();
			this.Code = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.DetailTable = new Telerik.Reporting.Table();
			this.Description = new Telerik.Reporting.TextBox();
			this.DocumentNo = new Telerik.Reporting.TextBox();
			this.Debit = new Telerik.Reporting.TextBox();
			this.DocumentDate = new Telerik.Reporting.TextBox();
			this.DocumentType = new Telerik.Reporting.TextBox();
			this.Credit = new Telerik.Reporting.TextBox();
			this.IsMatchedCredit = new Telerik.Reporting.TextBox();
			this.IsMatchedDebit = new Telerik.Reporting.TextBox();
			this.BalancePeriod1Header = new Telerik.Reporting.HtmlTextBox();
			this.BalancePeriod3Header = new Telerik.Reporting.HtmlTextBox();
			this.BalanceHeader = new Telerik.Reporting.TextBox();
			this.BalancePeriod2Header = new Telerik.Reporting.HtmlTextBox();
			this.BalanceCurrentHeader = new Telerik.Reporting.TextBox();
			this.BalancePeriod3 = new Telerik.Reporting.TextBox();
			this.BalancePeriod2 = new Telerik.Reporting.TextBox();
			this.BalancePeriod1 = new Telerik.Reporting.TextBox();
			this.BalanceCurrent = new Telerik.Reporting.TextBox();
			this.Balance = new Telerik.Reporting.TextBox();
			this.Pages = new Telerik.Reporting.TextBox();
			this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
			this.CreationTime = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			this.MintLogo = new Telerik.Reporting.PictureBox();
			this.PayIdLogo = new Telerik.Reporting.PictureBox();
			this.TravelPayLogo = new Telerik.Reporting.PictureBox();
			this.PaymentOptionsLabel = new Telerik.Reporting.TextBox();
			this.PayId = new Telerik.Reporting.TextBox();
			this.PaymentOptions = new Telerik.Reporting.TextBox();
			this.PaymentTermsLabel = new Telerik.Reporting.TextBox();
			this.PaymentTerms = new Telerik.Reporting.TextBox();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// DocumentNoHeader
			// 
			this.DocumentNoHeader.Name = "DocumentNoHeader";
			this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNoHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentNoHeader.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNoHeader.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNoHeader.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNoHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNoHeader.Style.Font.Bold = true;
			this.DocumentNoHeader.Style.Font.Name = "Calibri";
			this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNoHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentNoHeader.StyleName = "Normal.TableHeader";
			this.DocumentNoHeader.Value = "Doc No";
			// 
			// DocumentDateHeader
			// 
			this.DocumentDateHeader.Name = "DocumentDateHeader";
			this.DocumentDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDateHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDateHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentDateHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDateHeader.Style.Font.Bold = true;
			this.DocumentDateHeader.Style.Font.Name = "Calibri";
			this.DocumentDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDateHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDateHeader.StyleName = "Normal.TableHeader";
			this.DocumentDateHeader.Value = "Date";
			// 
			// DocumentTypeHeader
			// 
			this.DocumentTypeHeader.Name = "DocumentTypeHeader";
			this.DocumentTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DocumentTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentTypeHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentTypeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentTypeHeader.Style.Font.Bold = true;
			this.DocumentTypeHeader.Style.Font.Name = "Calibri";
			this.DocumentTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentTypeHeader.StyleName = "Normal.TableHeader";
			this.DocumentTypeHeader.Value = "Type";
			// 
			// DescriptionHeader
			// 
			this.DescriptionHeader.Name = "DescriptionHeader";
			this.DescriptionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DescriptionHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DescriptionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DescriptionHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DescriptionHeader.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.DescriptionHeader.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.DescriptionHeader.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.DescriptionHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DescriptionHeader.Style.Font.Bold = true;
			this.DescriptionHeader.Style.Font.Name = "Calibri";
			this.DescriptionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DescriptionHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DescriptionHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DescriptionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DescriptionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DescriptionHeader.StyleName = "Normal.TableHeader";
			this.DescriptionHeader.Value = "Description";
			// 
			// DebitHeader
			// 
			this.DebitHeader.Name = "DebitHeader";
			this.DebitHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DebitHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.DebitHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DebitHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DebitHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DebitHeader.Style.Font.Bold = true;
			this.DebitHeader.Style.Font.Name = "Calibri";
			this.DebitHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DebitHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DebitHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DebitHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DebitHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.DebitHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DebitHeader.StyleName = "Normal.TableHeader";
			this.DebitHeader.Value = "Debit";
			// 
			// IsMatchDebitHeader
			// 
			this.IsMatchDebitHeader.Name = "IsMatchDebitHeader";
			this.IsMatchDebitHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.IsMatchDebitHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.IsMatchDebitHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.IsMatchDebitHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.IsMatchDebitHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.IsMatchDebitHeader.Style.Font.Name = "Calibri";
			this.IsMatchDebitHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.IsMatchDebitHeader.StyleName = "Normal.TableHeader";
			this.IsMatchDebitHeader.Value = "";
			// 
			// CreditHeader
			// 
			this.CreditHeader.Name = "CreditHeader";
			this.CreditHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CreditHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.CreditHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CreditHeader.Style.Font.Bold = true;
			this.CreditHeader.Style.Font.Name = "Calibri";
			this.CreditHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreditHeader.StyleName = "Normal.TableHeader";
			this.CreditHeader.Value = "Credit";
			// 
			// IsMatchCreditHeader
			// 
			this.IsMatchCreditHeader.Name = "IsMatchCreditHeader";
			this.IsMatchCreditHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.IsMatchCreditHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.IsMatchCreditHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.IsMatchCreditHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.IsMatchCreditHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.IsMatchCreditHeader.Style.Font.Name = "Calibri";
			this.IsMatchCreditHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.IsMatchCreditHeader.StyleName = "Normal.TableHeader";
			this.IsMatchCreditHeader.Value = "";
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(4.5D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.PaymentTerms,
            this.PaymentTermsLabel,
            this.PaymentOptions,
            this.PayId,
            this.PaymentOptionsLabel,
            this.TravelPayLogo,
            this.PayIdLogo,
            this.MintLogo});
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			this.GroupFooterSection1.PageBreak = Telerik.Reporting.PageBreak.After;
			this.GroupFooterSection1.Style.Visible = true;
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(2.001D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AgencyHeaderSubReport1,
            this.ReportNameLabel,
            this.TaxNo,
            this.StatementDate});
			this.GroupHeaderSection1.KeepTogether = false;
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			// 
			// AgencyHeaderSubReport1
			// 
			this.AgencyHeaderSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AgencyHeaderSubReport1.Name = "AgencyHeaderSubReport1";
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Fields.AgencyId"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
			typeReportSource1.TypeName = "Travelog.Reports.Common.AgencyHeaderSubReport1, Travelog.Reports, Version=1.0.0.0" +
    ", Culture=neutral, PublicKeyToken=null";
			this.AgencyHeaderSubReport1.ReportSource = typeReportSource1;
			this.AgencyHeaderSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.AgencyHeaderSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// ReportNameLabel
			// 
			this.ReportNameLabel.CanShrink = true;
			this.ReportNameLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ReportNameLabel.Name = "ReportNameLabel";
			this.ReportNameLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(1.001D));
			this.ReportNameLabel.Style.Font.Name = "Calibri";
			this.ReportNameLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(18D);
			this.ReportNameLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(0D);
			this.ReportNameLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ReportNameLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ReportNameLabel.Value = "STATEMENT";
			// 
			// TaxNo
			// 
			this.TaxNo.CanShrink = true;
			this.TaxNo.Format = "";
			this.TaxNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.TaxNo.Name = "TaxNo";
			this.TaxNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.TaxNo.Style.Font.Name = "Calibri";
			this.TaxNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxNo.Value = "= Fields.TaxNo";
			this.TaxNo.ItemDataBound += new System.EventHandler(this.TaxNo_ItemDataBound);
			// 
			// StatementDate
			// 
			this.StatementDate.CanShrink = true;
			this.StatementDate.Format = "";
			this.StatementDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.StatementDate.Name = "StatementDate";
			this.StatementDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.StatementDate.Style.Font.Name = "Calibri";
			this.StatementDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.StatementDate.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.StatementDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.StatementDate.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.StatementDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.StatementDate.Value = "= \"Date: \" + Format(\"{0:dd-MMM-yyyy}\", Parameters.reportDate.Value)";
			// 
			// Debtor
			// 
			this.Debtor.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Debtor.Name = "Debtor";
			this.Debtor.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Debtor.Style.Font.Bold = true;
			this.Debtor.Style.Font.Name = "Calibri";
			this.Debtor.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(11D);
			this.Debtor.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Debtor.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Debtor.Value = "= Fields.Debtor";
			// 
			// Address
			// 
			this.Address.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Address.Name = "Address";
			this.Address.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Address.Style.Font.Name = "Calibri";
			this.Address.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Address.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Address.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Address.Value = "= Fields.Address";
			// 
			// Code
			// 
			this.Code.CanShrink = true;
			this.Code.Format = "";
			this.Code.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Code.Name = "Code";
			this.Code.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Code.Style.Font.Name = "Calibri";
			this.Code.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Code.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Code.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Code.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Code.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Code.Value = "= IIf(Fields.Code = \"\", \"\", \"Debtor Code: \" + Fields.Code)";
			// 
			// Detail
			// 
			this.Detail.Bindings.Add(new Telerik.Reporting.Binding("PageBreak", "= IIf(Parameters.issuedDocumentType.Value = \"Invoice\", 0, 1)"));
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(4.899D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailTable,
            this.BalancePeriod1Header,
            this.BalancePeriod3Header,
            this.BalanceHeader,
            this.BalancePeriod2Header,
            this.BalanceCurrentHeader,
            this.BalancePeriod3,
            this.BalancePeriod2,
            this.BalancePeriod1,
            this.BalanceCurrent,
            this.Balance,
            this.Address,
            this.Debtor,
            this.Code});
			this.Detail.KeepTogether = false;
			this.Detail.Name = "Detail";
			this.Detail.PageBreak = Telerik.Reporting.PageBreak.Before;
			this.Detail.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// DetailTable
			// 
			this.DetailTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.TransactionDetailReportList"));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.2D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.6D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.5D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(5.4D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.4D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.3D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.4D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.3D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.SetCellContent(0, 3, this.Description);
			this.DetailTable.Body.SetCellContent(0, 0, this.DocumentNo);
			this.DetailTable.Body.SetCellContent(0, 4, this.Debit);
			this.DetailTable.Body.SetCellContent(0, 1, this.DocumentDate);
			this.DetailTable.Body.SetCellContent(0, 2, this.DocumentType);
			this.DetailTable.Body.SetCellContent(0, 6, this.Credit);
			this.DetailTable.Body.SetCellContent(0, 7, this.IsMatchedCredit);
			this.DetailTable.Body.SetCellContent(0, 5, this.IsMatchedDebit);
			tableGroup1.Name = "tableGroup8";
			tableGroup1.ReportItem = this.DocumentNoHeader;
			tableGroup2.Name = "group";
			tableGroup2.ReportItem = this.DocumentDateHeader;
			tableGroup3.Name = "group1";
			tableGroup3.ReportItem = this.DocumentTypeHeader;
			tableGroup4.Name = "tableGroup9";
			tableGroup4.ReportItem = this.DescriptionHeader;
			tableGroup5.Name = "tableGroup10";
			tableGroup5.ReportItem = this.DebitHeader;
			tableGroup6.Name = "group4";
			tableGroup6.ReportItem = this.IsMatchDebitHeader;
			tableGroup7.Name = "group2";
			tableGroup7.ReportItem = this.CreditHeader;
			tableGroup8.Name = "group3";
			tableGroup8.ReportItem = this.IsMatchCreditHeader;
			this.DetailTable.ColumnGroups.Add(tableGroup1);
			this.DetailTable.ColumnGroups.Add(tableGroup2);
			this.DetailTable.ColumnGroups.Add(tableGroup3);
			this.DetailTable.ColumnGroups.Add(tableGroup4);
			this.DetailTable.ColumnGroups.Add(tableGroup5);
			this.DetailTable.ColumnGroups.Add(tableGroup6);
			this.DetailTable.ColumnGroups.Add(tableGroup7);
			this.DetailTable.ColumnGroups.Add(tableGroup8);
			this.DetailTable.ColumnHeadersPrintOnEveryPage = true;
			this.DetailTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DocumentNo,
            this.DocumentDate,
            this.DocumentType,
            this.Description,
            this.Debit,
            this.IsMatchedDebit,
            this.Credit,
            this.IsMatchedCredit,
            this.DocumentNoHeader,
            this.DocumentDateHeader,
            this.DocumentTypeHeader,
            this.DescriptionHeader,
            this.DebitHeader,
            this.IsMatchDebitHeader,
            this.CreditHeader,
            this.IsMatchCreditHeader});
			this.DetailTable.KeepTogether = false;
			this.DetailTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.DetailTable.Name = "DetailTable";
			tableGroup9.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup9.Name = "detailTableGroup";
			this.DetailTable.RowGroups.Add(tableGroup9);
			this.DetailTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.1D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			// 
			// Description
			// 
			this.Description.CanGrow = false;
			this.Description.Format = "";
			this.Description.Name = "Description";
			this.Description.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Description.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Description.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Description.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.Description.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.Description.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.Description.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Description.Style.Font.Name = "Calibri";
			this.Description.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Description.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Description.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Description.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Description.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Description.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Description.StyleName = "Normal.TableBody";
			this.Description.Value = "= Fields.Description";
			// 
			// DocumentNo
			// 
			this.DocumentNo.CanGrow = false;
			this.DocumentNo.Format = "";
			this.DocumentNo.Name = "DocumentNo";
			this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNo.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentNo.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNo.Style.Font.Name = "Calibri";
			this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.DocumentNo.StyleName = "Normal.TableBody";
			this.DocumentNo.Value = "= Fields.DocumentNo";
			// 
			// Debit
			// 
			this.Debit.CanGrow = false;
			this.Debit.Format = "{0:c2}";
			this.Debit.Name = "Debit";
			this.Debit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Debit.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Debit.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Debit.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Debit.Style.Font.Name = "Calibri";
			this.Debit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Debit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Debit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Debit.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Debit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Debit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Debit.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Debit.StyleName = "Normal.TableBody";
			this.Debit.Value = "= IIf(Fields.SignType = \"Debit\", Fields.AmountGross, Null)";
			// 
			// DocumentDate
			// 
			this.DocumentDate.CanGrow = false;
			this.DocumentDate.Format = "{0:dd-MMM-yyyy}";
			this.DocumentDate.Name = "DocumentDate";
			this.DocumentDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDate.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentDate.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDate.Style.Font.Name = "Calibri";
			this.DocumentDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.StyleName = "Normal.TableBody";
			this.DocumentDate.Value = "= Fields.DocumentDate";
			// 
			// DocumentType
			// 
			this.DocumentType.CanGrow = false;
			this.DocumentType.Name = "DocumentType";
			this.DocumentType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentType.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentType.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentType.Style.Font.Name = "Calibri";
			this.DocumentType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentType.StyleName = "Normal.TableBody";
			this.DocumentType.Value = "= Fields.TransactionType";
			// 
			// Credit
			// 
			this.Credit.CanGrow = false;
			this.Credit.Format = "{0:c2}";
			this.Credit.Name = "Credit";
			this.Credit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Credit.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Credit.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Credit.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.Credit.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.Credit.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.Credit.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Credit.Style.Font.Name = "Calibri";
			this.Credit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Credit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Credit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Credit.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Credit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Credit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Credit.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Credit.StyleName = "Normal.TableBody";
			this.Credit.Value = "= IIf(Fields.SignType = \"Debit\", Null, Fields.AmountGross)";
			// 
			// IsMatchedCredit
			// 
			this.IsMatchedCredit.CanGrow = false;
			this.IsMatchedCredit.Name = "IsMatchedCredit";
			this.IsMatchedCredit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.IsMatchedCredit.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.IsMatchedCredit.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.IsMatchedCredit.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.IsMatchedCredit.Style.Font.Name = "Calibri";
			this.IsMatchedCredit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.IsMatchedCredit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.IsMatchedCredit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
			this.IsMatchedCredit.StyleName = "Normal.TableBody";
			this.IsMatchedCredit.Value = "= IIf(Fields.SignType = \"Credit\" And Fields.IsMatched,\"*\",\"\")";
			// 
			// IsMatchedDebit
			// 
			this.IsMatchedDebit.CanGrow = false;
			this.IsMatchedDebit.Name = "IsMatchedDebit";
			this.IsMatchedDebit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.IsMatchedDebit.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.IsMatchedDebit.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.IsMatchedDebit.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.IsMatchedDebit.Style.Font.Name = "Calibri";
			this.IsMatchedDebit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.IsMatchedDebit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.IsMatchedDebit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
			this.IsMatchedDebit.StyleName = "Normal.TableBody";
			this.IsMatchedDebit.Value = "= IIf(Fields.SignType = \"Debit\" And Fields.IsMatched,\"*\",\"\")";
			// 
			// BalancePeriod1Header
			// 
			this.BalancePeriod1Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7.2D), Telerik.Reporting.Drawing.Unit.Cm(3.199D));
			this.BalancePeriod1Header.Name = "BalancePeriod1Header";
			this.BalancePeriod1Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod1Header.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.BalancePeriod1Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod1Header.Style.Font.Name = "Calibri";
			this.BalancePeriod1Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod1Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod1Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod1Header.StyleName = "Normal.TableHeader";
			this.BalancePeriod1Header.Value = "= IIf(Fields.AgingCycleId = 0, \"7 Day\", IIf(Fields.AgingCycleId = 1, \"14 Day\", II" +
    "f(Fields.AgingCycleId = 2, \"30 Day\", \"Period 1\")))+\" Balance\"";
			// 
			// BalancePeriod3Header
			// 
			this.BalancePeriod3Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.199D));
			this.BalancePeriod3Header.Name = "BalancePeriod3Header";
			this.BalancePeriod3Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod3Header.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.BalancePeriod3Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod3Header.Style.Font.Name = "Calibri";
			this.BalancePeriod3Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod3Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod3Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod3Header.StyleName = "Normal.TableHeader";
			this.BalancePeriod3Header.Value = "= IIf(Fields.AgingCycleId = 0, \"21 Day+\", IIf(Fields.AgingCycleId = 1, \"42 Day+\"," +
    " IIf(Fields.AgingCycleId = 2, \"90 Day+\", \"Period 3+\")))+\" Balance\"";
			// 
			// BalanceHeader
			// 
			this.BalanceHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.4D), Telerik.Reporting.Drawing.Unit.Cm(3.199D));
			this.BalanceHeader.Name = "BalanceHeader";
			this.BalanceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalanceHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.BalanceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalanceHeader.Style.Font.Name = "Calibri";
			this.BalanceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalanceHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalanceHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalanceHeader.StyleName = "Normal.TableHeader";
			this.BalanceHeader.Value = "Balance";
			// 
			// BalancePeriod2Header
			// 
			this.BalancePeriod2Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(3.199D));
			this.BalancePeriod2Header.Name = "BalancePeriod2Header";
			this.BalancePeriod2Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod2Header.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.BalancePeriod2Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod2Header.Style.Font.Name = "Calibri";
			this.BalancePeriod2Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod2Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod2Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod2Header.StyleName = "Normal.TableHeader";
			this.BalancePeriod2Header.Value = "= IIf(Fields.AgingCycleId = 0, \"14 Day\", IIf(Fields.AgingCycleId = 1, \"28 Day\", I" +
    "If(Fields.AgingCycleId = 2, \"60 Day\", \"Period 2\")))+\" Balance\"";
			// 
			// BalanceCurrentHeader
			// 
			this.BalanceCurrentHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.8D), Telerik.Reporting.Drawing.Unit.Cm(3.199D));
			this.BalanceCurrentHeader.Name = "BalanceCurrentHeader";
			this.BalanceCurrentHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalanceCurrentHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.BalanceCurrentHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalanceCurrentHeader.Style.Font.Name = "Calibri";
			this.BalanceCurrentHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalanceCurrentHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalanceCurrentHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalanceCurrentHeader.StyleName = "Normal.TableHeader";
			this.BalanceCurrentHeader.Value = "Current";
			// 
			// BalancePeriod3
			// 
			this.BalancePeriod3.Format = "{0:C2}";
			this.BalancePeriod3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.799D));
			this.BalancePeriod3.Name = "BalancePeriod3";
			this.BalancePeriod3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod3.Style.Font.Name = "Calibri";
			this.BalancePeriod3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod3.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod3.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod3.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod3.StyleName = "Normal.TableBody";
			this.BalancePeriod3.Value = "= Fields.BalancePeriod3";
			// 
			// BalancePeriod2
			// 
			this.BalancePeriod2.Format = "{0:C2}";
			this.BalancePeriod2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(3.799D));
			this.BalancePeriod2.Name = "BalancePeriod2";
			this.BalancePeriod2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod2.Style.Font.Name = "Calibri";
			this.BalancePeriod2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod2.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod2.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod2.StyleName = "Normal.TableBody";
			this.BalancePeriod2.Value = "= Fields.BalancePeriod2";
			// 
			// BalancePeriod1
			// 
			this.BalancePeriod1.Format = "{0:C2}";
			this.BalancePeriod1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7.2D), Telerik.Reporting.Drawing.Unit.Cm(3.799D));
			this.BalancePeriod1.Name = "BalancePeriod1";
			this.BalancePeriod1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod1.Style.Font.Name = "Calibri";
			this.BalancePeriod1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod1.StyleName = "Normal.TableBody";
			this.BalancePeriod1.Value = "= Fields.BalancePeriod1";
			// 
			// BalanceCurrent
			// 
			this.BalanceCurrent.Format = "{0:C2}";
			this.BalanceCurrent.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.8D), Telerik.Reporting.Drawing.Unit.Cm(3.799D));
			this.BalanceCurrent.Name = "BalanceCurrent";
			this.BalanceCurrent.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalanceCurrent.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalanceCurrent.Style.Font.Name = "Calibri";
			this.BalanceCurrent.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalanceCurrent.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalanceCurrent.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalanceCurrent.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalanceCurrent.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalanceCurrent.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalanceCurrent.StyleName = "Normal.TableBody";
			this.BalanceCurrent.Value = "= Fields.BalanceCurrent";
			// 
			// Balance
			// 
			this.Balance.Format = "{0:C2}";
			this.Balance.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.4D), Telerik.Reporting.Drawing.Unit.Cm(3.799D));
			this.Balance.Name = "Balance";
			this.Balance.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Balance.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Balance.Style.Font.Name = "Calibri";
			this.Balance.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Balance.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Balance.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Balance.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Balance.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Balance.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Balance.StyleName = "Normal.TableBody";
			this.Balance.Value = "= Fields.Balance";
			// 
			// Pages
			// 
			this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Name = "Pages";
			this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Style.Color = System.Drawing.Color.DarkGray;
			this.Pages.Style.Font.Name = "Calibri";
			this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Pages.Value = "= \"Page \" + PageNumber";
			// 
			// PageFooterSection
			// 
			this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
			this.PageFooterSection.Name = "PageFooterSection";
			// 
			// CreationTime
			// 
			this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Name = "CreationTime";
			this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
			this.CreationTime.Style.Font.Name = "Calibri";
			this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy" +
    " HH:mm}\", Parameters.creationTime.Value)";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "DebtorStatementReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.DebtorLedger.DebtorLedgerDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("reportDate", typeof(System.DateTime), "= Parameters.reportDate.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("reportOrderId", typeof(int), "= Parameters.reportOrderId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("matchedTxnsReportOptionId", typeof(int), "= Parameters.matchedTxnsReportOptionId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("transactionBalanceTypeId", typeof(int), "= Parameters.transactionBalanceTypeId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agingCycleId", typeof(int), "= Parameters.agingCycleId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agingPeriodId", typeof(int), "= Parameters.agingPeriodId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("classId", typeof(int), "= Parameters.classId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("debtorIds", typeof(string), "= Parameters.debtorIds.Value"));
			// 
			// MintLogo
			// 
			navigateToUrlAction2.Url = "= Fields.MintUrl";
			this.MintLogo.Action = navigateToUrlAction2;
			this.MintLogo.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.MintUrl,\"\")=\"\", False, True)"));
			this.MintLogo.Bindings.Add(new Telerik.Reporting.Binding("Left", resources.GetString("MintLogo.Bindings")));
			this.MintLogo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.6D), Telerik.Reporting.Drawing.Unit.Cm(3.2D));
			this.MintLogo.MimeType = "image/png";
			this.MintLogo.Name = "MintLogo";
			this.MintLogo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.MintLogo.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
			this.MintLogo.Value = ((object)(resources.GetObject("MintLogo.Value")));
			// 
			// PayIdLogo
			// 
			this.PayIdLogo.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.PayId,\"\")=\"\", False, True)"));
			this.PayIdLogo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.2D));
			this.PayIdLogo.MimeType = "image/png";
			this.PayIdLogo.Name = "PayIdLogo";
			this.PayIdLogo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.38D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.PayIdLogo.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
			this.PayIdLogo.Value = ((object)(resources.GetObject("PayIdLogo.Value")));
			// 
			// TravelPayLogo
			// 
			navigateToUrlAction1.Url = "= Fields.TravelPayUrl";
			this.TravelPayLogo.Action = navigateToUrlAction1;
			this.TravelPayLogo.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.TravelPayUrl,\"\")=\"\", False, True)"));
			this.TravelPayLogo.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(IsNull(Fields.PayId,\"\")=\"\", \"0cm\", \"2.4cm\")"));
			this.TravelPayLogo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.TravelPayLogo.MimeType = "image/png";
			this.TravelPayLogo.Name = "TravelPayLogo";
			this.TravelPayLogo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.TravelPayLogo.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
			this.TravelPayLogo.Value = ((object)(resources.GetObject("TravelPayLogo.Value")));
			// 
			// PaymentOptionsLabel
			// 
			this.PaymentOptionsLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.PaymentOptions, \"\")=\"\" And IsNull(Fields.PayId, \"\")=\"\" And Is" +
            "Null(Fields.TravelPayUrl, \"\")=\"\" And IsNull(Fields.MintUrl, \"\")=\"\", False, True)" +
            ""));
			this.PaymentOptionsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.PaymentOptionsLabel.Name = "PaymentOptionsLabel";
			this.PaymentOptionsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.PaymentOptionsLabel.Style.Font.Bold = true;
			this.PaymentOptionsLabel.Style.Font.Name = "Calibri";
			this.PaymentOptionsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PaymentOptionsLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.PaymentOptionsLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.PaymentOptionsLabel.Value = "Payment Options";
			// 
			// PayId
			// 
			this.PayId.CanGrow = false;
			this.PayId.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4D));
			this.PayId.Name = "PayId";
			this.PayId.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.PayId.Style.Font.Italic = true;
			this.PayId.Style.Font.Name = "Calibri";
			this.PayId.Value = "= IIf(IsNull(Fields.PayId, \"\")=\"\", \"\", Fields.PayIdLabel + \": \" + Fields.PayId)";
			// 
			// PaymentOptions
			// 
			this.PaymentOptions.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.PaymentOptions, \"\") = \"\", False, True)"));
			this.PaymentOptions.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2D));
			this.PaymentOptions.Name = "PaymentOptions";
			this.PaymentOptions.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PaymentOptions.Style.Font.Name = "Calibri";
			this.PaymentOptions.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PaymentOptions.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			this.PaymentOptions.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.PaymentOptions.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.PaymentOptions.Value = "= Fields.PaymentOptions";
			// 
			// PaymentTermsLabel
			// 
			this.PaymentTermsLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.PaymentTerms, \"\") = \"\", False, True)"));
			this.PaymentTermsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.PaymentTermsLabel.Name = "PaymentTermsLabel";
			this.PaymentTermsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.PaymentTermsLabel.Style.Font.Bold = true;
			this.PaymentTermsLabel.Style.Font.Name = "Calibri";
			this.PaymentTermsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PaymentTermsLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.PaymentTermsLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.PaymentTermsLabel.Value = "Payment Terms";
			// 
			// PaymentTerms
			// 
			this.PaymentTerms.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.PaymentTerms, \"\") = \"\", False, True)"));
			this.PaymentTerms.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.PaymentTerms.Name = "PaymentTerms";
			this.PaymentTerms.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PaymentTerms.Style.Font.Name = "Calibri";
			this.PaymentTerms.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PaymentTerms.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			this.PaymentTerms.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.PaymentTerms.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.PaymentTerms.Value = "= Fields.PaymentTerms";
			// 
			// DebtorStatementReport
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.DebtorId"));
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail,
            this.PageFooterSection});
			this.Name = "DebtorStatementReport";
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "customerId";
			reportParameter2.Name = "agencyId";
			reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter3.Name = "issuedDocumentType";
			reportParameter4.Name = "creationUser";
			reportParameter5.Name = "creationTime";
			reportParameter5.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter6.Name = "reportDate";
			reportParameter7.Name = "reportOrderId";
			reportParameter7.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter8.Name = "matchedTxnsReportOptionId";
			reportParameter8.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter9.Name = "transactionBalanceTypeId";
			reportParameter9.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter10.Name = "agingCycleId";
			reportParameter10.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter11.Name = "agingPeriodId";
			reportParameter11.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter12.Name = "classId";
			reportParameter12.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter13.Name = "debtorIds";
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.ReportParameters.Add(reportParameter9);
			this.ReportParameters.Add(reportParameter10);
			this.ReportParameters.Add(reportParameter11);
			this.ReportParameters.Add(reportParameter12);
			this.ReportParameters.Add(reportParameter13);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(18.1D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.TextBox ReportNameLabel;
		private Telerik.Reporting.TextBox TaxNo;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.TextBox Debtor;
		private Telerik.Reporting.TextBox StatementDate;
		private Telerik.Reporting.TextBox Address;
		private Telerik.Reporting.TextBox Code;
		private Telerik.Reporting.Table DetailTable;
		private Telerik.Reporting.TextBox Description;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox Debit;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox DescriptionHeader;
		private Telerik.Reporting.TextBox DebitHeader;
		private Telerik.Reporting.TextBox DocumentDate;
		private Telerik.Reporting.TextBox DocumentDateHeader;
		private Telerik.Reporting.TextBox DocumentType;
		private Telerik.Reporting.TextBox DocumentTypeHeader;
		private Telerik.Reporting.TextBox Credit;
		private Telerik.Reporting.TextBox CreditHeader;
		private Telerik.Reporting.SubReport AgencyHeaderSubReport1;
		private Telerik.Reporting.HtmlTextBox BalancePeriod1Header;
		private Telerik.Reporting.HtmlTextBox BalancePeriod3Header;
		private Telerik.Reporting.TextBox BalanceHeader;
		private Telerik.Reporting.HtmlTextBox BalancePeriod2Header;
		private Telerik.Reporting.TextBox BalanceCurrentHeader;
		private Telerik.Reporting.TextBox BalancePeriod3;
		private Telerik.Reporting.TextBox BalancePeriod2;
		private Telerik.Reporting.TextBox BalancePeriod1;
		private Telerik.Reporting.TextBox BalanceCurrent;
		private Telerik.Reporting.TextBox Balance;
		private Telerik.Reporting.TextBox IsMatchedCredit;
		private Telerik.Reporting.TextBox IsMatchCreditHeader;
		private Telerik.Reporting.TextBox IsMatchedDebit;
		private Telerik.Reporting.TextBox IsMatchDebitHeader;
		private Telerik.Reporting.TextBox PaymentTerms;
		private Telerik.Reporting.TextBox PaymentTermsLabel;
		private Telerik.Reporting.TextBox PaymentOptions;
		private Telerik.Reporting.TextBox PayId;
		private Telerik.Reporting.TextBox PaymentOptionsLabel;
		private Telerik.Reporting.PictureBox TravelPayLogo;
		private Telerik.Reporting.PictureBox PayIdLogo;
		private Telerik.Reporting.PictureBox MintLogo;
	}
}