﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.DebtorLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;

namespace Travelog.Reports.DebtorLedger {
    public class DebtorLedgerDataSources {
		private const string ClassName = "Travelog.Reports.DebtorLedger.DebtorLedgerDataSources";

		public List<DebtorTrialBalanceReportModel> DebtorTrialBalanceReport(int customerId, DateTime reportDate, int reportOrderId, int matchedTxnsReportOptionId, int ledgerDocumentTypeId, int transactionBalanceTypeId, int agingCycleId, int agingPeriodId, int classId, int agencyId, string debtorIds) {
			try {
				using (var lazyContext = new AppLazyContext(customerId, true)) {
					var matchedTxnsReportOption = (MatchedTxnsReportOption)matchedTxnsReportOptionId;
					var agingCycle = (AgingCycle)agingCycleId;
					var transactionBalanceType = (TransactionBalanceType)transactionBalanceTypeId;
					var ledgerDocumentType = (LedgerDocumentType)ledgerDocumentTypeId;

					int[] debtorIdList = null;

					if (!string.IsNullOrEmpty(debtorIds))
						debtorIdList = debtorIds.Split(',').Select(int.Parse).ToArray();

					var q = Debtor.GetDebtorLedgerReportQuery(lazyContext, agencyId, agingCycle, reportDate, ledgerDocumentType, reportOrderId, classId, debtorIdList);

					if (transactionBalanceType == TransactionBalanceType.NonZero) {
						q = q.Where(t => t.BalancePeriod1 != 0 || t.BalancePeriod2 != 0 || t.BalancePeriod3 != 0 || t.BalanceCurrent != 0 || t.Balance != 0);
					}
					else if (agingPeriodId != -1) {
						if (agingPeriodId == 0) {
							q = q.Where(t => t.BalancePeriod1 != 0 || t.BalancePeriod2 != 0 || t.BalancePeriod3 != 0);
						}
						else if (agingPeriodId == 1) {
							q = q.Where(t => t.BalancePeriod2 != 0 || t.BalancePeriod3 != 0);
						}
						else if (agingPeriodId == 2) {
							q = q.Where(t => t.BalancePeriod3 != 0);
						}
					}

					return q.ToList().ConvertAll(row => new DebtorTrialBalanceReportModel {
						DebtorId = row.Debtor.Id,
						Code = row.Debtor.Code,
						Name = row.Debtor.Name,
						CreditLimit = row.Debtor.CreditLimit,
						BalancePeriod1 = row.BalancePeriod1,
						BalancePeriod2 = row.BalancePeriod2,
						BalancePeriod3 = row.BalancePeriod3,
						BalanceCurrent = row.BalanceCurrent,
						Balance = row.Balance,
						TransactionDetailReportList = ledgerDocumentType == LedgerDocumentType.Standard || ledgerDocumentType == LedgerDocumentType.Reconciliation ? new List<TransactionDetailReportModel>()
						: Debtor.GetDebtorLedgerTransactionReportQuery(row, customerId, matchedTxnsReportOption, reportDate, ledgerDocumentType)
					});
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "DebtorTrialBalanceReport", ex, customerId);
				return new List<DebtorTrialBalanceReportModel>();
			}
		}

		public List<DebtorStatementReportModel> DebtorStatementReport(int customerId, DateTime reportDate, int reportOrderId, int matchedTxnsReportOptionId, int transactionBalanceTypeId, int agingCycleId, int agingPeriodId, int classId, int agencyId, string debtorIds) {
			try {
				using (var lazyContext = new AppLazyContext(customerId, true)) {
					var matchedTxnsReportOption = (MatchedTxnsReportOption)matchedTxnsReportOptionId;
					var agingCycle = (AgingCycle)agingCycleId;
					var transactionBalanceType = (TransactionBalanceType)transactionBalanceTypeId;

					int[] debtorIdList = null;

					if (!string.IsNullOrEmpty(debtorIds))
						debtorIdList = debtorIds.Split(',').Select(int.Parse).ToArray();

					var q = Debtor.GetDebtorLedgerReportQuery(lazyContext, agencyId, agingCycle, reportDate, LedgerDocumentType.Reconciliation, reportOrderId, classId, debtorIdList);

					if (transactionBalanceType == TransactionBalanceType.NonZero) {
						q = q.Where(t => t.BalancePeriod1 != 0 || t.BalancePeriod2 != 0 || t.BalancePeriod3 != 0 || t.BalanceCurrent != 0 || t.Balance != 0);
					}
					else if (agingPeriodId != -1) {
						if (agingPeriodId == 0) {
							q = q.Where(t => t.BalancePeriod1 != 0 || t.BalancePeriod2 != 0 || t.BalancePeriod3 != 0);
						}
						else if (agingPeriodId == 1) {
							q = q.Where(t => t.BalancePeriod2 != 0 || t.BalancePeriod3 != 0);
						}
						else if (agingPeriodId == 2) {
							q = q.Where(t => t.BalancePeriod3 != 0);
						}
					}

					Agency agency;

					if (agencyId > 0) {
						agency = lazyContext.Agency.Find(agencyId);
					}
					else {
                        agency = lazyContext.Agency.Single(t => t.IsHeadOffice);
                    }

					return q.ToList().ConvertAll(row => new DebtorStatementReportModel {
						DebtorId = row.Debtor.Id,
						Code = row.Debtor.Code,
						Debtor = row.Debtor.Name,
						Address = row.Debtor.GetAddress(lazyContext).Replace(AppConstants.HtmlLineBreak, Environment.NewLine),
						AgencyId = agency.Id,
						TaxNo = agency.TaxNo,
						PaymentTerms = row.PaymentTerms,
						PaymentOptions = agency.PaymentOptions,
						PayIdLabel = agency.PayIdType.GetEnumDescription(),
						PayId = agency.PayId,
						TravelPayUrl = agency.TravelPayUrl,
						MintUrl = agency.MintUrl,
						AgingCycleId = (int)row.Debtor.AgingCycle,
						BalanceCurrent = row.BalanceCurrent,
						BalancePeriod1 = row.BalancePeriod1,
						BalancePeriod2 = row.BalancePeriod2,
						BalancePeriod3 = row.BalancePeriod3,
						Balance = row.Balance,
						TransactionDetailReportList = Debtor.GetDebtorLedgerTransactionReportQuery(row, customerId, matchedTxnsReportOption, reportDate, LedgerDocumentType.Reconciliation).ToList()
					});
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "DebtorStatementReport", ex, customerId);
				return new List<DebtorStatementReportModel>();
			}
		}

		public static TypeReportSource GetReportSource(AppMainContext context, DebtorReportSourceModel model) {
			string typeName;
			string reportName;

			var sb = new StringBuilder();

			switch (model.ReportSource) {
				default:
					throw new InvalidOperationException("Invalid Report Source.");
				case ReportSourceDebtor.TrialBalance:
					reportName = string.Format("{0} {1}", GetReportName(model.ReportSource), (model.LedgerDocumentType ?? LedgerDocumentType.Standard).GetEnumDescription());
					typeName = typeof(DebtorTrialBalanceReport).AssemblyQualifiedName;
					sb.AppendFormat("Agency: {0}", (model.AgencyId ?? 0) <= 0 ? "All Agencies" : context.Agency.Find(model.AgencyId).Name);
					sb.AppendFormat(" | Matched Txns: {0}", (model.MatchedTxnsReportOption ?? MatchedTxnsReportOption.ExcludeAll).GetEnumDescription());
					sb.AppendFormat(" | Balances: {0}", (model.TransactionBalanceType ?? TransactionBalanceType.None) == TransactionBalanceType.NonZero ? "Non-Zero" : "All Balances");
					sb.AppendFormat(" | Aging Cycle: {0}", (model.AgingCycle ?? AgingCycle.NotSpecified) == AgingCycle.NotSpecified ? "All Aging Cycles" : model.AgingCycle.GetEnumDescription());
					sb.AppendFormat(" | Periods: {0}", model.AgingPeriodId == 0 ? "Period 1 & Above" : model.AgingPeriodId == 1 ? "Period 2 & Above" : model.AgingPeriodId == 2 ? "Period 3 & Above" : "All Periods");
					sb.AppendFormat(" | Class: {0}", (model.ClassId ?? -1) == -1 ? "All Classes" : context.Class.Find(model.ClassId).Name);
					break;
				case ReportSourceDebtor.DebtorStatements:
					reportName = "Debtor Statements";
					typeName = typeof(DebtorStatementReport).AssemblyQualifiedName;
					break;
			}

			var reportSource = new TypeReportSource {
				TypeName = typeName
			};

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = model.CustomerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = model.AgencyId ?? -1 });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = model.CreationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = model.CreationTime });
			reportSource.Parameters.Add(new Parameter { Name = "reportName", Value = reportName });
			reportSource.Parameters.Add(new Parameter { Name = "reportDate", Value = (model.ReportDate ?? DateTime.MinValue).ToShortDateStringExt() });
			reportSource.Parameters.Add(new Parameter { Name = "headerContent", Value = Utils.HtmlEncodeExceptTags(sb.ToString()) });
			reportSource.Parameters.Add(new Parameter { Name = "reportOrderId", Value = model.ReportOrderId ?? 0 });
			reportSource.Parameters.Add(new Parameter { Name = "matchedTxnsReportOptionId", Value = (int)(model.MatchedTxnsReportOption ?? MatchedTxnsReportOption.ExcludeAll) });
			reportSource.Parameters.Add(new Parameter { Name = "transactionBalanceTypeId", Value = (int)(model.TransactionBalanceType ?? TransactionBalanceType.None) });
			reportSource.Parameters.Add(new Parameter { Name = "agingCycleId", Value = (int)(model.AgingCycle ?? AgingCycle.NotSpecified) });
			reportSource.Parameters.Add(new Parameter { Name = "agingPeriodId", Value = model.AgingPeriodId ?? -1 });
			reportSource.Parameters.Add(new Parameter { Name = "classId", Value = model.ClassId ?? -1 });
			reportSource.Parameters.Add(new Parameter { Name = "debtorIds", Value = model.DebtorIds == null ? string.Empty : string.Join(",", model.DebtorIds) });

			switch (model.ReportSource) {
				case ReportSourceDebtor.TrialBalance:
					reportSource.Parameters.Add(new Parameter { Name = "customerName", Value = Utils.GetCustomerName(model.CustomerId, model.DefaultAgency) });
					reportSource.Parameters.Add(new Parameter { Name = "ledgerDocumentTypeId", Value = (int)model.LedgerDocumentType });
					break;
				case ReportSourceDebtor.DebtorStatements:
					reportSource.Parameters.Add(new Parameter { Name = "issuedDocumentType", Value = nameof(IssuedDocumentType.DebtorStatement) });
					break;
			}

			return reportSource;
		}

		public static string GetReportName(ReportSourceDebtor reportSource) {
			switch (reportSource) {
				default:
					throw new InvalidOperationException("Invalid Report Source.");
				case ReportSourceDebtor.TrialBalance:
					return "Debtor Account Trial Balance";
				case ReportSourceDebtor.DebtorStatements:
					return "Debtor Statements";
			}
		}

		public static string GetReportFileName(ReportSourceDebtor reportSource) {
			return WebUtility.HtmlDecode(GetReportName(reportSource));
		}
	}
}