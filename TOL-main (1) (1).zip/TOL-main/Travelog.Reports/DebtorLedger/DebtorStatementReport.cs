using System;
using Telerik.Reporting;
using Travelog.Biz.Resources;

namespace Travelog.Reports.DebtorLedger {
	public partial class DebtorStatementReport : TelerikReport {
		public DebtorStatementReport() {
			InitializeComponent();
		}

		private void TaxNo_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("{0}: {1}", Resource.TaxNoLabel, textBox.Value);
		}

		private void TaxLabel_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = Resource.TaxLabel;
		}

		private void TaxAppliesLabel_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("*{0} Applies", Resource.TaxLabel);
		}
	}
}