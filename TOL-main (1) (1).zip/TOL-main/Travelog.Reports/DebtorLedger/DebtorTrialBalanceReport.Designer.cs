namespace Travelog.Reports.DebtorLedger {
	partial class DebtorTrialBalanceReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.Drawing.FormattingRule formattingRule1 = new Telerik.Reporting.Drawing.FormattingRule();
			Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter11 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter12 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter13 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter14 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter15 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter16 = new Telerik.Reporting.ReportParameter();
			this.DocumentNoHeader = new Telerik.Reporting.TextBox();
			this.DocumentDateHeader = new Telerik.Reporting.TextBox();
			this.DocumentTypeHeader = new Telerik.Reporting.TextBox();
			this.DescriptionHeader = new Telerik.Reporting.TextBox();
			this.ReferenceHeader = new Telerik.Reporting.TextBox();
			this.AmountHeader = new Telerik.Reporting.TextBox();
			this.IsMatchHeader = new Telerik.Reporting.TextBox();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.TotalsLabel = new Telerik.Reporting.TextBox();
			this.BalancePeriod3Total = new Telerik.Reporting.TextBox();
			this.BalancePeriod2Total = new Telerik.Reporting.TextBox();
			this.BalancePeriod1Total = new Telerik.Reporting.TextBox();
			this.CurrentBalanceTotal = new Telerik.Reporting.TextBox();
			this.BalanceTotal = new Telerik.Reporting.TextBox();
			this.BalancePeriod3TotalPercent = new Telerik.Reporting.TextBox();
			this.BalancePeriod2TotalPercent = new Telerik.Reporting.TextBox();
			this.BalancePeriod1TotalPercent = new Telerik.Reporting.TextBox();
			this.CurrentBalanceTotalPercent = new Telerik.Reporting.TextBox();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.ManagementReportHeaderSubReport1 = new Telerik.Reporting.SubReport();
			this.CodeHeader = new Telerik.Reporting.TextBox();
			this.NameHeader = new Telerik.Reporting.TextBox();
			this.BalancePeriod3Header = new Telerik.Reporting.HtmlTextBox();
			this.BalancePeriod2Header = new Telerik.Reporting.HtmlTextBox();
			this.BalancePeriod1Header = new Telerik.Reporting.HtmlTextBox();
			this.BalanceCurrentHeader = new Telerik.Reporting.TextBox();
			this.BalanceHeader = new Telerik.Reporting.TextBox();
			this.CreditLimitHeader = new Telerik.Reporting.TextBox();
			this.NoData = new Telerik.Reporting.TextBox();
			this.GroupFooterSection2 = new Telerik.Reporting.GroupFooterSection();
			this.GroupHeaderSection2 = new Telerik.Reporting.GroupHeaderSection();
			this.NameField = new Telerik.Reporting.TextBox();
			this.Code = new Telerik.Reporting.TextBox();
			this.BalancePeriod3 = new Telerik.Reporting.TextBox();
			this.BalancePeriod2 = new Telerik.Reporting.TextBox();
			this.BalancePeriod1 = new Telerik.Reporting.TextBox();
			this.BalanceCurrent = new Telerik.Reporting.TextBox();
			this.Balance = new Telerik.Reporting.TextBox();
			this.CreditLimit = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.DetailTable = new Telerik.Reporting.Table();
			this.Description = new Telerik.Reporting.TextBox();
			this.DocumentNo = new Telerik.Reporting.TextBox();
			this.DocumentDate = new Telerik.Reporting.TextBox();
			this.DocumentType = new Telerik.Reporting.TextBox();
			this.Amount = new Telerik.Reporting.TextBox();
			this.Reference = new Telerik.Reporting.TextBox();
			this.IsMatched = new Telerik.Reporting.TextBox();
			this.TotalAmount = new Telerik.Reporting.TextBox();
			this.IsMatchedFooter = new Telerik.Reporting.TextBox();
			this.TotalAmountLabel = new Telerik.Reporting.TextBox();
			this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
			this.Pages = new Telerik.Reporting.TextBox();
			this.CreationTime = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// DocumentNoHeader
			// 
			this.DocumentNoHeader.Name = "DocumentNoHeader";
			this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNoHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentNoHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNoHeader.Style.Font.Bold = false;
			this.DocumentNoHeader.Style.Font.Name = "Calibri";
			this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentNoHeader.StyleName = "Normal.TableHeader";
			this.DocumentNoHeader.Value = "Document No";
			// 
			// DocumentDateHeader
			// 
			this.DocumentDateHeader.Name = "DocumentDateHeader";
			this.DocumentDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDateHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.DocumentDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDateHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentDateHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDateHeader.Style.Font.Bold = false;
			this.DocumentDateHeader.Style.Font.Name = "Calibri";
			this.DocumentDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDateHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDateHeader.StyleName = "Normal.TableHeader";
			this.DocumentDateHeader.Value = "Date";
			// 
			// DocumentTypeHeader
			// 
			this.DocumentTypeHeader.Name = "DocumentTypeHeader";
			this.DocumentTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentTypeHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.DocumentTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentTypeHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentTypeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentTypeHeader.Style.Font.Bold = false;
			this.DocumentTypeHeader.Style.Font.Name = "Calibri";
			this.DocumentTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentTypeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentTypeHeader.StyleName = "Normal.TableHeader";
			this.DocumentTypeHeader.Value = "Type";
			// 
			// DescriptionHeader
			// 
			this.DescriptionHeader.Name = "DescriptionHeader";
			this.DescriptionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DescriptionHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.DescriptionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DescriptionHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DescriptionHeader.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.DescriptionHeader.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.DescriptionHeader.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.DescriptionHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DescriptionHeader.Style.Font.Bold = false;
			this.DescriptionHeader.Style.Font.Name = "Calibri";
			this.DescriptionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DescriptionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DescriptionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DescriptionHeader.StyleName = "Normal.TableHeader";
			this.DescriptionHeader.Value = "Description";
			// 
			// ReferenceHeader
			// 
			this.ReferenceHeader.Name = "ReferenceHeader";
			this.ReferenceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReferenceHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.ReferenceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ReferenceHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ReferenceHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ReferenceHeader.Style.Font.Bold = false;
			this.ReferenceHeader.Style.Font.Name = "Calibri";
			this.ReferenceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ReferenceHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ReferenceHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ReferenceHeader.StyleName = "Normal.TableHeader";
			this.ReferenceHeader.Value = "Reference";
			// 
			// AmountHeader
			// 
			this.AmountHeader.Name = "AmountHeader";
			this.AmountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.AmountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AmountHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AmountHeader.Style.Font.Bold = false;
			this.AmountHeader.Style.Font.Name = "Calibri";
			this.AmountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AmountHeader.StyleName = "Normal.TableHeader";
			this.AmountHeader.Value = "Amount";
			// 
			// IsMatchHeader
			// 
			this.IsMatchHeader.Name = "IsMatchHeader";
			this.IsMatchHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.IsMatchHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.IsMatchHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.IsMatchHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.IsMatchHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.IsMatchHeader.Style.Font.Name = "Calibri";
			this.IsMatchHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.IsMatchHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.IsMatchHeader.StyleName = "Normal.TableHeader";
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.CanShrink = true;
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TotalsLabel,
            this.BalancePeriod3Total,
            this.BalancePeriod2Total,
            this.BalancePeriod1Total,
            this.CurrentBalanceTotal,
            this.BalanceTotal,
            this.BalancePeriod3TotalPercent,
            this.BalancePeriod2TotalPercent,
            this.BalancePeriod1TotalPercent,
            this.CurrentBalanceTotalPercent});
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			// 
			// TotalsLabel
			// 
			this.TotalsLabel.CanShrink = true;
			this.TotalsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TotalsLabel.Name = "TotalsLabel";
			this.TotalsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.TotalsLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalsLabel.Style.Font.Bold = true;
			this.TotalsLabel.Style.Font.Name = "Calibri";
			this.TotalsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalsLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TotalsLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalsLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalsLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TotalsLabel.StyleName = "Normal.TableBody";
			this.TotalsLabel.Value = "Totals";
			// 
			// BalancePeriod3Total
			// 
			this.BalancePeriod3Total.CanShrink = true;
			this.BalancePeriod3Total.Format = "{0:C2}";
			this.BalancePeriod3Total.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.BalancePeriod3Total.Name = "BalancePeriod3Total";
			this.BalancePeriod3Total.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BalancePeriod3Total.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod3Total.Style.Font.Bold = true;
			this.BalancePeriod3Total.Style.Font.Name = "Calibri";
			this.BalancePeriod3Total.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod3Total.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod3Total.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod3Total.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod3Total.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod3Total.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.BalancePeriod3Total.StyleName = "Normal.TableBody";
			this.BalancePeriod3Total.Value = "= Sum(Fields.BalancePeriod3)";
			// 
			// BalancePeriod2Total
			// 
			this.BalancePeriod2Total.CanShrink = true;
			this.BalancePeriod2Total.Format = "{0:C2}";
			this.BalancePeriod2Total.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.BalancePeriod2Total.Name = "BalancePeriod2Total";
			this.BalancePeriod2Total.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BalancePeriod2Total.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod2Total.Style.Font.Bold = true;
			this.BalancePeriod2Total.Style.Font.Name = "Calibri";
			this.BalancePeriod2Total.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod2Total.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod2Total.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod2Total.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod2Total.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod2Total.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.BalancePeriod2Total.StyleName = "Normal.TableBody";
			this.BalancePeriod2Total.Value = "= Sum(Fields.BalancePeriod2)";
			// 
			// BalancePeriod1Total
			// 
			this.BalancePeriod1Total.CanShrink = true;
			this.BalancePeriod1Total.Format = "{0:C2}";
			this.BalancePeriod1Total.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.BalancePeriod1Total.Name = "BalancePeriod1Total";
			this.BalancePeriod1Total.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BalancePeriod1Total.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod1Total.Style.Font.Bold = true;
			this.BalancePeriod1Total.Style.Font.Name = "Calibri";
			this.BalancePeriod1Total.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod1Total.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod1Total.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod1Total.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod1Total.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod1Total.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.BalancePeriod1Total.StyleName = "Normal.TableBody";
			this.BalancePeriod1Total.Value = "= Sum(Fields.BalancePeriod1)";
			// 
			// CurrentBalanceTotal
			// 
			this.CurrentBalanceTotal.CanShrink = true;
			this.CurrentBalanceTotal.Format = "{0:C2}";
			this.CurrentBalanceTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(21.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CurrentBalanceTotal.Name = "CurrentBalanceTotal";
			this.CurrentBalanceTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CurrentBalanceTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CurrentBalanceTotal.Style.Font.Bold = true;
			this.CurrentBalanceTotal.Style.Font.Name = "Calibri";
			this.CurrentBalanceTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CurrentBalanceTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CurrentBalanceTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CurrentBalanceTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CurrentBalanceTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CurrentBalanceTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CurrentBalanceTotal.StyleName = "Normal.TableBody";
			this.CurrentBalanceTotal.Value = "= Sum(Fields.BalanceCurrent)";
			// 
			// BalanceTotal
			// 
			this.BalanceTotal.CanShrink = true;
			this.BalanceTotal.Format = "{0:C2}";
			this.BalanceTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.6D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.BalanceTotal.Name = "BalanceTotal";
			this.BalanceTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BalanceTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalanceTotal.Style.Font.Bold = true;
			this.BalanceTotal.Style.Font.Name = "Calibri";
			this.BalanceTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalanceTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalanceTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalanceTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalanceTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalanceTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.BalanceTotal.StyleName = "Normal.TableBody";
			this.BalanceTotal.Value = "= Sum(Fields.Balance)";
			// 
			// BalancePeriod3TotalPercent
			// 
			this.BalancePeriod3TotalPercent.CanShrink = true;
			this.BalancePeriod3TotalPercent.Format = "{0:P3}";
			this.BalancePeriod3TotalPercent.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BalancePeriod3TotalPercent.Name = "BalancePeriod3TotalPercent";
			this.BalancePeriod3TotalPercent.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BalancePeriod3TotalPercent.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod3TotalPercent.Style.Font.Bold = true;
			this.BalancePeriod3TotalPercent.Style.Font.Name = "Calibri";
			this.BalancePeriod3TotalPercent.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod3TotalPercent.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod3TotalPercent.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod3TotalPercent.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod3TotalPercent.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod3TotalPercent.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.BalancePeriod3TotalPercent.StyleName = "Normal.TableBody";
			this.BalancePeriod3TotalPercent.Value = "= IIf(Sum(Fields.Balance) = 0, 0, Sum(Fields.BalancePeriod3) / IIf(Sum(Fields.Bal" +
    "ance) = 0, 1, Sum(Fields.Balance)))";
			// 
			// BalancePeriod2TotalPercent
			// 
			this.BalancePeriod2TotalPercent.CanShrink = true;
			this.BalancePeriod2TotalPercent.Format = "{0:P3}";
			this.BalancePeriod2TotalPercent.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BalancePeriod2TotalPercent.Name = "BalancePeriod2TotalPercent";
			this.BalancePeriod2TotalPercent.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BalancePeriod2TotalPercent.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod2TotalPercent.Style.Font.Bold = true;
			this.BalancePeriod2TotalPercent.Style.Font.Name = "Calibri";
			this.BalancePeriod2TotalPercent.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod2TotalPercent.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod2TotalPercent.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod2TotalPercent.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod2TotalPercent.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod2TotalPercent.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.BalancePeriod2TotalPercent.StyleName = "Normal.TableBody";
			this.BalancePeriod2TotalPercent.Value = "= IIf(Sum(Fields.Balance) = 0, 0, Sum(Fields.BalancePeriod2) / IIf(Sum(Fields.Bal" +
    "ance) = 0, 1, Sum(Fields.Balance)))";
			// 
			// BalancePeriod1TotalPercent
			// 
			this.BalancePeriod1TotalPercent.CanShrink = true;
			this.BalancePeriod1TotalPercent.Format = "{0:P3}";
			this.BalancePeriod1TotalPercent.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BalancePeriod1TotalPercent.Name = "BalancePeriod1TotalPercent";
			this.BalancePeriod1TotalPercent.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BalancePeriod1TotalPercent.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod1TotalPercent.Style.Font.Bold = true;
			this.BalancePeriod1TotalPercent.Style.Font.Name = "Calibri";
			this.BalancePeriod1TotalPercent.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod1TotalPercent.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod1TotalPercent.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod1TotalPercent.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod1TotalPercent.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod1TotalPercent.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.BalancePeriod1TotalPercent.StyleName = "Normal.TableBody";
			this.BalancePeriod1TotalPercent.Value = "= IIf(Sum(Fields.Balance) = 0, 0, Sum(Fields.BalancePeriod1) / IIf(Sum(Fields.Bal" +
    "ance) = 0, 1, Sum(Fields.Balance)))";
			// 
			// CurrentBalanceTotalPercent
			// 
			this.CurrentBalanceTotalPercent.CanShrink = true;
			this.CurrentBalanceTotalPercent.Format = "{0:P3}";
			this.CurrentBalanceTotalPercent.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(21.7D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CurrentBalanceTotalPercent.Name = "CurrentBalanceTotalPercent";
			this.CurrentBalanceTotalPercent.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CurrentBalanceTotalPercent.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CurrentBalanceTotalPercent.Style.Font.Bold = true;
			this.CurrentBalanceTotalPercent.Style.Font.Name = "Calibri";
			this.CurrentBalanceTotalPercent.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CurrentBalanceTotalPercent.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CurrentBalanceTotalPercent.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CurrentBalanceTotalPercent.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CurrentBalanceTotalPercent.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CurrentBalanceTotalPercent.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.CurrentBalanceTotalPercent.StyleName = "Normal.TableBody";
			this.CurrentBalanceTotalPercent.Value = "= IIf(Sum(Fields.Balance) = 0, 0, Sum(Fields.BalanceCurrent) / IIf(Sum(Fields.Bal" +
    "ance) = 0, 1, Sum(Fields.Balance)))";
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Count(1) = 0, \"None\", \"Solid\")"));
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(2.2D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ManagementReportHeaderSubReport1,
            this.CodeHeader,
            this.NameHeader,
            this.BalancePeriod3Header,
            this.BalancePeriod2Header,
            this.BalancePeriod1Header,
            this.BalanceCurrentHeader,
            this.BalanceHeader,
            this.CreditLimitHeader,
            this.NoData});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = true;
			this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupHeaderSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// ManagementReportHeaderSubReport1
			// 
			this.ManagementReportHeaderSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ManagementReportHeaderSubReport1.Name = "ManagementReportHeaderSubReport1";
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerName", "= Parameters.customerName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportName", "= Parameters.reportName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportDate", "= Parameters.reportDate.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("headerContent", "= Parameters.headerContent.Value"));
			typeReportSource1.TypeName = "Travelog.Reports.Common.ManagementReportHeaderSubReport1, Travelog.Reports, Versi" +
    "on=1.0.0.0, Culture=neutral, PublicKeyToken=null";
			this.ManagementReportHeaderSubReport1.ReportSource = typeReportSource1;
			this.ManagementReportHeaderSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.8D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ManagementReportHeaderSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// CodeHeader
			// 
			this.CodeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.CodeHeader.Name = "CodeHeader";
			this.CodeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CodeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CodeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CodeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CodeHeader.Style.Font.Bold = true;
			this.CodeHeader.Style.Font.Name = "Calibri";
			this.CodeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CodeHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CodeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CodeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CodeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CodeHeader.StyleName = "Normal.TableHeader";
			this.CodeHeader.Value = "\r\nCode";
			// 
			// NameHeader
			// 
			this.NameHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.NameHeader.Name = "NameHeader";
			this.NameHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NameHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.NameHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NameHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.NameHeader.Style.Font.Bold = true;
			this.NameHeader.Style.Font.Name = "Calibri";
			this.NameHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NameHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NameHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NameHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NameHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.NameHeader.StyleName = "Normal.TableHeader";
			this.NameHeader.Value = "\r\nName";
			// 
			// BalancePeriod3Header
			// 
			this.BalancePeriod3Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.BalancePeriod3Header.Name = "BalancePeriod3Header";
			this.BalancePeriod3Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod3Header.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.BalancePeriod3Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod3Header.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.BalancePeriod3Header.Style.Font.Bold = true;
			this.BalancePeriod3Header.Style.Font.Name = "Calibri";
			this.BalancePeriod3Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod3Header.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod3Header.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod3Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod3Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod3Header.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BalancePeriod3Header.StyleName = "Normal.TableHeader";
			this.BalancePeriod3Header.Value = "= IIf(Parameters.agingCycleId.Value=0, \"21 Day+\", IIf(Parameters.agingCycleId.Val" +
    "ue=1, \"42 Day+\", IIf(Parameters.agingCycleId.Value=2, \"90 Day+\", \"Period 3+\")))+" +
    "\"<br />Balance\"";
			// 
			// BalancePeriod2Header
			// 
			this.BalancePeriod2Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.9D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.BalancePeriod2Header.Name = "BalancePeriod2Header";
			this.BalancePeriod2Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod2Header.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.BalancePeriod2Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod2Header.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.BalancePeriod2Header.Style.Font.Bold = true;
			this.BalancePeriod2Header.Style.Font.Name = "Calibri";
			this.BalancePeriod2Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod2Header.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod2Header.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod2Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod2Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod2Header.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BalancePeriod2Header.StyleName = "Normal.TableHeader";
			this.BalancePeriod2Header.Value = "= IIf(Parameters.agingCycleId.Value=0, \"14 Day\", IIf(Parameters.agingCycleId.Valu" +
    "e=1, \"28 Day\", IIf(Parameters.agingCycleId.Value=2, \"60 Day\", \"Period 2\")))+\"<br" +
    " />Balance\"";
			// 
			// BalancePeriod1Header
			// 
			this.BalancePeriod1Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.8D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.BalancePeriod1Header.Name = "BalancePeriod1Header";
			this.BalancePeriod1Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod1Header.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.BalancePeriod1Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod1Header.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.BalancePeriod1Header.Style.Font.Bold = true;
			this.BalancePeriod1Header.Style.Font.Name = "Calibri";
			this.BalancePeriod1Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod1Header.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod1Header.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod1Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod1Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod1Header.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BalancePeriod1Header.StyleName = "Normal.TableHeader";
			this.BalancePeriod1Header.Value = "= IIf(Parameters.agingCycleId.Value=0, \"7 Day\", IIf(Parameters.agingCycleId.Value" +
    "=1, \"14 Day\", IIf(Parameters.agingCycleId.Value=2, \"30 Day\", \"Period 1\")))+\"<br " +
    "/>Balance\"";
			// 
			// BalanceCurrentHeader
			// 
			this.BalanceCurrentHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(21.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.BalanceCurrentHeader.Name = "BalanceCurrentHeader";
			this.BalanceCurrentHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalanceCurrentHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.BalanceCurrentHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalanceCurrentHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.BalanceCurrentHeader.Style.Font.Bold = true;
			this.BalanceCurrentHeader.Style.Font.Name = "Calibri";
			this.BalanceCurrentHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalanceCurrentHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalanceCurrentHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalanceCurrentHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalanceCurrentHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalanceCurrentHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BalanceCurrentHeader.StyleName = "Normal.TableHeader";
			this.BalanceCurrentHeader.Value = "Current\r\nBalance";
			// 
			// BalanceHeader
			// 
			this.BalanceHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.6D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.BalanceHeader.Name = "BalanceHeader";
			this.BalanceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalanceHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.BalanceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalanceHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.BalanceHeader.Style.Font.Bold = true;
			this.BalanceHeader.Style.Font.Name = "Calibri";
			this.BalanceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalanceHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalanceHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalanceHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalanceHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalanceHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.BalanceHeader.StyleName = "Normal.TableHeader";
			this.BalanceHeader.Value = "\r\nBalance";
			// 
			// CreditLimitHeader
			// 
			this.CreditLimitHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.CreditLimitHeader.Name = "CreditLimitHeader";
			this.CreditLimitHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditLimitHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CreditLimitHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditLimitHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CreditLimitHeader.Style.Font.Bold = true;
			this.CreditLimitHeader.Style.Font.Name = "Calibri";
			this.CreditLimitHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditLimitHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditLimitHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditLimitHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreditLimitHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditLimitHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreditLimitHeader.StyleName = "Normal.TableHeader";
			this.CreditLimitHeader.Value = "Credit\r\nLimit";
			// 
			// NoData
			// 
			formattingRule1.Filters.Add(new Telerik.Reporting.Filter("= Count(1)", Telerik.Reporting.FilterOperator.Equal, "0"));
			formattingRule1.Style.Visible = true;
			this.NoData.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule1});
			this.NoData.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.6D));
			this.NoData.Name = "NoData";
			this.NoData.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NoData.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.NoData.Style.BorderColor.Default = System.Drawing.Color.WhiteSmoke;
			this.NoData.Style.Font.Name = "Calibri";
			this.NoData.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NoData.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
			this.NoData.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.NoData.Style.Visible = false;
			this.NoData.StyleName = "Normal.TableHeader";
			this.NoData.Value = "NO DATA AVAILABLE";
			// 
			// GroupFooterSection2
			// 
			this.GroupFooterSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupFooterSection2.Name = "GroupFooterSection2";
			this.GroupFooterSection2.Style.Visible = false;
			// 
			// GroupHeaderSection2
			// 
			this.GroupHeaderSection2.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Parameters.ledgerDocumentTypeId.Value In (0, 2) Or Fields.TransactionDetail" +
            "ReportList.Count = 0, \"Solid\", \"None\")"));
			this.GroupHeaderSection2.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderWidth.Default", "= IIf(Parameters.ledgerDocumentTypeId.Value In (0, 2) Or Fields.TransactionDetail" +
            "ReportList.Count = 0, \"0.5pt\", \"0pt\")"));
			this.GroupHeaderSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupHeaderSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.NameField,
            this.Code,
            this.BalancePeriod3,
            this.BalancePeriod2,
            this.BalancePeriod1,
            this.BalanceCurrent,
            this.Balance,
            this.CreditLimit});
			this.GroupHeaderSection2.Name = "GroupHeaderSection2";
			this.GroupHeaderSection2.PrintOnEveryPage = true;
			this.GroupHeaderSection2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			// 
			// NameField
			// 
			this.NameField.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.NameField.Name = "NameField";
			this.NameField.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NameField.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NameField.Style.Font.Name = "Calibri";
			this.NameField.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NameField.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.NameField.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NameField.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NameField.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.NameField.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.NameField.StyleName = "Normal.TableBody";
			this.NameField.Value = "= Fields.Name";
			// 
			// Code
			// 
			this.Code.CanShrink = true;
			this.Code.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Code.Name = "Code";
			this.Code.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Code.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Code.Style.Font.Name = "Calibri";
			this.Code.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Code.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Code.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Code.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Code.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Code.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Code.StyleName = "Normal.TableBody";
			this.Code.Value = "= Fields.Code";
			// 
			// BalancePeriod3
			// 
			this.BalancePeriod3.Format = "{0:C2}";
			this.BalancePeriod3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.BalancePeriod3.Name = "BalancePeriod3";
			this.BalancePeriod3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod3.Style.Font.Name = "Calibri";
			this.BalancePeriod3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod3.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod3.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod3.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalancePeriod3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.BalancePeriod3.StyleName = "Normal.TableBody";
			this.BalancePeriod3.Value = "= Fields.BalancePeriod3";
			// 
			// BalancePeriod2
			// 
			this.BalancePeriod2.Format = "{0:C2}";
			this.BalancePeriod2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.BalancePeriod2.Name = "BalancePeriod2";
			this.BalancePeriod2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod2.Style.Font.Name = "Calibri";
			this.BalancePeriod2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod2.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod2.StyleName = "Normal.TableBody";
			this.BalancePeriod2.Value = "= Fields.BalancePeriod2";
			// 
			// BalancePeriod1
			// 
			this.BalancePeriod1.Format = "{0:C2}";
			this.BalancePeriod1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.BalancePeriod1.Name = "BalancePeriod1";
			this.BalancePeriod1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalancePeriod1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalancePeriod1.Style.Font.Name = "Calibri";
			this.BalancePeriod1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalancePeriod1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalancePeriod1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalancePeriod1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalancePeriod1.StyleName = "Normal.TableBody";
			this.BalancePeriod1.Value = "= Fields.BalancePeriod1";
			// 
			// BalanceCurrent
			// 
			this.BalanceCurrent.Format = "{0:C2}";
			this.BalanceCurrent.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(21.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.BalanceCurrent.Name = "BalanceCurrent";
			this.BalanceCurrent.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.BalanceCurrent.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalanceCurrent.Style.Font.Name = "Calibri";
			this.BalanceCurrent.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalanceCurrent.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalanceCurrent.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalanceCurrent.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalanceCurrent.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalanceCurrent.StyleName = "Normal.TableBody";
			this.BalanceCurrent.Value = "= Fields.BalanceCurrent";
			// 
			// Balance
			// 
			this.Balance.Format = "{0:C2}";
			this.Balance.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.6D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Balance.Name = "Balance";
			this.Balance.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Balance.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Balance.Style.Font.Name = "Calibri";
			this.Balance.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Balance.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Balance.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Balance.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Balance.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Balance.StyleName = "Normal.TableBody";
			this.Balance.Value = "= Fields.Balance";
			// 
			// CreditLimit
			// 
			this.CreditLimit.Format = "{0:C2}";
			this.CreditLimit.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CreditLimit.Name = "CreditLimit";
			this.CreditLimit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CreditLimit.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CreditLimit.Style.Font.Name = "Calibri";
			this.CreditLimit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreditLimit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditLimit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CreditLimit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.CreditLimit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.CreditLimit.StyleName = "Normal.TableBody";
			this.CreditLimit.Value = "= Fields.CreditLimit";
			// 
			// Detail
			// 
			this.Detail.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value In (0, 2) Or Fields.TransactionDetail" +
            "ReportList.Count = 0, False, True)"));
			this.Detail.CanShrink = true;
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(1.8D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailTable});
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// DetailTable
			// 
			this.DetailTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.TransactionDetailReportList"));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.7D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.6D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.2D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(9.4D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(5.8D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.8D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.3D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.SetCellContent(0, 3, this.Description);
			this.DetailTable.Body.SetCellContent(0, 0, this.DocumentNo);
			this.DetailTable.Body.SetCellContent(0, 1, this.DocumentDate);
			this.DetailTable.Body.SetCellContent(0, 2, this.DocumentType);
			this.DetailTable.Body.SetCellContent(0, 5, this.Amount);
			this.DetailTable.Body.SetCellContent(0, 4, this.Reference);
			this.DetailTable.Body.SetCellContent(0, 6, this.IsMatched);
			this.DetailTable.Body.SetCellContent(1, 5, this.TotalAmount);
			this.DetailTable.Body.SetCellContent(1, 6, this.IsMatchedFooter);
			this.DetailTable.Body.SetCellContent(1, 0, this.TotalAmountLabel, 1, 5);
			tableGroup1.Name = "tableGroup8";
			tableGroup1.ReportItem = this.DocumentNoHeader;
			tableGroup2.Name = "group";
			tableGroup2.ReportItem = this.DocumentDateHeader;
			tableGroup3.Name = "group1";
			tableGroup3.ReportItem = this.DocumentTypeHeader;
			tableGroup4.Name = "tableGroup9";
			tableGroup4.ReportItem = this.DescriptionHeader;
			tableGroup5.Name = "group3";
			tableGroup5.ReportItem = this.ReferenceHeader;
			tableGroup6.Name = "group2";
			tableGroup6.ReportItem = this.AmountHeader;
			tableGroup7.Name = "group4";
			tableGroup7.ReportItem = this.IsMatchHeader;
			this.DetailTable.ColumnGroups.Add(tableGroup1);
			this.DetailTable.ColumnGroups.Add(tableGroup2);
			this.DetailTable.ColumnGroups.Add(tableGroup3);
			this.DetailTable.ColumnGroups.Add(tableGroup4);
			this.DetailTable.ColumnGroups.Add(tableGroup5);
			this.DetailTable.ColumnGroups.Add(tableGroup6);
			this.DetailTable.ColumnGroups.Add(tableGroup7);
			this.DetailTable.ColumnHeadersPrintOnEveryPage = true;
			this.DetailTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DocumentNo,
            this.DocumentDate,
            this.DocumentType,
            this.Description,
            this.Reference,
            this.Amount,
            this.IsMatched,
            this.TotalAmountLabel,
            this.TotalAmount,
            this.IsMatchedFooter,
            this.DocumentNoHeader,
            this.DocumentDateHeader,
            this.DocumentTypeHeader,
            this.DescriptionHeader,
            this.ReferenceHeader,
            this.AmountHeader,
            this.IsMatchHeader});
			this.DetailTable.KeepTogether = false;
			this.DetailTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DetailTable.Name = "DetailTable";
			tableGroup8.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup8.Name = "detailTableGroup";
			tableGroup9.Name = "group5";
			this.DetailTable.RowGroups.Add(tableGroup8);
			this.DetailTable.RowGroups.Add(tableGroup9);
			this.DetailTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.8D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			// 
			// Description
			// 
			this.Description.CanGrow = false;
			this.Description.Format = "";
			this.Description.Name = "Description";
			this.Description.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Description.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Description.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Description.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.Description.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.Description.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.Description.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Description.Style.Font.Name = "Calibri";
			this.Description.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Description.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Description.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Description.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Description.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Description.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Description.StyleName = "Normal.TableBody";
			this.Description.Value = "= Fields.Description";
			// 
			// DocumentNo
			// 
			this.DocumentNo.CanGrow = false;
			this.DocumentNo.Format = "";
			this.DocumentNo.Name = "DocumentNo";
			this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNo.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentNo.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNo.Style.Font.Name = "Calibri";
			this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentNo.StyleName = "Normal.TableBody";
			this.DocumentNo.Value = "= Fields.DocumentNo";
			// 
			// DocumentDate
			// 
			this.DocumentDate.CanGrow = false;
			this.DocumentDate.Format = "{0:dd-MMM-yyyy}";
			this.DocumentDate.Name = "DocumentDate";
			this.DocumentDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDate.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentDate.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDate.Style.Font.Name = "Calibri";
			this.DocumentDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDate.StyleName = "Normal.TableBody";
			this.DocumentDate.Value = "= Fields.DocumentDate";
			// 
			// DocumentType
			// 
			this.DocumentType.CanGrow = false;
			this.DocumentType.Name = "DocumentType";
			this.DocumentType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentType.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentType.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentType.Style.Font.Name = "Calibri";
			this.DocumentType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentType.StyleName = "Normal.TableBody";
			this.DocumentType.Value = "= Fields.TransactionType";
			// 
			// Amount
			// 
			this.Amount.CanGrow = false;
			this.Amount.Format = "{0:c2}";
			this.Amount.Name = "Amount";
			this.Amount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Amount.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Amount.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Amount.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Amount.Style.Font.Name = "Calibri";
			this.Amount.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Amount.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Amount.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Amount.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Amount.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Amount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Amount.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Amount.StyleName = "Normal.TableBody";
			this.Amount.Value = "= Fields.AmountGross";
			// 
			// Reference
			// 
			this.Reference.CanGrow = false;
			this.Reference.Name = "Reference";
			this.Reference.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Reference.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Reference.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Reference.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Reference.Style.Font.Name = "Calibri";
			this.Reference.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Reference.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Reference.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Reference.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Reference.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Reference.StyleName = "Normal.TableBody";
			this.Reference.Value = "= Fields.Reference";
			// 
			// IsMatched
			// 
			this.IsMatched.CanGrow = false;
			this.IsMatched.Name = "IsMatched";
			this.IsMatched.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.IsMatched.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.IsMatched.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.IsMatched.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.IsMatched.Style.Font.Name = "Calibri";
			this.IsMatched.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.IsMatched.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.IsMatched.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.IsMatched.StyleName = "Normal.TableBody";
			this.IsMatched.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
			this.IsMatched.Value = "=IIf(Fields.IsMatched,\"*\",\"\")";
			// 
			// TotalAmount
			// 
			this.TotalAmount.Format = "{0:c2}";
			this.TotalAmount.Name = "TotalAmount";
			this.TotalAmount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalAmount.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.TotalAmount.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalAmount.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TotalAmount.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TotalAmount.Style.Font.Name = "Calibri";
			this.TotalAmount.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalAmount.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TotalAmount.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalAmount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalAmount.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalAmount.StyleName = "Normal.TableBody";
			this.TotalAmount.Value = "= Sum(Fields.AmountGross)";
			// 
			// IsMatchedFooter
			// 
			this.IsMatchedFooter.Name = "IsMatchedFooter";
			this.IsMatchedFooter.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.IsMatchedFooter.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.IsMatchedFooter.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.IsMatchedFooter.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.IsMatchedFooter.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.IsMatchedFooter.Style.Font.Name = "Calibri";
			this.IsMatchedFooter.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.IsMatchedFooter.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.IsMatchedFooter.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.IsMatchedFooter.StyleName = "Normal.TableBody";
			// 
			// TotalAmountLabel
			// 
			this.TotalAmountLabel.Name = "TotalAmountLabel";
			this.TotalAmountLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalAmountLabel.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.TotalAmountLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalAmountLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TotalAmountLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TotalAmountLabel.Style.Font.Name = "Calibri";
			this.TotalAmountLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalAmountLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalAmountLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalAmountLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalAmountLabel.StyleName = "Normal.TableBody";
			this.TotalAmountLabel.Value = "Total";
			// 
			// PageFooterSection
			// 
			this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
			this.PageFooterSection.Name = "PageFooter";
			// 
			// Pages
			// 
			this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.7D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Name = "Pages";
			this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Style.Color = System.Drawing.Color.DarkGray;
			this.Pages.Style.Font.Name = "Calibri";
			this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Pages.Value = "= \"Page \" + PageNumber";
			// 
			// CreationTime
			// 
			this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Name = "CreationTime";
			this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
			this.CreationTime.Style.Font.Name = "Calibri";
			this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy HH:mm}\", Parame" +
    "ters.creationTime.Value)";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "DebtorTrialBalanceReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.DebtorLedger.DebtorLedgerDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("reportDate", typeof(System.DateTime), "= Parameters.reportDate.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("reportOrderId", typeof(int), "= Parameters.reportOrderId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("matchedTxnsReportOptionId", typeof(int), "= Parameters.matchedTxnsReportOptionId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("ledgerDocumentTypeId", typeof(int), "= Parameters.ledgerDocumentTypeId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("transactionBalanceTypeId", typeof(int), "= Parameters.transactionBalanceTypeId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agingCycleId", typeof(int), "= Parameters.agingCycleId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agingPeriodId", typeof(int), "= Parameters.agingPeriodId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("classId", typeof(int), "= Parameters.classId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("debtorIds", typeof(string), "= Parameters.debtorIds.Value"));
			// 
			// DebtorTrialBalanceReport
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			group2.GroupFooter = this.GroupFooterSection2;
			group2.GroupHeader = this.GroupHeaderSection2;
			group2.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.DebtorId"));
			group2.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group2.Name = "Group2";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.GroupHeaderSection2,
            this.GroupFooterSection2,
            this.Detail,
            this.PageFooterSection});
			this.Name = "DebtorTrialBalanceReport";
			this.PageSettings.Landscape = true;
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(0.95D), Telerik.Reporting.Drawing.Unit.Cm(0.95D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "customerId";
			reportParameter2.Name = "agencyId";
			reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter3.Name = "customerName";
			reportParameter4.Name = "reportName";
			reportParameter5.Name = "headerContent";
			reportParameter6.Name = "creationUser";
			reportParameter7.Name = "creationTime";
			reportParameter7.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter8.Name = "reportDate";
			reportParameter9.Name = "reportOrderId";
			reportParameter9.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter10.Name = "matchedTxnsReportOptionId";
			reportParameter10.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter11.Name = "ledgerDocumentTypeId";
			reportParameter11.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter12.Name = "transactionBalanceTypeId";
			reportParameter12.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter13.Name = "agingCycleId";
			reportParameter13.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter14.Name = "agingPeriodId";
			reportParameter14.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter15.Name = "classId";
			reportParameter15.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter16.Name = "debtorIds";
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.ReportParameters.Add(reportParameter9);
			this.ReportParameters.Add(reportParameter10);
			this.ReportParameters.Add(reportParameter11);
			this.ReportParameters.Add(reportParameter12);
			this.ReportParameters.Add(reportParameter13);
			this.ReportParameters.Add(reportParameter14);
			this.ReportParameters.Add(reportParameter15);
			this.ReportParameters.Add(reportParameter16);
			this.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Style.Font.Name = "Calibri";
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(27.8D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.SubReport ManagementReportHeaderSubReport1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.TextBox TotalsLabel;
		private Telerik.Reporting.TextBox BalancePeriod3Total;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.TextBox CodeHeader;
		private Telerik.Reporting.TextBox NameHeader;
		private Telerik.Reporting.HtmlTextBox BalancePeriod3Header;
		private Telerik.Reporting.HtmlTextBox BalancePeriod2Header;
		private Telerik.Reporting.HtmlTextBox BalancePeriod1Header;
		private Telerik.Reporting.TextBox BalanceCurrentHeader;
		private Telerik.Reporting.TextBox BalanceHeader;
		private Telerik.Reporting.TextBox Code;
		private Telerik.Reporting.TextBox NameField;
		private Telerik.Reporting.TextBox BalancePeriod3;
		private Telerik.Reporting.TextBox BalancePeriod2;
		private Telerik.Reporting.TextBox BalancePeriod1;
		private Telerik.Reporting.TextBox BalanceCurrent;
		private Telerik.Reporting.TextBox Balance;
		private Telerik.Reporting.TextBox BalancePeriod2Total;
		private Telerik.Reporting.TextBox BalancePeriod1Total;
		private Telerik.Reporting.TextBox CurrentBalanceTotal;
		private Telerik.Reporting.TextBox BalanceTotal;
		private Telerik.Reporting.TextBox BalancePeriod3TotalPercent;
		private Telerik.Reporting.TextBox BalancePeriod2TotalPercent;
		private Telerik.Reporting.TextBox BalancePeriod1TotalPercent;
		private Telerik.Reporting.TextBox CurrentBalanceTotalPercent;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection2;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection2;
		private Telerik.Reporting.Table DetailTable;
		private Telerik.Reporting.TextBox Description;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox DocumentDate;
		private Telerik.Reporting.TextBox DocumentType;
		private Telerik.Reporting.TextBox DocumentDateHeader;
		private Telerik.Reporting.TextBox DocumentTypeHeader;
		private Telerik.Reporting.TextBox DescriptionHeader;
		private Telerik.Reporting.TextBox AmountHeader;
		private Telerik.Reporting.TextBox Reference;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox ReferenceHeader;
		private Telerik.Reporting.TextBox Amount;
		private Telerik.Reporting.TextBox IsMatched;
		private Telerik.Reporting.TextBox IsMatchHeader;
		private Telerik.Reporting.TextBox TotalAmountLabel;
		private Telerik.Reporting.TextBox TotalAmount;
		private Telerik.Reporting.TextBox IsMatchedFooter;
		private Telerik.Reporting.TextBox CreditLimitHeader;
		private Telerik.Reporting.TextBox CreditLimit;
		private Telerik.Reporting.TextBox NoData;
	}
}