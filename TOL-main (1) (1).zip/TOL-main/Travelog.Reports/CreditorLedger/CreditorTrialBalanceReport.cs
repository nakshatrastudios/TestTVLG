using Telerik.Reporting;

namespace Travelog.Reports.CreditorLedger {

	public partial class CreditorTrialBalanceReport : TelerikReport {
		public CreditorTrialBalanceReport() {
			InitializeComponent();
		}
	}
}