﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;

namespace Travelog.Reports.CreditorLedger {
    public class CreditorLedgerDataSources {
		private const string ClassName = "Travelog.Reports.CreditorLedger.CreditorLedgerDataSources";

		public List<CreditorTrialBalanceReportModel> CreditorTrialBalanceReport(int customerId, DateTime reportDate, int matchedTxnsReportOptionId, int paidStatusReportOptionId, int ledgerDocumentTypeId, int transactionBalanceTypeId, int agingCycleId, int agingPeriodId, int classId, int agencyId, int ledgerReportTypeId, DateTime? dateFrom, DateTime? dateTo, int? transactionTypeId, string creditorIds) {
			try {
				using (var lazyContext = new AppLazyContext(customerId, true)) {
					var matchedTxnsReportOption = (MatchedTxnsReportOption)matchedTxnsReportOptionId;
					var paidStatusReportOption = (PaidStatusReportOption)paidStatusReportOptionId;
					var agingCycle = (AgingCycle)agingCycleId;
					var transactionBalanceType = (TransactionBalanceType)transactionBalanceTypeId;
					var ledgerDocumentType = (LedgerDocumentType)ledgerDocumentTypeId;
					var ledgerReportType = (LedgerReportType)ledgerReportTypeId;

					var transactionType = TransactionType.All;

					if (transactionTypeId != null)
						transactionType = (TransactionType)transactionTypeId;

					int[] creditorIdList = null;

					if (!string.IsNullOrEmpty(creditorIds))
						creditorIdList = creditorIds.Split(',').Select(int.Parse).ToArray();

					var q = Creditor.GetCreditorLedgerReportQuery(lazyContext, agencyId, agingCycle, reportDate, ledgerDocumentType, paidStatusReportOption, ledgerReportType, dateFrom, dateTo, transactionType, classId, creditorIdList, reportDate);

					if (transactionBalanceType == TransactionBalanceType.NonZero) {
						q = q.Where(t => t.BalancePeriod1 != 0 || t.BalancePeriod2 != 0 || t.BalancePeriod3 != 0 || t.BalanceCurrent != 0 || t.Balance != 0);
					}
					else if (agingPeriodId != -1) {
						if (agingPeriodId == 0) {
							q = q.Where(t => t.BalancePeriod1 != 0 || t.BalancePeriod2 != 0 || t.BalancePeriod3 != 0);
						}
						else if (agingPeriodId == 1) {
							q = q.Where(t => t.BalancePeriod2 != 0 || t.BalancePeriod3 != 0);
						}
						else if (agingPeriodId == 2) {
							q = q.Where(t => t.BalancePeriod3 != 0);
						}
					}

					return q.ToList().ConvertAll(row => new CreditorTrialBalanceReportModel {
						CreditorId = row.Creditor.Id,
						Name = row.Creditor.Name,
						CreditLimit = row.Creditor.CreditLimit,
						BalancePeriod1 = row.BalancePeriod1,
						BalancePeriod2 = row.BalancePeriod2,
						BalancePeriod3 = row.BalancePeriod3,
						BalanceCurrent = row.BalanceCurrent,
						Balance = row.Balance,
						TransactionDetailReportList = ledgerDocumentType == LedgerDocumentType.Standard || ledgerDocumentType == LedgerDocumentType.Reconciliation ? new List<TransactionDetailReportModel>()
						: ledgerReportType == LedgerReportType.TrialBalance ? Creditor.GetCreditorLedgerTransactionReportQuery(row, transactionType, matchedTxnsReportOption, reportDate, ledgerDocumentType)
						: row.BspAccrualTransactionDetail.ConvertAll(t => new TransactionDetailReportModel {
							TransactionType = t.Transaction.TransactionType.GetEnumDescription(),
							DocumentNo = t.Transaction.DocumentNo,
							DocumentDate = t.Transaction.DocumentDate,
							Description = t.Description,
							Reference = t.Reference,
							AmountGross = t.Amount + t.Tax,
							IsMatched = t.IsMatched
						})
					});
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "CreditorTrialBalanceReport", ex, customerId);
				return new List<CreditorTrialBalanceReportModel>();
			}
		}

		public static TypeReportSource GetReportSource(AppMainContext context, CreditorReportSourceModel model) {
			string typeName;
			string reportName;

			var ledgerReportType = LedgerReportType.TrialBalance;

			if (model.ReportSource == ReportSourceCreditor.BspReturns)
				ledgerReportType = LedgerReportType.BspReturn;

			var sb = new StringBuilder();

			switch (model.ReportSource) {
				default:
					throw new InvalidOperationException("Invalid Report Source.");
				case ReportSourceCreditor.TrialBalance:
				case ReportSourceCreditor.BspReturns:
					reportName = string.Format("{0} {1}", GetReportName(model.ReportSource), (model.LedgerDocumentType ?? LedgerDocumentType.Standard).GetEnumDescription());
					typeName = typeof(CreditorTrialBalanceReport).AssemblyQualifiedName;
					sb.AppendFormat("Agency: {0}", (model.AgencyId ?? 0) <= 0 ? "All Agencies" : context.Agency.Find(model.AgencyId).Name);
					sb.AppendFormat(" | Matched Txns: {0}", (model.MatchedTxnsReportOption ?? MatchedTxnsReportOption.ExcludeAll).GetEnumDescription());
					sb.AppendFormat(" | Balances: {0}", (model.TransactionBalanceType ?? TransactionBalanceType.None) == TransactionBalanceType.NonZero ? "Non-Zero" : "All Balances");
					sb.AppendFormat(" | Aging Cycle: {0}", (model.AgingCycle ?? AgingCycle.NotSpecified) == AgingCycle.NotSpecified ? "All Aging Cycles" : model.AgingCycle.GetEnumDescription());
					sb.AppendFormat(" | Periods: {0}", model.AgingPeriodId == 0 ? "Period 1 & Above" : model.AgingPeriodId == 1 ? "Period 2 & Above" : model.AgingPeriodId == 2 ? "Period 3 & Above" : "All Periods");
					sb.AppendFormat("{0}Transaction Type: {1}", AppConstants.HtmlLineBreak, (model.TransactionType ?? TransactionType.All) == TransactionType.All ? "All Transaction Types" : model.TransactionType.GetEnumDescription());
					sb.AppendFormat(" | Class: {0}", (model.ClassId ?? -1) == -1 ? "All Classes" : context.Class.Find(model.ClassId).Name);
					break;
			}

			switch (model.ReportSource) {
				case ReportSourceCreditor.BspReturns:
					string description = string.Format("Paid Status: {0} | Document Date:", (model.PaidStatusReportOption ?? PaidStatusReportOption.All).GetEnumDescription());

					if (model.DateFrom == null && model.DateTo == null) {
						description = string.Format("{0} All Dates", description);
					}
					else if (model.DateTo == null) {
						description = string.Format("{0} From {1:dd-MMM-yyyy}", description, model.DateFrom);
					}
					else if (model.DateFrom == null) {
						description = string.Format("{0} To {1:dd-MMM-yyyy}", description, model.DateTo);
					}
					else {
						description = string.Format("{0} From {1:dd-MMM-yyyy} To {2:dd-MMM-yyyy}", description, model.DateFrom, model.DateTo);
					}

					sb.AppendFormat("{0}{1}", AppConstants.HtmlLineBreak, description);
					break;
			}

			var reportSource = new TypeReportSource {
				TypeName = typeName
			};

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = model.CustomerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = model.AgencyId ?? -1 });
			reportSource.Parameters.Add(new Parameter { Name = "customerName", Value = Utils.GetCustomerName(model.CustomerId, model.DefaultAgency) });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = model.CreationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = model.CreationTime });
			reportSource.Parameters.Add(new Parameter { Name = "reportName", Value = reportName });
			reportSource.Parameters.Add(new Parameter { Name = "reportDate", Value = (model.ReportDate ?? DateTime.MinValue).ToShortDateStringExt() });
			reportSource.Parameters.Add(new Parameter { Name = "headerContent", Value = Utils.HtmlEncodeExceptTags(sb.ToString()) });
			reportSource.Parameters.Add(new Parameter { Name = "ledgerDocumentTypeId", Value = (int)(model.LedgerDocumentType ?? LedgerDocumentType.Standard) });
			reportSource.Parameters.Add(new Parameter { Name = "matchedTxnsReportOptionId", Value = (int)(model.MatchedTxnsReportOption ?? MatchedTxnsReportOption.ExcludeAll) });
			reportSource.Parameters.Add(new Parameter { Name = "paidStatusReportOptionId", Value = (int)(model.PaidStatusReportOption ?? PaidStatusReportOption.All) });
			reportSource.Parameters.Add(new Parameter { Name = "transactionBalanceTypeId", Value = (int)(model.TransactionBalanceType ?? TransactionBalanceType.None) });
			reportSource.Parameters.Add(new Parameter { Name = "agingCycleId", Value = (int)(model.AgingCycle ?? AgingCycle.NotSpecified) });
			reportSource.Parameters.Add(new Parameter { Name = "agingPeriodId", Value = model.AgingPeriodId ?? -1 });
			reportSource.Parameters.Add(new Parameter { Name = "classId", Value = model.ClassId ?? -1 });
			reportSource.Parameters.Add(new Parameter { Name = "ledgerReportTypeId", Value = (int)ledgerReportType });
			reportSource.Parameters.Add(new Parameter { Name = "dateFrom", Value = model.DateFrom });
			reportSource.Parameters.Add(new Parameter { Name = "dateTo", Value = model.DateTo });
			reportSource.Parameters.Add(new Parameter { Name = "transactionTypeId", Value = (int)(model.TransactionType ?? TransactionType.All) });
			reportSource.Parameters.Add(new Parameter { Name = "creditorIds", Value = model.CreditorIds == null ? string.Empty : string.Join(",", model.CreditorIds) });

			return reportSource;
		}

		public static string GetReportName(ReportSourceCreditor reportSource) {
			switch (reportSource) {
				default:
					throw new InvalidOperationException("Invalid Report Source.");
				case ReportSourceCreditor.TrialBalance:
					return "Creditor Account Trial Balance";
				case ReportSourceCreditor.BspReturns:
					return "BSP Returns";
			}
		}

		public static string GetReportFileName(ReportSourceCreditor reportSource) {
			return WebUtility.HtmlDecode(GetReportName(reportSource));
		}
	}
}