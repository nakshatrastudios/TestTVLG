using System;
using Telerik.Reporting;
using Travelog.Biz.Resources;

namespace Travelog.Reports.ClientLedger {
	public partial class QuoteSubReport : TelerikReport {
		public QuoteSubReport() {
			InitializeComponent();
		}

		private void TaxTotal1_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("Total {0} Included", Resource.TaxLabel);
		}
	}
}