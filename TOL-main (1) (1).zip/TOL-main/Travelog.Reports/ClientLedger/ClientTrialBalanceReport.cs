using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Telerik.Reporting;
using Telerik.Reporting.Drawing;
using Travelog.Biz;
using Travelog.Biz.Models;

namespace Travelog.Reports.ClientLedger {
	public partial class ClientTrialBalanceReport : TelerikReport {
		public ClientTrialBalanceReport() {
			InitializeComponent();
			ItemDataBinding += Report_ItemDataBinding;
		}

		private void Report_ItemDataBinding(object sender, EventArgs e) {
			var report = sender as Telerik.Reporting.Processing.Report;
			var parameters = report.Parameters;
			var groupList = new List<ReportGroupModel>();

			if (parameters["groupByAgency"].Value.ToBool())
				groupList.Add(new ReportGroupModel { Name = "Agency", Level = parameters["agencyLevel"].Value.ToInt(), NewPage = parameters["agencyNewPage"].Value.ToBool() });

			if (parameters["groupByAgent"].Value.ToBool())
				groupList.Add(new ReportGroupModel { Name = "Agent", Level = parameters["agentLevel"].Value.ToInt(), NewPage = parameters["agentNewPage"].Value.ToBool() });

			if (parameters["groupByCategory"].Value.ToBool())
				groupList.Add(new ReportGroupModel { Name = "Category", Level = parameters["categoryLevel"].Value.ToInt(), NewPage = parameters["categoryNewPage"].Value.ToBool() });

			if (parameters["groupByClass"].Value.ToBool())
				groupList.Add(new ReportGroupModel { Name = "Class", Level = parameters["classLevel"].Value.ToInt(), NewPage = parameters["classNewPage"].Value.ToBool() });

			if (parameters["groupByConsultant"].Value.ToBool())
				groupList.Add(new ReportGroupModel { Name = "Consultant", Level = parameters["consultantLevel"].Value.ToInt(), NewPage = parameters["consultantNewPage"].Value.ToBool() });

			if (parameters["groupByDebtor"].Value.ToBool())
				groupList.Add(new ReportGroupModel { Name = "Debtor", Level = parameters["debtorLevel"].Value.ToInt(), NewPage = parameters["debtorNewPage"].Value.ToBool() });

			if (parameters["groupByDestination"].Value.ToBool())
				groupList.Add(new ReportGroupModel { Name = "Destination", Level = parameters["destinationLevel"].Value.ToInt(), NewPage = parameters["destinationNewPage"].Value.ToBool() });

			if (parameters["groupByGroup"].Value.ToBool())
				groupList.Add(new ReportGroupModel { Name = "Group", Level = parameters["groupLevel"].Value.ToInt(), NewPage = parameters["groupNewPage"].Value.ToBool() });

			if (parameters["groupByLocation"].Value.ToBool())
				groupList.Add(new ReportGroupModel { Name = "Location", Level = parameters["locationLevel"].Value.ToInt(), NewPage = parameters["locationNewPage"].Value.ToBool() });

			if (parameters["groupBySource"].Value.ToBool())
				groupList.Add(new ReportGroupModel { Name = "Source", Level = parameters["sourceLevel"].Value.ToInt(), NewPage = parameters["sourceNewPage"].Value.ToBool() });

			foreach (var item in groupList.OrderByDescending(t => t.Level)) {
				var group = new Group {
					Name = string.Format("{0}Group", item.Name),
					GroupKeepTogether = GroupKeepTogether.FirstDetail,
					GroupHeader = new GroupHeaderSection {
						Name = string.Format("{0}GroupHeader", item.Name),
						Height = Unit.Cm(0.6),
						PageBreak = item.NewPage ? PageBreak.Before : PageBreak.None,
						PrintOnEveryPage = true
					},
					GroupFooter = new GroupFooterSection {
						Name = string.Format("{0}GroupFooter", item.Name),
						Height = Unit.Cm(0.6),
						PageBreak = item.NewPage ? PageBreak.After : PageBreak.None
					}
				};

				group.GroupHeader.Bindings.Add(new Binding { Path = "Visible", Expression = string.Format(@"=IIf(Fields.{0}Id <= 0, False, True)", item.Name) });
				group.GroupFooter.Bindings.Add(new Binding { Path = "Visible", Expression = string.Format(@"=IIf(Fields.{0}Id <= 0, False, True)", item.Name) });

				group.Groupings.Add(new Grouping(string.Format("=Fields.{0}Id", item.Name)));
				group.Sortings.Add(new Sorting(string.Format("=Fields.{0}", item.Name), SortDirection.Asc));

				var textBox = new TextBox {
					Name = string.Format("{0}Header", item.Name),
					Location = new PointU(new Unit(0, UnitType.Cm), new Unit(0, UnitType.Cm)),
					Size = new SizeU(new Unit(27.7, UnitType.Cm), new Unit(0.6, UnitType.Cm)),
					Value = string.Format(@"=""{0}: "" + Fields.{0}", item.Name)
				};

				textBox.Style.Font.Name = "Calibri";
				textBox.Style.Font.Size = Unit.Point(10);

				textBox.Style.BackgroundColor = Color.WhiteSmoke;
				textBox.Style.Padding.Top = Unit.Cm(0.05);
				textBox.Style.Padding.Bottom = Unit.Cm(0.05);

				group.GroupHeader.Items.Add(textBox);

				textBox = new TextBox {
					Name = string.Format("{0}FooterLabel", item.Name),
					Location = new PointU(new Unit(0, UnitType.Cm), new Unit(0, UnitType.Cm)),
					Size = new SizeU(new Unit(9.1, UnitType.Cm), new Unit(0.6, UnitType.Cm)),
					Value = string.Format(@"=""Totals for {0}: "" + Fields.{0}", item.Name),
				};

				textBox.Style.Font.Name = "Calibri";
				textBox.Style.Font.Size = Unit.Point(10);
				textBox.Style.BackgroundColor = Color.WhiteSmoke;

				textBox.Style.Padding.Top = Unit.Cm(0.05);
				textBox.Style.Padding.Bottom = Unit.Cm(0.05);

				group.GroupFooter.Items.Add(textBox);

				textBox = new TextBox {
					Name = string.Format("{0}CommissionGroupTotal", item.Name),
					Location = new PointU(new Unit(9.1, UnitType.Cm), new Unit(0, UnitType.Cm)),
					Size = new SizeU(new Unit(5.4, UnitType.Cm), new Unit(0.6, UnitType.Cm)),
					Value = "=Sum(Fields.Commission)"
				};

				textBox.Style.Font.Name = "Calibri";
				textBox.Style.Font.Size = Unit.Point(10);
				textBox.Style.TextAlign = HorizontalAlign.Right;
				textBox.Style.BackgroundColor = Color.WhiteSmoke;
				textBox.Style.Padding.Right = Unit.Cm(1);
				textBox.Format = "Commission: {0:c2}";

				group.GroupFooter.Items.Add(textBox);

				textBox = new TextBox {
					Name = string.Format("{0}GrossGroupTotal", item.Name),
					Location = new PointU(new Unit(14.5, UnitType.Cm), new Unit(0, UnitType.Cm)),
					Size = new SizeU(new Unit(5.4, UnitType.Cm), new Unit(0.6, UnitType.Cm)),
					Value = "=Sum(Fields.AmountGross)"
				};

				textBox.Style.Font.Name = "Calibri";
				textBox.Style.Font.Size = Unit.Point(10);
				textBox.Style.TextAlign = HorizontalAlign.Right;
				textBox.Style.BackgroundColor = Color.WhiteSmoke;
				textBox.Style.Padding.Right = Unit.Cm(1);
				textBox.Format = "Gross: {0:c2}";

				group.GroupFooter.Items.Add(textBox);

				textBox = new TextBox {
					Name = string.Format("{0}DebitTotal", item.Name),
					Location = new PointU(new Unit(19.9, UnitType.Cm), new Unit(0, UnitType.Cm)),
					Size = new SizeU(new Unit(2.6, UnitType.Cm), new Unit(0.6, UnitType.Cm)),
					Value = "=Sum(Fields.Debit)"
				};

				textBox.Style.Font.Name = "Calibri";
				textBox.Style.Font.Size = Unit.Point(10);
				textBox.Style.BackgroundColor = Color.WhiteSmoke;
				textBox.Format = "{0:c2}";

				textBox.Style.Padding.Top = Unit.Cm(0.05);
				textBox.Style.Padding.Bottom = Unit.Cm(0.05);
				textBox.Style.TextAlign = HorizontalAlign.Right;

				group.GroupFooter.Items.Add(textBox);

				textBox = new TextBox {
					Name = string.Format("{0}CreditTotal", item.Name),
					Location = new PointU(new Unit(22.5, UnitType.Cm), new Unit(0, UnitType.Cm)),
					Size = new SizeU(new Unit(2.6, UnitType.Cm), new Unit(0.6, UnitType.Cm)),
					Value = "=Sum(Fields.Credit)"
				};

				textBox.Style.Font.Name = "Calibri";
				textBox.Style.Font.Size = Unit.Point(10);
				textBox.Style.BackgroundColor = Color.WhiteSmoke;
				textBox.Format = "{0:c2}";

				textBox.Style.Padding.Top = Unit.Cm(0.05);
				textBox.Style.Padding.Bottom = Unit.Cm(0.05);
				textBox.Style.TextAlign = HorizontalAlign.Right;

				group.GroupFooter.Items.Add(textBox);

				textBox = new TextBox {
					Name = string.Format("{0}BalanceTotal", item.Name),
					Location = new PointU(new Unit(25.1, UnitType.Cm), new Unit(0, UnitType.Cm)),
					Size = new SizeU(new Unit(2.6, UnitType.Cm), new Unit(0.6, UnitType.Cm)),
					Value = "=Sum(Fields.Balance)"
				};

				textBox.Style.Font.Name = "Calibri";
				textBox.Style.Font.Size = Unit.Point(10);
				textBox.Style.BackgroundColor = Color.WhiteSmoke;
				textBox.Format = "{0:c2}";

				textBox.Style.Padding.Top = Unit.Cm(0.05);
				textBox.Style.Padding.Bottom = Unit.Cm(0.05);
				textBox.Style.TextAlign = HorizontalAlign.Right;

				group.GroupFooter.Items.Add(textBox);
				Groups.Insert(1, group);
			}
		}
	}
}