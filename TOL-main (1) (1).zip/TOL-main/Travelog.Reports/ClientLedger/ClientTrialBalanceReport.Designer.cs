namespace Travelog.Reports.ClientLedger {
	partial class ClientTrialBalanceReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
            Telerik.Reporting.Drawing.FormattingRule formattingRule1 = new Telerik.Reporting.Drawing.FormattingRule();
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup10 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
            Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
            Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter11 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter12 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter13 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter14 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter15 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter16 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter17 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter18 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter19 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter20 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter21 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter22 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter23 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter24 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter25 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter26 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter27 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter28 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter29 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter30 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter31 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter32 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter33 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter34 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter35 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter36 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter37 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter38 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter39 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter40 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter41 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter42 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter43 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter44 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter45 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter46 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter47 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter48 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter49 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter50 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter51 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter52 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter53 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter54 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter55 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter56 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter57 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter58 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter59 = new Telerik.Reporting.ReportParameter();
            this.DocumentNoHeader = new Telerik.Reporting.TextBox();
            this.DocumentDateHeader = new Telerik.Reporting.TextBox();
            this.DocumentTypeHeader = new Telerik.Reporting.TextBox();
            this.DescriptionHeader = new Telerik.Reporting.TextBox();
            this.ReferenceHeader = new Telerik.Reporting.TextBox();
            this.CommissionHeader = new Telerik.Reporting.TextBox();
            this.AmountGrossHeader = new Telerik.Reporting.TextBox();
            this.BalanceDetailHeader = new Telerik.Reporting.TextBox();
            this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
            this.TotalsLabel = new Telerik.Reporting.TextBox();
            this.BalanceTotal = new Telerik.Reporting.TextBox();
            this.CreditTotal = new Telerik.Reporting.TextBox();
            this.DebitTotal = new Telerik.Reporting.TextBox();
            this.CommissionTotal = new Telerik.Reporting.TextBox();
            this.textBox1 = new Telerik.Reporting.TextBox();
            this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
            this.ManagementReportHeaderSubReport1 = new Telerik.Reporting.SubReport();
            this.TripNoHeader = new Telerik.Reporting.TextBox();
            this.FullNameHeader = new Telerik.Reporting.TextBox();
            this.DepartureDateHeader = new Telerik.Reporting.TextBox();
            this.SourceHeader = new Telerik.Reporting.TextBox();
            this.BalanceHeader = new Telerik.Reporting.TextBox();
            this.CategoryHeader = new Telerik.Reporting.TextBox();
            this.ConsultantHeader = new Telerik.Reporting.TextBox();
            this.CreditHeader = new Telerik.Reporting.TextBox();
            this.DebitHeader = new Telerik.Reporting.TextBox();
            this.NoData = new Telerik.Reporting.TextBox();
            this.GroupFooterSection2 = new Telerik.Reporting.GroupFooterSection();
            this.GroupHeaderSection2 = new Telerik.Reporting.GroupHeaderSection();
            this.FullName = new Telerik.Reporting.TextBox();
            this.TripNo = new Telerik.Reporting.TextBox();
            this.DepartureDate = new Telerik.Reporting.TextBox();
            this.Balance = new Telerik.Reporting.TextBox();
            this.Category = new Telerik.Reporting.TextBox();
            this.Consultant = new Telerik.Reporting.TextBox();
            this.Credit = new Telerik.Reporting.TextBox();
            this.Source = new Telerik.Reporting.TextBox();
            this.Debit = new Telerik.Reporting.TextBox();
            this.Detail = new Telerik.Reporting.DetailSection();
            this.DetailTable = new Telerik.Reporting.Table();
            this.Description = new Telerik.Reporting.TextBox();
            this.DocumentNo = new Telerik.Reporting.TextBox();
            this.DocumentDate = new Telerik.Reporting.TextBox();
            this.DocumentType = new Telerik.Reporting.TextBox();
            this.Commission = new Telerik.Reporting.TextBox();
            this.Reference = new Telerik.Reporting.TextBox();
            this.AmountGross = new Telerik.Reporting.TextBox();
            this.BalanceDetail = new Telerik.Reporting.TextBox();
            this.TotalsDetail = new Telerik.Reporting.TextBox();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.textBox3 = new Telerik.Reporting.TextBox();
            this.textBox4 = new Telerik.Reporting.TextBox();
            this.textBox5 = new Telerik.Reporting.TextBox();
            this.CommissionDetailTotal = new Telerik.Reporting.TextBox();
            this.AmountGrossDetailTotal = new Telerik.Reporting.TextBox();
            this.BalanceDetailTotal = new Telerik.Reporting.TextBox();
            this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
            this.Pages = new Telerik.Reporting.TextBox();
            this.CreationTime = new Telerik.Reporting.TextBox();
            this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // DocumentNoHeader
            // 
            this.DocumentNoHeader.Name = "DocumentNoHeader";
            this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DocumentNoHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DocumentNoHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DocumentNoHeader.Style.Font.Bold = false;
            this.DocumentNoHeader.Style.Font.Name = "Calibri";
            this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DocumentNoHeader.StyleName = "Normal.TableHeader";
            this.DocumentNoHeader.Value = "Document No";
            // 
            // DocumentDateHeader
            // 
            this.DocumentDateHeader.Name = "DocumentDateHeader";
            this.DocumentDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DocumentDateHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DocumentDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DocumentDateHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DocumentDateHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DocumentDateHeader.Style.Font.Bold = false;
            this.DocumentDateHeader.Style.Font.Name = "Calibri";
            this.DocumentDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DocumentDateHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DocumentDateHeader.StyleName = "Normal.TableHeader";
            this.DocumentDateHeader.Value = "Date";
            // 
            // DocumentTypeHeader
            // 
            this.DocumentTypeHeader.Name = "DocumentTypeHeader";
            this.DocumentTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DocumentTypeHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DocumentTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DocumentTypeHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DocumentTypeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DocumentTypeHeader.Style.Font.Bold = false;
            this.DocumentTypeHeader.Style.Font.Name = "Calibri";
            this.DocumentTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DocumentTypeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DocumentTypeHeader.StyleName = "Normal.TableHeader";
            this.DocumentTypeHeader.Value = "Type";
            // 
            // DescriptionHeader
            // 
            this.DescriptionHeader.Name = "DescriptionHeader";
            this.DescriptionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DescriptionHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DescriptionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DescriptionHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DescriptionHeader.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.DescriptionHeader.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.DescriptionHeader.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.DescriptionHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DescriptionHeader.Style.Font.Bold = false;
            this.DescriptionHeader.Style.Font.Name = "Calibri";
            this.DescriptionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DescriptionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DescriptionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DescriptionHeader.StyleName = "Normal.TableHeader";
            this.DescriptionHeader.Value = "Description";
            // 
            // ReferenceHeader
            // 
            this.ReferenceHeader.Name = "ReferenceHeader";
            this.ReferenceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ReferenceHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.ReferenceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ReferenceHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ReferenceHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ReferenceHeader.Style.Font.Bold = false;
            this.ReferenceHeader.Style.Font.Name = "Calibri";
            this.ReferenceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ReferenceHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ReferenceHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.ReferenceHeader.StyleName = "Normal.TableHeader";
            this.ReferenceHeader.Value = "Reference";
            // 
            // CommissionHeader
            // 
            this.CommissionHeader.Name = "CommissionHeader";
            this.CommissionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CommissionHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.CommissionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CommissionHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.CommissionHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CommissionHeader.Style.Font.Bold = false;
            this.CommissionHeader.Style.Font.Name = "Calibri";
            this.CommissionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CommissionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CommissionHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.CommissionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.CommissionHeader.StyleName = "Normal.TableHeader";
            this.CommissionHeader.Value = "Commission";
            // 
            // AmountGrossHeader
            // 
            this.AmountGrossHeader.Name = "AmountGrossHeader";
            this.AmountGrossHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AmountGrossHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.AmountGrossHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AmountGrossHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AmountGrossHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AmountGrossHeader.Style.Font.Name = "Calibri";
            this.AmountGrossHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AmountGrossHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AmountGrossHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.AmountGrossHeader.StyleName = "Normal.TableHeader";
            this.AmountGrossHeader.Value = "Gross";
            // 
            // BalanceDetailHeader
            // 
            this.BalanceDetailHeader.Name = "BalanceDetailHeader";
            this.BalanceDetailHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.BalanceDetailHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.BalanceDetailHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.BalanceDetailHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.BalanceDetailHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.BalanceDetailHeader.Style.Font.Name = "Calibri";
            this.BalanceDetailHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.BalanceDetailHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.BalanceDetailHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.BalanceDetailHeader.StyleName = "Normal.TableHeader";
            this.BalanceDetailHeader.Value = "Balance";
            // 
            // GroupFooterSection1
            // 
            this.GroupFooterSection1.CanShrink = true;
            this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
            this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TotalsLabel,
            this.BalanceTotal,
            this.CreditTotal,
            this.DebitTotal,
            this.CommissionTotal,
            this.textBox1});
            this.GroupFooterSection1.Name = "GroupFooterSection1";
            // 
            // TotalsLabel
            // 
            this.TotalsLabel.CanShrink = true;
            this.TotalsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TotalsLabel.Name = "TotalsLabel";
            this.TotalsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.1D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.TotalsLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalsLabel.Style.Font.Bold = true;
            this.TotalsLabel.Style.Font.Name = "Calibri";
            this.TotalsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalsLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.TotalsLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalsLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.TotalsLabel.StyleName = "Normal.TableBody";
            this.TotalsLabel.Value = "Grand Totals";
            // 
            // BalanceTotal
            // 
            this.BalanceTotal.CanShrink = true;
            this.BalanceTotal.Format = "{0:C2}";
            this.BalanceTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.BalanceTotal.Name = "BalanceTotal";
            this.BalanceTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.BalanceTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.BalanceTotal.Style.Font.Bold = true;
            this.BalanceTotal.Style.Font.Name = "Calibri";
            this.BalanceTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.BalanceTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.BalanceTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.BalanceTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.BalanceTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.BalanceTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.BalanceTotal.StyleName = "Normal.TableBody";
            this.BalanceTotal.Value = "= Sum(Fields.Balance)";
            // 
            // CreditTotal
            // 
            this.CreditTotal.CanShrink = true;
            this.CreditTotal.Format = "{0:C2}";
            this.CreditTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.CreditTotal.Name = "CreditTotal";
            this.CreditTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.CreditTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CreditTotal.Style.Font.Bold = true;
            this.CreditTotal.Style.Font.Name = "Calibri";
            this.CreditTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CreditTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.CreditTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CreditTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CreditTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.CreditTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.CreditTotal.StyleName = "Normal.TableBody";
            this.CreditTotal.Value = "= Sum(Fields.Credit)";
            // 
            // DebitTotal
            // 
            this.DebitTotal.CanShrink = true;
            this.DebitTotal.Format = "{0:C2}";
            this.DebitTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(19.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.DebitTotal.Name = "DebitTotal";
            this.DebitTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.DebitTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DebitTotal.Style.Font.Bold = true;
            this.DebitTotal.Style.Font.Name = "Calibri";
            this.DebitTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DebitTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.DebitTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DebitTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DebitTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.DebitTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.DebitTotal.StyleName = "Normal.TableBody";
            this.DebitTotal.Value = "= Sum(Fields.Debit)";
            // 
            // CommissionTotal
            // 
            this.CommissionTotal.CanShrink = true;
            this.CommissionTotal.Format = "";
            this.CommissionTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.CommissionTotal.Name = "CommissionTotal";
            this.CommissionTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.4D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.CommissionTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CommissionTotal.Style.Font.Bold = true;
            this.CommissionTotal.Style.Font.Name = "Calibri";
            this.CommissionTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CommissionTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(1D);
            this.CommissionTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CommissionTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.CommissionTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.CommissionTotal.StyleName = "Normal.TableBody";
            this.CommissionTotal.Value = "= Format(\"Commission: {0:C2}\", Sum(Fields.Commission))";
            // 
            // textBox1
            // 
            this.textBox1.CanShrink = true;
            this.textBox1.Format = "";
            this.textBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.4D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.textBox1.Style.Font.Bold = true;
            this.textBox1.Style.Font.Name = "Calibri";
            this.textBox1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.textBox1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(1D);
            this.textBox1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.textBox1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.textBox1.StyleName = "Normal.TableBody";
            this.textBox1.Value = "= Format(\"Gross: {0:C2}\", Sum(Fields.AmountGross))";
            // 
            // GroupHeaderSection1
            // 
            this.GroupHeaderSection1.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Count(1) = 0, \"None\", \"Solid\")"));
            this.GroupHeaderSection1.CanShrink = true;
            this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(2.2D);
            this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ManagementReportHeaderSubReport1,
            this.TripNoHeader,
            this.FullNameHeader,
            this.DepartureDateHeader,
            this.SourceHeader,
            this.BalanceHeader,
            this.CategoryHeader,
            this.ConsultantHeader,
            this.CreditHeader,
            this.DebitHeader,
            this.NoData});
            this.GroupHeaderSection1.Name = "GroupHeaderSection1";
            this.GroupHeaderSection1.PrintOnEveryPage = true;
            this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.GroupHeaderSection1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.GroupHeaderSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            // 
            // ManagementReportHeaderSubReport1
            // 
            this.ManagementReportHeaderSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.ManagementReportHeaderSubReport1.Name = "ManagementReportHeaderSubReport1";
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerName", "= Parameters.customerName.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportName", "= Parameters.reportName.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportDate", "= Parameters.reportDate.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("headerContent", "= Parameters.headerContent.Value"));
            typeReportSource1.TypeName = "Travelog.Reports.Common.ManagementReportHeaderSubReport1, Travelog.Reports, Versi" +
    "on=1.0.0.0, Culture=neutral, PublicKeyToken=null";
            this.ManagementReportHeaderSubReport1.ReportSource = typeReportSource1;
            this.ManagementReportHeaderSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.ManagementReportHeaderSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            // 
            // TripNoHeader
            // 
            this.TripNoHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.TripNoHeader.Name = "TripNoHeader";
            this.TripNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TripNoHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TripNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TripNoHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TripNoHeader.Style.Font.Bold = true;
            this.TripNoHeader.Style.Font.Name = "Calibri";
            this.TripNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TripNoHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.TripNoHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.TripNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.TripNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TripNoHeader.StyleName = "Normal.TableHeader";
            this.TripNoHeader.Value = "Trip No";
            // 
            // FullNameHeader
            // 
            this.FullNameHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.9D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.FullNameHeader.Name = "FullNameHeader";
            this.FullNameHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.FullNameHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.FullNameHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.FullNameHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.FullNameHeader.Style.Font.Bold = true;
            this.FullNameHeader.Style.Font.Name = "Calibri";
            this.FullNameHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.FullNameHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.FullNameHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.FullNameHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.FullNameHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.FullNameHeader.StyleName = "Normal.TableHeader";
            this.FullNameHeader.Value = "Client Name/Debtor";
            // 
            // DepartureDateHeader
            // 
            this.DepartureDateHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.4D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.DepartureDateHeader.Name = "DepartureDateHeader";
            this.DepartureDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DepartureDateHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.DepartureDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DepartureDateHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DepartureDateHeader.Style.Font.Bold = true;
            this.DepartureDateHeader.Style.Font.Name = "Calibri";
            this.DepartureDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DepartureDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DepartureDateHeader.StyleName = "Normal.TableHeader";
            this.DepartureDateHeader.Value = "Dep Date";
            // 
            // SourceHeader
            // 
            this.SourceHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(8.8D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.SourceHeader.Name = "SourceHeader";
            this.SourceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.SourceHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.SourceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.SourceHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.SourceHeader.Style.Font.Bold = true;
            this.SourceHeader.Style.Font.Name = "Calibri";
            this.SourceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.SourceHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.SourceHeader.StyleName = "Normal.TableHeader";
            this.SourceHeader.Value = "Source";
            // 
            // BalanceHeader
            // 
            this.BalanceHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.BalanceHeader.Name = "BalanceHeader";
            this.BalanceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.BalanceHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.BalanceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.BalanceHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.BalanceHeader.Style.Font.Bold = true;
            this.BalanceHeader.Style.Font.Name = "Calibri";
            this.BalanceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.BalanceHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.BalanceHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.BalanceHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.BalanceHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.BalanceHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.BalanceHeader.StyleName = "Normal.TableHeader";
            this.BalanceHeader.Value = "Balance";
            // 
            // CategoryHeader
            // 
            this.CategoryHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.5D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.CategoryHeader.Name = "CategoryHeader";
            this.CategoryHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CategoryHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.CategoryHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CategoryHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CategoryHeader.Style.Font.Bold = true;
            this.CategoryHeader.Style.Font.Name = "Calibri";
            this.CategoryHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CategoryHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.CategoryHeader.StyleName = "Normal.TableHeader";
            this.CategoryHeader.Value = "Category";
            // 
            // ConsultantHeader
            // 
            this.ConsultantHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.2D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.ConsultantHeader.Name = "ConsultantHeader";
            this.ConsultantHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ConsultantHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.ConsultantHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ConsultantHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ConsultantHeader.Style.Font.Bold = true;
            this.ConsultantHeader.Style.Font.Name = "Calibri";
            this.ConsultantHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ConsultantHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.ConsultantHeader.StyleName = "Normal.TableHeader";
            this.ConsultantHeader.Value = "Consultant/Agent";
            // 
            // CreditHeader
            // 
            this.CreditHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.5D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.CreditHeader.Name = "CreditHeader";
            this.CreditHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CreditHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.CreditHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CreditHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CreditHeader.Style.Font.Bold = true;
            this.CreditHeader.Style.Font.Name = "Calibri";
            this.CreditHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CreditHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.CreditHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CreditHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CreditHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.CreditHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.CreditHeader.StyleName = "Normal.TableHeader";
            this.CreditHeader.Value = "Credit";
            // 
            // DebitHeader
            // 
            this.DebitHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(19.9D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.DebitHeader.Name = "DebitHeader";
            this.DebitHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DebitHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.DebitHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DebitHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DebitHeader.Style.Font.Bold = true;
            this.DebitHeader.Style.Font.Name = "Calibri";
            this.DebitHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DebitHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.DebitHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DebitHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DebitHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.DebitHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DebitHeader.StyleName = "Normal.TableHeader";
            this.DebitHeader.Value = "Debit";
            // 
            // NoData
            // 
            formattingRule1.Filters.Add(new Telerik.Reporting.Filter("= Count(1)", Telerik.Reporting.FilterOperator.Equal, "0"));
            formattingRule1.Style.Visible = true;
            this.NoData.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule1});
            this.NoData.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.6D));
            this.NoData.Name = "NoData";
            this.NoData.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.NoData.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.NoData.Style.BorderColor.Default = System.Drawing.Color.WhiteSmoke;
            this.NoData.Style.Font.Name = "Calibri";
            this.NoData.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.NoData.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.NoData.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.NoData.Style.Visible = false;
            this.NoData.StyleName = "Normal.TableHeader";
            this.NoData.Value = "NO DATA AVAILABLE";
            // 
            // GroupFooterSection2
            // 
            this.GroupFooterSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.GroupFooterSection2.Name = "GroupFooterSection2";
            this.GroupFooterSection2.Style.Visible = false;
            // 
            // GroupHeaderSection2
            // 
            this.GroupHeaderSection2.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Parameters.ledgerDocumentTypeId.Value In (0, 2) Or Fields.TransactionDetail" +
            "ReportList.Count = 0, \"Solid\", \"None\")"));
            this.GroupHeaderSection2.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderWidth.Default", "= IIf(Parameters.ledgerDocumentTypeId.Value In (0, 2) Or Fields.TransactionDetail" +
            "ReportList.Count = 0, \"0.5pt\", \"0pt\")"));
            this.GroupHeaderSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
            this.GroupHeaderSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.FullName,
            this.TripNo,
            this.DepartureDate,
            this.Balance,
            this.Category,
            this.Consultant,
            this.Credit,
            this.Source,
            this.Debit});
            this.GroupHeaderSection2.Name = "GroupHeaderSection2";
            this.GroupHeaderSection2.PrintOnEveryPage = true;
            this.GroupHeaderSection2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            // 
            // FullName
            // 
            this.FullName.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Bold", "= IIf(Parameters.ledgerDocumentTypeId.Value In (0, 2), False, True)"));
            this.FullName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.FullName.Name = "FullName";
            this.FullName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.FullName.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.FullName.Style.Font.Name = "Calibri";
            this.FullName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.FullName.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.FullName.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.FullName.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.FullName.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.FullName.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.FullName.StyleName = "Normal.TableBody";
            this.FullName.Value = "= Fields.FullName";
            // 
            // TripNo
            // 
            this.TripNo.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Bold", "= IIf(Parameters.ledgerDocumentTypeId.Value In (0, 2), False, True)"));
            this.TripNo.CanShrink = true;
            this.TripNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TripNo.Name = "TripNo";
            this.TripNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TripNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TripNo.Style.Font.Name = "Calibri";
            this.TripNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TripNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TripNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.TripNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.TripNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TripNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.TripNo.StyleName = "Normal.TableBody";
            this.TripNo.Value = "= Fields.TripNo";
            // 
            // DepartureDate
            // 
            this.DepartureDate.Format = "{0:dd-MMM-yyyy}";
            this.DepartureDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.DepartureDate.Name = "DepartureDate";
            this.DepartureDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DepartureDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DepartureDate.Style.Font.Name = "Calibri";
            this.DepartureDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DepartureDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DepartureDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.DepartureDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DepartureDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.DepartureDate.StyleName = "Normal.TableBody";
            this.DepartureDate.Value = "= Fields.DepartureDate";
            // 
            // Balance
            // 
            this.Balance.Format = "{0:C2}";
            this.Balance.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.Balance.Name = "Balance";
            this.Balance.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Balance.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Balance.Style.Font.Name = "Calibri";
            this.Balance.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Balance.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Balance.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Balance.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Balance.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Balance.StyleName = "Normal.TableBody";
            this.Balance.Value = "= Fields.Balance";
            // 
            // Category
            // 
            this.Category.Format = "{0:C2}";
            this.Category.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.Category.Name = "Category";
            this.Category.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Category.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Category.Style.Font.Name = "Calibri";
            this.Category.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Category.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Category.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Category.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Category.StyleName = "Normal.TableBody";
            this.Category.Value = "= Fields.Category";
            // 
            // Consultant
            // 
            this.Consultant.Format = "{0:C2}";
            this.Consultant.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.2D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.Consultant.Name = "Consultant";
            this.Consultant.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Consultant.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Consultant.Style.Font.Name = "Calibri";
            this.Consultant.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Consultant.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Consultant.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Consultant.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Consultant.StyleName = "Normal.TableBody";
            this.Consultant.Value = "= Fields.Consultant";
            // 
            // Credit
            // 
            this.Credit.Format = "{0:C2}";
            this.Credit.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.Credit.Name = "Credit";
            this.Credit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Credit.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Credit.Style.Font.Name = "Calibri";
            this.Credit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Credit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Credit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Credit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Credit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Credit.StyleName = "Normal.TableBody";
            this.Credit.Value = "= Fields.Credit";
            // 
            // Source
            // 
            this.Source.Format = "{0:C2}";
            this.Source.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(8.8D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.Source.Name = "Source";
            this.Source.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Source.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Source.Style.Font.Name = "Calibri";
            this.Source.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Source.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Source.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Source.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Source.StyleName = "Normal.TableBody";
            this.Source.Value = "= Fields.Source";
            // 
            // Debit
            // 
            this.Debit.Format = "{0:C2}";
            this.Debit.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(19.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.Debit.Name = "Debit";
            this.Debit.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Debit.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Debit.Style.Font.Name = "Calibri";
            this.Debit.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Debit.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Debit.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Debit.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Debit.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Debit.StyleName = "Normal.TableBody";
            this.Debit.Value = "= Fields.Debit";
            // 
            // Detail
            // 
            this.Detail.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.ledgerDocumentTypeId.Value In (0, 2) Or Fields.TransactionDetail" +
            "ReportList.Count = 0, False, True)"));
            this.Detail.CanShrink = true;
            this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(1.8D);
            this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailTable});
            this.Detail.Name = "Detail";
            this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            // 
            // DetailTable
            // 
            this.DetailTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.TransactionDetailReportList"));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.7D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.8D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.4D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(5D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(5D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.6D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.6D)));
            this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.6D)));
            this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
            this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
            this.DetailTable.Body.SetCellContent(0, 3, this.Description);
            this.DetailTable.Body.SetCellContent(0, 0, this.DocumentNo);
            this.DetailTable.Body.SetCellContent(0, 1, this.DocumentDate);
            this.DetailTable.Body.SetCellContent(0, 2, this.DocumentType);
            this.DetailTable.Body.SetCellContent(0, 5, this.Commission);
            this.DetailTable.Body.SetCellContent(0, 4, this.Reference);
            this.DetailTable.Body.SetCellContent(0, 6, this.AmountGross);
            this.DetailTable.Body.SetCellContent(0, 7, this.BalanceDetail);
            this.DetailTable.Body.SetCellContent(1, 0, this.TotalsDetail);
            this.DetailTable.Body.SetCellContent(1, 1, this.textBox2);
            this.DetailTable.Body.SetCellContent(1, 2, this.textBox3);
            this.DetailTable.Body.SetCellContent(1, 3, this.textBox4);
            this.DetailTable.Body.SetCellContent(1, 4, this.textBox5);
            this.DetailTable.Body.SetCellContent(1, 5, this.CommissionDetailTotal);
            this.DetailTable.Body.SetCellContent(1, 6, this.AmountGrossDetailTotal);
            this.DetailTable.Body.SetCellContent(1, 7, this.BalanceDetailTotal);
            tableGroup1.Name = "tableGroup8";
            tableGroup1.ReportItem = this.DocumentNoHeader;
            tableGroup2.Name = "group";
            tableGroup2.ReportItem = this.DocumentDateHeader;
            tableGroup3.Name = "group1";
            tableGroup3.ReportItem = this.DocumentTypeHeader;
            tableGroup4.Name = "tableGroup9";
            tableGroup4.ReportItem = this.DescriptionHeader;
            tableGroup5.Name = "group3";
            tableGroup5.ReportItem = this.ReferenceHeader;
            tableGroup6.Name = "group2";
            tableGroup6.ReportItem = this.CommissionHeader;
            tableGroup7.Name = "group4";
            tableGroup7.ReportItem = this.AmountGrossHeader;
            tableGroup8.Name = "group5";
            tableGroup8.ReportItem = this.BalanceDetailHeader;
            this.DetailTable.ColumnGroups.Add(tableGroup1);
            this.DetailTable.ColumnGroups.Add(tableGroup2);
            this.DetailTable.ColumnGroups.Add(tableGroup3);
            this.DetailTable.ColumnGroups.Add(tableGroup4);
            this.DetailTable.ColumnGroups.Add(tableGroup5);
            this.DetailTable.ColumnGroups.Add(tableGroup6);
            this.DetailTable.ColumnGroups.Add(tableGroup7);
            this.DetailTable.ColumnGroups.Add(tableGroup8);
            this.DetailTable.ColumnHeadersPrintOnEveryPage = true;
            this.DetailTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DocumentNo,
            this.DocumentDate,
            this.DocumentType,
            this.Description,
            this.Reference,
            this.Commission,
            this.AmountGross,
            this.BalanceDetail,
            this.TotalsDetail,
            this.textBox2,
            this.textBox3,
            this.textBox4,
            this.textBox5,
            this.CommissionDetailTotal,
            this.AmountGrossDetailTotal,
            this.BalanceDetailTotal,
            this.DocumentNoHeader,
            this.DocumentDateHeader,
            this.DocumentTypeHeader,
            this.DescriptionHeader,
            this.ReferenceHeader,
            this.CommissionHeader,
            this.AmountGrossHeader,
            this.BalanceDetailHeader});
            this.DetailTable.KeepTogether = false;
            this.DetailTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.DetailTable.Name = "DetailTable";
            tableGroup9.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup9.Name = "detailTableGroup";
            tableGroup10.Name = "group6";
            this.DetailTable.RowGroups.Add(tableGroup9);
            this.DetailTable.RowGroups.Add(tableGroup10);
            this.DetailTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            // 
            // Description
            // 
            this.Description.CanGrow = false;
            this.Description.Format = "";
            this.Description.Name = "Description";
            this.Description.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Description.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Description.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Description.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.Description.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.Description.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.Description.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Description.Style.Font.Name = "Calibri";
            this.Description.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Description.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Description.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Description.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Description.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Description.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Description.StyleName = "Normal.TableBody";
            this.Description.Value = "= Fields.Description";
            // 
            // DocumentNo
            // 
            this.DocumentNo.CanGrow = false;
            this.DocumentNo.Format = "";
            this.DocumentNo.Name = "DocumentNo";
            this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DocumentNo.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DocumentNo.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.DocumentNo.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.DocumentNo.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.DocumentNo.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DocumentNo.Style.Font.Name = "Calibri";
            this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DocumentNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.DocumentNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DocumentNo.StyleName = "Normal.TableBody";
            this.DocumentNo.Value = "= Fields.DocumentNo";
            // 
            // DocumentDate
            // 
            this.DocumentDate.CanGrow = false;
            this.DocumentDate.Format = "{0:dd-MMM-yyyy}";
            this.DocumentDate.Name = "DocumentDate";
            this.DocumentDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DocumentDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DocumentDate.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DocumentDate.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DocumentDate.Style.Font.Name = "Calibri";
            this.DocumentDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DocumentDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.DocumentDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DocumentDate.StyleName = "Normal.TableBody";
            this.DocumentDate.Value = "= Fields.DocumentDate";
            // 
            // DocumentType
            // 
            this.DocumentType.CanGrow = false;
            this.DocumentType.Name = "DocumentType";
            this.DocumentType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DocumentType.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DocumentType.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DocumentType.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DocumentType.Style.Font.Name = "Calibri";
            this.DocumentType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DocumentType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.DocumentType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DocumentType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DocumentType.StyleName = "Normal.TableBody";
            this.DocumentType.Value = "= Fields.TransactionType";
            // 
            // Commission
            // 
            this.Commission.CanGrow = false;
            this.Commission.Format = "{0:c2}";
            this.Commission.Name = "Commission";
            this.Commission.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Commission.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Commission.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Commission.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.Commission.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.Commission.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.Commission.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Commission.Style.Font.Name = "Calibri";
            this.Commission.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Commission.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Commission.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Commission.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Commission.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Commission.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Commission.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Commission.StyleName = "Normal.TableBody";
            this.Commission.Value = "= Fields.Commission";
            // 
            // Reference
            // 
            this.Reference.CanGrow = false;
            this.Reference.Name = "Reference";
            this.Reference.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Reference.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Reference.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Reference.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Reference.Style.Font.Name = "Calibri";
            this.Reference.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Reference.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Reference.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Reference.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Reference.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Reference.StyleName = "Normal.TableBody";
            this.Reference.Value = "= Fields.Reference";
            // 
            // AmountGross
            // 
            this.AmountGross.CanGrow = false;
            this.AmountGross.Format = "{0:c2}";
            this.AmountGross.Name = "AmountGross";
            this.AmountGross.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AmountGross.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AmountGross.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AmountGross.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AmountGross.Style.Font.Name = "Calibri";
            this.AmountGross.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AmountGross.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.AmountGross.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AmountGross.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AmountGross.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.AmountGross.StyleName = "Normal.TableBody";
            this.AmountGross.Value = "= Fields.AmountGross";
            // 
            // BalanceDetail
            // 
            this.BalanceDetail.CanGrow = false;
            this.BalanceDetail.Format = "{0:c2}";
            this.BalanceDetail.Name = "BalanceDetail";
            this.BalanceDetail.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.BalanceDetail.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.BalanceDetail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.BalanceDetail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.BalanceDetail.Style.Font.Name = "Calibri";
            this.BalanceDetail.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.BalanceDetail.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.BalanceDetail.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.BalanceDetail.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.BalanceDetail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.BalanceDetail.StyleName = "Normal.TableBody";
            this.BalanceDetail.Value = "= RunningValue(\"DetailTable\", Sum(Fields.AmountGross))";
            // 
            // TotalsDetail
            // 
            this.TotalsDetail.Name = "TotalsDetail";
            this.TotalsDetail.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalsDetail.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalsDetail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalsDetail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalsDetail.Style.Font.Name = "Calibri";
            this.TotalsDetail.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalsDetail.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.TotalsDetail.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalsDetail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TotalsDetail.StyleName = "Normal.TableBody";
            this.TotalsDetail.Value = "Totals";
            // 
            // textBox2
            // 
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.textBox2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.textBox2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox2.Style.Font.Name = "Calibri";
            this.textBox2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.textBox2.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.textBox2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.textBox2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox2.StyleName = "Normal.TableBody";
            // 
            // textBox3
            // 
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.textBox3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.textBox3.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox3.Style.Font.Name = "Calibri";
            this.textBox3.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.textBox3.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.textBox3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.textBox3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox3.StyleName = "Normal.TableBody";
            // 
            // textBox4
            // 
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.textBox4.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.textBox4.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox4.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox4.Style.Font.Name = "Calibri";
            this.textBox4.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.textBox4.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.textBox4.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.textBox4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox4.StyleName = "Normal.TableBody";
            // 
            // textBox5
            // 
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.textBox5.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.textBox5.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox5.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.textBox5.Style.Font.Name = "Calibri";
            this.textBox5.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.textBox5.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.textBox5.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.textBox5.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox5.StyleName = "Normal.TableBody";
            // 
            // CommissionDetailTotal
            // 
            this.CommissionDetailTotal.Format = "{0:c2}";
            this.CommissionDetailTotal.Name = "CommissionDetailTotal";
            this.CommissionDetailTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CommissionDetailTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CommissionDetailTotal.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.CommissionDetailTotal.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CommissionDetailTotal.Style.Font.Name = "Calibri";
            this.CommissionDetailTotal.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CommissionDetailTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.CommissionDetailTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CommissionDetailTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.CommissionDetailTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.CommissionDetailTotal.StyleName = "Normal.TableBody";
            this.CommissionDetailTotal.Value = "= Sum(Fields.Commission)";
            // 
            // AmountGrossDetailTotal
            // 
            this.AmountGrossDetailTotal.Format = "{0:c2}";
            this.AmountGrossDetailTotal.Name = "AmountGrossDetailTotal";
            this.AmountGrossDetailTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AmountGrossDetailTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AmountGrossDetailTotal.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AmountGrossDetailTotal.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AmountGrossDetailTotal.Style.Font.Name = "Calibri";
            this.AmountGrossDetailTotal.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AmountGrossDetailTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.AmountGrossDetailTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AmountGrossDetailTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AmountGrossDetailTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.AmountGrossDetailTotal.StyleName = "Normal.TableBody";
            this.AmountGrossDetailTotal.Value = "= Sum(Fields.AmountGross)";
            // 
            // BalanceDetailTotal
            // 
            this.BalanceDetailTotal.Format = "{0:c2}";
            this.BalanceDetailTotal.Name = "BalanceDetailTotal";
            this.BalanceDetailTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.BalanceDetailTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.BalanceDetailTotal.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.BalanceDetailTotal.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.BalanceDetailTotal.Style.Font.Name = "Calibri";
            this.BalanceDetailTotal.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.BalanceDetailTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.BalanceDetailTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.BalanceDetailTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.BalanceDetailTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.BalanceDetailTotal.StyleName = "Normal.TableBody";
            this.BalanceDetailTotal.Value = "= Sum(Fields.AmountGross)";
            // 
            // PageFooterSection
            // 
            this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
            this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
            this.PageFooterSection.Name = "PageFooter";
            // 
            // Pages
            // 
            this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.7D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Pages.Name = "Pages";
            this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Pages.Style.Color = System.Drawing.Color.DarkGray;
            this.Pages.Style.Font.Name = "Calibri";
            this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Pages.Value = "= \"Page \" + PageNumber";
            // 
            // CreationTime
            // 
            this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.CreationTime.Name = "CreationTime";
            this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
            this.CreationTime.Style.Font.Name = "Calibri";
            this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy" +
    " HH:mm}\", Parameters.creationTime.Value)";
            // 
            // ReportDataSource
            // 
            this.ReportDataSource.DataMember = "ClientTrialBalanceReport";
            this.ReportDataSource.DataSource = typeof(Travelog.Reports.ClientLedger.ClientLedgerDataSources);
            this.ReportDataSource.Name = "ReportDataSource";
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("reportSourceId", typeof(int), "= Parameters.reportSourceId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("reportDate", typeof(System.DateTime), "= Parameters.reportDate.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("reportOrderId", typeof(int), "= Parameters.reportOrderId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("ledgerDocumentTypeId", typeof(int), "= Parameters.ledgerDocumentTypeId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("commissionValueTypeId", typeof(int), "= Parameters.commissionValueTypeId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("transactionBalanceTypeId", typeof(int), "= Parameters.transactionBalanceTypeId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("departureDateFrom", typeof(System.Nullable<System.DateTime>), "= Parameters.departureDateFrom.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("departureDateTo", typeof(System.Nullable<System.DateTime>), "= Parameters.departureDateTo.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("txnDateFrom", typeof(System.Nullable<System.DateTime>), "= Parameters.txnDateFrom.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("txnDateTo", typeof(System.Nullable<System.DateTime>), "= Parameters.txnDateTo.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("includeOpenDated", typeof(bool), "= Parameters.includeOpenDated.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("tripIdFrom", typeof(int), "= Parameters.tripIdFrom.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("tripIdTo", typeof(int), "= Parameters.tripIdTo.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyIds", typeof(string), "= Parameters.agencyIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agentIds", typeof(string), "= Parameters.agentIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("categoryIds", typeof(string), "= Parameters.categoryIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("classIds", typeof(string), "= Parameters.classIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("consultantIds", typeof(string), "= Parameters.consultantIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("debtorIds", typeof(string), "= Parameters.debtorIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("destinationIds", typeof(string), "= Parameters.destinationIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupIds", typeof(string), "= Parameters.groupIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("locationIds", typeof(string), "= Parameters.locationIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("sourceIds", typeof(string), "= Parameters.sourceIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupByAgency", typeof(bool), "= Parameters.groupByAgency.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupByAgent", typeof(bool), "= Parameters.groupByAgent.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupByCategory", typeof(bool), "= Parameters.groupByCategory.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupByClass", typeof(bool), "= Parameters.groupByClass.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupByConsultant", typeof(bool), "= Parameters.groupByConsultant.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupByDebtor", typeof(bool), "= Parameters.groupByDebtor.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupByDestination", typeof(bool), "= Parameters.groupByDestination.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupByGroup", typeof(bool), "= Parameters.groupByGroup.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupByLocation", typeof(bool), "= Parameters.groupByLocation.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupBySource", typeof(bool), "= Parameters.groupBySource.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyNewPage", typeof(bool), "= Parameters.agencyNewPage.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agentNewPage", typeof(bool), "= Parameters.agentNewPage.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("categoryNewPage", typeof(bool), "= Parameters.categoryNewPage.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("classNewPage", typeof(bool), "= Parameters.classNewPage.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("consultantNewPage", typeof(bool), "= Parameters.consultantNewPage.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("debtorNewPage", typeof(bool), "= Parameters.debtorNewPage.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("destinationNewPage", typeof(bool), "= Parameters.destinationNewPage.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupNewPage", typeof(bool), "= Parameters.groupNewPage.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("locationNewPage", typeof(bool), "= Parameters.locationNewPage.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("sourceNewPage", typeof(bool), "= Parameters.sourceNewPage.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyLevel", typeof(System.Nullable<int>), "= Parameters.agencyLevel.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agentLevel", typeof(System.Nullable<int>), "= Parameters.agentLevel.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("categoryLevel", typeof(System.Nullable<int>), "= Parameters.categoryLevel.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("classLevel", typeof(System.Nullable<int>), "= Parameters.classLevel.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("consultantLevel", typeof(System.Nullable<int>), "= Parameters.consultantLevel.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("debtorLevel", typeof(System.Nullable<int>), "= Parameters.debtorLevel.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("destinationLevel", typeof(System.Nullable<int>), "= Parameters.destinationLevel.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("groupLevel", typeof(System.Nullable<int>), "= Parameters.groupLevel.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("locationLevel", typeof(System.Nullable<int>), "= Parameters.locationLevel.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("sourceLevel", typeof(System.Nullable<int>), "= Parameters.sourceLevel.Value"));
            // 
            // ClientTrialBalanceReport
            // 
            this.DataSource = this.ReportDataSource;
            group1.GroupFooter = this.GroupFooterSection1;
            group1.GroupHeader = this.GroupHeaderSection1;
            group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
            group1.Name = "Group1";
            group2.GroupFooter = this.GroupFooterSection2;
            group2.GroupHeader = this.GroupHeaderSection2;
            group2.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.TripId"));
            group2.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
            group2.Name = "Group2";
            this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2});
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.GroupHeaderSection2,
            this.GroupFooterSection2,
            this.Detail,
            this.PageFooterSection});
            this.Name = "ClientTrialBalanceReport";
            this.PageSettings.Landscape = true;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            reportParameter1.Name = "customerId";
            reportParameter2.Name = "reportSourceId";
            reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter3.Name = "customerName";
            reportParameter4.Name = "reportName";
            reportParameter5.Name = "headerContent";
            reportParameter6.Name = "creationUser";
            reportParameter7.Name = "creationTime";
            reportParameter7.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter8.Name = "reportDate";
            reportParameter9.Name = "reportOrderId";
            reportParameter9.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter10.Name = "commissionValueTypeId";
            reportParameter10.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter11.Name = "transactionBalanceTypeId";
            reportParameter11.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter12.Name = "ledgerDocumentTypeId";
            reportParameter12.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter13.AllowNull = true;
            reportParameter13.Name = "departureDateFrom";
            reportParameter13.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter14.AllowNull = true;
            reportParameter14.Name = "departureDateTo";
            reportParameter14.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter15.AllowNull = true;
            reportParameter15.Name = "txnDateFrom";
            reportParameter15.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter16.AllowNull = true;
            reportParameter16.Name = "txnDateTo";
            reportParameter16.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter17.Name = "includeOpenDated";
            reportParameter17.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter18.Name = "tripIdFrom";
            reportParameter18.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter19.Name = "tripIdTo";
            reportParameter19.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter20.Name = "agencyIds";
            reportParameter21.Name = "agentIds";
            reportParameter22.Name = "categoryIds";
            reportParameter23.Name = "classIds";
            reportParameter24.Name = "consultantIds";
            reportParameter25.Name = "debtorIds";
            reportParameter26.Name = "destinationIds";
            reportParameter27.Name = "groupIds";
            reportParameter28.Name = "locationIds";
            reportParameter29.Name = "sourceIds";
            reportParameter30.Name = "groupByAgency";
            reportParameter30.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter31.Name = "groupByAgent";
            reportParameter31.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter32.Name = "groupByCategory";
            reportParameter32.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter33.Name = "groupByClass";
            reportParameter33.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter34.Name = "groupByConsultant";
            reportParameter34.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter35.Name = "groupByDebtor";
            reportParameter35.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter36.Name = "groupByDestination";
            reportParameter36.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter37.Name = "groupByGroup";
            reportParameter37.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter38.Name = "groupByLocation";
            reportParameter38.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter39.Name = "groupBySource";
            reportParameter39.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter40.Name = "agencyNewPage";
            reportParameter40.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter41.Name = "agentNewPage";
            reportParameter41.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter42.Name = "categoryNewPage";
            reportParameter42.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter43.Name = "classNewPage";
            reportParameter43.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter44.Name = "consultantNewPage";
            reportParameter44.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter45.Name = "debtorNewPage";
            reportParameter45.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter46.Name = "destinationNewPage";
            reportParameter46.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter47.Name = "groupNewPage";
            reportParameter47.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter48.Name = "locationNewPage";
            reportParameter48.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter49.Name = "sourceNewPage";
            reportParameter49.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter50.AllowNull = true;
            reportParameter50.Name = "agencyLevel";
            reportParameter50.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter51.AllowNull = true;
            reportParameter51.Name = "agentLevel";
            reportParameter51.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter52.AllowNull = true;
            reportParameter52.Name = "categoryLevel";
            reportParameter52.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter53.AllowNull = true;
            reportParameter53.Name = "classLevel";
            reportParameter53.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter54.AllowNull = true;
            reportParameter54.Name = "consultantLevel";
            reportParameter54.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter55.AllowNull = true;
            reportParameter55.Name = "debtorLevel";
            reportParameter55.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter56.AllowNull = true;
            reportParameter56.Name = "destinationLevel";
            reportParameter56.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter57.AllowNull = true;
            reportParameter57.Name = "groupLevel";
            reportParameter57.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter58.AllowNull = true;
            reportParameter58.Name = "locationLevel";
            reportParameter58.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter59.AllowNull = true;
            reportParameter59.Name = "sourceLevel";
            reportParameter59.Type = Telerik.Reporting.ReportParameterType.Integer;
            this.ReportParameters.Add(reportParameter1);
            this.ReportParameters.Add(reportParameter2);
            this.ReportParameters.Add(reportParameter3);
            this.ReportParameters.Add(reportParameter4);
            this.ReportParameters.Add(reportParameter5);
            this.ReportParameters.Add(reportParameter6);
            this.ReportParameters.Add(reportParameter7);
            this.ReportParameters.Add(reportParameter8);
            this.ReportParameters.Add(reportParameter9);
            this.ReportParameters.Add(reportParameter10);
            this.ReportParameters.Add(reportParameter11);
            this.ReportParameters.Add(reportParameter12);
            this.ReportParameters.Add(reportParameter13);
            this.ReportParameters.Add(reportParameter14);
            this.ReportParameters.Add(reportParameter15);
            this.ReportParameters.Add(reportParameter16);
            this.ReportParameters.Add(reportParameter17);
            this.ReportParameters.Add(reportParameter18);
            this.ReportParameters.Add(reportParameter19);
            this.ReportParameters.Add(reportParameter20);
            this.ReportParameters.Add(reportParameter21);
            this.ReportParameters.Add(reportParameter22);
            this.ReportParameters.Add(reportParameter23);
            this.ReportParameters.Add(reportParameter24);
            this.ReportParameters.Add(reportParameter25);
            this.ReportParameters.Add(reportParameter26);
            this.ReportParameters.Add(reportParameter27);
            this.ReportParameters.Add(reportParameter28);
            this.ReportParameters.Add(reportParameter29);
            this.ReportParameters.Add(reportParameter30);
            this.ReportParameters.Add(reportParameter31);
            this.ReportParameters.Add(reportParameter32);
            this.ReportParameters.Add(reportParameter33);
            this.ReportParameters.Add(reportParameter34);
            this.ReportParameters.Add(reportParameter35);
            this.ReportParameters.Add(reportParameter36);
            this.ReportParameters.Add(reportParameter37);
            this.ReportParameters.Add(reportParameter38);
            this.ReportParameters.Add(reportParameter39);
            this.ReportParameters.Add(reportParameter40);
            this.ReportParameters.Add(reportParameter41);
            this.ReportParameters.Add(reportParameter42);
            this.ReportParameters.Add(reportParameter43);
            this.ReportParameters.Add(reportParameter44);
            this.ReportParameters.Add(reportParameter45);
            this.ReportParameters.Add(reportParameter46);
            this.ReportParameters.Add(reportParameter47);
            this.ReportParameters.Add(reportParameter48);
            this.ReportParameters.Add(reportParameter49);
            this.ReportParameters.Add(reportParameter50);
            this.ReportParameters.Add(reportParameter51);
            this.ReportParameters.Add(reportParameter52);
            this.ReportParameters.Add(reportParameter53);
            this.ReportParameters.Add(reportParameter54);
            this.ReportParameters.Add(reportParameter55);
            this.ReportParameters.Add(reportParameter56);
            this.ReportParameters.Add(reportParameter57);
            this.ReportParameters.Add(reportParameter58);
            this.ReportParameters.Add(reportParameter59);
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(27.7D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.TextBox TotalsLabel;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.TextBox TripNoHeader;
		private Telerik.Reporting.TextBox FullNameHeader;
		private Telerik.Reporting.TextBox DepartureDateHeader;
		private Telerik.Reporting.TextBox SourceHeader;
		private Telerik.Reporting.TextBox BalanceHeader;
		private Telerik.Reporting.TextBox TripNo;
		private Telerik.Reporting.TextBox FullName;
		private Telerik.Reporting.TextBox DepartureDate;
		private Telerik.Reporting.TextBox Source;
		private Telerik.Reporting.TextBox Balance;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection2;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection2;
		private Telerik.Reporting.Table DetailTable;
		private Telerik.Reporting.TextBox Description;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox DocumentDate;
		private Telerik.Reporting.TextBox DocumentType;
		private Telerik.Reporting.TextBox DocumentDateHeader;
		private Telerik.Reporting.TextBox DocumentTypeHeader;
		private Telerik.Reporting.TextBox DescriptionHeader;
		private Telerik.Reporting.TextBox CommissionHeader;
		private Telerik.Reporting.TextBox Reference;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox ReferenceHeader;
		private Telerik.Reporting.TextBox Commission;
		private Telerik.Reporting.TextBox CategoryHeader;
		private Telerik.Reporting.TextBox ConsultantHeader;
		private Telerik.Reporting.TextBox Category;
		private Telerik.Reporting.TextBox Consultant;
		private Telerik.Reporting.TextBox BalanceTotal;
		private Telerik.Reporting.TextBox AmountGross;
		private Telerik.Reporting.TextBox BalanceDetail;
		private Telerik.Reporting.TextBox AmountGrossHeader;
		private Telerik.Reporting.TextBox BalanceDetailHeader;
		private Telerik.Reporting.TextBox CreditHeader;
		private Telerik.Reporting.TextBox Credit;
		private Telerik.Reporting.TextBox DebitHeader;
		private Telerik.Reporting.TextBox Debit;
		private Telerik.Reporting.TextBox CreditTotal;
		private Telerik.Reporting.TextBox DebitTotal;
		private Telerik.Reporting.TextBox TotalsDetail;
		private Telerik.Reporting.TextBox textBox2;
		private Telerik.Reporting.TextBox textBox3;
		private Telerik.Reporting.TextBox textBox4;
		private Telerik.Reporting.TextBox textBox5;
		private Telerik.Reporting.TextBox CommissionDetailTotal;
		private Telerik.Reporting.TextBox AmountGrossDetailTotal;
		private Telerik.Reporting.TextBox BalanceDetailTotal;
		private Telerik.Reporting.SubReport ManagementReportHeaderSubReport1;
		private Telerik.Reporting.TextBox CommissionTotal;
		private Telerik.Reporting.TextBox textBox1;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.TextBox NoData;
	}
}