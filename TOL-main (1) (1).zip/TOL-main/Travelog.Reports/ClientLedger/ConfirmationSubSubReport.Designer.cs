using Travelog.Biz;

namespace Travelog.Reports.ClientLedger {
	partial class ConfirmationSubSubReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfirmationSubSubReport));
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.Footer = new Telerik.Reporting.HtmlTextBox();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.Header1 = new Telerik.Reporting.HtmlTextBox();
			this.Header2 = new Telerik.Reporting.HtmlTextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.DateRange = new Telerik.Reporting.HtmlTextBox();
			this.Remarks = new Telerik.Reporting.HtmlTextBox();
			this.Description = new Telerik.Reporting.HtmlTextBox();
			this.Icon = new Telerik.Reporting.PictureBox();
			this.ObjectDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.Footer=\"\", False, True)"));
			this.GroupFooterSection1.CanShrink = true;
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Footer});
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			// 
			// Footer
			// 
			this.Footer.CanShrink = true;
			this.Footer.Name = "Footer";
			this.Footer.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Footer.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.Footer.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Footer.Style.Font.Name = "Calibri";
			this.Footer.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Footer.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Footer.StyleName = "Normal.TableBody";
			this.Footer.Value = "= Fields.Footer";
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.IsHeaderHidden, False, True)"));
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Header1,
            this.Header2});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupHeaderSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// Header1
			// 
			this.Header1.Bindings.Add(new Telerik.Reporting.Binding("Value", "= Substr(Fields.Header1, 4, Len(Fields.Header1))"));
			this.Header1.CanShrink = true;
			this.Header1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Header1.Name = "Header1";
			this.Header1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Header1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Header1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Header1.Style.Font.Bold = true;
			this.Header1.Style.Font.Name = "Calibri";
			this.Header1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Header1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Header1.StyleName = "";
			this.Header1.Value = "= Fields.Header1";
			// 
			// Header2
			// 
			this.Header2.CanShrink = true;
			this.Header2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Header2.Name = "Header2";
			this.Header2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Header2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Header2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Header2.Style.Font.Bold = true;
			this.Header2.Style.Font.Name = "Calibri";
			this.Header2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Header2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Header2.StyleName = "";
			this.Header2.Value = "= Fields.Header2";
			// 
			// Detail
			// 
			this.Detail.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.IsHeaderHidden, \"None\", \"Solid\")"));
			this.Detail.CanShrink = true;
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(1.55D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DateRange,
            this.Remarks,
            this.Description,
            this.Icon});
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Detail.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// DateRange
			// 
			this.DateRange.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.IsHeaderHidden, False, True)"));
			this.DateRange.CanShrink = true;
			this.DateRange.KeepTogether = false;
			this.DateRange.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.DateRange.Name = "DateRange";
			this.DateRange.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.DateRange.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DateRange.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DateRange.Style.Font.Name = "Calibri";
			this.DateRange.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DateRange.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DateRange.Value = "= IIf(Parameters.issuedDocumentType.Value=\"Itinerary\", \"\", Fields.DateRange)";
			// 
			// Remarks
			// 
			this.Remarks.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Top", "= IIf(Fields.IsHeaderHidden, \"None\", \"Solid\")"));
			this.Remarks.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.Remarks=\"\", False, True)"));
			this.Remarks.CanShrink = true;
			this.Remarks.KeepTogether = false;
			this.Remarks.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Remarks.Name = "Remarks";
			this.Remarks.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Remarks.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.Remarks.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Remarks.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Remarks.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Remarks.Style.Font.Italic = true;
			this.Remarks.Style.Font.Name = "Calibri";
			this.Remarks.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Remarks.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Remarks.StyleName = "Normal.TableBody";
			this.Remarks.Value = "= Fields.Remarks";
			// 
			// Description
			// 
			this.Description.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.IsHeaderHidden, False, True)"));
			this.Description.CanShrink = true;
			this.Description.KeepTogether = false;
			this.Description.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Description.Name = "Description";
			this.Description.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Description.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Description.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Description.Style.Font.Name = "Calibri";
			this.Description.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Description.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Description.StyleName = "Normal.TableBody";
			this.Description.Value = "= Fields.Description";
			// 
			// Icon
			// 
			this.Icon.Bindings.Add(new Telerik.Reporting.Binding("Height", "= IIf(Fields.IsHeaderHidden, \"0cm\", \"0.9cm\")"));
			this.Icon.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value=\"Itinerary\", True, False)"));
			this.Icon.Bindings.Add(new Telerik.Reporting.Binding("Value", resources.GetString("Icon.Bindings")));
			this.Icon.MimeType = "";
			this.Icon.Name = "Icon";
			this.Icon.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.9D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Icon.Sizing = Telerik.Reporting.Drawing.ImageSizeMode.ScaleProportional;
			this.Icon.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Icon.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Icon.Value = "";
			// 
			// ObjectDataSource
			// 
			this.ObjectDataSource.Name = "ObjectDataSource";
			// 
			// ConfirmationSubSubReport
			// 
			this.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= ReportItem.Parent.DataObject"));
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail});
			this.Name = "ConfirmationSubReport";
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "issuedDocumentType";
			reportParameter2.Name = "imagePath";
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(18D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.HtmlTextBox Footer;
		private Telerik.Reporting.HtmlTextBox Header1;
		private Telerik.Reporting.HtmlTextBox DateRange;
		private Telerik.Reporting.HtmlTextBox Remarks;
		private Telerik.Reporting.HtmlTextBox Description;
		private Telerik.Reporting.HtmlTextBox Header2;
		private Telerik.Reporting.PictureBox Icon;
		private Telerik.Reporting.ObjectDataSource ObjectDataSource;
    }
}