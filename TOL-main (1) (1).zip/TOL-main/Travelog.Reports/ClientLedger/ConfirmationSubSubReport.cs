using Telerik.Reporting;

namespace Travelog.Reports.ClientLedger {
	public partial class ConfirmationSubSubReport : TelerikReport {
		public ConfirmationSubSubReport() {
			InitializeComponent();
        }
    }
}