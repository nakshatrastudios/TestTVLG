namespace Travelog.Reports.ClientLedger {
	partial class QuoteSubSubReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup10 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup11 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup12 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup13 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup14 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup15 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup16 = new Telerik.Reporting.TableGroup();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.AirPassengerTable = new Telerik.Reporting.Table();
			this.AirPassengerPanel = new Telerik.Reporting.Panel();
			this.AirHeader = new Telerik.Reporting.TextBox();
			this.AirSegmentTable = new Telerik.Reporting.Table();
			this.AirSegmentPanel = new Telerik.Reporting.Panel();
			this.AirDetail2 = new Telerik.Reporting.TextBox();
			this.AirDetail3 = new Telerik.Reporting.TextBox();
			this.AirRemarks = new Telerik.Reporting.HtmlTextBox();
			this.AirDetail1 = new Telerik.Reporting.TextBox();
			this.AirFooter = new Telerik.Reporting.TextBox();
			this.AirPassenger = new Telerik.Reporting.TextBox();
			this.LandTable = new Telerik.Reporting.Table();
			this.LandPanel = new Telerik.Reporting.Panel();
			this.LandFooter = new Telerik.Reporting.TextBox();
			this.LandHeader = new Telerik.Reporting.TextBox();
			this.LandDetail1 = new Telerik.Reporting.TextBox();
			this.LandDetail3 = new Telerik.Reporting.TextBox();
			this.LandDetail4 = new Telerik.Reporting.TextBox();
			this.LandDetail5 = new Telerik.Reporting.TextBox();
			this.LandRemarks = new Telerik.Reporting.HtmlTextBox();
			this.ForeignCurrencyTable = new Telerik.Reporting.Table();
			this.ForeignCurrencyPanel = new Telerik.Reporting.Panel();
			this.ForeignCurrencyFooter = new Telerik.Reporting.TextBox();
			this.ForeignCurrencyHeader = new Telerik.Reporting.TextBox();
			this.ForeignCurrencyDetail2 = new Telerik.Reporting.TextBox();
			this.ForeignCurrencyDetail3 = new Telerik.Reporting.TextBox();
			this.ForeignCurrencyDetail1 = new Telerik.Reporting.TextBox();
			this.ForeignCurrencyRemarks = new Telerik.Reporting.HtmlTextBox();
			this.ServiceFeeTable = new Telerik.Reporting.Table();
			this.ServiceFeePanel = new Telerik.Reporting.Panel();
			this.ServiceFeeDetail3 = new Telerik.Reporting.TextBox();
			this.ServiceFeeFooter = new Telerik.Reporting.TextBox();
			this.ServiceFeeRemarks = new Telerik.Reporting.HtmlTextBox();
			this.ServiceFeeDetail1 = new Telerik.Reporting.TextBox();
			this.ServiceFeeDetail2 = new Telerik.Reporting.TextBox();
			this.ServiceFeeHeader = new Telerik.Reporting.TextBox();
			this.OtherInclusionTable = new Telerik.Reporting.Table();
			this.OtherInclusionPanel = new Telerik.Reporting.Panel();
			this.OtherInclusionFooter = new Telerik.Reporting.TextBox();
			this.OtherInclusionHeader = new Telerik.Reporting.TextBox();
			this.OtherInclusionDetail1 = new Telerik.Reporting.TextBox();
			this.OtherInclusionDetail2 = new Telerik.Reporting.TextBox();
			this.OtherInclusionDetail3 = new Telerik.Reporting.TextBox();
			this.OtherInclusionRemarks = new Telerik.Reporting.HtmlTextBox();
			this.InsuranceTable = new Telerik.Reporting.Table();
			this.InsurancePanel = new Telerik.Reporting.Panel();
			this.InsuranceFooter = new Telerik.Reporting.TextBox();
			this.InsuranceHeader = new Telerik.Reporting.TextBox();
			this.InsuranceDetail1 = new Telerik.Reporting.TextBox();
			this.InsuranceDetail2 = new Telerik.Reporting.TextBox();
			this.InsuranceDetail3 = new Telerik.Reporting.TextBox();
			this.InsuranceDetail4 = new Telerik.Reporting.TextBox();
			this.InsuranceRemarks = new Telerik.Reporting.HtmlTextBox();
			this.InsuranceDetail5 = new Telerik.Reporting.TextBox();
			this.InsurancePassenger = new Telerik.Reporting.TextBox();
			this.RemarkTable = new Telerik.Reporting.Table();
			this.RemarkPanel = new Telerik.Reporting.Panel();
			this.Remark = new Telerik.Reporting.HtmlTextBox();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// Detail
			// 
			this.Detail.CanShrink = true;
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(23.3D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AirPassengerTable,
            this.LandTable,
            this.ForeignCurrencyTable,
            this.ServiceFeeTable,
            this.OtherInclusionTable,
            this.InsuranceTable,
            this.RemarkTable});
			this.Detail.KeepTogether = false;
			this.Detail.Name = "Detail";
			// 
			// AirPassengerTable
			// 
			this.AirPassengerTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.QuoteSubReportAirPassenger"));
			this.AirPassengerTable.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.QuoteSubReportAirPassenger Is Null, False, True)"));
			this.AirPassengerTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18D)));
			this.AirPassengerTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Pixel(154.96D)));
			this.AirPassengerTable.Body.SetCellContent(0, 0, this.AirPassengerPanel);
			tableGroup3.Name = "tableGroup1";
			this.AirPassengerTable.ColumnGroups.Add(tableGroup3);
			this.AirPassengerTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AirPassengerPanel});
			this.AirPassengerTable.KeepTogether = false;
			this.AirPassengerTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AirPassengerTable.Name = "AirPassengerTable";
			tableGroup4.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup4.Name = "detailTableGroup";
			this.AirPassengerTable.RowGroups.Add(tableGroup4);
			this.AirPassengerTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(4.1D));
			// 
			// AirPassengerPanel
			// 
			this.AirPassengerPanel.CanShrink = true;
			this.AirPassengerPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AirHeader,
            this.AirSegmentTable,
            this.AirFooter,
            this.AirPassenger});
			this.AirPassengerPanel.KeepTogether = false;
			this.AirPassengerPanel.Name = "AirPassengerPanel";
			this.AirPassengerPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Pixel(154.96D));
			this.AirPassengerPanel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AirPassengerPanel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			// 
			// AirHeader
			// 
			this.AirHeader.CanShrink = true;
			this.AirHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AirHeader.Name = "AirHeader";
			this.AirHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AirHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AirHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AirHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AirHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AirHeader.Style.Font.Bold = true;
			this.AirHeader.Style.Font.Name = "Calibri";
			this.AirHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AirHeader.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AirHeader.StyleName = "Normal.TableHeader";
			this.AirHeader.Value = "= \"Flight Details\"";
			// 
			// AirSegmentTable
			// 
			this.AirSegmentTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.QuoteSubReportAirSegmentList"));
			this.AirSegmentTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18D)));
			this.AirSegmentTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(1.8D)));
			this.AirSegmentTable.Body.SetCellContent(0, 0, this.AirSegmentPanel);
			tableGroup1.Name = "tableGroup2";
			this.AirSegmentTable.ColumnGroups.Add(tableGroup1);
			this.AirSegmentTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AirSegmentPanel});
			this.AirSegmentTable.KeepTogether = false;
			this.AirSegmentTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.AirSegmentTable.Name = "AirSegmentTable";
			tableGroup2.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup2.Name = "detailTableGroup1";
			this.AirSegmentTable.RowGroups.Add(tableGroup2);
			this.AirSegmentTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			this.AirSegmentTable.Style.BorderColor.Default = System.Drawing.Color.Silver;
			// 
			// AirSegmentPanel
			// 
			this.AirSegmentPanel.CanShrink = true;
			this.AirSegmentPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AirDetail2,
            this.AirDetail3,
            this.AirRemarks,
            this.AirDetail1});
			this.AirSegmentPanel.Name = "AirSegmentPanel";
			this.AirSegmentPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			// 
			// AirDetail2
			// 
			this.AirDetail2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.Segments, \"\") = \"\", False, True)"));
			this.AirDetail2.CanShrink = true;
			this.AirDetail2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AirDetail2.Name = "AirDetail2";
			this.AirDetail2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AirDetail2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AirDetail2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AirDetail2.Style.Font.Bold = false;
			this.AirDetail2.Style.Font.Name = "Calibri";
			this.AirDetail2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AirDetail2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirDetail2.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AirDetail2.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AirDetail2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirDetail2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AirDetail2.StyleName = "Normal.TableBody";
			this.AirDetail2.Value = "= Fields.Segments";
			// 
			// AirDetail3
			// 
			this.AirDetail3.CanShrink = true;
			this.AirDetail3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AirDetail3.Name = "AirDetail3";
			this.AirDetail3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AirDetail3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AirDetail3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AirDetail3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AirDetail3.Style.Font.Bold = false;
			this.AirDetail3.Style.Font.Name = "Calibri";
			this.AirDetail3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AirDetail3.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirDetail3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirDetail3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AirDetail3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AirDetail3.StyleName = "Normal.TableBody";
			this.AirDetail3.Value = "= Fields.StartEndDate";
			// 
			// AirRemarks
			// 
			this.AirRemarks.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.Remarks, \"\") = \"\", False, True)"));
			this.AirRemarks.CanShrink = true;
			this.AirRemarks.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.AirRemarks.Name = "AirRemarks";
			this.AirRemarks.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AirRemarks.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AirRemarks.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AirRemarks.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AirRemarks.Style.Font.Italic = true;
			this.AirRemarks.Style.Font.Name = "Calibri";
			this.AirRemarks.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AirRemarks.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirRemarks.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirRemarks.Value = "= Fields.Remarks";
			// 
			// AirDetail1
			// 
			this.AirDetail1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.Flight, \"\") = \"\", False, True)"));
			this.AirDetail1.CanShrink = true;
			this.AirDetail1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AirDetail1.Name = "AirDetail1";
			this.AirDetail1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AirDetail1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AirDetail1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AirDetail1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AirDetail1.Style.Font.Bold = false;
			this.AirDetail1.Style.Font.Name = "Calibri";
			this.AirDetail1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AirDetail1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirDetail1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AirDetail1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AirDetail1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirDetail1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AirDetail1.StyleName = "Normal.TableBody";
			this.AirDetail1.Value = "= Fields.Flight";
			// 
			// AirFooter
			// 
			this.AirFooter.Bindings.Add(new Telerik.Reporting.Binding("Height", "= IIf(Fields.PackageNo = 0, \"0.1cm\", \"0.6cm\")"));
			this.AirFooter.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.AirFooter.Name = "AirFooter";
			this.AirFooter.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AirFooter.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AirFooter.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AirFooter.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AirFooter.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AirFooter.Style.Font.Bold = false;
			this.AirFooter.Style.Font.Name = "Calibri";
			this.AirFooter.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AirFooter.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirFooter.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirFooter.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AirFooter.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AirFooter.StyleName = "Normal.TableBody";
			this.AirFooter.Value = "= IIf(Fields.PackageNo = 0, Fields.Footer, \"\")";
			// 
			// AirPassenger
			// 
			this.AirPassenger.CanShrink = true;
			this.AirPassenger.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AirPassenger.Name = "AirPassenger";
			this.AirPassenger.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(17.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AirPassenger.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AirPassenger.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AirPassenger.Style.Font.Bold = false;
			this.AirPassenger.Style.Font.Name = "Calibri";
			this.AirPassenger.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AirPassenger.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirPassenger.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AirPassenger.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AirPassenger.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AirPassenger.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.AirPassenger.StyleName = "Normal.TableBody";
			this.AirPassenger.Value = "= \"Passenger(s): \" + Fields.PassengerNames";
			// 
			// LandTable
			// 
			this.LandTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.QuoteSubReportLand"));
			this.LandTable.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.QuoteSubReportLand Is Null, False, True)"));
			this.LandTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18D)));
			this.LandTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(4.1D)));
			this.LandTable.Body.SetCellContent(0, 0, this.LandPanel);
			tableGroup5.Name = "tableGroup1";
			this.LandTable.ColumnGroups.Add(tableGroup5);
			this.LandTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.LandPanel});
			this.LandTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.1D));
			this.LandTable.Name = "LandTable";
			tableGroup6.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup6.Name = "detailTableGroup";
			this.LandTable.RowGroups.Add(tableGroup6);
			this.LandTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(4.1D));
			// 
			// LandPanel
			// 
			this.LandPanel.CanShrink = true;
			this.LandPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.LandFooter,
            this.LandHeader,
            this.LandDetail1,
            this.LandDetail3,
            this.LandDetail4,
            this.LandDetail5,
            this.LandRemarks});
			this.LandPanel.KeepTogether = false;
			this.LandPanel.Name = "LandPanel";
			this.LandPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Pixel(680.31D), Telerik.Reporting.Drawing.Unit.Cm(4.1D));
			this.LandPanel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.LandPanel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			// 
			// LandFooter
			// 
			this.LandFooter.Bindings.Add(new Telerik.Reporting.Binding("Height", "= IIf(Fields.PackageNo = 0, \"0.1cm\", \"0.6cm\")"));
			this.LandFooter.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.LandFooter.Name = "LandFooter";
			this.LandFooter.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LandFooter.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.LandFooter.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.LandFooter.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.LandFooter.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.LandFooter.Style.Font.Bold = false;
			this.LandFooter.Style.Font.Name = "Calibri";
			this.LandFooter.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.LandFooter.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandFooter.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.LandFooter.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.LandFooter.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandFooter.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.LandFooter.StyleName = "Normal.TableBody";
			this.LandFooter.Value = "= IIf(Fields.PackageNo = 0, Fields.ServiceTypeRateBasisDescription, \"\")";
			// 
			// LandHeader
			// 
			this.LandHeader.CanShrink = true;
			this.LandHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.LandHeader.Name = "LandHeader";
			this.LandHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LandHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.LandHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.LandHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.LandHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.LandHeader.Style.Font.Bold = true;
			this.LandHeader.Style.Font.Name = "Calibri";
			this.LandHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.LandHeader.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.LandHeader.StyleName = "Normal.TableHeader";
			this.LandHeader.Value = "= Fields.TripLineType + \" Details\"";
			// 
			// LandDetail1
			// 
			this.LandDetail1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.SupplierName, \"\") = \"\", False, True)"));
			this.LandDetail1.CanShrink = true;
			this.LandDetail1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LandDetail1.Name = "LandDetail1";
			this.LandDetail1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LandDetail1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.LandDetail1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.LandDetail1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.LandDetail1.Style.Font.Bold = false;
			this.LandDetail1.Style.Font.Name = "Calibri";
			this.LandDetail1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.LandDetail1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandDetail1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.LandDetail1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.LandDetail1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandDetail1.StyleName = "Normal.TableBody";
			this.LandDetail1.Value = "{Fields.SupplierName}\r\n{Fields.SupplierAddress}";
			// 
			// LandDetail3
			// 
			this.LandDetail3.CanShrink = true;
			this.LandDetail3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LandDetail3.Name = "LandDetail3";
			this.LandDetail3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LandDetail3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.LandDetail3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.LandDetail3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.LandDetail3.Style.Font.Bold = false;
			this.LandDetail3.Style.Font.Name = "Calibri";
			this.LandDetail3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.LandDetail3.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandDetail3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandDetail3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.LandDetail3.StyleName = "Normal.TableBody";
			this.LandDetail3.Value = "= Fields.StartEndDate";
			// 
			// LandDetail4
			// 
			this.LandDetail4.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.SupplierServiceDescription, \"\") = \"\", False, True)"));
			this.LandDetail4.CanShrink = true;
			this.LandDetail4.Culture = new System.Globalization.CultureInfo("aa-ER");
			this.LandDetail4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.LandDetail4.Name = "LandDetail4";
			this.LandDetail4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LandDetail4.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.LandDetail4.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.LandDetail4.Style.Font.Name = "Calibri";
			this.LandDetail4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.LandDetail4.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandDetail4.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandDetail4.StyleName = "Normal.TableBody";
			this.LandDetail4.Value = "= Fields.SupplierServiceDescription";
			// 
			// LandDetail5
			// 
			this.LandDetail5.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.Comments, \"\") = \"\", False, True)"));
			this.LandDetail5.CanShrink = true;
			this.LandDetail5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			this.LandDetail5.Name = "LandDetail5";
			this.LandDetail5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LandDetail5.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.LandDetail5.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.LandDetail5.Style.Font.Bold = false;
			this.LandDetail5.Style.Font.Name = "Calibri";
			this.LandDetail5.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.LandDetail5.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandDetail5.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.LandDetail5.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.LandDetail5.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandDetail5.StyleName = "Normal.TableBody";
			this.LandDetail5.Value = "= Fields.Comments";
			// 
			// LandRemarks
			// 
			this.LandRemarks.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.Remarks, \"\") = \"\", False, True)"));
			this.LandRemarks.CanShrink = true;
			this.LandRemarks.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
			this.LandRemarks.Name = "LandRemarks";
			this.LandRemarks.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.LandRemarks.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.LandRemarks.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.LandRemarks.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.LandRemarks.Style.Font.Italic = true;
			this.LandRemarks.Style.Font.Name = "Calibri";
			this.LandRemarks.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.LandRemarks.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandRemarks.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.LandRemarks.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.LandRemarks.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.LandRemarks.Value = "= Fields.Remarks";
			// 
			// ForeignCurrencyTable
			// 
			this.ForeignCurrencyTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.QuoteSubReportForeignCurrency"));
			this.ForeignCurrencyTable.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.QuoteSubReportForeignCurrency Is Null, False, True)"));
			this.ForeignCurrencyTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18D)));
			this.ForeignCurrencyTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(3.5D)));
			this.ForeignCurrencyTable.Body.SetCellContent(0, 0, this.ForeignCurrencyPanel);
			tableGroup7.Name = "tableGroup1";
			this.ForeignCurrencyTable.ColumnGroups.Add(tableGroup7);
			this.ForeignCurrencyTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ForeignCurrencyPanel});
			this.ForeignCurrencyTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(12.9D));
			this.ForeignCurrencyTable.Name = "ForeignCurrencyTable";
			tableGroup8.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup8.Name = "detailTableGroup";
			this.ForeignCurrencyTable.RowGroups.Add(tableGroup8);
			this.ForeignCurrencyTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(3.5D));
			// 
			// ForeignCurrencyPanel
			// 
			this.ForeignCurrencyPanel.CanShrink = true;
			this.ForeignCurrencyPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ForeignCurrencyFooter,
            this.ForeignCurrencyHeader,
            this.ForeignCurrencyDetail2,
            this.ForeignCurrencyDetail3,
            this.ForeignCurrencyDetail1,
            this.ForeignCurrencyRemarks});
			this.ForeignCurrencyPanel.KeepTogether = false;
			this.ForeignCurrencyPanel.Name = "ForeignCurrencyPanel";
			this.ForeignCurrencyPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(3.5D));
			this.ForeignCurrencyPanel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ForeignCurrencyPanel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			// 
			// ForeignCurrencyFooter
			// 
			this.ForeignCurrencyFooter.Bindings.Add(new Telerik.Reporting.Binding("Height", "= IIf(Fields.PackageNo = 0, \"0.1cm\", \"0.6cm\")"));
			this.ForeignCurrencyFooter.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
			this.ForeignCurrencyFooter.Name = "ForeignCurrencyFooter";
			this.ForeignCurrencyFooter.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ForeignCurrencyFooter.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ForeignCurrencyFooter.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ForeignCurrencyFooter.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ForeignCurrencyFooter.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ForeignCurrencyFooter.Style.Font.Bold = false;
			this.ForeignCurrencyFooter.Style.Font.Name = "Calibri";
			this.ForeignCurrencyFooter.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ForeignCurrencyFooter.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyFooter.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ForeignCurrencyFooter.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ForeignCurrencyFooter.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyFooter.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ForeignCurrencyFooter.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ForeignCurrencyFooter.StyleName = "Normal.TableBody";
			this.ForeignCurrencyFooter.Value = "= IIf(Fields.PackageNo = 0, \"Total: \" + Format(\"{0:c2}\", Fields.CostToClient), \"\"" +
    ")";
			// 
			// ForeignCurrencyHeader
			// 
			this.ForeignCurrencyHeader.CanShrink = true;
			this.ForeignCurrencyHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ForeignCurrencyHeader.Name = "ForeignCurrencyHeader";
			this.ForeignCurrencyHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ForeignCurrencyHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ForeignCurrencyHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ForeignCurrencyHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ForeignCurrencyHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ForeignCurrencyHeader.Style.Font.Bold = true;
			this.ForeignCurrencyHeader.Style.Font.Name = "Calibri";
			this.ForeignCurrencyHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ForeignCurrencyHeader.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ForeignCurrencyHeader.StyleName = "Normal.TableHeader";
			this.ForeignCurrencyHeader.Value = "Foreign Currency";
			// 
			// ForeignCurrencyDetail2
			// 
			this.ForeignCurrencyDetail2.CanShrink = true;
			this.ForeignCurrencyDetail2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.ForeignCurrencyDetail2.Name = "ForeignCurrencyDetail2";
			this.ForeignCurrencyDetail2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ForeignCurrencyDetail2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ForeignCurrencyDetail2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ForeignCurrencyDetail2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ForeignCurrencyDetail2.Style.Font.Bold = false;
			this.ForeignCurrencyDetail2.Style.Font.Name = "Calibri";
			this.ForeignCurrencyDetail2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ForeignCurrencyDetail2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyDetail2.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ForeignCurrencyDetail2.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ForeignCurrencyDetail2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyDetail2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ForeignCurrencyDetail2.StyleName = "Normal.TableBody";
			this.ForeignCurrencyDetail2.Value = "= Fields.Description";
			// 
			// ForeignCurrencyDetail3
			// 
			this.ForeignCurrencyDetail3.CanShrink = true;
			this.ForeignCurrencyDetail3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.ForeignCurrencyDetail3.Name = "ForeignCurrencyDetail3";
			this.ForeignCurrencyDetail3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ForeignCurrencyDetail3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ForeignCurrencyDetail3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ForeignCurrencyDetail3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ForeignCurrencyDetail3.Style.Font.Bold = false;
			this.ForeignCurrencyDetail3.Style.Font.Name = "Calibri";
			this.ForeignCurrencyDetail3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ForeignCurrencyDetail3.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyDetail3.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ForeignCurrencyDetail3.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ForeignCurrencyDetail3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyDetail3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ForeignCurrencyDetail3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ForeignCurrencyDetail3.StyleName = "Normal.TableBody";
			this.ForeignCurrencyDetail3.Value = "= IIf(Fields.PackageNo = 0, Format(\"{0:c2}\", Fields.CostToClient), \"\")";
			// 
			// ForeignCurrencyDetail1
			// 
			this.ForeignCurrencyDetail1.CanShrink = true;
			this.ForeignCurrencyDetail1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ForeignCurrencyDetail1.Name = "ForeignCurrencyDetail1";
			this.ForeignCurrencyDetail1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ForeignCurrencyDetail1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ForeignCurrencyDetail1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ForeignCurrencyDetail1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ForeignCurrencyDetail1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ForeignCurrencyDetail1.Style.Font.Bold = false;
			this.ForeignCurrencyDetail1.Style.Font.Name = "Calibri";
			this.ForeignCurrencyDetail1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ForeignCurrencyDetail1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyDetail1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyDetail1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ForeignCurrencyDetail1.StyleName = "Normal.TableBody";
			this.ForeignCurrencyDetail1.Value = "= Fields.SupplierName";
			// 
			// ForeignCurrencyRemarks
			// 
			this.ForeignCurrencyRemarks.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.Remarks, \"\") = \"\", False, True)"));
			this.ForeignCurrencyRemarks.CanShrink = true;
			this.ForeignCurrencyRemarks.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			this.ForeignCurrencyRemarks.Name = "ForeignCurrencyRemarks";
			this.ForeignCurrencyRemarks.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ForeignCurrencyRemarks.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ForeignCurrencyRemarks.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ForeignCurrencyRemarks.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ForeignCurrencyRemarks.Style.Font.Italic = true;
			this.ForeignCurrencyRemarks.Style.Font.Name = "Calibri";
			this.ForeignCurrencyRemarks.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ForeignCurrencyRemarks.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyRemarks.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ForeignCurrencyRemarks.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ForeignCurrencyRemarks.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ForeignCurrencyRemarks.Value = "= Fields.Remarks";
			// 
			// ServiceFeeTable
			// 
			this.ServiceFeeTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.QuoteSubReportServiceFee"));
			this.ServiceFeeTable.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.QuoteSubReportServiceFee Is Null, False, True)"));
			this.ServiceFeeTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18D)));
			this.ServiceFeeTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(2.9D)));
			this.ServiceFeeTable.Body.SetCellContent(0, 0, this.ServiceFeePanel);
			tableGroup9.Name = "tableGroup1";
			this.ServiceFeeTable.ColumnGroups.Add(tableGroup9);
			this.ServiceFeeTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ServiceFeePanel});
			this.ServiceFeeTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(16.4D));
			this.ServiceFeeTable.Name = "ServiceFeeTable";
			tableGroup10.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup10.Name = "detailTableGroup";
			this.ServiceFeeTable.RowGroups.Add(tableGroup10);
			this.ServiceFeeTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(2.9D));
			// 
			// ServiceFeePanel
			// 
			this.ServiceFeePanel.CanShrink = true;
			this.ServiceFeePanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ServiceFeeDetail3,
            this.ServiceFeeFooter,
            this.ServiceFeeRemarks,
            this.ServiceFeeDetail1,
            this.ServiceFeeDetail2,
            this.ServiceFeeHeader});
			this.ServiceFeePanel.KeepTogether = false;
			this.ServiceFeePanel.Name = "ServiceFeePanel";
			this.ServiceFeePanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(2.9D));
			this.ServiceFeePanel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ServiceFeePanel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			// 
			// ServiceFeeDetail3
			// 
			this.ServiceFeeDetail3.CanShrink = true;
			this.ServiceFeeDetail3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ServiceFeeDetail3.Name = "ServiceFeeDetail3";
			this.ServiceFeeDetail3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ServiceFeeDetail3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ServiceFeeDetail3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ServiceFeeDetail3.Style.Font.Bold = false;
			this.ServiceFeeDetail3.Style.Font.Name = "Calibri";
			this.ServiceFeeDetail3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ServiceFeeDetail3.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeDetail3.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceFeeDetail3.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceFeeDetail3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeDetail3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ServiceFeeDetail3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ServiceFeeDetail3.StyleName = "Normal.TableBody";
			this.ServiceFeeDetail3.Value = "= IIf(Fields.PackageNo = 0, Format(\"{0:c2}\", Fields.CostToClient), \"\")";
			// 
			// ServiceFeeFooter
			// 
			this.ServiceFeeFooter.Bindings.Add(new Telerik.Reporting.Binding("Height", "= IIf(Fields.PackageNo = 0, \"0.1cm\", \"0.6cm\")"));
			this.ServiceFeeFooter.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			this.ServiceFeeFooter.Name = "ServiceFeeFooter";
			this.ServiceFeeFooter.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ServiceFeeFooter.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ServiceFeeFooter.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ServiceFeeFooter.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ServiceFeeFooter.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ServiceFeeFooter.Style.Font.Bold = false;
			this.ServiceFeeFooter.Style.Font.Name = "Calibri";
			this.ServiceFeeFooter.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ServiceFeeFooter.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeFooter.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceFeeFooter.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceFeeFooter.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeFooter.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ServiceFeeFooter.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ServiceFeeFooter.StyleName = "Normal.TableBody";
			this.ServiceFeeFooter.Value = "= IIf(Fields.PackageNo = 0, \"Total: \" + Format(\"{0:c2}\", Fields.CostToClient), \"\"" +
    ")";
			// 
			// ServiceFeeRemarks
			// 
			this.ServiceFeeRemarks.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.Remarks, \"\") = \"\", False, True)"));
			this.ServiceFeeRemarks.CanShrink = true;
			this.ServiceFeeRemarks.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.ServiceFeeRemarks.Name = "ServiceFeeRemarks";
			this.ServiceFeeRemarks.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ServiceFeeRemarks.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ServiceFeeRemarks.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ServiceFeeRemarks.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ServiceFeeRemarks.Style.Font.Italic = true;
			this.ServiceFeeRemarks.Style.Font.Name = "Calibri";
			this.ServiceFeeRemarks.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ServiceFeeRemarks.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeRemarks.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeRemarks.Value = "= Fields.Remarks";
			// 
			// ServiceFeeDetail1
			// 
			this.ServiceFeeDetail1.CanShrink = true;
			this.ServiceFeeDetail1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ServiceFeeDetail1.Name = "ServiceFeeDetail1";
			this.ServiceFeeDetail1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ServiceFeeDetail1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ServiceFeeDetail1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ServiceFeeDetail1.Style.Font.Bold = false;
			this.ServiceFeeDetail1.Style.Font.Name = "Calibri";
			this.ServiceFeeDetail1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ServiceFeeDetail1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeDetail1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceFeeDetail1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceFeeDetail1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeDetail1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ServiceFeeDetail1.StyleName = "Normal.TableBody";
			this.ServiceFeeDetail1.Value = "= Fields.ServiceFee";
			// 
			// ServiceFeeDetail2
			// 
			this.ServiceFeeDetail2.CanShrink = true;
			this.ServiceFeeDetail2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ServiceFeeDetail2.Name = "ServiceFeeDetail2";
			this.ServiceFeeDetail2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ServiceFeeDetail2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ServiceFeeDetail2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ServiceFeeDetail2.Style.Font.Bold = false;
			this.ServiceFeeDetail2.Style.Font.Name = "Calibri";
			this.ServiceFeeDetail2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ServiceFeeDetail2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeDetail2.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceFeeDetail2.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ServiceFeeDetail2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeDetail2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.ServiceFeeDetail2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ServiceFeeDetail2.StyleName = "Normal.TableBody";
			this.ServiceFeeDetail2.Value = "= IIf(Fields.PackageNo = 0, Fields.Description, \"\")";
			// 
			// ServiceFeeHeader
			// 
			this.ServiceFeeHeader.CanShrink = true;
			this.ServiceFeeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ServiceFeeHeader.Name = "ServiceFeeHeader";
			this.ServiceFeeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ServiceFeeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ServiceFeeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ServiceFeeHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.ServiceFeeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ServiceFeeHeader.Style.Font.Bold = true;
			this.ServiceFeeHeader.Style.Font.Name = "Calibri";
			this.ServiceFeeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ServiceFeeHeader.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ServiceFeeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ServiceFeeHeader.StyleName = "Normal.TableHeader";
			this.ServiceFeeHeader.Value = "Service Fees";
			// 
			// OtherInclusionTable
			// 
			this.OtherInclusionTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.QuoteSubReportOtherInclusion"));
			this.OtherInclusionTable.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.QuoteSubReportOtherInclusion Is Null, False, True)"));
			this.OtherInclusionTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18D)));
			this.OtherInclusionTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(2.9D)));
			this.OtherInclusionTable.Body.SetCellContent(0, 0, this.OtherInclusionPanel);
			tableGroup11.Name = "tableGroup1";
			this.OtherInclusionTable.ColumnGroups.Add(tableGroup11);
			this.OtherInclusionTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.OtherInclusionPanel});
			this.OtherInclusionTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(19.3D));
			this.OtherInclusionTable.Name = "OtherInclusionTable";
			tableGroup12.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup12.Name = "detailTableGroup";
			this.OtherInclusionTable.RowGroups.Add(tableGroup12);
			this.OtherInclusionTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(2.9D));
			// 
			// OtherInclusionPanel
			// 
			this.OtherInclusionPanel.CanShrink = true;
			this.OtherInclusionPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.OtherInclusionFooter,
            this.OtherInclusionHeader,
            this.OtherInclusionDetail1,
            this.OtherInclusionDetail2,
            this.OtherInclusionDetail3,
            this.OtherInclusionRemarks});
			this.OtherInclusionPanel.KeepTogether = false;
			this.OtherInclusionPanel.Name = "OtherInclusionPanel";
			this.OtherInclusionPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(2.9D));
			this.OtherInclusionPanel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.OtherInclusionPanel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			// 
			// OtherInclusionFooter
			// 
			this.OtherInclusionFooter.Bindings.Add(new Telerik.Reporting.Binding("Height", "= IIf(Fields.PackageNo = 0, \"0.1cm\", \"0.6cm\")"));
			this.OtherInclusionFooter.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			this.OtherInclusionFooter.Name = "OtherInclusionFooter";
			this.OtherInclusionFooter.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OtherInclusionFooter.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.OtherInclusionFooter.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.OtherInclusionFooter.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.OtherInclusionFooter.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.OtherInclusionFooter.Style.Font.Bold = false;
			this.OtherInclusionFooter.Style.Font.Name = "Calibri";
			this.OtherInclusionFooter.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.OtherInclusionFooter.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionFooter.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OtherInclusionFooter.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OtherInclusionFooter.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionFooter.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.OtherInclusionFooter.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.OtherInclusionFooter.StyleName = "Normal.TableBody";
			this.OtherInclusionFooter.Value = "= IIf(Fields.PackageNo = 0, Fields.Footer, \"\")";
			// 
			// OtherInclusionHeader
			// 
			this.OtherInclusionHeader.CanShrink = true;
			this.OtherInclusionHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.OtherInclusionHeader.Name = "OtherInclusionHeader";
			this.OtherInclusionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OtherInclusionHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.OtherInclusionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.OtherInclusionHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.OtherInclusionHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.OtherInclusionHeader.Style.Font.Bold = true;
			this.OtherInclusionHeader.Style.Font.Name = "Calibri";
			this.OtherInclusionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.OtherInclusionHeader.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.OtherInclusionHeader.StyleName = "Normal.TableHeader";
			this.OtherInclusionHeader.Value = "Other Inclusions";
			// 
			// OtherInclusionDetail1
			// 
			this.OtherInclusionDetail1.CanShrink = true;
			this.OtherInclusionDetail1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OtherInclusionDetail1.Name = "OtherInclusionDetail1";
			this.OtherInclusionDetail1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OtherInclusionDetail1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.OtherInclusionDetail1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.OtherInclusionDetail1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.OtherInclusionDetail1.Style.Font.Bold = false;
			this.OtherInclusionDetail1.Style.Font.Name = "Calibri";
			this.OtherInclusionDetail1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.OtherInclusionDetail1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionDetail1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OtherInclusionDetail1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OtherInclusionDetail1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionDetail1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.OtherInclusionDetail1.StyleName = "Normal.TableBody";
			this.OtherInclusionDetail1.Value = "= Fields.Comments";
			// 
			// OtherInclusionDetail2
			// 
			this.OtherInclusionDetail2.CanShrink = true;
			this.OtherInclusionDetail2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OtherInclusionDetail2.Name = "OtherInclusionDetail2";
			this.OtherInclusionDetail2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OtherInclusionDetail2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.OtherInclusionDetail2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.OtherInclusionDetail2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.OtherInclusionDetail2.Style.Font.Bold = false;
			this.OtherInclusionDetail2.Style.Font.Name = "Calibri";
			this.OtherInclusionDetail2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.OtherInclusionDetail2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionDetail2.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OtherInclusionDetail2.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OtherInclusionDetail2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionDetail2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.OtherInclusionDetail2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.OtherInclusionDetail2.StyleName = "Normal.TableBody";
			this.OtherInclusionDetail2.Value = "= IIf(Fields.PackageNo = 0, Fields.Description, \"\")";
			// 
			// OtherInclusionDetail3
			// 
			this.OtherInclusionDetail3.CanShrink = true;
			this.OtherInclusionDetail3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OtherInclusionDetail3.Name = "OtherInclusionDetail3";
			this.OtherInclusionDetail3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OtherInclusionDetail3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.OtherInclusionDetail3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.OtherInclusionDetail3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.OtherInclusionDetail3.Style.Font.Bold = false;
			this.OtherInclusionDetail3.Style.Font.Name = "Calibri";
			this.OtherInclusionDetail3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.OtherInclusionDetail3.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionDetail3.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OtherInclusionDetail3.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OtherInclusionDetail3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionDetail3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.OtherInclusionDetail3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.OtherInclusionDetail3.StyleName = "Normal.TableHeader";
			this.OtherInclusionDetail3.Value = "= IIf(Fields.PackageNo = 0, Format(\"{0:c2}\", Fields.CostToClient), \"\")";
			// 
			// OtherInclusionRemarks
			// 
			this.OtherInclusionRemarks.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.Remarks, \"\") = \"\", False, True)"));
			this.OtherInclusionRemarks.CanShrink = true;
			this.OtherInclusionRemarks.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.OtherInclusionRemarks.Name = "OtherInclusionRemarks";
			this.OtherInclusionRemarks.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.OtherInclusionRemarks.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.OtherInclusionRemarks.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.OtherInclusionRemarks.Style.Font.Italic = true;
			this.OtherInclusionRemarks.Style.Font.Name = "Calibri";
			this.OtherInclusionRemarks.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.OtherInclusionRemarks.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionRemarks.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OtherInclusionRemarks.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.OtherInclusionRemarks.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.OtherInclusionRemarks.Value = "= Fields.Remarks";
			// 
			// InsuranceTable
			// 
			this.InsuranceTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.QuoteSubReportInsurance"));
			this.InsuranceTable.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.QuoteSubReportInsurance Is Null, False, True)"));
			this.InsuranceTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18D)));
			this.InsuranceTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(4.7D)));
			this.InsuranceTable.Body.SetCellContent(0, 0, this.InsurancePanel);
			tableGroup13.Name = "tableGroup1";
			this.InsuranceTable.ColumnGroups.Add(tableGroup13);
			this.InsuranceTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.InsurancePanel});
			this.InsuranceTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(8.2D));
			this.InsuranceTable.Name = "InsuranceTable";
			tableGroup14.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup14.Name = "detailTableGroup";
			this.InsuranceTable.RowGroups.Add(tableGroup14);
			this.InsuranceTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(4.7D));
			// 
			// InsurancePanel
			// 
			this.InsurancePanel.CanShrink = true;
			this.InsurancePanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.InsuranceFooter,
            this.InsuranceHeader,
            this.InsuranceDetail1,
            this.InsuranceDetail2,
            this.InsuranceDetail3,
            this.InsuranceDetail4,
            this.InsuranceRemarks,
            this.InsuranceDetail5,
            this.InsurancePassenger});
			this.InsurancePanel.KeepTogether = false;
			this.InsurancePanel.Name = "InsurancePanel";
			this.InsurancePanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Pixel(680.31D), Telerik.Reporting.Drawing.Unit.Pixel(177.64D));
			this.InsurancePanel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.InsurancePanel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			// 
			// InsuranceFooter
			// 
			this.InsuranceFooter.Bindings.Add(new Telerik.Reporting.Binding("Height", "= IIf(Fields.PackageNo = 0, \"0.1cm\", \"0.6cm\")"));
			this.InsuranceFooter.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
			this.InsuranceFooter.Name = "InsuranceFooter";
			this.InsuranceFooter.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.InsuranceFooter.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.InsuranceFooter.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.InsuranceFooter.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.InsuranceFooter.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.InsuranceFooter.Style.Font.Bold = false;
			this.InsuranceFooter.Style.Font.Name = "Calibri";
			this.InsuranceFooter.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.InsuranceFooter.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceFooter.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceFooter.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceFooter.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceFooter.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.InsuranceFooter.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.InsuranceFooter.StyleName = "Normal.TableBody";
			this.InsuranceFooter.Value = "= IIf(Fields.PackageNo = 0, Fields.TotalAmountDescription, \"\")";
			// 
			// InsuranceHeader
			// 
			this.InsuranceHeader.CanShrink = true;
			this.InsuranceHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.InsuranceHeader.Name = "InsuranceHeader";
			this.InsuranceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.InsuranceHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.InsuranceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.InsuranceHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.InsuranceHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.InsuranceHeader.Style.Font.Bold = true;
			this.InsuranceHeader.Style.Font.Name = "Calibri";
			this.InsuranceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.InsuranceHeader.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.InsuranceHeader.StyleName = "Normal.TableHeader";
			this.InsuranceHeader.Value = "= \"Insurance Details\"";
			// 
			// InsuranceDetail1
			// 
			this.InsuranceDetail1.CanShrink = true;
			this.InsuranceDetail1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.InsuranceDetail1.Name = "InsuranceDetail1";
			this.InsuranceDetail1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.InsuranceDetail1.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.InsuranceDetail1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.InsuranceDetail1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.InsuranceDetail1.Style.Font.Bold = false;
			this.InsuranceDetail1.Style.Font.Name = "Calibri";
			this.InsuranceDetail1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.InsuranceDetail1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceDetail1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceDetail1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceDetail1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceDetail1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.InsuranceDetail1.StyleName = "Normal.TableBody";
			this.InsuranceDetail1.Value = "= Fields.SupplierName";
			// 
			// InsuranceDetail2
			// 
			this.InsuranceDetail2.CanShrink = true;
			this.InsuranceDetail2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			this.InsuranceDetail2.Name = "InsuranceDetail2";
			this.InsuranceDetail2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.InsuranceDetail2.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.InsuranceDetail2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.InsuranceDetail2.Style.Font.Bold = false;
			this.InsuranceDetail2.Style.Font.Name = "Calibri";
			this.InsuranceDetail2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.InsuranceDetail2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceDetail2.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceDetail2.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceDetail2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceDetail2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.InsuranceDetail2.StyleName = "Normal.TableBody";
			this.InsuranceDetail2.Value = "= Fields.PolicyType";
			// 
			// InsuranceDetail3
			// 
			this.InsuranceDetail3.CanShrink = true;
			this.InsuranceDetail3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
			this.InsuranceDetail3.Name = "InsuranceDetail3";
			this.InsuranceDetail3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.InsuranceDetail3.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.InsuranceDetail3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.InsuranceDetail3.Style.Font.Bold = false;
			this.InsuranceDetail3.Style.Font.Name = "Calibri";
			this.InsuranceDetail3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.InsuranceDetail3.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceDetail3.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceDetail3.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceDetail3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceDetail3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.InsuranceDetail3.StyleName = "Normal.TableBody";
			this.InsuranceDetail3.Value = "= Fields.Coverage";
			// 
			// InsuranceDetail4
			// 
			this.InsuranceDetail4.CanShrink = true;
			this.InsuranceDetail4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			this.InsuranceDetail4.Name = "InsuranceDetail4";
			this.InsuranceDetail4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.InsuranceDetail4.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.InsuranceDetail4.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.InsuranceDetail4.Style.Font.Bold = false;
			this.InsuranceDetail4.Style.Font.Name = "Calibri";
			this.InsuranceDetail4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.InsuranceDetail4.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceDetail4.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceDetail4.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceDetail4.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceDetail4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.InsuranceDetail4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.InsuranceDetail4.StyleName = "Normal.TableBody";
			this.InsuranceDetail4.Value = "= Fields.Plan";
			// 
			// InsuranceRemarks
			// 
			this.InsuranceRemarks.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.Remarks, \"\") = \"\", False, True)"));
			this.InsuranceRemarks.CanShrink = true;
			this.InsuranceRemarks.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
			this.InsuranceRemarks.Name = "InsuranceRemarks";
			this.InsuranceRemarks.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.InsuranceRemarks.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.InsuranceRemarks.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
			this.InsuranceRemarks.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.InsuranceRemarks.Style.Font.Italic = true;
			this.InsuranceRemarks.Style.Font.Name = "Calibri";
			this.InsuranceRemarks.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.InsuranceRemarks.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceRemarks.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceRemarks.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceRemarks.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceRemarks.Value = "= Fields.Remarks";
			// 
			// InsuranceDetail5
			// 
			this.InsuranceDetail5.CanShrink = true;
			this.InsuranceDetail5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.5D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.InsuranceDetail5.Name = "InsuranceDetail5";
			this.InsuranceDetail5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.InsuranceDetail5.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.InsuranceDetail5.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.InsuranceDetail5.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.InsuranceDetail5.Style.Font.Bold = false;
			this.InsuranceDetail5.Style.Font.Name = "Calibri";
			this.InsuranceDetail5.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.InsuranceDetail5.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceDetail5.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceDetail5.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsuranceDetail5.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsuranceDetail5.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.InsuranceDetail5.StyleName = "Normal.TableBody";
			this.InsuranceDetail5.Value = "= Fields.StartEndDate";
			// 
			// InsurancePassenger
			// 
			this.InsurancePassenger.CanShrink = true;
			this.InsurancePassenger.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.InsurancePassenger.Name = "InsurancePassenger";
			this.InsurancePassenger.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.InsurancePassenger.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.InsurancePassenger.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.InsurancePassenger.Style.Font.Bold = false;
			this.InsurancePassenger.Style.Font.Name = "Calibri";
			this.InsurancePassenger.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.InsurancePassenger.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsurancePassenger.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsurancePassenger.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.InsurancePassenger.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.InsurancePassenger.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.InsurancePassenger.StyleName = "Normal.TableBody";
			this.InsurancePassenger.Value = "= IIf(Fields.PassengerNames = \"\", \"\", \"Passenger(s): \" + Fields.PassengerNames)";
			// 
			// RemarkTable
			// 
			this.RemarkTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.QuoteSubReportRemark"));
			this.RemarkTable.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.QuoteSubReportRemark Is Null, False, True)"));
			this.RemarkTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18D)));
			this.RemarkTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Pixel(41.57D)));
			this.RemarkTable.Body.SetCellContent(0, 0, this.RemarkPanel);
			tableGroup15.Name = "tableGroup1";
			this.RemarkTable.ColumnGroups.Add(tableGroup15);
			this.RemarkTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.RemarkPanel});
			this.RemarkTable.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(22.2D));
			this.RemarkTable.Name = "RemarkTable";
			tableGroup16.Groupings.Add(new Telerik.Reporting.Grouping(null));
			tableGroup16.Name = "detailTableGroup";
			this.RemarkTable.RowGroups.Add(tableGroup16);
			this.RemarkTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1.1D));
			// 
			// RemarkPanel
			// 
			this.RemarkPanel.CanShrink = true;
			this.RemarkPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Remark});
			this.RemarkPanel.KeepTogether = false;
			this.RemarkPanel.Name = "RemarkPanel";
			this.RemarkPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Pixel(41.58D));
			this.RemarkPanel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.RemarkPanel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			// 
			// Remark
			// 
			this.Remark.CanShrink = true;
			this.Remark.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Remark.Name = "Remark";
			this.Remark.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Remark.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.Remark.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Remark.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Remark.Style.Font.Italic = true;
			this.Remark.Style.Font.Name = "Calibri";
			this.Remark.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Remark.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Remark.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Remark.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Remark.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Remark.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.Remark.StyleName = "Normal.TableBody";
			this.Remark.Value = "= Fields.Remark";
			// 
			// QuoteSubSubReport
			// 
			this.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= ReportItem.Parent.DataObject"));
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Detail});
			this.Name = "QuoteSubSubReport";
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(18D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.Table AirPassengerTable;
		private Telerik.Reporting.Panel AirPassengerPanel;
		private Telerik.Reporting.Table AirSegmentTable;
		private Telerik.Reporting.Panel AirSegmentPanel;
		private Telerik.Reporting.TextBox AirDetail2;
		private Telerik.Reporting.TextBox AirDetail3;
		private Telerik.Reporting.TextBox AirFooter;
		private Telerik.Reporting.TextBox AirHeader;
		private Telerik.Reporting.HtmlTextBox AirRemarks;
		private Telerik.Reporting.TextBox AirDetail1;
		private Telerik.Reporting.Table RemarkTable;
		private Telerik.Reporting.Panel RemarkPanel;
		private Telerik.Reporting.TextBox AirPassenger;
		private Telerik.Reporting.Table LandTable;
		private Telerik.Reporting.Panel LandPanel;
		private Telerik.Reporting.TextBox LandFooter;
		private Telerik.Reporting.TextBox LandHeader;
		private Telerik.Reporting.TextBox LandDetail1;
		private Telerik.Reporting.TextBox LandDetail3;
		private Telerik.Reporting.TextBox LandDetail4;
		private Telerik.Reporting.TextBox LandDetail5;
		private Telerik.Reporting.HtmlTextBox LandRemarks;
		private Telerik.Reporting.Table ForeignCurrencyTable;
		private Telerik.Reporting.Panel ForeignCurrencyPanel;
		private Telerik.Reporting.TextBox ForeignCurrencyFooter;
		private Telerik.Reporting.TextBox ForeignCurrencyHeader;
		private Telerik.Reporting.TextBox ForeignCurrencyDetail2;
		private Telerik.Reporting.TextBox ForeignCurrencyDetail3;
		private Telerik.Reporting.TextBox ForeignCurrencyDetail1;
		private Telerik.Reporting.HtmlTextBox ForeignCurrencyRemarks;
		private Telerik.Reporting.Table ServiceFeeTable;
		private Telerik.Reporting.Panel ServiceFeePanel;
		private Telerik.Reporting.TextBox ServiceFeeDetail3;
		private Telerik.Reporting.TextBox ServiceFeeFooter;
		private Telerik.Reporting.HtmlTextBox ServiceFeeRemarks;
		private Telerik.Reporting.TextBox ServiceFeeDetail1;
		private Telerik.Reporting.TextBox ServiceFeeDetail2;
		private Telerik.Reporting.TextBox ServiceFeeHeader;
		private Telerik.Reporting.Table OtherInclusionTable;
		private Telerik.Reporting.Panel OtherInclusionPanel;
		private Telerik.Reporting.TextBox OtherInclusionFooter;
		private Telerik.Reporting.TextBox OtherInclusionHeader;
		private Telerik.Reporting.TextBox OtherInclusionDetail1;
		private Telerik.Reporting.TextBox OtherInclusionDetail2;
		private Telerik.Reporting.TextBox OtherInclusionDetail3;
		private Telerik.Reporting.HtmlTextBox OtherInclusionRemarks;
		private Telerik.Reporting.Table InsuranceTable;
		private Telerik.Reporting.Panel InsurancePanel;
		private Telerik.Reporting.TextBox InsuranceFooter;
		private Telerik.Reporting.TextBox InsuranceHeader;
		private Telerik.Reporting.TextBox InsuranceDetail1;
		private Telerik.Reporting.TextBox InsuranceDetail2;
		private Telerik.Reporting.TextBox InsuranceDetail3;
		private Telerik.Reporting.TextBox InsuranceDetail4;
		private Telerik.Reporting.HtmlTextBox InsuranceRemarks;
		private Telerik.Reporting.TextBox InsuranceDetail5;
		private Telerik.Reporting.TextBox InsurancePassenger;
		private Telerik.Reporting.HtmlTextBox Remark;
	}
}