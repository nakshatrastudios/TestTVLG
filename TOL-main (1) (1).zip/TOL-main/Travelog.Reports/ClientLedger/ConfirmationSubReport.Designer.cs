namespace Travelog.Reports.ClientLedger {
	partial class ConfirmationSubReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
            Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
            Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
            Telerik.Reporting.Group group3 = new Telerik.Reporting.Group();
            Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
            this.GroupFooterSection3 = new Telerik.Reporting.GroupFooterSection();
            this.RemarksAfter = new Telerik.Reporting.HtmlTextBox();
            this.GroupHeaderSection3 = new Telerik.Reporting.GroupHeaderSection();
            this.GroupFooterSection2 = new Telerik.Reporting.GroupFooterSection();
            this.TotalsPanel = new Telerik.Reporting.Panel();
            this.TotalsHeader = new Telerik.Reporting.TextBox();
            this.PackageGrandTotal1 = new Telerik.Reporting.TextBox();
            this.PackageGrandTotal2 = new Telerik.Reporting.TextBox();
            this.Total2 = new Telerik.Reporting.TextBox();
            this.TaxTotal2 = new Telerik.Reporting.TextBox();
            this.TotalDiscount2 = new Telerik.Reporting.TextBox();
            this.GrandTotal2 = new Telerik.Reporting.TextBox();
            this.GrandTotal1 = new Telerik.Reporting.TextBox();
            this.TotalDiscount1 = new Telerik.Reporting.TextBox();
            this.TaxTotal1 = new Telerik.Reporting.TextBox();
            this.Total1 = new Telerik.Reporting.TextBox();
            this.PackageGrandTotal3 = new Telerik.Reporting.TextBox();
            this.Total3 = new Telerik.Reporting.TextBox();
            this.TaxAppliesLabel = new Telerik.Reporting.TextBox();
            this.UnassignedTotal3 = new Telerik.Reporting.TextBox();
            this.GroupHeaderSection2 = new Telerik.Reporting.GroupHeaderSection();
            this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
            this.PackageTotal1 = new Telerik.Reporting.TextBox();
            this.PackageTotal2 = new Telerik.Reporting.TextBox();
            this.AgentCommissionTotal1 = new Telerik.Reporting.TextBox();
            this.AgentCommissionTotal2 = new Telerik.Reporting.TextBox();
            this.DiscountTotal1 = new Telerik.Reporting.TextBox();
            this.DiscountTotal2 = new Telerik.Reporting.TextBox();
            this.PackageTotal3 = new Telerik.Reporting.TextBox();
            this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
            this.PackageLabel = new Telerik.Reporting.TextBox();
            this.RemarksBefore = new Telerik.Reporting.HtmlTextBox();
            this.Detail = new Telerik.Reporting.DetailSection();
            this.DetailList = new Telerik.Reporting.Crosstab();
            this.DetailPanel = new Telerik.Reporting.Panel();
            this.ConfirmationSubSubReport = new Telerik.Reporting.SubReport();
            this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // GroupFooterSection3
            // 
            this.GroupFooterSection3.Bindings.Add(new Telerik.Reporting.Binding("PageBreak", "= IIf(Fields.RemarksAfter=\"\",0,1)"));
            this.GroupFooterSection3.CanShrink = true;
            this.GroupFooterSection3.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
            this.GroupFooterSection3.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.RemarksAfter});
            this.GroupFooterSection3.Name = "GroupFooterSection3";
            // 
            // RemarksAfter
            // 
            this.RemarksAfter.CanShrink = true;
            this.RemarksAfter.KeepTogether = false;
            this.RemarksAfter.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.RemarksAfter.Name = "RemarksAfter";
            this.RemarksAfter.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.RemarksAfter.Style.Font.Name = "Calibri";
            this.RemarksAfter.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.RemarksAfter.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.RemarksAfter.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.RemarksAfter.Value = "= Fields.RemarksAfter";
            // 
            // GroupHeaderSection3
            // 
            this.GroupHeaderSection3.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.GroupHeaderSection3.Name = "GroupHeaderSection3";
            this.GroupHeaderSection3.Style.Visible = false;
            // 
            // GroupFooterSection2
            // 
            this.GroupFooterSection2.CanShrink = true;
            this.GroupFooterSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(4.2D);
            this.GroupFooterSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TotalsPanel});
            this.GroupFooterSection2.Name = "GroupFooterSection2";
            // 
            // TotalsPanel
            // 
            this.TotalsPanel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value = \"Confirmation\", True, False)"));
            this.TotalsPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TotalsHeader,
            this.PackageGrandTotal1,
            this.PackageGrandTotal2,
            this.Total2,
            this.TaxTotal2,
            this.TotalDiscount2,
            this.GrandTotal2,
            this.GrandTotal1,
            this.TotalDiscount1,
            this.TaxTotal1,
            this.Total1,
            this.PackageGrandTotal3,
            this.Total3,
            this.TaxAppliesLabel,
            this.UnassignedTotal3});
            this.TotalsPanel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TotalsPanel.Name = "TotalsPanel";
            this.TotalsPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.3D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
            // 
            // TotalsHeader
            // 
            this.TotalsHeader.CanShrink = true;
            this.TotalsHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TotalsHeader.Name = "TotalsHeader";
            this.TotalsHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalsHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TotalsHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalsHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalsHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalsHeader.Style.Font.Bold = true;
            this.TotalsHeader.Style.Font.Name = "Calibri";
            this.TotalsHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalsHeader.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalsHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalsHeader.StyleName = "Normal.TableHeader";
            this.TotalsHeader.Value = "Totals";
            // 
            // PackageGrandTotal1
            // 
            this.PackageGrandTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value = \"ClientStatement\" And Sum(Fields.Pack" +
            "ageTotal) <> 0, True, False)"));
            this.PackageGrandTotal1.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Sum(Fields.PackageTotal) = 0, \"11pt\", \"10pt\")"));
            this.PackageGrandTotal1.CanShrink = true;
            this.PackageGrandTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageGrandTotal1.Name = "PackageGrandTotal1";
            this.PackageGrandTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageGrandTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageGrandTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageGrandTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PackageGrandTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageGrandTotal1.Style.Font.Bold = true;
            this.PackageGrandTotal1.Style.Font.Name = "Calibri";
            this.PackageGrandTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageGrandTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageGrandTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageGrandTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PackageGrandTotal1.StyleName = "";
            this.PackageGrandTotal1.Value = "Package Total";
            // 
            // PackageGrandTotal2
            // 
            this.PackageGrandTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value = \"ClientStatement\" And Sum(Fields.Pack" +
            "ageTotal) <> 0, True, False)"));
            this.PackageGrandTotal2.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Sum(Fields.PackageTotal) = 0, \"11pt\", \"10pt\")"));
            this.PackageGrandTotal2.CanShrink = true;
            this.PackageGrandTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageGrandTotal2.Name = "PackageGrandTotal2";
            this.PackageGrandTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageGrandTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageGrandTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageGrandTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PackageGrandTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageGrandTotal2.Style.Font.Bold = true;
            this.PackageGrandTotal2.Style.Font.Name = "Calibri";
            this.PackageGrandTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageGrandTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageGrandTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageGrandTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PackageGrandTotal2.StyleName = "";
            this.PackageGrandTotal2.Value = "= Format(\"{0:c2}\", Sum(Fields.PackageTotal))";
            // 
            // Total2
            // 
            this.Total2.CanShrink = true;
            this.Total2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.Total2.Name = "Total2";
            this.Total2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Total2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.Total2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Total2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Total2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Total2.Style.Font.Bold = true;
            this.Total2.Style.Font.Name = "Calibri";
            this.Total2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Total2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Total2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Total2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Total2.StyleName = "";
            this.Total2.Value = "= Format(\"{0:c2}\", Sum(Fields.Total))";
            // 
            // TaxTotal2
            // 
            this.TaxTotal2.CanShrink = true;
            this.TaxTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.TaxTotal2.Name = "TaxTotal2";
            this.TaxTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TaxTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TaxTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TaxTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TaxTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TaxTotal2.Style.Font.Bold = true;
            this.TaxTotal2.Style.Font.Name = "Calibri";
            this.TaxTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TaxTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TaxTotal2.StyleName = "";
            this.TaxTotal2.Value = "= Format(\"{0:c2}\", Sum(Fields.TaxTotal))";
            // 
            // TotalDiscount2
            // 
            this.TotalDiscount2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value = \"ClientStatement\" And Sum(Fields.Disc" +
            "ountTotal) <> 0, True, False)"));
            this.TotalDiscount2.CanShrink = true;
            this.TotalDiscount2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
            this.TotalDiscount2.Name = "TotalDiscount2";
            this.TotalDiscount2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalDiscount2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TotalDiscount2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalDiscount2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalDiscount2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalDiscount2.Style.Font.Bold = true;
            this.TotalDiscount2.Style.Font.Name = "Calibri";
            this.TotalDiscount2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalDiscount2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalDiscount2.StyleName = "";
            this.TotalDiscount2.Value = "= Format(\"{0:c2}\", Sum(Fields.DiscountTotal))";
            // 
            // GrandTotal2
            // 
            this.GrandTotal2.CanShrink = true;
            this.GrandTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.GrandTotal2.Name = "GrandTotal2";
            this.GrandTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.GrandTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.GrandTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.GrandTotal2.Style.Font.Bold = true;
            this.GrandTotal2.Style.Font.Name = "Calibri";
            this.GrandTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.GrandTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.GrandTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.GrandTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.GrandTotal2.StyleName = "";
            this.GrandTotal2.Value = "= Format(\"{0:c2}\", Sum(Fields.Total))";
            // 
            // GrandTotal1
            // 
            this.GrandTotal1.CanShrink = true;
            this.GrandTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.GrandTotal1.Name = "GrandTotal1";
            this.GrandTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.GrandTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.GrandTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.GrandTotal1.Style.Font.Bold = true;
            this.GrandTotal1.Style.Font.Name = "Calibri";
            this.GrandTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.GrandTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.GrandTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.GrandTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.GrandTotal1.StyleName = "";
            this.GrandTotal1.Value = "Grand Total";
            // 
            // TotalDiscount1
            // 
            this.TotalDiscount1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value = \"ClientStatement\" And Sum(Fields.Disc" +
            "ountTotal) <> 0, True, False)"));
            this.TotalDiscount1.CanShrink = true;
            this.TotalDiscount1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
            this.TotalDiscount1.Name = "TotalDiscount1";
            this.TotalDiscount1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalDiscount1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TotalDiscount1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalDiscount1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalDiscount1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalDiscount1.Style.Font.Bold = true;
            this.TotalDiscount1.Style.Font.Name = "Calibri";
            this.TotalDiscount1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalDiscount1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalDiscount1.StyleName = "";
            this.TotalDiscount1.Value = "Total Discounts Included";
            // 
            // TaxTotal1
            // 
            this.TaxTotal1.CanShrink = true;
            this.TaxTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.TaxTotal1.Name = "TaxTotal1";
            this.TaxTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TaxTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TaxTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TaxTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TaxTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TaxTotal1.Style.Font.Bold = true;
            this.TaxTotal1.Style.Font.Name = "Calibri";
            this.TaxTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TaxTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TaxTotal1.StyleName = "";
            this.TaxTotal1.Value = "Total Tax Included";
            this.TaxTotal1.ItemDataBound += new System.EventHandler(this.TaxTotal1_ItemDataBound);
            // 
            // Total1
            // 
            this.Total1.CanShrink = true;
            this.Total1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.Total1.Name = "Total1";
            this.Total1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Total1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.Total1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Total1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Total1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Total1.Style.Font.Bold = true;
            this.Total1.Style.Font.Name = "Calibri";
            this.Total1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Total1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Total1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Total1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Total1.StyleName = "";
            this.Total1.Value = "Total";
            // 
            // PackageGrandTotal3
            // 
            this.PackageGrandTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value = \"ClientStatement\" And Fields.PackageT" +
            "axApplies, True, False)"));
            this.PackageGrandTotal3.CanShrink = true;
            this.PackageGrandTotal3.Format = "";
            this.PackageGrandTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageGrandTotal3.Name = "PackageGrandTotal3";
            this.PackageGrandTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageGrandTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageGrandTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageGrandTotal3.Style.Font.Name = "Calibri";
            this.PackageGrandTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageGrandTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.PackageGrandTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.PackageGrandTotal3.StyleName = "Normal.TableBody";
            this.PackageGrandTotal3.Value = "= IIf(Fields.PackageTaxApplies, \"*\", \"\")";
            // 
            // Total3
            // 
            this.Total3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Sum(Fields.TaxTotal)=0, False, True)"));
            this.Total3.CanShrink = true;
            this.Total3.Format = "";
            this.Total3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.Total3.Name = "Total3";
            this.Total3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Total3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Total3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Total3.Style.Font.Name = "Calibri";
            this.Total3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Total3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.Total3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.Total3.StyleName = "Normal.TableBody";
            this.Total3.Value = "= IIf(Sum(Fields.TaxTotal)=0, \"\", \"*\")";
            // 
            // TaxAppliesLabel
            // 
            this.TaxAppliesLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Sum(Fields.TaxTotal) = 0, False, True)"));
            this.TaxAppliesLabel.CanShrink = true;
            this.TaxAppliesLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.TaxAppliesLabel.Name = "TaxAppliesLabel";
            this.TaxAppliesLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TaxAppliesLabel.Style.Font.Italic = true;
            this.TaxAppliesLabel.Style.Font.Name = "Calibri";
            this.TaxAppliesLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TaxAppliesLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxAppliesLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxAppliesLabel.Value = "*Tax Applies";
            this.TaxAppliesLabel.ItemDataBound += new System.EventHandler(this.TaxAppliesLabel_ItemDataBound);
            // 
            // UnassignedTotal3
            // 
            this.UnassignedTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Sum(Fields.TaxTotal)=0, False, True)"));
            this.UnassignedTotal3.CanShrink = true;
            this.UnassignedTotal3.Format = "";
            this.UnassignedTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.UnassignedTotal3.Name = "UnassignedTotal3";
            this.UnassignedTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.UnassignedTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.UnassignedTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.UnassignedTotal3.Style.Font.Name = "Calibri";
            this.UnassignedTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.UnassignedTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.UnassignedTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.UnassignedTotal3.StyleName = "Normal.TableBody";
            this.UnassignedTotal3.Value = "= IIf(Sum(Fields.TaxTotal)=0, \"\", \"*\")";
            // 
            // GroupHeaderSection2
            // 
            this.GroupHeaderSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.GroupHeaderSection2.Name = "GroupHeaderSection2";
            this.GroupHeaderSection2.Style.Visible = false;
            // 
            // GroupFooterSection1
            // 
            this.GroupFooterSection1.CanShrink = true;
            this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1.8D);
            this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.PackageTotal1,
            this.PackageTotal2,
            this.AgentCommissionTotal1,
            this.AgentCommissionTotal2,
            this.DiscountTotal1,
            this.DiscountTotal2,
            this.PackageTotal3});
            this.GroupFooterSection1.KeepTogether = false;
            this.GroupFooterSection1.Name = "GroupFooterSection1";
            // 
            // PackageTotal1
            // 
            this.PackageTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0, False, True)"));
            this.PackageTotal1.CanShrink = true;
            this.PackageTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.PackageTotal1.Name = "PackageTotal1";
            this.PackageTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageTotal1.Style.Font.Bold = true;
            this.PackageTotal1.Style.Font.Name = "Calibri";
            this.PackageTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PackageTotal1.StyleName = "";
            this.PackageTotal1.Value = "= \"Package \" + Fields.PackageNo + \" Total\"";
            // 
            // PackageTotal2
            // 
            this.PackageTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0, False, True)"));
            this.PackageTotal2.CanShrink = true;
            this.PackageTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.PackageTotal2.Name = "PackageTotal2";
            this.PackageTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageTotal2.Style.Font.Bold = true;
            this.PackageTotal2.Style.Font.Name = "Calibri";
            this.PackageTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PackageTotal2.StyleName = "";
            this.PackageTotal2.Value = "= Format(\"{0:c2}\", Fields.PackageTotal)";
            // 
            // AgentCommissionTotal1
            // 
            this.AgentCommissionTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value <> \"ClientStatement\" Or Fields.PackageN" +
            "o = 0 Or Fields.AgentCommissionTotal = 0, False, True)"));
            this.AgentCommissionTotal1.CanShrink = true;
            this.AgentCommissionTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.AgentCommissionTotal1.Name = "AgentCommissionTotal1";
            this.AgentCommissionTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AgentCommissionTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AgentCommissionTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AgentCommissionTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AgentCommissionTotal1.Style.Font.Bold = true;
            this.AgentCommissionTotal1.Style.Font.Name = "Calibri";
            this.AgentCommissionTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AgentCommissionTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AgentCommissionTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AgentCommissionTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AgentCommissionTotal1.StyleName = "";
            this.AgentCommissionTotal1.Value = "Less Agent Commission";
            // 
            // AgentCommissionTotal2
            // 
            this.AgentCommissionTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value <> \"ClientStatement\" Or Fields.PackageN" +
            "o = 0 Or Fields.AgentCommissionTotal = 0, False, True)"));
            this.AgentCommissionTotal2.CanShrink = true;
            this.AgentCommissionTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.AgentCommissionTotal2.Name = "AgentCommissionTotal2";
            this.AgentCommissionTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AgentCommissionTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AgentCommissionTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AgentCommissionTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AgentCommissionTotal2.Style.Font.Bold = true;
            this.AgentCommissionTotal2.Style.Font.Name = "Calibri";
            this.AgentCommissionTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AgentCommissionTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AgentCommissionTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AgentCommissionTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AgentCommissionTotal2.StyleName = "";
            this.AgentCommissionTotal2.Value = "= Format(\"{0:c2}\", Fields.AgentCommissionTotal)";
            // 
            // DiscountTotal1
            // 
            this.DiscountTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value <> \"ClientStatement\" Or Fields.PackageN" +
            "o = 0 Or Fields.DiscountTotal = 0, False, True)"));
            this.DiscountTotal1.CanShrink = true;
            this.DiscountTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DiscountTotal1.Name = "DiscountTotal1";
            this.DiscountTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DiscountTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.DiscountTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DiscountTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DiscountTotal1.Style.Font.Bold = true;
            this.DiscountTotal1.Style.Font.Name = "Calibri";
            this.DiscountTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DiscountTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DiscountTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DiscountTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.DiscountTotal1.StyleName = "";
            this.DiscountTotal1.Value = "Discounts Included";
            // 
            // DiscountTotal2
            // 
            this.DiscountTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.issuedDocumentType.Value <> \"ClientStatement\" Or Fields.PackageN" +
            "o = 0 Or Fields.DiscountTotal = 0, False, True)"));
            this.DiscountTotal2.CanShrink = true;
            this.DiscountTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DiscountTotal2.Name = "DiscountTotal2";
            this.DiscountTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DiscountTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.DiscountTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DiscountTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DiscountTotal2.Style.Font.Bold = true;
            this.DiscountTotal2.Style.Font.Name = "Calibri";
            this.DiscountTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DiscountTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DiscountTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DiscountTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.DiscountTotal2.StyleName = "";
            this.DiscountTotal2.Value = "= Format(\"{0:c2}\", Fields.DiscountTotal)";
            // 
            // PackageTotal3
            // 
            this.PackageTotal3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo > 0 And Fields.PackageTaxApplies, True, False)"));
            this.PackageTotal3.CanShrink = true;
            this.PackageTotal3.Format = "";
            this.PackageTotal3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.PackageTotal3.Name = "PackageTotal3";
            this.PackageTotal3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageTotal3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageTotal3.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageTotal3.Style.Font.Name = "Calibri";
            this.PackageTotal3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageTotal3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
            this.PackageTotal3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.PackageTotal3.StyleName = "Normal.TableBody";
            this.PackageTotal3.Value = "= IIf(Fields.PackageNo > 0 And Fields.PackageTaxApplies, \"*\", \"\")";
            // 
            // GroupHeaderSection1
            // 
            this.GroupHeaderSection1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo=0, False, True)"));
            this.GroupHeaderSection1.CanShrink = true;
            this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1.1D);
            this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.PackageLabel});
            this.GroupHeaderSection1.KeepTogether = false;
            this.GroupHeaderSection1.Name = "GroupHeaderSection1";
            this.GroupHeaderSection1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
            // 
            // PackageLabel
            // 
            this.PackageLabel.CanShrink = true;
            this.PackageLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.PackageLabel.Name = "PackageLabel";
            this.PackageLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageLabel.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageLabel.Style.Font.Bold = true;
            this.PackageLabel.Style.Font.Name = "Calibri";
            this.PackageLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(11D);
            this.PackageLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PackageLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PackageLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageLabel.StyleName = "";
            this.PackageLabel.Value = "= \"Package \" + Fields.PackageNo + \" Details\"";
            // 
            // RemarksBefore
            // 
            this.RemarksBefore.CanShrink = true;
            this.RemarksBefore.KeepTogether = false;
            this.RemarksBefore.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.RemarksBefore.Name = "RemarksBefore";
            this.RemarksBefore.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.RemarksBefore.Style.Font.Name = "Calibri";
            this.RemarksBefore.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.RemarksBefore.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.RemarksBefore.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.RemarksBefore.Value = "= Fields.RemarksBefore";
            // 
            // Detail
            // 
            this.Detail.CanShrink = true;
            this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(1.6D);
            this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailList,
            this.RemarksBefore});
            this.Detail.KeepTogether = false;
            this.Detail.Name = "Detail";
            this.Detail.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
            this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            // 
            // DetailList
            // 
            this.DetailList.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.ConfirmationDetailSubReportList"));
            this.DetailList.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18D)));
            this.DetailList.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
            this.DetailList.Body.SetCellContent(0, 0, this.DetailPanel);
            tableGroup1.Name = "ColumnGroup";
            this.DetailList.ColumnGroups.Add(tableGroup1);
            this.DetailList.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailPanel});
            this.DetailList.KeepTogether = false;
            this.DetailList.Name = "DetailList";
            tableGroup2.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.Header1"));
            tableGroup2.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.Header2"));
            tableGroup2.Groupings.Add(new Telerik.Reporting.Grouping("= IIf(Parameters.issuedDocumentType.Value = \"Itinerary\", 0, Fields.TripLineId)"));
            tableGroup2.Name = "DetailGroup";
            this.DetailList.RowGroups.Add(tableGroup2);
            this.DetailList.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            // 
            // DetailPanel
            // 
            this.DetailPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ConfirmationSubSubReport});
            this.DetailPanel.KeepTogether = false;
            this.DetailPanel.Name = "DetailPanel";
            this.DetailPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            // 
            // ConfirmationSubSubReport
            // 
            this.ConfirmationSubSubReport.KeepTogether = false;
            this.ConfirmationSubSubReport.Name = "ConfirmationSubSubReport";
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("imagePath", "= Parameters.imagePath.Value"));
            typeReportSource1.TypeName = "Travelog.Reports.ClientLedger.ConfirmationSubSubReport, Travelog.Reports, Version" +
    "=1.0.0.0, Culture=neutral, PublicKeyToken=null";
            this.ConfirmationSubSubReport.ReportSource = typeReportSource1;
            this.ConfirmationSubSubReport.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ConfirmationSubSubReport.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            // 
            // ReportDataSource
            // 
            this.ReportDataSource.DataMember = "ConfirmationSubReport";
            this.ReportDataSource.DataSource = typeof(Travelog.Reports.ClientLedger.ClientLedgerDataSources);
            this.ReportDataSource.Name = "ReportDataSource";
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("tripLineIds", typeof(string), "= Parameters.tripLineIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("passengerIds", typeof(string), "= Parameters.passengerIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("quoteNo", typeof(int), "= Parameters.quoteNo.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("tripItineraryId", typeof(int), "= Parameters.tripItineraryId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("issuedDocumentType", typeof(string), "= Parameters.issuedDocumentType.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("timeFormat", typeof(string), "= Parameters.timeFormat.Value"));
            // 
            // ConfirmationSubReport
            // 
            this.DataSource = this.ReportDataSource;
            group1.GroupFooter = this.GroupFooterSection3;
            group1.GroupHeader = this.GroupHeaderSection3;
            group1.Name = "Group3";
            group2.GroupFooter = this.GroupFooterSection2;
            group2.GroupHeader = this.GroupHeaderSection2;
            group2.Name = "Group2";
            group3.GroupFooter = this.GroupFooterSection1;
            group3.GroupHeader = this.GroupHeaderSection1;
            group3.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.PackageNo"));
            group3.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
            group3.Name = "Group1";
            group3.Sortings.Add(new Telerik.Reporting.Sorting("= IIf(Fields.PackageNo=0,1,0)", Telerik.Reporting.SortDirection.Asc));
            group3.Sortings.Add(new Telerik.Reporting.Sorting("= Fields.PackageNo", Telerik.Reporting.SortDirection.Asc));
            group3.Sortings.Add(new Telerik.Reporting.Sorting("= Fields.SeqNo", Telerik.Reporting.SortDirection.Asc));
            this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2,
            group3});
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection3,
            this.GroupFooterSection3,
            this.GroupHeaderSection2,
            this.GroupFooterSection2,
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail});
            this.Name = "ConfirmationSubReport";
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.35D), Telerik.Reporting.Drawing.Unit.Cm(1.35D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            reportParameter1.Name = "customerId";
            reportParameter1.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter2.Name = "imagePath";
            reportParameter3.Name = "tripLineIds";
            reportParameter4.Name = "passengerIds";
            reportParameter5.Name = "quoteNo";
            reportParameter5.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter6.Name = "tripItineraryId";
            reportParameter6.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter7.Name = "issuedDocumentType";
            reportParameter8.Name = "timeFormat";
            this.ReportParameters.Add(reportParameter1);
            this.ReportParameters.Add(reportParameter2);
            this.ReportParameters.Add(reportParameter3);
            this.ReportParameters.Add(reportParameter4);
            this.ReportParameters.Add(reportParameter5);
            this.ReportParameters.Add(reportParameter6);
            this.ReportParameters.Add(reportParameter7);
            this.ReportParameters.Add(reportParameter8);
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(18.3D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.HtmlTextBox RemarksBefore;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.TextBox PackageLabel;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.Crosstab DetailList;
		private Telerik.Reporting.Panel DetailPanel;
		private Telerik.Reporting.SubReport ConfirmationSubSubReport;
		private Telerik.Reporting.HtmlTextBox RemarksAfter;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection2;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection2;
		private Telerik.Reporting.TextBox PackageTotal1;
		private Telerik.Reporting.TextBox PackageTotal2;
		private Telerik.Reporting.TextBox AgentCommissionTotal1;
		private Telerik.Reporting.TextBox AgentCommissionTotal2;
		private Telerik.Reporting.TextBox DiscountTotal1;
		private Telerik.Reporting.TextBox DiscountTotal2;
		private Telerik.Reporting.Panel TotalsPanel;
		private Telerik.Reporting.TextBox TotalsHeader;
		private Telerik.Reporting.TextBox PackageGrandTotal1;
		private Telerik.Reporting.TextBox PackageGrandTotal2;
		private Telerik.Reporting.TextBox Total2;
		private Telerik.Reporting.TextBox TaxTotal2;
		private Telerik.Reporting.TextBox TotalDiscount2;
		private Telerik.Reporting.TextBox GrandTotal2;
		private Telerik.Reporting.TextBox GrandTotal1;
		private Telerik.Reporting.TextBox TaxAppliesLabel;
		private Telerik.Reporting.TextBox TotalDiscount1;
		private Telerik.Reporting.TextBox TaxTotal1;
		private Telerik.Reporting.TextBox Total1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection3;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection3;
		private Telerik.Reporting.TextBox PackageTotal3;
		private Telerik.Reporting.TextBox PackageGrandTotal3;
        private Telerik.Reporting.TextBox Total3;
        private Telerik.Reporting.TextBox UnassignedTotal3;
    }
}