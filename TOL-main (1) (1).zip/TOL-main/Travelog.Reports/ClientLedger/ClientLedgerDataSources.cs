﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;

namespace Travelog.Reports.ClientLedger {
    public class ClientLedgerDataSources {
        private const string ClassName = "Travelog.Reports.ClientLedger.ClientLedgerDataSources";

		public List<ClientTrialBalanceReportModel> ClientTrialBalanceReport(int reportSourceId, int customerId, DateTime reportDate, int reportOrderId, int ledgerDocumentTypeId, int commissionValueTypeId, int transactionBalanceTypeId,
			DateTime? departureDateFrom, DateTime? departureDateTo, DateTime? txnDateFrom, DateTime? txnDateTo, bool includeOpenDated, int tripIdFrom, int tripIdTo, string agencyIds, string agentIds, string categoryIds,
			string classIds, string consultantIds, string debtorIds, string destinationIds, string groupIds, string locationIds, string sourceIds, bool groupByAgency, bool groupByAgent, bool groupByCategory,
			bool groupByClass, bool groupByConsultant, bool groupByDebtor, bool groupByDestination, bool groupByGroup, bool groupByLocation, bool groupBySource, bool agencyNewPage, bool agentNewPage,
			bool categoryNewPage, bool classNewPage, bool consultantNewPage, bool debtorNewPage, bool destinationNewPage, bool groupNewPage, bool locationNewPage, bool sourceNewPage, int? agencyLevel,
			int? agentLevel, int? categoryLevel, int? classLevel, int? consultantLevel, int? debtorLevel, int? destinationLevel, int? groupLevel, int? locationLevel, int? sourceLevel) {

			try {
				using (var lazyContext = new AppLazyContext(customerId, true)) {
					var model = new ClientReportSourceModel {
						ReportSource = (ReportSourceClient)reportSourceId,
						ReportDate = reportDate,
						ReportOrderId = reportOrderId,
						LedgerDocumentType = (LedgerDocumentType)ledgerDocumentTypeId,
						TransactionBalanceType = (TransactionBalanceType)transactionBalanceTypeId,
						DepartureDateFrom = departureDateFrom,
						DepartureDateTo = departureDateTo,
						TxnDateFrom = txnDateFrom,
						TxnDateTo = txnDateTo,
						IncludeOpenDated = includeOpenDated,
						TripIdFrom = tripIdFrom,
						TripIdTo = tripIdTo,
						AgencyIds = string.IsNullOrEmpty(agencyIds) || agencyIds == "0" ? null : agencyIds.Split(',').Select(int.Parse).ToArray(),
						AgentIds = string.IsNullOrEmpty(agentIds) || agentIds == "0" ? null : agentIds.Split(',').Select(int.Parse).ToArray(),
						CategoryIds = string.IsNullOrEmpty(categoryIds) || categoryIds == "0" ? null : categoryIds.Split(',').Select(int.Parse).ToArray(),
						ClassIds = string.IsNullOrEmpty(classIds) || classIds == "0" ? null : classIds.Split(',').Select(int.Parse).ToArray(),
						ConsultantIds = string.IsNullOrEmpty(consultantIds) || consultantIds == "0" ? null : consultantIds.Split(',').Select(int.Parse).ToArray(),
						DebtorIds = string.IsNullOrEmpty(debtorIds) || debtorIds == "0" ? null : debtorIds.Split(',').Select(int.Parse).ToArray(),
						DestinationIds = string.IsNullOrEmpty(destinationIds) || destinationIds == "0" ? null : destinationIds.Split(',').Select(int.Parse).ToArray(),
						GroupIds = string.IsNullOrEmpty(groupIds) || groupIds == "0" ? null : groupIds.Split(',').Select(int.Parse).ToArray(),
						LocationIds = string.IsNullOrEmpty(locationIds) || locationIds == "0" ? null : locationIds.Split(',').Select(int.Parse).ToArray(),
						SourceIds = string.IsNullOrEmpty(sourceIds) || sourceIds == "0" ? null : sourceIds.Split(',').Select(int.Parse).ToArray(),
						GroupByAgency = groupByAgency,
						GroupByAgent = groupByAgent,
						GroupByCategory = groupByCategory,
						GroupByClass = groupByClass,
						GroupByConsultant = groupByConsultant,
						GroupByDebtor = groupByDebtor,
						GroupByDestination = groupByDestination,
						GroupByGroup = groupByGroup,
						GroupByLocation = groupByLocation,
						GroupBySource = groupBySource,
						AgencyNewPage = agencyNewPage,
						AgentNewPage = agentNewPage,
						CategoryNewPage = categoryNewPage,
						ClassNewPage = classNewPage,
						ConsultantNewPage = consultantNewPage,
						DebtorNewPage = debtorNewPage,
						DestinationNewPage = destinationNewPage,
						GroupNewPage = groupNewPage,
						LocationNewPage = locationNewPage,
						SourceNewPage = sourceNewPage,
						AgencyLevel = agencyLevel,
						AgentLevel = agentLevel,
						CategoryLevel = categoryLevel,
						ClassLevel = classLevel,
						ConsultantLevel = consultantLevel,
						DebtorLevel = debtorLevel,
						DestinationLevel = destinationLevel,
						GroupLevel = groupLevel,
						LocationLevel = locationLevel,
						SourceLevel = sourceLevel
					};

					var commissionValueType = (Biz.Enums.ValueType)commissionValueTypeId;

					var q = Trip.GetClientLedgerQuery(lazyContext, model).ConvertAll(row => new ClientTrialBalanceReportModel {
						TripId = row.TripId,
						TripNo = row.TripNo,
						FullName = string.Format("{0} {1}{2}", row.FirstName, row.LastName, model.GroupByDebtor || row.Debtor.Id <= 0 ? string.Empty : string.Format("{0}{1}", Environment.NewLine, row.Debtor.Name)),
						DepartureDate = row.DepartureDate,
						AgencyId = row.Agency.Id,
						Agency = row.Agency.Id <= 0 ? "None" : row.Agency.Name,
						AgentId = row.Agent.Id,
						Agent = row.Agent.Id <= 0 ? "None" : row.Agent.Name,
						CategoryId = row.Category.Id,
						Category = row.Category.Id <= 0 ? "None" : row.Category.Name,
						ClassId = row.Class.Id,
						Class = row.Class.Id <= 0 ? "None" : row.Class.Name,
						ConsultantId = row.Consultant.Id,
						Consultant = string.Format("{0}{1}", row.Consultant.Id <= 0 ? "None" : row.Consultant.Name, row.Agent.Id <= 0 ? string.Empty : string.Format("{0}{1}", Environment.NewLine, row.Agent.Name)),
						DebtorId = row.Debtor.Id,
						Debtor = row.Debtor.Id <= 0 ? "None" : row.Debtor.Name,
						DestinationId = row.Destination.Id,
						Destination = row.Destination.Id <= 0 ? "None" : row.Destination.Name,
						GroupId = row.Group.Id,
						Group = row.Group.Id <= 0 ? "None" : row.Group.Name,
						LocationId = row.Location.Id,
						Location = row.Location.Id <= 0 ? "None" : row.Location.Name,
						SourceId = row.Source.Id,
						Source = row.Source.Id <= 0 ? "None" : row.Source.Name,
						Debit = row.Debit,
						Credit = row.Credit,
						Balance = row.Balance,
						TransactionDetailReportList = row.TransactionDetail == null ? new List<TransactionDetailReportModel>() : row.TransactionDetail.ConvertAll(t => new TransactionDetailReportModel {
							TransactionType = t.Transaction.EffectiveTransactionType.GetEnumDescription(),
							DocumentDate = t.Transaction.DocumentDate,
							DocumentNo = t.Transaction.DocumentNo,
							Description = t.Description,
							Reference = t.Reference,
							Commission = commissionValueType == Biz.Enums.ValueType.Net ? t.CommissionLessDiscount : t.CommissionLessDiscountGross,
							AmountGross = t.Amount + t.Tax
						})
					});

					foreach (var row in q) {
						row.Commission = row.TransactionDetailReportList.Sum(t => (decimal?)t.Commission) ?? 0;
						row.AmountGross = row.TransactionDetailReportList.Sum(t => (decimal?)t.AmountGross) ?? 0;
					}

					return q;
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "ClientTrialBalanceReport", ex, customerId);
				return new List<ClientTrialBalanceReportModel>();
			}
		}

		public QuoteReportModel QuoteReport(int customerId, string passengerIds, int quoteNo, int agencyId, DateTime creationTime) {
			try {
				using (var context = new AppMainContext(customerId, true)) {
					var passengerIdList = passengerIds.Split(',').Select(int.Parse).ToArray();
					string passengers = string.Empty;

					var q1 = context.Trip.Include(t => t.MainCity).Include(t => t.Consultant).Include(t => t.TripAddresses).Include(t => t.TripPassengers).Single(t => t.TripPassengers.Any(t2 => passengerIdList.Contains(t2.Id)));
					var q2 = context.Agency.Include(t => t.AgencyHeaders).Single(t => t.Id == agencyId);

					foreach (var passenger in q1.TripPassengers.Where(t => passengerIdList.Contains(t.Id)).OrderBy(t => t.SeqNo).ThenBy(t => t.Id)) {
						int age = passenger.GetAge();
						passengers += string.Format("{0}{1}{2}", passenger.FullName, passenger.PassengerType == PassengerType.NotSpecified ? string.Empty : string.Format(" [{0}]", passenger.PassengerType == PassengerType.Child && age > 0 ? string.Format("{0} years", age) : passenger.PassengerType == PassengerType.Infant && age > 0 ? string.Format("{0} months", age) : passenger.PassengerType.GetEnumDescription()), Environment.NewLine);
					}

					passengers.TrimEnd(Environment.NewLine);

					return new QuoteReportModel {
						TripId = q1.Id,
						TripNo = quoteNo <= 0 ? string.Format("BOOKING NO {0}", q1.TripNo) : string.Format("QUOTE NO {0}.{1}", q1.TripNo, quoteNo),
						QuoteNo = quoteNo,
						TaxNo = (q2.AgencyHeaders.SingleOrDefault(t => t.IssuedDocumentType == IssuedDocumentType.Quote)?.IncludeTaxNo ?? false) ? q2.TaxNo : string.Empty,
						DocumentDate = creationTime.Date,
						Consultant = Utils.GetIssuedBy(q1.Consultant, q1.CreationUser, customerId),
						DepartureDate = q1.DepartureDate,
						Passengers = passengers,
						FullName = q1.FullName,
						Address = q1.GetAddress(context).Replace(AppConstants.HtmlLineBreak, Environment.NewLine),
						MainCity = q1.MainCity.Name
					};
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "QuoteReport", ex, customerId);
				return new QuoteReportModel();
			}
		}

		public List<QuoteSubReportModel> QuoteSubReport(int customerId, string tripLineIds, string passengerIds, int quoteNo, string timeFormat) {
            try {
                using (var lazyContext = new AppLazyContext(customerId, true)) {
					var timeFormatValue = (TimeFormat)Enum.Parse(typeof(TimeFormat), timeFormat, true);

					int[] tripLineIdList = null;
					int[] passengerIdList = passengerIds.Split(',').Select(int.Parse).ToArray();

					if (string.IsNullOrEmpty(tripLineIds) || tripLineIds == "0") {
						tripLineIdList = lazyContext.TripLine.Where(t1 => (quoteNo < 0 || t1.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo)) && t1.Trip.TripPassengers.Any(t2 => passengerIdList.Contains(t2.Id))).Select(t => t.Id).ToArray();
					}
					else {
						tripLineIdList = tripLineIds.Split(',').Select(int.Parse).ToArray();
					}

					var tripLines = lazyContext.TripLine.Where(t1 => t1.PrintOnQuote && tripLineIdList.Contains(t1.Id) && t1.Trip.TripPassengers.Any(t2 => passengerIdList.Contains(t2.Id))).AsEnumerable().Where(t => t.Exists);

					if (tripLines.SelectMany(t1 => t1.TripLineSelections).Any(t2 => t2.QuoteNo == quoteNo)) {
						tripLines = tripLines.Select(t1 => new { TripLine = t1, TripLineSelection = t1.TripLineSelections.SingleOrDefault(t2 => t2.TripLineId == t1.Id && t2.QuoteNo == quoteNo) })
							.OrderBy(t => t.TripLine.PackageNo == 0 ? 1 : 0).ThenBy(t => t.TripLine.PackageNo).ThenBy(t => t.TripLineSelection == null ? -1 : t.TripLineSelection.SeqNo)
							.Select(t => t.TripLine);
					}

					var tripLineAir = lazyContext.TripLineAirPassenger.Where(t => tripLineIdList.Contains(t.TripLineId) && passengerIdList.Contains(t.PassengerId) && t.TripLineAirPassengerAirSegments.Count > 0 && t.TripLineAir.TripLine.PrintOnQuote).AsEnumerable().Where(t => t.TripLineAir?.TripLine.Exists ?? false).ToList();
                    var tripLineAirUnassigned = lazyContext.TripLineAirPassenger.Where(t => tripLineIdList.Contains(t.TripLineId) && passengerIdList.Contains(t.PassengerId) && t.TripLineAirPassengerAirSegments.Count == 0 && t.TripLineAir.TripLine.PrintOnQuote).AsEnumerable().Where(t => t?.TripLineAir?.TripLine.Exists ?? false).ToList();
                    var tripLineOther = lazyContext.TripLine.Where(t1 => tripLineIdList.Contains(t1.Id) && t1.Trip.TripPassengers.Any(t2 => passengerIdList.Contains(t2.Id)) && t1.PrintOnQuote && t1.TripLineType != TripLineType.Air).AsEnumerable().Where(t => t.Exists).ToList();

					var quoteSubReportList = new List<QuoteSubReportModel>();
					var quoteDetailSubReportList = new List<QuoteDetailSubReportModel>();

					string supplierName = string.Empty;
					string supplierAddress = string.Empty;
					string startEndDate = string.Empty;
					string supplierServiceDescription = string.Empty;
					string serviceTypeRateBasisDescription = string.Empty;
					string htmlRemarksAfter = string.Empty;

					int packageNo = -1;
					int seqNo = -1;

					int adultCount = 0;
					int childCount = 0;
					int infantCount = 0;

					decimal adultCostToClient = 0;
					decimal childCostToClient = 0;
					decimal infantCostToClient = 0;

					decimal adultNonCommissionable = 0;
					decimal childNonCommissionable = 0;
					decimal infantNonCommissionable = 0;

                    decimal miscellaneousCharges = 0;
                    decimal airDiscount = 0;

					foreach (var tripLine in tripLines.ToList()) {
						seqNo++;

						if (packageNo != tripLine.PackageNo) {
							packageNo = tripLine.PackageNo;

							decimal tripLineAirPackageTotal = 0;
							decimal tripLineOtherPackageTotal = 0;
							decimal discountTotal = 0;

							if (packageNo > 0) {
								tripLineAirPackageTotal = tripLineAir.Where(t => t.TripLineAir.TripLine.PackageNo == packageNo).Sum(t => (decimal?)t.GetCostToClient(customerId)) ?? 0;
								tripLineOtherPackageTotal = tripLineOther.Where(t => t.PackageNo == packageNo).Sum(t => (decimal?)t.CostToClient) ?? 0;
								discountTotal = (tripLineAir.Where(t => t.TripLineId == tripLine.Id).Sum(t => (decimal?)t.Discount) ?? 0) + (tripLineOther.Where(t => t.Id == tripLine.Id).Sum(t => (decimal?)t.Discount) ?? 0);
							}

							quoteSubReportList.Add(new QuoteSubReportModel {
								PackageNo = packageNo,
								PackageTotal = tripLineAirPackageTotal + tripLineOtherPackageTotal,
								DiscountTotal = discountTotal,
								RemarksAfter = string.Empty,
								QuoteDetailSubReportList = new List<QuoteDetailSubReportModel>()
							});
						}

						quoteDetailSubReportList = quoteSubReportList.Last().QuoteDetailSubReportList;

						switch (tripLine.TripLineType) {
							case TripLineType.Air:
                                foreach (var row in tripLine.TripLineAir.TripLineAirSegments.Where(t1 => t1.TripLineAirPassengerAirSegments.Any(t3 => passengerIdList.Contains(t3.TripLineAirPassenger.PassengerId)))
									.GroupBy(t1 => new { t1.TripLineAir, t1.TripLineAirPassengerAirSegments.Select(t2 => t2.TripLineAirPassenger).First(t3 => passengerIdList.Contains(t3.PassengerId)).Airline })
									.OrderBy(t1 => t1.Min(t2 => t2.SeqNo)).ThenBy(t1 => t1.Min(t2 => t2.DepartureDateTime)).ThenBy(t1 => t1.Min(t2 => t2.ArrivalDateTime)).ToList()) {

									if (!row.Any())
										continue;

									var tripLineAirSegments = row.Select(t => t).Where(t1 => t1.DepartureDate > AppConstants.VoidDate && row.Any(t2 => t2.GetClassDescription(lazyContext, row.Key.Airline.Id) == t1.GetClassDescription(lazyContext, row.Key.Airline.Id))).Distinct().OrderBy(t => t.DepartureDate).ThenBy(t => t.ArrivalDate).ToList();

									if (tripLineAirSegments.Count == 0)
										continue;

									string segments = string.Empty;
									string arrivalCity = null;

									foreach (var airSegment in tripLineAirSegments) {
										if (airSegment.DepartureCity.Name != arrivalCity)
											segments += string.Format("{0}{1}", arrivalCity == null ? string.Empty : " then ", airSegment.DepartureCity.Name);

										segments += string.Format(" to {0}", airSegment.ArrivalCity.Name);
										arrivalCity = airSegment.ArrivalCity.Name;
									}

									var departureSegment = tripLineAirSegments.First();
									var arrivalSegment = tripLineAirSegments.Last();

									startEndDate = string.Empty;

									if (departureSegment.DepartureDateTime > AppConstants.VoidDate) {
										if (departureSegment.Id == arrivalSegment.Id) {
											startEndDate = string.Format("Departs: {0:dd-MMM-yyyy}", departureSegment.DepartureDateTime);
										}
										else {
											startEndDate = string.Format("Departs: {0:dd-MMM-yyyy}     Returns: {1:dd-MMM-yyyy}", departureSegment.DepartureDateTime, arrivalSegment.ArrivalDateTime);
										}
									}

									string classDescription = string.Join("/", row.Select(t => t.GetClassDescription(lazyContext, t.AirlineCode)).Distinct());
									string remarks = string.Empty;

									if (tripLine.TripLineAir.TripLineAirSegments.Any(t => t.TripLineRemarks.Count > 0)) {
										var tripLineAirRemarks = tripLine.TripLineAir.TripLineAirSegments.SelectMany(t => t.TripLineRemarks).Where(t1 => row.Any(t2 => t2.Id == t1.RelatedTripLineAirSegmentId) && (t1.PassengerId <= 0 || row.Any(t2 => t2.TripLineAirPassengerAirSegments.Any(t3 => t3.TripLineAirPassenger.PassengerId == t1.PassengerId)) && (quoteNo < 0 || t1.RelatedTripLine.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo) && t1.TripLine.PrintOnQuote))).Select(t1 => t1.Remark).Distinct();

										if (tripLineAirRemarks.Any())
											remarks = string.Join(string.Format("{0}{0}", AppConstants.HtmlLineBreak), tripLineAirRemarks).TrimStart(AppConstants.HtmlLineBreak);
									}

									adultCount = row.SelectMany(t => t.TripLineAirPassengerAirSegments).Where(t => passengerIdList.Contains(t.TripLineAirPassenger.PassengerId)).Select(t => new { t.TripLineAirPassenger.PassengerId, t.TripLineAirPassenger.Passenger.PassengerType }).Distinct().Count(t => t.PassengerType != PassengerType.Child && t.PassengerType != PassengerType.Infant);
									childCount = row.SelectMany(t => t.TripLineAirPassengerAirSegments).Where(t => passengerIdList.Contains(t.TripLineAirPassenger.PassengerId)).Select(t => new { t.TripLineAirPassenger.PassengerId, t.TripLineAirPassenger.Passenger.PassengerType }).Distinct().Count(t => t.PassengerType == PassengerType.Child);
									infantCount = row.SelectMany(t => t.TripLineAirPassengerAirSegments).Where(t => passengerIdList.Contains(t.TripLineAirPassenger.PassengerId)).Select(t => new { t.TripLineAirPassenger.PassengerId, t.TripLineAirPassenger.Passenger.PassengerType }).Distinct().Count(t => t.PassengerType == PassengerType.Infant);

									if (adultCount > 0) {
										adultCostToClient = row.SelectMany(t => t.TripLineAirPassengerAirSegments).Where(t => passengerIdList.Contains(t.TripLineAirPassenger.PassengerId) && t.TripLineAirPassenger.BspEntryType != BspEntryType.Emd).Select(t => new { t.TripLineAirPassenger, t.TripLineAirPassenger.Passenger.PassengerType }).Where(t => t.PassengerType != PassengerType.Child && t.PassengerType != PassengerType.Infant).Select(t => t.TripLineAirPassenger).Distinct().Sum(t => t.GetCostToClient(customerId))
											+ tripLineAirUnassigned.Where(t1 => tripLine.TripLineAir.TripLineAirPassengers.Where(t2 => t2.BspEntryType != BspEntryType.Emd && t2.Passenger.PassengerType != PassengerType.Child && t2.Passenger.PassengerType != PassengerType.Infant).Select(t2 => t2.Id).Contains(t1.Id)).Sum(t1 => (decimal?)t1.GetCostToClient(customerId)) ?? 0;

										adultNonCommissionable = row.SelectMany(t => t.TripLineAirPassengerAirSegments).Where(t => passengerIdList.Contains(t.TripLineAirPassenger.PassengerId) && t.TripLineAirPassenger.BspEntryType != BspEntryType.Emd).Select(t => new { t.TripLineAirPassenger, t.TripLineAirPassenger.Passenger.PassengerType }).Where(t => t.PassengerType != PassengerType.Child && t.PassengerType != PassengerType.Infant).Select(t => t.TripLineAirPassenger).Distinct().Sum(t => t.NonCommissionable)
                                            + tripLineAirUnassigned.Where(t1 => tripLine.TripLineAir.TripLineAirPassengers.Where(t2 => t2.BspEntryType != BspEntryType.Emd && t2.Passenger.PassengerType != PassengerType.Child && t2.Passenger.PassengerType != PassengerType.Infant).Select(t2 => t2.Id).Contains(t1.Id)).Sum(t1 => (decimal?)t1.NonCommissionable) ?? 0;
                                    }

									if (childCount > 0) {
										childCostToClient = row.SelectMany(t => t.TripLineAirPassengerAirSegments).Where(t => passengerIdList.Contains(t.TripLineAirPassenger.PassengerId) && t.TripLineAirPassenger.BspEntryType != BspEntryType.Emd).Select(t => new { t.TripLineAirPassenger, t.TripLineAirPassenger.Passenger.PassengerType }).Where(t => t.PassengerType == PassengerType.Child).Select(t => t.TripLineAirPassenger).Distinct().Sum(t => t.GetCostToClient(customerId))
                                            + tripLineAirUnassigned.Where(t1 => tripLine.TripLineAir.TripLineAirPassengers.Where(t2 => t2.BspEntryType != BspEntryType.Emd && t2.Passenger.PassengerType == PassengerType.Child).Select(t2 => t2.Id).Contains(t1.Id)).Sum(t1 => (decimal?)t1.GetCostToClient(customerId)) ?? 0;

										childNonCommissionable = row.SelectMany(t => t.TripLineAirPassengerAirSegments).Where(t => passengerIdList.Contains(t.TripLineAirPassenger.PassengerId) && t.TripLineAirPassenger.BspEntryType != BspEntryType.Emd).Select(t => new { t.TripLineAirPassenger, t.TripLineAirPassenger.Passenger.PassengerType }).Where(t => t.PassengerType == PassengerType.Child).Select(t => t.TripLineAirPassenger).Distinct().Sum(t => t.NonCommissionable)
                                            + tripLineAirUnassigned.Where(t1 => tripLine.TripLineAir.TripLineAirPassengers.Where(t2 => t2.BspEntryType != BspEntryType.Emd && t2.Passenger.PassengerType == PassengerType.Child).Select(t2 => t2.Id).Contains(t1.Id)).Sum(t1 => (decimal?)t1.NonCommissionable) ?? 0;
                                    }

                                    if (infantCount > 0) {
										infantCostToClient = row.SelectMany(t => t.TripLineAirPassengerAirSegments).Where(t => passengerIdList.Contains(t.TripLineAirPassenger.PassengerId) && t.TripLineAirPassenger.BspEntryType != BspEntryType.Emd).Select(t => new { t.TripLineAirPassenger, t.TripLineAirPassenger.Passenger.PassengerType }).Where(t => t.PassengerType == PassengerType.Infant).Select(t => t.TripLineAirPassenger).Distinct().Sum(t => t.GetCostToClient(customerId))
                                            + tripLineAirUnassigned.Where(t1 => tripLine.TripLineAir.TripLineAirPassengers.Where(t2 => t2.BspEntryType != BspEntryType.Emd && t2.Passenger.PassengerType == PassengerType.Infant).Select(t2 => t2.Id).Contains(t1.Id)).Sum(t1 => (decimal?)t1.GetCostToClient(customerId)) ?? 0;

										infantNonCommissionable = row.SelectMany(t => t.TripLineAirPassengerAirSegments).Where(t => passengerIdList.Contains(t.TripLineAirPassenger.PassengerId) && t.TripLineAirPassenger.BspEntryType != BspEntryType.Emd).Select(t => new { t.TripLineAirPassenger, t.TripLineAirPassenger.Passenger.PassengerType }).Where(t => t.PassengerType == PassengerType.Infant).Select(t => t.TripLineAirPassenger).Distinct().Sum(t => t.NonCommissionable)
                                            + tripLineAirUnassigned.Where(t1 => tripLine.TripLineAir.TripLineAirPassengers.Where(t2 => t2.BspEntryType != BspEntryType.Emd && t2.Passenger.PassengerType == PassengerType.Infant).Select(t2 => t2.Id).Contains(t1.Id)).Sum(t1 => (decimal?)t1.NonCommissionable) ?? 0;
                                    }

                                    miscellaneousCharges = row.Key.TripLineAir.TripLineAirPassengers.Where(t => passengerIdList.Contains(t.PassengerId) && t.BspEntryType == BspEntryType.Emd).Sum(t => (decimal?)(t.GetCostToClient(customerId) + t.NonCommissionable)) ?? 0;
                                    airDiscount = row.Key.TripLineAir.TripLineAirPassengers.Where(t => passengerIdList.Contains(t.PassengerId)).Sum(t => (decimal?)t.Discount) ?? 0;

									string footer = string.Empty;

									if (adultCount > 0)
										footer += string.Format("{0}{1} Travel for {2} {3} @ {4:c2}     Taxes, Levies & Surcharges: {5:c2}", Environment.NewLine, classDescription, adultCount, adultCount == 1 ? "Adult" : "Adults", adultCostToClient - adultNonCommissionable, adultNonCommissionable);

									if (childCount > 0)
										footer += string.Format("{0}{1} Travel for {2} {3} @ {4:c2}     Taxes, Levies & Surcharges: {5:c2}", Environment.NewLine, classDescription, childCount, childCount == 1 ? "Child" : "Children", childCostToClient - childNonCommissionable, childNonCommissionable);

									if (infantCount > 0)
										footer += string.Format("{0}{1} Travel for {2} {3} @ {4:c2}     Taxes, Levies & Surcharges: {5:c2}", Environment.NewLine, classDescription, infantCount, infantCount == 1 ? "Infant" : "Infants", infantCostToClient - infantNonCommissionable, infantNonCommissionable);

									if (miscellaneousCharges != 0)
                                        footer += string.Format("{0}Plus Miscellaneous Charges (EMD): {1:c2}", Environment.NewLine, miscellaneousCharges);

                                    footer = footer.TrimStart(Environment.NewLine);
									footer += string.Format("{0}Total: {1:c2}", Environment.NewLine, adultCostToClient + childCostToClient + infantCostToClient + miscellaneousCharges - airDiscount);

									if (airDiscount != 0)
										footer += string.Format("{0}Discounts been deducted to the value of {1:c2}", Environment.NewLine, airDiscount);

									quoteDetailSubReportList.Add(new QuoteDetailSubReportModel {
										QuoteSubReportAirPassenger = new QuoteSubReportAirPassengerReportModel {
											PackageNo = tripLine.PackageNo,
											PassengerNames = string.Join("; ", row.SelectMany(t => t.TripLineAirPassengerAirSegments).Select(t => new { t.TripLineAirPassenger.PassengerId, t.TripLineAirPassenger.Passenger.FullName, t.TripLineAirPassenger.Passenger.SeqNo }).Distinct().OrderBy(t => t.SeqNo).ThenBy(t => t.PassengerId).Select(t => t.FullName)),
											CostToClient = adultCostToClient + childCostToClient + infantCostToClient + miscellaneousCharges - airDiscount,
											MiscellaneousCharges = miscellaneousCharges,
                                            Footer = footer,
											QuoteSubReportAirSegmentList = new List<QuoteSubReportAirSegmentReportModel> {
													new QuoteSubReportAirSegmentReportModel {
														TripLineId = row.Key.TripLineAir.TripLineId,
														Flight = row.Key.Airline.Name,
														Segments = segments,
														StartEndDate = startEndDate,
														DepartureSegmentId = departureSegment.Id,
														ArrivalSegmentId = arrivalSegment.Id,
														ClassDescription = classDescription,
														Remarks = remarks
													}
												}
										},
										SeqNo = seqNo
									});
								}

								break;
							case TripLineType.Accommodation:
							case TripLineType.Transport:
							case TripLineType.Cruise:
							case TripLineType.Tour:
							case TripLineType.OtherLand:
								string startDateLabel = "Start Date";
								string endDateLabel = "End Date";

								switch (tripLine.TripLineType) {
									case TripLineType.Accommodation:
										startDateLabel = "In";
										endDateLabel = "Out";
										break;
								}

								if (tripLine.TripLineLand.StartDate == DateTime.MinValue && tripLine.TripLineLand.EndDate == DateTime.MinValue) {
									supplierName = "Own Arrangements";
									supplierAddress = string.Empty;
									startEndDate = string.Empty;
									supplierServiceDescription = string.Empty;
									serviceTypeRateBasisDescription = string.Empty;
								}
								else {
									supplierName = tripLine.TripLineLand.SupplierName.Length == 0 ? tripLine.TripLineLand.Supplier.Name : tripLine.TripLineLand.SupplierName;
									supplierAddress = tripLine.TripLineType == TripLineType.Accommodation || tripLine.TripLineType == TripLineType.OtherLand ? tripLine.TripLineLand.GetSupplierAddress(lazyContext).Replace(AppConstants.HtmlLineBreak, " ") : string.Empty;

									startEndDate = string.Empty;

									if (tripLine.TripLineLand.StartDate > DateTime.MinValue)
										startEndDate = string.Format("{0}: {1:dd-MMM-yyyy}", startDateLabel, tripLine.TripLineLand.StartDate);

									if (tripLine.TripLineLand.EndDate > DateTime.MinValue)
										startEndDate += string.Format("     {0}: {1:dd-MMM-yyyy}", endDateLabel, tripLine.TripLineLand.EndDate);

									supplierServiceDescription = tripLine.TripLineLand.SupplierServiceDescription;

									if (tripLine.TripLineType == TripLineType.Cruise) {
										serviceTypeRateBasisDescription = string.Format("{0}{1}", tripLine.TripLineLand.GetServiceTypeRateBasisDescription(customerId, true, false, false, IssuedDocumentType.Quote), tripLine.TripLineLand.Discount == 0 ? string.Empty : string.Format("{0}Discounts have been deducted to the value of {1:c2}", Environment.NewLine, tripLine.TripLineLand.Discount));
									}
									else {
										serviceTypeRateBasisDescription = string.Format("{0}{1}{2}", tripLine.TripLineLand.GetServiceTypeRateBasisDescription(customerId, true, false, false, IssuedDocumentType.Quote), tripLine.TripLineLand.NonCommissionable == 0 ? string.Empty : string.Format("{0}Includes Taxes, Levies & Surcharges of {1:c2}", Environment.NewLine, tripLine.TripLineLand.NonCommissionable), tripLine.TripLineLand.Discount == 0 ? string.Empty : string.Format("{0}Discounts have been deducted to the value of {1:c2}", Environment.NewLine, tripLine.TripLineLand.Discount));
									}
                                }

								quoteDetailSubReportList.Add(new QuoteDetailSubReportModel {
									QuoteSubReportLand = new QuoteSubReportLandReportModel {
										TripLineType = tripLine.TripLineType.GetEnumDescription(),
										SupplierName = supplierName,
										SupplierAddress = supplierAddress,
										StartEndDate = startEndDate.Trim(),
										SupplierServiceDescription = supplierServiceDescription,
										ServiceTypeRateBasisDescription = serviceTypeRateBasisDescription,
										Comments = string.Empty,
										Remarks = string.Join(string.Format("{0}{0}", AppConstants.HtmlLineBreak), lazyContext.TripLineRemark.Where(t1 => t1.RelatedTripLineId == tripLine.Id && (t1.PassengerId <= 0 || passengerIdList.Contains(t1.PassengerId)) && (quoteNo < 0 || t1.RelatedTripLine.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo)) && t1.TripLine.PrintOnQuote).Select(t => t.Remark.TrimHtmlLineBreaks()).Distinct()),
										CostToClient = tripLine.TripLineLand.GetCostToClient(customerId),
										PackageNo = tripLine.PackageNo
									},
									TripLineType = tripLine.TripLineType,
									SeqNo = seqNo
								});

								break;
							case TripLineType.Insurance:
								if (!tripLine.TripLineInsurance.TripLineInsurancePassengers.Any(t => passengerIdList.Contains(t.PassengerId)))
									continue;

								startEndDate = string.Empty;

								if (tripLine.TripLineInsurance.StartDate > DateTime.MinValue)
									startEndDate = string.Format("Commencing: {0:dd-MMM-yyyy}", tripLine.TripLineInsurance.StartDate);

								if (tripLine.TripLineInsurance.EndDate > DateTime.MinValue)
									startEndDate += string.Format("     Ending: {0:dd-MMM-yyyy}", tripLine.TripLineInsurance.StartDate.AddDays(tripLine.TripLineInsurance.Duration - 1));

								quoteDetailSubReportList.Add(new QuoteDetailSubReportModel {
									QuoteSubReportInsurance = new QuoteSubReportInsuranceReportModel {
										PassengerNames = string.Join("; ", tripLine.TripLineInsurance.TripLineInsurancePassengers.Where(t => passengerIdList.Contains(t.PassengerId)).OrderBy(t => t.Passenger.SeqNo).ThenBy(t => t.PassengerId).Select(t => t.Passenger.FullName)),
										SupplierName = tripLine.TripLineInsurance.Supplier.Name,
										StartEndDate = startEndDate.Trim(),
										PolicyType = string.Format("{0} - {1}", tripLine.TripLineInsurance.InsurancePolicy.Name, tripLine.TripLineInsurance.InsurancePolicyPlan.Name),
										Plan = string.Format("{0} day(s) cover", tripLine.TripLineInsurance.Duration),
										Coverage = string.Format("Coverage: {0}", tripLine.TripLineInsurance.InsurancePolicyCoverage.GetEnumDescription()),
										Remarks = string.Join(string.Format("{0}{0}", AppConstants.HtmlLineBreak), lazyContext.TripLineRemark.Where(t1 => t1.RelatedTripLineId == tripLine.Id && (t1.PassengerId <= 0 || passengerIdList.Contains(t1.PassengerId)) && (quoteNo < 0 || t1.RelatedTripLine.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo)) && t1.TripLine.PrintOnQuote).Select(t => t.Remark.TrimHtmlLineBreaks()).Distinct()),
										CostToClient = tripLine.TripLineInsurance.GetCostToClient(customerId),
										TotalSurcharge = tripLine.TripLineInsurance.TotalSurcharge,
										TotalAmountDescription = string.Format("Total: {0:c2}{1}{2}", tripLine.TripLineInsurance.GetCostToClient(customerId) + tripLine.TripLineInsurance.TotalSurcharge, tripLine.TripLineInsurance.TotalSurcharge == 0 ? string.Empty : string.Format("{0}Includes surcharges of {1:c2}", Environment.NewLine, tripLine.TripLineInsurance.TotalSurcharge), tripLine.TripLineInsurance.Discount == 0 ? string.Empty : string.Format("{0}Discounts have been deducted to the value of {1:c2}", Environment.NewLine, tripLine.TripLineInsurance.Discount)),
										PackageNo = tripLine.PackageNo
									},
									TripLineType = TripLineType.Insurance,
									SeqNo = seqNo
								});

								break;
							case TripLineType.ForeignCurrency:
								quoteDetailSubReportList.Add(new QuoteDetailSubReportModel {
									QuoteSubReportForeignCurrency = new QuoteSubReportForeignCurrencyReportModel {
										SupplierName = tripLine.TripLineForeignCurrency.Supplier.Name,
										Description = string.Format("{0:n2} {1} @ Exchange Rate of {2:n4}", tripLine.TripLineForeignCurrency.ForeignAmount, tripLine.TripLineForeignCurrency.Currency.Name, tripLine.TripLineForeignCurrency.ExchangeRate),
										Remarks = string.Join(string.Format("{0}{0}", AppConstants.HtmlLineBreak), lazyContext.TripLineRemark.Where(t1 => t1.RelatedTripLineId == tripLine.Id && (t1.PassengerId <= 0 || passengerIdList.Contains(t1.PassengerId)) && (quoteNo < 0 || t1.RelatedTripLine.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo)) && t1.TripLine.PrintOnQuote).Select(t => t.Remark).Distinct()),
										CostToClient = tripLine.TripLineForeignCurrency.CostToClient,
										PackageNo = tripLine.PackageNo
									},
									TripLineType = TripLineType.ForeignCurrency,
									SeqNo = seqNo
								});

								break;
							case TripLineType.ServiceFee:
								quoteDetailSubReportList.Add(new QuoteDetailSubReportModel {
									QuoteSubReportServiceFee = new QuoteSubReportServiceFeeReportModel {
										ServiceFee = tripLine.TripLineServiceFee.ServiceFeeType.Name,
										Description = string.Format("{0} @ {1:c2}", tripLine.TripLineServiceFee.PaxNo, tripLine.TripLineServiceFee.PaxNo == 0 ? 0 : tripLine.TripLineServiceFee.CostToClient / tripLine.TripLineServiceFee.PaxNo),
										Remarks = string.Join(string.Format("{0}{0}", AppConstants.HtmlLineBreak), lazyContext.TripLineRemark.Where(t1 => t1.RelatedTripLineId == tripLine.Id && (quoteNo < 0 || t1.RelatedTripLine.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo)) && t1.TripLine.PrintOnQuote).Select(t => t.Remark.TrimHtmlLineBreaks()).Distinct()),
										CostToClient = tripLine.TripLineServiceFee.CostToClient,
										PackageNo = tripLine.PackageNo
									},
									TripLineType = TripLineType.ServiceFee,
									SeqNo = seqNo
								});

								break;
							case TripLineType.OtherInclusion:
								quoteDetailSubReportList.Add(new QuoteDetailSubReportModel {
									QuoteSubReportOtherInclusion = new QuoteSubReportOtherInclusionReportModel {
										Comments = tripLine.TripLineOtherInclusion.Comments,
										Description = string.Format("{0} @ {1:c2}", tripLine.TripLineOtherInclusion.PaxNo, tripLine.TripLineOtherInclusion.PaxNo == 0 ? 0 : tripLine.TripLineOtherInclusion.CostToClient / tripLine.TripLineOtherInclusion.PaxNo),
										Remarks = string.Join(string.Format("{0}{0}", AppConstants.HtmlLineBreak), lazyContext.TripLineRemark.Where(t1 => t1.RelatedTripLineId == tripLine.Id && (t1.PassengerId <= 0 || passengerIdList.Contains(t1.PassengerId)) && (quoteNo < 0 || t1.RelatedTripLine.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo)) && t1.TripLine.PrintOnQuote).Select(t => t.Remark.TrimHtmlLineBreaks()).Distinct()),
										CostToClient = tripLine.TripLineOtherInclusion.CostToClient,
										Footer = string.Format("Total: {0:c2}{1}", tripLine.TripLineOtherInclusion.CostToClient, tripLine.TripLineOtherInclusion.Discount == 0 ? string.Empty : string.Format("{0}Discounts have been deducted to the value of {1:c2}", Environment.NewLine, tripLine.TripLineOtherInclusion.Discount)),
										PackageNo = tripLine.PackageNo
									},
									TripLineType = TripLineType.OtherInclusion,
									SeqNo = seqNo
								});

								break;
							case TripLineType.Remark:
								if (tripLine.TripLineRemark.RelatedTripLineId <= 0 && tripLine.PrintOnQuote) {
									if (tripLine.TripLineRemark.PrintAfterTotals) {
										htmlRemarksAfter = string.Format(string.Format("{1}{0}{0}{2}", AppConstants.HtmlLineBreak, htmlRemarksAfter, tripLine.TripLineRemark.Remark.TrimHtmlLineBreaks()));
									}
									else {
										quoteDetailSubReportList.Add(new QuoteDetailSubReportModel {
											QuoteSubReportRemark = new QuoteSubReportRemarkReportModel {
												Remark = tripLine.TripLineRemark.Remark.TrimHtmlLineBreaks(),
												PackageNo = tripLine.PackageNo
											},
											TripLineType = TripLineType.Remark,
											SeqNo = seqNo
										});
									}
								}

								break;
						}
					}

					if (quoteSubReportList.Count > 0) {
						var quoteSubReport = quoteSubReportList.Last();

                        quoteSubReport.PackageGrandTotal = quoteSubReportList.Sum(t => (decimal?)t.PackageTotal) ?? 0;
						quoteSubReport.DiscountTotal = (tripLineAir.Sum(t => (decimal?)t.Discount) ?? 0) + (tripLineOther.Sum(t => (decimal?)t.Discount) ?? 0);
                        quoteSubReport.TaxTotal = (tripLineAir.Sum(t => (decimal?)t.GetCostToClientTax(customerId, t.TripLineAir.TripLine.StartDate == DateTime.MinValue ? t.TripLineAir.TripLine.Trip.DepartureDate : t.TripLineAir.TripLine.StartDate)) ?? 0) + (tripLineOther.Sum(t => (decimal?)t.GetCostToClientTax(customerId, t.StartDate == DateTime.MinValue ? t.Trip.DepartureDate : t.StartDate)) ?? 0) + (tripLineAirUnassigned.Sum(t => (decimal?)t.GetCostToClientTax(customerId, t.TripLineAir.TripLine.StartDate == DateTime.MinValue ? t.TripLineAir.TripLine.Trip.DepartureDate : t.TripLineAir.TripLine.StartDate)) ?? 0);
                        quoteSubReport.GrandTotal = (tripLineAir.Sum(t => (decimal?)t.GetCostToClient(customerId)) ?? 0) + (tripLineOther.Sum(t => (decimal?)t.CostToClient) ?? 0) + (tripLineAirUnassigned.Sum(t => (decimal?)t.GetCostToClient(customerId)) ?? 0);

                        quoteSubReport.RemarksAfter = htmlRemarksAfter;
					}

					foreach (var row in quoteSubReportList) {
						row.QuoteDetailSubReportList = row.QuoteDetailSubReportList.OrderBy(t => t.SeqNo).ToList();
					}

					return quoteSubReportList;
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "QuoteSubReport", ex, 0);
				return new List<QuoteSubReportModel>();
			}
		}

		public ConfirmationReportModel ConfirmationReport(int customerId, string tripLineIds, string passengerIds, int quoteNo, int agencyId, string issuedDocumentType, DateTime creationTime) {
			try {
				issuedDocumentType = issuedDocumentType == "CreditNote" ? "Invoice" : issuedDocumentType;
				var issuedDocumentTypeValue = (IssuedDocumentType)Enum.Parse(typeof(IssuedDocumentType), issuedDocumentType, true);

				using (var context = new AppMainContext(customerId, true)) {
					var passengerIdList = passengerIds.Split(',').Select(int.Parse).ToArray();
					string passengers = string.Empty;

					int[] tripLineIdList = null;

					if (!string.IsNullOrEmpty(tripLineIds) && tripLineIds != "0")
						tripLineIdList = tripLineIds.Split(',').Select(int.Parse).ToArray();

					var q1 = context.Trip.Include(t => t.Destination).ThenInclude(t => t.StandardComment).Include(t => t.Consultant).Include(t => t.TripPassengers).Include(t => t.TripAddresses).Single(t => t.TripPassengers.Any(t2 => passengerIdList.Contains(t2.Id)));
					var q2 = context.Agency.Include(t => t.AgencyHeaders).Single(t => t.Id == agencyId);
					var q3 = context.TripLineAirPassenger.Include(t => t.Passenger).Where(t => (tripLineIdList == null || tripLineIdList.Contains(t.TripLineId)) && passengerIdList.Contains(t.PassengerId)).Distinct().ToList();

					foreach (var passenger in q1.TripPassengers.Where(t => passengerIdList.Contains(t.Id)).OrderBy(t => t.SeqNo).ThenBy(t => t.Id)) {
						int age = passenger.GetAge();
						string ticketNos = string.Join("; ", q3.Where(t => t.Passenger.Id == passenger.Id).Select(t => t.TicketNo).Where(t => !string.IsNullOrEmpty(t)).Distinct());
						passengers += string.Format("{0}{1}{2}{3}", passenger.FullName, passenger.PassengerType == PassengerType.NotSpecified ? string.Empty : string.Format(" [{0}]", passenger.PassengerType == PassengerType.Child && age > 0 ? string.Format("{0} years", age) : passenger.PassengerType == PassengerType.Infant && age > 0 ? string.Format("{0} months", age) : passenger.PassengerType.GetEnumDescription()), string.IsNullOrEmpty(ticketNos) ? string.Empty : string.Format(" [E-Ticket(s): {0}]", ticketNos), Environment.NewLine);
					}

					passengers.TrimEnd(Environment.NewLine);

					return new ConfirmationReportModel {
						TripId = q1.Id,
						TripNo = quoteNo <= 0 ? string.Format("BOOKING NO {0}", q1.TripNo) : string.Format("QUOTE NO {0}.{1}", q1.TripNo, quoteNo),
						QuoteNo = quoteNo,
						TaxNo = (q2.AgencyHeaders.SingleOrDefault(t => t.IssuedDocumentType == IssuedDocumentType.Quote)?.IncludeTaxNo ?? false) ? q2.TaxNo : string.Empty,
						DocumentDate = creationTime.Date,
						Consultant = Utils.GetIssuedBy(q1.Consultant, q1.CreationUser, customerId),
						DepartureDate = q1.DepartureDate,
						Passengers = passengers,
						FullName = q1.FullName,
						Address = q1.GetAddress(context).Replace(AppConstants.HtmlLineBreak, Environment.NewLine),
						StandardComment = issuedDocumentTypeValue == IssuedDocumentType.Itinerary ? q1.Destination.StandardComment.Comment : string.Empty
					};
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "ConfirmationReport", ex, customerId);
				return new ConfirmationReportModel();
			}
		}

		public List<ConfirmationSubReportModel> ConfirmationSubReport(int customerId, string tripLineIds, string passengerIds, int quoteNo, int tripItineraryId, string issuedDocumentType, string timeFormat) {
			try {
				issuedDocumentType = issuedDocumentType == "CreditNote" ? "Invoice" : issuedDocumentType;

				var issuedDocumentTypeValue = (IssuedDocumentType)Enum.Parse(typeof(IssuedDocumentType), issuedDocumentType, true);
				var timeFormatValue = (TimeFormat)Enum.Parse(typeof(TimeFormat), timeFormat, true);

				if (issuedDocumentTypeValue == IssuedDocumentType.Invoice)
					return new List<ConfirmationSubReportModel>();

				if (issuedDocumentTypeValue != IssuedDocumentType.Confirmation && issuedDocumentTypeValue != IssuedDocumentType.Itinerary && issuedDocumentTypeValue != IssuedDocumentType.ClientStatement && issuedDocumentTypeValue != IssuedDocumentType.PersonalStatement)
					throw new InvalidOperationException("Invalid Document Type.");

				using (var lazyContext = new AppLazyContext(customerId, true)) {
					var passengerIdList = passengerIds.Split(',').Select(int.Parse).ToArray();

					IQueryable<TripLine> tripLines = null;

					if (string.IsNullOrEmpty(tripLineIds) || tripLineIds == "0") {
						tripLines = lazyContext.TripLine.Where(t1 => (quoteNo < 0 || t1.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo)) && t1.Trip.TripPassengers.Any(t2 => passengerIdList.Contains(t2.Id)));
					}
					else {
						int[] ids = tripLineIds.Split(',').Select(int.Parse).ToArray();
						tripLines = lazyContext.TripLine.Where(t => ids.Contains(t.Id));
					}

					if (issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement)
						tripLines = tripLines.Where(t => t.PersonalTravelAmount != 0);

					if (!tripLines.Any())
						return new List<ConfirmationSubReportModel>();

					int agentCommissionDiscountReasonId = AppSettings.Setting(customerId).AgentCommissionDiscountReasonId;

					int[] tripLineIdList = tripLines.Select(t => t.Id).ToArray();

					var confirmationSubReportList = new List<ConfirmationSubReportModel>();
					int packageNo = -1;

					var tripLineAir = lazyContext.TripLineAirPassenger.Where(t => t.TripLineAirPassengerAirSegments.Count > 0 && tripLineIdList.Contains(t.TripLineId) && passengerIdList.Contains(t.PassengerId) && ((issuedDocumentTypeValue == IssuedDocumentType.Confirmation && t.TripLineAir.TripLine.PrintOnConfirmation) || (issuedDocumentTypeValue == IssuedDocumentType.Itinerary && t.TripLineAir.TripLine.PrintOnItinerary) || ((issuedDocumentTypeValue == IssuedDocumentType.ClientStatement || issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement) && t.TripLineAir.TripLine.PrintOnStatement))).ToList();
                    var tripLineAirUnassigned = lazyContext.TripLineAirPassenger.Where(t => t.TripLineAirPassengerAirSegments.Count == 0 && tripLineIdList.Contains(t.TripLineId) && passengerIdList.Contains(t.PassengerId) && ((issuedDocumentTypeValue == IssuedDocumentType.Confirmation && t.TripLineAir.TripLine.PrintOnConfirmation) || (issuedDocumentTypeValue == IssuedDocumentType.Itinerary && t.TripLineAir.TripLine.PrintOnItinerary) || ((issuedDocumentTypeValue == IssuedDocumentType.ClientStatement || issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement) && t.TripLineAir.TripLine.PrintOnStatement))).ToList();
                    var tripLineOther = lazyContext.TripLine.Where(t1 => t1.TripLineType != TripLineType.Air && tripLineIdList.Contains(t1.Id) && t1.Trip.TripPassengers.Any(t2 => passengerIdList.Contains(t2.Id)) && ((issuedDocumentTypeValue == IssuedDocumentType.Confirmation && t1.PrintOnConfirmation) || (issuedDocumentTypeValue == IssuedDocumentType.Itinerary && t1.PrintOnItinerary) || ((issuedDocumentTypeValue == IssuedDocumentType.ClientStatement || issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement) && t1.PrintOnStatement))).ToList();

					if (issuedDocumentTypeValue == IssuedDocumentType.ClientStatement || issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement)
						tripLineOther = tripLineOther.Where(t => t.Voucher.VoucherType != VoucherType.PaidDirect && t.Voucher.VoucherType != VoucherType.Billback).ToList();

					ConfirmationSubReportModel confirmationSubReport = null;

					foreach (var row in GetTripItinerary(lazyContext, issuedDocumentTypeValue, tripLineIdList, passengerIdList, quoteNo, tripItineraryId)) {
						bool addRow = false;

						if (issuedDocumentTypeValue == IssuedDocumentType.Confirmation || issuedDocumentTypeValue == IssuedDocumentType.ClientStatement) {
							if (packageNo != row.TripLine.PackageNo) {
								packageNo = row.TripLine.PackageNo;
								addRow = true;
							}
						}
						else if (issuedDocumentTypeValue == IssuedDocumentType.Itinerary || issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement) {
							if (!confirmationSubReportList.Any(t => t.PackageNo == 0)) {
								packageNo = 0;
								addRow = true;
							}
						}

						if (addRow) {
							decimal packageTotalAir = 0;
							decimal packageTotalOther = 0;
							decimal discountTotal = 0;
							decimal agentCommissionTotal = 0;
							bool packageTaxApplies = false;

							if (packageNo > 0) {
								packageTotalAir = tripLineAir.Where(t => t.TripLineAir.TripLine.PackageNo == packageNo).Sum(t => (decimal?)t.GetCostToClient(customerId)) ?? 0;
								packageTotalOther = tripLineOther.Where(t => t.PackageNo == packageNo).Sum(t => (decimal?)t.CostToClient) ?? 0;

								discountTotal = (tripLineAir.Where(t => t.TripLineAir.TripLine.PackageNo == packageNo && t.DiscountReasonId != agentCommissionDiscountReasonId).Sum(t => (decimal?)t.Discount) ?? 0)
									+ (tripLineOther.Where(t => t.PackageNo == packageNo && t.DiscountReason.Id != agentCommissionDiscountReasonId).Sum(t => (decimal?)t.Discount) ?? 0);

								if (issuedDocumentTypeValue != IssuedDocumentType.Confirmation) {
									agentCommissionTotal = (tripLineAir.Where(t => t.TripLineAir.TripLine.PackageNo == packageNo && t.DiscountReasonId == agentCommissionDiscountReasonId).Sum(t => (decimal?)t.Discount) ?? 0)
										+ (tripLineOther.Where(t => t.PackageNo == packageNo && t.DiscountReason.Id == agentCommissionDiscountReasonId).Sum(t => (decimal?)t.Discount) ?? 0);
								}

								packageTaxApplies = tripLineAir.Any(t => t.TripLineAir.TripLine.PackageNo == packageNo && t.SaleType.IsTaxApplicable)
									|| tripLineOther.Any(t => t.PackageNo == packageNo && t.SaleType.IsTaxApplicable);
							}

							confirmationSubReportList.Add(new ConfirmationSubReportModel {
								PackageNo = packageNo,
								TripLineId = row.TripLine.Id,
								PackageTotal = packageTotalAir + packageTotalOther + agentCommissionTotal,
								DiscountTotal = discountTotal,
								AgentCommissionTotal = agentCommissionTotal,
								Total = 0,
								TaxTotal = 0,
								PackageTaxApplies = packageTaxApplies,
								RemarksBefore = string.Empty,
								RemarksAfter = string.Empty,
								ConfirmationDetailSubReportList = new List<ConfirmationDetailSubReportModel>()
							});
						}

						if (confirmationSubReportList.Count > 0) {
							confirmationSubReport = confirmationSubReportList.Last();
							var confirmationDetailSubReportList = confirmationSubReport.ConfirmationDetailSubReportList;

							decimal paxNoRatio = 0;

							string description = string.Empty;
							string htmlRemarksAfter = string.Empty;

							row.TripLine.GetTravelDocumentReportDetails(
								context: lazyContext,
								customerId: customerId,
								issuedDocumentType: issuedDocumentTypeValue,
								timeFormat: timeFormatValue,
								quoteNo: quoteNo,
								seqNo: row.SeqNo,
								packageNo: packageNo,
								paxNoRatio: ref paxNoRatio,
								description: ref description,
								htmlRemarkAfter: ref htmlRemarksAfter,
								tripLineAirSegmentId: row.TripLineAirSegmentId,
								passengerIds: passengerIdList,
								detailedFooter: true,
								confirmationDetailSubReportList: confirmationDetailSubReportList
							);

							if (htmlRemarksAfter.Length > 0) {
								htmlRemarksAfter = htmlRemarksAfter.TrimHtmlLineBreaks();
								confirmationSubReport.RemarksAfter = string.Format("{1}{0}{0}{2}", AppConstants.HtmlLineBreak, confirmationSubReport.RemarksBefore, htmlRemarksAfter);
							}

							confirmationSubReport = confirmationSubReportList.Last();
						}
					}

					if (confirmationSubReport != null) {
						if (issuedDocumentTypeValue != IssuedDocumentType.Itinerary) {
							if (issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement) {
								confirmationSubReport.TaxTotal = (tripLineAir.Sum(t => (decimal?)t.GetPersonalTravelAmountTax(customerId, t.TripLineAir.TripLine.StartDate == DateTime.MinValue ? t.TripLineAir.TripLine.Trip.DepartureDate : t.TripLineAir.TripLine.StartDate)) ?? 0) + (tripLineOther.Sum(t => (decimal?)t.GetPersonalTravelAmountTax(customerId, t.StartDate == DateTime.MinValue ? t.Trip.DepartureDate : t.StartDate)) ?? 0);
								confirmationSubReport.Total = (tripLineAir.Sum(t => (decimal?)t.PersonalTravelAmount) ?? 0) + (tripLineOther.Sum(t => (decimal?)t.PersonalTravelAmount) ?? 0);
							}
							else {
								confirmationSubReport.TaxTotal = (tripLineAir.Sum(t => (decimal?)t.GetCostToClientTax(customerId, t.TripLineAir.TripLine.StartDate == DateTime.MinValue ? t.TripLineAir.TripLine.Trip.DepartureDate : t.TripLineAir.TripLine.StartDate)) ?? 0) + (tripLineOther.Sum(t => (decimal?)t.GetCostToClientTax(customerId, t.StartDate == DateTime.MinValue ? t.Trip.DepartureDate : t.StartDate)) ?? 0);
								confirmationSubReport.Total = (tripLineAir.Sum(t => (decimal?)t.GetCostToClient(customerId)) ?? 0) + (tripLineOther.Sum(t => (decimal?)t.GetCostToClient(customerId)) ?? 0);
							}
						}

						confirmationSubReport.TaxTotal += tripLineAirUnassigned.Sum(t => (decimal?)t.GetCostToClientTax(customerId, t.TripLineAir.TripLine.StartDate == DateTime.MinValue ? t.TripLineAir.TripLine.Trip.DepartureDate : t.TripLineAir.TripLine.StartDate)) ?? 0;
						confirmationSubReport.Total += tripLineAirUnassigned.Sum(t => (decimal?)t.GetCostToClient(customerId)) ?? 0;
					}

                    if (confirmationSubReportList.Any(t => t.PackageNo > 0 && t.PackageTaxApplies)) {
						foreach (var row in confirmationSubReportList.Where(t => t.PackageNo == 0).ToList()) {
							row.PackageTaxApplies = true;
						}
					}

					foreach (var row1 in confirmationSubReportList) {
						foreach (var row2 in row1.ConfirmationDetailSubReportList) {
							row2.Header1 = string.Format("{0:0000}{1}", row2.SeqNo, row2.Header1);
						}
					}

					return confirmationSubReportList;
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "ConfirmationSubReport", ex, customerId);
				return new List<ConfirmationSubReportModel>();
			}
		}

		private List<TripItineraryReportModel> GetTripItinerary(AppLazyContext lazyContext, IssuedDocumentType issuedDocumentType, int[] tripLineIds, int[] passengerIds, int quoteNo, int tripItineraryId) {
			IEnumerable<TripItineraryReportModel> itineraryDetailList = null;
			bool orderByPackage = false;

			if (issuedDocumentType == IssuedDocumentType.Itinerary && lazyContext.TripItineraryDetail.Any(t => t.TripItineraryId == tripItineraryId)) {
				itineraryDetailList = lazyContext.TripItineraryDetail.Where(t => t.TripItineraryId == tripItineraryId).AsEnumerable()
					.Select(row => new TripItineraryReportModel {
						TripLine = row.TripLine,
						TripLineAirSegmentId = row.TripLineAirSegmentId,
						TripLineAirPassengerId = 0,
						SeqNo = row.SeqNo
					});
			}
			else {
				IQueryable<TripLine> q = null;

				if (issuedDocumentType != IssuedDocumentType.Itinerary && lazyContext.TripLineSelection.Any(t => tripLineIds.Contains(t.TripLineId) && t.QuoteNo == quoteNo)) {
					q = lazyContext.TripLineSelection.Where(t => tripLineIds.Contains(t.TripLineId) && t.QuoteNo == quoteNo).Select(t => t.TripLine);
				}
				else {
					q = lazyContext.TripLine.Where(t => tripLineIds.Contains(t.Id));
					orderByPackage = issuedDocumentType != IssuedDocumentType.Itinerary;
				}

				itineraryDetailList = q.Where(t1 => t1.TripLineType != TripLineType.Air && t1.Trip.TripPassengers.Any(t2 => passengerIds.Contains(t2.Id))).AsEnumerable()
					.Select(row => new TripItineraryReportModel {
						TripLine = row,
						TripLineAirSegmentId = 0,
						TripLineAirPassengerId = 0,
						SeqNo = row.TripLineSelections.SingleOrDefault(t => t.QuoteNo == quoteNo)?.SeqNo ?? 0
					}).Concat(q.Where(t1 => t1.TripLineType == TripLineType.Air && lazyContext.TripLineAirPassenger.Any(t2 => t2.TripLineId == t1.Id && passengerIds.Contains(t2.PassengerId))).SelectMany(t1 => t1.TripLineAir.TripLineAirSegments).AsEnumerable()
					.Select(row => new TripItineraryReportModel {
						TripLine = row.TripLineAir.TripLine,
						TripLineAirSegmentId = row.Id,
						TripLineAirPassengerId = 0,
						SeqNo = (row.TripLineAir.TripLine.TripLineSelections.SingleOrDefault(t => t.QuoteNo == quoteNo)?.SeqNo ?? 0) + ((decimal)row.SeqNo / 100)
                    }));

				switch (issuedDocumentType) {
					case IssuedDocumentType.Confirmation:
						itineraryDetailList = itineraryDetailList.Where(t => t.TripLine.PrintOnConfirmation);
						break;
					case IssuedDocumentType.Itinerary:
						itineraryDetailList = itineraryDetailList.Where(t => t.TripLine.PrintOnItinerary);
						break;
					case IssuedDocumentType.ClientStatement:
					case IssuedDocumentType.PersonalStatement:
						itineraryDetailList = itineraryDetailList.Where(t => t.TripLine.PrintOnStatement);
						break;
				}
			}

			if (orderByPackage) {
				itineraryDetailList = itineraryDetailList.OrderBy(t => t.TripLine.PackageNo == 0 ? 1 : 0).ThenBy(t => t.TripLine.PackageNo).ThenBy(t => t.TripLine.Id).ThenBy(t => t.TripLine.StartDate).ThenBy(t => t.TripLine.EndDate);
			}
			else if (itineraryDetailList.Any(t => t.SeqNo > 0)) {
				itineraryDetailList = itineraryDetailList.OrderBy(t => t.SeqNo);
			}
			else {
				itineraryDetailList = itineraryDetailList.OrderBy(t => t.TripLine.StartDate).ThenBy(t => t.TripLine.EndDate);
			}

			return itineraryDetailList.ToList();
		}

		public static TypeReportSource GetReportSource(ClientReportSourceModel model) {
			string typeName;
			string reportName;
			string description;

			var sb = new StringBuilder();

			switch (model.ReportSource) {
				default:
					throw new InvalidOperationException("Invalid Report Source.");
				case ReportSourceClient.TrialBalance:
					reportName = string.Format("{0} {1}", GetReportName(model.ReportSource), model.LedgerDocumentType.GetEnumDescription());
					typeName = typeof(ClientTrialBalanceReport).AssemblyQualifiedName;

					sb.AppendFormat("Commission Type: {0}", model.CommissionValueType == Biz.Enums.ValueType.Net ? "Net" : "Gross");
					sb.AppendFormat(" | Balances: {0}", (model.TransactionBalanceType ?? TransactionBalanceType.None) == TransactionBalanceType.None ? "All Balances" : model.TransactionBalanceType.GetEnumDescription());

					description = "Departure Date:";

					if (model.DepartureDateFrom == null && model.DepartureDateTo == null) {
						description = string.Format("{0} All Dates", description);
					}
					else if (model.DepartureDateTo == null) {
						description = string.Format("{0} From {1:dd-MMM-yyyy}", description, model.DepartureDateFrom);
					}
					else if (model.DepartureDateFrom == null) {
						description = string.Format("{0} To {1:dd-MMM-yyyy}", description, model.DepartureDateTo);
					}
					else {
						description = string.Format("{0} From {1:dd-MMM-yyyy} To {2:dd-MMM-yyyy}", description, model.DepartureDateFrom, model.DepartureDateTo);
					}

					if (model.IncludeOpenDated)
						description = string.Format("{0} (open-dated included)", description);

					sb.AppendFormat(" | {0}", description);
					description = "Transaction Date:";

					if (model.TxnDateFrom == null && model.TxnDateTo == null) {
						description = string.Format("{0} All Dates", description);
					}
					else if (model.TxnDateTo == null) {
						description = string.Format("{0} From {1:dd-MMM-yyyy}", description, model.TxnDateFrom);
					}
					else if (model.TxnDateFrom == null) {
						description = string.Format("{0} To {1:dd-MMM-yyyy}", description, model.TxnDateTo);
					}
					else {
						description = string.Format("{0} From {1:dd-MMM-yyyy} To {2:dd-MMM-yyyy}", description, model.TxnDateFrom, model.TxnDateTo);
					}

					sb.AppendFormat(" | {0}", description);
					description = "Trip:";

					if ((model.TripIdFrom == null || model.TripIdFrom <= 0) && (model.TripIdTo == null || model.TripIdTo <= 0)) {
						description = string.Format("{0} All Trips", description);
					}
					else if (model.TripIdTo == null || model.TripIdTo <= 0) {
						description = string.Format("{0} From {1}", description, model.TripNoFrom);
					}
					else if (model.TripIdFrom == null || model.TripIdFrom <= 0) {
						description = string.Format("{0} To {1}", description, model.TripNoTo);
					}
					else {
						description = string.Format("{0} From {1} To {2}", description, model.TripNoFrom, model.TripNoTo);
					}

					sb.AppendFormat(" | {0}", description);
					description = string.Empty;

					if (model.GroupByAgency)
						description = string.Format("{0} Agencies (L{1}), ", description, model.AgencyLevel);

					if (model.GroupByAgent)
						description = string.Format("{0} Agents (L{1}), ", description, model.AgentLevel);

					if (model.GroupByCategory)
						description = string.Format("{0} Categories (L{1}), ", description, model.CategoryLevel);

					if (model.GroupByClass)
						description = string.Format("{0} Classes (L{1}), ", description, model.ClassLevel);

					if (model.GroupByConsultant)
						description = string.Format("{0} Consultants (L{1}), ", description, model.ConsultantLevel);

					if (model.GroupByDebtor)
						description = string.Format("{0} Debtors (L{1}), ", description, model.DebtorLevel);

					if (model.GroupByDestination)
						description = string.Format("{0} Destinations (L{1}), ", description, model.DestinationLevel);

					if (model.GroupByGroup)
						description = string.Format("{0} Groups (L{1}), ", description, model.GroupLevel);

					if (model.GroupByLocation)
						description = string.Format("{0} Locations (L{1}), ", description, model.LocationLevel);

					if (model.GroupBySource)
						description = string.Format("{0} Sources (L{1}), ", description, model.SourceLevel);

					if (!string.IsNullOrEmpty(description))
						sb.AppendFormat("{0}Filters/Groups: {1}", AppConstants.HtmlLineBreak, description.TrimEnd(", "));

					break;
			}

			var reportSource = new TypeReportSource {
				TypeName = typeName
			};

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = model.CustomerId });
			reportSource.Parameters.Add(new Parameter { Name = "reportSourceId", Value = (int)model.ReportSource });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = model.CreationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = model.CreationTime });
			reportSource.Parameters.Add(new Parameter { Name = "reportName", Value = reportName });
			reportSource.Parameters.Add(new Parameter { Name = "reportDate", Value = (model.ReportDate ?? DateTime.MinValue).ToShortDateStringExt() });
			reportSource.Parameters.Add(new Parameter { Name = "headerContent", Value = Utils.HtmlEncodeExceptTags(sb.ToString()) });

			reportSource.Parameters.Add(new Parameter { Name = "reportOrderId", Value = model.ReportOrderId ?? 0 });
			reportSource.Parameters.Add(new Parameter { Name = "commissionValueTypeId", Value = (int)(model.CommissionValueType ?? Biz.Enums.ValueType.Net) });
			reportSource.Parameters.Add(new Parameter { Name = "transactionBalanceTypeId", Value = (int)(model.TransactionBalanceType ?? TransactionBalanceType.None) });

			reportSource.Parameters.Add(new Parameter { Name = "departureDateFrom", Value = model.DepartureDateFrom });
			reportSource.Parameters.Add(new Parameter { Name = "departureDateTo", Value = model.DepartureDateTo });
			reportSource.Parameters.Add(new Parameter { Name = "txnDateFrom", Value = model.TxnDateFrom });
			reportSource.Parameters.Add(new Parameter { Name = "txnDateTo", Value = model.TxnDateTo });
			reportSource.Parameters.Add(new Parameter { Name = "includeOpenDated", Value = model.IncludeOpenDated });

			reportSource.Parameters.Add(new Parameter { Name = "tripIdFrom", Value = model.TripIdFrom ?? 0 });
			reportSource.Parameters.Add(new Parameter { Name = "tripIdTo", Value = model.TripIdTo ?? 0 });

			reportSource.Parameters.Add(new Parameter { Name = "agencyIds", Value = string.Join(",", model.AgencyIds ?? new int[] { 0 }) });
			reportSource.Parameters.Add(new Parameter { Name = "agentIds", Value = string.Join(",", model.AgentIds ?? new int[] { 0 }) });
			reportSource.Parameters.Add(new Parameter { Name = "categoryIds", Value = string.Join(",", model.CategoryIds ?? new int[] { 0 }) });
			reportSource.Parameters.Add(new Parameter { Name = "classIds", Value = string.Join(",", model.ClassIds ?? new int[] { 0 }) });
			reportSource.Parameters.Add(new Parameter { Name = "consultantIds", Value = string.Join(",", model.ConsultantIds ?? new int[] { 0 }) });
			reportSource.Parameters.Add(new Parameter { Name = "debtorIds", Value = string.Join(",", model.DebtorIds ?? new int[] { 0 }) });
			reportSource.Parameters.Add(new Parameter { Name = "destinationIds", Value = string.Join(",", model.DestinationIds ?? new int[] { 0 }) });
			reportSource.Parameters.Add(new Parameter { Name = "groupIds", Value = string.Join(",", model.GroupIds ?? new int[] { 0 }) });
			reportSource.Parameters.Add(new Parameter { Name = "locationIds", Value = string.Join(",", model.LocationIds ?? new int[] { 0 }) });
			reportSource.Parameters.Add(new Parameter { Name = "sourceIds", Value = string.Join(",", model.SourceIds ?? new int[] { 0 }) });

			reportSource.Parameters.Add(new Parameter { Name = "groupByAgency", Value = model.GroupByAgency });
			reportSource.Parameters.Add(new Parameter { Name = "groupByAgent", Value = model.GroupByAgent });
			reportSource.Parameters.Add(new Parameter { Name = "groupByCategory", Value = model.GroupByCategory });
			reportSource.Parameters.Add(new Parameter { Name = "groupByClass", Value = model.GroupByClass });
			reportSource.Parameters.Add(new Parameter { Name = "groupByConsultant", Value = model.GroupByConsultant });
			reportSource.Parameters.Add(new Parameter { Name = "groupByDebtor", Value = model.GroupByDebtor });
			reportSource.Parameters.Add(new Parameter { Name = "groupByDestination", Value = model.GroupByDestination });
			reportSource.Parameters.Add(new Parameter { Name = "groupByGroup", Value = model.GroupByGroup });
			reportSource.Parameters.Add(new Parameter { Name = "groupByLocation", Value = model.GroupByLocation });
			reportSource.Parameters.Add(new Parameter { Name = "groupBySource", Value = model.GroupBySource });

			reportSource.Parameters.Add(new Parameter { Name = "agencyNewPage", Value = model.AgencyNewPage });
			reportSource.Parameters.Add(new Parameter { Name = "agentNewPage", Value = model.AgentNewPage });
			reportSource.Parameters.Add(new Parameter { Name = "categoryNewPage", Value = model.CategoryNewPage });
			reportSource.Parameters.Add(new Parameter { Name = "classNewPage", Value = model.ClassNewPage });
			reportSource.Parameters.Add(new Parameter { Name = "consultantNewPage", Value = model.ConsultantNewPage });
			reportSource.Parameters.Add(new Parameter { Name = "debtorNewPage", Value = model.DebtorNewPage });
			reportSource.Parameters.Add(new Parameter { Name = "destinationNewPage", Value = model.DestinationNewPage });
			reportSource.Parameters.Add(new Parameter { Name = "groupNewPage", Value = model.GroupNewPage });
			reportSource.Parameters.Add(new Parameter { Name = "locationNewPage", Value = model.LocationNewPage });
			reportSource.Parameters.Add(new Parameter { Name = "sourceNewPage", Value = model.SourceNewPage });

			reportSource.Parameters.Add(new Parameter { Name = "agencyLevel", Value = model.AgencyLevel });
			reportSource.Parameters.Add(new Parameter { Name = "agentLevel", Value = model.AgentLevel });
			reportSource.Parameters.Add(new Parameter { Name = "categoryLevel", Value = model.CategoryLevel });
			reportSource.Parameters.Add(new Parameter { Name = "classLevel", Value = model.ClassLevel });
			reportSource.Parameters.Add(new Parameter { Name = "consultantLevel", Value = model.ConsultantLevel });
			reportSource.Parameters.Add(new Parameter { Name = "debtorLevel", Value = model.DebtorLevel });
			reportSource.Parameters.Add(new Parameter { Name = "destinationLevel", Value = model.DestinationLevel });
			reportSource.Parameters.Add(new Parameter { Name = "groupLevel", Value = model.GroupLevel });
			reportSource.Parameters.Add(new Parameter { Name = "locationLevel", Value = model.LocationLevel });
			reportSource.Parameters.Add(new Parameter { Name = "sourceLevel", Value = model.SourceLevel });

			switch (model.ReportSource) {
				case 0:
					reportSource.Parameters.Add(new Parameter { Name = "customerName", Value = Utils.GetCustomerName(model.CustomerId, model.DefaultAgency) });
					reportSource.Parameters.Add(new Parameter { Name = "ledgerDocumentTypeId", Value = (int)model.LedgerDocumentType });
					break;
			}

			return reportSource;
		}

		public static TypeReportSource GetQuoteReportSource(int customerId, int agencyId, int quoteNo, TimeFormat timeFormat, string tripLineIds, string passengerIds, DateTime creationTime, string creationUser) {
			var reportSource = new TypeReportSource {
				TypeName = typeof(QuoteReport).AssemblyQualifiedName
			};

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = customerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = agencyId });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = creationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = creationTime });
			reportSource.Parameters.Add(new Parameter { Name = "quoteNo", Value = quoteNo });
			reportSource.Parameters.Add(new Parameter { Name = "issuedDocumentType", Value = nameof(IssuedDocumentType.Quote) });
			reportSource.Parameters.Add(new Parameter { Name = "timeFormat", Value = timeFormat.ToString() });
			reportSource.Parameters.Add(new Parameter { Name = "tripLineIds", Value = tripLineIds.ToStringExt() });
			reportSource.Parameters.Add(new Parameter { Name = "passengerIds", Value = passengerIds.ToStringExt() });

			return reportSource;
		}

		public static TypeReportSource GetConfirmationReportSource(int customerId, int agencyId, string imagePath, int quoteNo, TimeFormat timeFormat, string tripLineIds, string passengerIds, DateTime creationTime, string creationUser) {
			if (quoteNo != 0)
				throw new UnreportedException("This document can only be printed from a booking.");

			var reportSource = new TypeReportSource {
				TypeName = typeof(ConfirmationReport).AssemblyQualifiedName
			};

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = customerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = agencyId });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = creationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = creationTime });
			reportSource.Parameters.Add(new Parameter { Name = "imagePath", Value = imagePath.ToStringExt().Replace(@"\", @"\\") });
			reportSource.Parameters.Add(new Parameter { Name = "quoteNo", Value = quoteNo });
			reportSource.Parameters.Add(new Parameter { Name = "tripItineraryId", Value = 0 });
			reportSource.Parameters.Add(new Parameter { Name = "issuedDocumentType", Value = nameof(IssuedDocumentType.Confirmation) });
			reportSource.Parameters.Add(new Parameter { Name = "timeFormat", Value = timeFormat.ToString() });
			reportSource.Parameters.Add(new Parameter { Name = "tripLineIds", Value = tripLineIds.ToStringExt() });
			reportSource.Parameters.Add(new Parameter { Name = "passengerIds", Value = passengerIds.ToStringExt() });

			return reportSource;
		}

		public static TypeReportSource GetItineraryReportSource(int customerId, int agencyId, string imagePath, int quoteNo, int tripItineraryId, TimeFormat timeFormat, string tripLineIds, string passengerIds, DateTime creationTime, string creationUser) {
			int[] tripLineIdList = null;
			int[] passengerIdList = null;

			if (!string.IsNullOrEmpty(tripLineIds))
				tripLineIdList = tripLineIds.Split(',').Select(int.Parse).ToArray();

			passengerIdList = passengerIds.Split(',').Select(int.Parse).ToArray();
			return GetItineraryReportSource(customerId, agencyId, imagePath, quoteNo, tripItineraryId, timeFormat, tripLineIdList, passengerIdList, creationTime, creationUser);
		}

		public static TypeReportSource GetItineraryReportSource(int customerId, int agencyId, string imagePath, int quoteNo, int tripItineraryId, TimeFormat timeFormat, int[] tripLineIds, int[] passengerIds, DateTime creationTime, string creationUser) {
			if (quoteNo != 0)
				throw new UnreportedException("This document can only be printed from a booking.");

			var reportSource = new TypeReportSource {
				TypeName = typeof(ConfirmationReport).AssemblyQualifiedName
			};

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = customerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = agencyId });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = creationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = creationTime });
			reportSource.Parameters.Add(new Parameter { Name = "imagePath", Value = imagePath.ToStringExt().Replace(@"\", @"\\") });
			reportSource.Parameters.Add(new Parameter { Name = "quoteNo", Value = quoteNo });
			reportSource.Parameters.Add(new Parameter { Name = "tripItineraryId", Value = tripItineraryId });
			reportSource.Parameters.Add(new Parameter { Name = "issuedDocumentType", Value = nameof(IssuedDocumentType.Itinerary) });
			reportSource.Parameters.Add(new Parameter { Name = "timeFormat", Value = timeFormat.ToString() });
			reportSource.Parameters.Add(new Parameter { Name = "tripLineIds", Value = string.Join(",", tripLineIds ?? new int[] { 0 }) });
			reportSource.Parameters.Add(new Parameter { Name = "passengerIds", Value = string.Join(",", passengerIds ?? new int[] { 0 }) });

			return reportSource;
		}

		public static string GetReportName(ReportSourceClient reportSource) {
            switch (reportSource) {
                default:
                    throw new InvalidOperationException("Invalid Report Source.");
                case ReportSourceClient.TrialBalance:
                    return "Client Account Trial Balance";
            }
        }

        public static string GetReportFileName(ReportSourceClient reportSource) {
            return WebUtility.HtmlDecode(GetReportName(reportSource));
        }
    }
}