using System;
using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Resources;

namespace Travelog.Reports.ClientLedger {
	public partial class QuoteReport : TelerikReport {
		public QuoteReport() {
			InitializeComponent();
		}

		private void TaxNo_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			if (textBox.Value.ToStringExt() != string.Empty)
				textBox.Value = string.Format("{0}: {1}", Resource.TaxNoLabel, textBox.Value);
		}
	}
}