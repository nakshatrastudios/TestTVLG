using Telerik.Reporting;

namespace Travelog.Reports.ClientLedger {
	public partial class QuoteSubSubReport : TelerikReport {
		public QuoteSubSubReport() {
			InitializeComponent();
		}
	}
}