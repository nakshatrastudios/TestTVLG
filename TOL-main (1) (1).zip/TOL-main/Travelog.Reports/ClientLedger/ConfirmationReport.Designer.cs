namespace Travelog.Reports.ClientLedger {
	partial class ConfirmationReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TypeReportSource typeReportSource2 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TypeReportSource typeReportSource3 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.TypeReportSource typeReportSource4 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter11 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter12 = new Telerik.Reporting.ReportParameter();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.AgencyFooterSubReport = new Telerik.Reporting.SubReport();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.AgencyHeaderSubReport1 = new Telerik.Reporting.SubReport();
			this.ReportNameLabel = new Telerik.Reporting.TextBox();
			this.TripNo = new Telerik.Reporting.TextBox();
			this.HeaderPanel = new Telerik.Reporting.Panel();
			this.TaxNo = new Telerik.Reporting.TextBox();
			this.Consultant = new Telerik.Reporting.TextBox();
			this.DocumentDate = new Telerik.Reporting.TextBox();
			this.DepartureDate = new Telerik.Reporting.TextBox();
			this.GroupFooterSection2 = new Telerik.Reporting.GroupFooterSection();
			this.GroupHeaderSection2 = new Telerik.Reporting.GroupHeaderSection();
			this.FullName = new Telerik.Reporting.TextBox();
			this.Address = new Telerik.Reporting.TextBox();
			this.AgencyHeaderSubReport2 = new Telerik.Reporting.SubReport();
			this.Passengers = new Telerik.Reporting.TextBox();
			this.StandardComment = new Telerik.Reporting.TextBox();
			this.PassengersLabel = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.ConfirmationSubReport = new Telerik.Reporting.SubReport();
			this.Pages = new Telerik.Reporting.TextBox();
			this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.CanShrink = true;
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AgencyFooterSubReport});
			this.GroupFooterSection1.KeepTogether = false;
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			// 
			// AgencyFooterSubReport
			// 
			this.AgencyFooterSubReport.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AgencyFooterSubReport.Name = "AgencyFooterSubReport";
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
			typeReportSource1.TypeName = "Travelog.Reports.Common.AgencyFooterSubReport, Travelog.Reports, Version=1.0.0.0," +
    " Culture=neutral, PublicKeyToken=null";
			this.AgencyFooterSubReport.ReportSource = typeReportSource1;
			this.AgencyFooterSubReport.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.AgencyFooterSubReport.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AgencyFooterSubReport.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(3.25D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AgencyHeaderSubReport1,
            this.ReportNameLabel,
            this.TripNo,
            this.HeaderPanel});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = false;
			this.GroupHeaderSection1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.25D);
			// 
			// AgencyHeaderSubReport1
			// 
			this.AgencyHeaderSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AgencyHeaderSubReport1.Name = "AgencyHeaderSubReport1";
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
			typeReportSource2.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
			typeReportSource2.TypeName = "Travelog.Reports.Common.AgencyHeaderSubReport1, Travelog.Reports, Version=1.0.0.0" +
    ", Culture=neutral, PublicKeyToken=null";
			this.AgencyHeaderSubReport1.ReportSource = typeReportSource2;
			this.AgencyHeaderSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.AgencyHeaderSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// ReportNameLabel
			// 
			this.ReportNameLabel.CanShrink = true;
			this.ReportNameLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ReportNameLabel.Name = "ReportNameLabel";
			this.ReportNameLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(0.75D));
			this.ReportNameLabel.Style.Font.Name = "Calibri";
			this.ReportNameLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(18D);
			this.ReportNameLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.ReportNameLabel.Value = "= IIf(Parameters.issuedDocumentType.Value = \"Confirmation\", \"CONFIRMATION\", \"ITIN" +
    "ERARY\")";
			// 
			// TripNo
			// 
			this.TripNo.CanShrink = true;
			this.TripNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.75D));
			this.TripNo.Name = "TripNo";
			this.TripNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(0.76D));
			this.TripNo.Style.Font.Bold = false;
			this.TripNo.Style.Font.Name = "Calibri";
			this.TripNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(14D);
			this.TripNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TripNo.Value = "= Fields.TripNo";
			// 
			// HeaderPanel
			// 
			this.HeaderPanel.CanShrink = true;
			this.HeaderPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TaxNo,
            this.Consultant,
            this.DocumentDate,
            this.DepartureDate});
			this.HeaderPanel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.HeaderPanel.Name = "HeaderPanel";
			this.HeaderPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(2D));
			// 
			// TaxNo
			// 
			this.TaxNo.CanShrink = true;
			this.TaxNo.Format = "";
			this.TaxNo.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TaxNo.Name = "TaxNo";
			this.TaxNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.TaxNo.Style.Font.Bold = true;
			this.TaxNo.Style.Font.Name = "Calibri";
			this.TaxNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TaxNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TaxNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TaxNo.Value = "= Fields.TaxNo";
			this.TaxNo.ItemDataBound += new System.EventHandler(this.TaxNo_ItemDataBound);
			// 
			// Consultant
			// 
			this.Consultant.CanShrink = true;
			this.Consultant.Format = "";
			this.Consultant.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.5D));
			this.Consultant.Name = "Consultant";
			this.Consultant.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Consultant.Style.Font.Name = "Calibri";
			this.Consultant.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Consultant.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Consultant.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Consultant.Value = "= \"Issued By: \" + Fields.Consultant";
			// 
			// DocumentDate
			// 
			this.DocumentDate.CanShrink = true;
			this.DocumentDate.Format = "";
			this.DocumentDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.DocumentDate.Name = "DocumentDate";
			this.DocumentDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.DocumentDate.Style.Font.Name = "Calibri";
			this.DocumentDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDate.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.DocumentDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDate.Value = "= Format(\"Date: {0:dd-MMM-yyyy}\", Fields.DocumentDate)";
			// 
			// DepartureDate
			// 
			this.DepartureDate.CanShrink = true;
			this.DepartureDate.Format = "";
			this.DepartureDate.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.DepartureDate.Name = "DepartureDate";
			this.DepartureDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.DepartureDate.Style.Font.Name = "Calibri";
			this.DepartureDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DepartureDate.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.DepartureDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DepartureDate.Value = "= Format(\"Departure Date: {0:dd-MMM-yyyy}\", Fields.DepartureDate)";
			// 
			// GroupFooterSection2
			// 
			this.GroupFooterSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupFooterSection2.Name = "GroupFooterSection2";
			this.GroupFooterSection2.Style.Visible = false;
			// 
			// GroupHeaderSection2
			// 
			this.GroupHeaderSection2.CanShrink = true;
			this.GroupHeaderSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(4.6D);
			this.GroupHeaderSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.FullName,
            this.Address,
            this.AgencyHeaderSubReport2,
            this.Passengers,
            this.StandardComment,
            this.PassengersLabel});
			this.GroupHeaderSection2.KeepTogether = false;
			this.GroupHeaderSection2.Name = "GroupHeaderSection2";
			this.GroupHeaderSection2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			// 
			// FullName
			// 
			this.FullName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.FullName.Name = "FullName";
			this.FullName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.FullName.Style.Font.Bold = true;
			this.FullName.Style.Font.Name = "Calibri";
			this.FullName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(11D);
			this.FullName.Value = "= Fields.FullName";
			// 
			// Address
			// 
			this.Address.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Address.Name = "Address";
			this.Address.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Address.Style.Font.Name = "Calibri";
			this.Address.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Address.Value = "= Fields.Address";
			// 
			// AgencyHeaderSubReport2
			// 
			this.AgencyHeaderSubReport2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.25D));
			this.AgencyHeaderSubReport2.Name = "AgencyHeaderSubReport2";
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("agencyId", "= Parameters.agencyId.Value"));
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
			typeReportSource3.Parameters.Add(new Telerik.Reporting.Parameter("removePadding", "= True"));
			typeReportSource3.TypeName = "Travelog.Reports.Common.AgencyHeaderSubReport2, Travelog.Reports, Version=1.0.0.0" +
    ", Culture=neutral, PublicKeyToken=null";
			this.AgencyHeaderSubReport2.ReportSource = typeReportSource3;
			this.AgencyHeaderSubReport2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AgencyHeaderSubReport2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// Passengers
			// 
			this.Passengers.CanShrink = true;
			this.Passengers.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.6D));
			this.Passengers.Name = "Passengers";
			this.Passengers.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Passengers.Style.Font.Name = "Calibri";
			this.Passengers.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Passengers.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Passengers.Value = "= Fields.Passengers";
			// 
			// StandardComment
			// 
			this.StandardComment.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(IsNull(Fields.StandardComment, \"\") = \"\", False, True)"));
			this.StandardComment.CanShrink = true;
			this.StandardComment.KeepTogether = false;
			this.StandardComment.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.1D));
			this.StandardComment.Name = "StandardComment";
			this.StandardComment.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.StandardComment.Style.Font.Name = "Calibri";
			this.StandardComment.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.StandardComment.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			this.StandardComment.Value = "= Fields.StandardComment";
			// 
			// PassengersLabel
			// 
			this.PassengersLabel.CanShrink = true;
			this.PassengersLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.1D));
			this.PassengersLabel.Name = "PassengersLabel";
			this.PassengersLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.PassengersLabel.Style.Font.Bold = true;
			this.PassengersLabel.Style.Font.Name = "Calibri";
			this.PassengersLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.PassengersLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.PassengersLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.PassengersLabel.Value = "Passengers";
			// 
			// Detail
			// 
			this.Detail.CanShrink = true;
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ConfirmationSubReport});
			this.Detail.KeepTogether = false;
			this.Detail.Name = "Detail";
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// ConfirmationSubReport
			// 
			this.ConfirmationSubReport.KeepTogether = false;
			this.ConfirmationSubReport.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ConfirmationSubReport.Name = "ConfirmationSubReport";
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("customerId", "= Parameters.customerId.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("imagePath", "= Parameters.imagePath.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("tripLineIds", "= Parameters.tripLineIds.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("passengerIds", "= Parameters.passengerIds.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("quoteNo", "= Parameters.quoteNo.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("tripItineraryId", "= Parameters.tripItineraryId.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("issuedDocumentType", "= Parameters.issuedDocumentType.Value"));
			typeReportSource4.Parameters.Add(new Telerik.Reporting.Parameter("timeFormat", "= Parameters.timeFormat.Value"));
			typeReportSource4.TypeName = "Travelog.Reports.ClientLedger.ConfirmationSubReport, Travelog.Reports, Version=1." +
    "0.0.0, Culture=neutral, PublicKeyToken=null";
			this.ConfirmationSubReport.ReportSource = typeReportSource4;
			this.ConfirmationSubReport.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.3D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ConfirmationSubReport.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// Pages
			// 
			this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Name = "Pages";
			this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Style.Color = System.Drawing.Color.DarkGray;
			this.Pages.Style.Font.Name = "Calibri";
			this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Pages.Value = "= \"Page \" + PageNumber + \" of \" + PageCount";
			// 
			// PageFooterSection
			// 
			this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages});
			this.PageFooterSection.Name = "PageFooterSection";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "ConfirmationReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.ClientLedger.ClientLedgerDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("tripLineIds", typeof(string), "= Parameters.tripLineIds.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("passengerIds", typeof(string), "= Parameters.passengerIds.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("quoteNo", typeof(int), "= Parameters.quoteNo.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("issuedDocumentType", typeof(string), "= Parameters.issuedDocumentType.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("creationTime", typeof(System.DateTime), "= Parameters.creationTime.Value"));
			// 
			// ConfirmationReport
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.Name = "Group1";
			group2.GroupFooter = this.GroupFooterSection2;
			group2.GroupHeader = this.GroupHeaderSection2;
			group2.Name = "Group2";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.GroupHeaderSection2,
            this.GroupFooterSection2,
            this.Detail,
            this.PageFooterSection});
			this.Name = "ConfirmationReport";
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.35D), Telerik.Reporting.Drawing.Unit.Cm(1.35D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter2.Name = "customerId";
			reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter3.Name = "agencyId";
			reportParameter3.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter4.Name = "imagePath";
			reportParameter5.Name = "quoteNo";
			reportParameter5.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter6.Name = "tripItineraryId";
			reportParameter6.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter7.Name = "issuedDocumentType";
			reportParameter8.Name = "timeFormat";
			reportParameter9.Name = "creationUser";
			reportParameter10.Name = "creationTime";
			reportParameter10.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter11.Name = "tripLineIds";
			reportParameter12.Name = "passengerIds";
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.ReportParameters.Add(reportParameter9);
			this.ReportParameters.Add(reportParameter10);
			this.ReportParameters.Add(reportParameter11);
			this.ReportParameters.Add(reportParameter12);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(18.3D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection2;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection2;
		private Telerik.Reporting.TextBox FullName;
		private Telerik.Reporting.TextBox Address;
		private Telerik.Reporting.SubReport ConfirmationSubReport;
		private Telerik.Reporting.SubReport AgencyFooterSubReport;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.TextBox TripNo;
		private Telerik.Reporting.TextBox ReportNameLabel;
		private Telerik.Reporting.SubReport AgencyHeaderSubReport1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.Panel HeaderPanel;
		private Telerik.Reporting.TextBox TaxNo;
		private Telerik.Reporting.TextBox Consultant;
		private Telerik.Reporting.TextBox DocumentDate;
		private Telerik.Reporting.TextBox DepartureDate;
		private Telerik.Reporting.SubReport AgencyHeaderSubReport2;
		private Telerik.Reporting.TextBox Passengers;
		private Telerik.Reporting.TextBox StandardComment;
		private Telerik.Reporting.TextBox PassengersLabel;
	}
}