namespace Travelog.Reports.ClientLedger {
	partial class QuoteSubReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
            Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
            Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
            Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
            this.GroupFooterSection2 = new Telerik.Reporting.GroupFooterSection();
            this.RemarksAfter = new Telerik.Reporting.HtmlTextBox();
            this.GroupHeaderSection2 = new Telerik.Reporting.GroupHeaderSection();
            this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
            this.TotalsPanel = new Telerik.Reporting.Panel();
            this.OtherInclusionTotal1 = new Telerik.Reporting.TextBox();
            this.OtherInclusionTotal2 = new Telerik.Reporting.TextBox();
            this.ServiceFeeTotal1 = new Telerik.Reporting.TextBox();
            this.ServiceFeeTotal2 = new Telerik.Reporting.TextBox();
            this.ForeignCurrencyTotal1 = new Telerik.Reporting.TextBox();
            this.ForeignCurrencyTotal2 = new Telerik.Reporting.TextBox();
            this.AccommodationTotal1 = new Telerik.Reporting.TextBox();
            this.AirTotal1 = new Telerik.Reporting.TextBox();
            this.AccommodationTotal2 = new Telerik.Reporting.TextBox();
            this.AirTotal2 = new Telerik.Reporting.TextBox();
            this.InsuranceTotal2 = new Telerik.Reporting.TextBox();
            this.InsuranceTotal1 = new Telerik.Reporting.TextBox();
            this.CruiseTotal1 = new Telerik.Reporting.TextBox();
            this.CruiseTotal2 = new Telerik.Reporting.TextBox();
            this.TransportTotal1 = new Telerik.Reporting.TextBox();
            this.TransportTotal2 = new Telerik.Reporting.TextBox();
            this.OtherLandTotal1 = new Telerik.Reporting.TextBox();
            this.OtherLandTotal2 = new Telerik.Reporting.TextBox();
            this.TourTotal1 = new Telerik.Reporting.TextBox();
            this.TourTotal2 = new Telerik.Reporting.TextBox();
            this.TotalsHeader = new Telerik.Reporting.TextBox();
            this.PackageTotal1 = new Telerik.Reporting.TextBox();
            this.PackageTotal2 = new Telerik.Reporting.TextBox();
            this.TotalDiscount1 = new Telerik.Reporting.TextBox();
            this.TotalDiscount2 = new Telerik.Reporting.TextBox();
            this.Total2 = new Telerik.Reporting.TextBox();
            this.Total1 = new Telerik.Reporting.TextBox();
            this.PackageGrandTotal1 = new Telerik.Reporting.TextBox();
            this.PackageGrandTotal2 = new Telerik.Reporting.TextBox();
            this.TaxTotal1 = new Telerik.Reporting.TextBox();
            this.TaxTotal2 = new Telerik.Reporting.TextBox();
            this.GrandTotal1 = new Telerik.Reporting.TextBox();
            this.GrandTotal2 = new Telerik.Reporting.TextBox();
            this.DiscountTotal1 = new Telerik.Reporting.TextBox();
            this.DiscountTotal2 = new Telerik.Reporting.TextBox();
            this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
            this.PackageLabel = new Telerik.Reporting.TextBox();
            this.Detail = new Telerik.Reporting.DetailSection();
            this.DetailList = new Telerik.Reporting.List();
            this.DetailPanel = new Telerik.Reporting.Panel();
            this.QuoteSubSubReport = new Telerik.Reporting.SubReport();
            this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // GroupFooterSection2
            // 
            this.GroupFooterSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(1.2D);
            this.GroupFooterSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.RemarksAfter});
            this.GroupFooterSection2.Name = "GroupFooterSection2";
            // 
            // RemarksAfter
            // 
            this.RemarksAfter.CanShrink = true;
            this.RemarksAfter.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.RemarksAfter.Name = "RemarksAfter";
            this.RemarksAfter.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.RemarksAfter.Style.Font.Name = "Calibri";
            this.RemarksAfter.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.RemarksAfter.Value = "= Fields.RemarksAfter";
            // 
            // GroupHeaderSection2
            // 
            this.GroupHeaderSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.GroupHeaderSection2.Name = "GroupHeaderSection2";
            this.GroupHeaderSection2.Style.Visible = false;
            // 
            // GroupFooterSection1
            // 
            this.GroupFooterSection1.CanShrink = true;
            this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(11.4D);
            this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TotalsPanel,
            this.TotalDiscount1,
            this.TotalDiscount2,
            this.Total2,
            this.Total1,
            this.PackageGrandTotal1,
            this.PackageGrandTotal2,
            this.TaxTotal1,
            this.TaxTotal2,
            this.GrandTotal1,
            this.GrandTotal2,
            this.DiscountTotal1,
            this.DiscountTotal2});
            this.GroupFooterSection1.Name = "GroupFooterSection1";
            this.GroupFooterSection1.PageBreak = Telerik.Reporting.PageBreak.After;
            // 
            // TotalsPanel
            // 
            this.TotalsPanel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo=0, True, False)"));
            this.TotalsPanel.CanShrink = true;
            this.TotalsPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.OtherInclusionTotal1,
            this.OtherInclusionTotal2,
            this.ServiceFeeTotal1,
            this.ServiceFeeTotal2,
            this.ForeignCurrencyTotal1,
            this.ForeignCurrencyTotal2,
            this.AccommodationTotal1,
            this.AirTotal1,
            this.AccommodationTotal2,
            this.AirTotal2,
            this.InsuranceTotal2,
            this.InsuranceTotal1,
            this.CruiseTotal1,
            this.CruiseTotal2,
            this.TransportTotal1,
            this.TransportTotal2,
            this.OtherLandTotal1,
            this.OtherLandTotal2,
            this.TourTotal1,
            this.TourTotal2,
            this.TotalsHeader,
            this.PackageTotal1,
            this.PackageTotal2});
            this.TotalsPanel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.TotalsPanel.Name = "TotalsPanel";
            this.TotalsPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(7.8D));
            // 
            // OtherInclusionTotal1
            // 
            this.OtherInclusionTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.OtherInclusionTotal=0,False,True)"));
            this.OtherInclusionTotal1.CanShrink = true;
            this.OtherInclusionTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(7.2D));
            this.OtherInclusionTotal1.Name = "OtherInclusionTotal1";
            this.OtherInclusionTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.OtherInclusionTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.OtherInclusionTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.OtherInclusionTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.OtherInclusionTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.OtherInclusionTotal1.Style.Font.Name = "Calibri";
            this.OtherInclusionTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.OtherInclusionTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherInclusionTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherInclusionTotal1.StyleName = "";
            this.OtherInclusionTotal1.Value = "Other Inclusions";
            // 
            // OtherInclusionTotal2
            // 
            this.OtherInclusionTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.OtherInclusionTotal=0,False,True)"));
            this.OtherInclusionTotal2.CanShrink = true;
            this.OtherInclusionTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(7.2D));
            this.OtherInclusionTotal2.Name = "OtherInclusionTotal2";
            this.OtherInclusionTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.OtherInclusionTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.OtherInclusionTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.OtherInclusionTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.OtherInclusionTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.OtherInclusionTotal2.Style.Font.Name = "Calibri";
            this.OtherInclusionTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.OtherInclusionTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherInclusionTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherInclusionTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.OtherInclusionTotal2.StyleName = "";
            this.OtherInclusionTotal2.Value = "= Format(\"{0:c2}\", Fields.OtherInclusionTotal)";
            // 
            // ServiceFeeTotal1
            // 
            this.ServiceFeeTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.ServiceFeeTotal=0,False,True)"));
            this.ServiceFeeTotal1.CanShrink = true;
            this.ServiceFeeTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(6.6D));
            this.ServiceFeeTotal1.Name = "ServiceFeeTotal1";
            this.ServiceFeeTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ServiceFeeTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.ServiceFeeTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ServiceFeeTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ServiceFeeTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ServiceFeeTotal1.Style.Font.Name = "Calibri";
            this.ServiceFeeTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ServiceFeeTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ServiceFeeTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ServiceFeeTotal1.StyleName = "";
            this.ServiceFeeTotal1.Value = "Service Fees";
            // 
            // ServiceFeeTotal2
            // 
            this.ServiceFeeTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.ServiceFeeTotal=0,False,True)"));
            this.ServiceFeeTotal2.CanShrink = true;
            this.ServiceFeeTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(6.6D));
            this.ServiceFeeTotal2.Name = "ServiceFeeTotal2";
            this.ServiceFeeTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ServiceFeeTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.ServiceFeeTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ServiceFeeTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ServiceFeeTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ServiceFeeTotal2.Style.Font.Name = "Calibri";
            this.ServiceFeeTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ServiceFeeTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ServiceFeeTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ServiceFeeTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.ServiceFeeTotal2.StyleName = "";
            this.ServiceFeeTotal2.Value = "= Format(\"{0:c2}\", Fields.ServiceFeeTotal)";
            // 
            // ForeignCurrencyTotal1
            // 
            this.ForeignCurrencyTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.ForeignCurrencyTotal=0,False,True)"));
            this.ForeignCurrencyTotal1.CanShrink = true;
            this.ForeignCurrencyTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(6D));
            this.ForeignCurrencyTotal1.Name = "ForeignCurrencyTotal1";
            this.ForeignCurrencyTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ForeignCurrencyTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.ForeignCurrencyTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ForeignCurrencyTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ForeignCurrencyTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ForeignCurrencyTotal1.Style.Font.Name = "Calibri";
            this.ForeignCurrencyTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ForeignCurrencyTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ForeignCurrencyTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ForeignCurrencyTotal1.StyleName = "";
            this.ForeignCurrencyTotal1.Value = "Foreign Currency";
            // 
            // ForeignCurrencyTotal2
            // 
            this.ForeignCurrencyTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.ForeignCurrencyTotal=0,False,True)"));
            this.ForeignCurrencyTotal2.CanShrink = true;
            this.ForeignCurrencyTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(6D));
            this.ForeignCurrencyTotal2.Name = "ForeignCurrencyTotal2";
            this.ForeignCurrencyTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.ForeignCurrencyTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.ForeignCurrencyTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.ForeignCurrencyTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ForeignCurrencyTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.ForeignCurrencyTotal2.Style.Font.Name = "Calibri";
            this.ForeignCurrencyTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.ForeignCurrencyTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ForeignCurrencyTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.ForeignCurrencyTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.ForeignCurrencyTotal2.StyleName = "";
            this.ForeignCurrencyTotal2.Value = "= Format(\"{0:c2}\", Fields.ForeignCurrencyTotal)";
            // 
            // AccommodationTotal1
            // 
            this.AccommodationTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AccommodationTotal=0,False,True)"));
            this.AccommodationTotal1.CanShrink = true;
            this.AccommodationTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
            this.AccommodationTotal1.Name = "AccommodationTotal1";
            this.AccommodationTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AccommodationTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AccommodationTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AccommodationTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AccommodationTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AccommodationTotal1.Style.Font.Name = "Calibri";
            this.AccommodationTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AccommodationTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccommodationTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccommodationTotal1.StyleName = "";
            this.AccommodationTotal1.Value = "Accommodation";
            // 
            // AirTotal1
            // 
            this.AirTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AirTotal=0,False,True)"));
            this.AirTotal1.CanShrink = true;
            this.AirTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.AirTotal1.Name = "AirTotal1";
            this.AirTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AirTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AirTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AirTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AirTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AirTotal1.Style.Font.Name = "Calibri";
            this.AirTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AirTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AirTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AirTotal1.StyleName = "";
            this.AirTotal1.Value = "Air";
            // 
            // AccommodationTotal2
            // 
            this.AccommodationTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AccommodationTotal=0,False,True)"));
            this.AccommodationTotal2.CanShrink = true;
            this.AccommodationTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(2.4D));
            this.AccommodationTotal2.Name = "AccommodationTotal2";
            this.AccommodationTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AccommodationTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AccommodationTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AccommodationTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AccommodationTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AccommodationTotal2.Style.Font.Name = "Calibri";
            this.AccommodationTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AccommodationTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccommodationTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AccommodationTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AccommodationTotal2.StyleName = "";
            this.AccommodationTotal2.Value = "= Format(\"{0:c2}\", Fields.AccommodationTotal)";
            // 
            // AirTotal2
            // 
            this.AirTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.AirTotal=0,False,True)"));
            this.AirTotal2.CanShrink = true;
            this.AirTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.AirTotal2.Name = "AirTotal2";
            this.AirTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.AirTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.AirTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.AirTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.AirTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.AirTotal2.Style.Font.Name = "Calibri";
            this.AirTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.AirTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AirTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.AirTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.AirTotal2.StyleName = "";
            this.AirTotal2.Value = "= Format(\"{0:c2}\", Fields.AirTotal)";
            // 
            // InsuranceTotal2
            // 
            this.InsuranceTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.InsuranceTotal=0,False,True)"));
            this.InsuranceTotal2.CanShrink = true;
            this.InsuranceTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(5.4D));
            this.InsuranceTotal2.Name = "InsuranceTotal2";
            this.InsuranceTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.InsuranceTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.InsuranceTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.InsuranceTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.InsuranceTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.InsuranceTotal2.Style.Font.Name = "Calibri";
            this.InsuranceTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.InsuranceTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.InsuranceTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.InsuranceTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.InsuranceTotal2.StyleName = "";
            this.InsuranceTotal2.Value = "= Format(\"{0:c2}\", Fields.InsuranceTotal)";
            // 
            // InsuranceTotal1
            // 
            this.InsuranceTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.InsuranceTotal=0,False,True)"));
            this.InsuranceTotal1.CanShrink = true;
            this.InsuranceTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(5.4D));
            this.InsuranceTotal1.Name = "InsuranceTotal1";
            this.InsuranceTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.InsuranceTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.InsuranceTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.InsuranceTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.InsuranceTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.InsuranceTotal1.Style.Font.Name = "Calibri";
            this.InsuranceTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.InsuranceTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.InsuranceTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.InsuranceTotal1.StyleName = "";
            this.InsuranceTotal1.Value = "Insurance";
            // 
            // CruiseTotal1
            // 
            this.CruiseTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.CruiseTotal=0,False,True)"));
            this.CruiseTotal1.CanShrink = true;
            this.CruiseTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
            this.CruiseTotal1.Name = "CruiseTotal1";
            this.CruiseTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CruiseTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.CruiseTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CruiseTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.CruiseTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CruiseTotal1.Style.Font.Name = "Calibri";
            this.CruiseTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CruiseTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CruiseTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CruiseTotal1.StyleName = "";
            this.CruiseTotal1.Value = "Cruise";
            // 
            // CruiseTotal2
            // 
            this.CruiseTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.CruiseTotal=0,False,True)"));
            this.CruiseTotal2.CanShrink = true;
            this.CruiseTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(3.6D));
            this.CruiseTotal2.Name = "CruiseTotal2";
            this.CruiseTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CruiseTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.CruiseTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CruiseTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.CruiseTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CruiseTotal2.Style.Font.Name = "Calibri";
            this.CruiseTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CruiseTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CruiseTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.CruiseTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.CruiseTotal2.StyleName = "";
            this.CruiseTotal2.Value = "= Format(\"{0:c2}\", Fields.CruiseTotal)";
            // 
            // TransportTotal1
            // 
            this.TransportTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.TransportTotal=0,False,True)"));
            this.TransportTotal1.CanShrink = true;
            this.TransportTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.TransportTotal1.Name = "TransportTotal1";
            this.TransportTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TransportTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TransportTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TransportTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TransportTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TransportTotal1.Style.Font.Name = "Calibri";
            this.TransportTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TransportTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TransportTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TransportTotal1.StyleName = "";
            this.TransportTotal1.Value = "Transport";
            // 
            // TransportTotal2
            // 
            this.TransportTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.TransportTotal=0,False,True)"));
            this.TransportTotal2.CanShrink = true;
            this.TransportTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(3D));
            this.TransportTotal2.Name = "TransportTotal2";
            this.TransportTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TransportTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TransportTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TransportTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TransportTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TransportTotal2.Style.Font.Name = "Calibri";
            this.TransportTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TransportTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TransportTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TransportTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TransportTotal2.StyleName = "";
            this.TransportTotal2.Value = "= Format(\"{0:c2}\", Fields.TransportTotal)";
            // 
            // OtherLandTotal1
            // 
            this.OtherLandTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.OtherLandTotal=0,False,True)"));
            this.OtherLandTotal1.CanShrink = true;
            this.OtherLandTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.8D));
            this.OtherLandTotal1.Name = "OtherLandTotal1";
            this.OtherLandTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.OtherLandTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.OtherLandTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.OtherLandTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.OtherLandTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.OtherLandTotal1.Style.Font.Name = "Calibri";
            this.OtherLandTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.OtherLandTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherLandTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherLandTotal1.StyleName = "";
            this.OtherLandTotal1.Value = "Other Land";
            // 
            // OtherLandTotal2
            // 
            this.OtherLandTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.OtherLandTotal=0,False,True)"));
            this.OtherLandTotal2.CanShrink = true;
            this.OtherLandTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(4.8D));
            this.OtherLandTotal2.Name = "OtherLandTotal2";
            this.OtherLandTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.OtherLandTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.OtherLandTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.OtherLandTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.OtherLandTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.OtherLandTotal2.Style.Font.Name = "Calibri";
            this.OtherLandTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.OtherLandTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherLandTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.OtherLandTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.OtherLandTotal2.StyleName = "";
            this.OtherLandTotal2.Value = "= Format(\"{0:c2}\", Fields.OtherLandTotal)";
            // 
            // TourTotal1
            // 
            this.TourTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.TourTotal=0,False,True)"));
            this.TourTotal1.CanShrink = true;
            this.TourTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.2D));
            this.TourTotal1.Name = "TourTotal1";
            this.TourTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TourTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TourTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TourTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TourTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TourTotal1.Style.Font.Name = "Calibri";
            this.TourTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TourTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TourTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TourTotal1.StyleName = "";
            this.TourTotal1.Value = "Tour";
            // 
            // TourTotal2
            // 
            this.TourTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.TourTotal=0,False,True)"));
            this.TourTotal2.CanShrink = true;
            this.TourTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(4.2D));
            this.TourTotal2.Name = "TourTotal2";
            this.TourTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TourTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TourTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TourTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TourTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TourTotal2.Style.Font.Name = "Calibri";
            this.TourTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TourTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TourTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TourTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TourTotal2.StyleName = "";
            this.TourTotal2.Value = "= Format(\"{0:c2}\", Fields.TourTotal)";
            // 
            // TotalsHeader
            // 
            this.TotalsHeader.CanShrink = true;
            this.TotalsHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalsHeader.Name = "TotalsHeader";
            this.TotalsHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalsHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TotalsHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalsHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalsHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalsHeader.Style.Font.Bold = true;
            this.TotalsHeader.Style.Font.Name = "Calibri";
            this.TotalsHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalsHeader.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalsHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalsHeader.StyleName = "Normal.TableHeader";
            this.TotalsHeader.Value = "Totals";
            // 
            // PackageTotal1
            // 
            this.PackageTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageGrandTotal=0,False,True)"));
            this.PackageTotal1.CanShrink = true;
            this.PackageTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.PackageTotal1.Name = "PackageTotal1";
            this.PackageTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PackageTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageTotal1.Style.Font.Name = "Calibri";
            this.PackageTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal1.StyleName = "";
            this.PackageTotal1.Value = "Package Total";
            // 
            // PackageTotal2
            // 
            this.PackageTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageGrandTotal=0,False,True)"));
            this.PackageTotal2.CanShrink = true;
            this.PackageTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.PackageTotal2.Name = "PackageTotal2";
            this.PackageTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PackageTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageTotal2.Style.Font.Name = "Calibri";
            this.PackageTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PackageTotal2.StyleName = "";
            this.PackageTotal2.Value = "= Format(\"{0:c2}\", Fields.PackageGrandTotal)";
            // 
            // TotalDiscount1
            // 
            this.TotalDiscount1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0 And Fields.DiscountTotal <> 0, True, False)"));
            this.TotalDiscount1.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.TotalDiscount1.CanShrink = true;
            this.TotalDiscount1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(10.2D));
            this.TotalDiscount1.Name = "TotalDiscount1";
            this.TotalDiscount1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalDiscount1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TotalDiscount1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalDiscount1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalDiscount1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalDiscount1.Style.Font.Bold = true;
            this.TotalDiscount1.Style.Font.Name = "Calibri";
            this.TotalDiscount1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalDiscount1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalDiscount1.StyleName = "";
            this.TotalDiscount1.Value = "Total Discounts Included";
            // 
            // TotalDiscount2
            // 
            this.TotalDiscount2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0 And Fields.DiscountTotal <> 0, True, False)"));
            this.TotalDiscount2.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.TotalDiscount2.CanShrink = true;
            this.TotalDiscount2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(10.2D));
            this.TotalDiscount2.Name = "TotalDiscount2";
            this.TotalDiscount2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalDiscount2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TotalDiscount2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalDiscount2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TotalDiscount2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TotalDiscount2.Style.Font.Bold = true;
            this.TotalDiscount2.Style.Font.Name = "Calibri";
            this.TotalDiscount2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalDiscount2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalDiscount2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TotalDiscount2.StyleName = "";
            this.TotalDiscount2.Value = "= Format(\"{0:c2}\", Fields.DiscountTotal)";
            // 
            // Total2
            // 
            this.Total2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0, True, False)"));
            this.Total2.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.Total2.CanShrink = true;
            this.Total2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(9D));
            this.Total2.Name = "Total2";
            this.Total2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Total2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.Total2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Total2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Total2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Total2.Style.Font.Bold = true;
            this.Total2.Style.Font.Name = "Calibri";
            this.Total2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Total2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Total2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Total2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Total2.StyleName = "";
            this.Total2.Value = "= Format(\"{0:c2}\", Fields.GrandTotal)";
            // 
            // Total1
            // 
            this.Total1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0, True, False)"));
            this.Total1.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.Total1.CanShrink = true;
            this.Total1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(9D));
            this.Total1.Name = "Total1";
            this.Total1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Total1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.Total1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Total1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Total1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Total1.Style.Font.Bold = true;
            this.Total1.Style.Font.Name = "Calibri";
            this.Total1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Total1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Total1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Total1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Total1.StyleName = "";
            this.Total1.Value = "Total";
            // 
            // PackageGrandTotal1
            // 
            this.PackageGrandTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0, False, True)"));
            this.PackageGrandTotal1.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.PackageGrandTotal1.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.PackageNo = 0, \"Solid\", \"None\")"));
            this.PackageGrandTotal1.CanShrink = true;
            this.PackageGrandTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(7.8D));
            this.PackageGrandTotal1.Name = "PackageGrandTotal1";
            this.PackageGrandTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageGrandTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageGrandTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageGrandTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PackageGrandTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageGrandTotal1.Style.Font.Bold = true;
            this.PackageGrandTotal1.Style.Font.Name = "Calibri";
            this.PackageGrandTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageGrandTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageGrandTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageGrandTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PackageGrandTotal1.StyleName = "";
            this.PackageGrandTotal1.Value = "= \"Package \" + Fields.PackageNo + \" Total\"";
            // 
            // PackageGrandTotal2
            // 
            this.PackageGrandTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0, False, True)"));
            this.PackageGrandTotal2.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.PackageGrandTotal2.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.PackageNo = 0, \"Solid\", \"None\")"));
            this.PackageGrandTotal2.CanShrink = true;
            this.PackageGrandTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(7.8D));
            this.PackageGrandTotal2.Name = "PackageGrandTotal2";
            this.PackageGrandTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageGrandTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageGrandTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageGrandTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.PackageGrandTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PackageGrandTotal2.Style.Font.Bold = true;
            this.PackageGrandTotal2.Style.Font.Name = "Calibri";
            this.PackageGrandTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PackageGrandTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageGrandTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageGrandTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PackageGrandTotal2.StyleName = "";
            this.PackageGrandTotal2.Value = "= Format(\"{0:c2}\", Fields.PackageTotal)";
            // 
            // TaxTotal1
            // 
            this.TaxTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0, True, False)"));
            this.TaxTotal1.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.TaxTotal1.CanShrink = true;
            this.TaxTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(9.6D));
            this.TaxTotal1.Name = "TaxTotal1";
            this.TaxTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TaxTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TaxTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TaxTotal1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TaxTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TaxTotal1.Style.Font.Bold = true;
            this.TaxTotal1.Style.Font.Name = "Calibri";
            this.TaxTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TaxTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TaxTotal1.StyleName = "";
            this.TaxTotal1.Value = "Total Tax Included";
            this.TaxTotal1.ItemDataBound += new System.EventHandler(this.TaxTotal1_ItemDataBound);
            // 
            // TaxTotal2
            // 
            this.TaxTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0, True, False)"));
            this.TaxTotal2.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.TaxTotal2.CanShrink = true;
            this.TaxTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(9.6D));
            this.TaxTotal2.Name = "TaxTotal2";
            this.TaxTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TaxTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.TaxTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TaxTotal2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.TaxTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.TaxTotal2.Style.Font.Bold = true;
            this.TaxTotal2.Style.Font.Name = "Calibri";
            this.TaxTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TaxTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TaxTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.TaxTotal2.StyleName = "";
            this.TaxTotal2.Value = "= Format(\"{0:c2}\", Fields.TaxTotal)";
            // 
            // GrandTotal1
            // 
            this.GrandTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0, True, False)"));
            this.GrandTotal1.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.GrandTotal1.CanShrink = true;
            this.GrandTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(10.8D));
            this.GrandTotal1.Name = "GrandTotal1";
            this.GrandTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.GrandTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.GrandTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.GrandTotal1.Style.Font.Bold = true;
            this.GrandTotal1.Style.Font.Name = "Calibri";
            this.GrandTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.GrandTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.GrandTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.GrandTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.GrandTotal1.StyleName = "";
            this.GrandTotal1.Value = "Grand Total";
            // 
            // GrandTotal2
            // 
            this.GrandTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0, True, False)"));
            this.GrandTotal2.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.GrandTotal2.CanShrink = true;
            this.GrandTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(10.8D));
            this.GrandTotal2.Name = "GrandTotal2";
            this.GrandTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.GrandTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.GrandTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.GrandTotal2.Style.Font.Bold = true;
            this.GrandTotal2.Style.Font.Name = "Calibri";
            this.GrandTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.GrandTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.GrandTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.GrandTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.GrandTotal2.StyleName = "";
            this.GrandTotal2.Value = "= Format(\"{0:c2}\", Fields.GrandTotal)";
            // 
            // DiscountTotal1
            // 
            this.DiscountTotal1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0 Or Fields.DiscountTotal = 0, False, True)"));
            this.DiscountTotal1.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.DiscountTotal1.CanShrink = true;
            this.DiscountTotal1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(8.4D));
            this.DiscountTotal1.Name = "DiscountTotal1";
            this.DiscountTotal1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DiscountTotal1.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.DiscountTotal1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DiscountTotal1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DiscountTotal1.Style.Font.Bold = true;
            this.DiscountTotal1.Style.Font.Name = "Calibri";
            this.DiscountTotal1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DiscountTotal1.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DiscountTotal1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DiscountTotal1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.DiscountTotal1.StyleName = "";
            this.DiscountTotal1.Value = "Discounts Included";
            // 
            // DiscountTotal2
            // 
            this.DiscountTotal2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo = 0 Or Fields.DiscountTotal = 0, False, True)"));
            this.DiscountTotal2.Bindings.Add(new Telerik.Reporting.Binding("Style.Font.Size", "= IIf(Fields.PackageNo = 0, \"10pt\", \"11pt\")"));
            this.DiscountTotal2.CanShrink = true;
            this.DiscountTotal2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15D), Telerik.Reporting.Drawing.Unit.Cm(8.4D));
            this.DiscountTotal2.Name = "DiscountTotal2";
            this.DiscountTotal2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.DiscountTotal2.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.DiscountTotal2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DiscountTotal2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.DiscountTotal2.Style.Font.Bold = true;
            this.DiscountTotal2.Style.Font.Name = "Calibri";
            this.DiscountTotal2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DiscountTotal2.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DiscountTotal2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.DiscountTotal2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.DiscountTotal2.StyleName = "";
            this.DiscountTotal2.Value = "= Format(\"{0:c2}\", Fields.DiscountTotal)";
            // 
            // GroupHeaderSection1
            // 
            this.GroupHeaderSection1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.PackageNo=0, False, True)"));
            this.GroupHeaderSection1.CanShrink = true;
            this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
            this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.PackageLabel});
            this.GroupHeaderSection1.KeepTogether = false;
            this.GroupHeaderSection1.Name = "GroupHeaderSection1";
            // 
            // PackageLabel
            // 
            this.PackageLabel.CanShrink = true;
            this.PackageLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.PackageLabel.Name = "PackageLabel";
            this.PackageLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PackageLabel.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PackageLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PackageLabel.Style.Font.Bold = true;
            this.PackageLabel.Style.Font.Name = "Calibri";
            this.PackageLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(11D);
            this.PackageLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PackageLabel.StyleName = "";
            this.PackageLabel.Value = "= \"Package \" + Fields.PackageNo + \" Details\"";
            // 
            // Detail
            // 
            this.Detail.CanShrink = true;
            this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
            this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailList});
            this.Detail.KeepTogether = false;
            this.Detail.Name = "Detail";
            this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            // 
            // DetailList
            // 
            this.DetailList.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.QuoteDetailSubReportList"));
            this.DetailList.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18D)));
            this.DetailList.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
            this.DetailList.Body.SetCellContent(0, 0, this.DetailPanel);
            tableGroup1.Name = "ColumnGroup";
            this.DetailList.ColumnGroups.Add(tableGroup1);
            this.DetailList.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailPanel});
            this.DetailList.KeepTogether = false;
            this.DetailList.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.DetailList.Name = "DetailList";
            tableGroup2.Name = "DetailGroup";
            this.DetailList.RowGroups.Add(tableGroup2);
            this.DetailList.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            // 
            // DetailPanel
            // 
            this.DetailPanel.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.QuoteSubSubReport});
            this.DetailPanel.KeepTogether = false;
            this.DetailPanel.Name = "DetailPanel";
            this.DetailPanel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            // 
            // QuoteSubSubReport
            // 
            this.QuoteSubSubReport.KeepTogether = false;
            this.QuoteSubSubReport.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.QuoteSubSubReport.Name = "QuoteSubSubReport";
            typeReportSource1.TypeName = "Travelog.Reports.ClientLedger.QuoteSubSubReport, Travelog.Reports, Version=1.0.0." +
    "0, Culture=neutral, PublicKeyToken=null";
            this.QuoteSubSubReport.ReportSource = typeReportSource1;
            this.QuoteSubSubReport.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.QuoteSubSubReport.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            // 
            // ReportDataSource
            // 
            this.ReportDataSource.DataMember = "QuoteSubReport";
            this.ReportDataSource.DataSource = typeof(Travelog.Reports.ClientLedger.ClientLedgerDataSources);
            this.ReportDataSource.Name = "ReportDataSource";
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("tripLineIds", typeof(string), "= Parameters.tripLineIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("passengerIds", typeof(string), "= Parameters.passengerIds.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("quoteNo", typeof(int), "= Parameters.quoteNo.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("timeFormat", typeof(string), "= Parameters.timeFormat.Value"));
            // 
            // QuoteSubReport
            // 
            this.DataSource = this.ReportDataSource;
            group1.GroupFooter = this.GroupFooterSection2;
            group1.GroupHeader = this.GroupHeaderSection2;
            group1.Name = "Group2";
            group2.GroupFooter = this.GroupFooterSection1;
            group2.GroupHeader = this.GroupHeaderSection1;
            group2.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.PackageNo"));
            group2.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
            group2.Name = "Group1";
            group2.Sortings.Add(new Telerik.Reporting.Sorting("= IIf(Fields.PackageNo=0,1,0)", Telerik.Reporting.SortDirection.Asc));
            group2.Sortings.Add(new Telerik.Reporting.Sorting("= Fields.PackageNo", Telerik.Reporting.SortDirection.Asc));
            group2.Sortings.Add(new Telerik.Reporting.Sorting("= Fields.SeqNo", Telerik.Reporting.SortDirection.Asc));
            this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2});
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection2,
            this.GroupFooterSection2,
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail});
            this.Name = "QuoteSubReport";
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            reportParameter1.Name = "customerId";
            reportParameter1.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter2.Name = "quoteNo";
            reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter3.Name = "tripLineIds";
            reportParameter4.Name = "timeFormat";
            reportParameter5.Name = "passengerIds";
            this.ReportParameters.Add(reportParameter1);
            this.ReportParameters.Add(reportParameter2);
            this.ReportParameters.Add(reportParameter3);
            this.ReportParameters.Add(reportParameter4);
            this.ReportParameters.Add(reportParameter5);
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(18D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.List DetailList;
		private Telerik.Reporting.Panel DetailPanel;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.TextBox PackageLabel;
		private Telerik.Reporting.Panel TotalsPanel;
		private Telerik.Reporting.TextBox OtherInclusionTotal1;
		private Telerik.Reporting.TextBox OtherInclusionTotal2;
		private Telerik.Reporting.TextBox ServiceFeeTotal1;
		private Telerik.Reporting.TextBox ServiceFeeTotal2;
		private Telerik.Reporting.TextBox ForeignCurrencyTotal1;
		private Telerik.Reporting.TextBox ForeignCurrencyTotal2;
		private Telerik.Reporting.TextBox AccommodationTotal1;
		private Telerik.Reporting.TextBox AirTotal1;
		private Telerik.Reporting.TextBox AccommodationTotal2;
		private Telerik.Reporting.TextBox AirTotal2;
		private Telerik.Reporting.TextBox InsuranceTotal2;
		private Telerik.Reporting.TextBox InsuranceTotal1;
		private Telerik.Reporting.TextBox CruiseTotal1;
		private Telerik.Reporting.TextBox CruiseTotal2;
		private Telerik.Reporting.TextBox TransportTotal1;
		private Telerik.Reporting.TextBox TransportTotal2;
		private Telerik.Reporting.TextBox OtherLandTotal1;
		private Telerik.Reporting.TextBox OtherLandTotal2;
		private Telerik.Reporting.TextBox TourTotal1;
		private Telerik.Reporting.TextBox TourTotal2;
		private Telerik.Reporting.TextBox TotalsHeader;
		private Telerik.Reporting.TextBox PackageTotal1;
		private Telerik.Reporting.TextBox PackageTotal2;
		private Telerik.Reporting.TextBox TotalDiscount1;
		private Telerik.Reporting.TextBox TotalDiscount2;
		private Telerik.Reporting.TextBox Total2;
		private Telerik.Reporting.TextBox Total1;
		private Telerik.Reporting.SubReport QuoteSubSubReport;
		private Telerik.Reporting.TextBox PackageGrandTotal1;
		private Telerik.Reporting.TextBox PackageGrandTotal2;
		private Telerik.Reporting.TextBox TaxTotal1;
		private Telerik.Reporting.TextBox TaxTotal2;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection2;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection2;
		private Telerik.Reporting.HtmlTextBox RemarksAfter;
		private Telerik.Reporting.TextBox GrandTotal1;
		private Telerik.Reporting.TextBox GrandTotal2;
		private Telerik.Reporting.TextBox DiscountTotal1;
		private Telerik.Reporting.TextBox DiscountTotal2;
    }
}