using System;
using Telerik.Reporting;
using Travelog.Biz.Resources;

namespace Travelog.Reports.ClientLedger {
	public partial class ConfirmationSubReport : TelerikReport {
		public ConfirmationSubReport() {
			InitializeComponent();
		}

		private void TaxTotal1_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("Total {0} Included", Resource.TaxLabel);
		}

		private void TaxAppliesLabel_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			textBox.Value = string.Format("*{0} Applies", Resource.TaxLabel);
		}
	}
}