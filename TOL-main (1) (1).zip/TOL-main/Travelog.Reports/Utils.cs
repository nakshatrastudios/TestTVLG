using System;
using System.Linq;
using System.Net;
using Telerik.Reporting;
using Telerik.Reporting.Processing;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Enums;
using Travelog.Biz.Resources;

namespace Travelog.Reports {
    public static class Utils {
        public static string GetCustomerName(int customerId, string defaultAgency) {
            return string.Format("{0}{1} {2}: {3}", CustomerSettings.Setting(customerId).FullName, CustomerSettings.Setting(customerId).AgencyType != AgencyType.MultiAgencyGLIndividual || string.IsNullOrEmpty(defaultAgency) ? string.Empty : string.Format(" - {0}", defaultAgency), Resource.TaxNoLabel, CustomerSettings.Setting(customerId).TaxNo);
        }

        public static string GetIssuedBy(Consultant consultant, string userName, int customerId) {
            if (consultant.Id > 0)
                return consultant.Name;

            using (var adminContext = new AppAdminContext(true)) {
                var aspNetUser = adminContext.AspNetUsers.SingleOrDefault(t => t.Email == userName);

                string userId = aspNetUser?.Id ?? string.Empty;
                var aspNetUserRole = adminContext.AspNetUserRoles.SingleOrDefault(t => t.UserId == userId && t.CustomerId == customerId);

                if (aspNetUserRole?.ConsultantId > 0) {
                    using (var context = new AppMainContext(customerId, true)) {
                        string name = context.Consultant.Find(aspNetUserRole.ConsultantId)?.Name;

                        if (!string.IsNullOrEmpty(name))
                            return name;
                    }
                }

                return aspNetUser?.FullName ?? "System";
            }
        }

        public static object HtmlEncodeExceptTags(object value) {
            if (value == null || value is DateTime)
                return value;

            return HtmlEncodeExceptTags(value.ToString());
        }

        public static string HtmlEncodeExceptTags(string value) {
            return Biz.Utils.HtmlEncodeExceptTags(value).Replace(Environment.NewLine, AppConstants.HtmlLineBreak);
        }
    }

    public class TelerikReport : Telerik.Reporting.Report {
        protected override void OnError(object sender, ErrorEventArgs e) {
            int.TryParse(UserIdentity.Current?.Context["CustomerId"]?.ToStringExt(), out int customerId);
            string userName = UserIdentity.Current?.Context["UserName"]?.ToStringExt();

            string error = ExceptionManagerBiz.Instance.GetErrorMessage("Travelog.Reports.TelerikReport", "OnError", e.Exception, customerId, userName);
            error = string.Format("{1}{0}Content: {2}{0}", Environment.NewLine, error, sender);

            ExceptionManagerBiz.Instance.LogError(error);

            string subject = string.Format("{0} - Application Error", AppSettings.AppTitle);
            string body = string.Format(AppConstants.MailBody, WebUtility.HtmlEncode(error).Replace(Environment.NewLine, AppConstants.HtmlLineBreak));

            Mail.Instance.SendMail(AppSettings.EmailErrors, subject, body);
            base.OnError(sender, e);
        }
    }
}