namespace Travelog.Reports.Common {
	partial class AgencyHeaderSubReport2 {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
            this.DetailSection = new Telerik.Reporting.DetailSection();
            this.HeaderStandardComment = new Telerik.Reporting.TextBox();
            this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // DetailSection
            // 
            this.DetailSection.Bindings.Add(new Telerik.Reporting.Binding("Visible", "=IIf(IsNull(Fields.HeaderStandardComment,\"\")=\"\",False,True)"));
            this.DetailSection.Bindings.Add(new Telerik.Reporting.Binding("Style.Padding.Bottom", "= IIf(Parameters.removePadding.Value = True, \"0cm\", \"0.5cm\")"));
            this.DetailSection.CanShrink = true;
            this.DetailSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
            this.DetailSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.HeaderStandardComment});
            this.DetailSection.KeepTogether = false;
            this.DetailSection.Name = "DetailSection";
            this.DetailSection.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DetailSection.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DetailSection.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
            // 
            // HeaderStandardComment
            // 
            this.HeaderStandardComment.CanShrink = true;
            this.HeaderStandardComment.Format = "";
            this.HeaderStandardComment.KeepTogether = false;
            this.HeaderStandardComment.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.HeaderStandardComment.Name = "HeaderStandardComment";
            this.HeaderStandardComment.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(17.9D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.HeaderStandardComment.Style.Font.Name = "Calibri";
            this.HeaderStandardComment.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.HeaderStandardComment.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.HeaderStandardComment.Value = "= Fields.HeaderStandardComment";
            // 
            // ReportDataSource
            // 
            this.ReportDataSource.DataMember = "AgencyHeaderReport";
            this.ReportDataSource.DataSource = typeof(Travelog.Reports.Common.CommonDataSources);
            this.ReportDataSource.Name = "ReportDataSource";
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("issuedDocumentType", typeof(string), "= Parameters.issuedDocumentType.Value"));
            // 
            // AgencyHeaderSubReport2
            // 
            this.DataSource = this.ReportDataSource;
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailSection});
            this.Name = "AgencyHeaderSubReport2";
            this.PageSettings.Landscape = false;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            reportParameter1.Name = "customerId";
            reportParameter2.Name = "agencyId";
            reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter2.Value = "";
            reportParameter3.Name = "issuedDocumentType";
            reportParameter3.Value = "";
            reportParameter4.Name = "removePadding";
            reportParameter4.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter4.Value = "= False";
            this.ReportParameters.Add(reportParameter1);
            this.ReportParameters.Add(reportParameter2);
            this.ReportParameters.Add(reportParameter3);
            this.ReportParameters.Add(reportParameter4);
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(18D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection DetailSection;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.TextBox HeaderStandardComment;
	}
}