using Telerik.Reporting;

namespace Travelog.Reports.Common {
	public partial class ManagementReportHeaderSubReport2 : TelerikReport {

		public ManagementReportHeaderSubReport2() {
			InitializeComponent();
		}
	}
}