namespace Travelog.Reports.Common {
	partial class AgencyFooterSubReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
            this.DetailSection = new Telerik.Reporting.DetailSection();
            this.FooterStandardComment = new Telerik.Reporting.TextBox();
            this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // DetailSection
            // 
            this.DetailSection.Bindings.Add(new Telerik.Reporting.Binding("Visible", "=IIf(IsNull(Fields.FooterStandardComment,\"\")=\"\",False,True)"));
            this.DetailSection.CanShrink = true;
            this.DetailSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
            this.DetailSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.FooterStandardComment});
            this.DetailSection.KeepTogether = false;
            this.DetailSection.Name = "DetailSection";
            this.DetailSection.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.DetailSection.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.DetailSection.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
            // 
            // FooterStandardComment
            // 
            this.FooterStandardComment.CanShrink = true;
            this.FooterStandardComment.Format = "";
            this.FooterStandardComment.KeepTogether = false;
            this.FooterStandardComment.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.FooterStandardComment.Name = "FooterStandardComment";
            this.FooterStandardComment.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(17.9D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.FooterStandardComment.Style.Font.Name = "Calibri";
            this.FooterStandardComment.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.FooterStandardComment.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            this.FooterStandardComment.Value = "= Fields.FooterStandardComment";
            // 
            // ReportDataSource
            // 
            this.ReportDataSource.DataMember = "AgencyHeaderReport";
            this.ReportDataSource.DataSource = typeof(Travelog.Reports.Common.CommonDataSources);
            this.ReportDataSource.Name = "ReportDataSource";
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("issuedDocumentType", typeof(string), "= Parameters.issuedDocumentType.Value"));
            // 
            // AgencyFooterSubReport
            // 
            this.DataSource = this.ReportDataSource;
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailSection});
            this.Name = "AgencyFooterSubReport";
            this.PageSettings.Landscape = false;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            reportParameter1.Name = "customerId";
            reportParameter2.Name = "agencyId";
            reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter2.Value = "";
            reportParameter3.Name = "issuedDocumentType";
            reportParameter3.Value = "";
            this.ReportParameters.Add(reportParameter1);
            this.ReportParameters.Add(reportParameter2);
            this.ReportParameters.Add(reportParameter3);
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(18D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection DetailSection;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.TextBox FooterStandardComment;
	}
}