using Telerik.Reporting;

namespace Travelog.Reports.Common {
	public partial class ManagementReportHeaderSubReport1 : TelerikReport {

		public ManagementReportHeaderSubReport1() {
			InitializeComponent();
		}
	}
}