﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;

namespace Travelog.Reports.Common {
	public class CommonDataSources {
		private const string ClassName = "Travelog.Reports.Common.CommonDataSources";

		public AgencyHeaderReportModel AgencyHeaderReport(int customerId, int agencyId, string issuedDocumentType) {
			try {
                using (var context = new AppMainContext(customerId, true)) {
					issuedDocumentType = issuedDocumentType == "CreditNote" ? "Invoice" : issuedDocumentType;
					var issuedDocumentTypeValue = (IssuedDocumentType)Enum.Parse(typeof(IssuedDocumentType), issuedDocumentType, true);

					if (issuedDocumentTypeValue == IssuedDocumentType.PersonalStatement)
						issuedDocumentTypeValue = IssuedDocumentType.ClientStatement;

					var q = context.AgencyHeader.Include(t => t.HeaderStandardComment).Include(t => t.FooterStandardComment).SingleOrDefault(t => t.AgencyId == agencyId && t.IssuedDocumentType == issuedDocumentTypeValue) ?? new AgencyHeader {
						Id = 0,
						LogoPosition = Position.Left,
                        HeaderContent = string.Empty,
                        HeaderStandardComment = new StandardComment {
							Id = 0,
							Comment = string.Empty
						},
						FooterStandardComment = new StandardComment {
							Id = 0,
							Comment = string.Empty
						}
					};

                    int logoWidth = 340;
                    int logoHeight = (int)(340m * 2 / 9);

                    var logo = q.Logo?.BytesToImage();

                    if (logo?.Width > logoWidth)
                        logo = logo.Resize(logoWidth, logoHeight);

                    return new AgencyHeaderReportModel {
                        Content = q.HeaderContent.TrimEnd(AppConstants.HtmlLineBreak),
                        HeaderStandardComment = q.HeaderStandardComment.Comment.TrimEnd(Environment.NewLine),
                        FooterStandardComment = q.FooterStandardComment.Comment.TrimEnd(Environment.NewLine),
                        LogoPosition = q.LogoPosition.ToString(),
                        LogoWidth = string.Format("{0}px", logo?.Width ?? logoWidth),
                        LogoHeight = string.Format("{0}px", logo?.Height ?? logoHeight),
                        Logo = logo
                    };
                }
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "AgencyHeaderReport", ex, customerId);
				return new AgencyHeaderReportModel();
			}
		}
	}
}