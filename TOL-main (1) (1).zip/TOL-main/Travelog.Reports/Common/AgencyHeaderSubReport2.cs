using Telerik.Reporting;

namespace Travelog.Reports.Common {
	public partial class AgencyHeaderSubReport2 : TelerikReport {

		public AgencyHeaderSubReport2() {
			InitializeComponent();
		}
	}
}