using Telerik.Reporting;

namespace Travelog.Reports.Common {
	public partial class AgencyHeaderSubReport1 : TelerikReport {
		public AgencyHeaderSubReport1() {
			InitializeComponent();
		}
	}
}