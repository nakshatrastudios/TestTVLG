using Telerik.Reporting;

namespace Travelog.Reports.Common {
	public partial class AgencyFooterSubReport : TelerikReport {
		public AgencyFooterSubReport() {
			InitializeComponent();
		}
	}
}