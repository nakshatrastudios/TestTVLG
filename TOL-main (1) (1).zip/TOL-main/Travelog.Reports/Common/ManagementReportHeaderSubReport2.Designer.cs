namespace Travelog.Reports.Common {
	partial class ManagementReportHeaderSubReport2 {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			this.DetailSection = new Telerik.Reporting.DetailSection();
			this.HeaderContent = new Telerik.Reporting.HtmlTextBox();
			this.CustomerName = new Telerik.Reporting.TextBox();
			this.TravelogOnline = new Telerik.Reporting.TextBox();
			this.ReportName = new Telerik.Reporting.TextBox();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// DetailSection
			// 
			this.DetailSection.CanShrink = true;
			this.DetailSection.Height = Telerik.Reporting.Drawing.Unit.Cm(2.3D);
			this.DetailSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.HeaderContent,
            this.CustomerName,
            this.TravelogOnline,
            this.ReportName});
			this.DetailSection.Name = "DetailSection";
			this.DetailSection.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DetailSection.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DetailSection.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			// 
			// HeaderContent
			// 
			this.HeaderContent.CanShrink = true;
			this.HeaderContent.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
			this.HeaderContent.Name = "HeaderContent";
			this.HeaderContent.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.HeaderContent.Style.Font.Name = "Calibri";
			this.HeaderContent.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.HeaderContent.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
			this.HeaderContent.Value = "= Parameters.headerContent.Value";
			// 
			// CustomerName
			// 
			this.CustomerName.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.reportName.Value Is Null Or Parameters.reportDate.Value Is Null," +
            " False, True)"));
			this.CustomerName.CanShrink = true;
			this.CustomerName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.CustomerName.Name = "CustomerName";
			this.CustomerName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CustomerName.Style.Font.Bold = true;
			this.CustomerName.Style.Font.Name = "Calibri";
			this.CustomerName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(12D);
			this.CustomerName.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
			this.CustomerName.Value = "= Parameters.customerName.Value";
			// 
			// TravelogOnline
			// 
			this.TravelogOnline.CanShrink = true;
			this.TravelogOnline.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TravelogOnline.Name = "TravelogOnline";
			this.TravelogOnline.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TravelogOnline.Style.Font.Bold = true;
			this.TravelogOnline.Style.Font.Name = "Arial";
			this.TravelogOnline.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(12D);
			this.TravelogOnline.Style.Visible = false;
			this.TravelogOnline.Value = "travelog online";
			// 
			// ReportName
			// 
			this.ReportName.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.reportName.Value Is Null Or Parameters.reportDate.Value Is Null," +
            " False, True)"));
			this.ReportName.CanShrink = true;
			this.ReportName.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReportName.Name = "ReportName";
			this.ReportName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ReportName.Style.Font.Bold = true;
			this.ReportName.Style.Font.Name = "Calibri";
			this.ReportName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(12D);
			this.ReportName.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
			this.ReportName.Value = "= Parameters.reportName.Value + \" - \" + Parameters.reportDate.Value";
			// 
			// ManagementReportHeaderSubReport2
			// 
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailSection});
			this.Name = "ManagementReportHeaderSubReport2";
			this.PageSettings.Landscape = true;
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(1.5D), Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "customerName";
			reportParameter1.Value = "";
			reportParameter2.AllowNull = true;
			reportParameter2.Name = "reportName";
			reportParameter2.Value = "";
			reportParameter3.AllowNull = true;
			reportParameter3.Name = "reportDate";
			reportParameter4.Name = "headerContent";
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(18D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection DetailSection;
		private Telerik.Reporting.TextBox CustomerName;
		private Telerik.Reporting.TextBox TravelogOnline;
		private Telerik.Reporting.HtmlTextBox HeaderContent;
		private Telerik.Reporting.TextBox ReportName;
	}
}