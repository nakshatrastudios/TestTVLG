﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Text;
using Telerik.Reporting;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;

namespace Travelog.Reports.GeneralLedger {
	public class GeneralLedgerDataSources {
		private const string ClassName = "Travelog.Reports.GeneralLedger.GeneralLedgerDataSources";

		public List<GeneralLedgerReportModel> GeneralLedgerReport(string reportSource, int customerId, int agencyId, int currentDefaultAgencyId, string userRoleId, int transactionViewOptionId, int chartOfAccountTypeId, int accountCategoryId, DateTime fiscalYearStartDate, DateTime periodFrom, DateTime dateFrom, DateTime dateTo, bool excludeZeroBalances, bool useAltReportingCode, bool useDateFilters) {
			try {
				using (var lazyContext = new AppLazyContext(customerId, true)) {
					var q = Biz.Dao.GeneralLedger.GeneralLedger.GetGeneralLedgerQuery(lazyContext, customerId, agencyId, currentDefaultAgencyId, userRoleId, chartOfAccountTypeId, (AccountCategory)accountCategoryId, fiscalYearStartDate, periodFrom, dateFrom, dateTo, (ReportSourceGeneralLedger)Enum.Parse(typeof(ReportSourceGeneralLedger), reportSource), (TransactionViewOption)transactionViewOptionId, excludeZeroBalances, useAltReportingCode, useDateFilters, false);
					var model = new List<GeneralLedgerReportModel>();

					if (chartOfAccountTypeId == -1) {
						model = q.ConvertAll(row => new GeneralLedgerReportModel {
							TransactionViewOption = (TransactionViewOption)transactionViewOptionId,
							Code = row.Code,
							Name = row.Name,
							RowTypeId = (int)row.ChartOfAccount.RowType,
							PeriodBudget = row.PeriodBudget,
							PeriodCurrentYear = row.PeriodCurrentYear,
							PeriodPreviousYear = row.PeriodPreviousYear,
							YtdBudget = row.YtdBudget,
							YtdCurrentYear = row.YtdCurrentYear,
							YtdPreviousYear = row.YtdPreviousYear
						});

						model.Add(new GeneralLedgerReportModel {
							TransactionViewOption = (TransactionViewOption)transactionViewOptionId,
							Code = "Totals",
							Name = string.Empty,
							RowTypeId = (int)RowType.Total,
							PeriodBudget = q.Sum(t => (decimal?)t.PeriodBudget) ?? 0,
							PeriodCurrentYear = q.Sum(t => (decimal?)t.PeriodCurrentYear) ?? 0,
							PeriodPreviousYear = q.Sum(t => (decimal?)t.PeriodPreviousYear) ?? 0,
							YtdBudget = q.Sum(t => (decimal?)t.YtdBudget) ?? 0,
							YtdCurrentYear = q.Sum(t => (decimal?)t.YtdCurrentYear) ?? 0,
							YtdPreviousYear = q.Sum(t => (decimal?)t.YtdPreviousYear) ?? 0
						});

						return model;
					}

					var totalLevelList = new List<TotalLevelModel>();

					foreach (var row in q) {
						if (row.ChartOfAccount.RowType == RowType.Normal || row.ChartOfAccount.RowType == RowType.UndistributedProfits || row.ChartOfAccount.RowType == RowType.RetainedProfits) {
							for (int totalLevelId = (int)row.TotalGroupLevel; totalLevelId <= (int)TotalLevel.Total9; totalLevelId++) {
								var totalLevel = (TotalLevel)totalLevelId;

								if (totalLevelList.Any(t => t.TotalLevel == totalLevel)) {
									totalLevelList.Single(t => t.TotalLevel == totalLevel && t.ColumnName == TotalLevelColumnName.PeriodBudgetTotal).Amount += row.PeriodBudget;
									totalLevelList.Single(t => t.TotalLevel == totalLevel && t.ColumnName == TotalLevelColumnName.PeriodCurrentYearTotal).Amount += row.PeriodCurrentYear;
									totalLevelList.Single(t => t.TotalLevel == totalLevel && t.ColumnName == TotalLevelColumnName.PeriodPreviousYearTotal).Amount += row.PeriodPreviousYear;
									totalLevelList.Single(t => t.TotalLevel == totalLevel && t.ColumnName == TotalLevelColumnName.YtdBudgetTotal).Amount += row.YtdBudget;
									totalLevelList.Single(t => t.TotalLevel == totalLevel && t.ColumnName == TotalLevelColumnName.YtdCurrentYearTotal).Amount += row.YtdCurrentYear;
									totalLevelList.Single(t => t.TotalLevel == totalLevel && t.ColumnName == TotalLevelColumnName.YtdPreviousYearTotal).Amount += row.YtdPreviousYear;
								}
								else {
									totalLevelList.Add(new TotalLevelModel { TotalLevel = totalLevel, ColumnName = TotalLevelColumnName.PeriodBudgetTotal, Amount = row.PeriodBudget });
									totalLevelList.Add(new TotalLevelModel { TotalLevel = totalLevel, ColumnName = TotalLevelColumnName.PeriodCurrentYearTotal, Amount = row.PeriodCurrentYear });
									totalLevelList.Add(new TotalLevelModel { TotalLevel = totalLevel, ColumnName = TotalLevelColumnName.PeriodPreviousYearTotal, Amount = row.PeriodPreviousYear });
									totalLevelList.Add(new TotalLevelModel { TotalLevel = totalLevel, ColumnName = TotalLevelColumnName.YtdBudgetTotal, Amount = row.YtdBudget });
									totalLevelList.Add(new TotalLevelModel { TotalLevel = totalLevel, ColumnName = TotalLevelColumnName.YtdCurrentYearTotal, Amount = row.YtdCurrentYear });
									totalLevelList.Add(new TotalLevelModel { TotalLevel = totalLevel, ColumnName = TotalLevelColumnName.YtdPreviousYearTotal, Amount = row.YtdPreviousYear });
								}
							}
						}

						if (row.ChartOfAccount.RowType == RowType.Total) {
							model.Add(new GeneralLedgerReportModel {
								TransactionViewOption = (TransactionViewOption)transactionViewOptionId,
								Code = row.Name,
								Name = string.Empty,
								RowTypeId = (int)row.ChartOfAccount.RowType,
								PeriodBudget = totalLevelList.SingleOrDefault(t => t.TotalLevel == row.TotalGroupLevel && t.ColumnName == TotalLevelColumnName.PeriodBudgetTotal)?.Amount ?? 0,
								PeriodCurrentYear = totalLevelList.SingleOrDefault(t => t.TotalLevel == row.TotalGroupLevel && t.ColumnName == TotalLevelColumnName.PeriodCurrentYearTotal)?.Amount ?? 0,
								PeriodPreviousYear = totalLevelList.SingleOrDefault(t => t.TotalLevel == row.TotalGroupLevel && t.ColumnName == TotalLevelColumnName.PeriodPreviousYearTotal)?.Amount ?? 0,
								YtdBudget = totalLevelList.SingleOrDefault(t => t.TotalLevel == row.TotalGroupLevel && t.ColumnName == TotalLevelColumnName.YtdBudgetTotal)?.Amount ?? 0,
								YtdCurrentYear = totalLevelList.SingleOrDefault(t => t.TotalLevel == row.TotalGroupLevel && t.ColumnName == TotalLevelColumnName.YtdCurrentYearTotal)?.Amount ?? 0,
								YtdPreviousYear = totalLevelList.SingleOrDefault(t => t.TotalLevel == row.TotalGroupLevel && t.ColumnName == TotalLevelColumnName.YtdPreviousYearTotal)?.Amount ?? 0
							});

							if (totalLevelList.Any(t => t.TotalLevel == row.TotalGroupLevel)) {
								foreach (var item in (TotalLevelColumnName[])Enum.GetValues(typeof(TotalLevelColumnName))) {
									totalLevelList.Single(t => t.TotalLevel == row.TotalGroupLevel && t.ColumnName == item).Amount = 0;
								}
							}
						}
						else {
							model.Add(new GeneralLedgerReportModel {
								TransactionViewOption = (TransactionViewOption)transactionViewOptionId,
								Code = row.Code,
								Name = row.Name,
								RowTypeId = (int)row.ChartOfAccount.RowType,
								PeriodBudget = row.PeriodBudget,
								PeriodCurrentYear = row.PeriodCurrentYear,
								PeriodPreviousYear = row.PeriodPreviousYear,
								YtdBudget = row.YtdBudget,
								YtdCurrentYear = row.YtdCurrentYear,
								YtdPreviousYear = row.YtdPreviousYear
							});
						}
					}

					return model;
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "GeneralLedgerReport", ex, customerId);
				return new List<GeneralLedgerReportModel>();
			}
		}

        public List<GeneralLedgerTransactionReportModel> GeneralLedgerTransactionReport(int customerId, int agencyId, string userRoleId, int transactionViewOptionId, bool useAltReportingCode, DateTime fiscalYearStartDate, DateTime previousFiscalYearStartDate, bool includeMonthlyTotals, bool existingTransactionsOnly, DateTime? dateFrom, DateTime? dateTo, int? transactionTypeId, int? chartOfAccountTypeId, int? accountCategoryId, string chartOfAccountIds) {
            try {
                using (var lazyContext = new AppLazyContext(customerId, true)) {
                    var transactionViewOption = (TransactionViewOption)transactionViewOptionId;
                    var transactionType = TransactionType.All;
                    var chartOfAccountType = ChartOfAccountType.NotSpecified;
                    var accountCategory = AccountCategory.None;

                    int[] chartOfAccountIdList = null;

                    if (transactionTypeId != null)
                        transactionType = (TransactionType)transactionTypeId;

                    if (chartOfAccountTypeId != null)
                        chartOfAccountType = (ChartOfAccountType)chartOfAccountTypeId;

                    if (accountCategoryId != null)
                        accountCategory = (AccountCategory)accountCategoryId;

                    if (!string.IsNullOrEmpty(chartOfAccountIds))
                        chartOfAccountIdList = chartOfAccountIds.Split(',').Select(int.Parse).ToArray();

                    var q = Biz.Dao.GeneralLedger.GeneralLedger.GetGeneralLedgerTransactionReportQuery(
                        lazyContext: lazyContext,
                        agencyId: agencyId,
                        userRoleId: userRoleId,
                        transactionViewOption: transactionViewOption,
                        fiscalYearStartDate: fiscalYearStartDate,
                        previousFiscalYearStartDate: previousFiscalYearStartDate,
                        dateFrom: dateFrom ?? DateTime.MinValue,
                        dateTo: dateTo ?? DateTime.MinValue,
                        transactionType: transactionType,
                        chartOfAccountType: chartOfAccountType,
                        accountCategory: accountCategory,
                        useAltReportingCode: useAltReportingCode,
                        includeMonthlyTotals: includeMonthlyTotals,
                        chartOfAccountIds: chartOfAccountIdList
                    ).Select(row => new GeneralLedgerTransactionReportModel {
                        ChartOfAccountId = row.ChartOfAccount.Id,
                        Code = row.Code,
                        Name = row.Name,
                        ChartOfAccountType = row.ChartOfAccount.ChartOfAccountType,
                        RowType = row.ChartOfAccount.RowType,
                        AccountCategory = row.ChartOfAccount.AccountCategory.GetEnumDescription(),
                        ChartOfAccountTransactionType = row.ChartOfAccount.ChartOfAccountTransactionType.GetEnumDescription(),
                        TotalAmount = (row.TransactionDetailPeriod.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) - (row.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.BalanceSheet && row.ChartOfAccount.RowType != RowType.RetainedProfits ? 0 : row.Period.PreviousYearBalance),
                        YtdBalance = (row.ChartOfAccount.RowType == RowType.RetainedProfits ? -1 : 1) * (row.Period.YtdBalance - (row.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.BalanceSheet && row.ChartOfAccount.RowType != RowType.RetainedProfits ? 0 : row.Period.PreviousYearBalance)),
                        PreviousYearBalance = row.Period.PreviousYearBalance,
                        Period01 = row.Period.Period[0],
                        Period02 = row.Period.Period[1],
                        Period03 = row.Period.Period[2],
                        Period04 = row.Period.Period[3],
                        Period05 = row.Period.Period[4],
                        Period06 = row.Period.Period[5],
                        Period07 = row.Period.Period[6],
                        Period08 = row.Period.Period[7],
                        Period09 = row.Period.Period[8],
                        Period10 = row.Period.Period[9],
                        Period11 = row.Period.Period[10],
                        Period12 = row.Period.Period[11],
                        Row1Value01 = row.Period.Row1Value[0],
                        Row1Value02 = row.Period.Row1Value[1],
                        Row1Value03 = row.Period.Row1Value[2],
                        Row1Value04 = row.Period.Row1Value[3],
                        Row1Value05 = row.Period.Row1Value[4],
                        Row1Value06 = row.Period.Row1Value[5],
                        Row1Value07 = row.Period.Row1Value[6],
                        Row1Value08 = row.Period.Row1Value[7],
                        Row1Value09 = row.Period.Row1Value[8],
                        Row1Value10 = row.Period.Row1Value[9],
                        Row1Value11 = row.Period.Row1Value[10],
                        Row1Value12 = row.Period.Row1Value[11],
                        Row2Value01 = row.Period.Row2Value[0],
                        Row2Value02 = row.Period.Row2Value[1],
                        Row2Value03 = row.Period.Row2Value[2],
                        Row2Value04 = row.Period.Row2Value[3],
                        Row2Value05 = row.Period.Row2Value[4],
                        Row2Value06 = row.Period.Row2Value[5],
                        Row2Value07 = row.Period.Row2Value[6],
                        Row2Value08 = row.Period.Row2Value[7],
                        Row2Value09 = row.Period.Row2Value[8],
                        Row2Value10 = row.Period.Row2Value[9],
                        Row2Value11 = row.Period.Row2Value[10],
                        Row2Value12 = row.Period.Row2Value[11],
                        Row3Value01 = row.Period.Row3Value[0],
                        Row3Value02 = row.Period.Row3Value[1],
                        Row3Value03 = row.Period.Row3Value[2],
                        Row3Value04 = row.Period.Row3Value[3],
                        Row3Value05 = row.Period.Row3Value[4],
                        Row3Value06 = row.Period.Row3Value[5],
                        Row3Value07 = row.Period.Row3Value[6],
                        Row3Value08 = row.Period.Row3Value[7],
                        Row3Value09 = row.Period.Row3Value[8],
                        Row3Value10 = row.Period.Row3Value[9],
                        Row3Value11 = row.Period.Row3Value[10],
                        Row3Value12 = row.Period.Row3Value[11],
                        TransactionDetailReportList = row.TransactionDetail.Where(t => t.Transaction.DocumentDate >= dateFrom).AsEnumerable().GroupBy(t1 => new {
                            t1.Transaction,
                            Description = t1.Transaction.TransactionType == TransactionType.Journal ? t1.Transaction.Journal.Comments : t1.Transaction.TransactionType == TransactionType.Adjustment ? t1.Description.Length == 0 ? t1.Transaction.Adjustment.AdjustmentType.Name : t1.Description : t1.Description
                        }).OrderBy(t1 => t1.Key.Transaction.DocumentDate).ThenBy(t1 => t1.Key.Transaction.DocumentNo).Select(t1 => new TransactionDetailReportModel {
                            TransactionDetailAllocationId = t1.Min(t2 => t2.Id),
                            TransactionType = t1.Key.Transaction.EffectiveTransactionType.GetEnumDescription(),
                            DocumentDate = t1.Key.Transaction.DocumentDate,
                            DocumentNo = t1.Key.Transaction.DocumentNo,
                            ChartOfAccount = string.Concat(row.Code, ": ", row.Name).TrimStart(": "),
                            AccountName = t1.Key.Transaction.AccountName,
                            Description = t1.Key.Description,
                            AmountGross = t1.Sum(t2 => (decimal?)(t2.Amount + t2.Tax)) ?? 0
                        }).ToList()
                    }).ToList();

                    foreach (var row in q) {
                        if (row.ChartOfAccountType == ChartOfAccountType.BalanceSheet && dateFrom == fiscalYearStartDate) {
                            row.TransactionDetailReportList.Insert(0, new TransactionDetailReportModel {
                                TransactionDetailAllocationId = -2,
                                TransactionType = string.Empty,
                                DocumentDate = fiscalYearStartDate,
                                DocumentNo = string.Empty,
                                ChartOfAccount = string.Concat(row.Code, ": ", row.Name).TrimStart(": "),
                                AccountName = string.Empty,
                                Description = "Opening Balance",
                                AmountGross = row.PreviousYearBalance
                            });
                        }

                        row.AccumulatedTotal = row.TransactionDetailReportList.Sum(t => t.AmountGross);
                    }

                    if (existingTransactionsOnly)
                        return q.Where(t => t.TransactionDetailReportList.Count > 0).ToList();

                    return q;
                }
            }
            catch (Exception ex) {
                ExceptionManagerBiz.Instance.HandleException(ClassName, "GeneralLedgerTransactionReport", ex, customerId);
                return new List<GeneralLedgerTransactionReportModel>();
            }
        }

        public List<GeneralLedgerTransactionReportModel> GeneralLedgerBudgetReport(int customerId, int agencyId, string userRoleId, DateTime fiscalYearStartDate) {
			try {
				using (var context = new AppMainContext(customerId, true)) {
					var q = Biz.Dao.GeneralLedger.GeneralLedger.GetGeneralLedgerBudgetQuery(context, agencyId, userRoleId, fiscalYearStartDate).AsEnumerable().Where(t1 => t1.Period.Row1Value.Any(t2 => t2 != 0)).ToList();

					return q.ConvertAll(row => new GeneralLedgerTransactionReportModel {
						ChartOfAccountId = row.ChartOfAccount.Id,
						Code = row.Code,
						Name = row.Name,
						ChartOfAccountType = row.ChartOfAccount.ChartOfAccountType,
						AccountCategory = row.ChartOfAccount.AccountCategory.GetEnumDescription(),
						ChartOfAccountTransactionType = row.ChartOfAccount.ChartOfAccountTransactionType.GetEnumDescription(),
						AltReportingCode = row.ChartOfAccount.AltReportingCode,
						Period01 = row.Period.Period[0],
						Period02 = row.Period.Period[1],
						Period03 = row.Period.Period[2],
						Period04 = row.Period.Period[3],
						Period05 = row.Period.Period[4],
						Period06 = row.Period.Period[5],
						Period07 = row.Period.Period[6],
						Period08 = row.Period.Period[7],
						Period09 = row.Period.Period[8],
						Period10 = row.Period.Period[9],
						Period11 = row.Period.Period[10],
						Period12 = row.Period.Period[11],
						Row1Value01 = row.Period.Row1Value[0],
						Row1Value02 = row.Period.Row1Value[1],
						Row1Value03 = row.Period.Row1Value[2],
						Row1Value04 = row.Period.Row1Value[3],
						Row1Value05 = row.Period.Row1Value[4],
						Row1Value06 = row.Period.Row1Value[5],
						Row1Value07 = row.Period.Row1Value[6],
						Row1Value08 = row.Period.Row1Value[7],
						Row1Value09 = row.Period.Row1Value[8],
						Row1Value10 = row.Period.Row1Value[9],
						Row1Value11 = row.Period.Row1Value[10],
						Row1Value12 = row.Period.Row1Value[11]
					});
				}
			}
			catch (Exception ex) {
				ExceptionManagerBiz.Instance.HandleException(ClassName, "GeneralLedgerBudgetReport", ex, customerId);
				return new List<GeneralLedgerTransactionReportModel>();
			}
		}

		public static TypeReportSource GetReportSource(AppMainContext context, IPrincipal principal, GeneralLedgerReportSourceModel model, int currentDefaultAgencyId) {
			string typeName;
			var sb = new StringBuilder();

			switch (model.ReportSource) {
				case ReportSourceGeneralLedger.TrialBalance:
				case ReportSourceGeneralLedger.ProfitLoss:
				case ReportSourceGeneralLedger.BalanceSheet:
					var setting = Setting.GetRow(model.CustomerId, model.PeriodFrom ?? DateTime.MinValue);

					switch (model.TransactionViewOption) {
						case TransactionViewOption.CurrentPrevious:
							model.YtdColumn1Header = setting.FiscalYearStartDateName;
							model.YtdColumn2Header = setting.FiscalYearPreviousStartDateName;
							model.YtdColumn3Header = "Variance";
							break;
						case TransactionViewOption.CurrentPreviousVariance:
							model.PeriodColumn1Header = setting.FiscalPeriodEndDateName;
							model.PeriodColumn2Header = setting.FiscalPeriodPreviousEndDateName;
							model.PeriodColumn3Header = "Variance";
							model.YtdColumn1Header = setting.FiscalYearStartDateName;
							model.YtdColumn2Header = setting.FiscalYearPreviousStartDateName;
							model.YtdColumn3Header = "Variance";
							break;
						case TransactionViewOption.CurrentBudgetVariance:
							model.PeriodColumn1Header = setting.FiscalPeriodEndDateName;
							model.PeriodColumn2Header = "Budget";
							model.PeriodColumn3Header = "Variance";
							model.YtdColumn1Header = setting.FiscalYearStartDateName;
							model.YtdColumn2Header = "Budget";
							model.YtdColumn3Header = "Variance";
							break;
						case TransactionViewOption.CurrentBudgetPrevious:
							model.PeriodColumn1Header = setting.FiscalPeriodEndDateName;
							model.PeriodColumn2Header = "Budget";
							model.PeriodColumn3Header = setting.FiscalPeriodPreviousEndDateName;
							model.YtdColumn1Header = setting.FiscalYearStartDateName;
							model.YtdColumn2Header = "Budget";
							model.YtdColumn3Header = setting.FiscalYearPreviousStartDateName;
							break;
					}

					if ((model.PeriodColumn1Header?.Length ?? 0) == 0)
						model.PeriodColumn1Header = "N/A";

					if ((model.PeriodColumn2Header?.Length ?? 0) == 0)
						model.PeriodColumn2Header = "N/A";

					if ((model.PeriodColumn3Header?.Length ?? 0) == 0)
						model.PeriodColumn3Header = "N/A";

					if ((model.YtdColumn1Header?.Length ?? 0) == 0)
						model.YtdColumn1Header = "N/A";

					if ((model.YtdColumn2Header?.Length ?? 0) == 0)
						model.YtdColumn2Header = "N/A";

					if ((model.YtdColumn3Header?.Length ?? 0) == 0)
						model.YtdColumn3Header = "N/A";

					break;
				case ReportSourceGeneralLedger.GeneralLedgerTransactions:
					if ((model.DateFrom ?? DateTime.MinValue) == DateTime.MinValue)
						throw new UnreportedException("Date From is required.");

					if ((model.DateTo ?? DateTime.MinValue) == DateTime.MinValue)
						throw new UnreportedException("Date To is required.");

					break;
			}

			sb.AppendFormat("Agency: {0}", (model.AgencyId ?? 0) <= 0 ? "All Agencies" : context.Agency.Find(model.AgencyId).Name);

			switch (model.ReportSource) {
				default:
					throw new InvalidOperationException("Invalid Report Source.");
				case ReportSourceGeneralLedger.TrialBalance:
				case ReportSourceGeneralLedger.ProfitLoss:
				case ReportSourceGeneralLedger.BalanceSheet:
					if (model.UseDateFilters) {
						sb.AppendFormat(" | Date From: {0}", (model.DateFrom ?? DateTime.MinValue) == DateTime.MinValue ? "All Dates" : (model.DateFrom ?? DateTime.MinValue).ToShortDateStringExt());
						sb.AppendFormat(" | Date To: {0}", (model.DateTo ?? DateTime.MinValue) == DateTime.MinValue ? "All Dates" : (model.DateTo ?? DateTime.MinValue).ToShortDateStringExt());
					}
					else {
						sb.AppendFormat(" | Fiscal Year: {0}", model.FiscalYearStartDateName);
					}

					typeName = typeof(GeneralLedgerReport).AssemblyQualifiedName;
					model.ChartOfAccountType = model.ReportSource == ReportSourceGeneralLedger.TrialBalance ? ChartOfAccountType.NotSpecified : model.ReportSource == ReportSourceGeneralLedger.ProfitLoss ? ChartOfAccountType.ProfitLoss : ChartOfAccountType.BalanceSheet;
					break;
				case ReportSourceGeneralLedger.GeneralLedgerTransactions:
					sb.AppendFormat(" | Date From: {0}", (model.DateFrom ?? DateTime.MinValue) == DateTime.MinValue ? "All Dates" : (model.DateFrom ?? DateTime.MinValue).ToShortDateStringExt());
					sb.AppendFormat(" | Date To: {0}", (model.DateTo ?? DateTime.MinValue) == DateTime.MinValue ? "All Dates" : (model.DateTo ?? DateTime.MinValue).ToShortDateStringExt());
					sb.AppendFormat("{0}Transaction Type: {1}", AppConstants.HtmlLineBreak, (model.TransactionType ?? TransactionType.All) == TransactionType.All ? "All Transaction Types" : (model.TransactionType ?? TransactionType.All).GetEnumDescription());
					sb.AppendFormat(" | Account Type: {0}", (model.ChartOfAccountType ?? ChartOfAccountType.NotSpecified) == ChartOfAccountType.NotSpecified ? "All Account Types" : (model.ChartOfAccountType ?? ChartOfAccountType.NotSpecified).GetEnumDescription());
					sb.AppendFormat(" | Account Category: {0}", (model.AccountCategory ?? AccountCategory.None) == AccountCategory.None ? "All Account Categories" : (model.AccountCategory ?? AccountCategory.None).GetEnumDescription());

					typeName = typeof(GeneralLedgerTransactionsReport).AssemblyQualifiedName;
					break;
				case ReportSourceGeneralLedger.Budget:
					sb.AppendFormat(" | Fiscal Year: {0}", model.FiscalYearStartDateName);
					typeName = typeof(GeneralLedgerBudgetReport).AssemblyQualifiedName;
					break;
			}

			var reportSource = new TypeReportSource {
				TypeName = typeName
			};

			reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = model.CustomerId });
			reportSource.Parameters.Add(new Parameter { Name = "agencyId", Value = model.AgencyId ?? 0 });
			reportSource.Parameters.Add(new Parameter { Name = "userRoleId", Value = model.UserRoleId });
			reportSource.Parameters.Add(new Parameter { Name = "customerName", Value = Utils.GetCustomerName(model.CustomerId, model.DefaultAgency) });
			reportSource.Parameters.Add(new Parameter { Name = "reportName", Value = GetReportName(model.ReportSource) });
			reportSource.Parameters.Add(new Parameter { Name = "headerContent", Value = Utils.HtmlEncodeExceptTags(sb.ToString()) });
			reportSource.Parameters.Add(new Parameter { Name = "creationUser", Value = model.CreationUser });
			reportSource.Parameters.Add(new Parameter { Name = "creationTime", Value = model.CreationTime });
			reportSource.Parameters.Add(new Parameter { Name = "fiscalYearStartDate", Value = model.FiscalYearStartDate ?? DateTime.MinValue });
			reportSource.Parameters.Add(new Parameter { Name = "isLast", Value = model.YtdColumn2Header == "N/A" });

			switch (model.ReportSource) {
				case ReportSourceGeneralLedger.TrialBalance:
				case ReportSourceGeneralLedger.ProfitLoss:
				case ReportSourceGeneralLedger.BalanceSheet:
				case ReportSourceGeneralLedger.GeneralLedgerTransactions:
					reportSource.Parameters.Add(new Parameter { Name = "reportDate", Value = (model.PeriodFrom ?? DateTime.MinValue).ToShortDateStringExt().Substring(3) });
					reportSource.Parameters.Add(new Parameter { Name = "dateFrom", Value = model.DateFrom ?? DateTime.MinValue });
					reportSource.Parameters.Add(new Parameter { Name = "dateTo", Value = model.DateTo ?? DateTime.MinValue });
					reportSource.Parameters.Add(new Parameter { Name = "transactionViewOptionId", Value = (int)(model.TransactionViewOption ?? TransactionViewOption.CurrentPreviousVariance) });
					reportSource.Parameters.Add(new Parameter { Name = "chartOfAccountTypeId", Value = (int)(model.ChartOfAccountType ?? ChartOfAccountType.NotSpecified) });
					reportSource.Parameters.Add(new Parameter { Name = "accountCategoryId", Value = (int)(model.AccountCategory ?? AccountCategory.None) });
					reportSource.Parameters.Add(new Parameter { Name = "useAltReportingCode", Value = model.UseAltReportingCode });
					break;
				case ReportSourceGeneralLedger.Budget:
					reportSource.Parameters.Add(new Parameter { Name = "reportDate", Value = (model.PeriodFrom ?? DateTime.MinValue).ToShortDateStringExt() });
					break;
			}

			switch (model.ReportSource) {
				case ReportSourceGeneralLedger.TrialBalance:
				case ReportSourceGeneralLedger.ProfitLoss:
				case ReportSourceGeneralLedger.BalanceSheet:
					reportSource.Parameters.Add(new Parameter { Name = "customerId", Value = model.CustomerId });
					reportSource.Parameters.Add(new Parameter { Name = "userName", Value = principal.Identity.Name });
					reportSource.Parameters.Add(new Parameter { Name = "reportSource", Value = model.ReportSource });
					reportSource.Parameters.Add(new Parameter { Name = "currentDefaultAgencyId", Value = currentDefaultAgencyId });
					reportSource.Parameters.Add(new Parameter { Name = "periodFrom", Value = model.PeriodFrom ?? DateTime.MinValue });
					reportSource.Parameters.Add(new Parameter { Name = "excludeZeroBalances", Value = model.TransactionBalanceType == TransactionBalanceType.NonZero });
					reportSource.Parameters.Add(new Parameter { Name = "useDateFilters", Value = model.UseDateFilters });
					reportSource.Parameters.Add(new Parameter { Name = "reportSignId", Value = (int)AppSettings.Setting(model.CustomerId).GeneralLedgerReportSign });

					reportSource.Parameters.Add(new Parameter { Name = "periodColumn1Header", Value = model.PeriodColumn1Header });
					reportSource.Parameters.Add(new Parameter { Name = "periodColumn2Header", Value = model.PeriodColumn2Header });
					reportSource.Parameters.Add(new Parameter { Name = "periodColumn3Header", Value = model.PeriodColumn3Header });
					reportSource.Parameters.Add(new Parameter { Name = "ytdColumn3Header", Value = model.YtdColumn3Header });

					switch (model.TransactionViewOption) {
						default:
							reportSource.Parameters.Add(new Parameter { Name = "ytdColumn1Header", Value = model.YtdColumn1Header == "N/A" ? model.YtdColumn1Header : string.Format("{0} YTD", model.YtdColumn1Header) });
							reportSource.Parameters.Add(new Parameter { Name = "ytdColumn2Header", Value = model.YtdColumn2Header });
							break;
						case TransactionViewOption.CurrentPrevious:
							reportSource.Parameters.Add(new Parameter { Name = "ytdColumn1Header", Value = model.YtdColumn1Header == "N/A" ? model.YtdColumn1Header : string.Format("{0} YTD", model.YtdColumn1Header) });
							reportSource.Parameters.Add(new Parameter { Name = "ytdColumn2Header", Value = model.YtdColumn2Header == "N/A" ? model.YtdColumn2Header : string.Format("{0} Year End", model.YtdColumn2Header) });
							break;
						case TransactionViewOption.CurrentPreviousVariance:
							reportSource.Parameters.Add(new Parameter { Name = "ytdColumn1Header", Value = model.YtdColumn1Header == "N/A" ? model.YtdColumn1Header : string.Format("{0} YTD", model.YtdColumn1Header) });
							reportSource.Parameters.Add(new Parameter { Name = "ytdColumn2Header", Value = model.YtdColumn2Header == "N/A" ? model.YtdColumn2Header : string.Format("{0} YTD", model.YtdColumn2Header) });
							break;
					}

					break;
				case ReportSourceGeneralLedger.GeneralLedgerTransactions:
					reportSource.Parameters.Add(new Parameter { Name = "previousFiscalYearStartDate", Value = model.PreviousFiscalYearStartDate ?? DateTime.MinValue });
					reportSource.Parameters.Add(new Parameter { Name = "transactionDateOptionId", Value = (int)(model.TransactionDateOption ?? TransactionDateOption.TxnDate) });
					reportSource.Parameters.Add(new Parameter { Name = "generalLedgerReportTypeId", Value = (int)(model.GeneralLedgerReportType ?? GeneralLedgerReportType.GeneralLedger) });
					reportSource.Parameters.Add(new Parameter { Name = "includeMonthlyTotals", Value = model.IncludeMonthlyTotals });
					reportSource.Parameters.Add(new Parameter { Name = "transactionTypeId", Value = (int)(model.TransactionType ?? TransactionType.All) });
					reportSource.Parameters.Add(new Parameter { Name = "chartOfAccountIds", Value = model.ChartOfAccountIds == null ? string.Empty : string.Join(",", model.ChartOfAccountIds) });
					reportSource.Parameters.Add(new Parameter { Name = "existingTransactionsOnly", Value = model.ExistingTransactionsOnly });

					string currentYear = Setting.GetRow(model.CustomerId, model.FiscalYearStartDate ?? DateTime.MinValue).FiscalYearStartDateName;
					string previousYear = Setting.GetRow(model.CustomerId, model.PreviousFiscalYearStartDate ?? DateTime.MinValue).FiscalYearStartDateName;

					reportSource.Parameters.Add(new Parameter { Name = "column1Label", Value = currentYear });

					switch (model.TransactionViewOption) {
						case TransactionViewOption.CurrentPreviousVariance:
							reportSource.Parameters.Add(new Parameter { Name = "column2Label", Value = previousYear });
							reportSource.Parameters.Add(new Parameter { Name = "column3Label", Value = "Variance" });
							break;
						case TransactionViewOption.CurrentBudgetVariance:
							reportSource.Parameters.Add(new Parameter { Name = "column2Label", Value = "Budget" });
							reportSource.Parameters.Add(new Parameter { Name = "column3Label", Value = "Variance" });
							break;
						case TransactionViewOption.CurrentBudgetPrevious:
							reportSource.Parameters.Add(new Parameter { Name = "column2Label", Value = "Budget" });
							reportSource.Parameters.Add(new Parameter { Name = "column3Label", Value = previousYear });
							break;
					}

					break;
			}

			return reportSource;
		}

		public static string GetReportName(ReportSourceGeneralLedger reportSource) {
			switch (reportSource) {
				default:
					throw new InvalidOperationException("Invalid Report Source.");
				case ReportSourceGeneralLedger.TrialBalance:
					return "General Ledger Trial Balance";
				case ReportSourceGeneralLedger.ProfitLoss:
					return "General Ledger Profit & Loss";
				case ReportSourceGeneralLedger.BalanceSheet:
					return "General Ledger Balance Sheet";
				case ReportSourceGeneralLedger.GeneralLedgerTransactions:
					return "General Ledger Transactions";
				case ReportSourceGeneralLedger.Budget:
					return "General Ledger Budget";
			}
		}

		public static string GetReportFileName(ReportSourceGeneralLedger reportSource) {
			return WebUtility.HtmlDecode(GetReportName(reportSource));
		}
	}
}