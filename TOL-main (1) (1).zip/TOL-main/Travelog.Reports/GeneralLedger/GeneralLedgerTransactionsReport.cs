using Telerik.Reporting;

namespace Travelog.Reports.GeneralLedger {
	public partial class GeneralLedgerTransactionsReport : TelerikReport {
		public GeneralLedgerTransactionsReport() {
			InitializeComponent();
		}
	}
}