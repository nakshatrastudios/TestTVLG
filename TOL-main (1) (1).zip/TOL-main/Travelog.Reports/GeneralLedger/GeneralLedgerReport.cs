using System;
using Telerik.Reporting;
using Telerik.Reporting.Drawing;
using Travelog.Biz.Enums;

namespace Travelog.Reports.GeneralLedger {
	public partial class GeneralLedgerReport : TelerikReport {
		private TransactionViewOption TransactionViewOption { get; set; }
		private ReportSign ReportSign { get; set; }
		private bool IsLast { get; set; }

		public GeneralLedgerReport() {
			InitializeComponent();
			ItemDataBinding += Report_ItemDataBinding;
		}

		private void Report_ItemDataBinding(object sender, EventArgs e) {
			var report = sender as Telerik.Reporting.Processing.Report;
			var parameters = report.Parameters;

			Enum.TryParse(parameters["transactionViewOptionId"].Value.ToString(), out TransactionViewOption transactionViewOption);
			Enum.TryParse(parameters["reportSignId"].Value.ToString(), out ReportSign reportSign);
			bool.TryParse(parameters["isLast"].Value.ToString(), out bool isLast);

			TransactionViewOption = transactionViewOption;
			ReportSign = reportSign;
			IsLast = isLast;
		}

		private void Name_ItemDataBound(object sender, EventArgs e) {
			if (TransactionViewOption != TransactionViewOption.CurrentPrevious)
				return;

			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			if (textBox.Value == null)
				return;

			textBox.Width = Unit.Cm(textBox.Width.Value + 3.2);
		}

		private void PeriodColumnHeader_ItemDataBound(object sender, EventArgs e) {
			FormatTextBox(sender);
		}

		private void PeriodColumn_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;
			FormatTextBox(sender, textBox);
			FormatValue(sender, textBox);
		}

		private void YtdColumn_ItemDataBound(object sender, EventArgs e) {
			var textBox = (Telerik.Reporting.Processing.TextBox)sender;

			if (textBox.Value == null)
				return;

			if (IsLast) {
				YtdColumn2.Value = "0";
				YtdColumn2Total.Value = "0";
				YtdColumn3.Value = YtdColumn1.Value;
				YtdColumn3Total.Value = YtdColumn1Total.Value;
			}

			if (TransactionViewOption == TransactionViewOption.CurrentPrevious) {
				if (textBox.Name == "YtdColumn1Header" || textBox.Name == "YtdColumn1" || textBox.Name == "YtdColumn1Total") {
					textBox.Left = Unit.Cm(textBox.Left.Value - 6.5);
					textBox.Width = Unit.Cm(textBox.Width.Value + 2);
				}
				else if (textBox.Name == "YtdColumn2Header" || textBox.Name == "YtdColumn2" || textBox.Name == "YtdColumn2Total") {
					textBox.Left = Unit.Cm(textBox.Left.Value - 4.5);
					textBox.Width = Unit.Cm(textBox.Width.Value + 2);
				}
				else if (textBox.Name == "YtdColumn3Header" || textBox.Name == "YtdColumn3" || textBox.Name == "YtdColumn3Total") {
					textBox.Left = Unit.Cm(textBox.Left.Value - 2.5);
					textBox.Width = Unit.Cm(textBox.Width.Value + 2);
				}
				else if (textBox.Name == "YtdVariancePercentHeader" || textBox.Name == "YtdVariancePercent" || textBox.Name == "YtdVariancePercentTotal") {
					textBox.Left = Unit.Cm(textBox.Left.Value - .5);
					textBox.Width = Unit.Cm(textBox.Width.Value + .5);
				}
			}

			if (textBox.Name == "YtdColumn1" || textBox.Name == "YtdColumn2" || textBox.Name == "YtdColumn3" || textBox.Name == "YtdColumn1Total" || textBox.Name == "YtdColumn2Total" || textBox.Name == "YtdColumn3Total")
				FormatValue(sender, textBox);
		}

		private void FormatTextBox(object sender, Telerik.Reporting.Processing.TextBox textBox = null) {
			if (textBox == null)
				textBox = (Telerik.Reporting.Processing.TextBox)sender;

			if (TransactionViewOption == TransactionViewOption.CurrentPrevious)
				textBox.Visible = false;
		}

		private void FormatValue(object sender, Telerik.Reporting.Processing.TextBox textBox = null) {
			if (textBox == null)
				textBox = (Telerik.Reporting.Processing.TextBox)sender;

			if (textBox.Value == null)
				return;

			decimal value = decimal.Parse(textBox.Value.ToString());

			switch (ReportSign) {
				default:
					textBox.Value = string.Format("{0:c2}", value);
					break;
				case ReportSign.Bracket:
					if (value < 0)
						textBox.Value = string.Format("({0:c2})", Math.Abs(value));

					break;
				case ReportSign.Debit:
					if (value > 0) {
						textBox.Value = string.Format("{0:c2} Dr", Math.Abs(value));
					}
					else if (value < 0) {
						textBox.Value = string.Format("{0:c2} Cr", Math.Abs(value));
					}

					break;
				case ReportSign.Credit:
					if (value < 0)
						textBox.Value = string.Format("{0:c2} Cr", Math.Abs(value));

					break;
			}
		}
	}
}