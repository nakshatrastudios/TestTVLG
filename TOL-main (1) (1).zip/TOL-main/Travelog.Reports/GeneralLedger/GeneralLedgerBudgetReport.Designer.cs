namespace Travelog.Reports.GeneralLedger {
	partial class GeneralLedgerBudgetReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.Drawing.FormattingRule formattingRule1 = new Telerik.Reporting.Drawing.FormattingRule();
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.ManagementReportHeaderSubReport1 = new Telerik.Reporting.SubReport();
			this.AccountCategoryHeader = new Telerik.Reporting.TextBox();
			this.CodeHeader = new Telerik.Reporting.TextBox();
			this.ChartOfAccountTypeHeader = new Telerik.Reporting.TextBox();
			this.NameHeader = new Telerik.Reporting.TextBox();
			this.ChartOfAccountTransactionTypeHeader = new Telerik.Reporting.TextBox();
			this.AltReportingCodeHeader = new Telerik.Reporting.TextBox();
			this.NoData = new Telerik.Reporting.TextBox();
			this.NameField = new Telerik.Reporting.TextBox();
			this.Code = new Telerik.Reporting.TextBox();
			this.ChartOfAccountTypeDescription = new Telerik.Reporting.TextBox();
			this.AccountCategory = new Telerik.Reporting.TextBox();
			this.ChartOfAccountTransactionType = new Telerik.Reporting.TextBox();
			this.AltReportingCode = new Telerik.Reporting.TextBox();
			this.Period06 = new Telerik.Reporting.TextBox();
			this.Period08 = new Telerik.Reporting.TextBox();
			this.Period11 = new Telerik.Reporting.TextBox();
			this.Period02 = new Telerik.Reporting.TextBox();
			this.Period07 = new Telerik.Reporting.TextBox();
			this.Row1Value01 = new Telerik.Reporting.TextBox();
			this.Row1Value02 = new Telerik.Reporting.TextBox();
			this.Row1Value03 = new Telerik.Reporting.TextBox();
			this.Row1Value04 = new Telerik.Reporting.TextBox();
			this.Row1Value05 = new Telerik.Reporting.TextBox();
			this.Row1Value06 = new Telerik.Reporting.TextBox();
			this.Row1Value07 = new Telerik.Reporting.TextBox();
			this.Period04 = new Telerik.Reporting.TextBox();
			this.Period01 = new Telerik.Reporting.TextBox();
			this.Row1Value08 = new Telerik.Reporting.TextBox();
			this.Row1Value11 = new Telerik.Reporting.TextBox();
			this.Period10 = new Telerik.Reporting.TextBox();
			this.Period05 = new Telerik.Reporting.TextBox();
			this.Row1Value09 = new Telerik.Reporting.TextBox();
			this.Period09 = new Telerik.Reporting.TextBox();
			this.Row1Value12 = new Telerik.Reporting.TextBox();
			this.Period12 = new Telerik.Reporting.TextBox();
			this.Period03 = new Telerik.Reporting.TextBox();
			this.Row1Value10 = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
			this.Pages = new Telerik.Reporting.TextBox();
			this.CreationTime = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			this.GroupFooterSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupFooterSection1.Style.Visible = false;
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Count(1) = 0, \"None\", \"Solid\")"));
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(2.2D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ManagementReportHeaderSubReport1,
            this.AccountCategoryHeader,
            this.CodeHeader,
            this.ChartOfAccountTypeHeader,
            this.NameHeader,
            this.ChartOfAccountTransactionTypeHeader,
            this.AltReportingCodeHeader,
            this.NoData});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = true;
			this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupHeaderSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// ManagementReportHeaderSubReport1
			// 
			this.ManagementReportHeaderSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ManagementReportHeaderSubReport1.Name = "ManagementReportHeaderSubReport1";
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerName", "= Parameters.customerName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportName", "= Parameters.reportName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportDate", "= Parameters.reportDate.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("headerContent", "= Parameters.headerContent.Value"));
			typeReportSource1.TypeName = "Travelog.Reports.Common.ManagementReportHeaderSubReport1, Travelog.Reports, Versi" +
    "on=1.0.0.0, Culture=neutral, PublicKeyToken=null";
			this.ManagementReportHeaderSubReport1.ReportSource = typeReportSource1;
			this.ManagementReportHeaderSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ManagementReportHeaderSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// AccountCategoryHeader
			// 
			this.AccountCategoryHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.5D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.AccountCategoryHeader.Name = "AccountCategoryHeader";
			this.AccountCategoryHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccountCategoryHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AccountCategoryHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccountCategoryHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AccountCategoryHeader.Style.Font.Bold = true;
			this.AccountCategoryHeader.Style.Font.Name = "Calibri";
			this.AccountCategoryHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AccountCategoryHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AccountCategoryHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AccountCategoryHeader.StyleName = "Normal.TableHeader";
			this.AccountCategoryHeader.Value = "Category";
			// 
			// CodeHeader
			// 
			this.CodeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.CodeHeader.Name = "CodeHeader";
			this.CodeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CodeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CodeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CodeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CodeHeader.Style.Font.Bold = true;
			this.CodeHeader.Style.Font.Name = "Calibri";
			this.CodeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CodeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CodeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CodeHeader.StyleName = "Normal.TableHeader";
			this.CodeHeader.Value = "Code";
			// 
			// ChartOfAccountTypeHeader
			// 
			this.ChartOfAccountTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ChartOfAccountTypeHeader.Name = "ChartOfAccountTypeHeader";
			this.ChartOfAccountTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ChartOfAccountTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountTypeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ChartOfAccountTypeHeader.Style.Font.Bold = true;
			this.ChartOfAccountTypeHeader.Style.Font.Name = "Calibri";
			this.ChartOfAccountTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ChartOfAccountTypeHeader.StyleName = "Normal.TableHeader";
			this.ChartOfAccountTypeHeader.Value = "Account Type";
			// 
			// NameHeader
			// 
			this.NameHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.NameHeader.Name = "NameHeader";
			this.NameHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NameHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.NameHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NameHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.NameHeader.Style.Font.Bold = true;
			this.NameHeader.Style.Font.Name = "Calibri";
			this.NameHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NameHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NameHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.NameHeader.StyleName = "Normal.TableHeader";
			this.NameHeader.Value = "Account";
			// 
			// ChartOfAccountTransactionTypeHeader
			// 
			this.ChartOfAccountTransactionTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(21.4D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ChartOfAccountTransactionTypeHeader.Name = "ChartOfAccountTransactionTypeHeader";
			this.ChartOfAccountTransactionTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountTransactionTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ChartOfAccountTransactionTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountTransactionTypeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ChartOfAccountTransactionTypeHeader.Style.Font.Bold = true;
			this.ChartOfAccountTransactionTypeHeader.Style.Font.Name = "Calibri";
			this.ChartOfAccountTransactionTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountTransactionTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountTransactionTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ChartOfAccountTransactionTypeHeader.StyleName = "Normal.TableHeader";
			this.ChartOfAccountTransactionTypeHeader.Value = "Transaction Type";
			// 
			// AltReportingCodeHeader
			// 
			this.AltReportingCodeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.AltReportingCodeHeader.Name = "AltReportingCodeHeader";
			this.AltReportingCodeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AltReportingCodeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AltReportingCodeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AltReportingCodeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AltReportingCodeHeader.Style.Font.Bold = true;
			this.AltReportingCodeHeader.Style.Font.Name = "Calibri";
			this.AltReportingCodeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AltReportingCodeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AltReportingCodeHeader.StyleName = "Normal.TableHeader";
			this.AltReportingCodeHeader.Value = "Alt Code";
			// 
			// NoData
			// 
			formattingRule1.Filters.Add(new Telerik.Reporting.Filter("= Count(1)", Telerik.Reporting.FilterOperator.Equal, "0"));
			formattingRule1.Style.Visible = true;
			this.NoData.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule1});
			this.NoData.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.6D));
			this.NoData.Name = "NoData";
			this.NoData.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NoData.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.NoData.Style.BorderColor.Default = System.Drawing.Color.WhiteSmoke;
			this.NoData.Style.Font.Name = "Calibri";
			this.NoData.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NoData.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
			this.NoData.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.NoData.Style.Visible = false;
			this.NoData.StyleName = "Normal.TableHeader";
			this.NoData.Value = "NO DATA AVAILABLE";
			// 
			// NameField
			// 
			this.NameField.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.NameField.Name = "NameField";
			this.NameField.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(11.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NameField.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NameField.Style.Font.Name = "Calibri";
			this.NameField.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NameField.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NameField.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NameField.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.NameField.StyleName = "Normal.TableBody";
			this.NameField.TextWrap = false;
			this.NameField.Value = "= Fields.Name";
			// 
			// Code
			// 
			this.Code.CanShrink = true;
			this.Code.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Code.Name = "Code";
			this.Code.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Code.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Code.Style.Font.Name = "Calibri";
			this.Code.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Code.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Code.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Code.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Code.StyleName = "Normal.TableBody";
			this.Code.TextWrap = false;
			this.Code.Value = "= Fields.Code";
			// 
			// ChartOfAccountTypeDescription
			// 
			this.ChartOfAccountTypeDescription.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ChartOfAccountTypeDescription.Name = "ChartOfAccountTypeDescription";
			this.ChartOfAccountTypeDescription.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountTypeDescription.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountTypeDescription.Style.Font.Name = "Calibri";
			this.ChartOfAccountTypeDescription.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountTypeDescription.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ChartOfAccountTypeDescription.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountTypeDescription.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ChartOfAccountTypeDescription.StyleName = "Normal.TableBody";
			this.ChartOfAccountTypeDescription.TextWrap = false;
			this.ChartOfAccountTypeDescription.Value = "= Fields.ChartOfAccountTypeDescription";
			// 
			// AccountCategory
			// 
			this.AccountCategory.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AccountCategory.Name = "AccountCategory";
			this.AccountCategory.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccountCategory.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccountCategory.Style.Font.Name = "Calibri";
			this.AccountCategory.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AccountCategory.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AccountCategory.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AccountCategory.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AccountCategory.StyleName = "Normal.TableBody";
			this.AccountCategory.TextWrap = false;
			this.AccountCategory.Value = "= Fields.AccountCategory";
			// 
			// ChartOfAccountTransactionType
			// 
			this.ChartOfAccountTransactionType.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(21.4D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ChartOfAccountTransactionType.Name = "ChartOfAccountTransactionType";
			this.ChartOfAccountTransactionType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountTransactionType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountTransactionType.Style.Font.Name = "Calibri";
			this.ChartOfAccountTransactionType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountTransactionType.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ChartOfAccountTransactionType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountTransactionType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ChartOfAccountTransactionType.StyleName = "Normal.TableBody";
			this.ChartOfAccountTransactionType.TextWrap = false;
			this.ChartOfAccountTransactionType.Value = "= Fields.ChartOfAccountTransactionType";
			// 
			// AltReportingCode
			// 
			this.AltReportingCode.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AltReportingCode.Name = "AltReportingCode";
			this.AltReportingCode.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AltReportingCode.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AltReportingCode.Style.Font.Name = "Calibri";
			this.AltReportingCode.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AltReportingCode.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AltReportingCode.StyleName = "Normal.TableBody";
			this.AltReportingCode.TextWrap = false;
			this.AltReportingCode.Value = "= Fields.AltReportingCode";
			// 
			// Period06
			// 
			this.Period06.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period06.Name = "Period06";
			this.Period06.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period06.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period06.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period06.Style.Font.Name = "Calibri";
			this.Period06.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period06.Style.LineColor = System.Drawing.Color.Silver;
			this.Period06.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period06.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period06.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period06.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period06.StyleName = "Normal.TableHeader";
			this.Period06.TextWrap = false;
			this.Period06.Value = "= Fields.Period06";
			// 
			// Period08
			// 
			this.Period08.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.2D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period08.Name = "Period08";
			this.Period08.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period08.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period08.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period08.Style.Font.Name = "Calibri";
			this.Period08.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period08.Style.LineColor = System.Drawing.Color.Silver;
			this.Period08.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period08.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period08.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period08.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period08.StyleName = "Normal.TableHeader";
			this.Period08.TextWrap = false;
			this.Period08.Value = "= Fields.Period08";
			// 
			// Period11
			// 
			this.Period11.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period11.Name = "Period11";
			this.Period11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period11.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period11.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period11.Style.Font.Name = "Calibri";
			this.Period11.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period11.Style.LineColor = System.Drawing.Color.Silver;
			this.Period11.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period11.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period11.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period11.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period11.StyleName = "Normal.TableHeader";
			this.Period11.TextWrap = false;
			this.Period11.Value = "= Fields.Period11";
			// 
			// Period02
			// 
			this.Period02.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period02.Name = "Period02";
			this.Period02.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period02.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period02.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period02.Style.Font.Name = "Calibri";
			this.Period02.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period02.Style.LineColor = System.Drawing.Color.Silver;
			this.Period02.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period02.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period02.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period02.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period02.StyleName = "Normal.TableHeader";
			this.Period02.TextWrap = false;
			this.Period02.Value = "= Fields.Period02";
			// 
			// Period07
			// 
			this.Period07.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period07.Name = "Period07";
			this.Period07.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period07.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period07.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period07.Style.Font.Name = "Calibri";
			this.Period07.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period07.Style.LineColor = System.Drawing.Color.Silver;
			this.Period07.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period07.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period07.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period07.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period07.StyleName = "Normal.TableHeader";
			this.Period07.TextWrap = false;
			this.Period07.Value = "= Fields.Period07";
			// 
			// Row1Value01
			// 
			this.Row1Value01.Format = "{0:C2}";
			this.Row1Value01.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value01.Name = "Row1Value01";
			this.Row1Value01.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value01.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value01.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value01.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value01.Style.Font.Name = "Calibri";
			this.Row1Value01.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value01.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value01.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value01.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value01.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value01.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value01.StyleName = "Normal.TableBody";
			this.Row1Value01.TextWrap = false;
			this.Row1Value01.Value = "= Fields.Row1Value01";
			// 
			// Row1Value02
			// 
			this.Row1Value02.Format = "{0:C2}";
			this.Row1Value02.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value02.Name = "Row1Value02";
			this.Row1Value02.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value02.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value02.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value02.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value02.Style.Font.Name = "Calibri";
			this.Row1Value02.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value02.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value02.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value02.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value02.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value02.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value02.StyleName = "Normal.TableBody";
			this.Row1Value02.TextWrap = false;
			this.Row1Value02.Value = "= Fields.Row1Value02";
			// 
			// Row1Value03
			// 
			this.Row1Value03.Format = "{0:C2}";
			this.Row1Value03.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.7D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value03.Name = "Row1Value03";
			this.Row1Value03.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value03.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value03.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value03.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value03.Style.Font.Name = "Calibri";
			this.Row1Value03.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value03.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value03.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value03.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value03.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value03.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value03.StyleName = "Normal.TableBody";
			this.Row1Value03.TextWrap = false;
			this.Row1Value03.Value = "= Fields.Row1Value03";
			// 
			// Row1Value04
			// 
			this.Row1Value04.Format = "{0:C2}";
			this.Row1Value04.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value04.Name = "Row1Value04";
			this.Row1Value04.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value04.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value04.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value04.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value04.Style.Font.Name = "Calibri";
			this.Row1Value04.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value04.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value04.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value04.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value04.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value04.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value04.StyleName = "Normal.TableBody";
			this.Row1Value04.TextWrap = false;
			this.Row1Value04.Value = "= Fields.Row1Value04";
			// 
			// Row1Value05
			// 
			this.Row1Value05.Format = "{0:C2}";
			this.Row1Value05.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.3D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value05.Name = "Row1Value05";
			this.Row1Value05.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value05.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value05.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value05.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value05.Style.Font.Name = "Calibri";
			this.Row1Value05.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value05.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value05.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value05.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value05.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value05.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value05.StyleName = "Normal.TableBody";
			this.Row1Value05.TextWrap = false;
			this.Row1Value05.Value = "= Fields.Row1Value05";
			// 
			// Row1Value06
			// 
			this.Row1Value06.Format = "{0:C2}";
			this.Row1Value06.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.6D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value06.Name = "Row1Value06";
			this.Row1Value06.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value06.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value06.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value06.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value06.Style.Font.Name = "Calibri";
			this.Row1Value06.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value06.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value06.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value06.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value06.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value06.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value06.StyleName = "Normal.TableBody";
			this.Row1Value06.TextWrap = false;
			this.Row1Value06.Value = "= Fields.Row1Value06";
			// 
			// Row1Value07
			// 
			this.Row1Value07.Format = "{0:C2}";
			this.Row1Value07.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(13.9D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value07.Name = "Row1Value07";
			this.Row1Value07.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value07.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value07.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value07.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value07.Style.Font.Name = "Calibri";
			this.Row1Value07.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value07.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value07.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value07.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value07.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value07.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value07.StyleName = "Normal.TableBody";
			this.Row1Value07.TextWrap = false;
			this.Row1Value07.Value = "= Fields.Row1Value07";
			// 
			// Period04
			// 
			this.Period04.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period04.Name = "Period04";
			this.Period04.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period04.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period04.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period04.Style.Font.Name = "Calibri";
			this.Period04.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period04.Style.LineColor = System.Drawing.Color.Silver;
			this.Period04.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period04.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period04.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period04.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period04.StyleName = "Normal.TableHeader";
			this.Period04.TextWrap = false;
			this.Period04.Value = "= Fields.Period04";
			// 
			// Period01
			// 
			this.Period01.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period01.Name = "Period01";
			this.Period01.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.4D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period01.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period01.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period01.Style.Font.Name = "Calibri";
			this.Period01.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period01.Style.LineColor = System.Drawing.Color.Silver;
			this.Period01.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period01.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period01.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period01.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period01.StyleName = "Normal.TableHeader";
			this.Period01.TextWrap = false;
			this.Period01.Value = "= Fields.Period01";
			// 
			// Row1Value08
			// 
			this.Row1Value08.Format = "{0:C2}";
			this.Row1Value08.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.2D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value08.Name = "Row1Value08";
			this.Row1Value08.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value08.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value08.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value08.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value08.Style.Font.Name = "Calibri";
			this.Row1Value08.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value08.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value08.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value08.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value08.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value08.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value08.StyleName = "Normal.TableBody";
			this.Row1Value08.TextWrap = false;
			this.Row1Value08.Value = "= Fields.Row1Value08";
			// 
			// Row1Value11
			// 
			this.Row1Value11.Format = "{0:C2}";
			this.Row1Value11.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.1D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value11.Name = "Row1Value11";
			this.Row1Value11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value11.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value11.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value11.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value11.Style.Font.Name = "Calibri";
			this.Row1Value11.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value11.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value11.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value11.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value11.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value11.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value11.StyleName = "Normal.TableBody";
			this.Row1Value11.TextWrap = false;
			this.Row1Value11.Value = "= Fields.Row1Value11";
			// 
			// Period10
			// 
			this.Period10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period10.Name = "Period10";
			this.Period10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period10.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period10.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period10.Style.Font.Name = "Calibri";
			this.Period10.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period10.Style.LineColor = System.Drawing.Color.Silver;
			this.Period10.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period10.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period10.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period10.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period10.StyleName = "Normal.TableHeader";
			this.Period10.TextWrap = false;
			this.Period10.Value = "= Fields.Period10";
			// 
			// Period05
			// 
			this.Period05.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period05.Name = "Period05";
			this.Period05.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period05.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period05.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period05.Style.Font.Name = "Calibri";
			this.Period05.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period05.Style.LineColor = System.Drawing.Color.Silver;
			this.Period05.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period05.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period05.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period05.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period05.StyleName = "Normal.TableHeader";
			this.Period05.TextWrap = false;
			this.Period05.Value = "= Fields.Period05";
			// 
			// Row1Value09
			// 
			this.Row1Value09.Format = "{0:C2}";
			this.Row1Value09.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.5D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value09.Name = "Row1Value09";
			this.Row1Value09.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value09.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value09.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value09.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value09.Style.Font.Name = "Calibri";
			this.Row1Value09.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value09.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value09.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value09.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value09.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value09.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value09.StyleName = "Normal.TableBody";
			this.Row1Value09.TextWrap = false;
			this.Row1Value09.Value = "= Fields.Row1Value09";
			// 
			// Period09
			// 
			this.Period09.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period09.Name = "Period09";
			this.Period09.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period09.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period09.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period09.Style.Font.Name = "Calibri";
			this.Period09.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period09.Style.LineColor = System.Drawing.Color.Silver;
			this.Period09.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period09.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period09.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period09.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period09.StyleName = "Normal.TableHeader";
			this.Period09.TextWrap = false;
			this.Period09.Value = "= Fields.Period09";
			// 
			// Row1Value12
			// 
			this.Row1Value12.Format = "{0:C2}";
			this.Row1Value12.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.4D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value12.Name = "Row1Value12";
			this.Row1Value12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value12.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value12.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value12.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value12.Style.Font.Name = "Calibri";
			this.Row1Value12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value12.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value12.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value12.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value12.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value12.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value12.StyleName = "Normal.TableBody";
			this.Row1Value12.TextWrap = false;
			this.Row1Value12.Value = "= Fields.Row1Value12";
			// 
			// Period12
			// 
			this.Period12.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period12.Name = "Period12";
			this.Period12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period12.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period12.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period12.Style.Font.Name = "Calibri";
			this.Period12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period12.Style.LineColor = System.Drawing.Color.Silver;
			this.Period12.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period12.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period12.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period12.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period12.StyleName = "Normal.TableHeader";
			this.Period12.TextWrap = false;
			this.Period12.Value = "= Fields.Period12";
			// 
			// Period03
			// 
			this.Period03.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Period03.Name = "Period03";
			this.Period03.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period03.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period03.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period03.Style.Font.Name = "Calibri";
			this.Period03.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period03.Style.LineColor = System.Drawing.Color.Silver;
			this.Period03.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period03.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period03.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period03.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period03.StyleName = "Normal.TableHeader";
			this.Period03.TextWrap = false;
			this.Period03.Value = "= Fields.Period03";
			// 
			// Row1Value10
			// 
			this.Row1Value10.Format = "{0:C2}";
			this.Row1Value10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.8D), Telerik.Reporting.Drawing.Unit.Cm(1.05D));
			this.Row1Value10.Name = "Row1Value10";
			this.Row1Value10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value10.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value10.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value10.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value10.Style.Font.Name = "Calibri";
			this.Row1Value10.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value10.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value10.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value10.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value10.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value10.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value10.StyleName = "Normal.TableBody";
			this.Row1Value10.TextWrap = false;
			this.Row1Value10.Value = "= Fields.Row1Value10";
			// 
			// Detail
			// 
			this.Detail.CanShrink = true;
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(1.5D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Period03,
            this.Period08,
            this.Period11,
            this.Period02,
            this.Period07,
            this.Row1Value01,
            this.Row1Value02,
            this.Row1Value03,
            this.Row1Value04,
            this.Row1Value05,
            this.Row1Value06,
            this.Row1Value07,
            this.Period04,
            this.Period01,
            this.Row1Value08,
            this.Row1Value11,
            this.Period10,
            this.Period05,
            this.Row1Value09,
            this.Period09,
            this.Row1Value12,
            this.Period12,
            this.Period06,
            this.Row1Value10,
            this.NameField,
            this.Code,
            this.ChartOfAccountTypeDescription,
            this.AccountCategory,
            this.ChartOfAccountTransactionType,
            this.AltReportingCode});
			this.Detail.KeepTogether = false;
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// PageFooterSection
			// 
			this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
			this.PageFooterSection.Name = "PageFooterSection";
			// 
			// Pages
			// 
			this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.7D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Name = "Pages";
			this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Style.Color = System.Drawing.Color.DarkGray;
			this.Pages.Style.Font.Name = "Calibri";
			this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Pages.Value = "= \"Page \" + PageNumber";
			// 
			// CreationTime
			// 
			this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Name = "CreationTime";
			this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
			this.CreationTime.Style.Font.Name = "Calibri";
			this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy HH:mm}\", Parame" +
    "ters.creationTime.Value)";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "GeneralLedgerBudgetReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.GeneralLedger.GeneralLedgerDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("userRoleId", typeof(string), "= Parameters.userRoleId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("fiscalYearStartDate", typeof(System.DateTime), "= Parameters.fiscalYearStartDate.Value"));
			// 
			// GeneralLedgerBudgetReport
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail,
            this.PageFooterSection});
			this.Name = "GeneralLedgerBudgetReport";
			this.PageSettings.Landscape = true;
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "customerId";
			reportParameter2.Name = "agencyId";
			reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter3.Name = "userRoleId";
			reportParameter4.Name = "customerName";
			reportParameter5.Name = "reportName";
			reportParameter6.Name = "reportDate";
			reportParameter7.Name = "headerContent";
			reportParameter8.Name = "creationUser";
			reportParameter9.Name = "creationTime";
			reportParameter9.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter10.Name = "fiscalYearStartDate";
			reportParameter10.Type = Telerik.Reporting.ReportParameterType.DateTime;
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.ReportParameters.Add(reportParameter9);
			this.ReportParameters.Add(reportParameter10);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(27.7D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.SubReport ManagementReportHeaderSubReport1;
		private Telerik.Reporting.TextBox NameHeader;
		private Telerik.Reporting.TextBox CodeHeader;
		private Telerik.Reporting.TextBox Code;
		private Telerik.Reporting.TextBox NameField;
		private Telerik.Reporting.TextBox ChartOfAccountTypeHeader;
		private Telerik.Reporting.TextBox ChartOfAccountTypeDescription;
		private Telerik.Reporting.TextBox AccountCategory;
		private Telerik.Reporting.TextBox AccountCategoryHeader;
		private Telerik.Reporting.TextBox ChartOfAccountTransactionType;
		private Telerik.Reporting.TextBox ChartOfAccountTransactionTypeHeader;
		private Telerik.Reporting.TextBox Period04;
		private Telerik.Reporting.TextBox Period08;
		private Telerik.Reporting.TextBox Period11;
		private Telerik.Reporting.TextBox Period02;
		private Telerik.Reporting.TextBox Period07;
		private Telerik.Reporting.TextBox Row1Value01;
		private Telerik.Reporting.TextBox Row1Value02;
		private Telerik.Reporting.TextBox Row1Value03;
		private Telerik.Reporting.TextBox Row1Value04;
		private Telerik.Reporting.TextBox Row1Value05;
		private Telerik.Reporting.TextBox Row1Value06;
		private Telerik.Reporting.TextBox Row1Value07;
		private Telerik.Reporting.TextBox Period06;
		private Telerik.Reporting.TextBox Period01;
		private Telerik.Reporting.TextBox Row1Value08;
		private Telerik.Reporting.TextBox Row1Value11;
		private Telerik.Reporting.TextBox Period10;
		private Telerik.Reporting.TextBox Period05;
		private Telerik.Reporting.TextBox Row1Value09;
		private Telerik.Reporting.TextBox Period09;
		private Telerik.Reporting.TextBox Row1Value12;
		private Telerik.Reporting.TextBox Period12;
		private Telerik.Reporting.TextBox Period03;
		private Telerik.Reporting.TextBox Row1Value10;
		private Telerik.Reporting.TextBox AltReportingCodeHeader;
		private Telerik.Reporting.TextBox AltReportingCode;
		private Telerik.Reporting.TextBox NoData;
	}
}