namespace Travelog.Reports.GeneralLedger {
	partial class GeneralLedgerReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
            Telerik.Reporting.Drawing.FormattingRule formattingRule1 = new Telerik.Reporting.Drawing.FormattingRule();
            Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
            Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter11 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter12 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter13 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter14 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter15 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter16 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter17 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter18 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter19 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter20 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter21 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter22 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter23 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter24 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter25 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter26 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter27 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter28 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter29 = new Telerik.Reporting.ReportParameter();
            Telerik.Reporting.ReportParameter reportParameter30 = new Telerik.Reporting.ReportParameter();
            this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
            this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
            this.ManagementReportHeaderSubReport1 = new Telerik.Reporting.SubReport();
            this.YtdColumn1Header = new Telerik.Reporting.TextBox();
            this.NameHeader = new Telerik.Reporting.TextBox();
            this.PeriodColumn1Header = new Telerik.Reporting.TextBox();
            this.PeriodColumn2Header = new Telerik.Reporting.TextBox();
            this.PeriodColumn3Header = new Telerik.Reporting.TextBox();
            this.CodeHeader = new Telerik.Reporting.TextBox();
            this.YtdColumn2Header = new Telerik.Reporting.TextBox();
            this.YtdColumn3Header = new Telerik.Reporting.TextBox();
            this.YtdVariancePercentHeader = new Telerik.Reporting.TextBox();
            this.PeriodVariancePercentHeader = new Telerik.Reporting.TextBox();
            this.NoData = new Telerik.Reporting.TextBox();
            this.Detail = new Telerik.Reporting.DetailSection();
            this.Code = new Telerik.Reporting.TextBox();
            this.NameField = new Telerik.Reporting.TextBox();
            this.PeriodColumn1 = new Telerik.Reporting.TextBox();
            this.PeriodColumn2 = new Telerik.Reporting.TextBox();
            this.PeriodColumn3 = new Telerik.Reporting.TextBox();
            this.YtdColumn1 = new Telerik.Reporting.TextBox();
            this.YtdColumn2 = new Telerik.Reporting.TextBox();
            this.YtdColumn3 = new Telerik.Reporting.TextBox();
            this.YtdVariancePercent = new Telerik.Reporting.TextBox();
            this.PeriodVariancePercent = new Telerik.Reporting.TextBox();
            this.Description = new Telerik.Reporting.TextBox();
            this.Header = new Telerik.Reporting.TextBox();
            this.TotalsLabel = new Telerik.Reporting.TextBox();
            this.PeriodColumn1Total = new Telerik.Reporting.TextBox();
            this.PeriodColumn2Total = new Telerik.Reporting.TextBox();
            this.PeriodColumn3Total = new Telerik.Reporting.TextBox();
            this.YtdColumn1Total = new Telerik.Reporting.TextBox();
            this.YtdColumn2Total = new Telerik.Reporting.TextBox();
            this.YtdColumn3Total = new Telerik.Reporting.TextBox();
            this.PeriodVariancePercentTotal = new Telerik.Reporting.TextBox();
            this.YtdVariancePercentTotal = new Telerik.Reporting.TextBox();
            this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
            this.Pages = new Telerik.Reporting.TextBox();
            this.CreationTime = new Telerik.Reporting.TextBox();
            this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // GroupFooterSection1
            // 
            this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.GroupFooterSection1.Name = "GroupFooterSection1";
            this.GroupFooterSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.GroupFooterSection1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.GroupFooterSection1.Style.Visible = false;
            // 
            // GroupHeaderSection1
            // 
            this.GroupHeaderSection1.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Count(1) = 0, \"None\", \"Solid\")"));
            this.GroupHeaderSection1.CanShrink = true;
            this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(2.2D);
            this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ManagementReportHeaderSubReport1,
            this.YtdColumn1Header,
            this.NameHeader,
            this.PeriodColumn1Header,
            this.PeriodColumn2Header,
            this.PeriodColumn3Header,
            this.CodeHeader,
            this.YtdColumn2Header,
            this.YtdColumn3Header,
            this.YtdVariancePercentHeader,
            this.PeriodVariancePercentHeader,
            this.NoData});
            this.GroupHeaderSection1.Name = "GroupHeaderSection1";
            this.GroupHeaderSection1.PrintOnEveryPage = true;
            this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.GroupHeaderSection1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.GroupHeaderSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            // 
            // ManagementReportHeaderSubReport1
            // 
            this.ManagementReportHeaderSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.ManagementReportHeaderSubReport1.Name = "ManagementReportHeaderSubReport1";
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerName", "= Parameters.customerName.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportName", "= Parameters.reportName.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportDate", "= Parameters.reportDate.Value"));
            typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("headerContent", "= Parameters.headerContent.Value"));
            typeReportSource1.TypeName = "Travelog.Reports.Common.ManagementReportHeaderSubReport1, Travelog.Reports, Versi" +
    "on=1.0.0.0, Culture=neutral, PublicKeyToken=null";
            this.ManagementReportHeaderSubReport1.ReportSource = typeReportSource1;
            this.ManagementReportHeaderSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.ManagementReportHeaderSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            // 
            // YtdColumn1Header
            // 
            this.YtdColumn1Header.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"19.0cm\", \"18.0cm\")"));
            this.YtdColumn1Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17.999D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.YtdColumn1Header.Name = "YtdColumn1Header";
            this.YtdColumn1Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdColumn1Header.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.YtdColumn1Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdColumn1Header.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.YtdColumn1Header.Style.Font.Bold = true;
            this.YtdColumn1Header.Style.Font.Name = "Calibri";
            this.YtdColumn1Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdColumn1Header.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.YtdColumn1Header.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.YtdColumn1Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.YtdColumn1Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdColumn1Header.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdColumn1Header.StyleName = "Normal.TableHeader";
            this.YtdColumn1Header.Value = "= Parameters.ytdColumn1Header.Value";
            this.YtdColumn1Header.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // NameHeader
            // 
            this.NameHeader.Bindings.Add(new Telerik.Reporting.Binding("Width", "= IIf(Parameters.transactionViewOptionId.Value=3, \"8.5cm\", \"6.5cm\")"));
            this.NameHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.8D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.NameHeader.Name = "NameHeader";
            this.NameHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.NameHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.NameHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.NameHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.NameHeader.Style.Font.Bold = true;
            this.NameHeader.Style.Font.Name = "Calibri";
            this.NameHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.NameHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.NameHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.NameHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.NameHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.NameHeader.StyleName = "Normal.TableHeader";
            this.NameHeader.Value = "Account";
            this.NameHeader.ItemDataBound += new System.EventHandler(this.Name_ItemDataBound);
            // 
            // PeriodColumn1Header
            // 
            this.PeriodColumn1Header.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"10.3cm\", \"8.3cm\")"));
            this.PeriodColumn1Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(8.3D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PeriodColumn1Header.Name = "PeriodColumn1Header";
            this.PeriodColumn1Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodColumn1Header.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PeriodColumn1Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodColumn1Header.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PeriodColumn1Header.Style.Font.Bold = true;
            this.PeriodColumn1Header.Style.Font.Name = "Calibri";
            this.PeriodColumn1Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodColumn1Header.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.PeriodColumn1Header.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodColumn1Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodColumn1Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodColumn1Header.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodColumn1Header.StyleName = "Normal.TableHeader";
            this.PeriodColumn1Header.Value = "= Parameters.periodColumn1Header.Value";
            this.PeriodColumn1Header.ItemDataBound += new System.EventHandler(this.PeriodColumnHeader_ItemDataBound);
            // 
            // PeriodColumn2Header
            // 
            this.PeriodColumn2Header.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"13.2cm\", \"11.2cm\")"));
            this.PeriodColumn2Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.2D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PeriodColumn2Header.Name = "PeriodColumn2Header";
            this.PeriodColumn2Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodColumn2Header.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PeriodColumn2Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodColumn2Header.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PeriodColumn2Header.Style.Font.Bold = true;
            this.PeriodColumn2Header.Style.Font.Name = "Calibri";
            this.PeriodColumn2Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodColumn2Header.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.PeriodColumn2Header.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodColumn2Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodColumn2Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodColumn2Header.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodColumn2Header.StyleName = "Normal.TableHeader";
            this.PeriodColumn2Header.Value = "= Parameters.periodColumn2Header.Value";
            this.PeriodColumn2Header.ItemDataBound += new System.EventHandler(this.PeriodColumnHeader_ItemDataBound);
            // 
            // PeriodColumn3Header
            // 
            this.PeriodColumn3Header.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"16.1cm\", \"14.1cm\")"));
            this.PeriodColumn3Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PeriodColumn3Header.Name = "PeriodColumn3Header";
            this.PeriodColumn3Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodColumn3Header.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PeriodColumn3Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodColumn3Header.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PeriodColumn3Header.Style.Font.Bold = true;
            this.PeriodColumn3Header.Style.Font.Name = "Calibri";
            this.PeriodColumn3Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodColumn3Header.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.PeriodColumn3Header.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodColumn3Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodColumn3Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodColumn3Header.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodColumn3Header.StyleName = "Normal.TableHeader";
            this.PeriodColumn3Header.Value = "= Parameters.periodColumn3Header.Value";
            this.PeriodColumn3Header.ItemDataBound += new System.EventHandler(this.PeriodColumnHeader_ItemDataBound);
            // 
            // CodeHeader
            // 
            this.CodeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.CodeHeader.Name = "CodeHeader";
            this.CodeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.CodeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.CodeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.CodeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.CodeHeader.Style.Font.Bold = true;
            this.CodeHeader.Style.Font.Name = "Calibri";
            this.CodeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CodeHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CodeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.CodeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CodeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.CodeHeader.StyleName = "Normal.TableHeader";
            this.CodeHeader.Value = "Code";
            // 
            // YtdColumn2Header
            // 
            this.YtdColumn2Header.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"21.9cm\", \"20.9cm\")"));
            this.YtdColumn2Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.9D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.YtdColumn2Header.Name = "YtdColumn2Header";
            this.YtdColumn2Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdColumn2Header.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.YtdColumn2Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdColumn2Header.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.YtdColumn2Header.Style.Font.Bold = true;
            this.YtdColumn2Header.Style.Font.Name = "Calibri";
            this.YtdColumn2Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdColumn2Header.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.YtdColumn2Header.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.YtdColumn2Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.YtdColumn2Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdColumn2Header.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdColumn2Header.StyleName = "Normal.TableHeader";
            this.YtdColumn2Header.Value = "= Parameters.ytdColumn2Header.Value";
            this.YtdColumn2Header.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // YtdColumn3Header
            // 
            this.YtdColumn3Header.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"24.8cm\", \"23.8cm\")"));
            this.YtdColumn3Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.8D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.YtdColumn3Header.Name = "YtdColumn3Header";
            this.YtdColumn3Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdColumn3Header.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.YtdColumn3Header.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdColumn3Header.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.YtdColumn3Header.Style.Font.Bold = true;
            this.YtdColumn3Header.Style.Font.Name = "Calibri";
            this.YtdColumn3Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdColumn3Header.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.YtdColumn3Header.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.YtdColumn3Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.YtdColumn3Header.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdColumn3Header.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdColumn3Header.StyleName = "Normal.TableHeader";
            this.YtdColumn3Header.Value = "= Parameters.ytdColumn3Header.Value";
            this.YtdColumn3Header.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // YtdVariancePercentHeader
            // 
            this.YtdVariancePercentHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(26.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.YtdVariancePercentHeader.Name = "YtdVariancePercentHeader";
            this.YtdVariancePercentHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdVariancePercentHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.YtdVariancePercentHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdVariancePercentHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.YtdVariancePercentHeader.Style.Font.Bold = true;
            this.YtdVariancePercentHeader.Style.Font.Name = "Calibri";
            this.YtdVariancePercentHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdVariancePercentHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.YtdVariancePercentHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.YtdVariancePercentHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdVariancePercentHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdVariancePercentHeader.StyleName = "Normal.TableHeader";
            this.YtdVariancePercentHeader.Value = "= IIf(Parameters.transactionViewOptionId.Value=3,Null,\"%\")";
            this.YtdVariancePercentHeader.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // PeriodVariancePercentHeader
            // 
            this.PeriodVariancePercentHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.999D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PeriodVariancePercentHeader.Name = "PeriodVariancePercentHeader";
            this.PeriodVariancePercentHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodVariancePercentHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
            this.PeriodVariancePercentHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodVariancePercentHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.PeriodVariancePercentHeader.Style.Font.Bold = true;
            this.PeriodVariancePercentHeader.Style.Font.Name = "Calibri";
            this.PeriodVariancePercentHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodVariancePercentHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodVariancePercentHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodVariancePercentHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodVariancePercentHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodVariancePercentHeader.StyleName = "Normal.TableHeader";
            this.PeriodVariancePercentHeader.Value = "= IIf(Parameters.transactionViewOptionId.Value=0 Or Parameters.transactionViewOpt" +
    "ionId.Value=3,Null,\"%\")";
            // 
            // NoData
            // 
            formattingRule1.Filters.Add(new Telerik.Reporting.Filter("= Count(1)", Telerik.Reporting.FilterOperator.Equal, "0"));
            formattingRule1.Style.Visible = true;
            this.NoData.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule1});
            this.NoData.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.6D));
            this.NoData.Name = "NoData";
            this.NoData.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.NoData.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.NoData.Style.BorderColor.Default = System.Drawing.Color.WhiteSmoke;
            this.NoData.Style.Font.Name = "Calibri";
            this.NoData.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.NoData.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.NoData.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.NoData.Style.Visible = false;
            this.NoData.StyleName = "Normal.TableHeader";
            this.NoData.Value = "NO DATA AVAILABLE";
            // 
            // Detail
            // 
            this.Detail.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.RowTypeId=1 Or Fields.RowTypeId=2, \"None\", \"Solid\")"));
            this.Detail.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderWidth.Default", "= IIf(Fields.RowTypeId=1 Or Fields.RowTypeId=2, \"0pt\", \"0.5pt\")"));
            this.Detail.CanShrink = true;
            this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(2.4D);
            this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Code,
            this.NameField,
            this.PeriodColumn1,
            this.PeriodColumn2,
            this.PeriodColumn3,
            this.YtdColumn1,
            this.YtdColumn2,
            this.YtdColumn3,
            this.YtdVariancePercent,
            this.PeriodVariancePercent,
            this.Description,
            this.Header,
            this.TotalsLabel,
            this.PeriodColumn1Total,
            this.PeriodColumn2Total,
            this.PeriodColumn3Total,
            this.YtdColumn1Total,
            this.YtdColumn2Total,
            this.YtdColumn3Total,
            this.PeriodVariancePercentTotal,
            this.YtdVariancePercentTotal});
            this.Detail.Name = "Detail";
            this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Detail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
            this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
            // 
            // Code
            // 
            this.Code.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=0 Or Fields.RowTypeId=3 Or Fields.RowTypeId=5, True, False" +
            ")"));
            this.Code.CanShrink = true;
            this.Code.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.Code.Name = "Code";
            this.Code.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Code.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.Code.Style.Font.Name = "Calibri";
            this.Code.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Code.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Code.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.Code.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Code.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Code.StyleName = "Normal.TableBody";
            this.Code.TextWrap = false;
            this.Code.Value = "= Fields.Code";
            // 
            // NameField
            // 
            this.NameField.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=0 Or Fields.RowTypeId=3 Or Fields.RowTypeId=5, True, False" +
            ")"));
            this.NameField.Bindings.Add(new Telerik.Reporting.Binding("Width", "= IIf(Parameters.transactionViewOptionId.Value=3, \"8.5cm\", \"6.5cm\")"));
            this.NameField.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.8D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.NameField.Name = "NameField";
            this.NameField.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.NameField.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.NameField.Style.Font.Name = "Calibri";
            this.NameField.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.NameField.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.NameField.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.NameField.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.NameField.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.NameField.StyleName = "Normal.TableBody";
            this.NameField.TextWrap = false;
            this.NameField.Value = "= Fields.Name";
            this.NameField.ItemDataBound += new System.EventHandler(this.Name_ItemDataBound);
            // 
            // PeriodColumn1
            // 
            this.PeriodColumn1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=0 Or Fields.RowTypeId=3 Or Fields.RowTypeId=5, True, False" +
            ")"));
            this.PeriodColumn1.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"10.3cm\", \"8.3cm\")"));
            this.PeriodColumn1.Format = "{0:C2}";
            this.PeriodColumn1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(8.3D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.PeriodColumn1.Name = "PeriodColumn1";
            this.PeriodColumn1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodColumn1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodColumn1.Style.Font.Name = "Calibri";
            this.PeriodColumn1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodColumn1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.PeriodColumn1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodColumn1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PeriodColumn1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodColumn1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodColumn1.StyleName = "Normal.TableBody";
            this.PeriodColumn1.TextWrap = false;
            this.PeriodColumn1.Value = "= Fields.PeriodColumn1";
            this.PeriodColumn1.ItemDataBound += new System.EventHandler(this.PeriodColumn_ItemDataBound);
            // 
            // PeriodColumn2
            // 
            this.PeriodColumn2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=0 Or Fields.RowTypeId=3 Or Fields.RowTypeId=5, True, False" +
            ")"));
            this.PeriodColumn2.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"13.2cm\", \"11.2cm\")"));
            this.PeriodColumn2.Format = "{0:C2}";
            this.PeriodColumn2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.2D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.PeriodColumn2.Name = "PeriodColumn2";
            this.PeriodColumn2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodColumn2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodColumn2.Style.Font.Name = "Calibri";
            this.PeriodColumn2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodColumn2.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.PeriodColumn2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PeriodColumn2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodColumn2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodColumn2.StyleName = "Normal.TableBody";
            this.PeriodColumn2.TextWrap = false;
            this.PeriodColumn2.Value = "= Fields.PeriodColumn2";
            this.PeriodColumn2.ItemDataBound += new System.EventHandler(this.PeriodColumn_ItemDataBound);
            // 
            // PeriodColumn3
            // 
            this.PeriodColumn3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=0 Or Fields.RowTypeId=3 Or Fields.RowTypeId=5, True, False" +
            ")"));
            this.PeriodColumn3.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"16.1cm\", \"14.1cm\")"));
            this.PeriodColumn3.Format = "{0:C2}";
            this.PeriodColumn3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.1D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.PeriodColumn3.Name = "PeriodColumn3";
            this.PeriodColumn3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodColumn3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodColumn3.Style.Font.Name = "Calibri";
            this.PeriodColumn3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodColumn3.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.PeriodColumn3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PeriodColumn3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodColumn3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodColumn3.StyleName = "Normal.TableBody";
            this.PeriodColumn3.TextWrap = false;
            this.PeriodColumn3.Value = "= Fields.PeriodColumn3";
            this.PeriodColumn3.ItemDataBound += new System.EventHandler(this.PeriodColumn_ItemDataBound);
            // 
            // YtdColumn1
            // 
            this.YtdColumn1.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=0 Or Fields.RowTypeId=3 Or Fields.RowTypeId=5, True, False" +
            ")"));
            this.YtdColumn1.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"19.0cm\", \"18.0cm\")"));
            this.YtdColumn1.Format = "{0:C2}";
            this.YtdColumn1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.YtdColumn1.Name = "YtdColumn1";
            this.YtdColumn1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdColumn1.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdColumn1.Style.Font.Name = "Calibri";
            this.YtdColumn1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdColumn1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.YtdColumn1.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.YtdColumn1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdColumn1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdColumn1.StyleName = "Normal.TableBody";
            this.YtdColumn1.TextWrap = false;
            this.YtdColumn1.Value = "= Fields.YtdColumn1";
            this.YtdColumn1.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // YtdColumn2
            // 
            this.YtdColumn2.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=0 Or Fields.RowTypeId=3 Or Fields.RowTypeId=5, True, False" +
            ")"));
            this.YtdColumn2.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"21.9cm\", \"20.9cm\")"));
            this.YtdColumn2.Format = "{0:C2}";
            this.YtdColumn2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.9D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.YtdColumn2.Name = "YtdColumn2";
            this.YtdColumn2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdColumn2.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdColumn2.Style.Font.Name = "Calibri";
            this.YtdColumn2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdColumn2.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.YtdColumn2.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.YtdColumn2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdColumn2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdColumn2.StyleName = "Normal.TableBody";
            this.YtdColumn2.TextWrap = false;
            this.YtdColumn2.Value = "= Fields.YtdColumn2";
            this.YtdColumn2.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // YtdColumn3
            // 
            this.YtdColumn3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=0 Or Fields.RowTypeId=3 Or Fields.RowTypeId=5, True, False" +
            ")"));
            this.YtdColumn3.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"24.8cm\", \"23.8cm\")"));
            this.YtdColumn3.Format = "{0:C2}";
            this.YtdColumn3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.8D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.YtdColumn3.Name = "YtdColumn3";
            this.YtdColumn3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdColumn3.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdColumn3.Style.Font.Name = "Calibri";
            this.YtdColumn3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdColumn3.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.YtdColumn3.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.YtdColumn3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdColumn3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdColumn3.StyleName = "Normal.TableBody";
            this.YtdColumn3.TextWrap = false;
            this.YtdColumn3.Value = "= Fields.YtdColumn3";
            this.YtdColumn3.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // YtdVariancePercent
            // 
            this.YtdVariancePercent.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=0 Or Fields.RowTypeId=3 Or Fields.RowTypeId=5, True, False" +
            ")"));
            this.YtdVariancePercent.Format = "";
            this.YtdVariancePercent.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(26.7D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.YtdVariancePercent.Name = "YtdVariancePercent";
            this.YtdVariancePercent.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdVariancePercent.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdVariancePercent.Style.Font.Name = "Calibri";
            this.YtdVariancePercent.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdVariancePercent.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.YtdVariancePercent.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdVariancePercent.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdVariancePercent.StyleName = "Normal.TableBody";
            this.YtdVariancePercent.TextWrap = false;
            this.YtdVariancePercent.Value = "= IIf(Parameters.transactionViewOptionId.Value=3 Or Fields.YtdVariancePercent=0,N" +
    "ull,Fields.YtdVariancePercent)";
            this.YtdVariancePercent.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // PeriodVariancePercent
            // 
            this.PeriodVariancePercent.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=0 Or Fields.RowTypeId=3 Or Fields.RowTypeId=5, True, False" +
            ")"));
            this.PeriodVariancePercent.Format = "";
            this.PeriodVariancePercent.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17D), Telerik.Reporting.Drawing.Unit.Cm(1.2D));
            this.PeriodVariancePercent.Name = "PeriodVariancePercent";
            this.PeriodVariancePercent.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodVariancePercent.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodVariancePercent.Style.Font.Name = "Calibri";
            this.PeriodVariancePercent.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodVariancePercent.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PeriodVariancePercent.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodVariancePercent.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodVariancePercent.StyleName = "Normal.TableBody";
            this.PeriodVariancePercent.TextWrap = false;
            this.PeriodVariancePercent.Value = "= IIf(Parameters.transactionViewOptionId.Value=0 Or Parameters.transactionViewOpt" +
    "ionId.Value=3 Or Fields.PeriodVariancePercent=0,Null,Fields.PeriodVariancePercen" +
    "t)";
            // 
            // Description
            // 
            this.Description.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=2, True, False)"));
            this.Description.CanShrink = true;
            this.Description.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Description.Name = "Description";
            this.Description.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Description.Style.Font.Italic = true;
            this.Description.Style.Font.Name = "Calibri";
            this.Description.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Description.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Description.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Description.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Description.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Description.Value = "= Fields.Name";
            // 
            // Header
            // 
            this.Header.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=1, True, False)"));
            this.Header.CanShrink = true;
            this.Header.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.Header.Name = "Header";
            this.Header.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.Header.Style.Font.Bold = true;
            this.Header.Style.Font.Name = "Calibri";
            this.Header.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Header.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Header.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Header.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.Header.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Header.Value = "= Fields.Name";
            // 
            // TotalsLabel
            // 
            this.TotalsLabel.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=4, True, False)"));
            this.TotalsLabel.Bindings.Add(new Telerik.Reporting.Binding("Width", "= IIf(Parameters.transactionViewOptionId.Value=3, \"10.3cm\", \"8.3cm\")"));
            this.TotalsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.TotalsLabel.Name = "TotalsLabel";
            this.TotalsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.TotalsLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.TotalsLabel.Style.Font.Bold = true;
            this.TotalsLabel.Style.Font.Name = "Calibri";
            this.TotalsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.TotalsLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.TotalsLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.TotalsLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.TotalsLabel.StyleName = "Normal.TableBody";
            this.TotalsLabel.Value = "= Fields.Code";
            this.TotalsLabel.ItemDataBound += new System.EventHandler(this.Name_ItemDataBound);
            // 
            // PeriodColumn1Total
            // 
            this.PeriodColumn1Total.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=4, True, False)"));
            this.PeriodColumn1Total.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"10.3cm\", \"8.3cm\")"));
            this.PeriodColumn1Total.Format = "{0:C2}";
            this.PeriodColumn1Total.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(8.3D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.PeriodColumn1Total.Name = "PeriodColumn1Total";
            this.PeriodColumn1Total.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodColumn1Total.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodColumn1Total.Style.Font.Bold = true;
            this.PeriodColumn1Total.Style.Font.Name = "Calibri";
            this.PeriodColumn1Total.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodColumn1Total.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.PeriodColumn1Total.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodColumn1Total.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PeriodColumn1Total.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodColumn1Total.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodColumn1Total.StyleName = "Normal.TableBody";
            this.PeriodColumn1Total.TextWrap = false;
            this.PeriodColumn1Total.Value = "= Fields.PeriodColumn1";
            this.PeriodColumn1Total.ItemDataBound += new System.EventHandler(this.PeriodColumn_ItemDataBound);
            // 
            // PeriodColumn2Total
            // 
            this.PeriodColumn2Total.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=4, True, False)"));
            this.PeriodColumn2Total.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"13.2cm\", \"11.2cm\")"));
            this.PeriodColumn2Total.Format = "{0:C2}";
            this.PeriodColumn2Total.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.2D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.PeriodColumn2Total.Name = "PeriodColumn2Total";
            this.PeriodColumn2Total.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodColumn2Total.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodColumn2Total.Style.Font.Bold = true;
            this.PeriodColumn2Total.Style.Font.Name = "Calibri";
            this.PeriodColumn2Total.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodColumn2Total.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.PeriodColumn2Total.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodColumn2Total.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PeriodColumn2Total.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodColumn2Total.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodColumn2Total.StyleName = "Normal.TableBody";
            this.PeriodColumn2Total.TextWrap = false;
            this.PeriodColumn2Total.Value = "= Fields.PeriodColumn2";
            this.PeriodColumn2Total.ItemDataBound += new System.EventHandler(this.PeriodColumn_ItemDataBound);
            // 
            // PeriodColumn3Total
            // 
            this.PeriodColumn3Total.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=4, True, False)"));
            this.PeriodColumn3Total.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"16.1cm\", \"14.1cm\")"));
            this.PeriodColumn3Total.Format = "{0:C2}";
            this.PeriodColumn3Total.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.1D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.PeriodColumn3Total.Name = "PeriodColumn3Total";
            this.PeriodColumn3Total.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodColumn3Total.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodColumn3Total.Style.Font.Bold = true;
            this.PeriodColumn3Total.Style.Font.Name = "Calibri";
            this.PeriodColumn3Total.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodColumn3Total.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.PeriodColumn3Total.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.PeriodColumn3Total.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PeriodColumn3Total.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodColumn3Total.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodColumn3Total.StyleName = "Normal.TableBody";
            this.PeriodColumn3Total.TextWrap = false;
            this.PeriodColumn3Total.Value = "= Fields.PeriodColumn3";
            this.PeriodColumn3Total.ItemDataBound += new System.EventHandler(this.PeriodColumn_ItemDataBound);
            // 
            // YtdColumn1Total
            // 
            this.YtdColumn1Total.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=4, True, False)"));
            this.YtdColumn1Total.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"19.0cm\", \"18.0cm\")"));
            this.YtdColumn1Total.Format = "{0:C2}";
            this.YtdColumn1Total.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.001D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.YtdColumn1Total.Name = "YtdColumn1Total";
            this.YtdColumn1Total.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdColumn1Total.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdColumn1Total.Style.Font.Bold = true;
            this.YtdColumn1Total.Style.Font.Name = "Calibri";
            this.YtdColumn1Total.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdColumn1Total.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.YtdColumn1Total.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.YtdColumn1Total.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.YtdColumn1Total.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdColumn1Total.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdColumn1Total.StyleName = "Normal.TableBody";
            this.YtdColumn1Total.TextWrap = false;
            this.YtdColumn1Total.Value = "= Fields.YtdColumn1";
            this.YtdColumn1Total.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // YtdColumn2Total
            // 
            this.YtdColumn2Total.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=4, True, False)"));
            this.YtdColumn2Total.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"21.9cm\", \"20.9cm\")"));
            this.YtdColumn2Total.Format = "{0:C2}";
            this.YtdColumn2Total.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.9D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.YtdColumn2Total.Name = "YtdColumn2Total";
            this.YtdColumn2Total.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdColumn2Total.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdColumn2Total.Style.Font.Bold = true;
            this.YtdColumn2Total.Style.Font.Name = "Calibri";
            this.YtdColumn2Total.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdColumn2Total.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.YtdColumn2Total.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.YtdColumn2Total.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.YtdColumn2Total.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdColumn2Total.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdColumn2Total.StyleName = "Normal.TableBody";
            this.YtdColumn2Total.TextWrap = false;
            this.YtdColumn2Total.Value = "= Fields.YtdColumn2";
            this.YtdColumn2Total.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // YtdColumn3Total
            // 
            this.YtdColumn3Total.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=4, True, False)"));
            this.YtdColumn3Total.Bindings.Add(new Telerik.Reporting.Binding("Left", "= IIf(Parameters.transactionViewOptionId.Value=3, \"24.8cm\", \"23.8cm\")"));
            this.YtdColumn3Total.Format = "{0:C2}";
            this.YtdColumn3Total.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.8D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.YtdColumn3Total.Name = "YtdColumn3Total";
            this.YtdColumn3Total.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdColumn3Total.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdColumn3Total.Style.Font.Bold = true;
            this.YtdColumn3Total.Style.Font.Name = "Calibri";
            this.YtdColumn3Total.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdColumn3Total.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
            this.YtdColumn3Total.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.YtdColumn3Total.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.YtdColumn3Total.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdColumn3Total.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdColumn3Total.StyleName = "Normal.TableBody";
            this.YtdColumn3Total.TextWrap = false;
            this.YtdColumn3Total.Value = "= Fields.YtdColumn3";
            this.YtdColumn3Total.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // PeriodVariancePercentTotal
            // 
            this.PeriodVariancePercentTotal.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=4, True, False)"));
            this.PeriodVariancePercentTotal.Format = "";
            this.PeriodVariancePercentTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(17D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.PeriodVariancePercentTotal.Name = "PeriodVariancePercentTotal";
            this.PeriodVariancePercentTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.PeriodVariancePercentTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.PeriodVariancePercentTotal.Style.Font.Bold = true;
            this.PeriodVariancePercentTotal.Style.Font.Name = "Calibri";
            this.PeriodVariancePercentTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.PeriodVariancePercentTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.PeriodVariancePercentTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.PeriodVariancePercentTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.PeriodVariancePercentTotal.StyleName = "Normal.TableBody";
            this.PeriodVariancePercentTotal.TextWrap = false;
            this.PeriodVariancePercentTotal.Value = "= IIf(Parameters.transactionViewOptionId.Value=0 Or Parameters.transactionViewOpt" +
    "ionId.Value=3 Or Fields.PeriodVariancePercent=0,Null, Fields.PeriodVariancePerce" +
    "nt)";
            // 
            // YtdVariancePercentTotal
            // 
            this.YtdVariancePercentTotal.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.RowTypeId=4, True, False)"));
            this.YtdVariancePercentTotal.Format = "";
            this.YtdVariancePercentTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(26.7D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
            this.YtdVariancePercentTotal.Name = "YtdVariancePercentTotal";
            this.YtdVariancePercentTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
            this.YtdVariancePercentTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
            this.YtdVariancePercentTotal.Style.Font.Bold = true;
            this.YtdVariancePercentTotal.Style.Font.Name = "Calibri";
            this.YtdVariancePercentTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.YtdVariancePercentTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
            this.YtdVariancePercentTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.YtdVariancePercentTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.YtdVariancePercentTotal.StyleName = "Normal.TableBody";
            this.YtdVariancePercentTotal.TextWrap = false;
            this.YtdVariancePercentTotal.Value = "= IIf(Parameters.transactionViewOptionId.Value=3 Or Fields.YtdVariancePercent=0,N" +
    "ull, Fields.YtdVariancePercent)";
            this.YtdVariancePercentTotal.ItemDataBound += new System.EventHandler(this.YtdColumn_ItemDataBound);
            // 
            // PageFooterSection
            // 
            this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
            this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
            this.PageFooterSection.Name = "pageFooterSection1";
            // 
            // Pages
            // 
            this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.7D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Pages.Name = "Pages";
            this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Pages.Style.Color = System.Drawing.Color.DarkGray;
            this.Pages.Style.Font.Name = "Calibri";
            this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Pages.Value = "= \"Page \" + PageNumber";
            // 
            // CreationTime
            // 
            this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.CreationTime.Name = "CreationTime";
            this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
            this.CreationTime.Style.Font.Name = "Calibri";
            this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
            this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy" +
    " HH:mm}\", Parameters.creationTime.Value)";
            // 
            // ReportDataSource
            // 
            this.ReportDataSource.DataMember = "GeneralLedgerReport";
            this.ReportDataSource.DataSource = typeof(Travelog.Reports.GeneralLedger.GeneralLedgerDataSources);
            this.ReportDataSource.Name = "ReportDataSource";
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("reportSource", typeof(string), "= Parameters.reportSource.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("currentDefaultAgencyId", typeof(int), "= Parameters.currentDefaultAgencyId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("userRoleId", typeof(string), "= Parameters.userRoleId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("transactionViewOptionId", typeof(int), "= Parameters.transactionViewOptionId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("chartOfAccountTypeId", typeof(int), "= Parameters.chartOfAccountTypeId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("accountCategoryId", typeof(int), "= Parameters.accountCategoryId.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("fiscalYearStartDate", typeof(System.DateTime), "= Parameters.fiscalYearStartDate.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("periodFrom", typeof(System.DateTime), "= Parameters.periodFrom.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateFrom", typeof(System.DateTime), "= Parameters.dateFrom.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateTo", typeof(System.DateTime), "= Parameters.dateTo.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("excludeZeroBalances", typeof(bool), "= Parameters.excludeZeroBalances.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("useAltReportingCode", typeof(bool), "= Parameters.useAltReportingCode.Value"));
            this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("useDateFilters", typeof(bool), "= Parameters.useDateFilters.Value"));
            // 
            // GeneralLedgerReport
            // 
            this.DataSource = this.ReportDataSource;
            group1.GroupFooter = this.GroupFooterSection1;
            group1.GroupHeader = this.GroupHeaderSection1;
            group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
            group1.Name = "Group1";
            this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1});
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.Detail,
            this.PageFooterSection});
            this.Name = "GeneralLedgerReport";
            this.PageSettings.Landscape = true;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            reportParameter1.Name = "reportSource";
            reportParameter2.Name = "userName";
            reportParameter3.Name = "customerId";
            reportParameter3.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter4.Name = "agencyId";
            reportParameter4.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter5.Name = "currentDefaultAgencyId";
            reportParameter5.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter6.Name = "userRoleId";
            reportParameter7.Name = "customerName";
            reportParameter8.Name = "reportName";
            reportParameter9.Name = "reportDate";
            reportParameter10.Name = "headerContent";
            reportParameter11.Name = "creationUser";
            reportParameter12.Name = "creationTime";
            reportParameter12.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter13.Name = "transactionViewOptionId";
            reportParameter13.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter14.Name = "chartOfAccountTypeId";
            reportParameter14.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter15.Name = "accountCategoryId";
            reportParameter15.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter16.Name = "fiscalYearStartDate";
            reportParameter16.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter17.Name = "periodFrom";
            reportParameter17.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter18.Name = "dateFrom";
            reportParameter18.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter19.Name = "dateTo";
            reportParameter19.Type = Telerik.Reporting.ReportParameterType.DateTime;
            reportParameter20.Name = "excludeZeroBalances";
            reportParameter20.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter21.Name = "useAltReportingCode";
            reportParameter21.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter22.Name = "useDateFilters";
            reportParameter22.Type = Telerik.Reporting.ReportParameterType.Boolean;
            reportParameter23.Name = "reportSignId";
            reportParameter23.Type = Telerik.Reporting.ReportParameterType.Integer;
            reportParameter24.AllowBlank = false;
            reportParameter24.Name = "periodColumn1Header";
            reportParameter25.AllowBlank = false;
            reportParameter25.Name = "periodColumn2Header";
            reportParameter26.AllowBlank = false;
            reportParameter26.Name = "periodColumn3Header";
            reportParameter27.AllowBlank = false;
            reportParameter27.Name = "ytdColumn1Header";
            reportParameter28.AllowBlank = false;
            reportParameter28.Name = "ytdColumn2Header";
            reportParameter29.AllowBlank = false;
            reportParameter29.Name = "ytdColumn3Header";
            reportParameter30.Name = "isLast";
            reportParameter30.Type = Telerik.Reporting.ReportParameterType.Boolean;
            this.ReportParameters.Add(reportParameter1);
            this.ReportParameters.Add(reportParameter2);
            this.ReportParameters.Add(reportParameter3);
            this.ReportParameters.Add(reportParameter4);
            this.ReportParameters.Add(reportParameter5);
            this.ReportParameters.Add(reportParameter6);
            this.ReportParameters.Add(reportParameter7);
            this.ReportParameters.Add(reportParameter8);
            this.ReportParameters.Add(reportParameter9);
            this.ReportParameters.Add(reportParameter10);
            this.ReportParameters.Add(reportParameter11);
            this.ReportParameters.Add(reportParameter12);
            this.ReportParameters.Add(reportParameter13);
            this.ReportParameters.Add(reportParameter14);
            this.ReportParameters.Add(reportParameter15);
            this.ReportParameters.Add(reportParameter16);
            this.ReportParameters.Add(reportParameter17);
            this.ReportParameters.Add(reportParameter18);
            this.ReportParameters.Add(reportParameter19);
            this.ReportParameters.Add(reportParameter20);
            this.ReportParameters.Add(reportParameter21);
            this.ReportParameters.Add(reportParameter22);
            this.ReportParameters.Add(reportParameter23);
            this.ReportParameters.Add(reportParameter24);
            this.ReportParameters.Add(reportParameter25);
            this.ReportParameters.Add(reportParameter26);
            this.ReportParameters.Add(reportParameter27);
            this.ReportParameters.Add(reportParameter28);
            this.ReportParameters.Add(reportParameter29);
            this.ReportParameters.Add(reportParameter30);
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(27.7D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.SubReport ManagementReportHeaderSubReport1;
		private Telerik.Reporting.TextBox YtdColumn1Header;
		private Telerik.Reporting.TextBox NameHeader;
		private Telerik.Reporting.TextBox PeriodColumn2Header;
		private Telerik.Reporting.TextBox PeriodColumn3Header;
		private Telerik.Reporting.TextBox CodeHeader;
		private Telerik.Reporting.TextBox YtdColumn2Header;
		private Telerik.Reporting.TextBox YtdColumn3Header;
		private Telerik.Reporting.TextBox YtdVariancePercentHeader;
		private Telerik.Reporting.TextBox PeriodVariancePercentHeader;
		private Telerik.Reporting.TextBox Code;
		private Telerik.Reporting.TextBox NameField;
		private Telerik.Reporting.TextBox PeriodColumn1;
		private Telerik.Reporting.TextBox PeriodColumn2;
		private Telerik.Reporting.TextBox PeriodColumn3;
		private Telerik.Reporting.TextBox YtdColumn1;
		private Telerik.Reporting.TextBox YtdColumn3;
		private Telerik.Reporting.TextBox YtdVariancePercent;
		private Telerik.Reporting.TextBox PeriodVariancePercent;
		private Telerik.Reporting.TextBox Description;
		private Telerik.Reporting.TextBox Header;
		private Telerik.Reporting.TextBox TotalsLabel;
		private Telerik.Reporting.TextBox PeriodColumn1Total;
		private Telerik.Reporting.TextBox PeriodColumn2Total;
		private Telerik.Reporting.TextBox PeriodColumn3Total;
		private Telerik.Reporting.TextBox YtdColumn1Total;
		private Telerik.Reporting.TextBox YtdColumn3Total;
		private Telerik.Reporting.TextBox PeriodVariancePercentTotal;
		private Telerik.Reporting.TextBox YtdVariancePercentTotal;
		private Telerik.Reporting.TextBox PeriodColumn1Header;
		private Telerik.Reporting.TextBox NoData;
		private Telerik.Reporting.TextBox YtdColumn2Total;
		private Telerik.Reporting.TextBox YtdColumn2;
	}
}