namespace Travelog.Reports.GeneralLedger {
	partial class GeneralLedgerTransactionsReport {
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			Telerik.Reporting.TypeReportSource typeReportSource1 = new Telerik.Reporting.TypeReportSource();
			Telerik.Reporting.Drawing.FormattingRule formattingRule1 = new Telerik.Reporting.Drawing.FormattingRule();
			Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup10 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.TableGroup tableGroup11 = new Telerik.Reporting.TableGroup();
			Telerik.Reporting.Group group1 = new Telerik.Reporting.Group();
			Telerik.Reporting.Group group2 = new Telerik.Reporting.Group();
			Telerik.Reporting.Group group3 = new Telerik.Reporting.Group();
			Telerik.Reporting.ReportParameter reportParameter1 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter2 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter3 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter4 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter5 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter6 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter7 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter8 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter9 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter10 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter11 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter12 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter13 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter14 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter15 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter16 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter17 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter18 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter19 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter20 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter21 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter22 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter23 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter24 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter25 = new Telerik.Reporting.ReportParameter();
			Telerik.Reporting.ReportParameter reportParameter26 = new Telerik.Reporting.ReportParameter();
			this.DocumentNoHeader = new Telerik.Reporting.TextBox();
			this.DocumentDateHeader = new Telerik.Reporting.TextBox();
			this.TransactionTypeHeader = new Telerik.Reporting.TextBox();
			this.AccountNameHeader = new Telerik.Reporting.TextBox();
			this.DescriptionHeader = new Telerik.Reporting.TextBox();
			this.AmountHeader = new Telerik.Reporting.TextBox();
			this.GroupFooterSection1 = new Telerik.Reporting.GroupFooterSection();
			this.TotalsLabel = new Telerik.Reporting.TextBox();
			this.BalanceTotal = new Telerik.Reporting.TextBox();
			this.GroupHeaderSection1 = new Telerik.Reporting.GroupHeaderSection();
			this.ManagementReportHeaderSubReport1 = new Telerik.Reporting.SubReport();
			this.AccountCategoryHeader = new Telerik.Reporting.TextBox();
			this.CodeHeader = new Telerik.Reporting.TextBox();
			this.ChartOfAccountTypeHeader = new Telerik.Reporting.TextBox();
			this.NameHeader = new Telerik.Reporting.TextBox();
			this.ChartOfAccountTransactionTypeHeader = new Telerik.Reporting.TextBox();
			this.YtdBalanceHeader = new Telerik.Reporting.TextBox();
			this.NoData = new Telerik.Reporting.TextBox();
			this.GroupFooterSection2 = new Telerik.Reporting.GroupFooterSection();
			this.GroupHeaderSection2 = new Telerik.Reporting.GroupHeaderSection();
			this.NameField = new Telerik.Reporting.TextBox();
			this.Code = new Telerik.Reporting.TextBox();
			this.ChartOfAccountTypeDescription = new Telerik.Reporting.TextBox();
			this.AccountCategory = new Telerik.Reporting.TextBox();
			this.ChartOfAccountTransactionType = new Telerik.Reporting.TextBox();
			this.YtdBalance = new Telerik.Reporting.TextBox();
			this.GroupFooterSection3 = new Telerik.Reporting.GroupFooterSection();
			this.GroupHeaderSection3 = new Telerik.Reporting.GroupHeaderSection();
			this.Period06 = new Telerik.Reporting.TextBox();
			this.Row3Value01 = new Telerik.Reporting.TextBox();
			this.Period08 = new Telerik.Reporting.TextBox();
			this.Row2Value12 = new Telerik.Reporting.TextBox();
			this.Row2Value05 = new Telerik.Reporting.TextBox();
			this.Period11 = new Telerik.Reporting.TextBox();
			this.MonthLabel = new Telerik.Reporting.TextBox();
			this.Period02 = new Telerik.Reporting.TextBox();
			this.Row2Value09 = new Telerik.Reporting.TextBox();
			this.Row1Label = new Telerik.Reporting.TextBox();
			this.Period07 = new Telerik.Reporting.TextBox();
			this.Row2Value06 = new Telerik.Reporting.TextBox();
			this.Row1Value01 = new Telerik.Reporting.TextBox();
			this.Row1Value02 = new Telerik.Reporting.TextBox();
			this.Row1Value03 = new Telerik.Reporting.TextBox();
			this.Row1Value04 = new Telerik.Reporting.TextBox();
			this.Row1Value05 = new Telerik.Reporting.TextBox();
			this.Row1Value06 = new Telerik.Reporting.TextBox();
			this.Row1Value07 = new Telerik.Reporting.TextBox();
			this.Row2Value08 = new Telerik.Reporting.TextBox();
			this.Row3Label = new Telerik.Reporting.TextBox();
			this.Period04 = new Telerik.Reporting.TextBox();
			this.Row2Value07 = new Telerik.Reporting.TextBox();
			this.Row3Value12 = new Telerik.Reporting.TextBox();
			this.Row2Label = new Telerik.Reporting.TextBox();
			this.Row2Value01 = new Telerik.Reporting.TextBox();
			this.Row2Value02 = new Telerik.Reporting.TextBox();
			this.Row2Value03 = new Telerik.Reporting.TextBox();
			this.Row2Value04 = new Telerik.Reporting.TextBox();
			this.Row3Value03 = new Telerik.Reporting.TextBox();
			this.Row3Value04 = new Telerik.Reporting.TextBox();
			this.Row3Value05 = new Telerik.Reporting.TextBox();
			this.Row3Value06 = new Telerik.Reporting.TextBox();
			this.Row3Value07 = new Telerik.Reporting.TextBox();
			this.Period01 = new Telerik.Reporting.TextBox();
			this.Row3Value08 = new Telerik.Reporting.TextBox();
			this.Row2Value10 = new Telerik.Reporting.TextBox();
			this.Row2Value11 = new Telerik.Reporting.TextBox();
			this.Row3Value10 = new Telerik.Reporting.TextBox();
			this.Row3Value11 = new Telerik.Reporting.TextBox();
			this.Row1Value08 = new Telerik.Reporting.TextBox();
			this.Row3Value09 = new Telerik.Reporting.TextBox();
			this.Row1Value11 = new Telerik.Reporting.TextBox();
			this.Period10 = new Telerik.Reporting.TextBox();
			this.Period05 = new Telerik.Reporting.TextBox();
			this.Row1Value09 = new Telerik.Reporting.TextBox();
			this.Period09 = new Telerik.Reporting.TextBox();
			this.Row3Value02 = new Telerik.Reporting.TextBox();
			this.Row1Value12 = new Telerik.Reporting.TextBox();
			this.Period12 = new Telerik.Reporting.TextBox();
			this.Period03 = new Telerik.Reporting.TextBox();
			this.Row1Value10 = new Telerik.Reporting.TextBox();
			this.Detail = new Telerik.Reporting.DetailSection();
			this.DetailTable = new Telerik.Reporting.Crosstab();
			this.AccountName = new Telerik.Reporting.TextBox();
			this.DocumentNo = new Telerik.Reporting.TextBox();
			this.DocumentDate = new Telerik.Reporting.TextBox();
			this.TransactionType = new Telerik.Reporting.TextBox();
			this.Amount = new Telerik.Reporting.TextBox();
			this.Description = new Telerik.Reporting.TextBox();
			this.AmountDetailTotalMonth = new Telerik.Reporting.TextBox();
			this.TotalDetailMonth = new Telerik.Reporting.TextBox();
			this.PageFooterSection = new Telerik.Reporting.PageFooterSection();
			this.Pages = new Telerik.Reporting.TextBox();
			this.CreationTime = new Telerik.Reporting.TextBox();
			this.ReportDataSource = new Telerik.Reporting.ObjectDataSource();
			this.AccumulatedTotal = new Telerik.Reporting.TextBox();
			this.AccumulatedTotalLabel = new Telerik.Reporting.TextBox();
			((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
			// 
			// DocumentNoHeader
			// 
			this.DocumentNoHeader.Name = "DocumentNoHeader";
			this.DocumentNoHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNoHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.DocumentNoHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNoHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentNoHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNoHeader.Style.Font.Bold = false;
			this.DocumentNoHeader.Style.Font.Name = "Calibri";
			this.DocumentNoHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNoHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNoHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentNoHeader.StyleName = "Normal.TableHeader";
			this.DocumentNoHeader.Value = "Document No";
			// 
			// DocumentDateHeader
			// 
			this.DocumentDateHeader.Name = "DocumentDateHeader";
			this.DocumentDateHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDateHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.DocumentDateHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDateHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentDateHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDateHeader.Style.Font.Bold = false;
			this.DocumentDateHeader.Style.Font.Name = "Calibri";
			this.DocumentDateHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDateHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDateHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDateHeader.StyleName = "Normal.TableHeader";
			this.DocumentDateHeader.Value = "Date";
			// 
			// TransactionTypeHeader
			// 
			this.TransactionTypeHeader.Name = "TransactionTypeHeader";
			this.TransactionTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TransactionTypeHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.TransactionTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TransactionTypeHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TransactionTypeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TransactionTypeHeader.Style.Font.Bold = false;
			this.TransactionTypeHeader.Style.Font.Name = "Calibri";
			this.TransactionTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TransactionTypeHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TransactionTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TransactionTypeHeader.StyleName = "Normal.TableHeader";
			this.TransactionTypeHeader.Value = "Type";
			// 
			// AccountNameHeader
			// 
			this.AccountNameHeader.Name = "AccountNameHeader";
			this.AccountNameHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccountNameHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.AccountNameHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccountNameHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AccountNameHeader.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.AccountNameHeader.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.AccountNameHeader.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.AccountNameHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AccountNameHeader.Style.Font.Bold = false;
			this.AccountNameHeader.Style.Font.Name = "Calibri";
			this.AccountNameHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AccountNameHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AccountNameHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AccountNameHeader.StyleName = "Normal.TableHeader";
			this.AccountNameHeader.Value = "Account";
			// 
			// DescriptionHeader
			// 
			this.DescriptionHeader.Name = "DescriptionHeader";
			this.DescriptionHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DescriptionHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.DescriptionHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DescriptionHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DescriptionHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DescriptionHeader.Style.Font.Bold = false;
			this.DescriptionHeader.Style.Font.Name = "Calibri";
			this.DescriptionHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DescriptionHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DescriptionHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DescriptionHeader.StyleName = "Normal.TableHeader";
			this.DescriptionHeader.Value = "Description";
			// 
			// AmountHeader
			// 
			this.AmountHeader.Name = "AmountHeader";
			this.AmountHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountHeader.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.AmountHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountHeader.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AmountHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AmountHeader.Style.Font.Bold = false;
			this.AmountHeader.Style.Font.Name = "Calibri";
			this.AmountHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AmountHeader.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AmountHeader.StyleName = "Normal.TableHeader";
			this.AmountHeader.Value = "Amount";
			// 
			// GroupFooterSection1
			// 
			this.GroupFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(0.5D);
			this.GroupFooterSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.TotalsLabel,
            this.BalanceTotal});
			this.GroupFooterSection1.Name = "GroupFooterSection1";
			this.GroupFooterSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			// 
			// TotalsLabel
			// 
			this.TotalsLabel.CanShrink = true;
			this.TotalsLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.TotalsLabel.Name = "TotalsLabel";
			this.TotalsLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.TotalsLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalsLabel.Style.Font.Bold = true;
			this.TotalsLabel.Style.Font.Name = "Calibri";
			this.TotalsLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TotalsLabel.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.TotalsLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalsLabel.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.TotalsLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.TotalsLabel.StyleName = "Normal.TableBody";
			this.TotalsLabel.Value = "Grand Total";
			// 
			// BalanceTotal
			// 
			this.BalanceTotal.CanShrink = true;
			this.BalanceTotal.Format = "{0:C2}";
			this.BalanceTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.BalanceTotal.Name = "BalanceTotal";
			this.BalanceTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.BalanceTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.BalanceTotal.Style.Font.Bold = true;
			this.BalanceTotal.Style.Font.Name = "Calibri";
			this.BalanceTotal.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.BalanceTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.BalanceTotal.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.BalanceTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.BalanceTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.BalanceTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			this.BalanceTotal.StyleName = "Normal.TableBody";
			this.BalanceTotal.Value = "= Sum(Fields.AccumulatedTotal)";
			// 
			// GroupHeaderSection1
			// 
			this.GroupHeaderSection1.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Count(1) = 0, \"None\", \"Solid\")"));
			this.GroupHeaderSection1.CanShrink = true;
			this.GroupHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(2.2D);
			this.GroupHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.ManagementReportHeaderSubReport1,
            this.AccountCategoryHeader,
            this.CodeHeader,
            this.ChartOfAccountTypeHeader,
            this.NameHeader,
            this.ChartOfAccountTransactionTypeHeader,
            this.YtdBalanceHeader,
            this.NoData});
			this.GroupHeaderSection1.Name = "GroupHeaderSection1";
			this.GroupHeaderSection1.PrintOnEveryPage = true;
			this.GroupHeaderSection1.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupHeaderSection1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// ManagementReportHeaderSubReport1
			// 
			this.ManagementReportHeaderSubReport1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ManagementReportHeaderSubReport1.Name = "ManagementReportHeaderSubReport1";
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("customerName", "= Parameters.customerName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportName", "= Parameters.reportName.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("reportDate", "= Parameters.reportDate.Value"));
			typeReportSource1.Parameters.Add(new Telerik.Reporting.Parameter("headerContent", "= Parameters.headerContent.Value"));
			typeReportSource1.TypeName = "Travelog.Reports.Common.ManagementReportHeaderSubReport1, Travelog.Reports, Versi" +
    "on=1.0.0.0, Culture=neutral, PublicKeyToken=null";
			this.ManagementReportHeaderSubReport1.ReportSource = typeReportSource1;
			this.ManagementReportHeaderSubReport1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ManagementReportHeaderSubReport1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			// 
			// AccountCategoryHeader
			// 
			this.AccountCategoryHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.AccountCategoryHeader.Name = "AccountCategoryHeader";
			this.AccountCategoryHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccountCategoryHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.AccountCategoryHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccountCategoryHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AccountCategoryHeader.Style.Font.Bold = true;
			this.AccountCategoryHeader.Style.Font.Name = "Calibri";
			this.AccountCategoryHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AccountCategoryHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AccountCategoryHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AccountCategoryHeader.StyleName = "Normal.TableHeader";
			this.AccountCategoryHeader.Value = "Category";
			// 
			// CodeHeader
			// 
			this.CodeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.CodeHeader.Name = "CodeHeader";
			this.CodeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.CodeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.CodeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.CodeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.CodeHeader.Style.Font.Bold = true;
			this.CodeHeader.Style.Font.Name = "Calibri";
			this.CodeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CodeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.CodeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CodeHeader.StyleName = "Normal.TableHeader";
			this.CodeHeader.Value = "Code";
			// 
			// ChartOfAccountTypeHeader
			// 
			this.ChartOfAccountTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ChartOfAccountTypeHeader.Name = "ChartOfAccountTypeHeader";
			this.ChartOfAccountTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ChartOfAccountTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountTypeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ChartOfAccountTypeHeader.Style.Font.Bold = true;
			this.ChartOfAccountTypeHeader.Style.Font.Name = "Calibri";
			this.ChartOfAccountTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ChartOfAccountTypeHeader.StyleName = "Normal.TableHeader";
			this.ChartOfAccountTypeHeader.Value = "Account Type";
			// 
			// NameHeader
			// 
			this.NameHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.NameHeader.Name = "NameHeader";
			this.NameHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NameHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.NameHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NameHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.NameHeader.Style.Font.Bold = true;
			this.NameHeader.Style.Font.Name = "Calibri";
			this.NameHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NameHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NameHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.NameHeader.StyleName = "Normal.TableHeader";
			this.NameHeader.Value = "Account";
			// 
			// ChartOfAccountTransactionTypeHeader
			// 
			this.ChartOfAccountTransactionTypeHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.ChartOfAccountTransactionTypeHeader.Name = "ChartOfAccountTransactionTypeHeader";
			this.ChartOfAccountTransactionTypeHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountTransactionTypeHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.ChartOfAccountTransactionTypeHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountTransactionTypeHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.ChartOfAccountTransactionTypeHeader.Style.Font.Bold = true;
			this.ChartOfAccountTransactionTypeHeader.Style.Font.Name = "Calibri";
			this.ChartOfAccountTransactionTypeHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountTransactionTypeHeader.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountTransactionTypeHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.ChartOfAccountTransactionTypeHeader.StyleName = "Normal.TableHeader";
			this.ChartOfAccountTransactionTypeHeader.Value = "Transaction Type";
			// 
			// YtdBalanceHeader
			// 
			this.YtdBalanceHeader.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.YtdBalanceHeader.Name = "YtdBalanceHeader";
			this.YtdBalanceHeader.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.YtdBalanceHeader.Style.BackgroundColor = System.Drawing.Color.Transparent;
			this.YtdBalanceHeader.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.YtdBalanceHeader.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.YtdBalanceHeader.Style.Font.Bold = true;
			this.YtdBalanceHeader.Style.Font.Name = "Calibri";
			this.YtdBalanceHeader.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.YtdBalanceHeader.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.YtdBalanceHeader.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.YtdBalanceHeader.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.YtdBalanceHeader.StyleName = "Normal.TableHeader";
			this.YtdBalanceHeader.Value = "YTD Balance";
			// 
			// NoData
			// 
			formattingRule1.Filters.Add(new Telerik.Reporting.Filter("= Count(1)", Telerik.Reporting.FilterOperator.Equal, "0"));
			formattingRule1.Style.Visible = true;
			this.NoData.ConditionalFormatting.AddRange(new Telerik.Reporting.Drawing.FormattingRule[] {
            formattingRule1});
			this.NoData.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.6D));
			this.NoData.Name = "NoData";
			this.NoData.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NoData.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.NoData.Style.BorderColor.Default = System.Drawing.Color.WhiteSmoke;
			this.NoData.Style.Font.Name = "Calibri";
			this.NoData.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NoData.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
			this.NoData.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.NoData.Style.Visible = false;
			this.NoData.StyleName = "Normal.TableHeader";
			this.NoData.Value = "NO DATA AVAILABLE";
			// 
			// GroupFooterSection2
			// 
			this.GroupFooterSection2.Bindings.Add(new Telerik.Reporting.Binding("PageBreak", "= IIf(Fields.TransactionDetailReportList.Count = 0, \"None\", \"After\")"));
			this.GroupFooterSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupFooterSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.AccumulatedTotalLabel,
            this.AccumulatedTotal});
			this.GroupFooterSection2.Name = "GroupFooterSection2";
			// 
			// GroupHeaderSection2
			// 
			this.GroupHeaderSection2.Bindings.Add(new Telerik.Reporting.Binding("PageBreak", "= IIf(Fields.TransactionDetailReportList.Count = 0, \"None\", \"Before\")"));
			this.GroupHeaderSection2.Height = Telerik.Reporting.Drawing.Unit.Cm(0.6D);
			this.GroupHeaderSection2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.NameField,
            this.Code,
            this.ChartOfAccountTypeDescription,
            this.AccountCategory,
            this.ChartOfAccountTransactionType,
            this.YtdBalance});
			this.GroupHeaderSection2.Name = "GroupHeaderSection2";
			this.GroupHeaderSection2.PrintOnEveryPage = true;
			this.GroupHeaderSection2.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.GroupHeaderSection2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.GroupHeaderSection2.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			// 
			// NameField
			// 
			this.NameField.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.NameField.Name = "NameField";
			this.NameField.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(9.8D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.NameField.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.NameField.Style.Font.Name = "Calibri";
			this.NameField.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.NameField.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.NameField.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.NameField.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.NameField.StyleName = "Normal.TableBody";
			this.NameField.TextWrap = false;
			this.NameField.Value = "= Fields.Name";
			// 
			// Code
			// 
			this.Code.CanShrink = true;
			this.Code.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Code.Name = "Code";
			this.Code.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.9D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Code.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Code.Style.Font.Name = "Calibri";
			this.Code.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Code.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Code.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Code.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Code.StyleName = "Normal.TableBody";
			this.Code.TextWrap = false;
			this.Code.Value = "= Fields.Code";
			// 
			// ChartOfAccountTypeDescription
			// 
			this.ChartOfAccountTypeDescription.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ChartOfAccountTypeDescription.Name = "ChartOfAccountTypeDescription";
			this.ChartOfAccountTypeDescription.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountTypeDescription.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountTypeDescription.Style.Font.Name = "Calibri";
			this.ChartOfAccountTypeDescription.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountTypeDescription.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ChartOfAccountTypeDescription.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountTypeDescription.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ChartOfAccountTypeDescription.StyleName = "Normal.TableBody";
			this.ChartOfAccountTypeDescription.TextWrap = false;
			this.ChartOfAccountTypeDescription.Value = "= Fields.ChartOfAccountTypeDescription";
			// 
			// AccountCategory
			// 
			this.AccountCategory.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AccountCategory.Name = "AccountCategory";
			this.AccountCategory.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccountCategory.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccountCategory.Style.Font.Name = "Calibri";
			this.AccountCategory.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AccountCategory.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AccountCategory.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AccountCategory.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AccountCategory.StyleName = "Normal.TableBody";
			this.AccountCategory.TextWrap = false;
			this.AccountCategory.Value = "= Fields.AccountCategory";
			// 
			// ChartOfAccountTransactionType
			// 
			this.ChartOfAccountTransactionType.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(20.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.ChartOfAccountTransactionType.Name = "ChartOfAccountTransactionType";
			this.ChartOfAccountTransactionType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.ChartOfAccountTransactionType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.ChartOfAccountTransactionType.Style.Font.Name = "Calibri";
			this.ChartOfAccountTransactionType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.ChartOfAccountTransactionType.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.ChartOfAccountTransactionType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.ChartOfAccountTransactionType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.ChartOfAccountTransactionType.StyleName = "Normal.TableBody";
			this.ChartOfAccountTransactionType.TextWrap = false;
			this.ChartOfAccountTransactionType.Value = "= Fields.ChartOfAccountTransactionType";
			// 
			// YtdBalance
			// 
			this.YtdBalance.Format = "{0:C2}";
			this.YtdBalance.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.YtdBalance.Name = "YtdBalance";
			this.YtdBalance.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.YtdBalance.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.YtdBalance.Style.Font.Name = "Calibri";
			this.YtdBalance.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.YtdBalance.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.YtdBalance.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.YtdBalance.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.YtdBalance.StyleName = "Normal.TableBody";
			this.YtdBalance.TextWrap = false;
			this.YtdBalance.Value = "= Fields.YtdBalance";
			// 
			// GroupFooterSection3
			// 
			this.GroupFooterSection3.Height = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.GroupFooterSection3.Name = "GroupFooterSection3";
			this.GroupFooterSection3.Style.Visible = false;
			// 
			// GroupHeaderSection3
			// 
			this.GroupHeaderSection3.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Parameters.includeMonthlyTotals.Value, True, False)"));
			this.GroupHeaderSection3.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderStyle.Bottom", "= IIf(Fields.TransactionDetailReportList.Count = 0, \"Solid\", \"None\")"));
			this.GroupHeaderSection3.Bindings.Add(new Telerik.Reporting.Binding("Style.BorderWidth.Default", "= IIf(Fields.TransactionDetailReportList.Count = 0, \"0.5pt\", \"0pt\")"));
			this.GroupHeaderSection3.CanShrink = true;
			this.GroupHeaderSection3.Height = Telerik.Reporting.Drawing.Unit.Cm(1.8D);
			this.GroupHeaderSection3.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Period06,
            this.Row3Value01,
            this.Period08,
            this.Row2Value12,
            this.Row2Value05,
            this.Period11,
            this.MonthLabel,
            this.Period02,
            this.Row2Value09,
            this.Row1Label,
            this.Period07,
            this.Row2Value06,
            this.Row1Value01,
            this.Row1Value02,
            this.Row1Value03,
            this.Row1Value04,
            this.Row1Value05,
            this.Row1Value06,
            this.Row1Value07,
            this.Row2Value08,
            this.Row3Label,
            this.Period04,
            this.Row2Value07,
            this.Row3Value12,
            this.Row2Label,
            this.Row2Value01,
            this.Row2Value02,
            this.Row2Value03,
            this.Row2Value04,
            this.Row3Value03,
            this.Row3Value04,
            this.Row3Value05,
            this.Row3Value06,
            this.Row3Value07,
            this.Period01,
            this.Row3Value08,
            this.Row2Value10,
            this.Row2Value11,
            this.Row3Value10,
            this.Row3Value11,
            this.Row1Value08,
            this.Row3Value09,
            this.Row1Value11,
            this.Period10,
            this.Period05,
            this.Row1Value09,
            this.Period09,
            this.Row3Value02,
            this.Row1Value12,
            this.Period12,
            this.Period03,
            this.Row1Value10});
			this.GroupHeaderSection3.Name = "GroupHeaderSection3";
			this.GroupHeaderSection3.Style.BorderColor.Default = System.Drawing.Color.Silver;
			// 
			// Period06
			// 
			this.Period06.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period06.Name = "Period06";
			this.Period06.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period06.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period06.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period06.Style.Font.Name = "Calibri";
			this.Period06.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period06.Style.LineColor = System.Drawing.Color.Silver;
			this.Period06.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period06.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period06.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period06.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period06.StyleName = "Normal.TableHeader";
			this.Period06.TextWrap = false;
			this.Period06.Value = "= Fields.Period06";
			// 
			// Row3Value01
			// 
			this.Row3Value01.Format = "{0:C2}";
			this.Row3Value01.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.3D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value01.Name = "Row3Value01";
			this.Row3Value01.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value01.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value01.Style.Font.Name = "Calibri";
			this.Row3Value01.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value01.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value01.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value01.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value01.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value01.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value01.StyleName = "Normal.TableBody";
			this.Row3Value01.TextWrap = false;
			this.Row3Value01.Value = "= Fields.Row3Value01";
			// 
			// Period08
			// 
			this.Period08.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period08.Name = "Period08";
			this.Period08.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period08.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period08.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period08.Style.Font.Name = "Calibri";
			this.Period08.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period08.Style.LineColor = System.Drawing.Color.Silver;
			this.Period08.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period08.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period08.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period08.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period08.StyleName = "Normal.TableHeader";
			this.Period08.TextWrap = false;
			this.Period08.Value = "= Fields.Period08";
			// 
			// Row2Value12
			// 
			this.Row2Value12.Format = "{0:C2}";
			this.Row2Value12.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.5D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value12.Name = "Row2Value12";
			this.Row2Value12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value12.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value12.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value12.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value12.Style.Font.Name = "Calibri";
			this.Row2Value12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value12.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value12.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value12.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value12.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value12.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value12.StyleName = "Normal.TableBody";
			this.Row2Value12.TextWrap = false;
			this.Row2Value12.Value = "= Fields.Row2Value12";
			// 
			// Row2Value05
			// 
			this.Row2Value05.Format = "{0:C2}";
			this.Row2Value05.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.1D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value05.Name = "Row2Value05";
			this.Row2Value05.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value05.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value05.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value05.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value05.Style.Font.Name = "Calibri";
			this.Row2Value05.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value05.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value05.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value05.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value05.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value05.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value05.StyleName = "Normal.TableBody";
			this.Row2Value05.TextWrap = false;
			this.Row2Value05.Value = "= Fields.Row2Value05";
			// 
			// Period11
			// 
			this.Period11.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period11.Name = "Period11";
			this.Period11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period11.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period11.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period11.Style.Font.Name = "Calibri";
			this.Period11.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period11.Style.LineColor = System.Drawing.Color.Silver;
			this.Period11.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period11.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period11.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period11.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period11.StyleName = "Normal.TableHeader";
			this.Period11.TextWrap = false;
			this.Period11.Value = "= Fields.Period11";
			// 
			// MonthLabel
			// 
			this.MonthLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.MonthLabel.Name = "MonthLabel";
			this.MonthLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.MonthLabel.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.MonthLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.MonthLabel.Style.Font.Name = "Calibri";
			this.MonthLabel.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.MonthLabel.Style.LineColor = System.Drawing.Color.Silver;
			this.MonthLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.MonthLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.MonthLabel.StyleName = "Normal.TableHeader";
			this.MonthLabel.TextWrap = false;
			this.MonthLabel.Value = "Period";
			// 
			// Period02
			// 
			this.Period02.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period02.Name = "Period02";
			this.Period02.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period02.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period02.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period02.Style.Font.Name = "Calibri";
			this.Period02.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period02.Style.LineColor = System.Drawing.Color.Silver;
			this.Period02.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period02.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period02.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period02.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period02.StyleName = "Normal.TableHeader";
			this.Period02.TextWrap = false;
			this.Period02.Value = "= Fields.Period02";
			// 
			// Row2Value09
			// 
			this.Row2Value09.Format = "{0:C2}";
			this.Row2Value09.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.9D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value09.Name = "Row2Value09";
			this.Row2Value09.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value09.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value09.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value09.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value09.Style.Font.Name = "Calibri";
			this.Row2Value09.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value09.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value09.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value09.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value09.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value09.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value09.StyleName = "Normal.TableBody";
			this.Row2Value09.TextWrap = false;
			this.Row2Value09.Value = "= Fields.Row2Value09";
			// 
			// Row1Label
			// 
			this.Row1Label.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Label.Name = "Row1Label";
			this.Row1Label.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Label.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Label.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Label.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Label.Style.Font.Name = "Calibri";
			this.Row1Label.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Label.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Label.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Label.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Label.StyleName = "Normal.TableHeader";
			this.Row1Label.TextWrap = false;
			this.Row1Label.Value = "= Parameters.column1Label.Value";
			// 
			// Period07
			// 
			this.Period07.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period07.Name = "Period07";
			this.Period07.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period07.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period07.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period07.Style.Font.Name = "Calibri";
			this.Period07.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period07.Style.LineColor = System.Drawing.Color.Silver;
			this.Period07.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period07.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period07.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period07.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period07.StyleName = "Normal.TableHeader";
			this.Period07.TextWrap = false;
			this.Period07.Value = "= Fields.Period07";
			// 
			// Row2Value06
			// 
			this.Row2Value06.Format = "{0:C2}";
			this.Row2Value06.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.3D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value06.Name = "Row2Value06";
			this.Row2Value06.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value06.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value06.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value06.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value06.Style.Font.Name = "Calibri";
			this.Row2Value06.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value06.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value06.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value06.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value06.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value06.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value06.StyleName = "Normal.TableBody";
			this.Row2Value06.TextWrap = false;
			this.Row2Value06.Value = "= Fields.Row2Value06";
			// 
			// Row1Value01
			// 
			this.Row1Value01.Format = "{0:C2}";
			this.Row1Value01.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value01.Name = "Row1Value01";
			this.Row1Value01.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value01.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value01.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value01.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value01.Style.Font.Name = "Calibri";
			this.Row1Value01.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value01.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value01.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value01.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value01.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value01.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value01.StyleName = "Normal.TableBody";
			this.Row1Value01.TextWrap = false;
			this.Row1Value01.Value = "= Fields.Row1Value01";
			// 
			// Row1Value02
			// 
			this.Row1Value02.Format = "{0:C2}";
			this.Row1Value02.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.5D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value02.Name = "Row1Value02";
			this.Row1Value02.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value02.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value02.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value02.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value02.Style.Font.Name = "Calibri";
			this.Row1Value02.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value02.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value02.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value02.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value02.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value02.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value02.StyleName = "Normal.TableBody";
			this.Row1Value02.TextWrap = false;
			this.Row1Value02.Value = "= Fields.Row1Value02";
			// 
			// Row1Value03
			// 
			this.Row1Value03.Format = "{0:C2}";
			this.Row1Value03.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(5.7D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value03.Name = "Row1Value03";
			this.Row1Value03.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value03.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value03.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value03.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value03.Style.Font.Name = "Calibri";
			this.Row1Value03.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value03.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value03.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value03.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value03.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value03.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value03.StyleName = "Normal.TableBody";
			this.Row1Value03.TextWrap = false;
			this.Row1Value03.Value = "= Fields.Row1Value03";
			// 
			// Row1Value04
			// 
			this.Row1Value04.Format = "{0:C2}";
			this.Row1Value04.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7.9D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value04.Name = "Row1Value04";
			this.Row1Value04.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value04.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value04.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value04.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value04.Style.Font.Name = "Calibri";
			this.Row1Value04.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value04.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value04.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value04.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value04.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value04.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value04.StyleName = "Normal.TableBody";
			this.Row1Value04.TextWrap = false;
			this.Row1Value04.Value = "= Fields.Row1Value04";
			// 
			// Row1Value05
			// 
			this.Row1Value05.Format = "{0:C2}";
			this.Row1Value05.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.1D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value05.Name = "Row1Value05";
			this.Row1Value05.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value05.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value05.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value05.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value05.Style.Font.Name = "Calibri";
			this.Row1Value05.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value05.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value05.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value05.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value05.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value05.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value05.StyleName = "Normal.TableBody";
			this.Row1Value05.TextWrap = false;
			this.Row1Value05.Value = "= Fields.Row1Value05";
			// 
			// Row1Value06
			// 
			this.Row1Value06.Format = "{0:C2}";
			this.Row1Value06.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value06.Name = "Row1Value06";
			this.Row1Value06.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value06.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value06.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value06.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value06.Style.Font.Name = "Calibri";
			this.Row1Value06.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value06.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value06.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value06.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value06.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value06.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value06.StyleName = "Normal.TableBody";
			this.Row1Value06.TextWrap = false;
			this.Row1Value06.Value = "= Fields.Row1Value06";
			// 
			// Row1Value07
			// 
			this.Row1Value07.Format = "{0:C2}";
			this.Row1Value07.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.5D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value07.Name = "Row1Value07";
			this.Row1Value07.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value07.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value07.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value07.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value07.Style.Font.Name = "Calibri";
			this.Row1Value07.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value07.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value07.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value07.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value07.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value07.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value07.StyleName = "Normal.TableBody";
			this.Row1Value07.TextWrap = false;
			this.Row1Value07.Value = "= Fields.Row1Value07";
			// 
			// Row2Value08
			// 
			this.Row2Value08.Format = "{0:C2}";
			this.Row2Value08.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.7D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value08.Name = "Row2Value08";
			this.Row2Value08.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value08.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value08.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value08.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value08.Style.Font.Name = "Calibri";
			this.Row2Value08.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value08.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value08.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value08.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value08.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value08.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value08.StyleName = "Normal.TableBody";
			this.Row2Value08.TextWrap = false;
			this.Row2Value08.Value = "= Fields.Row2Value08";
			// 
			// Row3Label
			// 
			this.Row3Label.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Label.Name = "Row3Label";
			this.Row3Label.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Label.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Label.Style.Font.Name = "Calibri";
			this.Row3Label.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Label.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Label.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Label.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Label.StyleName = "Normal.TableHeader";
			this.Row3Label.TextWrap = false;
			this.Row3Label.Value = "= Parameters.column3Label.Value";
			// 
			// Period04
			// 
			this.Period04.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period04.Name = "Period04";
			this.Period04.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period04.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period04.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period04.Style.Font.Name = "Calibri";
			this.Period04.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period04.Style.LineColor = System.Drawing.Color.Silver;
			this.Period04.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period04.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period04.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period04.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period04.StyleName = "Normal.TableHeader";
			this.Period04.TextWrap = false;
			this.Period04.Value = "= Fields.Period04";
			// 
			// Row2Value07
			// 
			this.Row2Value07.Format = "{0:C2}";
			this.Row2Value07.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.5D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value07.Name = "Row2Value07";
			this.Row2Value07.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value07.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value07.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value07.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value07.Style.Font.Name = "Calibri";
			this.Row2Value07.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value07.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value07.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value07.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value07.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value07.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value07.StyleName = "Normal.TableBody";
			this.Row2Value07.TextWrap = false;
			this.Row2Value07.Value = "= Fields.Row2Value07";
			// 
			// Row3Value12
			// 
			this.Row3Value12.Format = "{0:C2}";
			this.Row3Value12.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.5D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value12.Name = "Row3Value12";
			this.Row3Value12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value12.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value12.Style.Font.Name = "Calibri";
			this.Row3Value12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value12.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value12.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value12.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value12.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value12.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value12.StyleName = "Normal.TableBody";
			this.Row3Value12.TextWrap = false;
			this.Row3Value12.Value = "= Fields.Row3Value12";
			// 
			// Row2Label
			// 
			this.Row2Label.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Label.Name = "Row2Label";
			this.Row2Label.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Label.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Label.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Label.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Label.Style.Font.Name = "Calibri";
			this.Row2Label.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Label.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Label.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Label.StyleName = "Normal.TableHeader";
			this.Row2Label.TextWrap = false;
			this.Row2Label.Value = "= Parameters.column2Label.Value";
			// 
			// Row2Value01
			// 
			this.Row2Value01.Format = "{0:C2}";
			this.Row2Value01.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.3D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value01.Name = "Row2Value01";
			this.Row2Value01.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value01.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value01.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value01.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value01.Style.Font.Name = "Calibri";
			this.Row2Value01.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value01.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value01.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value01.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value01.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value01.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value01.StyleName = "Normal.TableBody";
			this.Row2Value01.TextWrap = false;
			this.Row2Value01.Value = "= Fields.Row2Value01";
			// 
			// Row2Value02
			// 
			this.Row2Value02.Format = "{0:C2}";
			this.Row2Value02.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.5D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value02.Name = "Row2Value02";
			this.Row2Value02.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value02.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value02.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value02.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value02.Style.Font.Name = "Calibri";
			this.Row2Value02.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value02.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value02.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value02.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value02.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value02.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value02.StyleName = "Normal.TableBody";
			this.Row2Value02.TextWrap = false;
			this.Row2Value02.Value = "= Fields.Row2Value02";
			// 
			// Row2Value03
			// 
			this.Row2Value03.Format = "{0:C2}";
			this.Row2Value03.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(5.7D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value03.Name = "Row2Value03";
			this.Row2Value03.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value03.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value03.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value03.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value03.Style.Font.Name = "Calibri";
			this.Row2Value03.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value03.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value03.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value03.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value03.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value03.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value03.StyleName = "Normal.TableBody";
			this.Row2Value03.TextWrap = false;
			this.Row2Value03.Value = "= Fields.Row2Value03";
			// 
			// Row2Value04
			// 
			this.Row2Value04.Format = "{0:C2}";
			this.Row2Value04.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7.9D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value04.Name = "Row2Value04";
			this.Row2Value04.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value04.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value04.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value04.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value04.Style.Font.Name = "Calibri";
			this.Row2Value04.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value04.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value04.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value04.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value04.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value04.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value04.StyleName = "Normal.TableBody";
			this.Row2Value04.TextWrap = false;
			this.Row2Value04.Value = "= Fields.Row2Value04";
			// 
			// Row3Value03
			// 
			this.Row3Value03.Format = "{0:C2}";
			this.Row3Value03.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(5.7D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value03.Name = "Row3Value03";
			this.Row3Value03.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value03.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value03.Style.Font.Name = "Calibri";
			this.Row3Value03.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value03.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value03.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value03.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value03.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value03.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value03.StyleName = "Normal.TableBody";
			this.Row3Value03.TextWrap = false;
			this.Row3Value03.Value = "= Fields.Row3Value03";
			// 
			// Row3Value04
			// 
			this.Row3Value04.Format = "{0:C2}";
			this.Row3Value04.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(7.9D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value04.Name = "Row3Value04";
			this.Row3Value04.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value04.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value04.Style.Font.Name = "Calibri";
			this.Row3Value04.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value04.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value04.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value04.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value04.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value04.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value04.StyleName = "Normal.TableBody";
			this.Row3Value04.TextWrap = false;
			this.Row3Value04.Value = "= Fields.Row3Value04";
			// 
			// Row3Value05
			// 
			this.Row3Value05.Format = "{0:C2}";
			this.Row3Value05.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.1D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value05.Name = "Row3Value05";
			this.Row3Value05.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value05.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value05.Style.Font.Name = "Calibri";
			this.Row3Value05.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value05.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value05.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value05.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value05.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value05.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value05.StyleName = "Normal.TableBody";
			this.Row3Value05.TextWrap = false;
			this.Row3Value05.Value = "= Fields.Row3Value05";
			// 
			// Row3Value06
			// 
			this.Row3Value06.Format = "{0:C2}";
			this.Row3Value06.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.3D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value06.Name = "Row3Value06";
			this.Row3Value06.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value06.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value06.Style.Font.Name = "Calibri";
			this.Row3Value06.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value06.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value06.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value06.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value06.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value06.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value06.StyleName = "Normal.TableBody";
			this.Row3Value06.TextWrap = false;
			this.Row3Value06.Value = "= Fields.Row3Value06";
			// 
			// Row3Value07
			// 
			this.Row3Value07.Format = "{0:C2}";
			this.Row3Value07.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(14.5D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value07.Name = "Row3Value07";
			this.Row3Value07.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value07.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value07.Style.Font.Name = "Calibri";
			this.Row3Value07.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value07.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value07.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value07.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value07.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value07.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value07.StyleName = "Normal.TableBody";
			this.Row3Value07.TextWrap = false;
			this.Row3Value07.Value = "= Fields.Row3Value07";
			// 
			// Period01
			// 
			this.Period01.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(1.3D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period01.Name = "Period01";
			this.Period01.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period01.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period01.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period01.Style.Font.Name = "Calibri";
			this.Period01.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period01.Style.LineColor = System.Drawing.Color.Silver;
			this.Period01.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period01.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period01.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period01.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period01.StyleName = "Normal.TableHeader";
			this.Period01.TextWrap = false;
			this.Period01.Value = "= Fields.Period01";
			// 
			// Row3Value08
			// 
			this.Row3Value08.Format = "{0:C2}";
			this.Row3Value08.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.7D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value08.Name = "Row3Value08";
			this.Row3Value08.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value08.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value08.Style.Font.Name = "Calibri";
			this.Row3Value08.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value08.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value08.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value08.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value08.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value08.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value08.StyleName = "Normal.TableBody";
			this.Row3Value08.TextWrap = false;
			this.Row3Value08.Value = "= Fields.Row3Value08";
			// 
			// Row2Value10
			// 
			this.Row2Value10.Format = "{0:C2}";
			this.Row2Value10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(21.1D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value10.Name = "Row2Value10";
			this.Row2Value10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value10.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value10.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value10.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value10.Style.Font.Name = "Calibri";
			this.Row2Value10.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value10.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value10.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value10.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value10.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value10.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value10.StyleName = "Normal.TableBody";
			this.Row2Value10.TextWrap = false;
			this.Row2Value10.Value = "= Fields.Row2Value10";
			// 
			// Row2Value11
			// 
			this.Row2Value11.Format = "{0:C2}";
			this.Row2Value11.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.3D), Telerik.Reporting.Drawing.Unit.Cm(0.9D));
			this.Row2Value11.Name = "Row2Value11";
			this.Row2Value11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row2Value11.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row2Value11.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row2Value11.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row2Value11.Style.Font.Name = "Calibri";
			this.Row2Value11.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row2Value11.Style.LineColor = System.Drawing.Color.Silver;
			this.Row2Value11.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value11.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row2Value11.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row2Value11.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row2Value11.StyleName = "Normal.TableBody";
			this.Row2Value11.TextWrap = false;
			this.Row2Value11.Value = "= Fields.Row2Value11";
			// 
			// Row3Value10
			// 
			this.Row3Value10.Format = "{0:C2}";
			this.Row3Value10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(21.1D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value10.Name = "Row3Value10";
			this.Row3Value10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value10.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value10.Style.Font.Name = "Calibri";
			this.Row3Value10.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value10.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value10.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value10.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value10.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value10.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value10.StyleName = "Normal.TableBody";
			this.Row3Value10.TextWrap = false;
			this.Row3Value10.Value = "= Fields.Row3Value10";
			// 
			// Row3Value11
			// 
			this.Row3Value11.Format = "{0:C2}";
			this.Row3Value11.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.3D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value11.Name = "Row3Value11";
			this.Row3Value11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value11.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value11.Style.Font.Name = "Calibri";
			this.Row3Value11.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value11.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value11.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value11.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value11.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value11.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value11.StyleName = "Normal.TableBody";
			this.Row3Value11.TextWrap = false;
			this.Row3Value11.Value = "= Fields.Row3Value11";
			// 
			// Row1Value08
			// 
			this.Row1Value08.Format = "{0:C2}";
			this.Row1Value08.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(16.7D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value08.Name = "Row1Value08";
			this.Row1Value08.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value08.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value08.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value08.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value08.Style.Font.Name = "Calibri";
			this.Row1Value08.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value08.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value08.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value08.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value08.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value08.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value08.StyleName = "Normal.TableBody";
			this.Row1Value08.TextWrap = false;
			this.Row1Value08.Value = "= Fields.Row1Value08";
			// 
			// Row3Value09
			// 
			this.Row3Value09.Format = "{0:C2}";
			this.Row3Value09.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.9D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value09.Name = "Row3Value09";
			this.Row3Value09.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value09.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value09.Style.Font.Name = "Calibri";
			this.Row3Value09.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value09.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value09.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value09.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value09.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value09.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value09.StyleName = "Normal.TableBody";
			this.Row3Value09.TextWrap = false;
			this.Row3Value09.Value = "= Fields.Row3Value09";
			// 
			// Row1Value11
			// 
			this.Row1Value11.Format = "{0:C2}";
			this.Row1Value11.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(23.3D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value11.Name = "Row1Value11";
			this.Row1Value11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value11.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value11.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value11.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value11.Style.Font.Name = "Calibri";
			this.Row1Value11.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value11.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value11.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value11.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value11.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value11.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value11.StyleName = "Normal.TableBody";
			this.Row1Value11.TextWrap = false;
			this.Row1Value11.Value = "= Fields.Row1Value11";
			// 
			// Period10
			// 
			this.Period10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(21.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period10.Name = "Period10";
			this.Period10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period10.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period10.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period10.Style.Font.Name = "Calibri";
			this.Period10.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period10.Style.LineColor = System.Drawing.Color.Silver;
			this.Period10.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period10.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period10.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period10.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period10.StyleName = "Normal.TableHeader";
			this.Period10.TextWrap = false;
			this.Period10.Value = "= Fields.Period10";
			// 
			// Period05
			// 
			this.Period05.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.1D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period05.Name = "Period05";
			this.Period05.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period05.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period05.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period05.Style.Font.Name = "Calibri";
			this.Period05.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period05.Style.LineColor = System.Drawing.Color.Silver;
			this.Period05.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period05.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period05.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period05.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period05.StyleName = "Normal.TableHeader";
			this.Period05.TextWrap = false;
			this.Period05.Value = "= Fields.Period05";
			// 
			// Row1Value09
			// 
			this.Row1Value09.Format = "{0:C2}";
			this.Row1Value09.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.9D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value09.Name = "Row1Value09";
			this.Row1Value09.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value09.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value09.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value09.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value09.Style.Font.Name = "Calibri";
			this.Row1Value09.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value09.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value09.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value09.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value09.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value09.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value09.StyleName = "Normal.TableBody";
			this.Row1Value09.TextWrap = false;
			this.Row1Value09.Value = "= Fields.Row1Value09";
			// 
			// Period09
			// 
			this.Period09.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(18.9D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period09.Name = "Period09";
			this.Period09.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period09.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period09.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period09.Style.Font.Name = "Calibri";
			this.Period09.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period09.Style.LineColor = System.Drawing.Color.Silver;
			this.Period09.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period09.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period09.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period09.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period09.StyleName = "Normal.TableHeader";
			this.Period09.TextWrap = false;
			this.Period09.Value = "= Fields.Period09";
			// 
			// Row3Value02
			// 
			this.Row3Value02.Format = "{0:C2}";
			this.Row3Value02.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.5D), Telerik.Reporting.Drawing.Unit.Cm(1.35D));
			this.Row3Value02.Name = "Row3Value02";
			this.Row3Value02.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row3Value02.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row3Value02.Style.Font.Name = "Calibri";
			this.Row3Value02.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row3Value02.Style.LineColor = System.Drawing.Color.Silver;
			this.Row3Value02.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value02.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row3Value02.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row3Value02.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row3Value02.StyleName = "Normal.TableBody";
			this.Row3Value02.TextWrap = false;
			this.Row3Value02.Value = "= Fields.Row3Value02";
			// 
			// Row1Value12
			// 
			this.Row1Value12.Format = "{0:C2}";
			this.Row1Value12.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.5D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value12.Name = "Row1Value12";
			this.Row1Value12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value12.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value12.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value12.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value12.Style.Font.Name = "Calibri";
			this.Row1Value12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value12.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value12.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value12.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value12.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value12.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value12.StyleName = "Normal.TableBody";
			this.Row1Value12.TextWrap = false;
			this.Row1Value12.Value = "= Fields.Row1Value12";
			// 
			// Period12
			// 
			this.Period12.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(25.5D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period12.Name = "Period12";
			this.Period12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period12.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period12.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period12.Style.Font.Name = "Calibri";
			this.Period12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period12.Style.LineColor = System.Drawing.Color.Silver;
			this.Period12.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period12.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period12.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period12.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period12.StyleName = "Normal.TableHeader";
			this.Period12.TextWrap = false;
			this.Period12.Value = "= Fields.Period12";
			// 
			// Period03
			// 
			this.Period03.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(5.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.Period03.Name = "Period03";
			this.Period03.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Period03.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.Period03.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Period03.Style.Font.Name = "Calibri";
			this.Period03.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Period03.Style.LineColor = System.Drawing.Color.Silver;
			this.Period03.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period03.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Period03.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Period03.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Period03.StyleName = "Normal.TableHeader";
			this.Period03.TextWrap = false;
			this.Period03.Value = "= Fields.Period03";
			// 
			// Row1Value10
			// 
			this.Row1Value10.Format = "{0:C2}";
			this.Row1Value10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(21.1D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value10.Name = "Row1Value10";
			this.Row1Value10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2D), Telerik.Reporting.Drawing.Unit.Cm(0.45D));
			this.Row1Value10.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Row1Value10.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Row1Value10.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Row1Value10.Style.Font.Name = "Calibri";
			this.Row1Value10.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
			this.Row1Value10.Style.LineColor = System.Drawing.Color.Silver;
			this.Row1Value10.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value10.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.1D);
			this.Row1Value10.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Row1Value10.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Row1Value10.StyleName = "Normal.TableBody";
			this.Row1Value10.TextWrap = false;
			this.Row1Value10.Value = "= Fields.Row1Value10";
			// 
			// Detail
			// 
			this.Detail.Bindings.Add(new Telerik.Reporting.Binding("Visible", "= IIf(Fields.TransactionDetailReportList.Count = 0, False, True)"));
			this.Detail.CanShrink = true;
			this.Detail.Height = Telerik.Reporting.Drawing.Unit.Cm(1.8D);
			this.Detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DetailTable});
			this.Detail.KeepTogether = false;
			this.Detail.Name = "Detail";
			this.Detail.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Detail.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Detail.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Detail.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Top;
			// 
			// DetailTable
			// 
			this.DetailTable.Bindings.Add(new Telerik.Reporting.Binding("DataSource", "= Fields.TransactionDetailReportList"));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.7D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.5D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.3D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(7.6D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(7.6D)));
			this.DetailTable.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.6D)));
			this.DetailTable.Body.SetCellContent(0, 3, this.AccountName);
			this.DetailTable.Body.SetCellContent(0, 0, this.DocumentNo);
			this.DetailTable.Body.SetCellContent(0, 1, this.DocumentDate);
			this.DetailTable.Body.SetCellContent(0, 2, this.TransactionType);
			this.DetailTable.Body.SetCellContent(0, 5, this.Amount);
			this.DetailTable.Body.SetCellContent(0, 4, this.Description);
			this.DetailTable.Body.SetCellContent(1, 5, this.AmountDetailTotalMonth);
			this.DetailTable.Body.SetCellContent(1, 0, this.TotalDetailMonth, 1, 5);
			tableGroup1.Name = "tableGroup8";
			tableGroup1.ReportItem = this.DocumentNoHeader;
			tableGroup2.Name = "group";
			tableGroup2.ReportItem = this.DocumentDateHeader;
			tableGroup3.Name = "group1";
			tableGroup3.ReportItem = this.TransactionTypeHeader;
			tableGroup4.Name = "tableGroup9";
			tableGroup4.ReportItem = this.AccountNameHeader;
			tableGroup5.Name = "group3";
			tableGroup5.ReportItem = this.DescriptionHeader;
			tableGroup6.Name = "group2";
			tableGroup6.ReportItem = this.AmountHeader;
			this.DetailTable.ColumnGroups.Add(tableGroup1);
			this.DetailTable.ColumnGroups.Add(tableGroup2);
			this.DetailTable.ColumnGroups.Add(tableGroup3);
			this.DetailTable.ColumnGroups.Add(tableGroup4);
			this.DetailTable.ColumnGroups.Add(tableGroup5);
			this.DetailTable.ColumnGroups.Add(tableGroup6);
			this.DetailTable.ColumnHeadersPrintOnEveryPage = true;
			this.DetailTable.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.DocumentNo,
            this.DocumentDate,
            this.TransactionType,
            this.AccountName,
            this.Description,
            this.Amount,
            this.TotalDetailMonth,
            this.AmountDetailTotalMonth,
            this.DocumentNoHeader,
            this.DocumentDateHeader,
            this.TransactionTypeHeader,
            this.AccountNameHeader,
            this.DescriptionHeader,
            this.AmountHeader});
			this.DetailTable.Name = "DetailTable";
			tableGroup9.Name = "group5";
			tableGroup8.ChildGroups.Add(tableGroup9);
			tableGroup8.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.TransactionDetailAllocationId"));
			tableGroup8.Name = "detailTableGroup";
			tableGroup11.Name = "group9";
			tableGroup10.ChildGroups.Add(tableGroup11);
			tableGroup10.Name = "group6";
			tableGroup7.ChildGroups.Add(tableGroup8);
			tableGroup7.ChildGroups.Add(tableGroup10);
			tableGroup7.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.DocumentMonth"));
			tableGroup7.Name = "documentMonth";
			tableGroup7.Sortings.Add(new Telerik.Reporting.Sorting("= Fields.DocumentMonth", Telerik.Reporting.SortDirection.Asc));
			this.DetailTable.RowGroups.Add(tableGroup7);
			this.DetailTable.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(27.7D), Telerik.Reporting.Drawing.Unit.Cm(1.8D));
			// 
			// AccountName
			// 
			this.AccountName.CanGrow = false;
			this.AccountName.Format = "";
			this.AccountName.Name = "AccountName";
			this.AccountName.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccountName.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccountName.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AccountName.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.AccountName.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.AccountName.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.AccountName.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AccountName.Style.Font.Name = "Calibri";
			this.AccountName.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.AccountName.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AccountName.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.AccountName.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AccountName.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AccountName.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AccountName.StyleName = "Normal.TableBody";
			this.AccountName.Value = "= Fields.AccountName";
			// 
			// DocumentNo
			// 
			this.DocumentNo.CanGrow = false;
			this.DocumentNo.Format = "";
			this.DocumentNo.Name = "DocumentNo";
			this.DocumentNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentNo.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentNo.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentNo.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.DocumentNo.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentNo.Style.Font.Name = "Calibri";
			this.DocumentNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentNo.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.DocumentNo.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentNo.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentNo.StyleName = "Normal.TableBody";
			this.DocumentNo.Value = "= Fields.DocumentNo";
			// 
			// DocumentDate
			// 
			this.DocumentDate.CanGrow = false;
			this.DocumentDate.Format = "{0:dd-MMM-yyyy}";
			this.DocumentDate.Name = "DocumentDate";
			this.DocumentDate.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.5D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.DocumentDate.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.DocumentDate.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.DocumentDate.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.DocumentDate.Style.Font.Name = "Calibri";
			this.DocumentDate.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.DocumentDate.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.DocumentDate.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.DocumentDate.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.DocumentDate.StyleName = "Normal.TableBody";
			this.DocumentDate.Value = "= Fields.DocumentDate";
			// 
			// TransactionType
			// 
			this.TransactionType.CanGrow = false;
			this.TransactionType.Name = "TransactionType";
			this.TransactionType.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TransactionType.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TransactionType.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.TransactionType.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.TransactionType.Style.Font.Name = "Calibri";
			this.TransactionType.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.TransactionType.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TransactionType.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TransactionType.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TransactionType.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TransactionType.StyleName = "Normal.TableBody";
			this.TransactionType.Value = "= Fields.TransactionType";
			// 
			// Amount
			// 
			this.Amount.CanGrow = false;
			this.Amount.Format = "{0:c2}";
			this.Amount.Name = "Amount";
			this.Amount.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Amount.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Amount.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Amount.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
			this.Amount.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Amount.Style.Font.Name = "Calibri";
			this.Amount.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Amount.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Amount.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Amount.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Amount.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Amount.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Amount.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Amount.StyleName = "Normal.TableBody";
			this.Amount.Value = "= Fields.AmountGross";
			// 
			// Description
			// 
			this.Description.CanGrow = false;
			this.Description.Name = "Description";
			this.Description.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.6D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.Description.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.Description.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.Description.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.Description.Style.Font.Name = "Calibri";
			this.Description.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Description.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Description.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.Description.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.Description.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Description.StyleName = "Normal.TableBody";
			this.Description.Value = "= Fields.Description";
			// 
			// AmountDetailTotalMonth
			// 
			this.AmountDetailTotalMonth.Format = "{0:c2}";
			this.AmountDetailTotalMonth.Name = "AmountDetailTotalMonth";
			this.AmountDetailTotalMonth.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AmountDetailTotalMonth.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.AmountDetailTotalMonth.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AmountDetailTotalMonth.Style.Font.Name = "Calibri";
			this.AmountDetailTotalMonth.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountDetailTotalMonth.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AmountDetailTotalMonth.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AmountDetailTotalMonth.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AmountDetailTotalMonth.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AmountDetailTotalMonth.StyleName = "Normal.TableBody";
			this.AmountDetailTotalMonth.Value = "= Sum(Fields.AmountGross)";
			// 
			// TotalDetailMonth
			// 
			this.TotalDetailMonth.Name = "TotalDetailMonth";
			this.TotalDetailMonth.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.TotalDetailMonth.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.TotalDetailMonth.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.TotalDetailMonth.Style.Font.Name = "Calibri";
			this.TotalDetailMonth.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalDetailMonth.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.TotalDetailMonth.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.TotalDetailMonth.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.TotalDetailMonth.StyleName = "Normal.TableBody";
			this.TotalDetailMonth.Value = "= \"Total for \" + Fields.ChartOfAccount + \" for \" + Format(\"{0:MMM-yyyy}\", Fields." +
    "DocumentMonth)";
			// 
			// PageFooterSection
			// 
			this.PageFooterSection.Height = Telerik.Reporting.Drawing.Unit.Cm(1D);
			this.PageFooterSection.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.Pages,
            this.CreationTime});
			this.PageFooterSection.Name = "PageFooterSection";
			// 
			// Pages
			// 
			this.Pages.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(22.7D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Name = "Pages";
			this.Pages.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.Pages.Style.Color = System.Drawing.Color.DarkGray;
			this.Pages.Style.Font.Name = "Calibri";
			this.Pages.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.Pages.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.Pages.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.Pages.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.Pages.Value = "= \"Page \" + PageNumber";
			// 
			// CreationTime
			// 
			this.CreationTime.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Name = "CreationTime";
			this.CreationTime.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
			this.CreationTime.Style.Color = System.Drawing.Color.DarkGray;
			this.CreationTime.Style.Font.Name = "Calibri";
			this.CreationTime.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
			this.CreationTime.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0D);
			this.CreationTime.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
			this.CreationTime.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.CreationTime.Value = "= \"Printed by \" + Parameters.creationUser.Value + \" on \" + Format(\"{0:dd-MMM-yyyy" +
    " HH:mm}\", Parameters.creationTime.Value)";
			// 
			// ReportDataSource
			// 
			this.ReportDataSource.DataMember = "GeneralLedgerTransactionReport";
			this.ReportDataSource.DataSource = typeof(Travelog.Reports.GeneralLedger.GeneralLedgerDataSources);
			this.ReportDataSource.Name = "ReportDataSource";
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("customerId", typeof(int), "= Parameters.customerId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("agencyId", typeof(int), "= Parameters.agencyId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("userRoleId", typeof(string), "= Parameters.userRoleId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("transactionViewOptionId", typeof(int), "= Parameters.transactionViewOptionId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("useAltReportingCode", typeof(bool), "= Parameters.useAltReportingCode.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("fiscalYearStartDate", typeof(System.DateTime), "= Parameters.fiscalYearStartDate.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("previousFiscalYearStartDate", typeof(System.DateTime), "= Parameters.previousFiscalYearStartDate.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("includeMonthlyTotals", typeof(bool), "= Parameters.includeMonthlyTotals.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("existingTransactionsOnly", typeof(bool), "= Parameters.existingTransactionsOnly.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateFrom", typeof(System.Nullable<System.DateTime>), "= Parameters.dateFrom.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("dateTo", typeof(System.Nullable<System.DateTime>), "= Parameters.dateTo.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("transactionTypeId", typeof(System.Nullable<int>), "= Parameters.transactionTypeId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("chartOfAccountTypeId", typeof(System.Nullable<int>), "= Parameters.chartOfAccountTypeId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("accountCategoryId", typeof(System.Nullable<int>), "= Parameters.accountCategoryId.Value"));
			this.ReportDataSource.Parameters.Add(new Telerik.Reporting.ObjectDataSourceParameter("chartOfAccountIds", typeof(string), "= Parameters.chartOfAccountIds.Value"));
			// 
			// AccumulatedTotal
			// 
			this.AccumulatedTotal.Format = "{0:c2}";
			this.AccumulatedTotal.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AccumulatedTotal.Name = "AccumulatedTotal";
			this.AccumulatedTotal.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccumulatedTotal.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.AccumulatedTotal.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccumulatedTotal.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AccumulatedTotal.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AccumulatedTotal.Style.Font.Name = "Calibri";
			this.AccumulatedTotal.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AccumulatedTotal.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AccumulatedTotal.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AccumulatedTotal.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
			this.AccumulatedTotal.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AccumulatedTotal.StyleName = "Normal.TableBody";
			this.AccumulatedTotal.Value = "= Fields.AccumulatedTotal";
			// 
			// AccumulatedTotalLabel
			// 
			this.AccumulatedTotalLabel.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
			this.AccumulatedTotalLabel.Name = "AccumulatedTotalLabel";
			this.AccumulatedTotalLabel.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(24.7D), Telerik.Reporting.Drawing.Unit.Cm(0.6D));
			this.AccumulatedTotalLabel.Style.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			this.AccumulatedTotalLabel.Style.BorderColor.Default = System.Drawing.Color.Silver;
			this.AccumulatedTotalLabel.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
			this.AccumulatedTotalLabel.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.5D);
			this.AccumulatedTotalLabel.Style.Font.Name = "Calibri";
			this.AccumulatedTotalLabel.Style.Padding.Bottom = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AccumulatedTotalLabel.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Cm(0.3D);
			this.AccumulatedTotalLabel.Style.Padding.Top = Telerik.Reporting.Drawing.Unit.Cm(0.05D);
			this.AccumulatedTotalLabel.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
			this.AccumulatedTotalLabel.StyleName = "Normal.TableBody";
			this.AccumulatedTotalLabel.Value = "= \"Accumulated Total for \" + Fields.ChartOfAccount";
			// 
			// GeneralLedgerTransactionsReport
			// 
			this.DataSource = this.ReportDataSource;
			group1.GroupFooter = this.GroupFooterSection1;
			group1.GroupHeader = this.GroupHeaderSection1;
			group1.GroupKeepTogether = Telerik.Reporting.GroupKeepTogether.FirstDetail;
			group1.Name = "Group1";
			group2.GroupFooter = this.GroupFooterSection2;
			group2.GroupHeader = this.GroupHeaderSection2;
			group2.Groupings.Add(new Telerik.Reporting.Grouping("= Fields.ChartOfAccountId"));
			group2.Name = "Group2";
			group3.GroupFooter = this.GroupFooterSection3;
			group3.GroupHeader = this.GroupHeaderSection3;
			group3.Name = "Group3";
			this.Groups.AddRange(new Telerik.Reporting.Group[] {
            group1,
            group2,
            group3});
			this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.GroupHeaderSection1,
            this.GroupFooterSection1,
            this.GroupHeaderSection2,
            this.GroupFooterSection2,
            this.GroupHeaderSection3,
            this.GroupFooterSection3,
            this.Detail,
            this.PageFooterSection});
			this.Name = "GeneralLedgerTransactionsReport";
			this.PageSettings.Landscape = true;
			this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D), Telerik.Reporting.Drawing.Unit.Cm(1D));
			this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
			reportParameter1.Name = "customerId";
			reportParameter2.Name = "agencyId";
			reportParameter2.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter3.Name = "userRoleId";
			reportParameter4.Name = "customerName";
			reportParameter5.Name = "reportName";
			reportParameter6.Name = "reportDate";
			reportParameter7.Name = "headerContent";
			reportParameter8.Name = "creationUser";
			reportParameter9.Name = "creationTime";
			reportParameter9.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter10.Name = "transactionViewOptionId";
			reportParameter10.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter11.Name = "transactionDateOptionId";
			reportParameter11.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter12.Name = "generalLedgerReportTypeId";
			reportParameter12.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter13.Name = "useAltReportingCode";
			reportParameter13.Type = Telerik.Reporting.ReportParameterType.Boolean;
			reportParameter14.Name = "fiscalYearStartDate";
			reportParameter14.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter15.Name = "previousFiscalYearStartDate";
			reportParameter15.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter16.Name = "includeMonthlyTotals";
			reportParameter16.Type = Telerik.Reporting.ReportParameterType.Boolean;
			reportParameter17.Name = "existingTransactionsOnly";
			reportParameter17.Type = Telerik.Reporting.ReportParameterType.Boolean;
			reportParameter18.AllowNull = true;
			reportParameter18.Name = "dateFrom";
			reportParameter18.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter19.AllowNull = true;
			reportParameter19.Name = "dateTo";
			reportParameter19.Type = Telerik.Reporting.ReportParameterType.DateTime;
			reportParameter20.AllowNull = true;
			reportParameter20.Name = "transactionTypeId";
			reportParameter20.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter21.AllowNull = true;
			reportParameter21.Name = "chartOfAccountTypeId";
			reportParameter21.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter22.AllowNull = true;
			reportParameter22.Name = "accountCategoryId";
			reportParameter22.Type = Telerik.Reporting.ReportParameterType.Integer;
			reportParameter23.Name = "chartOfAccountIds";
			reportParameter24.Name = "column1Label";
			reportParameter25.Name = "column2Label";
			reportParameter26.Name = "column3Label";
			this.ReportParameters.Add(reportParameter1);
			this.ReportParameters.Add(reportParameter2);
			this.ReportParameters.Add(reportParameter3);
			this.ReportParameters.Add(reportParameter4);
			this.ReportParameters.Add(reportParameter5);
			this.ReportParameters.Add(reportParameter6);
			this.ReportParameters.Add(reportParameter7);
			this.ReportParameters.Add(reportParameter8);
			this.ReportParameters.Add(reportParameter9);
			this.ReportParameters.Add(reportParameter10);
			this.ReportParameters.Add(reportParameter11);
			this.ReportParameters.Add(reportParameter12);
			this.ReportParameters.Add(reportParameter13);
			this.ReportParameters.Add(reportParameter14);
			this.ReportParameters.Add(reportParameter15);
			this.ReportParameters.Add(reportParameter16);
			this.ReportParameters.Add(reportParameter17);
			this.ReportParameters.Add(reportParameter18);
			this.ReportParameters.Add(reportParameter19);
			this.ReportParameters.Add(reportParameter20);
			this.ReportParameters.Add(reportParameter21);
			this.ReportParameters.Add(reportParameter22);
			this.ReportParameters.Add(reportParameter23);
			this.ReportParameters.Add(reportParameter24);
			this.ReportParameters.Add(reportParameter25);
			this.ReportParameters.Add(reportParameter26);
			this.Width = Telerik.Reporting.Drawing.Unit.Cm(27.7D);
			((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private Telerik.Reporting.DetailSection Detail;
		private Telerik.Reporting.ObjectDataSource ReportDataSource;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection1;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection1;
		private Telerik.Reporting.PageFooterSection PageFooterSection;
		private Telerik.Reporting.TextBox Pages;
		private Telerik.Reporting.TextBox CreationTime;
		private Telerik.Reporting.SubReport ManagementReportHeaderSubReport1;
		private Telerik.Reporting.TextBox NameHeader;
		private Telerik.Reporting.TextBox CodeHeader;
		private Telerik.Reporting.TextBox Code;
		private Telerik.Reporting.TextBox NameField;
		private Telerik.Reporting.TextBox ChartOfAccountTypeHeader;
		private Telerik.Reporting.TextBox ChartOfAccountTypeDescription;
		private Telerik.Reporting.TextBox AccountCategory;
		private Telerik.Reporting.TextBox AccountCategoryHeader;
		private Telerik.Reporting.TextBox ChartOfAccountTransactionType;
		private Telerik.Reporting.TextBox ChartOfAccountTransactionTypeHeader;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection2;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection2;
		private Telerik.Reporting.TextBox AccountName;
		private Telerik.Reporting.TextBox DocumentNo;
		private Telerik.Reporting.TextBox DocumentDate;
		private Telerik.Reporting.TextBox TransactionType;
		private Telerik.Reporting.TextBox Amount;
		private Telerik.Reporting.TextBox Description;
		private Telerik.Reporting.TextBox DocumentNoHeader;
		private Telerik.Reporting.TextBox DocumentDateHeader;
		private Telerik.Reporting.TextBox TransactionTypeHeader;
		private Telerik.Reporting.TextBox AccountNameHeader;
		private Telerik.Reporting.TextBox DescriptionHeader;
		private Telerik.Reporting.TextBox AmountHeader;
		private Telerik.Reporting.TextBox Period04;
		private Telerik.Reporting.TextBox Row3Value01;
		private Telerik.Reporting.TextBox Period08;
		private Telerik.Reporting.TextBox Row2Value12;
		private Telerik.Reporting.TextBox Row2Value05;
		private Telerik.Reporting.TextBox Period11;
		private Telerik.Reporting.TextBox MonthLabel;
		private Telerik.Reporting.TextBox Period02;
		private Telerik.Reporting.TextBox Row2Value09;
		private Telerik.Reporting.TextBox Row1Label;
		private Telerik.Reporting.TextBox Period07;
		private Telerik.Reporting.TextBox Row2Value06;
		private Telerik.Reporting.TextBox Row1Value01;
		private Telerik.Reporting.TextBox Row1Value02;
		private Telerik.Reporting.TextBox Row1Value03;
		private Telerik.Reporting.TextBox Row1Value04;
		private Telerik.Reporting.TextBox Row1Value05;
		private Telerik.Reporting.TextBox Row1Value06;
		private Telerik.Reporting.TextBox Row1Value07;
		private Telerik.Reporting.TextBox Row2Value08;
		private Telerik.Reporting.TextBox Row3Label;
		private Telerik.Reporting.TextBox Period06;
		private Telerik.Reporting.TextBox Row2Value07;
		private Telerik.Reporting.TextBox Row3Value12;
		private Telerik.Reporting.TextBox Row2Label;
		private Telerik.Reporting.TextBox Row2Value01;
		private Telerik.Reporting.TextBox Row2Value02;
		private Telerik.Reporting.TextBox Row2Value03;
		private Telerik.Reporting.TextBox Row2Value04;
		private Telerik.Reporting.TextBox Row3Value03;
		private Telerik.Reporting.TextBox Row3Value04;
		private Telerik.Reporting.TextBox Row3Value05;
		private Telerik.Reporting.TextBox Row3Value06;
		private Telerik.Reporting.TextBox Row3Value07;
		private Telerik.Reporting.TextBox Period01;
		private Telerik.Reporting.TextBox Row3Value08;
		private Telerik.Reporting.TextBox Row2Value10;
		private Telerik.Reporting.TextBox Row3Value10;
		private Telerik.Reporting.TextBox Row3Value11;
		private Telerik.Reporting.TextBox Row1Value08;
		private Telerik.Reporting.TextBox Row3Value09;
		private Telerik.Reporting.TextBox Row1Value11;
		private Telerik.Reporting.TextBox Period10;
		private Telerik.Reporting.TextBox Period05;
		private Telerik.Reporting.TextBox Row1Value09;
		private Telerik.Reporting.TextBox Period09;
		private Telerik.Reporting.TextBox Row3Value02;
		private Telerik.Reporting.TextBox Row1Value12;
		private Telerik.Reporting.TextBox Period12;
		private Telerik.Reporting.TextBox Period03;
		private Telerik.Reporting.TextBox Row1Value10;
		private Telerik.Reporting.TextBox Row2Value11;
		private Telerik.Reporting.GroupHeaderSection GroupHeaderSection3;
		private Telerik.Reporting.GroupFooterSection GroupFooterSection3;
		private Telerik.Reporting.TextBox YtdBalanceHeader;
		private Telerik.Reporting.TextBox YtdBalance;
		private Telerik.Reporting.Crosstab DetailTable;
		private Telerik.Reporting.TextBox TotalsLabel;
		private Telerik.Reporting.TextBox BalanceTotal;
		private Telerik.Reporting.TextBox AmountDetailTotalMonth;
		private Telerik.Reporting.TextBox TotalDetailMonth;
		private Telerik.Reporting.TextBox NoData;
		private Telerik.Reporting.TextBox AccumulatedTotalLabel;
		private Telerik.Reporting.TextBox AccumulatedTotal;
	}
}