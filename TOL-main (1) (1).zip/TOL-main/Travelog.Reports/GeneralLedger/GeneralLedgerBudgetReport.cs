using Telerik.Reporting;

namespace Travelog.Reports.GeneralLedger {
	public partial class GeneralLedgerBudgetReport : TelerikReport {
		public GeneralLedgerBudgetReport() {
			InitializeComponent();
		}
	}
}