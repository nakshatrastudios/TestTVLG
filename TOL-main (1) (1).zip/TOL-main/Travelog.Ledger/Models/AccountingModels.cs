﻿using Travelog.Biz;
using Travelog.Biz.Enums;

namespace Travelog.Ledger.Models {
	public class TransactionViewModel {
		public int TransactionId { get; set; }
		public TransactionType TransactionType { get; set; }
		public DocumentStatus DocumentStatus { get; set; }
		public ReversalStatus ReversalStatus { get; set; }
		public int TransactionRefId { get; set; }
		public string DocumentType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public bool IsDebtorReceipt { get; set; }
		public bool IsIssued { get; set; }

		public bool CanEdit { get; set; }
		public bool CanDelete { get; set; }
		public bool CanUndo { get; set; }
		public bool CanReverse { get; set; }
		public string EditText {
			get {
				return CanEdit ? "Edit" : "View";
			}
		}
		public string DeleteText {
			get {
				return CanDelete ? "Delete" : CanUndo ? "Undo" : CanReverse ? TransactionType == TransactionType.Invoice || TransactionType == TransactionType.CreditNote ? "Reissue" : "Reverse" : "None";
			}
		}

		public decimal TotalDebit { get; set; }
		public decimal TotalCredit { get; set; }
		public decimal TotalCommission { get; set; }
		public decimal TotalDiscount { get; set; }
		public decimal TotalNonCommissionable { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public string TransactionTypeDescription { get { return TransactionType.GetEnumDescription(); } }
		public string ReversalStatusDescription { get { return ReversalStatus.GetEnumDescription(); } }
		public string CombinedStatusDescription { get { return string.Concat(DocumentStatusDescription, ReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", ReversalStatusDescription)); } }
		public string DocumentDateString { get { return DocumentDate.ToShortDateStringExt(); } }
		public string DocumentStatusDescription {
			get {
				if (DocumentStatus == DocumentStatus.DepositedPaid) {
					return TransactionType == TransactionType.Receipt ? "Deposited"
						: TransactionType == TransactionType.Bsp || TransactionType == TransactionType.NonBsp || TransactionType == TransactionType.Payment ? "Paid"
						: DocumentStatus.GetEnumDescription();
				}

				return DocumentStatus.GetEnumDescription();
			}
		}
		public MenuPageType MenuPageType {
			get {
				return TransactionType == TransactionType.Receipt ? MenuPageType.Receipt
					: TransactionType == TransactionType.Bsp ? MenuPageType.Bsp
					: TransactionType == TransactionType.NonBsp ? MenuPageType.NonBsp
					: TransactionType == TransactionType.Payment ? MenuPageType.Payment
					: TransactionType == TransactionType.Invoice || TransactionType == TransactionType.CreditNote ? MenuPageType.Invoice
					: TransactionType == TransactionType.Journal ? MenuPageType.Journal
					: TransactionType == TransactionType.Adjustment ? MenuPageType.Adjustment
					: MenuPageType.Undefined;
			}
		}
	}

	public class TransactionDetailViewModel {
		public long TransactionDetailId { get; set; }
		public int TransactionId { get; set; }
		public int TransactionRefId { get; set; }
        public int TransactionDetailRefId { get; set; }
        public LedgerType LedgerType { get; set; }
		public TransactionType TransactionType { get; set; }
		public SignType SignType { get; set; }
		public DocumentStatus DocumentStatus { get; set; }
		public ReversalStatus ReversalStatus { get; set; }
		public string DocumentNo { get; set; }
		public string DocumentNoLink { get; set; }
		public DateTime DocumentDate { get; set; }

        public int AgencyId { get; set; }
        public int TripId { get; set; }
		public int DebtorId { get; set; }
		public int CreditorId { get; set; }
		public int ChartOfAccountId { get; set; }

		public string AccountNameLink { get; set; }
		public string AccountName { get; set; }
		public string Reference { get; set; }
		public string Description { get; set; }

		public decimal Debit { get; set; }
		public decimal Credit { get; set; }
		public decimal Commission { get; set; }
		public decimal CommissionTax { get; set; }
		public decimal CommissionGross { get { return Commission + CommissionTax; } }
		public decimal Discount { get; set; }
		public decimal DiscountTax { get; set; }
		public decimal DiscountGross { get { return Discount + DiscountTax; } }
		public decimal NonCommissionable { get; set; }
		public decimal NonCommissionableTax { get; set; }
		public decimal Amount { get; set; }
		public decimal Tax { get; set; }
		public TransactionDetailType TransactionDetailType { get; set; }
		public TransactionAnalysisType TransactionAnalysisType { get; set; }
		public bool IsAllocation { get; set; }
		public bool IsCreditCardDebtorAllocation { get; set; }
		public bool IsCash { get; set; }
		public bool IntegrityCheckFailed { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string LastWriteUser { get; set; }
		public string CreationUser { get; set; }

		public decimal CumulativeCommission { get; set; }
		public decimal CumulativeCommissionTax { get; set; }
		public decimal CumulativeDiscount { get; set; }
		public decimal CumulativeDiscountTax { get; set; }
		public decimal CumulativeMarkup { get; set; }
		public decimal CumulativeMarkupTax { get; set; }
		public decimal CumulativeMarkupGrossOther { get; set; }
		public decimal CumulativeNonCommissionable { get; set; }
		public decimal CumulativeNonCommissionableTax { get; set; }
		public decimal CumulativeClientRefund { get; set; }
		public decimal CumulativeClientRefundTax { get; set; }
		public decimal CumulativeOriginalSaleTotal { get; set; }
		public decimal CumulativeOriginalSaleTotalTax { get; set; }
		public decimal CumulativeCancellationFee { get; set; }
		public decimal CumulativeCancellationFeeTax { get; set; }
		public decimal CumulativeSupplierCancellationFee { get; set; }
		public decimal CumulativeSupplierCancellationFeeTax { get; set; }
		public decimal CumulativeAmountPayable { get; set; }
		public decimal CumulativeAmountPayableTax { get; set; }

		public string LedgerTypeDescription { get { return LedgerType.GetEnumDescription(); } }
		public string TransactionTypeDescription { get { return TransactionType.GetEnumDescription(); } }
		public string ReversalStatusDescription { get { return ReversalStatus.GetEnumDescription(); } }
		public string CombinedStatusDescription { get { return string.Concat(DocumentStatusDescription, ReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", ReversalStatusDescription)); } }
		public string DocumentDateString { get { return DocumentDate.ToShortDateStringExt(); } }
		public string DocumentStatusDescription {
			get {
				if (DocumentStatus == DocumentStatus.DepositedPaid) {
					return TransactionType == TransactionType.Receipt ? "Deposited"
						: TransactionType == TransactionType.Bsp || TransactionType == TransactionType.NonBsp || TransactionType == TransactionType.Payment ? "Paid"
						: DocumentStatus.GetEnumDescription();
				}

				return DocumentStatus.GetEnumDescription();
			}
		}
	}

    public class TransactionDetailAllocationViewModel {
        public long TransactionDetailOrAllocationId { get; set; }
        public int TransactionId { get; set; }
        public long TransactionDetailId { get; set; }
        public int TransactionRefId { get; set; }
        public int TransactionDetailRefId { get; set; }
        public int PaymentTransactionId { get; set; }
        public int ReceiptDetailId { get; set; }
        public int NonBspDetailId { get; set; }
        public int PaymentDetailId { get; set; }
        public int InvoiceDetailId { get; set; }
        public int JournalDetailId { get; set; }
        public int AdjustmentId { get; set; }
        public TransactionType TransactionType { get; set; }
        public SignType SignType { get; set; }
        public string DocumentNo { get; set; }
        public string DocumentNoLink { get; set; }
        public DateTime DocumentDate { get; set; }
        public string Description { get; set; }
        public string Reference { get; set; }
        public decimal Amount { get; set; }
        public decimal AmountNet { get; set; }
        public decimal AmountGross { get; set; }
        public decimal? Debit { get; set; }
        public decimal? Credit { get; set; }
        public TransactionMatchStatus TransactionMatchStatus { get; set; }
        public bool IsMasterDocument { get; set; }
        public string TransactionTypeDescription { get { return TransactionType.GetEnumDescription(); } }
        public string TransactionMatchStatusDescription { get { return TransactionMatchStatus.GetEnumDescription(); } }
        public string DocumentDateString { get { return DocumentDate.ToShortDateStringExt(); } }
    }

    public class TransactionDetailAllocationMappingModel {
        public int TransactionId { get; set; }
        public TransactionDetailType TransactionDetailType { get; set; }
        public LedgerType LedgerType { get; set; }
        public SignType SignType { get; set; }
        public int TripId { get; set; }
        public int DebtorId { get; set; }
        public int CreditorId { get; set; }
        public int ChartOfAccountId { get; set; }
        public int ReceiptDetailId { get; set; }
        public int NonBspDetailId { get; set; }
        public int PaymentDetailId { get; set; }
        public int InvoiceDetailId { get; set; }
        public int JournalDetailId { get; set; }
        public int AdjustmentId { get; set; }
        public int AllocationReceiptDetailId { get; set; }
        public int AllocationNonBspDetailId { get; set; }
        public int AllocationPaymentDetailId { get; set; }
        public int AllocationInvoiceDetailId { get; set; }
        public int AllocationJournalDetailId { get; set; }
        public int AllocationAdjustmentId { get; set; }
        public decimal AllocationAmount { get; set; }
        public decimal AllocationMerchantFee { get; set; }
        public decimal AllocationMerchantFeeTax { get; set; }
        public string AllocationReference { get; set; }
        public TransactionMatchStatus AllocationMatchStatus { get; set; }
        public int AllocationGroupNo { get; set; }
        public bool IsCreditCardDebtor { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }
    }

    public class SalesAnalysisMappingModel {
        public int TransactionId { get; set; }
        public TransactionDetailType TransactionDetailType { get; set; }
        public LedgerType LedgerType { get; set; }
        public SignType SignType { get; set; }
        public int TripId { get; set; }
        public int DebtorId { get; set; }
        public int CreditorId { get; set; }
        public int ChartOfAccountId { get; set; }
        public int ReceiptDetailId { get; set; }
        public int NonBspDetailId { get; set; }
        public int PaymentDetailId { get; set; }
        public int InvoiceDetailId { get; set; }
        public int JournalDetailId { get; set; }
        public int AdjustmentId { get; set; }
        public int SalesAnalysisDebtorId { get; set; }
        public int SalesAnalysisGroupId { get; set; }
        public int SalesAnalysisClassId { get; set; }
        public int SalesAnalysisDestinationId { get; set; }
        public int SalesAnalysisRegionId { get; set; }
        public int SalesAnalysisLocationId { get; set; }
        public int SalesAnalysisAgentId { get; set; }
    }

	public class TransactionDetailExportModel {
		public string TransactionType { get; set; }
		public string DocumentNo { get; set; }
		public string DocumentType { get; set; }
		public DateTime DocumentDate { get; set; }
		public string DocumentStatus { get; set; }
		public string ReversalStatus { get; set; }
		public string AccountName { get; set; }
		public string LedgerType { get; set; }
		public string Description { get; set; }
		public string Reference { get; set; }
		public decimal Commission { get; set; }
		public decimal CommissionTax { get; set; }
		public decimal Discount { get; set; }
		public decimal DiscountTax { get; set; }
		public decimal NonCommissionable { get; set; }
		public decimal NonCommissionableTax { get; set; }
		public decimal Amount { get; set; }
		public decimal Tax { get; set; }
	}

	public class FinancialIntegrityViewModel {
		public int FinancialIntegrityId { get; set; }
		public int SettingId { get; set; }
		public string AccountName { get; set; }
		public DateTime FiscalYearStartDate { get; set; }
		public string FiscalYearStartDateName { get; set; }
		public decimal LedgerAccountTotal { get; set; }
		public decimal GlAccountTotal { get; set; }
        public int FailureCount { get; set; }
        public decimal Balance { get { return LedgerAccountTotal - GlAccountTotal; } }
        public string AccountNameDescription { get { return FailureCount == 0 ? AccountName : string.Concat(@"<span style=""color: ", AppConstants.DefaultHighlightColor, @""">", AccountName, " [", FailureCount, " failures]</span>"); } }
    }

    public class FinancialIntegrityDetailExportModel {
		public string FiscalYear { get; set; }
		public string GLAccount { get; set; }
		public string AccountName { get; set; }
		public string LedgerType { get; set; }
		public string TransactionType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string DocumentStatus { get; set; }
		public string Reference { get; set; }
		public string Description { get; set; }
		public decimal Commission { get; set; }
		public decimal CommissionTax { get; set; }
		public decimal Discount { get; set; }
		public decimal DiscountTax { get; set; }
		public decimal NonCommissionable { get; set; }
		public decimal NonCommissionableTax { get; set; }
		public decimal Amount { get; set; }
		public decimal Tax { get; set; }
	}
}