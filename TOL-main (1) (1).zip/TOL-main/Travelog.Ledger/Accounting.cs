﻿using System.Security.Principal;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Dao.StaticMethods;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;
using Travelog.Biz.Resources;
using Travelog.Ledger.Models;
using Setting = Travelog.Biz.Dao.GeneralLedger.Setting;

namespace Travelog.Ledger.Accounting {
    public static class Transactions {
        private const string ClassName = "Travelog.Ledger.Accounting.Transactions";

        public static void UpdateTransactions<T>(this T entity, IPrincipal principal, int customerId, AppLazyContext lazyContext = null, TripLine tripLine = null, List<ReceiptMerchantFeeModel> merchantFees = null, bool isBatchMode = false) where T : class {
            if (tripLine?.TripLineType == TripLineType.Remark)
                return;

            bool disposeContext = false;

            if (lazyContext == null) {
                lazyContext = new AppLazyContext(principal, customerId, false, false);
                disposeContext = true;
            }

            try {
                entity.UpdateTransactions(lazyContext, customerId, merchantFees, isBatchMode);

                if (tripLine?.Id > 0)
                    tripLine.Update(principal, customerId, lazyContext);
            }
            finally {
                if (disposeContext)
                    lazyContext.Dispose();
            }
        }

        public static void UpdateTransactions<T>(this T entity, AppLazyContext lazyContext, int customerId, List<ReceiptMerchantFeeModel> merchantFees = null, bool isBatchMode = false) where T : class {
            var transactionType = TransactionType.All;
            var accountType = AccountType.None;
            var transactionAccountType = AccountType.None;

            int tripId = -1;
            int debtorId = -1;
            int creditorId = -1;
            int chartOfAccountId = -1;
            int transactionRefId = 0;

            var transactions = new List<Transaction>();

            bool result = entity.SetValues(lazyContext, transactions, ref transactionType, ref accountType, ref transactionAccountType, ref tripId, ref debtorId, ref creditorId, ref chartOfAccountId, ref transactionRefId, isBatchMode);

            if (!result)
                return;

            int[] transactionIds = transactions.Select(t => t.Id).ToArray();

            var salesAnalysisList = lazyContext.TransactionDetail.Where(t1 => transactionIds.Contains(t1.TransactionId)).AsEnumerable().Where(t => TransactionDetail.SalesAnalysisWhereClause.Compile().Invoke(t)).Select(row => new SalesAnalysisMappingModel {
                TransactionId = row.TransactionId,
                TransactionDetailType = row.TransactionDetailType,
                LedgerType = row.LedgerType,
                SignType = row.SignType,
                TripId = row.TripId,
                DebtorId = row.DebtorId,
                CreditorId = row.CreditorId,
                ChartOfAccountId = row.ChartOfAccountId,
                ReceiptDetailId = row.ReceiptDetailId,
                NonBspDetailId = row.NonBspDetailId,
                PaymentDetailId = row.PaymentDetailId,
                InvoiceDetailId = row.InvoiceDetailId,
                JournalDetailId = row.JournalDetailId,
                AdjustmentId = row.Transaction.AdjustmentId,
                SalesAnalysisDebtorId = row.Transaction.TransactionType == TransactionType.Bsp
                    || (row.Transaction.TransactionType == TransactionType.NonBsp && row.Transaction.NonBsp.NonBspType != NonBspType.Admin)
                    || (row.Transaction.TransactionType == TransactionType.Payment && row.Transaction.Payment.PaymentType == PaymentType.SupplierPayment) ? row.SalesAnalysisDebtorId : 0,

                SalesAnalysisGroupId = (row.Transaction.TransactionType == TransactionType.Receipt && (row.Transaction.Receipt.ReceiptType == ReceiptType.OtherCommission || row.Transaction.Receipt.ReceiptType == ReceiptType.Refund))
                    || row.Transaction.TransactionType == TransactionType.Bsp
                    || (row.Transaction.TransactionType == TransactionType.NonBsp && row.Transaction.NonBsp.NonBspType != NonBspType.Admin)
                    || (row.Transaction.TransactionType == TransactionType.Payment && row.Transaction.Payment.PaymentType == PaymentType.SupplierPayment) ? row.SalesAnalysisGroupId : 0,

                SalesAnalysisDestinationId = (row.Transaction.TransactionType == TransactionType.Receipt && (row.Transaction.Receipt.ReceiptType == ReceiptType.OtherCommission || row.Transaction.Receipt.ReceiptType == ReceiptType.Refund))
                    || (row.Transaction.TransactionType == TransactionType.Payment && row.Transaction.Payment.PaymentType == PaymentType.SupplierPayment) ? row.SalesAnalysisDestinationId : 0,

                SalesAnalysisRegionId = (row.Transaction.TransactionType == TransactionType.Receipt && (row.Transaction.Receipt.ReceiptType == ReceiptType.OtherCommission || row.Transaction.Receipt.ReceiptType == ReceiptType.Refund))
                    || (row.Transaction.TransactionType == TransactionType.Payment && row.Transaction.Payment.PaymentType == PaymentType.SupplierPayment) ? row.SalesAnalysisRegionId : 0,

                SalesAnalysisAgentId = (row.Transaction.TransactionType == TransactionType.Receipt && (row.Transaction.Receipt.ReceiptType == ReceiptType.OtherCommission || row.Transaction.Receipt.ReceiptType == ReceiptType.Refund))
                    || (row.Transaction.TransactionType == TransactionType.Payment && row.Transaction.Payment.PaymentType == PaymentType.SupplierPayment) ? row.SalesAnalysisAgentId : 0,

                SalesAnalysisClassId = row.SalesAnalysisClassId,
                SalesAnalysisLocationId = row.SalesAnalysisLocationId
            }).ToList();

            var allocationList = lazyContext.TransactionDetailAllocation.Where(t1 => transactionIds.Contains(t1.TransactionDetail.TransactionId) || (t1.ReceiptDetailId > 0 && t1.ReceiptDetail.ReceiptId == transactionRefId && t1.ReceiptDetail.Receipt.Debtor.FormOfPayments.Any(t2 => t2.Id > 0 && t2.DebtorId > 0))).Select(row => new TransactionDetailAllocationMappingModel {
                TransactionId = row.TransactionDetail.TransactionId,
                TransactionDetailType = row.TransactionDetail.TransactionDetailType,
                LedgerType = row.TransactionDetail.LedgerType,
                SignType = row.TransactionDetail.SignType,
                TripId = row.TransactionDetail.TripId,
                DebtorId = row.TransactionDetail.DebtorId,
                CreditorId = row.TransactionDetail.CreditorId,
                ChartOfAccountId = row.TransactionDetail.ChartOfAccountId,
                ReceiptDetailId = row.TransactionDetail.ReceiptDetailId,
                NonBspDetailId = row.TransactionDetail.NonBspDetailId,
                PaymentDetailId = row.TransactionDetail.PaymentDetailId,
                InvoiceDetailId = row.TransactionDetail.InvoiceDetailId,
                JournalDetailId = row.TransactionDetail.JournalDetailId,
                AdjustmentId = row.TransactionDetail.Transaction.AdjustmentId,
                AllocationReceiptDetailId = row.ReceiptDetailId,
                AllocationNonBspDetailId = row.NonBspDetailId,
                AllocationPaymentDetailId = row.PaymentDetailId,
                AllocationInvoiceDetailId = row.InvoiceDetailId,
                AllocationJournalDetailId = row.JournalDetailId,
                AllocationAdjustmentId = row.AdjustmentId,
                AllocationAmount = row.Amount,
                AllocationMerchantFee = row.MerchantFee,
                AllocationMerchantFeeTax = row.MerchantFeeTax,
                AllocationReference = row.Reference,
                AllocationMatchStatus = row.TransactionMatchStatus,
                AllocationGroupNo = row.GroupNo,
                IsCreditCardDebtor = row.ReceiptDetailId > 0 && row.ReceiptDetail.ReceiptId == transactionRefId && row.ReceiptDetail.Receipt.Debtor.IsCreditCardDebtor,
                LastWriteTime = row.LastWriteTime,
                CreationTime = row.CreationTime,
                LastWriteUser = row.LastWriteUser,
                CreationUser = row.CreationUser
            }).ToList();

            var transactionList = new List<TransactionViewModel>();
            var transactionDetailList = new List<TransactionDetailViewModel>();

            AddRows(lazyContext, transactionList, transactionDetailList, transactionType, accountType, transactionRefId, merchantFees, isBatchMode);

            var q = (from txn in transactions.DefaultIfEmpty()
                     from txnItem in transactionList.DefaultIfEmpty()
                     where txn == null || txnItem == null || (txn.ReceiptId == (txn.TransactionType == TransactionType.Receipt ? txnItem.TransactionRefId : -1)
                     && txn.BspId == (txn.TransactionType == TransactionType.Bsp ? txnItem.TransactionRefId : -1)
                     && txn.NonBspId == (txn.TransactionType == TransactionType.NonBsp ? txnItem.TransactionRefId : -1)
                     && txn.PaymentId == (txn.TransactionType == TransactionType.Payment ? txnItem.TransactionRefId : -1)
                     && txn.InvoiceId == (txn.TransactionType == TransactionType.Invoice ? txnItem.TransactionRefId : -1)
                     && txn.JournalId == (txn.TransactionType == TransactionType.Journal ? txnItem.TransactionRefId : -1)
                     && txn.AdjustmentId == (txn.TransactionType == TransactionType.Adjustment ? txnItem.TransactionRefId : -1))
                     select new { txn, txnItem }).ToList();

            foreach (var row in q.Where(t => t.txn != null && t.txnItem != null)) {
                row.txnItem.TransactionId = row.txn.Id;
            }

            int count = 0;

            foreach (var txn in transactionList) {
                count++;

                int txnId = txn.TransactionId <= 0 ? -1 : txn.TransactionId;
                var txnDetailItems = transactionDetailList.Where(t => t.TransactionId == txnId || t.TransactionId <= 0 || t.TransactionDetailId <= 0).ToList();

                if (txnId == -1 && txnDetailItems.Count == 0)
                    continue;

                var transaction = lazyContext.Transaction.Include(t => t.TransactionDetails).ThenInclude(t => t.TransactionDetailAllocations).Single(t => t.Id == txnId);

                if (transaction.Id == -1) {
                    transaction = transaction.Clone() as Transaction;
                    transaction.Id = 0;
                }

                transaction.UpdateEntity(lazyContext, txn);

                lazyContext.RemoveRange(lazyContext.TransactionDetailAllocation.Where(t => t.TransactionDetail.TransactionId == transaction.Id));
                lazyContext.RemoveRange(lazyContext.TransactionDetail.Where(t => t.TransactionId == transaction.Id));
                lazyContext.SaveChanges();

                foreach (var txnDetail in txnDetailItems) {
                    var transactionDetail = lazyContext.TransactionDetail.Single(t => t.Id == -1).Clone() as TransactionDetail;

                    transactionDetail.Id = 0;
                    transactionDetail.TransactionId = transaction.Id;
                    transactionDetail.Transaction = transaction;

                    transactionDetail.UpdateEntity(lazyContext, txnDetail, salesAnalysisList, false);
                }

                if (allocationList.Count > 0) {
                    foreach (var allocation in allocationList.Where(t => t.TransactionId == txnId)) {
                        var transactionDetail = lazyContext.TransactionDetail.SingleOrDefault(t => t.TransactionId == allocation.TransactionId && t.ReceiptDetailId == allocation.ReceiptDetailId && t.NonBspDetailId == allocation.NonBspDetailId && t.PaymentDetailId == allocation.PaymentDetailId && t.InvoiceDetailId == allocation.InvoiceDetailId && t.JournalDetailId == allocation.JournalDetailId && t.Transaction.AdjustmentId == allocation.AdjustmentId
                            && t.LedgerType == allocation.LedgerType && t.SignType == allocation.SignType && t.TransactionDetailType == allocation.TransactionDetailType && t.TripId == allocation.TripId && t.DebtorId == allocation.DebtorId && t.CreditorId == allocation.CreditorId && t.ChartOfAccountId == allocation.ChartOfAccountId);

                        if (transactionDetail == null)
                            continue;

                        var allocationRow = new TransactionDetailAllocation {
                            Id = 0,
                            TransactionDetailId = transactionDetail.Id,
                            ReceiptDetailId = allocation.AllocationReceiptDetailId,
                            NonBspDetailId = allocation.AllocationNonBspDetailId,
                            PaymentDetailId = allocation.AllocationPaymentDetailId,
                            InvoiceDetailId = allocation.AllocationInvoiceDetailId,
                            JournalDetailId = allocation.AllocationJournalDetailId,
                            AdjustmentId = allocation.AllocationAdjustmentId,
                            Amount = allocation.AllocationAmount,
                            MerchantFee = allocation.AllocationMerchantFee,
                            MerchantFeeTax = allocation.AllocationMerchantFeeTax,
                            Reference = allocation.AllocationReference,
                            TransactionMatchStatus = allocation.AllocationMatchStatus,
                            GroupNo = allocation.AllocationGroupNo,
                            LastWriteTime = allocation.LastWriteTime,
                            CreationTime = allocation.CreationTime,
                            LastWriteUser = allocation.LastWriteUser,
                            CreationUser = allocation.CreationUser
                        };

                        lazyContext.Entry(allocationRow).State = EntityState.Added;
                        lazyContext.SaveChanges();
                    }

                    if (count == transactionList.Count) {
                        foreach (int groupNo in allocationList.Where(t => t.IsCreditCardDebtor).Select(t => t.AllocationGroupNo).Distinct()) {
                            AddMerchantFeeReducedCommissionRows(lazyContext, salesAnalysisList, groupNo);
                        }
                    }
                }

                var glSetting = Setting.GetRow(lazyContext, transaction.DocumentDate);
                var txnDetails = lazyContext.TransactionDetail.Where(t => t.TransactionId == transaction.Id).ToList();

                if (txnDetails.Any(t => t.Transaction.Receipt.ReceiptType == ReceiptType.Admin) && txnDetails.Any(t => t.ChartOfAccountId != glSetting.PurchasesTaxAccount.Id && t.ChartOfAccountId != glSetting.SalesTaxAccount.Id)) {
                    foreach (var txnDetail in txnDetails.Where(t => t.Tax != 0 && t.ChartOfAccountId > 0 && t.ChartOfAccountId == t.ReceiptDetail.Receipt.BankAccount.ChartOfAccountId).ToList()) {
                        txnDetail.Commission = txnDetail.Amount;
                        txnDetail.CommissionTax = txnDetail.Tax;

                        if (txnDetail.TransactionAnalysisType != TransactionAnalysisType.SalesAnalysis && txnDetail.TransactionAnalysisType != TransactionAnalysisType.SalesAnalysisAndTaxAuditReport)
                            txnDetail.TransactionAnalysisType = TransactionAnalysisType.TaxAuditReport;

                        lazyContext.Save(txnDetail, false);
                    }
                }
                else if (txnDetails.Any(t => t.Transaction.Receipt.ReceiptType == ReceiptType.Debtor && t.TransactionDetailType == TransactionDetailType.MerchantFee && (t.ChartOfAccountId == glSetting.PurchasesTaxAccount.Id || t.ChartOfAccountId == glSetting.SalesTaxAccount.Id))) {
                    foreach (var txnDetail in txnDetails.Where(t => t.GetMerchantFeeTax(customerId) != 0 && t.TransactionDetailType == TransactionDetailType.MerchantFee).ToList()) {
                        if (txnDetail.TransactionAnalysisType != TransactionAnalysisType.SalesAnalysis && txnDetail.TransactionAnalysisType != TransactionAnalysisType.SalesAnalysisAndTaxAuditReport)
                            txnDetail.TransactionAnalysisType = TransactionAnalysisType.TaxAuditReport;

                        lazyContext.Save(txnDetail, false);
                    }
                }
                else if (txnDetails.Any(t => t.Transaction.NonBsp.NonBspType == NonBspType.Admin) && txnDetails.Any(t => t.ChartOfAccountId == glSetting.PurchasesTaxAccount.Id || t.ChartOfAccountId == glSetting.SalesTaxAccount.Id)) {
                    foreach (var txnDetail in txnDetails.Where(t => t.Tax != 0 && t.ChartOfAccountId > 0 && t.ChartOfAccountId == Setting.GetRow(lazyContext, t.Transaction.DocumentDate).CreditorControlAccount.Id).ToList()) {
                        if (txnDetail.TransactionAnalysisType != TransactionAnalysisType.SalesAnalysis && txnDetail.TransactionAnalysisType != TransactionAnalysisType.SalesAnalysisAndTaxAuditReport)
                            txnDetail.TransactionAnalysisType = TransactionAnalysisType.TaxAuditReport;

                        lazyContext.Save(txnDetail, false);
                    }
                }
                else if (txnDetails.Any(t => t.Transaction.Payment.PaymentType == PaymentType.Admin) && txnDetails.Any(t => t.ChartOfAccountId == glSetting.PurchasesTaxAccount.Id || t.ChartOfAccountId == glSetting.SalesTaxAccount.Id)) {
                    foreach (var txnDetail in txnDetails.Where(t => t.Tax != 0 && t.ChartOfAccountId > 0 && t.ChartOfAccountId == t.PaymentDetail.Payment.BankAccount.ChartOfAccountId).ToList()) {
                        if (txnDetail.TransactionAnalysisType != TransactionAnalysisType.SalesAnalysis && txnDetail.TransactionAnalysisType != TransactionAnalysisType.SalesAnalysisAndTaxAuditReport)
                            txnDetail.TransactionAnalysisType = TransactionAnalysisType.TaxAuditReport;

                        lazyContext.Save(txnDetail, false);
                    }
                }
                else if (txnDetails.Any(t => t.Transaction.Invoice.AccountType == AccountType.GeneralLedger) && txnDetails.Any(t => t.ChartOfAccountId == glSetting.SalesTaxAccount.Id)) {
                    foreach (var txnDetail in txnDetails.Where(t => t.Tax != 0 && t.ChartOfAccountId > 0 && t.ChartOfAccountId == Setting.GetRow(lazyContext, t.Transaction.DocumentDate).DebtorControlAccount.Id).ToList()) {
                        foreach (var row in txnDetails.Where(t => t.Transaction.Invoice.AccountType == AccountType.GeneralLedger && t.TransactionDetailType == TransactionDetailType.Discount).ToList()) {
                            if (row.ChartOfAccountId == glSetting.SalesTaxAccount.Id) {
                                txnDetail.DiscountTax = row.Amount;
                            }
                            else {
                                txnDetail.Discount = row.Amount;
                            }
                        }

                        if (txnDetail.TransactionAnalysisType != TransactionAnalysisType.SalesAnalysis && txnDetail.TransactionAnalysisType != TransactionAnalysisType.SalesAnalysisAndTaxAuditReport)
                            txnDetail.TransactionAnalysisType = TransactionAnalysisType.TaxAuditReport;

                        lazyContext.Save(txnDetail, false);
                    }
                }
            }
        }

        private static bool SetValues<T>(this T entity, AppLazyContext lazyContext, List<Transaction> transactions, ref TransactionType transactionType, ref AccountType accountType, ref AccountType transactionAccountType, ref int tripId, ref int debtorId, ref int creditorId, ref int chartOfAccountId, ref int transactionRefId, bool isBatchMode) where T : class {
            if (entity.GetType() == typeof(Receipt) || entity.GetType().BaseType == typeof(Receipt)) {
                var receipt = entity as Receipt;
                transactionType = TransactionType.Receipt;
                accountType = receipt.AccountType;
                transactionAccountType = receipt.TransactionAccountType;

                tripId = receipt.TripId;
                debtorId = receipt.DebtorId;
                creditorId = receipt.CreditorId;
                chartOfAccountId = receipt.ChartOfAccountId;
                transactionRefId = receipt.Id;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.ReceiptId == receipt.Id));
            }
            else if (entity.GetType() == typeof(ReceiptDetail) || entity.GetType().BaseType == typeof(ReceiptDetail)) {
                var receiptDetail = entity as ReceiptDetail;
                transactionType = TransactionType.Receipt;
                accountType = receiptDetail.Receipt.AccountType;
                transactionAccountType = receiptDetail.Receipt.TransactionAccountType;

                tripId = receiptDetail.Receipt.TripId;
                debtorId = receiptDetail.Receipt.DebtorId;
                creditorId = receiptDetail.Receipt.CreditorId;
                chartOfAccountId = receiptDetail.Receipt.ChartOfAccountId;
                transactionRefId = receiptDetail.ReceiptId;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.ReceiptId == receiptDetail.ReceiptId));
            }
            else if (entity.GetType() == typeof(Bsp) || entity.GetType().BaseType == typeof(Bsp)) {
                var bsp = entity as Bsp;
                transactionType = TransactionType.Bsp;
                accountType = AccountType.Client;
                transactionAccountType = AccountType.None;

                tripId = bsp.TripId;
                debtorId = -1;
                creditorId = bsp.CreditorId;
                chartOfAccountId = -1;
                transactionRefId = bsp.Id;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.BspId == bsp.Id));
            }
            else if (entity.GetType() == typeof(BspDetail) || entity.GetType().BaseType == typeof(BspDetail)) {
                var bspDetail = entity as BspDetail;
                transactionType = TransactionType.Bsp;
                accountType = AccountType.Client;
                transactionAccountType = AccountType.None;

                tripId = bspDetail.Bsp.TripId;
                debtorId = -1;
                creditorId = bspDetail.Bsp.CreditorId;
                chartOfAccountId = -1;
                transactionRefId = bspDetail.BspId;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.BspId == bspDetail.BspId));
            }
            else if (entity.GetType() == typeof(NonBsp) || entity.GetType().BaseType == typeof(NonBsp)) {
                var nonBsp = entity as NonBsp;
                transactionType = TransactionType.NonBsp;
                transactionAccountType = AccountType.None;
                transactionRefId = nonBsp.Id;

                if (nonBsp.LoyaltySchemeReceiptDetailId > 0 && nonBsp.LoyaltySchemeReceiptDetail.Receipt.DebtorId > 0) {
                    accountType = AccountType.Debtor;
                    debtorId = nonBsp.LoyaltySchemeReceiptDetail.Receipt.DebtorId;
                }
                else {
                    accountType = nonBsp.AccountType;
                    debtorId = -1;
                }

                tripId = nonBsp.TripId;
                creditorId = nonBsp.CreditorId;
                chartOfAccountId = nonBsp.ChartOfAccountId;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.NonBspId == nonBsp.Id));
            }
            else if (entity.GetType() == typeof(NonBspDetail) || entity.GetType().BaseType == typeof(NonBspDetail)) {
                var nonBspDetail = entity as NonBspDetail;
                transactionType = TransactionType.NonBsp;
                transactionAccountType = AccountType.None;
                transactionRefId = nonBspDetail.NonBspId;

                if (nonBspDetail.NonBsp.LoyaltySchemeReceiptDetailId > 0 && nonBspDetail.NonBsp.LoyaltySchemeReceiptDetail.Receipt.DebtorId > 0) {
                    accountType = AccountType.Debtor;
                    debtorId = nonBspDetail.NonBsp.LoyaltySchemeReceiptDetail.Receipt.DebtorId;
                }
                else {
                    accountType = nonBspDetail.NonBsp.AccountType;
                    debtorId = -1;
                }

                tripId = nonBspDetail.NonBsp.TripId;
                creditorId = nonBspDetail.NonBsp.CreditorId;
                chartOfAccountId = nonBspDetail.NonBsp.ChartOfAccountId;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.NonBspId == nonBspDetail.NonBspId));
            }
            else if (entity.GetType() == typeof(Payment) || entity.GetType().BaseType == typeof(Payment)) {
                var payment = entity as Payment;
                transactionType = TransactionType.Payment;
                accountType = payment.AccountType;
                transactionAccountType = AccountType.None;

                tripId = payment.TripId;
                debtorId = -1;
                creditorId = payment.CreditorId;
                chartOfAccountId = payment.ChartOfAccountId;
                transactionRefId = payment.Id;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.PaymentId == payment.Id));
            }
            else if (entity.GetType() == typeof(PaymentDetail) || entity.GetType().BaseType == typeof(PaymentDetail)) {
                var paymentDetail = entity as PaymentDetail;
                transactionType = TransactionType.Payment;
                accountType = paymentDetail.Payment.AccountType;
                transactionAccountType = AccountType.None;

                tripId = paymentDetail.Payment.TripId;
                debtorId = -1;
                creditorId = paymentDetail.Payment.CreditorId;
                chartOfAccountId = paymentDetail.Payment.ChartOfAccountId;
                transactionRefId = paymentDetail.PaymentId;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.PaymentId == paymentDetail.PaymentId));
            }
            else if (entity.GetType() == typeof(Invoice) || entity.GetType().BaseType == typeof(Invoice)) {
                var invoice = entity as Invoice;
                transactionType = TransactionType.Invoice;
                accountType = invoice.AccountType;
                transactionAccountType = AccountType.None;

                tripId = -1;
                debtorId = invoice.Debtor.BillingHeadDebtor.Id;
                creditorId = -1;
                chartOfAccountId = -1;
                transactionRefId = invoice.Id;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.InvoiceId == invoice.Id));
            }
            else if (entity.GetType() == typeof(InvoiceDetail) || entity.GetType().BaseType == typeof(InvoiceDetail)) {
                var invoiceDetail = entity as InvoiceDetail;
                transactionType = TransactionType.Invoice;
                accountType = invoiceDetail.Invoice.AccountType;
                transactionAccountType = AccountType.None;

                tripId = invoiceDetail.TripId;
                debtorId = invoiceDetail.Invoice.Debtor.BillingHeadDebtor.Id;
                creditorId = -1;
                chartOfAccountId = invoiceDetail.ChartOfAccountId;
                transactionRefId = invoiceDetail.InvoiceId;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.InvoiceId == invoiceDetail.InvoiceId));
            }
            else if (entity.GetType() == typeof(Journal) || entity.GetType().BaseType == typeof(Journal)) {
                var journal = entity as Journal;
                transactionType = TransactionType.Journal;
                accountType = AccountType.None;
                transactionAccountType = AccountType.None;

                tripId = -1;
                debtorId = -1;
                creditorId = -1;
                chartOfAccountId = -1;
                transactionRefId = journal.Id;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.JournalId == journal.Id));
            }
            else if (entity.GetType() == typeof(JournalDetail) || entity.GetType().BaseType == typeof(JournalDetail)) {
                var journalDetail = entity as JournalDetail;
                transactionType = TransactionType.Journal;
                accountType = journalDetail.AccountType;
                transactionAccountType = AccountType.None;

                tripId = journalDetail.TripId;
                debtorId = journalDetail.DebtorId;
                creditorId = journalDetail.CreditorId;
                chartOfAccountId = journalDetail.ChartOfAccountId;
                transactionRefId = journalDetail.JournalId;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.JournalId == journalDetail.JournalId));
            }
            else if (entity.GetType() == typeof(Adjustment) || entity.GetType().BaseType == typeof(Adjustment)) {
                var adjustment = entity as Adjustment;
                transactionType = TransactionType.Adjustment;
                accountType = AccountType.None;
                transactionAccountType = AccountType.None;

                tripId = adjustment.DebitType == DebitCreditType.Client && adjustment.DebitTripId > 0 ? adjustment.DebitTripId : adjustment.CreditType == DebitCreditType.Client ? adjustment.CreditTripId : -1;
                debtorId = adjustment.DebitType == DebitCreditType.Debtor && adjustment.DebitDebtorId > 0 ? adjustment.DebitDebtorId : adjustment.CreditType == DebitCreditType.Debtor ? adjustment.CreditDebtorId : -1;
                creditorId = adjustment.DebitType == DebitCreditType.Creditor && adjustment.DebitCreditorId > 0 ? adjustment.DebitCreditorId : adjustment.CreditType == DebitCreditType.Creditor ? adjustment.CreditCreditorId : -1;
                chartOfAccountId = adjustment.DebitType == DebitCreditType.GeneralLedger && adjustment.DebitChartOfAccountId > 0 ? adjustment.DebitChartOfAccountId : adjustment.CreditType == DebitCreditType.GeneralLedger ? adjustment.CreditCreditorId : -1;
                transactionRefId = adjustment.Id;

                transactions.AddRange(lazyContext.Transaction.Where(t => t.AdjustmentId == adjustment.Id));
            }
            else {
                HandleException("Invalid Entity Type", string.Format("Entity type {0} is invalid.", entity.GetType()), false, isBatchMode);
                return false;
            }

            return true;
        }

        private static void AddRows(AppLazyContext lazyContext, List<TransactionViewModel> transactionList, List<TransactionDetailViewModel> transactionDetailList, TransactionType transactionType, AccountType accountType, int transactionRefId, List<ReceiptMerchantFeeModel> merchantFees, bool isBatchMode = false) {
            Receipt receipt = null;
            Bsp bsp = null;
            NonBsp nonBsp = null;
            Payment payment = null;
            Invoice invoice = null;
            Journal journal = null;
            Adjustment adjustment = null;

            bool result = false;

            switch (transactionType) {
                case TransactionType.Receipt:
                    receipt = lazyContext.Receipt.Find(transactionRefId);

                    if (receipt.IsLegacy || receipt.IsDeposit || receipt.ReceiptDetails.Count == 0)
                        return;

                    if (receipt.ChartOfAccount.RowType != RowType.Normal && receipt.ChartOfAccount.RowType != RowType.RetainedProfits) {
                        HandleException("Chart of Account Misposting", string.Format("Receipt No {0}: Chart of Account does not have a valid Row Type.", receipt.DocumentNo), false, isBatchMode);
                        return;
                    }

                    if (receipt.AgencyId <= 0) {
                        HandleException("Agency Not Specified", string.Format("Receipt No {0}: {1}", receipt.DocumentNo, AppConstants.AgencyNotSpecified), true, isBatchMode);
                        return;
                    }

                    if (receipt.ReverseTransferReceiptId > 0) {
                        result = transactionDetailList.AddReceiptDetailAutoGeneratedRows(lazyContext, receipt);
                    }
                    else {
                        result = transactionDetailList.AddReceiptDetailRows(lazyContext, receipt, merchantFees);
                    }

                    if (result)
                        transactionList.AddRow(receipt.Id, TransactionType.Receipt, receipt.DocumentStatus, receipt.ReceiptType.GetEnumDescription(), receipt.DocumentNo, receipt.DocumentDate);

                    break;
                case TransactionType.Bsp:
                    bsp = lazyContext.Bsp.Find(transactionRefId);

                    if (bsp.IsLegacy || bsp.BspType == BspType.Conjunction || bsp.BspType == BspType.Free || bsp.BspType == BspType.Void || bsp.BspDetails.Count == 0)
                        return;

                    if (bsp.AgencyId <= 0) {
                        HandleException("Agency Not Specified", string.Format("BSP No {0}: {1}", bsp.DocumentNo, AppConstants.AgencyNotSpecified), true, isBatchMode);
                        return;
                    }

                    if (!bsp.Creditor.IsBspAgent) {
                        HandleException("Invalid Creditor", string.Format("BSP No {0}: The creditor assigned to this document cannot accept BSP returns.", bsp.DocumentNo), true, isBatchMode);
                        return;
                    }

                    if (bsp.BspDetails.Count(t => t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross) > 1 && bsp.BspDetails.Any(t => t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardNet && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardGross)) {
                        HandleException("Invalid Form of Payment", string.Format("BSP No {0}: Form of Payment Type 'Agency Credit Card' cannot be included with other Forms of Payment.", bsp.DocumentNo), true, isBatchMode);
                        return;
                    }

                    if (bsp.AgencyCreditCardBspId > 0) {
                        result = transactionDetailList.AddBspDetailAutoGeneratedRows(lazyContext, bsp);
                    }
                    else {
                        result = transactionDetailList.AddBspDetailRows(lazyContext, bsp);
                    }

                    if (result)
                        transactionList.AddRow(bsp.Id, TransactionType.Bsp, bsp.DocumentStatus, bsp.BspType.GetEnumDescription(), bsp.DocumentNo, bsp.DocumentDate);

                    break;
                case TransactionType.NonBsp:
                    nonBsp = lazyContext.NonBsp.Find(transactionRefId);

                    if (nonBsp.IsLegacy || nonBsp.NonBspDetails.Count == 0)
                        return;

                    if (nonBsp.ChartOfAccount.RowType != RowType.Normal && nonBsp.ChartOfAccount.RowType != RowType.RetainedProfits) {
                        HandleException("Chart of Account Misposting", string.Format("Non-BSP No {0}: Chart of Account does not have a valid Row Type.", nonBsp.DocumentNo), false, isBatchMode);
                        return;
                    }

                    if (nonBsp.AgencyId <= 0) {
                        HandleException("Agency Not Specified", string.Format("Non-BSP No {0}: {1}", nonBsp.DocumentNo, AppConstants.AgencyNotSpecified), true, isBatchMode);
                        return;
                    }

                    if (nonBsp.NonBspDetails.Any(t => t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || t.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross) && nonBsp.NonBspDetails.Any(t => t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardNet && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.AgencyCreditCardGross && t.FormOfPayment.FormOfPaymentType != FormOfPaymentType.PaySupplierGross)) {
                        HandleException("Invalid Form of Payment", string.Format("Non-BSP No {0}: Form of Payment Type 'Agency Credit Card' or 'Pay Supplier Gross' cannot be included with other Forms of Payment.", nonBsp.DocumentNo), true, isBatchMode);
                        return;
                    }

                    if (nonBsp.AgencyCreditCardBspId > 0 || nonBsp.AgencyCreditCardNonBspId > 0 || nonBsp.SupplierOtherCommissionReceiptId > 0) {
                        result = transactionDetailList.AddNonBspDetailAutoGeneratedRows(lazyContext, nonBsp);
                    }
                    else {
                        result = transactionDetailList.AddNonBspDetailRows(lazyContext, nonBsp, accountType);
                    }

                    if (result)
                        transactionList.AddRow(nonBsp.Id, TransactionType.NonBsp, nonBsp.DocumentStatus, nonBsp.NonBspType.GetEnumDescription(), nonBsp.DocumentNo, nonBsp.DocumentDate);

                    break;
                case TransactionType.Payment:
                    payment = lazyContext.Payment.Find(transactionRefId);

                    if (payment.IsLegacy || payment.PaymentDetails.Count == 0)
                        return;

                    if (payment.ChartOfAccount.RowType != RowType.Normal && payment.ChartOfAccount.RowType != RowType.RetainedProfits) {
                        HandleException("Chart of Account Misposting", string.Format("Payment No {0}: Chart of Account does not have a valid Row Type.", payment.DocumentNo), false, isBatchMode);
                        return;
                    }

                    if (payment.AgencyId <= 0) {
                        HandleException("Agency Not Specified", string.Format("Payment No {0}: {1}", payment.DocumentNo, AppConstants.AgencyNotSpecified), true, isBatchMode);
                        return;
                    }

                    if (transactionDetailList.AddPaymentDetailRows(lazyContext, payment, accountType))
                        transactionList.AddRow(payment.Id, TransactionType.Payment, payment.DocumentStatus, payment.PaymentType.GetEnumDescription(), payment.DocumentNo, payment.DocumentDate);

                    break;
                case TransactionType.Invoice:
                    invoice = lazyContext.Invoice.Find(transactionRefId);

                    if (invoice.InvoiceDetails.Count == 0)
                        return;

                    if (invoice.InvoiceDetails.Any(t => t.ChartOfAccount.RowType != RowType.Normal && t.ChartOfAccount.RowType != RowType.RetainedProfits)) {
                        HandleException("Chart of Account Misposting", string.Format("Invoice No {0}: Chart of Account does not have a valid Row Type.", invoice.DocumentNo), false, isBatchMode);
                        return;
                    }

                    if (invoice.Debtor.AgencyId <= 0) {
                        HandleException("Agency Not Specified", string.Format("Invoice No {0}: {1}", invoice.DocumentNo, AppConstants.AgencyNotSpecified), true, isBatchMode);
                        return;
                    }

                    if (transactionDetailList.AddInvoiceDetailRows(lazyContext, invoice))
                        transactionList.AddRow(invoice.Id, TransactionType.Invoice, invoice.DocumentStatus, invoice.InvoiceType.GetEnumDescription(), invoice.DocumentNo, invoice.DocumentDate);

                    break;
                case TransactionType.Journal:
                    journal = lazyContext.Journal.Find(transactionRefId);

                    if (journal.JournalDetails.Count == 0 || journal.DocumentStatus != DocumentStatus.Closed)
                        return;

                    if (journal.JournalDetails.Any(t => t.ChartOfAccount.RowType != RowType.Normal && t.ChartOfAccount.RowType != RowType.RetainedProfits)) {
                        HandleException("Chart of Account Misposting", string.Format("Journal No {0}: Chart of Account does not have a valid Row Type.", journal.DocumentNo), false, isBatchMode);
                        return;
                    }

                    if (transactionDetailList.AddJournalDetailRows(lazyContext, journal))
                        transactionList.AddRow(journal.Id, TransactionType.Journal, journal.DocumentStatus, "Journal", journal.DocumentNo, journal.DocumentDate);

                    break;
                case TransactionType.Adjustment:
                    adjustment = lazyContext.Adjustment.Find(transactionRefId);

                    if (adjustment.DebitAgencyId <= 0) {
                        HandleException("Agency Not Specified", string.Format("Adjustment No {0}: {1}", adjustment.DocumentNo, AppConstants.AgencyNotSpecified), true, isBatchMode);
                        return;
                    }

                    if (transactionDetailList.AddAdjustmentRows(lazyContext, adjustment))
                        transactionList.AddRow(adjustment.Id, TransactionType.Adjustment, adjustment.DocumentStatus, "Adjustment", adjustment.DocumentNo, adjustment.DocumentDate);

                    break;
            }

            decimal amount = transactionDetailList.Where(t => t.LedgerType == LedgerType.GeneralLedger).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;

            if (amount == 0 || transactionType == TransactionType.Journal)
                return;

            string message = null;

            switch (transactionType) {
                default:
                    return;
                case TransactionType.Receipt:
                    if ((receipt.ReceiptType == ReceiptType.OtherCommission && receipt.SupplierCommissionType == SupplierCommissionType.Creditor) || receipt.ReceiptType == ReceiptType.Transfer)
                        return;

                    message = string.Format("Receipt No {0}: An amount of {1:c2} has been misposted.", receipt.DocumentNo, amount);
                    break;
                case TransactionType.Bsp:
                    if (bsp.AgencyCreditCardBspId > 0)
                        return;

                    message = string.Format("BSP No {0}: An amount of {1:c2} has been misposted.", bsp.DocumentNo, amount);
                    break;
                case TransactionType.NonBsp:
                    if (nonBsp.AgencyCreditCardBspId > 0 || nonBsp.AgencyCreditCardNonBspId > 0 || nonBsp.SupplierOtherCommissionReceiptId > 0)
                        return;

                    message = string.Format("Non-BSP No {0}: An amount of {1:c2} has been misposted.", nonBsp.DocumentNo, amount);
                    break;
                case TransactionType.Payment:
                    message = string.Format("Payment No {0}: An amount of {1:c2} has been misposted.", payment.DocumentNo, amount);
                    break;
                case TransactionType.Invoice:
                    message = string.Format("Invoice No {0}: An amount of {1:c2} has been misposted.", invoice.DocumentNo, amount);
                    break;
                case TransactionType.Adjustment:
                    message = string.Format("Adjustment No {0}: An amount of {1:c2} has been misposted.", adjustment.DocumentNo, amount);
                    break;
            }

            HandleException("General Ledger Misposting", message, false, isBatchMode);
        }

        private static bool AddReceiptDetailRows(this List<TransactionDetailViewModel> transactionDetailList, AppLazyContext lazyContext, Receipt receipt, List<ReceiptMerchantFeeModel> merchantFees) {
            var transactionDetail = new TransactionDetailViewModel {
                TransactionId = -2,
                TransactionType = TransactionType.Receipt,
                AgencyId = receipt.AgencyId
            };

            string reference = string.Empty;

            decimal amount = 0;
            decimal tax = 0;
            decimal commission = 0;
            decimal commissionTax = 0;
            decimal discount = 0;
            decimal discountTax = 0;
            decimal nonCommissionable = 0;
            decimal nonCommissionableTax = 0;
            decimal clientRefund = 0;
            decimal clientRefundTax = 0;
            decimal originalSaleTotal = 0;
            decimal originalSaleTotalTax = 0;
            decimal cancellationFee = 0;
            decimal cancellationFeeTax = 0;
            decimal supplierCancellationFee = 0;
            decimal supplierCancellationFeeTax = 0;
            decimal totalAmount = 0;

            decimal ledgerNonCommissionable = 0;
            decimal ledgerNonCommissionableTax = 0;
            decimal ledgerCommission = 0;
            decimal ledgerCommissionTax = 0;
            decimal ledgerDiscount = 0;
            decimal ledgerDiscountTax = 0;

            bool isCash = false;
            bool isCcDebtorReceipt = false;

            SignType signType;
            var glSetting = Setting.GetRow(lazyContext, receipt.DocumentDate);

            var chartOfAccount = receipt.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, receipt.AgencyId);
            ChartOfAccount ccChargeAccount = null;

            int ledgerDebtorId = receipt.Debtor.BillingHeadDebtor.Id;
            int ledgerCreditorId = receipt.CreditorId;
            int ledgerChartOfAccountId = 0;

            var receiptDetails = receipt.ReceiptDetails;
            totalAmount = receiptDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;

            if (receipt.TransactionAccountType == AccountType.Debtor) {
                ccChargeAccount = receipt.Debtor.CreditCardChartOfAccount.Id > 0 ? receipt.Debtor.CreditCardChartOfAccount : glSetting.CreditCardChargeAccount;
                isCcDebtorReceipt = ccChargeAccount.Id > 0;
            }
            else {
                ccChargeAccount = null;
                isCcDebtorReceipt = false;
            }

            foreach (var row in receiptDetails) {
                decimal merchantFee = merchantFees?.Where(t => t.ReceiptDetailId == row.Id).Sum(t => (decimal?)t.MerchantFee) ?? 0;
                decimal merchantFeeTax = merchantFees?.Where(t => t.ReceiptDetailId == row.Id).Sum(t => (decimal?)t.MerchantFeeTax) ?? 0;

                int ledgerTripId = receipt.ReceiptType == ReceiptType.VoucherCommission ? row.Voucher.TripId : receipt.TripId;

                transactionDetail.TransactionDetailRefId = row.Id;
                transactionDetail.DocumentStatus = row.DocumentStatus;
                transactionDetail.ReversalStatus = row.ReversalStatus;
                transactionDetail.Description = row.PassengerId <= 0 ? row.TripLineAirPassenger.Passenger.FullName : row.Passenger.FullName;

                isCash = row.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard;

                if (row.Receipt.ReceiptDetails.Count > 1 && row.Receipt.ReceiptDetails.Last().Id == row.Id) {
                    var q = transactionDetailList.Where(t => t.TransactionDetailRefId != row.Id);
                    commission = row.Receipt.Commission - (q.Sum(t => (decimal?)t.CumulativeCommission) ?? 0);
                    commissionTax = row.Receipt.CommissionTax - (q.Sum(t => (decimal?)t.CumulativeCommissionTax) ?? 0);
                    discount = row.Receipt.Discount - (q.Sum(t => (decimal?)t.CumulativeDiscount) ?? 0);
                    discountTax = row.Receipt.DiscountTax - (q.Sum(t => (decimal?)t.CumulativeDiscountTax) ?? 0);
                    nonCommissionable = row.Receipt.NonCommissionable - (q.Sum(t => (decimal?)t.CumulativeNonCommissionable) ?? 0);
                    nonCommissionableTax = row.Receipt.NonCommissionableTax - (q.Sum(t => (decimal?)t.CumulativeNonCommissionableTax) ?? 0);
                    clientRefund = row.Receipt.ClientRefund - (q.Sum(t => (decimal?)t.CumulativeClientRefund) ?? 0);
                    clientRefundTax = row.Receipt.ClientRefundTax - (q.Sum(t => (decimal?)t.CumulativeClientRefundTax) ?? 0);
                    originalSaleTotal = row.Receipt.OriginalSaleTotal - (q.Sum(t => (decimal?)t.CumulativeOriginalSaleTotal) ?? 0);
                    originalSaleTotalTax = row.Receipt.OriginalSaleTotalTax - (q.Sum(t => (decimal?)t.CumulativeOriginalSaleTotalTax) ?? 0);
                    cancellationFee = row.Receipt.CancellationFee - (q.Sum(t => (decimal?)t.CumulativeCancellationFee) ?? 0);
                    cancellationFeeTax = row.Receipt.CancellationFeeTax - (q.Sum(t => (decimal?)t.CumulativeCancellationFeeTax) ?? 0);
                    supplierCancellationFee = row.Receipt.SupplierCancellationFee - (q.Sum(t => (decimal?)t.CumulativeSupplierCancellationFee) ?? 0);
                    supplierCancellationFeeTax = row.Receipt.SupplierCancellationFeeTax - (q.Sum(t => (decimal?)t.CumulativeSupplierCancellationFeeTax) ?? 0);
                }
                else {
                    decimal proRataRatio = row.Receipt.ReceiptDetails.Count == 1 ? 1 : totalAmount == 0 ? 1 / row.Receipt.ReceiptDetails.Count : (row.Amount + row.Tax) / totalAmount;
                    decimal discountProRataRatio = row.DiscountProRataRatio;

                    commission = Math.Round(row.Receipt.Commission * proRataRatio, 2);
                    commissionTax = Math.Round(row.Receipt.CommissionTax * proRataRatio, 2);
                    discount = Math.Round(row.Receipt.Discount * discountProRataRatio, 2);
                    discountTax = Math.Round(row.Receipt.DiscountTax * discountProRataRatio, 2);
                    nonCommissionable = Math.Round(row.Receipt.NonCommissionable * proRataRatio, 2);
                    nonCommissionableTax = Math.Round(row.Receipt.NonCommissionableTax * proRataRatio, 2);
                    clientRefund = Math.Round(row.Receipt.ClientRefund * proRataRatio, 2);
                    clientRefundTax = Math.Round(row.Receipt.ClientRefundTax * proRataRatio, 2);
                    originalSaleTotal = Math.Round(row.Receipt.OriginalSaleTotal * proRataRatio, 2);
                    originalSaleTotalTax = Math.Round(row.Receipt.OriginalSaleTotalTax * proRataRatio, 2);
                    cancellationFee = Math.Round(row.Receipt.CancellationFee * proRataRatio, 2);
                    cancellationFeeTax = Math.Round(row.Receipt.CancellationFeeTax * proRataRatio, 2);
                    supplierCancellationFee = Math.Round(row.Receipt.SupplierCancellationFee * proRataRatio, 2);
                    supplierCancellationFeeTax = Math.Round(row.Receipt.SupplierCancellationFeeTax * proRataRatio, 2);
                }

                transactionDetail.CumulativeCommission = commission;
                transactionDetail.CumulativeCommissionTax = commissionTax;
                transactionDetail.CumulativeDiscount = discount;
                transactionDetail.CumulativeDiscountTax = discountTax;
                transactionDetail.CumulativeNonCommissionable = nonCommissionable;
                transactionDetail.CumulativeNonCommissionableTax = nonCommissionableTax;
                transactionDetail.CumulativeClientRefund = clientRefund;
                transactionDetail.CumulativeClientRefundTax = clientRefundTax;
                transactionDetail.CumulativeOriginalSaleTotal = originalSaleTotal;
                transactionDetail.CumulativeOriginalSaleTotalTax = originalSaleTotalTax;
                transactionDetail.CumulativeCancellationFee = cancellationFee;
                transactionDetail.CumulativeCancellationFeeTax = cancellationFeeTax;
                transactionDetail.CumulativeSupplierCancellationFee = supplierCancellationFee;
                transactionDetail.CumulativeSupplierCancellationFeeTax = supplierCancellationFeeTax;

                switch (row.Receipt.TransactionAccountType) {
                    case AccountType.Client:
                        if (ledgerTripId <= 0)
                            break;

                        if (row.Receipt.ReceiptType == ReceiptType.VoucherCommission) {
                            ledgerChartOfAccountId = chartOfAccount.Id;

                            //Desktop Version Reference: T130
                            reference = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name;
                            signType = SignType.Credit;
                            amount = -originalSaleTotal;
                            tax = -originalSaleTotalTax;
                            transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.ExcludeFromSalesAnalysis);

                            //Desktop Version Reference: T131
                            reference = "Non-BSP";
                            signType = SignType.Debit;
                            amount = originalSaleTotal;
                            tax = originalSaleTotalTax;
                            ledgerCommission = row.Amount;
                            ledgerCommissionTax = row.Tax;
                            transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, ledgerCommission, ledgerCommissionTax, 0, 0, 0, 0, amount, tax, isCash);
                        }
                        else {
                            //Desktop Version Reference: T122
                            ledgerChartOfAccountId = chartOfAccount.Id;
                            reference = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name;
                            signType = SignType.Credit;

                            if (row.Receipt.ReceiptType == ReceiptType.Refund) {
                                amount = -originalSaleTotal;
                                tax = -originalSaleTotalTax;
                                ledgerNonCommissionable = -nonCommissionable;
                                ledgerNonCommissionableTax = -nonCommissionableTax;
                                ledgerCommission = -commission;
                                ledgerCommissionTax = -commissionTax;
                                ledgerDiscount = 0;
                                ledgerDiscountTax = 0;
                            }
                            else {
                                amount = -row.Amount;
                                tax = -row.Tax;
                                ledgerNonCommissionable = nonCommissionable;
                                ledgerNonCommissionableTax = nonCommissionableTax;
                                ledgerCommission = commission;
                                ledgerCommissionTax = commissionTax;
                                ledgerDiscount = discount;
                                ledgerDiscountTax = discountTax;
                            }

                            transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, ledgerCommission, ledgerCommissionTax, ledgerDiscount, ledgerDiscountTax, ledgerNonCommissionable, ledgerNonCommissionableTax, amount, tax, isCash);
                        }

                        if (row.Receipt.ReceiptType == ReceiptType.Refund) {
                            //Desktop Version Reference: T124
                            if (discount != 0) {
                                ledgerChartOfAccountId = chartOfAccount.Id;
                                reference = "Discount";
                                signType = SignType.Credit;
                                amount = discount;
                                tax = discountTax;
                                ledgerDiscount = discount;
                                ledgerDiscountTax = discountTax;
                                transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, ledgerDiscount, ledgerDiscountTax, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);
                            }

                            //Desktop Version Reference: T123
                            if (cancellationFee != 0) {
                                ledgerChartOfAccountId = chartOfAccount.Id;
                                reference = "Cancellation Fee";
                                signType = SignType.Credit;
                                ledgerCommission = cancellationFee;
                                ledgerCommissionTax = cancellationFeeTax;
                                amount = cancellationFee;
                                tax = cancellationFeeTax;
                                transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, ledgerCommission, ledgerCommissionTax, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.CancellationFee);
                            }

                            //Desktop Version Reference: T125
                            if (supplierCancellationFee != 0) {
                                ledgerChartOfAccountId = chartOfAccount.Id;
                                reference = "Supplier Cancellation Fee";
                                signType = SignType.Credit;
                                amount = supplierCancellationFee;
                                tax = supplierCancellationFeeTax;
                                transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.ExcludeFromSalesAnalysis);
                            }
                        }

                        break;
                    case AccountType.Debtor:
                        if (row.Receipt.DebtorId <= 0)
                            break;

                        //Desktop Version Reference: T126
                        ledgerChartOfAccountId = chartOfAccount.Id;
                        reference = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name;
                        signType = SignType.Credit;

                        if (isCcDebtorReceipt) {
                            amount = -(row.Amount + merchantFee);
                            tax = -(row.Tax + merchantFeeTax);
                        }
                        else {
                            amount = -row.Amount;
                            tax = -row.Tax;
                        }

                        ledgerCommission = commission;
                        ledgerCommissionTax = commissionTax;
                        ledgerDiscount = discount;
                        ledgerDiscountTax = discountTax;

                        transactionDetailList.AddDetailRow(LedgerType.DebtorLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, ledgerCommission, ledgerCommissionTax, ledgerDiscount, ledgerDiscountTax, nonCommissionable, nonCommissionableTax, amount, tax, isCash);
                        break;
                    case AccountType.Creditor:
                        if (row.Receipt.CreditorId <= 0)
                            break;

                        //Desktop Version Reference: T84
                        ledgerChartOfAccountId = chartOfAccount.Id;
                        reference = chartOfAccount.Id <= 0 ? string.Empty : chartOfAccount.AccountName;
                        signType = SignType.Credit;
                        amount = -row.Amount;
                        tax = -row.Tax;
                        transactionDetailList.AddDetailRow(LedgerType.CreditorLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, commission, commissionTax, discount, discountTax, nonCommissionable, nonCommissionableTax, amount, tax, isCash);
                        break;
                }

                //Desktop Version Reference: T83
                if (row.FormOfPayment.FormOfPaymentType == FormOfPaymentType.CreditCard && row.FormOfPayment.DebtorId > 0) {
                    ledgerChartOfAccountId = chartOfAccount.Id;
                    reference = row.Receipt.TripId <= 0 ? string.Empty : row.Receipt.Trip.AccountName;
                    signType = SignType.Debit;
                    amount = row.Amount;
                    tax = row.Tax;
                    transactionDetailList.AddDetailRow(LedgerType.DebtorLedger, signType, transactionDetail, ledgerTripId, row.FormOfPayment.DebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                }

                //General Ledger
                reference = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name;
                signType = SignType.Debit;
                amount = row.Amount;
                tax = row.Tax;

                if (row.FormOfPayment.FormOfPaymentType == FormOfPaymentType.CreditCard && row.FormOfPayment.DebtorId > 0) {
                    //Desktop Version Reference: T41
                    ledgerChartOfAccountId = glSetting.DebtorControlAccount.Id;
                }
                else {
                    //Desktop Version Reference: T42
                    ledgerChartOfAccountId = row.Receipt.BankAccount.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Receipt.AgencyId).Id;
                }

                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                reference = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name;
                signType = SignType.None;
                ledgerCommission = 0;
                ledgerCommissionTax = 0;

                if ((row.Receipt.TransactionAccountType == AccountType.Client && row.Receipt.ReceiptType != ReceiptType.VoucherCommission)
                    || row.Receipt.TransactionAccountType == AccountType.Debtor
                    || row.Receipt.TransactionAccountType == AccountType.Creditor
                    || (row.Receipt.TransactionAccountType == AccountType.GeneralLedger && row.Receipt.ReceiptType == ReceiptType.OtherCommission && row.Receipt.SupplierCommissionType == SupplierCommissionType.Creditor)) {

                    signType = SignType.Credit;

                    if (row.Receipt.TransactionAccountType == AccountType.Client) {
                        //Desktop Version Reference: T44
                        ledgerChartOfAccountId = glSetting.ClientControlAccount.Id;
                    }
                    else if (row.Receipt.TransactionAccountType == AccountType.Debtor) {
                        //Desktop Version Reference: T45
                        ledgerChartOfAccountId = glSetting.DebtorControlAccount.Id;
                    }
                    else if (row.Receipt.TransactionAccountType == AccountType.Creditor) {
                        //Desktop Version Reference: T46
                        ledgerChartOfAccountId = glSetting.CreditorControlAccount.Id;
                    }

                    if (row.Receipt.ReceiptType == ReceiptType.Refund) {
                        amount = -clientRefund;
                        tax = -clientRefundTax;
                    }
                    else if (row.Receipt.ReceiptType == ReceiptType.OtherCommission && row.Receipt.SupplierCommissionType == SupplierCommissionType.Creditor) {
                        if (row.Receipt.SupplierCommissionType == SupplierCommissionType.None) {
                            amount = -row.Amount;
                            tax = -row.Tax;
                        }
                        else if (row.Receipt.SupplierCommissionType == SupplierCommissionType.Creditor) {
                            amount = 0;
                            tax = 0;
                        }

                        ledgerCommission = row.Amount;
                        ledgerCommissionTax = row.Tax;
                    }
                    else if (isCcDebtorReceipt) {
                        amount = -(row.Amount + merchantFee);
                        tax = -(row.Tax + merchantFeeTax);
                    }
                    else {
                        amount = -row.Amount;
                        tax = -row.Tax;
                    }
                }
                else if (row.Receipt.ReceiptType != ReceiptType.Transfer) {
                    //Desktop Version Reference: T128
                    signType = SignType.Credit;
                    ledgerChartOfAccountId = chartOfAccount.Id;
                    amount = -row.Amount;
                    tax = 0;
                }

                if (signType != SignType.None)
                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, ledgerCommission, ledgerCommissionTax, 0, 0, 0, 0, amount, tax, isCash);

                if (row.Receipt.TransactionAccountType == AccountType.GeneralLedger && row.Receipt.ReceiptType != ReceiptType.OtherCommission && row.Tax != 0) {
                    reference = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name;
                    signType = SignType.Credit;
                    amount = -row.Tax;
                    tax = 0;

                    if (chartOfAccount.AccountCategory == AccountCategory.Income) {
                        //Desktop Version Reference: T49
                        ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                    }
                    else {
                        //Desktop Version Reference: T50
                        ledgerChartOfAccountId = glSetting.PurchasesTaxAccount.Id;
                    }

                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                }

                if (isCcDebtorReceipt && merchantFee != 0) {
                    ledgerChartOfAccountId = ccChargeAccount.Id;
                    reference = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name;
                    signType = SignType.Debit;
                    amount = merchantFee;
                    tax = 0;

                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.MerchantFee);

                    //Desktop Version Reference: T53
                    if (merchantFeeTax != 0) {
                        ledgerChartOfAccountId = glSetting.PurchasesTaxAccount.Id;
                        reference = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name;
                        signType = SignType.Debit;
                        amount = merchantFeeTax;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.MerchantFee);
                    }
                }

                if (row.Receipt.ReceiptType == ReceiptType.Refund) {
                    //Desktop Version Reference: T43
                    ledgerChartOfAccountId = glSetting.CommissionAccount.Id;
                    reference = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name;
                    signType = SignType.Debit;
                    amount = commission - cancellationFee;
                    tax = 0;
                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                    //Desktop Version Reference: T54
                    if (discount != 0) {
                        ledgerChartOfAccountId = row.Receipt.DiscountReason.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Receipt.AgencyId).Id;
                        signType = SignType.Debit;
                        amount = -discount;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);
                    }
                }

                if (row.Receipt.IsTaxApplicable || row.IsTaxApplicable) {
                    ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                    reference = row.FormOfPaymentId <= 0 ? string.Empty : row.FormOfPayment.Name;
                    signType = SignType.None;
                    amount = 0;
                    tax = 0;

                    if (row.Receipt.ReceiptType == ReceiptType.Refund && (commissionTax - discountTax - cancellationFeeTax) != 0) {
                        //Desktop Version Reference: T47
                        signType = SignType.Debit;
                        amount = commissionTax - discountTax - cancellationFeeTax;
                    }
                    else if ((row.Receipt.ReceiptType == ReceiptType.VoucherCommission || (row.Receipt.ReceiptType == ReceiptType.OtherCommission && row.Receipt.SupplierCommissionType == SupplierCommissionType.None)) && row.Tax != 0) {
                        signType = SignType.Credit;
                        amount = -row.Tax;
                    }
                    else if (commissionTax != 0) {
                        //Desktop Version Reference: T75
                        signType = SignType.Credit;
                        amount = -commissionTax;
                    }

                    if (signType != SignType.None)
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                }
            }

            return true;
        }

        private static bool AddReceiptDetailAutoGeneratedRows(this List<TransactionDetailViewModel> transactionDetailList, AppLazyContext lazyContext, Receipt receipt) {
            if (receipt.ReverseTransferReceiptId <= 0)
                throw new InvalidOperationException(string.Format("Receipt No {0} is not valid for this method.", receipt.DocumentNo));

            var transactionDetail = new TransactionDetailViewModel {
                TransactionId = -2,
                TransactionType = TransactionType.Receipt,
                AgencyId = receipt.AgencyId,
                Description = string.Empty
            };

            const int ledgerDebtorId = -1;

            string reference;
            decimal amount;
            decimal tax;
            bool isCash;
            SignType signType;

            int ledgerTripId = receipt.TripId;
            int ledgerCreditorId = receipt.CreditorId;
            int ledgerChartOfAccountId;

            foreach (var row in receipt.ReceiptDetails) {
                transactionDetail.TransactionDetailRefId = row.Id;
                transactionDetail.DocumentStatus = row.DocumentStatus;
                transactionDetail.ReversalStatus = row.ReversalStatus;

                isCash = row.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard;

                //Desktop Version Reference: T42
                reference = "Auto Transfer";
                signType = SignType.Credit;
                amount = row.Amount;
                tax = row.Tax;
                ledgerChartOfAccountId = row.Receipt.BankAccount.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Receipt.AgencyId).Id;
                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
            }

            return true;
        }

        private static bool AddBspDetailRows(this List<TransactionDetailViewModel> transactionDetailList, AppLazyContext lazyContext, Bsp bsp) {
            var transactionDetail = new TransactionDetailViewModel {
                TransactionId = -2,
                TransactionType = TransactionType.Bsp,
                AgencyId = bsp.AgencyId,
                Description = bsp.Comments.Length == 0 ? bsp.Supplier.Name : bsp.Comments
            };

            const int ledgerDebtorId = -1;

            string reference = string.Empty;

            decimal amount = 0;
            decimal tax = 0;
            decimal cashAmount = 0;
            decimal cashTax = 0;
            decimal nonCommissionable = 0;
            decimal nonCommissionableTax = 0;
            decimal commission = 0;
            decimal commissionTax = 0;
            decimal discount = 0;
            decimal discountTax = 0;
            decimal markup = 0;
            decimal markupTax = 0;
            decimal markupGross = 0;
            decimal markupGrossOther = 0;
            decimal supplierCancellationFee = 0;
            decimal supplierCancellationFeeTax = 0;
            decimal supplierNet = 0;
            decimal supplierNetTax = 0;
            decimal ccDiscountMarkup = 0;
            decimal ccDiscountMarkupTax = 0;

            decimal totalAmount = 0;
            decimal ledgerCommission = 0;
            decimal ledgerCommissionTax = 0;
            decimal ledgerDiscount = 0;
            decimal ledgerDiscountTax = 0;

            bool isCash = false;

            SignType signType;
            var glSetting = Setting.GetRow(lazyContext, bsp.DocumentDate);

            int ledgerTripId = bsp.TripId;
            int ledgerCreditorId = bsp.CreditorId;
            int ledgerChartOfAccountId = 0;
            int sign = bsp.Sign;

            totalAmount = bsp.BspDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;

            foreach (var row in bsp.BspDetails) {
                transactionDetail.TransactionDetailRefId = row.Id;
                transactionDetail.DocumentStatus = row.DocumentStatus;
                transactionDetail.ReversalStatus = row.ReversalStatus;

                isCash = row.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard;

                if (row.Bsp.BspDetails.Count > 1 && row.Bsp.BspDetails.Last().Id == row.Id) {
                    var q = transactionDetailList.Where(t => t.TransactionDetailRefId != row.Id);
                    commission = row.Bsp.Commission - (q.Sum(t => (decimal?)t.CumulativeCommission) ?? 0);
                    commissionTax = row.Bsp.CommissionTax - (q.Sum(t => (decimal?)t.CumulativeCommissionTax) ?? 0);
                    discount = row.Bsp.Discount - (q.Sum(t => (decimal?)t.CumulativeDiscount) ?? 0);
                    discountTax = row.Bsp.DiscountTax - (q.Sum(t => (decimal?)t.CumulativeDiscountTax) ?? 0);
                    markup = row.Bsp.Markup - (q.Sum(t => (decimal?)t.CumulativeMarkup) ?? 0);
                    markupTax = row.Bsp.MarkupTax - (q.Sum(t => (decimal?)t.CumulativeMarkupTax) ?? 0);
                    markupGrossOther = row.Bsp.MarkupGrossOther - (q.Sum(t => (decimal?)t.CumulativeMarkupGrossOther) ?? 0);
                    supplierCancellationFee = row.Bsp.SupplierCancellationFee - (q.Sum(t => (decimal?)t.CumulativeSupplierCancellationFee) ?? 0);
                    supplierCancellationFeeTax = row.Bsp.SupplierCancellationFeeTax - (q.Sum(t => (decimal?)t.CumulativeSupplierCancellationFeeTax) ?? 0);
                }
                else {
                    decimal proRataRatio = row.Bsp.BspDetails.Count == 1 ? 1 : totalAmount == 0 ? 1 / row.Bsp.BspDetails.Count : (row.Amount + row.Tax) / totalAmount;
                    decimal discountProRataRatio = row.DiscountProRataRatio;
                    decimal markupProRataRatio = row.MarkupProRataRatio;

                    commission = Math.Round(row.Bsp.Commission * proRataRatio, 2);
                    commissionTax = Math.Round(row.Bsp.CommissionTax * proRataRatio, 2);
                    discount = Math.Round(row.Bsp.Discount * discountProRataRatio, 2);
                    discountTax = Math.Round(row.Bsp.DiscountTax * discountProRataRatio, 2);
                    markup = Math.Round(row.Bsp.Markup * markupProRataRatio, 2);
                    markupTax = Math.Round(row.Bsp.MarkupTax * markupProRataRatio, 2);
                    markupGrossOther = Math.Round(row.Bsp.MarkupGrossOther * proRataRatio, 2);
                    supplierCancellationFee = Math.Round(row.Bsp.SupplierCancellationFee * proRataRatio, 2);
                    supplierCancellationFeeTax = Math.Round(row.Bsp.SupplierCancellationFeeTax * proRataRatio, 2);
                }

                transactionDetail.CumulativeCommission = commission;
                transactionDetail.CumulativeCommissionTax = commissionTax;
                transactionDetail.CumulativeDiscount = discount;
                transactionDetail.CumulativeDiscountTax = discountTax;
                transactionDetail.CumulativeMarkup = markup;
                transactionDetail.CumulativeMarkupTax = markupTax;
                transactionDetail.CumulativeMarkupGrossOther = markupGrossOther;
                transactionDetail.CumulativeSupplierCancellationFee = supplierCancellationFee;
                transactionDetail.CumulativeSupplierCancellationFeeTax = supplierCancellationFeeTax;

                nonCommissionable = row.NonCommissionable * sign;
                nonCommissionableTax = row.NonCommissionableTax * sign;
                markupGross = markup + markupTax;

                ccDiscountMarkup = (row.Bsp.IsCreditCardDiscountApplicable ? discount : 0) - (row.Bsp.IncludeMarkupInCreditCardPayment ? markup : 0);
                ccDiscountMarkupTax = (row.Bsp.IsCreditCardDiscountApplicable ? discountTax : 0) - (row.Bsp.IncludeMarkupInCreditCardPayment ? markupTax : 0);

                cashAmount = row.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? ccDiscountMarkup : row.Amount + row.NonCommissionable;
                cashTax = row.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? ccDiscountMarkupTax : row.Tax + row.NonCommissionableTax;

                supplierNet = cashAmount - (commission + supplierCancellationFee);
                supplierNetTax = cashTax - (commissionTax + supplierCancellationFeeTax);

                //Client & Debtor
                //Desktop Version Reference: T86/T91
                if (row.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
                    ledgerChartOfAccountId = -1;
                    reference = "Credit Card";
                    signType = SignType.Credit;
                    amount = -(row.Amount + row.NonCommissionable - ccDiscountMarkup) * sign;
                    tax = -(row.Tax + row.NonCommissionableTax - ccDiscountMarkupTax) * sign;
                    transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.ExcludeFromSalesAnalysis);
                }

                //General Ledger
                ledgerChartOfAccountId = glSetting.ClientControlAccount.Id;
                reference = row.Bsp.TripLine.Description;
                signType = SignType.Debit;
                amount = (cashAmount - discount - supplierCancellationFee) * sign;
                tax = (cashTax - discountTax - supplierCancellationFeeTax) * sign;

                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                //Client & Debtor
                //Desktop Version Reference: T85/T90
                ledgerChartOfAccountId = -1;
                reference = row.Bsp.TripLine.Description;
                signType = SignType.Debit;
                amount = (row.Amount + row.NonCommissionable) * sign;
                tax = (row.Tax + row.NonCommissionableTax) * sign;

                if (row.Bsp.BspType == BspType.AcmNoAnalysis || row.Bsp.BspType == BspType.AdmNoAnalysis) {
                    ledgerCommission = 0;
                    ledgerCommissionTax = 0;
                }
                else {
                    ledgerCommission = commission * sign;
                    ledgerCommissionTax = commissionTax * sign;
                }

                ledgerDiscount = -discount * sign;
                ledgerDiscountTax = -discountTax * sign;
                transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, ledgerCommission, ledgerCommissionTax, ledgerDiscount, ledgerDiscountTax, nonCommissionable, nonCommissionableTax, amount, tax, isCash);

                //Desktop Version Reference: T87/T92
                if (discount != 0) {
                    ledgerChartOfAccountId = -1;
                    reference = "Discount";
                    signType = SignType.Debit;
                    amount = -discount * sign;
                    tax = -discountTax * sign;
                    transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);
                }

                //Desktop Version Reference: T88/T93
                if (row.Bsp.IsCancellationPermitted && supplierCancellationFee != 0) {
                    ledgerChartOfAccountId = -1;
                    reference = "Supplier Cancellation Fee";
                    signType = SignType.Credit;
                    amount = -supplierCancellationFee * sign;
                    tax = -supplierCancellationFeeTax * sign;
                    transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.ExcludeFromSalesAnalysis);
                }

                //Desktop Version Reference: T89/T94
                if (row.Bsp.IsMarkupPermitted && markupGross != 0) {
                    ledgerChartOfAccountId = -1;
                    reference = "Mark-Up";
                    signType = SignType.Debit;
                    amount = markup * sign;
                    tax = markupTax * sign;
                    ledgerCommission = row.Bsp.MarkupStrategy.GetRemainderCommission(markupGrossOther, markup) * sign;
                    ledgerCommissionTax = row.Bsp.MarkupStrategy.GetRemainderCommission(markupGrossOther, markupTax) * sign;
                    transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, ledgerCommission, ledgerCommissionTax, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Markup);
                }

                //General Ledger
                //Desktop Version Reference: T3
                ledgerChartOfAccountId = glSetting.BspAccrualAccount.Id;
                reference = row.Bsp.TripLine.Description;
                signType = SignType.Credit;
                amount = -supplierNet * sign;
                tax = -supplierNetTax * sign;
                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                //Desktop Version Reference: T1
                ledgerChartOfAccountId = glSetting.CommissionAccount.Id;
                reference = "Commission";
                signType = SignType.Credit;
                amount = -commission * sign;
                tax = 0;
                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                //Desktop Version Reference: T6
                if (row.Bsp.IsTaxApplicable) {
                    ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                    reference = string.Format("Commission {0}", Resource.TaxLabel);
                    signType = SignType.Credit;
                    amount = -commissionTax * sign;
                    tax = 0;
                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                }

                if (row.Bsp.IsDiscountPermitted && discount != 0) {
                    //Desktop Version Reference: T7
                    ledgerChartOfAccountId = row.Bsp.DiscountReason.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Bsp.AgencyId).Id;
                    reference = "Discount";
                    signType = SignType.Debit;
                    amount = discount * sign;
                    tax = 0;
                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);

                    //Desktop Version Reference: T8
                    if (discountTax != 0) {
                        ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                        reference = string.Format("Discount {0}", Resource.TaxLabel);
                        signType = SignType.Debit;
                        amount = discountTax * sign;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);
                    }
                }

                if (row.Bsp.IsMarkupPermitted && markupGross != 0) {
                    //Desktop Version Reference: T9
                    ledgerChartOfAccountId = glSetting.ClientControlAccount.Id;
                    reference = "Mark-Up";
                    signType = SignType.Debit;
                    amount = markup * sign;
                    tax = markupTax * sign;
                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Markup);

                    decimal markupRemainder = markup;

                    //Desktop Version Reference: T11
                    foreach (var row3 in row.Bsp.MarkupStrategy.MarkupStrategyElements) {
                        ledgerChartOfAccountId = row3.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Bsp.AgencyId).Id;
                        reference = string.Empty;
                        signType = SignType.Credit;

                        amount = row3.GetAmount(row3.ApportionMethod == ApportionMethod.Fixed ? markupGrossOther : row.Bsp.MarkupGrossOther, markupGross) - markupTax;

                        markupRemainder -= amount;
                        amount = -amount * sign;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                    }

                    //Desktop Version Reference: T12
                    if (markupRemainder != 0) {
                        ledgerChartOfAccountId = row.Bsp.MarkupStrategy.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Bsp.AgencyId).Id;
                        reference = string.Empty;
                        signType = SignType.Credit;
                        amount = -markupRemainder * sign;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                    }

                    //Desktop Version Reference: T40
                    if (markupTax != 0) {
                        ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                        reference = string.Format("Mark-Up {0}", Resource.TaxLabel);
                        signType = SignType.Credit;
                        amount = -markupTax * sign;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Markup);
                    }
                }
            }

            return true;
        }

        private static bool AddBspDetailAutoGeneratedRows(this List<TransactionDetailViewModel> transactionDetailList, AppLazyContext lazyContext, Bsp bsp) {
            if (bsp.AgencyCreditCardBspId <= 0)
                throw new InvalidOperationException(string.Format("BSP No {0} is not valid for this method.", bsp.DocumentNo));

            var transactionDetail = new TransactionDetailViewModel {
                TransactionId = -2,
                TransactionType = TransactionType.Bsp,
                AgencyId = bsp.AgencyId,
                Description = string.Empty
            };

            const int ledgerDebtorId = -1;

            string reference;
            decimal amount;
            decimal tax;
            bool isCash;

            SignType signType;
            var glSetting = Setting.GetRow(lazyContext, bsp.DocumentDate);

            int ledgerTripId = bsp.TripId;
            int ledgerCreditorId = bsp.CreditorId;
            int ledgerChartOfAccountId;

            foreach (var row in bsp.BspDetails) {
                transactionDetail.TransactionDetailRefId = row.Id;
                transactionDetail.DocumentStatus = row.DocumentStatus;
                transactionDetail.ReversalStatus = row.ReversalStatus;

                //Desktop Version Reference: T14
                ledgerChartOfAccountId = glSetting.BspAccrualAccount.Id;
                signType = SignType.Credit;
                amount = -(row.Amount + row.NonCommissionable - row.CommissionProRata);
                tax = -(row.Tax + row.NonCommissionableTax - row.CommissionTaxProRata);
                isCash = row.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard;

                if (row.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet) {
                    reference = "Auto BSP Agency Credit Card Net";
                }
                else {
                    reference = "Auto BSP Agency Credit Card Gross";
                }

                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
            }

            return true;
        }

        private static bool AddNonBspDetailRows(this List<TransactionDetailViewModel> transactionDetailList, AppLazyContext lazyContext, NonBsp nonBsp, AccountType accountType) {
            var transactionDetail = new TransactionDetailViewModel {
                TransactionId = -2,
                TransactionType = TransactionType.NonBsp,
                AgencyId = nonBsp.AgencyId,
                Description = nonBsp.Comments.Length == 0 ? nonBsp.Supplier.Name : nonBsp.Comments
            };

            LedgerType ledgerType;
            string reference = string.Empty;

            decimal amount = 0;
            decimal tax = 0;
            decimal cashAmount = 0;
            decimal cashTax = 0;
            decimal nonCommissionable = 0;
            decimal nonCommissionableTax = 0;
            decimal commission = 0;
            decimal commissionTax = 0;
            decimal discount = 0;
            decimal discountTax = 0;
            decimal markup = 0;
            decimal markupTax = 0;
            decimal markupGross = 0;
            decimal markupGrossOther = 0;
            decimal supplierCancellationFee = 0;
            decimal supplierCancellationFeeTax = 0;
            decimal supplierNet = 0;
            decimal supplierNetTax = 0;
            decimal ccDiscountMarkup = 0;
            decimal ccDiscountMarkupTax = 0;

            decimal totalAmount = 0;
            decimal ledgerCommission = 0;
            decimal ledgerCommissionTax = 0;
            decimal ledgerDiscount = 0;
            decimal ledgerDiscountTax = 0;

            bool isCash = false;

            SignType signType;
            var glSetting = Setting.GetRow(lazyContext, nonBsp.DocumentDate);

            var chartOfAccount = nonBsp.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, nonBsp.AgencyId);

            int ledgerTripId = nonBsp.TripId;
            int ledgerDebtorId = -1;
            int ledgerCreditorId = nonBsp.CreditorId;
            int ledgerChartOfAccountId = 0;
            int sign = nonBsp.Sign;

            if (accountType == AccountType.Client) {
                ledgerType = LedgerType.ClientLedger;
            }
            else {
                ledgerType = LedgerType.DebtorLedger;
            }

            totalAmount = nonBsp.NonBspDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;

            foreach (var row in nonBsp.NonBspDetails) {
                if (accountType == AccountType.Debtor)
                    ledgerDebtorId = row.NonBsp.LoyaltySchemeReceiptDetail.Receipt.DebtorId;

                transactionDetail.TransactionDetailRefId = row.Id;
                transactionDetail.DocumentStatus = row.DocumentStatus;
                transactionDetail.ReversalStatus = row.ReversalStatus;

                isCash = row.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard;

                if (row.NonBsp.NonBspDetails.Count > 1 && row.NonBsp.NonBspDetails.Last().Id == row.Id) {
                    var q = transactionDetailList.Where(t => t.TransactionDetailRefId != row.Id);
                    commission = row.NonBsp.Commission - (q.Sum(t => (decimal?)t.CumulativeCommission) ?? 0);
                    commissionTax = row.NonBsp.CommissionTax - (q.Sum(t => (decimal?)t.CumulativeCommissionTax) ?? 0);
                    discount = row.NonBsp.Discount - (q.Sum(t => (decimal?)t.CumulativeDiscount) ?? 0);
                    discountTax = row.NonBsp.DiscountTax - (q.Sum(t => (decimal?)t.CumulativeDiscountTax) ?? 0);
                    markup = row.NonBsp.Markup - (q.Sum(t => (decimal?)t.CumulativeMarkup) ?? 0);
                    markupTax = row.NonBsp.MarkupTax - (q.Sum(t => (decimal?)t.CumulativeMarkupTax) ?? 0);
                    markupGrossOther = row.NonBsp.MarkupGrossOther - (q.Sum(t => (decimal?)t.CumulativeMarkupGrossOther) ?? 0);
                    supplierCancellationFee = row.NonBsp.SupplierCancellationFee - (q.Sum(t => (decimal?)t.CumulativeSupplierCancellationFee) ?? 0);
                    supplierCancellationFeeTax = row.NonBsp.SupplierCancellationFeeTax - (q.Sum(t => (decimal?)t.CumulativeSupplierCancellationFeeTax) ?? 0);
                }
                else {
                    decimal proRataRatio = row.NonBsp.NonBspDetails.Count == 1 ? 1 : totalAmount == 0 ? 1 / row.NonBsp.NonBspDetails.Count : (row.Amount + row.Tax) / totalAmount;
                    decimal discountProRataRatio = row.DiscountProRataRatio;
                    decimal markupProRataRatio = row.MarkupProRataRatio;

                    commission = Math.Round(row.NonBsp.Commission * proRataRatio, 2);
                    commissionTax = Math.Round(row.NonBsp.CommissionTax * proRataRatio, 2);
                    discount = Math.Round(row.NonBsp.Discount * discountProRataRatio, 2);
                    discountTax = Math.Round(row.NonBsp.DiscountTax * discountProRataRatio, 2);
                    markup = Math.Round(row.NonBsp.Markup * markupProRataRatio, 2);
                    markupTax = Math.Round(row.NonBsp.MarkupTax * markupProRataRatio, 2);
                    markupGrossOther = Math.Round(row.NonBsp.MarkupGrossOther * proRataRatio, 2);
                    supplierCancellationFee = Math.Round(row.NonBsp.SupplierCancellationFee * proRataRatio, 2);
                    supplierCancellationFeeTax = Math.Round(row.NonBsp.SupplierCancellationFeeTax * proRataRatio, 2);
                }

                transactionDetail.CumulativeCommission = commission;
                transactionDetail.CumulativeCommissionTax = commissionTax;
                transactionDetail.CumulativeDiscount = discount;
                transactionDetail.CumulativeDiscountTax = discountTax;
                transactionDetail.CumulativeMarkup = markup;
                transactionDetail.CumulativeMarkupTax = markupTax;
                transactionDetail.CumulativeMarkupGrossOther = markupGrossOther;
                transactionDetail.CumulativeSupplierCancellationFee = supplierCancellationFee;
                transactionDetail.CumulativeSupplierCancellationFeeTax = supplierCancellationFeeTax;

                nonCommissionable = row.NonCommissionable * sign;
                nonCommissionableTax = row.NonCommissionableTax * sign;
                markupGross = markup + markupTax;

                ccDiscountMarkup = (row.NonBsp.IsCreditCardDiscountApplicable ? discount : 0) - (row.NonBsp.IncludeMarkupInCreditCardPayment ? markup : 0);
                ccDiscountMarkupTax = (row.NonBsp.IsCreditCardDiscountApplicable ? discountTax : 0) - (row.NonBsp.IncludeMarkupInCreditCardPayment ? markupTax : 0);

                cashAmount = row.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? ccDiscountMarkup : row.Amount + row.NonCommissionable;
                cashTax = row.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? ccDiscountMarkupTax : row.Tax + row.NonCommissionableTax;

                supplierNet = cashAmount - (commission + supplierCancellationFee);
                supplierNetTax = cashTax - (commissionTax + supplierCancellationFeeTax);

                switch (accountType) {
                    case AccountType.Client:
                    case AccountType.Debtor:
                        //Desktop Version Reference: T98/T103
                        ledgerChartOfAccountId = chartOfAccount.Id;
                        reference = row.NonBsp.TripLine.Description;
                        signType = SignType.Debit;
                        amount = (row.Amount + row.NonCommissionable) * sign;
                        tax = (row.Tax + row.NonCommissionableTax) * sign;
                        ledgerCommission = commission * sign;
                        ledgerCommissionTax = commissionTax * sign;
                        ledgerDiscount = -discount * sign;
                        ledgerDiscountTax = -discountTax * sign;
                        transactionDetailList.AddDetailRow(ledgerType, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, ledgerCommission, ledgerCommissionTax, ledgerDiscount, ledgerDiscountTax, nonCommissionable, nonCommissionableTax, amount, tax, isCash);

                        //Desktop Version Reference: T99/T104
                        if (row.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
                            ledgerChartOfAccountId = chartOfAccount.Id;
                            reference = "Credit Card";
                            signType = SignType.Credit;
                            amount = -(row.Amount + row.NonCommissionable - ccDiscountMarkup) * sign;
                            tax = -(row.Tax + row.NonCommissionableTax - ccDiscountMarkupTax) * sign;
                            transactionDetailList.AddDetailRow(ledgerType, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.ExcludeFromSalesAnalysis);
                        }

                        //Desktop Version Reference: T100/T105
                        if (discount != 0) {
                            ledgerChartOfAccountId = chartOfAccount.Id;
                            reference = "Discount";
                            signType = SignType.Debit;
                            amount = -discount * sign;
                            tax = -discountTax * sign;
                            transactionDetailList.AddDetailRow(ledgerType, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);
                        }

                        //Desktop Version Reference: T101/T107
                        if (row.NonBsp.IsCancellationPermitted && supplierCancellationFee != 0) {
                            ledgerChartOfAccountId = chartOfAccount.Id;
                            reference = "Supplier Cancellation Fee";
                            signType = SignType.Credit;
                            amount = -supplierCancellationFee * sign;
                            tax = -supplierCancellationFeeTax * sign;
                            transactionDetailList.AddDetailRow(ledgerType, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.ExcludeFromSalesAnalysis);
                        }

                        //Desktop Version Reference: T102/T106
                        if (row.NonBsp.IsMarkupPermitted && markupGross != 0) {
                            ledgerChartOfAccountId = chartOfAccount.Id;
                            reference = "Mark-Up";
                            signType = SignType.Debit;
                            amount = markup * sign;
                            tax = markupTax * sign;
                            ledgerCommission = row.NonBsp.MarkupStrategy.GetRemainderCommission(markupGrossOther, markup) * sign;
                            ledgerCommissionTax = row.NonBsp.MarkupStrategy.GetRemainderCommission(markupGrossOther, markupTax) * sign;
                            transactionDetailList.AddDetailRow(ledgerType, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, ledgerCommission, ledgerCommissionTax, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Markup);
                        }

                        reference = row.NonBsp.TripLine.Description;
                        signType = SignType.Credit;
                        amount = -supplierNet * sign;
                        tax = -supplierNetTax * sign;

                        if (row.NonBsp.CreditorId > 0) {
                            ledgerChartOfAccountId = glSetting.CreditorControlAccount.Id;
                        }
                        else {
                            //Desktop Version Reference: T16
                            ledgerChartOfAccountId = glSetting.SupplierReturnsAccount.Id;
                        }

                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                        //Desktop Version Reference: T18
                        ledgerChartOfAccountId = glSetting.ClientControlAccount.Id;
                        reference = row.NonBsp.TripLine.Description;
                        signType = SignType.Debit;
                        amount = (cashAmount - discount - supplierCancellationFee) * sign;
                        tax = (cashTax - discountTax - supplierCancellationFeeTax) * sign;

                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                        //Desktop Version Reference: T17
                        if (commission != 0) {
                            ledgerChartOfAccountId = glSetting.CommissionAccount.Id;
                            reference = "Commission";
                            signType = SignType.Credit;
                            amount = -commission * sign;
                            tax = 0;
                            transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                        }

                        //Desktop Version Reference: T20
                        if (row.NonBsp.IsTaxApplicable) {
                            ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                            reference = string.Format("Commission {0}", Resource.TaxLabel);
                            signType = SignType.Credit;
                            amount = -commissionTax * sign;
                            tax = 0;
                            transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                        }

                        //Desktop Version Reference: T21
                        if (row.NonBsp.IsDiscountPermitted && discount != 0) {
                            ledgerChartOfAccountId = row.NonBsp.DiscountReason.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.NonBsp.AgencyId).Id;
                            reference = "Discount";
                            signType = SignType.Debit;
                            amount = discount * sign;
                            tax = 0;
                            transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);

                            //Desktop Version Reference: T22
                            if (discountTax != 0) {
                                ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                                reference = string.Format("Discount {0}", Resource.TaxLabel);
                                signType = SignType.Debit;
                                amount = discountTax * sign;
                                tax = 0;
                                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);
                            }
                        }

                        if (row.NonBsp.IsMarkupPermitted && markupGross != 0) {
                            //Desktop Version Reference: T24
                            ledgerChartOfAccountId = glSetting.ClientControlAccount.Id;
                            reference = "Mark-Up";
                            signType = SignType.Debit;
                            amount = markup * sign;
                            tax = markupTax * sign;
                            transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Markup);

                            decimal markupRemainder = markup;

                            //Desktop Version Reference: T26
                            foreach (var row3 in row.NonBsp.MarkupStrategy.MarkupStrategyElements) {
                                ledgerChartOfAccountId = row3.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.NonBsp.AgencyId).Id;
                                reference = string.Empty;
                                signType = SignType.Credit;

                                amount = row3.GetAmount(row3.ApportionMethod == ApportionMethod.Fixed ? markupGrossOther : row.NonBsp.MarkupGrossOther, markupGross) - markupTax;

                                markupRemainder -= amount;
                                amount = -amount * sign;
                                tax = 0;
                                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                            }

                            //Desktop Version Reference: T27
                            if (markupRemainder != 0) {
                                ledgerChartOfAccountId = row.NonBsp.MarkupStrategy.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.NonBsp.AgencyId).Id;
                                reference = row.NonBsp.TripLine.Description;
                                signType = SignType.Credit;
                                amount = -markupRemainder * sign;
                                tax = 0;
                                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                            }

                            //Desktop Version Reference: T28
                            if (markupTax != 0) {
                                ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                                reference = string.Format("Mark-Up {0}", Resource.TaxLabel);
                                signType = SignType.Credit;
                                amount = -markupTax * sign;
                                tax = 0;
                                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Markup);
                            }
                        }

                        break;
                    case AccountType.GeneralLedger:
                        //Desktop Version Reference: T29
                        ledgerChartOfAccountId = chartOfAccount.Id;
                        reference = row.NonBsp.TripLine.Description;
                        signType = SignType.Debit;
                        amount = (row.Amount + row.NonCommissionable) * sign;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                        reference = row.NonBsp.TripLine.Description;
                        signType = SignType.Credit;
                        amount = -(row.Amount + row.NonCommissionable) * sign;
                        tax = -(row.Tax + row.NonCommissionableTax) * sign;

                        if (row.NonBsp.CreditorId > 0) {
                            ledgerChartOfAccountId = glSetting.CreditorControlAccount.Id;
                        }
                        else {
                            //Desktop Version Reference: T32
                            ledgerChartOfAccountId = glSetting.SupplierReturnsAccount.Id;
                        }

                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                        if (row.IsTaxApplicable && row.Tax != 0) {
                            if (chartOfAccount.AccountCategory == AccountCategory.Income) {
                                //Desktop Version Reference: T133
                                ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                            }
                            else {
                                //Desktop Version Reference: T30
                                ledgerChartOfAccountId = glSetting.PurchasesTaxAccount.Id;
                            }

                            reference = row.NonBsp.TripLine.Description;
                            signType = SignType.Debit;
                            amount = row.Tax * sign;
                            tax = 0;
                            transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                        }

                        break;
                }

                if (row.NonBsp.CreditorId > 0) {
                    reference = row.NonBsp.TripLine.Description;
                    signType = SignType.Credit;
                    amount = -supplierNet * sign;
                    tax = -supplierNetTax * sign;

                    //Desktop Version Reference: T80
                    ledgerCreditorId = row.NonBsp.CreditorId;
                    ledgerChartOfAccountId = chartOfAccount.Id;
                    transactionDetailList.AddDetailRow(LedgerType.CreditorLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                }
            }

            return true;
        }

        private static bool AddNonBspDetailAutoGeneratedRows(this List<TransactionDetailViewModel> transactionDetailList, AppLazyContext lazyContext, NonBsp nonBsp) {
            if (nonBsp.AgencyCreditCardBspId <= 0 && nonBsp.AgencyCreditCardNonBspId <= 0 && nonBsp.SupplierOtherCommissionReceiptId <= 0)
                throw new InvalidOperationException(string.Format("Non-BSP No {0} is not valid for this method.", nonBsp.DocumentNo));

            var transactionDetail = new TransactionDetailViewModel {
                TransactionId = -2,
                TransactionType = TransactionType.NonBsp,
                AgencyId = nonBsp.AgencyId,
                Description = string.Empty
            };

            const int ledgerDebtorId = -1;

            string reference = string.Empty;
            string ledgerReference;
            decimal amount;
            decimal tax;

            bool isCash;

            SignType signType;
            var glSetting = Setting.GetRow(lazyContext, nonBsp.DocumentDate);

            var chartOfAccount = nonBsp.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, nonBsp.AgencyId);

            int ledgerTripId = nonBsp.TripId;
            int ledgerCreditorId = nonBsp.CreditorId;
            int ledgerChartOfAccountId = 0;

            if (nonBsp.AgencyCreditCardBspId > 0 || nonBsp.AgencyCreditCardNonBspId > 0) {
                foreach (var row in nonBsp.NonBspDetails) {
                    transactionDetail.TransactionDetailRefId = row.Id;
                    transactionDetail.DocumentStatus = row.DocumentStatus;
                    transactionDetail.ReversalStatus = row.ReversalStatus;

                    signType = SignType.Credit;
                    amount = -(row.Amount + row.NonCommissionable - row.CommissionProRata);
                    tax = -(row.Tax + row.NonCommissionableTax - row.CommissionTaxProRata);
                    isCash = row.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard;

                    switch (row.FormOfPayment.FormOfPaymentType) {
                        case FormOfPaymentType.PaySupplierGross:
                            reference = "Auto Non-BSP Pay Supplier Gross";
                            break;
                        case FormOfPaymentType.AgencyCreditCardNet:
                            reference = "Auto Non-BSP Agency Credit Card Net";
                            break;
                        case FormOfPaymentType.AgencyCreditCardGross:
                            reference = "Auto Non-BSP Agency Credit Card Gross";
                            break;
                    }

                    if (nonBsp.AgencyCreditCardBspId > 0) {
                        if (row.FormOfPayment.CreditorId > 0) {
                            //Desktop Version Reference: T97
                            ledgerReference = string.Empty;
                            ledgerCreditorId = nonBsp.CreditorId;
                            transactionDetailList.AddDetailRow(LedgerType.CreditorLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, ledgerReference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                            //Desktop Version Reference: T38
                            ledgerChartOfAccountId = glSetting.CreditorControlAccount.Id;
                        }
                        else {
                            //Desktop Version Reference: T39
                            ledgerCreditorId = nonBsp.CreditorId;
                            ledgerChartOfAccountId = glSetting.SupplierReturnsAccount.Id;
                        }

                        ledgerReference = reference;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, ledgerReference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                    }
                    else if (nonBsp.AgencyCreditCardNonBspId > 0) {
                        if (amount < 0) {
                            if (row.NonBsp.CreditorId > 0) {
                                //Desktop Version Reference: T34
                                ledgerReference = string.Empty;
                                ledgerCreditorId = nonBsp.CreditorId;

                                //Desktop Version Reference: T108
                                transactionDetailList.AddDetailRow(LedgerType.CreditorLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, ledgerReference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                                ledgerChartOfAccountId = glSetting.CreditorControlAccount.Id;
                            }
                            else {
                                //Desktop Version Reference: T35
                                ledgerChartOfAccountId = glSetting.SupplierReturnsAccount.Id;
                            }

                            ledgerReference = reference;
                            transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, ledgerReference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                        }
                        else {
                            if (row.FormOfPayment.CreditorId > 0) {
                                //Desktop Version Reference: T36
                                ledgerReference = string.Empty;
                                ledgerCreditorId = nonBsp.CreditorId;

                                //Desktop Version Reference: T109
                                transactionDetailList.AddDetailRow(LedgerType.CreditorLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, ledgerReference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                                ledgerChartOfAccountId = glSetting.CreditorControlAccount.Id;
                            }
                            else {
                                //Desktop Version Reference: T37
                                ledgerCreditorId = nonBsp.CreditorId;
                                ledgerChartOfAccountId = glSetting.SupplierReturnsAccount.Id;
                            }

                            ledgerReference = reference;
                            transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, ledgerReference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                        }
                    }
                }
            }
            else if (nonBsp.SupplierOtherCommissionReceiptId > 0) {
                foreach (var row in nonBsp.NonBspDetails) {
                    transactionDetail.TransactionDetailRefId = row.Id;
                    transactionDetail.DocumentStatus = row.DocumentStatus;
                    transactionDetail.ReversalStatus = row.ReversalStatus;

                    isCash = row.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard;

                    //Desktop Version Reference: T119
                    ledgerReference = string.Empty;
                    signType = SignType.Credit;
                    amount = -(row.Amount + row.NonCommissionable - row.CommissionProRata);
                    tax = -(row.Tax + row.NonCommissionableTax - row.CommissionTaxProRata);
                    ledgerChartOfAccountId = chartOfAccount.Id;
                    transactionDetailList.AddDetailRow(LedgerType.CreditorLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, ledgerReference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                    //Desktop Version Reference: T128
                    ledgerReference = "Auto Non-BSP Other Commission";
                    signType = SignType.Credit;
                    amount = -row.Amount;
                    tax = -row.Tax;
                    ledgerChartOfAccountId = glSetting.CreditorControlAccount.Id;
                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, ledgerReference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                }
            }

            return true;
        }

        private static bool AddPaymentDetailRows(this List<TransactionDetailViewModel> transactionDetailList, AppLazyContext lazyContext, Payment payment, AccountType accountType) {
            var transactionDetail = new TransactionDetailViewModel {
                TransactionId = -2,
                TransactionType = TransactionType.Payment,
                AgencyId = payment.AgencyId,
                Description = payment.Supplier.Name
            };

            string reference = string.Empty;

            decimal amount = 0;
            decimal tax = 0;
            decimal nonCommissionable = 0;
            decimal nonCommissionableTax = 0;
            decimal commission = 0;
            decimal commissionTax = 0;
            decimal discount = 0;
            decimal discountTax = 0;
            decimal markup = 0;
            decimal markupTax = 0;
            decimal markupGross = 0;
            decimal markupGrossOther = 0;

            decimal totalAmount = 0;
            decimal ccAmount = 0;
            decimal ccTax = 0;
            decimal ccDiscountMarkup = 0;
            decimal ccDiscountMarkupTax = 0;
            decimal ledgerCommission = 0;
            decimal ledgerCommissionTax = 0;
            decimal ledgerDiscount = 0;
            decimal ledgerDiscountTax = 0;

            bool isCash = false;

            SignType signType;
            var glSetting = Setting.GetRow(lazyContext, payment.DocumentDate);

            var chartOfAccount = payment.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, payment.AgencyId);

            int ledgerTripId = payment.TripId;
            int ledgerDebtorId = payment.Debtor.BillingHeadDebtor.Id;
            int ledgerCreditorId = payment.CreditorId;
            int ledgerChartOfAccountId = 0;

            int sign = payment.Sign;

            totalAmount = payment.PaymentDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;

            foreach (var row in payment.PaymentDetails) {
                transactionDetail.TransactionDetailRefId = row.Id;
                transactionDetail.DocumentStatus = row.DocumentStatus;
                transactionDetail.ReversalStatus = row.ReversalStatus;

                isCash = row.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard;

                if (row.Payment.PaymentDetails.Count > 1 && row.Payment.PaymentDetails.Last().Id == row.Id) {
                    var q = transactionDetailList.Where(t => t.TransactionDetailRefId != row.Id);
                    commission = row.Payment.Commission - (q.Sum(t => (decimal?)t.CumulativeCommission) ?? 0);
                    commissionTax = row.Payment.CommissionTax - (q.Sum(t => (decimal?)t.CumulativeCommissionTax) ?? 0);
                    discount = row.Payment.Discount - (q.Sum(t => (decimal?)t.CumulativeDiscount) ?? 0);
                    discountTax = row.Payment.DiscountTax - (q.Sum(t => (decimal?)t.CumulativeDiscountTax) ?? 0);
                    markup = row.Payment.Markup - (q.Sum(t => (decimal?)t.CumulativeMarkup) ?? 0);
                    markupTax = row.Payment.MarkupTax - (q.Sum(t => (decimal?)t.CumulativeMarkupTax) ?? 0);
                    markupGrossOther = row.Payment.MarkupGrossOther - (q.Sum(t => (decimal?)t.CumulativeMarkupGrossOther) ?? 0);
                }
                else {
                    decimal proRataRatio = row.Payment.PaymentDetails.Count == 1 ? 1 : totalAmount == 0 ? 1 / row.Payment.PaymentDetails.Count : (row.Amount + row.Tax) / totalAmount;
                    decimal discountProRataRatio = row.DiscountProRataRatio;
                    decimal markupProRataRatio = row.MarkupProRataRatio;

                    commission = Math.Round(row.Payment.Commission * proRataRatio, 2);
                    commissionTax = Math.Round(row.Payment.CommissionTax * proRataRatio, 2);
                    discount = Math.Round(row.Payment.Discount * discountProRataRatio, 2);
                    discountTax = Math.Round(row.Payment.DiscountTax * discountProRataRatio, 2);
                    markup = Math.Round(row.Payment.Markup * markupProRataRatio, 2);
                    markupTax = Math.Round(row.Payment.MarkupTax * markupProRataRatio, 2);
                    markupGrossOther = Math.Round(row.Payment.MarkupGrossOther * proRataRatio, 2);
                }

                transactionDetail.CumulativeCommission = commission;
                transactionDetail.CumulativeCommissionTax = commissionTax;
                transactionDetail.CumulativeDiscount = discount;
                transactionDetail.CumulativeDiscountTax = discountTax;
                transactionDetail.CumulativeMarkupGrossOther = markupGrossOther;
                transactionDetail.CumulativeMarkup = markup;
                transactionDetail.CumulativeMarkupTax = markupTax;

                nonCommissionable = row.NonCommissionable * sign;
                nonCommissionableTax = row.NonCommissionableTax * sign;
                markupGross = markup + markupTax;

                if (row.Payment.PaymentType == PaymentType.SupplierPayment) {
                    ccDiscountMarkup = (row.Payment.IsCreditCardDiscountApplicable ? discount : 0) - (row.Payment.IncludeMarkupInCreditCardPayment ? markup : 0);
                    ccDiscountMarkupTax = (row.Payment.IsCreditCardDiscountApplicable ? discountTax : 0) - (row.Payment.IncludeMarkupInCreditCardPayment ? markupTax : 0);

                    ccAmount = row.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? row.Amount + row.NonCommissionable - ccDiscountMarkup : 0;
                    ccTax = row.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? row.Tax + row.NonCommissionableTax - ccDiscountMarkupTax : 0;
                }
                else {
                    ccAmount = 0;
                    ccTax = 0;
                }

                if (accountType == AccountType.Client || accountType == AccountType.Debtor) {
                    var ledgerType = accountType == AccountType.Client ? LedgerType.ClientLedger : LedgerType.DebtorLedger;

                    //Desktop Version Reference: T110, T114
                    ledgerChartOfAccountId = chartOfAccount.Id;
                    reference = row.Payment.IsDeposit ? "Deposit" : string.Empty;
                    signType = SignType.Debit;
                    amount = row.Amount + row.NonCommissionable;
                    tax = row.Tax + row.NonCommissionableTax;
                    ledgerDiscount = -discount;
                    ledgerDiscountTax = -discountTax;
                    transactionDetailList.AddDetailRow(ledgerType, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, commission, commissionTax, ledgerDiscount, ledgerDiscountTax, nonCommissionable, nonCommissionableTax, amount, tax, isCash);

                    //Desktop Version Reference: T111, T115
                    if (ccAmount != 0) {
                        ledgerChartOfAccountId = chartOfAccount.Id;
                        reference = "Credit Card";
                        signType = SignType.Credit;
                        amount = -ccAmount;
                        tax = -ccTax;
                        transactionDetailList.AddDetailRow(ledgerType, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.ExcludeFromSalesAnalysis);
                    }

                    //Desktop Version Reference: T112, T116
                    if (discount != 0) {
                        ledgerChartOfAccountId = chartOfAccount.Id;
                        reference = "Discount";
                        signType = SignType.Debit;
                        amount = -discount;
                        tax = -discountTax;
                        transactionDetailList.AddDetailRow(ledgerType, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);
                    }

                    //Desktop Version Reference: T113, T117
                    if (markupGross != 0) {
                        ledgerChartOfAccountId = chartOfAccount.Id;
                        reference = "Mark-Up";
                        signType = SignType.Debit;
                        amount = markup * sign;
                        tax = markupTax * sign;
                        ledgerCommission = row.Payment.MarkupStrategy.GetRemainderCommission(markupGrossOther, amount) * sign;
                        ledgerCommissionTax = row.Payment.MarkupStrategy.GetRemainderCommission(markupGrossOther, tax) * sign;
                        transactionDetailList.AddDetailRow(ledgerType, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, ledgerCommission, ledgerCommissionTax, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Markup);
                    }
                }
                else if (accountType == AccountType.Creditor) {
                    //Creditor
                    //Desktop Version Reference: T118
                    if (row.Payment.PaymentType != PaymentType.BspReturn) {
                        ledgerChartOfAccountId = chartOfAccount.Id;
                        reference = string.Empty;
                        signType = SignType.Debit;
                        amount = row.Amount + row.NonCommissionable - ccAmount - discount;
                        tax = row.Tax + row.NonCommissionableTax - ccTax - discountTax;
                        transactionDetailList.AddDetailRow(LedgerType.CreditorLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, row.Payment.CreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                    }
                }

                //General Ledger
                //Desktop Version Reference: T56
                ledgerChartOfAccountId = row.Payment.BankAccount.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Payment.AgencyId).Id;
                reference = row.Payment.Payee;
                signType = SignType.Credit;

                if (row.Payment.PaymentType == PaymentType.SupplierPayment) {
                    amount = -(row.Amount + row.NonCommissionable - ccAmount - commission);
                    tax = -(row.Tax + row.NonCommissionableTax - ccTax - commissionTax);
                }
                else {
                    amount = -(row.Amount + row.NonCommissionable);
                    tax = -(row.Tax + row.NonCommissionableTax);
                }

                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                ledgerChartOfAccountId = 0;
                reference = row.Payment.Payee;
                signType = SignType.Debit;

                if (row.Payment.PaymentType == PaymentType.BspReturn) {
                    //Desktop Version Reference: T57
                    ledgerChartOfAccountId = glSetting.BspAccrualAccount.Id;
                    amount = row.Amount + row.NonCommissionable;
                    tax = row.Tax + row.NonCommissionableTax;
                }
                else if (row.Payment.PaymentType == PaymentType.NonBspReturn) {
                    //Desktop Version Reference: T58
                    if (row.Payment.CreditorId > 0) {
                        ledgerChartOfAccountId = glSetting.CreditorControlAccount.Id;
                    }
                    else {
                        ledgerChartOfAccountId = glSetting.SupplierReturnsAccount.Id;
                    }

                    amount = row.Amount + row.NonCommissionable;
                    tax = row.Tax + row.NonCommissionableTax;
                }
                else {
                    amount = row.Amount + row.NonCommissionable - ccAmount - discount;
                    tax = row.Tax + row.NonCommissionableTax - ccTax - discountTax;

                    if (accountType == AccountType.Client) {
                        //Desktop Version Reference: T61
                        ledgerChartOfAccountId = glSetting.ClientControlAccount.Id;
                    }
                    else if (accountType == AccountType.Debtor) {
                        //Desktop Version Reference: T62
                        ledgerChartOfAccountId = glSetting.DebtorControlAccount.Id;
                    }
                    else if (accountType == AccountType.Creditor) {
                        //Desktop Version Reference: T63
                        if (row.Payment.CreditorId > 0) {
                            ledgerChartOfAccountId = glSetting.CreditorControlAccount.Id;
                        }
                        else {
                            ledgerChartOfAccountId = glSetting.SupplierReturnsAccount.Id;
                        }
                    }
                    else if (accountType == AccountType.GeneralLedger) {
                        //Desktop Version Reference: T129
                        if (chartOfAccount.Id > 0) {
                            ledgerChartOfAccountId = chartOfAccount.Id;
                            amount = row.Amount + row.NonCommissionable;
                            tax = 0;
                        }
                    }
                }

                if (ledgerChartOfAccountId > 0)
                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                //Desktop Version Reference: T60
                if (row.Payment.Commission != 0 || row.Payment.PaymentType == PaymentType.SupplierPayment || row.Payment.PaymentType == PaymentType.ClientRefund) {
                    ledgerChartOfAccountId = glSetting.CommissionAccount.Id;
                    reference = "Commission";
                    signType = SignType.Credit;
                    amount = -commission * sign;
                    tax = 0;
                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                }

                signType = SignType.None;

                if (row.Payment.PaymentType == PaymentType.SupplierPayment) {
                    if (row.Payment.IsTaxApplicable) {
                        //Desktop Version Reference: T64
                        reference = string.Format("Commission {0}", Resource.TaxLabel);
                        ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                        signType = SignType.Credit;
                        amount = -commissionTax * sign;
                        tax = 0;
                    }
                }
                else if (accountType == AccountType.GeneralLedger && row.Tax != 0) {
                    reference = row.Payment.Payee;
                    signType = SignType.Debit;
                    amount = row.Tax;
                    tax = 0;

                    if (chartOfAccount.AccountCategory == AccountCategory.Income) {
                        //Desktop Version Reference: T67
                        ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                    }
                    else {
                        //Desktop Version Reference: T68
                        ledgerChartOfAccountId = glSetting.PurchasesTaxAccount.Id;
                    }
                }

                if (signType != SignType.None)
                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                //Desktop Version Reference: T69
                if (row.Payment.IsDiscountPermitted && discount != 0) {
                    ledgerChartOfAccountId = row.Payment.DiscountReason.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Payment.AgencyId).Id;
                    reference = "Discount";
                    signType = SignType.Debit;
                    amount = discount * sign;
                    tax = 0;
                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);

                    //Desktop Version Reference: T70
                    if (discountTax != 0) {
                        ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                        reference = string.Format("Discount {0}", Resource.TaxLabel);
                        signType = SignType.Debit;
                        amount = discountTax * sign;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);
                    }
                }

                if (row.Payment.IsMarkupPermitted && markupGross != 0) {
                    reference = "Mark-Up";
                    signType = SignType.Debit;
                    amount = markup * sign;
                    tax = markupTax * sign;

                    if (accountType == AccountType.Client) {
                        //Desktop Version Reference: T71
                        ledgerChartOfAccountId = glSetting.ClientControlAccount.Id;
                    }
                    else if (accountType == AccountType.Debtor) {
                        //Desktop Version Reference: T72
                        ledgerChartOfAccountId = glSetting.DebtorControlAccount.Id;
                    }

                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Markup);

                    decimal markupRemainder = markup;

                    //Desktop Version Reference: T74
                    foreach (var row3 in row.Payment.MarkupStrategy.MarkupStrategyElements) {
                        ledgerChartOfAccountId = row3.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Payment.AgencyId).Id;
                        reference = string.Empty;
                        signType = SignType.Credit;

                        amount = row3.GetAmount(row3.ApportionMethod == ApportionMethod.Fixed ? markupGrossOther : row.Payment.MarkupGrossOther, markupGross) - markupTax;

                        markupRemainder -= amount;
                        amount = -amount * sign;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                    }

                    //Desktop Version Reference: T73
                    if (markupRemainder != 0) {
                        ledgerChartOfAccountId = row.Payment.MarkupStrategy.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Payment.AgencyId).Id;
                        reference = string.Empty;
                        signType = SignType.Credit;
                        amount = -markupRemainder * sign;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                    }

                    //Desktop Version Reference: T127
                    if (markupTax != 0) {
                        ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                        reference = string.Format("Mark-Up {0}", Resource.TaxLabel);
                        signType = SignType.Credit;
                        amount = -markupTax * sign;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Markup);
                    }
                }
            }

            return true;
        }

        private static bool AddInvoiceDetailRows(this List<TransactionDetailViewModel> transactionDetailList, AppLazyContext lazyContext, Invoice invoice) {
            var transactionDetail = new TransactionDetailViewModel {
                TransactionId = -2,
                TransactionType = TransactionType.Invoice,
                ReversalStatus = ReversalStatus.None
            };

            const int ledgerCreditorId = -1;
            const bool isCash = true;

            string reference;

            decimal amount;
            decimal tax;
            decimal discount;
            decimal discountTax;

            SignType signType;
            var glSetting = Setting.GetRow(lazyContext, invoice.DocumentDate);

            int ledgerTripId;
            int ledgerDebtorId = invoice.Debtor.BillingHeadDebtor.Id;
            int ledgerChartOfAccountId;
            int sign;

            if (invoice.InvoiceType == InvoiceType.CreditNote) {
                sign = -1;
            }
            else {
                sign = 1;
            }

            foreach (var row in invoice.InvoiceDetails) {
                transactionDetail.TransactionDetailRefId = row.Id;
                transactionDetail.DocumentStatus = row.DocumentStatus;
                transactionDetail.AgencyId = row.AgencyId;

                if (invoice.AccountType == AccountType.Client) {
                    transactionDetail.Description = row.TripLineId > 0 ? row.TripLine.Description : string.Empty;
                }
                else {
                    transactionDetail.Description = row.ChartOfAccount.AccountName;
                }

                ledgerTripId = row.TripId;

                var chartOfAccount = row.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Invoice.Debtor.AgencyId);

                discount = row.Discount;
                discountTax = row.DiscountTax;

                switch (row.Invoice.AccountType) {
                    case AccountType.Client:
                        //Desktop Version Reference: T120
                        ledgerChartOfAccountId = chartOfAccount.Id;
                        reference = string.Empty;
                        signType = invoice.InvoiceType == InvoiceType.CreditNote ? SignType.Debit : SignType.Credit;
                        amount = -(row.Amount + row.PaymentTax) * sign;
                        tax = -row.Tax * sign;
                        transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                        //Desktop Version Reference: T121
                        if (discount != 0) {
                            ledgerChartOfAccountId = chartOfAccount.Id;
                            reference = "Discount";
                            signType = invoice.InvoiceType == InvoiceType.CreditNote ? SignType.Debit : SignType.Credit;
                            amount = discount * sign;
                            tax = discountTax * sign;
                            transactionDetailList.AddDetailRow(LedgerType.ClientLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);
                        }

                        //Desktop Version Reference: T76
                        ledgerChartOfAccountId = glSetting.ClientControlAccount.Id;
                        reference = string.Empty;
                        signType = invoice.InvoiceType == InvoiceType.CreditNote ? SignType.Debit : SignType.Credit;
                        amount = -(row.Amount + row.PaymentTax - discount) * sign;
                        tax = -(row.Tax - discountTax) * sign;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                        break;
                    case AccountType.GeneralLedger:
                        //Desktop Version Reference: T79
                        ledgerChartOfAccountId = chartOfAccount.Id;
                        reference = string.Empty;
                        signType = invoice.InvoiceType == InvoiceType.CreditNote ? SignType.Debit : SignType.Credit;
                        amount = -(row.Amount - discount) * sign;
                        tax = 0;
                        transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                        if (row.IsTaxApplicable) {
                            //Desktop Version Reference: T77
                            ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                            reference = Resource.TaxLabel;
                            signType = invoice.InvoiceType == InvoiceType.CreditNote ? SignType.Debit : SignType.Credit;
                            amount = -(row.Tax + row.PaymentTax - discountTax) * sign;
                            tax = 0;
                            transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
                        }

                        break;
                }

                //Desktop Version Reference: T78
                ledgerChartOfAccountId = glSetting.DebtorControlAccount.Id;
                reference = string.Empty;
                signType = invoice.InvoiceType == InvoiceType.CreditNote ? SignType.Credit : SignType.Debit;
                amount = (row.Amount + row.PaymentTax - discount) * sign;
                tax = (row.Tax - discountTax) * sign;
                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                //Desktop Version Reference: T81
                ledgerChartOfAccountId = chartOfAccount.Id;
                reference = string.Empty;
                signType = invoice.InvoiceType == InvoiceType.CreditNote ? SignType.Credit : SignType.Debit;
                amount = (row.Amount + row.PaymentTax) * sign;
                tax = row.Tax * sign;
                transactionDetailList.AddDetailRow(LedgerType.DebtorLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);

                //Desktop Version Reference: T82
                if (discount != 0) {
                    ledgerChartOfAccountId = row.DiscountReason.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.Invoice.Debtor.AgencyId).Id;
                    reference = "Discount";
                    signType = invoice.InvoiceType == InvoiceType.CreditNote ? SignType.Credit : SignType.Debit;
                    amount = -discount * sign;
                    tax = -discountTax * sign;
                    transactionDetailList.AddDetailRow(LedgerType.DebtorLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, TransactionDetailType.Discount);
                }
            }

            return true;
        }

        private static bool AddJournalDetailRows(this List<TransactionDetailViewModel> transactionDetailList, AppLazyContext lazyContext, Journal journal) {
            var transactionDetail = new TransactionDetailViewModel {
                TransactionId = -2,
                TransactionType = TransactionType.Journal,
                ReversalStatus = ReversalStatus.None
            };

            const decimal tax = 0;
            const bool isCash = true;

            int ledgerTripId;
            int ledgerDebtorId;
            int ledgerCreditorId;
            int ledgerChartOfAccountId;

            string reference = string.Empty;
            decimal amount;

            GeneralLedgerSettingDetail glSetting = null;

            foreach (var row in journal.JournalDetails) {
                transactionDetail.TransactionDetailRefId = row.Id;
                transactionDetail.DocumentStatus = row.Journal.DocumentStatus;
                transactionDetail.AgencyId = row.AgencyId;
                transactionDetail.Description = row.Comments;

                ledgerTripId = row.AccountType == AccountType.Client ? row.TripId : -1;
                ledgerDebtorId = row.AccountType == AccountType.Debtor ? row.Debtor.BillingHeadDebtor.Id : -1;
                ledgerCreditorId = row.AccountType == AccountType.Creditor ? row.CreditorId : -1;
                ledgerChartOfAccountId = row.AccountType == AccountType.GeneralLedger ? row.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.AgencyId).Id : -1;

                if (glSetting == null)
                    glSetting = Setting.GetRow(lazyContext, row.Journal.DocumentDate);

                if (row.SignType == SignType.Debit) {
                    amount = row.Amount;
                }
                else {
                    amount = -row.Amount;
                }

                var ledgerType = LedgerType.None;

                switch (row.AccountType) {
                    case AccountType.Client:
                        ledgerType = LedgerType.ClientLedger;
                        ledgerChartOfAccountId = glSetting.ClientControlAccount.Id;
                        break;
                    case AccountType.Debtor:
                        ledgerType = LedgerType.DebtorLedger;
                        ledgerChartOfAccountId = glSetting.DebtorControlAccount.Id;
                        break;
                    case AccountType.Creditor:
                        ledgerType = LedgerType.CreditorLedger;
                        ledgerChartOfAccountId = glSetting.CreditorControlAccount.Id;
                        break;
                    default:
                        ledgerType = LedgerType.GeneralLedger;
                        ledgerChartOfAccountId = row.ChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, row.AgencyId).Id;
                        break;
                }

                decimal commission = row.Commission;
                decimal commissionTax = row.CommissionTax;

                transactionDetailList.AddDetailRow(ledgerType, row.SignType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, commission, commissionTax, 0, 0, 0, 0, amount, tax, isCash);

                if (ledgerType != LedgerType.GeneralLedger && ledgerType != LedgerType.None)
                    transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, row.SignType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash);
            }

            return true;
        }

        private static bool AddAdjustmentRows(this List<TransactionDetailViewModel> transactionDetailList, AppLazyContext lazyContext, Adjustment adjustment) {
            var transactionDetail = new TransactionDetailViewModel {
                TransactionId = -2,
                TransactionDetailRefId = -1,
                TransactionType = TransactionType.Adjustment,
                AgencyId = adjustment.DebitAgencyId
            };

            var glSetting = Setting.GetRow(lazyContext, adjustment.DocumentDate);

            transactionDetail.DocumentStatus = adjustment.DocumentStatus;
            transactionDetail.ReversalStatus = adjustment.ReversalStatus;
            transactionDetail.Description = adjustment.Comments;

            string reference = string.Empty;

            int ledgerTripId = adjustment.DebitType == DebitCreditType.Client ? adjustment.DebitTripId : -1;
            int ledgerDebtorId = adjustment.DebitType == DebitCreditType.Debtor ? adjustment.DebitDebtor.BillingHeadDebtor.Id : -1;
            int ledgerCreditorId = adjustment.DebitType == DebitCreditType.Creditor ? adjustment.DebitCreditorId : -1;
            int ledgerChartOfAccountId = adjustment.DebitType == DebitCreditType.GeneralLedger ? adjustment.DebitChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, adjustment.DebitAgencyId).Id : -1;

            var signType = SignType.Debit;
            bool isCash;

            decimal amount = adjustment.Amount;
            decimal tax = adjustment.IsDebitTaxApplicable ? 0 : adjustment.Tax;
            decimal commission;
            decimal commissionTax;

            var transactionDetailType = adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.None && !adjustment.IsDebitTaxApplicable && !adjustment.IsCreditTaxApplicable ? TransactionDetailType.ExcludeFromSalesAnalysis
                : adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.CommissionOnly ? TransactionDetailType.CommissionOnly
                : adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.TaxAuditCommissionOnly ? TransactionDetailType.TaxAuditCommissionOnly
                : TransactionDetailType.Normal;

            if (adjustment.DebitType == DebitCreditType.Client || adjustment.DebitType == DebitCreditType.Debtor) {
                isCash = adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.Cash || adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.CashCommission || adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.CommissionOnly || adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.TaxAuditCommissionOnly;

                if (adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.CashCommission || adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.CreditCardCommission) {
                    commission = amount;
                    commissionTax = tax;
                }
                else {
                    commission = 0;
                    commissionTax = 0;
                }
            }
            else {
                isCash = true;
                commission = 0;
                commissionTax = 0;
            }

            var ledgerType = GetAdjustmentLedger(adjustment.DebitType);
            var transactionAnalysisType = adjustment.IsDebitTaxApplicable && ledgerType != LedgerType.GeneralLedger ? TransactionAnalysisType.TaxAuditReport : TransactionAnalysisType.All;
            transactionDetailList.AddDetailRow(ledgerType, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, commission, commissionTax, 0, 0, 0, 0, amount, tax, isCash, transactionDetailType, transactionAnalysisType);

            ledgerChartOfAccountId = GetAdjustmentControlAccountId(adjustment.DebitType, glSetting);

            if (ledgerChartOfAccountId > -1)
                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, transactionDetailType);

            if (adjustment.IsDebitTaxApplicable) {
                amount = adjustment.Tax;
                tax = 0;
                ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, transactionDetailType);
            }

            ledgerTripId = adjustment.CreditType == DebitCreditType.Client ? adjustment.CreditTripId : -1;
            ledgerDebtorId = adjustment.CreditType == DebitCreditType.Debtor ? adjustment.CreditDebtor.BillingHeadDebtor.Id : -1;
            ledgerCreditorId = adjustment.CreditType == DebitCreditType.Creditor ? adjustment.CreditCreditorId : -1;
            ledgerChartOfAccountId = adjustment.CreditType == DebitCreditType.GeneralLedger ? adjustment.CreditChartOfAccount.GetChartOfAccountByAgencyId(lazyContext, adjustment.DebitAgencyId).Id : -1;

            signType = SignType.Credit;
            amount = -adjustment.Amount;
            tax = adjustment.IsCreditTaxApplicable ? 0 : -adjustment.Tax;

            if (adjustment.CreditType == DebitCreditType.Client || adjustment.CreditType == DebitCreditType.Debtor) {
                isCash = adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.Cash || adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.CashCommission || adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.CommissionOnly || adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.TaxAuditCommissionOnly;

                if (adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.CashCommission || adjustment.AdjustmentType.AdjustmentTransactionType == AdjustmentTransactionType.CreditCardCommission) {
                    commission = amount;
                    commissionTax = tax;
                }
                else {
                    commission = 0;
                    commissionTax = 0;
                }
            }
            else {
                isCash = true;
                commission = 0;
                commissionTax = 0;
            }

            ledgerType = GetAdjustmentLedger(adjustment.CreditType);
            transactionAnalysisType = adjustment.IsCreditTaxApplicable && ledgerType != LedgerType.GeneralLedger ? TransactionAnalysisType.TaxAuditReport : TransactionAnalysisType.All;
            transactionDetailList.AddDetailRow(ledgerType, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, commission, commissionTax, 0, 0, 0, 0, amount, tax, isCash, transactionDetailType, transactionAnalysisType);

            ledgerChartOfAccountId = GetAdjustmentControlAccountId(adjustment.CreditType, glSetting);

            if (ledgerChartOfAccountId > -1)
                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, transactionDetailType);

            if (adjustment.IsCreditTaxApplicable) {
                amount = -adjustment.Tax;
                tax = 0;
                ledgerChartOfAccountId = glSetting.SalesTaxAccount.Id;
                transactionDetailList.AddDetailRow(LedgerType.GeneralLedger, signType, transactionDetail, ledgerTripId, ledgerDebtorId, ledgerCreditorId, ledgerChartOfAccountId, reference, 0, 0, 0, 0, 0, 0, amount, tax, isCash, transactionDetailType);
            }

            return true;
        }

        private static LedgerType GetAdjustmentLedger(DebitCreditType debitCreditType) {
            switch (debitCreditType) {
                default:
                    return LedgerType.GeneralLedger;
                case DebitCreditType.Client:
                    return LedgerType.ClientLedger;
                case DebitCreditType.Debtor:
                    return LedgerType.DebtorLedger;
                case DebitCreditType.Creditor:
                    return LedgerType.CreditorLedger;
            }
        }

        private static int GetAdjustmentControlAccountId(DebitCreditType debitCreditType, GeneralLedgerSettingDetail glSetting) {
            switch (debitCreditType) {
                default:
                    return -1;
                case DebitCreditType.Client:
                    return glSetting.ClientControlAccount.Id;
                case DebitCreditType.Debtor:
                    return glSetting.DebtorControlAccount.Id;
                case DebitCreditType.Creditor:
                    return glSetting.CreditorControlAccount.Id;
            }
        }

        private static void AddRow(this List<TransactionViewModel> transactionList, int transactionRefId, TransactionType transactionType, DocumentStatus documentStatus, string documentType, string documentNo, DateTime documentDate) {
            transactionList.Add(new TransactionViewModel {
                TransactionId = -2,
                TransactionRefId = transactionRefId,
                TransactionType = transactionType,
                DocumentStatus = documentStatus,
                DocumentType = documentType.Left(50),
                DocumentNo = documentNo,
                DocumentDate = documentDate
            });
        }

        private static void AddDetailRow(this List<TransactionDetailViewModel> transactionDetailList, LedgerType ledgerType, SignType signType, TransactionDetailViewModel model, int tripId, int debtorId, int creditorId, int chartOfAccountId, string reference, decimal commission, decimal commissionTax, decimal discount, decimal discountTax, decimal nonCommissionable, decimal nonCommissionableTax, decimal amount, decimal tax, bool isCash, TransactionDetailType transactionDetailType = TransactionDetailType.Normal, TransactionAnalysisType transactionAnalysisType = TransactionAnalysisType.All) {
            switch (ledgerType) {
                case LedgerType.ClientLedger:
                    debtorId = -1;
                    creditorId = -1;
                    chartOfAccountId = -1;
                    break;
                case LedgerType.DebtorLedger:
                    tripId = -1;
                    creditorId = -1;
                    chartOfAccountId = -1;
                    break;
                case LedgerType.CreditorLedger:
                    tripId = -1;
                    debtorId = -1;
                    chartOfAccountId = -1;
                    break;
                case LedgerType.GeneralLedger:
                    tripId = -1;
                    debtorId = -1;
                    creditorId = -1;
                    break;
            }

            transactionDetailList.Add(new TransactionDetailViewModel {
                TransactionId = model.TransactionId,
                TransactionDetailRefId = model.TransactionDetailRefId,
                AgencyId = model.AgencyId,
                TransactionType = model.TransactionType,
                LedgerType = ledgerType,
                SignType = signType,
                DocumentStatus = model.DocumentStatus,
                ReversalStatus = model.ReversalStatus,
                TripId = tripId,
                DebtorId = debtorId,
                CreditorId = creditorId,
                ChartOfAccountId = chartOfAccountId,
                Reference = reference.Replace("Not Specified", string.Empty).Replace("None", string.Empty).Left(100),
                Description = model.Description.Replace("Not Specified", string.Empty).Replace("None", string.Empty).Left(100),
                Commission = commission,
                CommissionTax = commissionTax,
                Discount = discount,
                DiscountTax = discountTax,
                NonCommissionable = nonCommissionable,
                NonCommissionableTax = nonCommissionableTax,
                Amount = amount,
                Tax = tax,
                TransactionDetailType = transactionDetailType,
                TransactionAnalysisType = transactionAnalysisType,
                IsCash = isCash,
                CumulativeCommission = model.CumulativeCommission,
                CumulativeCommissionTax = model.CumulativeCommissionTax,
                CumulativeDiscount = model.CumulativeDiscount,
                CumulativeDiscountTax = model.CumulativeDiscountTax,
                CumulativeMarkup = model.CumulativeMarkup,
                CumulativeMarkupTax = model.CumulativeMarkupTax,
                CumulativeMarkupGrossOther = model.CumulativeMarkupGrossOther,
                CumulativeNonCommissionable = model.CumulativeNonCommissionable,
                CumulativeNonCommissionableTax = model.CumulativeNonCommissionableTax,
                CumulativeClientRefund = model.CumulativeClientRefund,
                CumulativeClientRefundTax = model.CumulativeClientRefundTax,
                CumulativeOriginalSaleTotal = model.CumulativeOriginalSaleTotal,
                CumulativeOriginalSaleTotalTax = model.CumulativeOriginalSaleTotalTax,
                CumulativeCancellationFee = model.CumulativeCancellationFee,
                CumulativeCancellationFeeTax = model.CumulativeCancellationFeeTax,
                CumulativeSupplierCancellationFee = model.CumulativeSupplierCancellationFee,
                CumulativeSupplierCancellationFeeTax = model.CumulativeSupplierCancellationFeeTax,
                CumulativeAmountPayable = model.CumulativeAmountPayable,
                CumulativeAmountPayableTax = model.CumulativeAmountPayableTax
            });

            model.CumulativeCommission = 0;
            model.CumulativeCommissionTax = 0;
            model.CumulativeDiscount = 0;
            model.CumulativeDiscountTax = 0;
            model.CumulativeMarkup = 0;
            model.CumulativeMarkupTax = 0;
            model.CumulativeMarkupGrossOther = 0;
            model.CumulativeNonCommissionable = 0;
            model.CumulativeNonCommissionableTax = 0;
            model.CumulativeClientRefund = 0;
            model.CumulativeClientRefundTax = 0;
            model.CumulativeOriginalSaleTotal = 0;
            model.CumulativeOriginalSaleTotalTax = 0;
            model.CumulativeCancellationFee = 0;
            model.CumulativeCancellationFeeTax = 0;
            model.CumulativeSupplierCancellationFee = 0;
            model.CumulativeSupplierCancellationFeeTax = 0;
            model.CumulativeAmountPayable = 0;
            model.CumulativeAmountPayableTax = 0;
        }

        private static bool AddMerchantFeeReducedCommissionRows(AppLazyContext lazyContext, List<SalesAnalysisMappingModel> salesAnalysisList, int groupNo) {
            var merchantFeeTxnDetails = Receipt.GetReceiptMerchantFeeTxnDetailList(lazyContext, groupNo, AccountType.Client).ToList();

            if (merchantFeeTxnDetails.Count == 0)
                return false;

            foreach (var merchantFeeTxnDetail in merchantFeeTxnDetails) {
                var q = lazyContext.TransactionDetail.Where(t => t.ReceiptDetailId == merchantFeeTxnDetail.ClientReceiptDetailId && t.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission).ToList();

                if (q.Count == 0) {
                    var txnDetail = lazyContext.TransactionDetail.Find((long)-1).Clone() as TransactionDetail;

                    txnDetail.Id = 0;
                    txnDetail.TransactionId = merchantFeeTxnDetail.Transaction.Id;
                    txnDetail.Transaction = merchantFeeTxnDetail.Transaction;

                    q.Add(txnDetail);
                }

                foreach (var txnDetail in q) {
                    var model = new TransactionDetailViewModel {
                        TransactionDetailId = txnDetail.Id,
                        TransactionId = merchantFeeTxnDetail.Transaction.Id,
                        LedgerType = LedgerType.ClientLedger,
                        SignType = SignType.Credit,
                        DocumentStatus = DocumentStatus.Open,
                        ReversalStatus = ReversalStatus.None,
                        TripId = -1,
                        DebtorId = merchantFeeTxnDetail.DebtorId,
                        CreditorId = -1,
                        ChartOfAccountId = -1,
                        TransactionDetailRefId = merchantFeeTxnDetail.ClientReceiptDetailId,
                        AgencyId = txnDetail.AgencyId,
                        Description = string.Format("Receipt No {0}", merchantFeeTxnDetail.ClientReceiptNo),
                        Reference = "Merchant Fee Reduced Commission",
                        TransactionDetailType = TransactionDetailType.MerchantFeeReducedCommission,
                        TransactionAnalysisType = TransactionAnalysisType.SalesAnalysis,
                        Commission = -merchantFeeTxnDetail.Amount,
                        CommissionTax = -merchantFeeTxnDetail.Tax,
                        IsCash = true
                    };

                    txnDetail.UpdateEntity(lazyContext, model, salesAnalysisList, true);
                }
            }

            return true;
        }

        private static bool UpdateEntity(this Transaction transaction, AppLazyContext lazyContext, TransactionViewModel model) {
            transaction.TransactionType = model.TransactionType;
            transaction.TransactionType = model.TransactionType;
            transaction.DocumentType = model.DocumentType;
            transaction.DocumentNo = model.DocumentNo;
            transaction.DocumentDate = model.DocumentDate;

            transaction.ReceiptId = model.TransactionType == TransactionType.Receipt ? model.TransactionRefId : -1;
            transaction.BspId = model.TransactionType == TransactionType.Bsp ? model.TransactionRefId : -1;
            transaction.NonBspId = model.TransactionType == TransactionType.NonBsp ? model.TransactionRefId : -1;
            transaction.PaymentId = model.TransactionType == TransactionType.Payment ? model.TransactionRefId : -1;
            transaction.InvoiceId = model.TransactionType == TransactionType.Invoice ? model.TransactionRefId : -1;
            transaction.JournalId = model.TransactionType == TransactionType.Journal ? model.TransactionRefId : -1;
            transaction.AdjustmentId = model.TransactionType == TransactionType.Adjustment ? model.TransactionRefId : -1;

            if (transaction.Id <= 0)
                return lazyContext.Insert(transaction, false);

            return lazyContext.Save(transaction, false);
        }

        private static bool UpdateEntity(this TransactionDetail transactionDetail, AppLazyContext lazyContext, TransactionDetailViewModel model, List<SalesAnalysisMappingModel> salesAnalysisList, bool isReducedCommissionEntry) {
            transactionDetail.LedgerType = model.LedgerType;
            transactionDetail.SignType = model.SignType;
            transactionDetail.DocumentStatus = model.DocumentStatus;
            transactionDetail.ReversalStatus = model.ReversalStatus;

            transactionDetail.TripId = model.TripId;
            transactionDetail.DebtorId = model.DebtorId;
            transactionDetail.CreditorId = model.CreditorId;
            transactionDetail.ChartOfAccountId = model.ChartOfAccountId;

            transactionDetail.ReceiptDetailId = model.TransactionType == TransactionType.Receipt ? model.TransactionDetailRefId : -1;
            transactionDetail.BspDetailId = model.TransactionType == TransactionType.Bsp ? model.TransactionDetailRefId : -1;
            transactionDetail.NonBspDetailId = model.TransactionType == TransactionType.NonBsp ? model.TransactionDetailRefId : -1;
            transactionDetail.PaymentDetailId = model.TransactionType == TransactionType.Payment ? model.TransactionDetailRefId : -1;
            transactionDetail.InvoiceDetailId = model.TransactionType == TransactionType.Invoice ? model.TransactionDetailRefId : -1;
            transactionDetail.JournalDetailId = model.TransactionType == TransactionType.Journal ? model.TransactionDetailRefId : -1;
            transactionDetail.AgencyId = model.AgencyId;

            transactionDetail.Description = model.Description.Left(100);
            transactionDetail.Reference = model.Reference.Left(100);

            transactionDetail.Commission = model.Commission;
            transactionDetail.CommissionTax = model.CommissionTax;
            transactionDetail.Discount = model.Discount;
            transactionDetail.DiscountTax = model.DiscountTax;
            transactionDetail.NonCommissionable = model.NonCommissionable;
            transactionDetail.NonCommissionableTax = model.NonCommissionableTax;
            transactionDetail.Amount = model.Amount;
            transactionDetail.Tax = model.Tax;
            transactionDetail.IsCash = model.IsCash;

            transactionDetail.TransactionDetailType = model.TransactionDetailType;
            transactionDetail.TransactionAnalysisType = model.TransactionAnalysisType;

            transactionDetail.SalesAnalysisAirlineId = -1;
            transactionDetail.SalesAnalysisPassengerId = -1;
            transactionDetail.SalesAnalysisOfferedFare = 0;
            transactionDetail.SalesAnalysisOfferedReasonId = -1;
            transactionDetail.SalesAnalysisDebtorId = -1;
            transactionDetail.SalesAnalysisCreditorId = -1;
            transactionDetail.SalesAnalysisSupplierId = -1;
            transactionDetail.SalesAnalysisSaleTypeId = -1;
            transactionDetail.SalesAnalysisDiscountReasonId = -1;
            transactionDetail.SalesAnalysisGroupId = -1;
            transactionDetail.SalesAnalysisClassId = -1;
            transactionDetail.SalesAnalysisSourceId = -1;
            transactionDetail.SalesAnalysisCategoryId = -1;
            transactionDetail.SalesAnalysisDestinationId = -1;
            transactionDetail.SalesAnalysisRegionId = -1;
            transactionDetail.SalesAnalysisLocationId = -1;
            transactionDetail.SalesAnalysisConsultantId = -1;
            transactionDetail.SalesAnalysisAgentId = -1;

            bool result1;
            bool result2 = false;

            if (transactionDetail.Id <= 0) {
                result1 = lazyContext.Insert(transactionDetail, false);
            }
            else {
                result1 = lazyContext.Save(transactionDetail, false);
            }

            lazyContext.Entry(transactionDetail).State = EntityState.Detached;

            transactionDetail = lazyContext.TransactionDetail
                .Include(t => t.Transaction).ThenInclude(t => t.Receipt).Include(t => t.ReceiptDetail)
                .Include(t => t.Transaction).ThenInclude(t => t.Bsp).Include(t => t.BspDetail)
                .Include(t => t.Transaction).ThenInclude(t => t.NonBsp).Include(t => t.NonBspDetail)
                .Include(t => t.Transaction).ThenInclude(t => t.Payment).Include(t => t.PaymentDetail)
                .Include(t => t.Transaction).ThenInclude(t => t.Invoice).Include(t => t.InvoiceDetail)
                .Include(t => t.Transaction).ThenInclude(t => t.Journal).Include(t => t.JournalDetail)
                .Include(t => t.Transaction).ThenInclude(t => t.Adjustment)
                .Single(t => t.Id == transactionDetail.Id);

            if (TransactionDetail.SalesAnalysisWhereClause.Compile().Invoke(transactionDetail))
                result2 = transactionDetail.UpdateSalesAnalysis(lazyContext, salesAnalysisList, isReducedCommissionEntry);

            return result1 || result2;
        }

        private static bool UpdateSalesAnalysis(this TransactionDetail transactionDetail, AppLazyContext lazyContext, List<SalesAnalysisMappingModel> salesAnalysisList, bool isReducedCommissionEntry) {
            transactionDetail.SalesAnalysisAirlineId = transactionDetail.SalesAirlineId;
            transactionDetail.SalesAnalysisPassengerId = transactionDetail.SalesPassengerId;
            transactionDetail.SalesAnalysisCreditorId = transactionDetail.SalesCreditorId;
            transactionDetail.SalesAnalysisSupplierId = transactionDetail.SalesSupplierId;
            transactionDetail.SalesAnalysisSaleTypeId = transactionDetail.SalesSaleTypeId;
            transactionDetail.SalesAnalysisOfferedFare = transactionDetail.TransactionDetailType == TransactionDetailType.Normal ? transactionDetail.OfferedFare : 0;
            transactionDetail.SalesAnalysisOfferedReasonId = transactionDetail.TransactionDetailType == TransactionDetailType.Normal ? transactionDetail.SalesOfferedReasonId : -1;
            transactionDetail.SalesAnalysisDiscountReasonId = transactionDetail.TransactionDetailType == TransactionDetailType.Discount ? transactionDetail.SalesDiscountReasonId : -1;
            
            if (transactionDetail.TransactionAnalysisType == TransactionAnalysisType.All)
                transactionDetail.TransactionAnalysisType = TransactionAnalysisType.SalesAnalysisAndTaxAuditReport;

            if (isReducedCommissionEntry) {
                var trip = transactionDetail.ReceiptDetail.Receipt.Trip;

                transactionDetail.DocumentStatus = transactionDetail.ReceiptDetail.DocumentStatus;
                transactionDetail.ReversalStatus = transactionDetail.ReceiptDetail.ReversalStatus;
                transactionDetail.ReceiptDetailId = transactionDetail.ReceiptDetailId;
                transactionDetail.AgencyId = trip.AgencyId;
                transactionDetail.SalesAnalysisDebtorId = trip.DebtorId;
                transactionDetail.SalesAnalysisGroupId = trip.GroupId;
                transactionDetail.SalesAnalysisClassId = trip.ClassId;
                transactionDetail.SalesAnalysisSourceId = trip.SourceId;
                transactionDetail.SalesAnalysisCategoryId = trip.CategoryId;
                transactionDetail.SalesAnalysisDestinationId = trip.DestinationId;
                transactionDetail.SalesAnalysisRegionId = trip.Destination.RegionId;
                transactionDetail.SalesAnalysisLocationId = trip.LocationId;
                transactionDetail.SalesAnalysisConsultantId = trip.ConsultantId;
                transactionDetail.SalesAnalysisAgentId = trip.AgentId;

                transactionDetail.SalesAnalysisSaleTypeId = transactionDetail.ReceiptDetail.FormOfPayment.CreditCardSaleTypeId;
            }
            else {
                transactionDetail.AgencyId = transactionDetail.AgencyId;
                transactionDetail.SalesAnalysisDebtorId = transactionDetail.SalesDebtorId;
                transactionDetail.SalesAnalysisGroupId = transactionDetail.SalesGroupId;
                transactionDetail.SalesAnalysisClassId = transactionDetail.SalesClassId;
                transactionDetail.SalesAnalysisSourceId = transactionDetail.SalesSourceId;
                transactionDetail.SalesAnalysisCategoryId = transactionDetail.SalesCategoryId;
                transactionDetail.SalesAnalysisDestinationId = transactionDetail.SalesDestinationId;
                transactionDetail.SalesAnalysisRegionId = transactionDetail.SalesRegionId;
                transactionDetail.SalesAnalysisLocationId = transactionDetail.SalesLocationId;
                transactionDetail.SalesAnalysisConsultantId = transactionDetail.SalesConsultantId;
                transactionDetail.SalesAnalysisAgentId = transactionDetail.SalesAgentId;
            }

            if (salesAnalysisList.Count > 0) {
                foreach (var salesAnalysis in salesAnalysisList.Where(t => t.TransactionId == transactionDetail.TransactionId && t.ReceiptDetailId == transactionDetail.ReceiptDetailId && t.NonBspDetailId == transactionDetail.NonBspDetailId && t.PaymentDetailId == transactionDetail.PaymentDetailId && t.InvoiceDetailId == transactionDetail.InvoiceDetailId && t.JournalDetailId == transactionDetail.JournalDetailId && t.AdjustmentId == transactionDetail.Transaction.AdjustmentId
                        && t.LedgerType == transactionDetail.LedgerType && t.SignType == transactionDetail.SignType && t.TransactionDetailType == transactionDetail.TransactionDetailType && t.TripId == transactionDetail.TripId && t.DebtorId == transactionDetail.DebtorId && t.CreditorId == transactionDetail.CreditorId && t.ChartOfAccountId == transactionDetail.ChartOfAccountId)) {

                    if (salesAnalysis.SalesAnalysisDebtorId != 0)
                        transactionDetail.SalesAnalysisDebtorId = salesAnalysis.SalesAnalysisDebtorId;

                    if (salesAnalysis.SalesAnalysisGroupId != 0)
                        transactionDetail.SalesAnalysisGroupId = salesAnalysis.SalesAnalysisGroupId;

                    if (salesAnalysis.SalesAnalysisClassId != 0)
                        transactionDetail.SalesAnalysisClassId = salesAnalysis.SalesAnalysisClassId;

                    if (salesAnalysis.SalesAnalysisDestinationId != 0)
                        transactionDetail.SalesAnalysisDestinationId = salesAnalysis.SalesAnalysisDestinationId;

                    if (salesAnalysis.SalesAnalysisRegionId != 0)
                        transactionDetail.SalesAnalysisRegionId = salesAnalysis.SalesAnalysisRegionId;

                    if (salesAnalysis.SalesAnalysisLocationId != 0)
                        transactionDetail.SalesAnalysisLocationId = salesAnalysis.SalesAnalysisLocationId;

                    if (salesAnalysis.SalesAnalysisAgentId != 0)
                        transactionDetail.SalesAnalysisAgentId = salesAnalysis.SalesAnalysisAgentId;
                }
            }

            return lazyContext.Save(transactionDetail, false);
        }

        public static bool UpdateDocumentStatus<T>(this T entity, AppLazyContext lazyContext, DocumentStatus documentStatus, int bankAccountStatementId = 0, int depositDetailId = 0) where T : class {
            if (entity == null)
                return false;

            using (var ts = Utils.CreateTransactionScope()) {
                bool isUpdated = false;

                if (entity.GetType() == typeof(Receipt) || entity.GetType().BaseType == typeof(Receipt)) {
                    var receipt = entity as Receipt;

                    foreach (var receiptDetail in receipt.ReceiptDetails.Where(t => t.DocumentStatus != documentStatus)) {
                        receiptDetail.DocumentStatus = documentStatus;
                        isUpdated = lazyContext.Save(receiptDetail, false);

                        foreach (var row in receiptDetail.TransactionDetails.Where(t => t.DocumentStatus != documentStatus)) {
                            row.DocumentStatus = documentStatus;
                            lazyContext.Save(row, false);
                        }
                    }

                    if (receipt.ReverseTransferReceiptId > 0) {
                        receipt = lazyContext.Receipt.Find(receipt.ReverseTransferReceiptId);

                        foreach (var receiptDetail in receipt.ReceiptDetails.Where(t => t.DocumentStatus != documentStatus)) {
                            receiptDetail.DocumentStatus = documentStatus;
                            isUpdated = lazyContext.Save(receiptDetail, false);

                            foreach (var row in receiptDetail.TransactionDetails.Where(t => t.DocumentStatus != documentStatus)) {
                                row.DocumentStatus = documentStatus;
                                lazyContext.Save(row, false);
                            }
                        }
                    }
                }
                else if (entity.GetType() == typeof(ReceiptDetail) || entity.GetType().BaseType == typeof(ReceiptDetail)) {
                    var receiptDetail = entity as ReceiptDetail;
                    receiptDetail.DocumentStatus = documentStatus;

                    if (depositDetailId != 0)
                        receiptDetail.DepositDetailId = depositDetailId;

                    if (bankAccountStatementId != 0)
                        receiptDetail.BankAccountStatementId = bankAccountStatementId;

                    isUpdated = lazyContext.Save(receiptDetail, false);

                    foreach (var row in receiptDetail.TransactionDetails.Where(t => t.DocumentStatus != documentStatus)) {
                        row.DocumentStatus = documentStatus;
                        lazyContext.Save(row, false);
                    }
                }
                else if (entity.GetType() == typeof(Bsp) || entity.GetType().BaseType == typeof(Bsp)) {
                    var bsp = entity as Bsp;

                    foreach (var bspDetail in bsp.BspDetails.Where(t => t.DocumentStatus != documentStatus)) {
                        bspDetail.DocumentStatus = documentStatus;
                        isUpdated = lazyContext.Save(bspDetail, false);

                        foreach (var row in bspDetail.TransactionDetails.Where(t => t.DocumentStatus != documentStatus)) {
                            row.DocumentStatus = documentStatus;
                            lazyContext.Save(row, false);
                        }
                    }
                }
                else if (entity.GetType() == typeof(BspDetail) || entity.GetType().BaseType == typeof(BspDetail)) {
                    var bspDetail = entity as BspDetail;
                    bspDetail.DocumentStatus = documentStatus;
                    isUpdated = lazyContext.Save(bspDetail, false);

                    foreach (var row in bspDetail.TransactionDetails.Where(t => t.DocumentStatus != documentStatus)) {
                        row.DocumentStatus = documentStatus;
                        lazyContext.Save(row, false);
                    }
                }
                else if (entity.GetType() == typeof(NonBsp) || entity.GetType().BaseType == typeof(NonBsp)) {
                    var nonBsp = entity as NonBsp;

                    foreach (var nonBspDetail in nonBsp.NonBspDetails.Where(t => t.DocumentStatus != documentStatus)) {
                        nonBspDetail.DocumentStatus = documentStatus;
                        isUpdated = lazyContext.Save(nonBspDetail, false);

                        foreach (var row in nonBspDetail.TransactionDetails.Where(t => t.DocumentStatus != documentStatus)) {
                            row.DocumentStatus = documentStatus;
                            lazyContext.Save(row, false);
                        }
                    }

                    if (nonBsp.SupplierOtherCommissionReceiptId > 0) {
                        var receipt = lazyContext.Receipt.Find(nonBsp.SupplierOtherCommissionReceiptId);

                        foreach (var receiptDetail in receipt.ReceiptDetails.Where(t => t.DocumentStatus != documentStatus)) {
                            receiptDetail.DocumentStatus = documentStatus;
                            isUpdated = lazyContext.Save(receiptDetail, false);

                            foreach (var row in receiptDetail.TransactionDetails.Where(t => t.DocumentStatus != documentStatus)) {
                                row.DocumentStatus = documentStatus;
                                lazyContext.Save(row, false);
                            }
                        }
                    }
                }
                else if (entity.GetType() == typeof(NonBspDetail) || entity.GetType().BaseType == typeof(NonBspDetail)) {
                    var nonBspDetail = entity as NonBspDetail;
                    nonBspDetail.DocumentStatus = documentStatus;
                    isUpdated = lazyContext.Save(nonBspDetail, false);

                    foreach (var row in nonBspDetail.TransactionDetails.Where(t => t.DocumentStatus != documentStatus)) {
                        row.DocumentStatus = documentStatus;
                        lazyContext.Save(row, false);
                    }
                }
                else if (entity.GetType() == typeof(PaymentDetail) || entity.GetType().BaseType == typeof(PaymentDetail)) {
                    var paymentDetail = entity as PaymentDetail;
                    paymentDetail.DocumentStatus = documentStatus;

                    if (bankAccountStatementId != 0)
                        paymentDetail.BankAccountStatementId = bankAccountStatementId;

                    isUpdated = lazyContext.Save(paymentDetail, false);

                    foreach (var row in paymentDetail.TransactionDetails.Where(t => t.DocumentStatus != documentStatus)) {
                        row.DocumentStatus = documentStatus;
                        lazyContext.Save(row, false);
                    }
                }
                else if (entity.GetType() == typeof(Invoice) || entity.GetType().BaseType == typeof(Invoice)) {
                    var invoice = entity as Invoice;

                    foreach (var invoiceDetail in invoice.InvoiceDetails.Where(t => t.DocumentStatus != documentStatus)) {
                        invoiceDetail.DocumentStatus = documentStatus;
                        isUpdated = lazyContext.Save(invoiceDetail, false);

                        foreach (var row in invoiceDetail.TransactionDetails.Where(t => t.DocumentStatus != documentStatus)) {
                            row.DocumentStatus = documentStatus;
                            lazyContext.Save(row, false);
                        }
                    }
                }
                else if (entity.GetType() == typeof(InvoiceDetail) || entity.GetType().BaseType == typeof(InvoiceDetail)) {
                    var invoiceDetail = entity as InvoiceDetail;
                    invoiceDetail.DocumentStatus = documentStatus;
                    isUpdated = lazyContext.Save(invoiceDetail, false);

                    foreach (var row in invoiceDetail.TransactionDetails.Where(t => t.DocumentStatus != documentStatus)) {
                        row.DocumentStatus = documentStatus;
                        lazyContext.Save(row, false);
                    }
                }
                else if (entity.GetType() == typeof(Journal) || entity.GetType().BaseType == typeof(Journal)) {
                    var journal = entity as Journal;
                    journal.DocumentStatus = documentStatus;
                    isUpdated = lazyContext.Save(journal, false);

                    foreach (var row in journal.JournalDetails.SelectMany(t => t.TransactionDetails).Where(t => t.DocumentStatus != documentStatus)) {
                        row.DocumentStatus = documentStatus;
                        lazyContext.Save(row, false);
                    }
                }
                else if (entity.GetType() == typeof(Adjustment) || entity.GetType().BaseType == typeof(Adjustment)) {
                    var adjustment = entity as Adjustment;
                    adjustment.DocumentStatus = documentStatus;
                    isUpdated = lazyContext.Save(adjustment, false);
                }
                else if (entity.GetType() == typeof(Voucher) || entity.GetType().BaseType == typeof(Voucher)) {
                    var voucher = entity as Voucher;
                    voucher.DocumentStatus = documentStatus;
                    isUpdated = lazyContext.Save(voucher, false);
                }
                else {
                    throw new InvalidOperationException("Invalid entity.");
                }

                ts.Complete();
                return isUpdated;
            }
        }

        public static bool UpdateReversalStatus<T>(this T entity, AppLazyContext lazyContext, ReversalStatus reversalStatus, int bankAccountStatementId = 0) where T : class {
            if (entity == null)
                return false;

            using (var ts = Utils.CreateTransactionScope()) {
                bool isUpdated = false;

                if (entity.GetType() == typeof(Receipt) || entity.GetType().BaseType == typeof(Receipt)) {
                    var receipt = entity as Receipt;

                    foreach (var receiptDetail in receipt.ReceiptDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                        receiptDetail.ReversalStatus = reversalStatus;
                        isUpdated = lazyContext.Save(receiptDetail, false);

                        foreach (var row in receiptDetail.TransactionDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                            row.ReversalStatus = reversalStatus;
                            lazyContext.Save(row, false);
                        }
                    }
                }
                else if (entity.GetType() == typeof(ReceiptDetail) || entity.GetType().BaseType == typeof(ReceiptDetail)) {
                    var receiptDetail = entity as ReceiptDetail;

                    if (bankAccountStatementId != 0)
                        receiptDetail.BankAccountStatementId = bankAccountStatementId;

                    receiptDetail.ReversalStatus = reversalStatus;
                    isUpdated = lazyContext.Save(receiptDetail, false);

                    foreach (var row in receiptDetail.TransactionDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                        row.ReversalStatus = reversalStatus;
                        lazyContext.Save(row, false);
                    }
                }
                else if (entity.GetType() == typeof(Bsp) || entity.GetType().BaseType == typeof(Bsp)) {
                    var bsp = entity as Bsp;

                    foreach (var bspDetail in bsp.BspDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                        bspDetail.ReversalStatus = reversalStatus;
                        isUpdated = lazyContext.Save(bspDetail, false);

                        foreach (var row in bspDetail.TransactionDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                            row.ReversalStatus = reversalStatus;
                            lazyContext.Save(row, false);
                        }
                    }
                }
                else if (entity.GetType() == typeof(BspDetail) || entity.GetType().BaseType == typeof(BspDetail)) {
                    var bspDetail = entity as BspDetail;
                    bspDetail.ReversalStatus = reversalStatus;
                    isUpdated = lazyContext.Save(bspDetail, false);

                    foreach (var row in bspDetail.TransactionDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                        row.ReversalStatus = reversalStatus;
                        lazyContext.Save(row, false);
                    }
                }
                else if (entity.GetType() == typeof(NonBsp) || entity.GetType().BaseType == typeof(NonBsp)) {
                    var nonBsp = entity as NonBsp;

                    foreach (var nonBspDetail in nonBsp.NonBspDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                        nonBspDetail.ReversalStatus = reversalStatus;
                        isUpdated = lazyContext.Save(nonBspDetail, false);

                        foreach (var row in nonBspDetail.TransactionDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                            row.ReversalStatus = reversalStatus;
                            lazyContext.Save(row, false);
                        }
                    }
                }
                else if (entity.GetType() == typeof(NonBspDetail) || entity.GetType().BaseType == typeof(NonBspDetail)) {
                    var nonBspDetail = entity as NonBspDetail;
                    nonBspDetail.ReversalStatus = reversalStatus;
                    isUpdated = lazyContext.Save(nonBspDetail, false);

                    foreach (var row in nonBspDetail.TransactionDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                        row.ReversalStatus = reversalStatus;
                        lazyContext.Save(row, false);
                    }
                }
                else if (entity.GetType() == typeof(Payment) || entity.GetType().BaseType == typeof(Payment)) {
                    var payment = entity as Payment;

                    foreach (var paymentDetail in payment.PaymentDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                        paymentDetail.ReversalStatus = reversalStatus;
                        isUpdated = lazyContext.Save(paymentDetail, false);

                        foreach (var row in paymentDetail.TransactionDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                            row.ReversalStatus = reversalStatus;
                            lazyContext.Save(row, false);
                        }
                    }
                }
                else if (entity.GetType() == typeof(PaymentDetail) || entity.GetType().BaseType == typeof(PaymentDetail)) {
                    var paymentDetail = entity as PaymentDetail;

                    if (bankAccountStatementId != 0)
                        paymentDetail.BankAccountStatementId = bankAccountStatementId;

                    paymentDetail.ReversalStatus = reversalStatus;
                    isUpdated = lazyContext.Save(paymentDetail, false);

                    foreach (var row in paymentDetail.TransactionDetails.Where(t => t.ReversalStatus != reversalStatus)) {
                        row.ReversalStatus = reversalStatus;
                        lazyContext.Save(row, false);
                    }
                }
                else if (entity.GetType() == typeof(Journal) || entity.GetType().BaseType == typeof(Journal)) {
                    var journal = entity as Journal;
                    journal.ReversalStatus = reversalStatus;
                    isUpdated = lazyContext.Save(journal, false);

                    foreach (var row in journal.JournalDetails.SelectMany(t => t.TransactionDetails).Where(t => t.ReversalStatus != reversalStatus)) {
                        row.ReversalStatus = reversalStatus;
                        lazyContext.Save(row, false);
                    }
                }
                else if (entity.GetType() == typeof(Adjustment) || entity.GetType().BaseType == typeof(Adjustment)) {
                    var adjustment = entity as Adjustment;
                    adjustment.ReversalStatus = reversalStatus;
                    isUpdated = lazyContext.Save(adjustment, false);
                }
                else if (entity.GetType() == typeof(Voucher) || entity.GetType().BaseType == typeof(Voucher)) {
                    var voucher = entity as Voucher;
                    voucher.ReversalStatus = reversalStatus;
                    isUpdated = lazyContext.Save(voucher, false);
                }
                else {
                    throw new InvalidOperationException("Invalid entity.");
                }

                ts.Complete();
                return isUpdated;
            }
        }

        private static void HandleException(string subject, string message, bool isUnreportedException, bool isBatchMode) {
            if (isBatchMode) {
                ExceptionManagerBiz.Instance.HandleException(ClassName, "HandleException", new Exception(string.Format("{0}{1}{2}", subject, Environment.NewLine, message)), 0);
            }
            else if (isUnreportedException) {
                throw new UnreportedException(message);
            }
            else {
                throw new ReportedException(message);
            }
        }
    }
}