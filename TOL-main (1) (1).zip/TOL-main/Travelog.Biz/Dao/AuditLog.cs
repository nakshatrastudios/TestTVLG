﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace Travelog.Biz.Dao {
    public static class AuditLog {
        public static List<AuditLogModel> GetAuditLog(IPrincipal principal, ChangeTracker changeTracker) {
            var auditLog = new List<AuditLogModel>();

            try {
                var entries = changeTracker.Entries().Where(t => t.State == EntityState.Added || t.State == EntityState.Deleted || t.State == EntityState.Modified).ToList();

                if (entries.Count == 0)
                    return auditLog;

                const string newLine = @"(\r\n|\n)";
                DateTime creationTime = DateTime.UtcNow;

                foreach (var entry in entries) {
                    var type = entry.Entity.GetType();

                    if (type.BaseType.Name != "Object")
                        type = type.BaseType;

                    string entityName = type.Name;
                    string propName = string.Empty;
                    string originalValue = string.Empty;
                    string currentValue = string.Empty;
                    string originalValues = string.Empty;
                    string currentValues = string.Empty;

                    foreach (var prop in (entry.State == EntityState.Added ? entry.CurrentValues : entry.OriginalValues).Properties.OrderBy(t => t.Name == "Id" ? 0 : t.Name == "Code" || t.Name == "Name" ? 1 : t.Name == "DocumentNo" || t.Name == "TripNo" ? 2 : 3)) {
                        propName = prop.Name;

                        if (entityName == "AspNetUsers") {
                            switch (propName) {
                                case "Id":
                                case "UserName":
                                case "FullName":
                                case "Email":
                                case "CurrentCustomerId":
                                case "CurrentConsultantId":
                                case "CurrentDefaultAgencyId":
                                case "OtherAgencies":
                                case "OtherConsultants":
                                case "IsSupportUser":
                                case "IsSuperUser":
                                case "Inactive":
                                    break;
                                default:
                                    continue;
                            }
                        }
                        else if (propName == "LastWriteTime" || propName == "CreationTime" || propName == "LastWriteUser" || propName == "CreationUser" || propName == "SecurityStamp" || propName == "ConcurrencyStamp" || propName.Contains("Password", StringComparison.OrdinalIgnoreCase) || propName.EndsWith("Shadow", StringComparison.OrdinalIgnoreCase)) {
                            continue;
                        }

                        switch (entry.State) {
                            case EntityState.Added:
                                currentValue = entry.CurrentValues[prop] == null || (entry.CurrentValues[prop].GetType() == typeof(DateTime) && (DateTime)entry.CurrentValues[prop] == DateTime.MinValue) ? null : Regex.Replace(entry.CurrentValues[prop].ToStringExt(), newLine, " ");

                                if (propName == "Id")
                                    continue;

                                if (string.IsNullOrEmpty(currentValue) || originalValue == "Not Specified" || originalValue == "NotSpecified")
                                    currentValue = "{empty}";

                                if (currentValue != "{empty}")
                                    AssignForeignKeyValue(entry, entry.State, ref propName, ref originalValue, ref currentValue);

                                break;
                            case EntityState.Modified:
                                originalValue = entry.OriginalValues[prop] == null || (entry.OriginalValues[prop].GetType() == typeof(DateTime) && (DateTime)entry.OriginalValues[prop] == DateTime.MinValue) ? null : Regex.Replace(entry.OriginalValues[prop].ToStringExt(), newLine, " ");
                                currentValue = entry.CurrentValues[prop] == null || (entry.CurrentValues[prop].GetType() == typeof(DateTime) && (DateTime)entry.CurrentValues[prop] == DateTime.MinValue) ? null : Regex.Replace(entry.CurrentValues[prop].ToStringExt(), newLine, " ");

                                if (propName != "Id" && propName != "ReceiptId" && propName != "BspId" && propName != "NonBspId" && propName != "PaymentId" && propName != "InvoiceId" && propName != "JournalId" && propName != "Code" && propName != "Name" && propName != "DocumentNo" && propName != "TripNo") {
                                    if (originalValue == currentValue && !prop.IsPrimaryKey())
                                        continue;

                                    if (DataValidation.IsNumber(originalValue) && DataValidation.IsNumber(currentValue) && decimal.Parse(originalValue) == decimal.Parse(currentValue))
                                        continue;
                                }

                                if (string.IsNullOrEmpty(originalValue) || originalValue == "Not Specified" || originalValue == "NotSpecified")
                                    originalValue = "{empty}";

                                if (string.IsNullOrEmpty(currentValue) || currentValue == "Not Specified" || currentValue == "NotSpecified")
                                    currentValue = "{empty}";

                                if (originalValue != "{empty}" || currentValue != "{empty}")
                                    AssignForeignKeyValue(entry, entry.State, ref propName, ref originalValue, ref currentValue);

                                break;
                            case EntityState.Deleted:
                                originalValue = entry.OriginalValues[prop] == null || (entry.OriginalValues[prop].GetType() == typeof(DateTime) && (DateTime)entry.OriginalValues[prop] == DateTime.MinValue) ? null : Regex.Replace(entry.OriginalValues[prop].ToStringExt(), newLine, " ");

                                if (string.IsNullOrEmpty(originalValue) || originalValue == "Not Specified" || originalValue == "NotSpecified")
                                    originalValue = "{empty}";

                                if (originalValue != "{empty}")
                                    AssignForeignKeyValue(entry, entry.State, ref propName, ref originalValue, ref currentValue);

                                break;
                        }

                        if (entry.State == EntityState.Modified || entry.State == EntityState.Deleted)
                            originalValues += string.Format("{0}: {1}{2}", propName, Regex.Replace(originalValue, newLine, " "), AppConstants.HtmlLineBreak);

                        if (entry.State == EntityState.Modified || entry.State == EntityState.Added)
                            currentValues += string.Format("{0}: {1}{2}", propName, Regex.Replace(currentValue, newLine, " "), AppConstants.HtmlLineBreak);
                    }

                    originalValues = originalValues.TrimEnd(AppConstants.HtmlLineBreak.ToCharArray());
                    currentValues = currentValues.TrimEnd(AppConstants.HtmlLineBreak.ToCharArray());

                    if (string.IsNullOrEmpty(entityName) || (string.IsNullOrEmpty(originalValues) && string.IsNullOrEmpty(currentValues)))
                        continue;

                    if (originalValues == currentValues) {
                        string[] original = originalValues.Split(':');
                        string[] current = currentValues.Split(':');

                        if (original.Length == 2 && original[0] == "Id" && current.Length == 2 && current[0] == "Id")
                            continue;
                    }

                    auditLog.Add(new AuditLogModel {
                        EntityState = entry.State,
                        EntityName = entityName,
                        OriginalValues = originalValues,
                        CurrentValues = currentValues,
                        CreationUser = principal.Identity.Name
                    });
                }

                return auditLog;
            }
            catch {
                return auditLog;
            }
        }

        private static void AssignForeignKeyValue(EntityEntry entry, EntityState entityState, ref string propName, ref string originalValue, ref string currentValue) {
            if (!propName.EndsWith("Id") || propName == "Id")
                return;

            try {
                if (propName != "ReceiptId" && propName != "BspId" && propName != "NonBspId" && propName != "PaymentId" && propName != "InvoiceId" && propName != "JournalId") {
                    if (entityState == EntityState.Modified && DataValidation.IsNumber(originalValue) && DataValidation.IsNumber(currentValue) && int.Parse(originalValue) <= 0 && int.Parse(currentValue) <= 0) {
                        propName = propName.TrimEnd("Id");
                        originalValue = "{empty}";
                        currentValue = "{empty}";
                        return;
                    }
                    else if (entityState == EntityState.Deleted && DataValidation.IsNumber(originalValue) && int.Parse(originalValue) <= 0) {
                        propName = propName.TrimEnd("Id");
                        originalValue = "{empty}";
                        return;
                    }
                    else if (entityState == EntityState.Added && DataValidation.IsNumber(currentValue) && int.Parse(currentValue) <= 0) {
                        propName = propName.TrimEnd("Id");
                        currentValue = "{empty}";
                        return;
                    }
                }

                string propertyName = propName;
                string sql = null;

                var clrType = entry.OriginalValues.Properties.SingleOrDefault(t => t.Name == propertyName).GetContainingForeignKeys().SingleOrDefault(t => t.DependentToPrincipal.Name == propertyName.TrimEnd("Id"))?.DependentToPrincipal.ClrType;

                if (clrType == null)
                    return;

                string nameSpace = clrType.Namespace.TrimStart("Travelog.Biz.Dao.");
                string columnName;

                switch (clrType.Name) {
                    default:
                        columnName = "[Name]";
                        break;
                    case "Receipt":
                    case "Bsp":
                    case "NonBsp":
                    case "Payment":
                    case "Invoice":
                    case "Journal":
                        columnName = "DocumentNo";
                        break;
                    case "StandardComment":
                        columnName = "Code";
                        break;
                    case "Trip":
                        columnName = "TripNo";
                        break;
                    case "TripLine":
                        columnName = "Description";
                        break;
                    case "Passenger":
                        columnName = "trim(Title + ' ' + FirstName + ' ' + LastName)";
                        break;
                    case "TripLineAirPassenger":
                        columnName = "(select trim(Title + ' ' + FirstName + ' ' + LastName) from ClientLedger.Passenger where (Id=ClientLedger.TripLineAirPassenger.PassengerId))";
                        break;
                }

                propName = propName.TrimEnd("Id");

                if (entityState == EntityState.Modified) {
                    int originalId = int.Parse(originalValue);
                    int currentId = int.Parse(currentValue);

                    sql = string.Format("select {0} as Value from [{1}].[{2}] where Id in ({3},{4}) order by Id{5}", columnName, nameSpace, clrType.Name, originalId, currentId, originalId < currentId ? string.Empty : " desc");
                    var q = entry.Context.Set<ReturnString>().FromSqlRaw(sql).ToList();

                    originalValue = q.First().Value;
                    currentValue = q.Last().Value;
                }
                else if (entityState == EntityState.Deleted) {
                    sql = string.Format("select {0} as Value from [{1}].[{2}] where Id={3}", columnName, nameSpace, clrType.Name, originalValue);
                    originalValue = entry.Context.Set<ReturnString>().FromSqlRaw(sql).AsEnumerable().First().Value;
                }
                else if (entityState == EntityState.Added) {
                    sql = string.Format("select {0} as Value from [{1}].[{2}] where Id={3}", columnName, nameSpace, clrType.Name, currentValue);
                    currentValue = entry.Context.Set<ReturnString>().FromSqlRaw(sql).AsEnumerable().First().Value;
                }
            }
            catch {
            }
        }

        public static void WriteAuditLog(IPrincipal principal, List<AuditLogModel> auditLog, bool isSuperUser) {
            using (var adminContext = new AppAdminContext(principal)) {
                foreach (var row in auditLog) {
                    WriteAuditLog(adminContext, row.EntityState, row.EntityName, row.OriginalValues, row.CurrentValues, row.CreationUser, isSuperUser);
                }
            }
        }

        private static void WriteAuditLog(AppAdminContext adminContext, EntityState entityState, string entityName, string originalValues, string currentValues, string creationUser, bool isSuperUser) {
            try {
                int customerId = adminContext.AspNetUsers.SingleOrDefault(t => t.Email == creationUser)?.CurrentCustomerId ?? 0;

                if (customerId == 0)
                    return;

                while (originalValues.Contains(string.Format("{0}{0}", AppConstants.HtmlLineBreak))) {
                    originalValues = originalValues.Replace(string.Format("{0}{0}", AppConstants.HtmlLineBreak), AppConstants.HtmlLineBreak);
                }

                while (currentValues.Contains(string.Format("{0}{0}", AppConstants.HtmlLineBreak))) {
                    currentValues = currentValues.Replace(string.Format("{0}{0}", AppConstants.HtmlLineBreak), AppConstants.HtmlLineBreak);
                }

                originalValues = originalValues.Replace("Not Specified", "{empty}").Replace("NotSpecified", "{empty}");
                currentValues = currentValues.Replace("Not Specified", "{empty}").Replace("NotSpecified", "{empty}");

                originalValues = originalValues.Replace(string.Format(": {0}", AppConstants.HtmlLineBreak), string.Format(": {{empty}}{0}", AppConstants.HtmlLineBreak));
                currentValues = currentValues.Replace(string.Format(": {0}", AppConstants.HtmlLineBreak), string.Format(": {{empty}}{0}", AppConstants.HtmlLineBreak));

                var q = new Admin.AuditLog {
                    Id = 0,
                    CustomerId = customerId,
                    Entity = entityName,
                    Type = entityState.ToString(),
                    SuperUser = isSuperUser,
                    OriginalValues = originalValues.TrimEnd(AppConstants.HtmlLineBreak),
                    CurrentValues = currentValues.TrimEnd(AppConstants.HtmlLineBreak),
                    CreationTime = DateTime.UtcNow,
                    CreationUser = creationUser
                };

                adminContext.Entry(q).State = EntityState.Added;
                adminContext.SaveChanges();
            }
            catch (Exception ex) {
                ExceptionManagerBiz.Instance.SendMailAsync("Travelog.Biz.Dao.AuditLog", "WriteAuditLog", ex).Wait();
            }
        }

        public static async Task ArchiveAuditLog(bool throwExceptionIfUnavailable = false) {
            try {
                using (var adminContext = new AppAdminContext(false)) {
                    int rowCount = adminContext.AuditLog.Count() - (50000 * adminContext.Customer.Count(t => t.Id > 0));

                    if (rowCount <= 0)
                        return;

                    using (var archiveContext = new AppAdminContext(false)) {
                        using (var ts = Utils.CreateTransactionScope()) {
                            foreach (var row in adminContext.AuditLog.Take(rowCount)) {
                                var auditLog = new Admin.AuditLog {
                                    CustomerId = row.CustomerId,
                                    Entity = row.Entity,
                                    Type = row.Type,
                                    SuperUser = row.SuperUser,
                                    OriginalValues = row.OriginalValues,
                                    CurrentValues = row.CurrentValues,
                                    CreationTime = row.CreationTime,
                                    CreationUser = row.CreationUser
                                };

                                archiveContext.Attach(auditLog);
                            }

                            await archiveContext.SaveChangesAsync();

                            string sql = string.Format("with cte as (select top {0} * from travelogadmin.dbo.AuditLog) delete from cte", rowCount);
                            await adminContext.Database.ExecuteSqlRawAsync(sql);

                            ts.Complete();
                        }
                    }
                }
            }
            catch (Exception ex) {
                foreach (var row in AppConstants.SqlArchiveDatabaseNotAvailable) {
                    if (ex.Message.Contains(row, StringComparison.OrdinalIgnoreCase)) {
                        if (throwExceptionIfUnavailable)
                            throw;

                        return;
                    }
                }

                throw;
            }
        }
    }

    public class AuditLogModel {
        public EntityState EntityState { get; set; }
        public string EntityName { get; set; }
        public string OriginalValues { get; set; }
        public string CurrentValues { get; set; }
        public string CreationUser { get; set; }
    }
}