﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Security.Principal;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.Configuration;
using static Travelog.Biz.Dao.AuditLog;

namespace Travelog.Biz.Dao {
	public class AppAdminContext : AdminContext {
		private IPrincipal Principal { get; }
		private string ConnectionString { get; }

		public AppAdminContext(bool isReadOnly) {
			if (isReadOnly) {
				Principal = Utils.GetGenericIdentity(UserRole.ReadOnly.Name);
			}
			else {
				Principal = Utils.GetGenericIdentity(UserRole.SystemAdministrator.Name);
			}

			ConnectionString = AppSettings.Configuration.GetConnectionString("travelogonline-admin");
		}

		public AppAdminContext(IPrincipal principal) {
			Principal = principal;
			ConnectionString = AppSettings.Configuration.GetConnectionString("travelogonline-admin");
		}

		public AppAdminContext(IPrincipal principal, string connectionString) {
			Principal = principal;
			ConnectionString = connectionString;
		}

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {
			optionsBuilder.UseSqlServer(ConnectionString, sqlServerOptions => sqlServerOptions.CommandTimeout(300));
			base.OnConfiguring(optionsBuilder);
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder) {
			modelBuilder.Entity<ReturnString>().HasNoKey();
			base.OnModelCreating(modelBuilder);
		}

		public bool Insert(object entity, bool logChanges = true) {
			if (entity == null || !Validate())
				return false;

			Entry(entity).State = EntityState.Added;

			foreach (var pi in entity.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)) {
				if (pi.Name == "CreationTime" || pi.Name == "LastWriteTime") {
					pi.SetValue(entity, DateTime.UtcNow);
				}
				else if (pi.Name == "CreationUser" || pi.Name == "LastWriteUser") {
					pi.SetValue(entity, DataValidation.IsEmail(Principal.Identity.Name) ? Principal.Identity.Name : AppSettings.SystemAccountEmail);
				}
			}

			List<AuditLogModel> auditLog = null;

			if (logChanges)
				auditLog = GetAuditLog(Principal, ChangeTracker);

			bool result = SaveChanges() > 0;

			if (result && logChanges)
				WriteAuditLog(Principal, auditLog, false);

			return result;
		}

		public bool Save(object entity, bool logChanges = true) {
			if (entity == null || !IsModified(entity) || !Validate())
				return false;

			if (Entry(entity).State == EntityState.Detached)
				Entry(entity).State = EntityState.Modified;

			var entityState = Entry(entity).State;

			foreach (var pi in entity.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)) {
				if (pi.Name == "CreationTime" && (entityState == EntityState.Added || pi.GetValue(entity) == null)) {
					pi.SetValue(entity, DateTime.UtcNow);
				}
				else if (pi.Name == "CreationUser" && (entityState == EntityState.Added || pi.GetValue(entity) == null)) {
					pi.SetValue(entity, DataValidation.IsEmail(Principal.Identity.Name) ? Principal.Identity.Name : AppSettings.SystemAccountEmail);
				}

				if (pi.Name == "LastWriteTime") {
					pi.SetValue(entity, DateTime.UtcNow);
				}
				else if (pi.Name == "LastWriteUser") {
					pi.SetValue(entity, DataValidation.IsEmail(Principal.Identity.Name) ? Principal.Identity.Name : AppSettings.SystemAccountEmail);
				}
			}

			List<AuditLogModel> auditLog = null;

			if (logChanges)
				auditLog = GetAuditLog(Principal, ChangeTracker);

			bool result = SaveChanges() > 0;

			if (result && logChanges)
				WriteAuditLog(Principal, auditLog, false);

			return result;
		}

		public bool Delete(object entity, bool logChanges = true) {
			if (entity == null || !Validate())
				return false;

			Entry(entity).State = EntityState.Deleted;

			List<AuditLogModel> auditLog = null;

			if (logChanges)
				auditLog = GetAuditLog(Principal, ChangeTracker);

			bool result = SaveChanges() > 0;

			if (result && logChanges)
				WriteAuditLog(Principal, auditLog, false);

			return result;
		}

		public bool Validate() {
			if (Principal.IsInRole(UserRole.ReadOnly.Name))
				throw new UnreportedException(AppConstants.RecordIsReadOnly);

			return true;
		}

		public bool IsModified(object entity) {
			ChangeTracker.DetectChanges();
			return base.Entry(entity).State != EntityState.Unchanged;
		}
	}

	public class AppMainContext : MainContext {
		internal IPrincipal Principal { get; set; }
		internal string ConnectionString { get; set; }
		internal bool UseLazyLoading { get; set; }
		internal bool IsExternalUser { get; set; }
		private bool IsSuperUser { get; }

		public AppMainContext(IPrincipal principal, int customerId, bool isExternalUser, bool isSuperUser) {
			Principal = principal;
			IsExternalUser = isExternalUser;
			IsSuperUser = isSuperUser;
			ConnectionString = AppSettings.GetConnectionString(customerId);
		}

		public AppMainContext(int customerId, bool isReadOnly) {
			if (isReadOnly) {
				Principal = Utils.GetGenericIdentity(UserRole.ReadOnly.Name);
			}
			else {
				Principal = Utils.GetGenericIdentity(UserRole.SystemAdministrator.Name);
			}

			ConnectionString = AppSettings.GetConnectionString(customerId);
		}

		public AppMainContext(string connectionString, bool isReadOnly) {
			if (isReadOnly) {
				Principal = Utils.GetGenericIdentity(UserRole.ReadOnly.Name);
			}
			else {
				Principal = Utils.GetGenericIdentity(UserRole.SystemAdministrator.Name);
			}

			ConnectionString = connectionString;
		}

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {
			optionsBuilder.UseSqlServer(ConnectionString, sqlServerOptions => sqlServerOptions.CommandTimeout(300));
			optionsBuilder.UseLazyLoadingProxies(UseLazyLoading);
			base.OnConfiguring(optionsBuilder);
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder) {
			modelBuilder.Entity<ReturnString>().HasNoKey();
			base.OnModelCreating(modelBuilder);
		}

		public bool Insert(object entity, bool logChanges = true, bool ignoreErrors = false) {
			if (entity == null || !Validate())
				return false;

			Entry(entity).State = EntityState.Added;

			foreach (var pi in entity.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)) {
				if (pi.Name == "CreationTime" || pi.Name == "LastWriteTime") {
					pi.SetValue(entity, DateTime.UtcNow);
				}
				else if (pi.Name == "CreationUser" || pi.Name == "LastWriteUser") {
					pi.SetValue(entity, DataValidation.IsEmail(Principal.Identity.Name) ? Principal.Identity.Name : AppSettings.SystemAccountEmail);
				}
			}

			List<AuditLogModel> auditLog = null;

			if (logChanges)
				auditLog = GetAuditLog(Principal, ChangeTracker);

			bool result = false;

			try {
				result = SaveChanges() > 0;
			}
			catch when (ignoreErrors) {
			}

			if (result && logChanges)
				WriteAuditLog(Principal, auditLog, IsSuperUser);

			return result;
		}

		public bool Save(object entity, bool logChanges = true, bool ignoreErrors = false) {
			if (entity == null || !Validate() || !IsModified(entity))
				return false;

			if (Entry(entity).State == EntityState.Detached)
				Entry(entity).State = EntityState.Modified;

			var entityState = Entry(entity).State;

			foreach (var pi in entity.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance)) {
				if (pi.Name == "CreationTime" && (entityState == EntityState.Added || pi.GetValue(entity) == null)) {
					pi.SetValue(entity, DateTime.UtcNow);
				}
				else if (pi.Name == "CreationUser" && (entityState == EntityState.Added || pi.GetValue(entity) == null)) {
					pi.SetValue(entity, DataValidation.IsEmail(Principal.Identity.Name) ? Principal.Identity.Name : AppSettings.SystemAccountEmail);
				}

				if (pi.Name == "LastWriteTime") {
					pi.SetValue(entity, DateTime.UtcNow);
				}
				else if (pi.Name == "LastWriteUser") {
					pi.SetValue(entity, DataValidation.IsEmail(Principal.Identity.Name) ? Principal.Identity.Name : AppSettings.SystemAccountEmail);
				}
			}

			List<AuditLogModel> auditLog = null;

			if (logChanges)
				auditLog = GetAuditLog(Principal, ChangeTracker);

			bool result = false;

			try {
				result = SaveChanges() > 0;
			}
			catch when (ignoreErrors) {
			}

			if (result && logChanges)
				WriteAuditLog(Principal, auditLog, IsSuperUser);

			return result;
		}

		public bool Delete(object entity, bool logChanges = true, bool ignoreErrors = false) {
			if (entity == null || !Validate())
				return false;

			Entry(entity).State = EntityState.Deleted;
			List<AuditLogModel> auditLog = null;

			if (logChanges)
				auditLog = GetAuditLog(Principal, ChangeTracker);

			bool result = false;

			try {
				result = SaveChanges() > 0;
			}
			catch when (ignoreErrors) {
			}

			if (result && logChanges)
				WriteAuditLog(Principal, auditLog, IsSuperUser);

			return result;
		}

		public bool Validate() {
			if (IsExternalUser)
				throw new UnreportedException(AppConstants.UnauthorisedAccessRemoteAssistanceUser);

			return !Principal.IsInRole(UserRole.ReadOnly.Name);
		}

		public bool IsModified(object entity) {
			ChangeTracker.DetectChanges();
			return base.Entry(entity).State != EntityState.Unchanged;
		}

		public DateTime VoidDate {
			get {
				return AppConstants.VoidDate;
			}
		}
	}

	public class AppLazyContext : AppMainContext {
		public AppLazyContext(IPrincipal principal, int customerId, bool isExternalUser, bool isSuperUser) : base(principal, customerId, isExternalUser, isSuperUser) {
			UseLazyLoading = true;
		}

		public AppLazyContext(int customerId, bool isReadOnly) : base(customerId, isReadOnly) {
			UseLazyLoading = true;
		}

		public AppLazyContext(string connectionString, bool isReadOnly) : base(connectionString, isReadOnly) {
			UseLazyLoading = true;
		}
	}

	public class ReturnString {
		public string Value { get; set; }
	}
}