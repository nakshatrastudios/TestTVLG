using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Security.Principal;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Dao.DebtorLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;

namespace Travelog.Biz.Dao.ClientLedger {
    public static class TripLineHelper {
        public static List<TripLine> GetRows(AppLazyContext lazyContext, int tripId, int quoteNo, int creditorId = 0, int supplierId = 0, int saleTypeId = 0, bool outstandingVouchers = false, bool derivedSort = false) {
            var q = lazyContext.TripLine.Where(t => t.TripId == tripId).AsEnumerable();

            if (quoteNo >= 0)
                q = q.Where(t1 => t1.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo));

            if (creditorId > 0)
                q = q.Where(t1 => (t1.TripLineType == TripLineType.Air && t1.TripLineAir.TripLineAirPassengers.Any(t2 => t2.CreditorId == -1 || t2.CreditorId == creditorId)) || (t1.TripLineType != TripLineType.Air && (t1.Creditor.Id == -1 || t1.Creditor.Id == creditorId)));

            if (supplierId > 0)
                q = q.Where(t1 => (t1.TripLineType == TripLineType.Air && t1.TripLineAir.TripLineAirPassengers.Any(t2 => t2.SupplierId == -1 || t2.SupplierId == supplierId)) || (t1.TripLineType != TripLineType.Air && (t1.Supplier.Id == -1 || t1.Supplier.Id == supplierId)));

            if (saleTypeId > 0)
                q = q.Where(t1 => (t1.TripLineType == TripLineType.Air && t1.TripLineAir.TripLineAirPassengers.Any(t2 => t2.SaleTypeId == -1 || t2.SaleTypeId == saleTypeId)) || (t1.TripLineType != TripLineType.Air && (t1.SaleType.Id == -1 || t1.SaleType.Id == saleTypeId)));

            if (outstandingVouchers)
                q = q.Where(t => (t.TripLineType == TripLineType.Accommodation || t.TripLineType == TripLineType.Transport || t.TripLineType == TripLineType.Cruise || t.TripLineType == TripLineType.Tour || t.TripLineType == TripLineType.OtherLand) && t.Voucher.Amount == 0);

            if (derivedSort)
                return q.OrderBy(t => t.GetSeqNo(quoteNo)).ThenBy(t => t.StartDate <= AppConstants.VoidDate || t.EndDate <= AppConstants.VoidDate ? 1 : 0).ThenBy(t => t.Id).ToList();

            return q.OrderBy(t1 => (t1.TripLineSelections.SingleOrDefault(t2 => t2.QuoteNo == quoteNo) ?? new TripLineSelection { SeqNo = -1 }).SeqNo).ThenBy(t => t.StartDate <= AppConstants.VoidDate || t.EndDate <= AppConstants.VoidDate ? 1 : 0).ThenBy(t => t.Id).ToList();
        }

        public static List<TripLineInformation> GetTripLineInformationQuery(AppLazyContext lazyContext, int customerId, int tripId, int quoteNo = -1, bool outstandingVouchers = false) {
            var q = lazyContext.TripLine.Where(t => t.TripId == tripId).AsEnumerable();

            if (quoteNo >= 0)
                q = q.Where(t1 => t1.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo));

            if (outstandingVouchers)
                q = q.Where(t => (t.TripLineType == TripLineType.Accommodation || t.TripLineType == TripLineType.Transport || t.TripLineType == TripLineType.Cruise || t.TripLineType == TripLineType.Tour || t.TripLineType == TripLineType.OtherLand) && t.Voucher.Amount == 0);

            q = q.OrderBy(t => t.GetSeqNo(quoteNo)).ThenBy(t => t.StartDate <= AppConstants.VoidDate || t.EndDate <= AppConstants.VoidDate ? 1 : 0).ThenBy(t => t.Id);

            return q.Select(row => new TripLineInformation {
                TripLineId = row.Id,
                TripId = row.TripId,
                TripLineType = row.TripLineType,
                ClientAccountType = row.Trip.ClientAccountType,
                Voucher = row.Voucher,
                StartDate = row.StartDate,
                EndDate = row.EndDate,
                Creditors = row.Creditors,
                Description = row.Description,
                ReceiptInfo = row.ReceiptInfo,
                PaymentInfo = row.PaymentInfo,
                InvoiceInfo = row.InvoiceInfo,
                PaxNo = row.PaxNo,
                SellingPrice = row.SellingPrice,
                PackageNo = row.PackageNo,
                Gross = row.Gross,
                Commission = row.Commission,
                SupplierNet = row.SupplierNet,
                Discount = row.Discount,
                Markup = row.Markup,
                CostToClient = row.CostToClient,
                Yield = row.Yield / 100,
                ClientToAgencyReceivable = row.Trip.ClientToAgencyReceivable > 0 && row.Trip.ClientToAgencyReceivable == row.Trip.ClientToAgencyReceived ? row.AmountReceivable : 0,
                ClientToAgencyReceived = row.Trip.ClientToAgencyReceivable > 0 && row.Trip.ClientToAgencyReceivable == row.Trip.ClientToAgencyReceived ? row.AmountReceived : 0,
                AmountReceivable = row.AmountReceivable,
                AmountReceived = row.AmountReceived,
                AmountPayable = row.AmountPayable,
                AmountPaid = row.AmountPaid,
                AmountInvoiceable = row.AmountInvoiceable,
                AmountInvoiced = row.AmountInvoiced,
                AmountInvoicedWithPayment = row.TripLineType == TripLineType.Air ? row.TripLineAir?.TripLineAirPassengers.Sum(t => (decimal?)t.GetAmountInvoiced(lazyContext, false)) ?? 0 : row.GetAmountInvoiced(lazyContext, false),
                PersonalTravelAmount = row.PersonalTravelAmount,
                IsAllCreditCardPayment = row.IsAllCreditCardPayment,
                CreditCardNotPaid = row.GetCreditCardNotPaid(lazyContext, customerId),
                DoNotGenerateInvoiceLine = row.DoNotGenerateInvoiceLine,
                LastWriteTime = row.LastWriteTime,
                CreationTime = row.CreationTime,
                LastWriteUser = row.LastWriteUser,
                CreationUser = row.CreationUser
            }).ToList();
        }
    }

    public partial class Profile {
        [NotMapped]
        public string FullName {
            get {
                return (Title + " " + FirstName + " " + LastName).Trim();
            }
        }

        [NotMapped]
        public string FullNameWithEmail {
            get {
                return string.IsNullOrEmpty(Email) ? FullName : string.Concat(@"<a href=""mailto:", WebUtility.HtmlEncode(Email), @""">", FullName, "</a>");
            }
        }

        [NotMapped]
        public string AccountName {
            get {
                return Id <= 0 ? "Not Specified" : string.Concat(Code, ": ", Title, " ", FirstName, " ", LastName).Trim();
            }
        }

        [NotMapped]
        public string AccountNameLink {
            get {
                return string.Concat(@"<a href=""/ClientLedger/Trip/?profileId=", Id, @""" target=""_blank"">", AccountName, "</a>");
            }
        }

        [NotMapped]
        public string PhoneNo {
            get {
                return string.IsNullOrEmpty(PhoneWork) ? string.IsNullOrEmpty(Mobile) ? PhoneHome : Mobile : PhoneWork;
            }
        }

        [NotMapped]
        public bool IsUpdateable {
            get {
                return DebtorId <= 0 || !Debtor.IsProfileChangesPrevented;
            }
        }

        public static string GetNewCode(AppMainContext context, string lastName) {
            lastName = lastName?.Trim();

            if (string.IsNullOrEmpty(lastName))
                return string.Empty;

            lastName = Utils.RemoveExtraSpaces(lastName).Replace(" ", string.Empty).ToUpper();
            int length = lastName.Length < 8 ? lastName.Length : 8;

            string code = lastName.Substring(0, length);
            var q = context.Profile.SingleOrDefault(t => t.Code.ToLower() == code.ToLower());

            if (q == null)
                return code.ToUpper();

            int i = 1;

            while (q != null) {
                i++;
                code = string.Format("{0}{1}", lastName.Substring(0, length), i);
                q = context.Profile.SingleOrDefault(t => t.Code.ToLower() == code.ToLower());
            }

            return code.ToUpper();
        }

        public static IQueryable<Profile> GetMatchingRows(AppMainContext context, int profileId, string firstName, string lastName, string phoneHome, string phoneWork, string mobile, string fax, string email, DateTime? birthDate) {
            var q = context.Profile.Where(t => t.Id > 0 && t.Id != profileId && !string.IsNullOrEmpty(firstName) && t.FirstName.ToLower() == firstName.ToLower() && !string.IsNullOrEmpty(lastName) && t.LastName.ToLower() == lastName.ToLower()
                && ((!string.IsNullOrEmpty(phoneHome) && t.PhoneHome == phoneHome) || (!string.IsNullOrEmpty(phoneWork) && t.PhoneWork == phoneWork) || (!string.IsNullOrEmpty(mobile) && t.Mobile == mobile)
                || (!string.IsNullOrEmpty(fax) && t.Fax == fax) || (!string.IsNullOrEmpty(email) && t.Email.ToLower() == email.ToLower()) || (birthDate != null && t.BirthDate == birthDate)))
                .OrderBy(t => t.LastName).ThenBy(t => t.FirstName);

            return q.Select(row => new Profile {
                Id = row.Id,
                Code = row.Code,
                Title = row.Title,
                FirstName = row.FirstName,
                LastName = row.LastName,
                PhoneHome = row.PhoneHome,
                PhoneWork = row.PhoneWork,
                Mobile = row.Mobile,
                Fax = row.Fax,
                Email = row.Email,
                BirthDate = row.BirthDate
            });
        }
    }

    public partial class ProfileAddress {
        [NotMapped]
        public string Address {
            get {
                return Utils.RemoveExtraSpaces(string.Concat(Address1, " ", Address2, " ", Locality, " ", Region, " ", PostCode, " ", CountryCode));
            }
        }
    }

    public partial class Trip {
        [NotMapped]
        public bool IsIncomplete {
            get {
                return Id > 0 && (CategoryId <= 0 || DestinationId <= 0 || ConsultantId <= 0 || SourceId <= 0 || DepartureDate == DateTime.MinValue || FirstName.Length == 0 || LastName.Length == 0);
            }
        }

        [NotMapped]
        public string FullName {
            get {
                return IsIncomplete && string.IsNullOrEmpty(Title) && string.IsNullOrEmpty(FirstName) && string.IsNullOrEmpty(LastName) ? "Incomplete" : string.Concat(Title, " ", FirstName, " ", LastName).Trim();
            }
        }

        [NotMapped]
        public string FullNameWithEmail {
            get {
                return IsIncomplete && string.IsNullOrEmpty(FullName) ? "Incomplete" : string.IsNullOrEmpty(Email) ? FullName : string.Concat(@"<a href=""mailto:", WebUtility.HtmlEncode(Email), @""">", FullName, "</a>");
            }
        }

        [NotMapped]
        public string PhoneNo {
            get {
                return string.IsNullOrEmpty(PhoneWork) ? string.IsNullOrEmpty(Mobile) ? PhoneHome : Mobile : PhoneWork;
            }
        }

        [NotMapped]
        public string AccountName {
            get {
                return Id <= 0 ? string.Empty : string.Concat(TripNo, ": ", FullName);
            }
        }

        [NotMapped]
        public string AccountNameLink {
            get {
                return Id <= 0 ? string.Empty : string.Concat(@"<a href=""/ClientLedger/Trip/?profileId=", ProfileId, "&tripId=", Id, @""" target=""_blank"">", AccountName, "</a>");
            }
        }

        [NotMapped]
        public decimal Yield {
            get {
                try {
                    return TripLines.Sum(t => (t.TripLineAir == null ? 0 : t.TripLineAir.Commission - t.TripLineAir.Discount + t.TripLineAir.Markup)
                        + (t.TripLineLand == null ? 0 : t.TripLineLand.Commission - t.TripLineLand.Discount + t.TripLineLand.Markup)
                        + (t.TripLineInsurance == null ? 0 : t.TripLineInsurance.Commission - t.TripLineInsurance.Discount + t.TripLineInsurance.Markup)
                        + (t.TripLineForeignCurrency == null ? 0 : t.TripLineForeignCurrency.Commission + t.TripLineForeignCurrency.Markup)
                        + (t.TripLineServiceFee == null ? 0 : t.TripLineServiceFee.Commission + t.TripLineServiceFee.Markup)
                        + (t.TripLineOtherInclusion == null ? 0 : t.TripLineOtherInclusion.Commission - t.TripLineOtherInclusion.Discount + t.TripLineOtherInclusion.Markup))
                        / TripLines.Sum(t => (t.TripLineAir == null ? 0 : t.TripLineAir.SellingPrice - t.TripLineAir.NonCommissionable + t.TripLineAir.Discount + t.TripLineAir.Markup)
                        + (t.TripLineLand == null ? 0 : t.TripLineLand.SellingPrice - t.TripLineLand.NonCommissionable + t.TripLineLand.Discount + t.TripLineLand.Markup)
                        + (t.TripLineInsurance == null ? 0 : t.TripLineInsurance.SellingPrice + t.TripLineInsurance.Discount + t.TripLineInsurance.Markup)
                        + (t.TripLineForeignCurrency == null ? 0 : t.TripLineForeignCurrency.SellingPrice + t.TripLineForeignCurrency.Markup)
                        + (t.TripLineServiceFee == null ? 0 : t.TripLineServiceFee.SellingPrice + t.TripLineServiceFee.Markup)
                        + (t.TripLineOtherInclusion == null ? 0 : t.TripLineOtherInclusion.SellingPrice + t.TripLineOtherInclusion.Discount + t.TripLineOtherInclusion.Markup));
                }
                catch {
                    return 0;
                }
            }
        }

        public Crs GetCrs(int customerId) {
            foreach (var row in TripLines) {
                switch (row.TripLineType) {
                    case TripLineType.Air:
                        if (row.TripLineAir != null && row.TripLineAir.Crs != Crs.NotSpecified)
                            return row.TripLineAir.Crs;

                        break;
                    case TripLineType.Accommodation:
                    case TripLineType.Transport:
                    case TripLineType.Cruise:
                    case TripLineType.Tour:
                    case TripLineType.OtherLand:
                        if (row.TripLineLand != null && row.TripLineLand.Crs != Crs.NotSpecified)
                            return row.TripLineLand.Crs;

                        break;
                    case TripLineType.ServiceFee:
                        if (row.TripLineServiceFee != null && row.TripLineServiceFee.Crs != Crs.NotSpecified)
                            return row.TripLineServiceFee.Crs;

                        break;
                }
            }

            return (Crs)AppSettings.Setting(customerId).CrsDefaultProviderId;
        }

        public static TripStatus GetTripStatus(string code) {
            switch (code) {
                default:
                    return TripStatus.NotSpecified;
                case "AK":
                case "BK":
                case "FS":
                case "GK":
                case "HK":
                case "HS":
                case "KK":
                case "KL":
                case "LK":
                case "MK":
                case "NK":
                case "OK":
                case "PK":
                case "RR":
                case "SS":
                case "TK":
                    return TripStatus.Confirmed;
                case "AN":
                case "BN":
                case "DS":
                case "GN":
                case "HA":
                case "HN":
                case "IN":
                case "IS":
                case "MR":
                case "NN":
                case "RQ":
                case "TN":
                    return TripStatus.OnRequest;
                case "AL":
                case "BL":
                case "DL":
                case "GL":
                case "HL":
                case "HW":
                case "LL":
                case "ML":
                case "PA":
                case "PB":
                case "PC":
                case "PD":
                case "PL":
                case "PW":
                case "UU":
                case "TL":
                case "US":
                case "WL":
                    return TripStatus.Waitlisted;
                case "MN":
                case "UC":
                    return TripStatus.CannotConfirm;
                case "DX":
                case "HX":
                case "IX":
                case "NO":
                case "OX":
                case "UN":
                case "WK":
                case "XX":
                    return TripStatus.NotAvailable;
            }
        }

        public string GetClientDetails(AppMainContext context) {
            string clientDetails = string.Format("Name: {0}{1}", FullName, Environment.NewLine);
            string address = GetAddress(context, true);

            if (!string.IsNullOrEmpty(address))
                clientDetails += string.Format("Address: {0}{1}", address.Replace(AppConstants.HtmlLineBreak, ", "), Environment.NewLine);

            if (!string.IsNullOrEmpty(PhoneHome))
                clientDetails += string.Format("Phone Home: {0}{1}", PhoneHome, Environment.NewLine);

            if (!string.IsNullOrEmpty(PhoneWork))
                clientDetails += string.Format("Phone Work: {0}{1}", PhoneWork, Environment.NewLine);

            if (!string.IsNullOrEmpty(Mobile))
                clientDetails += string.Format("Mobile: {0}{1}", Mobile, Environment.NewLine);

            if (!string.IsNullOrEmpty(Fax))
                clientDetails += string.Format("Fax: {0}{1}", Fax, Environment.NewLine);

            if (!string.IsNullOrEmpty(Email))
                clientDetails += string.Format("Email: {0}{1}", Email, Environment.NewLine);

            if (DebtorId > 0) {
                var debtorContact = Debtor.DebtorContacts.OrderBy(t => t.IsDefault ? 0 : 1).FirstOrDefault();

                if (debtorContact != null) {
                    if (!string.IsNullOrEmpty(debtorContact.PhoneHome))
                        clientDetails += string.Format("Debtor Phone Home: {0}{1}", debtorContact.PhoneHome, Environment.NewLine);

                    if (!string.IsNullOrEmpty(debtorContact.PhoneWork))
                        clientDetails += string.Format("Debtor Phone Work: {0}{1}", debtorContact.PhoneWork, Environment.NewLine);

                    if (!string.IsNullOrEmpty(debtorContact.Mobile))
                        clientDetails += string.Format("Debtor Mobile: {0}{1}", debtorContact.Mobile, Environment.NewLine);

                    if (!string.IsNullOrEmpty(debtorContact.Fax))
                        clientDetails += string.Format("Debtor Fax: {0}{1}", debtorContact.Fax, Environment.NewLine);
                }
            }

            return clientDetails.TrimEnd(Environment.NewLine);
        }

        public string GetAddress(AppMainContext context, bool useCountryCode = false) {
            var tripAddress = TripAddresses.Select(t => t).OrderByDescending(t => t.IsDefault).FirstOrDefault();

            if (tripAddress == null)
                return string.Empty;

            string address = string.Empty;

            if (!string.IsNullOrEmpty(tripAddress.Address1))
                address += string.Format("{0}{1}", tripAddress.Address1, AppConstants.HtmlLineBreak);

            if (!string.IsNullOrEmpty(tripAddress.Address2))
                address += string.Format("{0}{1}", tripAddress.Address2, AppConstants.HtmlLineBreak);

            string country = string.Empty;

            if (!string.IsNullOrEmpty(tripAddress.CountryCode)) {
                if (useCountryCode) {
                    country = string.Concat(" ", tripAddress.CountryCode);
                }
                else {
                    country = string.Concat(AppConstants.HtmlLineBreak, Country.GetCountry(context, tripAddress.CountryCode).Name);
                }
            }

            address += Utils.RemoveExtraSpaces(string.Concat(tripAddress.Locality, " ", tripAddress.Region, " ", tripAddress.PostCode, country));
            return address.TrimEnd(AppConstants.HtmlLineBreak);
        }

        public DateTime GetDepartureDate(IList<TripLine> tripLines = null) {
            if (tripLines == null)
                tripLines = TripLines;

            return tripLines.Where(t => (t.TripLineType == TripLineType.Air || t.TripLineType == TripLineType.Accommodation || t.TripLineType == TripLineType.Transport || t.TripLineType == TripLineType.Cruise || t.TripLineType == TripLineType.Tour || t.TripLineType == TripLineType.OtherLand || t.TripLineType == TripLineType.Insurance || t.TripLineType == TripLineType.OtherInclusion) && t.IsBooking == IsBooking && t.StartDate > DateTime.MinValue).Min(t => (DateTime?)t.StartDate) ?? DateTime.MinValue;
        }

        public DateTime GetReturnDate(IList<TripLine> tripLines = null) {
            if (tripLines == null)
                tripLines = TripLines;

            return tripLines.Where(t => (t.TripLineType == TripLineType.Air || t.TripLineType == TripLineType.Accommodation || t.TripLineType == TripLineType.Transport || t.TripLineType == TripLineType.Cruise || t.TripLineType == TripLineType.Tour || t.TripLineType == TripLineType.OtherLand || t.TripLineType == TripLineType.Insurance || t.TripLineType == TripLineType.OtherInclusion) && t.IsBooking == IsBooking).Max(t => (DateTime?)t.EndDate) ?? DateTime.MinValue;
        }

        public decimal GetAmountInvoiced(AppLazyContext lazyContext, bool excludePayment = true) {
            return lazyContext.InvoiceDetail.Where(t => t.TripId == Id && ((excludePayment && !t.IsPayment) || !excludePayment)).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)((t.Invoice.InvoiceType == InvoiceType.Invoice ? 1 : -1) * (t.Amount + t.Tax - t.Discount - t.DiscountTax + t.PaymentTax))) ?? 0;
        }

        public decimal GetAmountReceived(AppLazyContext lazyContext) {
            return (lazyContext.ReceiptDetail.Where(t => t.Receipt.TripId == Id && t.Receipt.ReceiptType == ReceiptType.Receipt).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0)
                + (lazyContext.Bsp.Where(t1 => t1.TripId == Id).AsEnumerable().Where(t1 => t1.TripLine.IsBooking && t1.BspType != BspType.AgencyCC && t1.BspType != BspType.Conjunction && t1.BspType != BspType.Free && t1.BspType != BspType.Void && t1.BspDetails.Any(t2 => t2.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)).Sum(t1 => (decimal?)(t1.Sign * ((t1.IncludeMarkupInCreditCardPayment ? t1.Markup + t1.MarkupTax : 0) - (t1.IsCreditCardDiscountApplicable ? t1.Discount + t1.DiscountTax : 0)))) ?? 0)
                + (lazyContext.NonBsp.Where(t1 => t1.TripId == Id).AsEnumerable().Where(t1 => t1.TripLine.IsBooking && t1.NonBspType != NonBspType.AgencyCC && t1.NonBspDetails.Any(t2 => t2.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)).Sum(t1 => (decimal?)(t1.Sign * ((t1.IncludeMarkupInCreditCardPayment ? t1.Markup + t1.MarkupTax : 0) - (t1.IsCreditCardDiscountApplicable ? t1.Discount + t1.DiscountTax : 0)))) ?? 0)
                + (lazyContext.Payment.Where(t1 => t1.TripId == Id).AsEnumerable().Where(t1 => t1.PaymentDetails.Any(t2 => t2.TripLine.IsBooking) && t1.PaymentType == PaymentType.SupplierPayment && t1.PaymentDetails.Any(t2 => t2.TripLineId == Id && t2.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)).Sum(t1 => (decimal?)((t1.IncludeMarkupInCreditCardPayment ? t1.Markup + t1.MarkupTax : 0) - (t1.IsCreditCardDiscountApplicable ? t1.Discount + t1.DiscountTax : 0))) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.Payment.TripId == Id && t.Payment.PaymentType == PaymentType.ClientRefund).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);
        }

        public decimal GetAmountPaid(AppLazyContext lazyContext, bool isCash) {
            return (lazyContext.Bsp.Where(t => t.TripId == Id && t.BspType != BspType.AgencyCC && t.BspType != BspType.Conjunction && t.BspType != BspType.Free && t.BspType != BspType.Void).AsEnumerable().Where(t => t.TripLine.IsBooking).Where(t => t.TripLine.IsBooking).SelectMany(t => t.BspDetails).Where(t => (isCash && t.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard) || (!isCash && t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)).Sum(t => (decimal?)(t.Bsp.BspType == BspType.Refund ? -1 : 1) * (t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + (lazyContext.NonBsp.Where(t => t.TripId == Id && t.NonBspType != NonBspType.AgencyCC).AsEnumerable().Where(t => t.TripLine.IsBooking).SelectMany(t => t.NonBspDetails).Where(t => (isCash && t.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard) || (!isCash && t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)).Sum(t => (decimal?)(t.NonBsp.NonBspType == NonBspType.Refund ? -1 : 1) * (t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.Payment.TripId == Id && t.Payment.PaymentType != PaymentType.ClientRefund && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).AsEnumerable().Where(t => t.TripLine.IsBooking && ((isCash && t.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard) || (!isCash && t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard))).Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + GetAdjustmentAmount(lazyContext, isCash);
        }

        public decimal GetAdjustmentAmount(AppLazyContext lazyContext, bool isCash) {
            return isCash ? (lazyContext.Adjustment.Where(t => t.DebitType == DebitCreditType.Client && t.DebitTripId == Id).AsEnumerable().Where(t => t.DebitTripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.CreditType == DebitCreditType.Client && t.CreditTripId == Id).AsEnumerable().Where(t => t.CreditTripLine.IsBooking).Sum(t => (decimal?)(-t.Amount - t.Tax)) ?? 0) : 0;
        }

        public bool Update(IPrincipal principal, int customerId, AppLazyContext lazyContext = null) {
            if (Id <= 0)
                return false;

            bool disposeContext = false;

            if (lazyContext == null) {
                lazyContext = new AppLazyContext(principal, customerId, false, false);
                disposeContext = true;
            }

            try {
                var tripLines = TripLines.Where(t => t.IsBooking && t.Exists).ToList();

                var departureDate = GetDepartureDate(tripLines);
                var returnDate = GetReturnDate(tripLines);

                DepartureDate = departureDate == DateTime.MinValue ? DepartureDate : departureDate;
                ReturnDate = returnDate == DateTime.MinValue ? ReturnDate : returnDate;

                var tripLineInformation = TripLineHelper.GetTripLineInformationQuery(lazyContext, customerId, Id, 0);

                var tripLineLandCash = tripLines.Where(t => t.TripLineType != TripLineType.Air && t.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard);
                var tripLineLandCreditCard = tripLines.Where(t => t.TripLineType != TripLineType.Air && t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard);

                var tripLineAirPassengerCash = tripLines.Where(t => t.TripLineType == TripLineType.Air).SelectMany(t1 => t1.TripLineAir.TripLineAirPassengers.Where(t2 => t2.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard));
                var tripLineAirPassengerCreditCard = tripLines.Where(t => t.TripLineType == TripLineType.Air).SelectMany(t1 => t1.TripLineAir.TripLineAirPassengers.Where(t2 => t2.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard));

                ClientToAgencyReceivable = tripLineInformation.Sum(t => (decimal?)t.AmountReceivable) ?? 0;
                ClientToAgencyReceived = GetAmountReceived(lazyContext) + GetAmountInvoiced(lazyContext);
                ClientToSupplierPayable = (tripLineLandCreditCard.Sum(t => (decimal?)t.AmountPayable) ?? 0) + (tripLineAirPassengerCreditCard.Sum(t => (decimal?)t.GetAmountPayable(customerId)) ?? 0);
                ClientToSupplierPaid = GetAmountPaid(lazyContext, false);
                AgencyToSupplierPayable = (tripLineLandCash.Sum(t => (decimal?)t.AmountPayable) ?? 0) + (tripLineAirPassengerCash.Sum(t => (decimal?)t.GetAmountPayable(customerId)) ?? 0);
                AgencyToSupplierPaid = GetAmountPaid(lazyContext, true);
                VouchersPaidDirect = lazyContext.Voucher.Where(t => t.TripId == Id).AsEnumerable().Where(t => t.PaymentClass == PaymentClass.PaidDirect).Sum(t => (decimal?)(t.Amount + t.Tax + t.Discount + t.DiscountTax)) ?? 0;
                BalanceDue = ClientToAgencyReceivable - ClientToAgencyReceived;

                return lazyContext.Save(this, false);
            }
            finally {
                if (disposeContext)
                    lazyContext.Dispose();
            }
        }

        public Trip Duplicate(AppLazyContext lazyContext, IPrincipal principal, int customerId, int agencyId, int consultantId, int[] tripLineIds, int[] sourcePassengerIds, int[] targetPassengerIds, bool includeProfile, bool includeClientDetails, bool includeTripInformation, bool includePassengerDetails) {
            var passengerList = new Dictionary<int, int>();

            var tripClone = Clone() as Trip;

            tripClone.Id = 0;
            tripClone.TripNo = LastDocumentNo.DocumentNo(lazyContext, "Trip");
            tripClone.Code = string.Empty;
            tripClone.AgencyId = agencyId;
            tripClone.ConsultantId = consultantId;

            if (!includeProfile)
                tripClone.ProfileId = -1;

            if (!includeClientDetails) {
                tripClone.BookingType = BookingType.NotSpecified;
                tripClone.SerkoOnlineBookingStatus = SerkoOnlineBookingStatus.NotSpecified;
                tripClone.Title = string.Empty;
                tripClone.FirstName = string.Empty;
                tripClone.LastName = string.Empty;
                tripClone.PhoneHome = string.Empty;
                tripClone.PhoneWork = string.Empty;
                tripClone.Mobile = string.Empty;
                tripClone.Fax = string.Empty;
                tripClone.Email = string.Empty;
                tripClone.MaritalStatus = MaritalStatus.NotSpecified;
                tripClone.UserReferenceNo = string.Empty;
                tripClone.Occupation = string.Empty;
                tripClone.BusinessType = string.Empty;
                tripClone.ExchangeRate = 0;
                tripClone.BalanceDueDate = DateTime.MinValue;
                tripClone.GroupId = -1;
                tripClone.ClassId = -1;
                tripClone.CategoryId = -1;
                tripClone.DestinationId = -1;
                tripClone.LocationId = -1;
                tripClone.MainCityId = -1;
                tripClone.PaxAdult = 0;
                tripClone.PaxChild = 0;
                tripClone.PaxInfant = 0;
                tripClone.DepartureDate = DateTime.MinValue;
                tripClone.ReturnDate = DateTime.MinValue;
                tripClone.AgentId = -1;
                tripClone.SourceId = -1;
                tripClone.Rules = string.Empty;
                tripClone.Remarks = string.Empty;
                tripClone.IsLocked = false;
            }

            LastDocumentNo.DocumentNo(lazyContext, "Trip", tripClone.TripNo);
            lazyContext.Insert(tripClone);

            foreach (var tripChecklist in TripChecklists) {
                var tripChecklistClone = tripChecklist.Clone() as TripChecklist;
                tripChecklistClone.Id = 0;
                tripChecklistClone.TripId = tripClone.Id;
                lazyContext.Insert(tripChecklistClone);
            }

            if (includeClientDetails) {
                foreach (var address in TripAddresses) {
                    var addressClone = address.Clone() as TripAddress;
                    addressClone.Id = 0;
                    addressClone.TripId = tripClone.Id;
                    lazyContext.Insert(addressClone);
                }
            }

            if (sourcePassengerIds != null && sourcePassengerIds.Length > 0 && targetPassengerIds != null && targetPassengerIds.Length > 0) {
                int i = -1;

                foreach (var tripPassenger in TripPassengers.Where(t => t.Id > 0 && sourcePassengerIds.Contains(t.Id))) {
                    i++;

                    if (i > targetPassengerIds.Length - 1)
                        break;

                    if (!includePassengerDetails) {
                        passengerList.Add(tripPassenger.Id, -1);
                    }
                    else if (targetPassengerIds[i] > 0) {
                        var passengerClone = lazyContext.Passenger.Find(targetPassengerIds[i]).Clone() as Passenger;
                        passengerClone.Id = 0;
                        passengerClone.TripId = tripClone.Id;
                        passengerClone.CrsKey = string.Empty;

                        if (passengerClone.PassengerType == PassengerType.NotSpecified)
                            passengerClone.PassengerType = tripPassenger.PassengerType;

                        if (passengerClone.PhoneNo.Length == 0)
                            passengerClone.PhoneNo = tripPassenger.PhoneNo;

                        if (passengerClone.BirthDate == DateTime.MinValue)
                            passengerClone.BirthDate = tripPassenger.BirthDate;

                        if (passengerClone.Age == 0)
                            passengerClone.Age = tripPassenger.Age;

                        if (passengerClone.Gender == Gender.NotSpecified)
                            passengerClone.Gender = tripPassenger.Gender;

                        lazyContext.Insert(passengerClone);
                        passengerList.Add(tripPassenger.Id, passengerClone.Id);

                        foreach (var passengerDocument in tripPassenger.PassengerDocuments) {
                            var passengerDocumentClone = lazyContext.PassengerDocument.Find(passengerDocument.Id).Clone() as PassengerDocument;
                            passengerDocumentClone.Id = 0;
                            passengerDocumentClone.PassengerId = passengerClone.Id;
                            lazyContext.Insert(passengerDocumentClone);
                        }

                        foreach (var passengerClubMembership in tripPassenger.PassengerClubMemberships) {
                            var passengerClubMembershipClone = lazyContext.PassengerClubMembership.Find(passengerClubMembership.Id).Clone() as PassengerClubMembership;
                            passengerClubMembershipClone.Id = 0;
                            passengerClubMembershipClone.PassengerId = passengerClone.Id;
                            lazyContext.Insert(passengerClubMembershipClone);
                        }
                    }
                    else {
                        passengerList.Add(tripPassenger.Id, targetPassengerIds[i]);
                    }
                }
            }

            var tripLines = new List<TripLine>();

            if (tripLineIds == null || tripLineIds.Length == 0) {
                tripLines.AddRange(TripLines);
            }
            else {
                foreach (int tripLineId in tripLineIds) {
                    tripLines.Add(lazyContext.TripLine.Find(tripLineId));
                }
            }

            if (includeTripInformation) {
                foreach (var tripLine in tripLines.OrderBy(t => t.Id)) {
                    tripLine.Duplicate(lazyContext, principal, customerId, tripClone, passengerList, includePassengerDetails);
                }
            }

            return tripClone;
        }

        public string GetPassengersByLastName(int[] passengerIds) {
            string passengers = string.Empty;

            foreach (var passenger in TripPassengers.Where(t => passengerIds.Contains(t.Id)).OrderBy(t => t.PassengerType == PassengerType.Child ? 1 : t.PassengerType == PassengerType.Infant ? 2 : 0).GroupBy(t => new { t.LastName }).ToList()) {
                string value = string.Format("{0} {1}; ", string.Join(", ", passenger.OrderBy(t => t.PassengerType == PassengerType.Child ? 1 : t.PassengerType == PassengerType.Infant ? 2 : 0).Select(t => string.Format("{0} {1}", t.Title, t.FirstName).Trim())), passenger.Key.LastName);

                if (passenger.Count() > 1) {
                    int index = value.LastIndexOf(",");
                    value = string.Format("{0} & {1}", value.Substring(0, index), value.Substring(index + 2));
                }

                passengers += value;
            }

            return passengers.Trim().TrimEnd(';');
        }

        public bool UpdatePassengerCount(AppMainContext context, bool updateTripLines = false) {
            int paxInfant = TripPassengers.Count(t => t.PassengerType == PassengerType.Infant);
            int paxChild = TripPassengers.Count(t => t.PassengerType == PassengerType.Child);
            int paxAdult = TripPassengers.Count - paxChild - paxInfant;

            if (paxAdult < 0)
                paxAdult = 0;

            if (PaxAdult != paxAdult || PaxChild != paxChild || PaxInfant != paxInfant) {
                PaxAdult = paxAdult;
                PaxChild = paxChild;
                PaxInfant = paxInfant;
                context.Database.ExecuteSqlRaw(string.Format("update ClientLedger.Trip set PaxAdult={1}, PaxChild={2}, PaxInfant={3} where Id={0}", Id, paxAdult, paxChild, paxInfant));
            }

            if (updateTripLines) {
                foreach (var tripLine in TripLines.Where(t => t.TripLineLand != null && (t.TripLineType == TripLineType.Accommodation || t.TripLineType == TripLineType.Transport || t.TripLineType == TripLineType.Cruise || t.TripLineType == TripLineType.Tour || t.TripLineType == TripLineType.OtherLand))) {
                    tripLine.TripLineLand.UpdatePassengerCount(context);
                }
            }

            return true;
        }

        public static List<ClientLedger> GetClientLedgerQuery(AppLazyContext lazyContext, ClientReportSourceModel model) {
            var q = lazyContext.Trip.Where(t => t.Id > 0);
            var transactionDetail = lazyContext.TransactionDetail.Where(t => t.LedgerType == LedgerType.ClientLedger);

            if (model.LedgerDocumentType == LedgerDocumentType.Reconciliation || model.LedgerDocumentType == LedgerDocumentType.ReconciliationDetail)
                transactionDetail = transactionDetail.Where(t => t.Transaction.DocumentDate <= model.ReportDate);

            if (model.DepartureDateFrom != null) {
                if (model.IncludeOpenDated) {
                    q = q.Where(t => t.DepartureDate >= model.DepartureDateFrom || t.DepartureDate == AppConstants.VoidDate);
                }
                else {
                    q = q.Where(t => t.DepartureDate >= model.DepartureDateFrom);
                }
            }

            if (model.DepartureDateTo != null) {
                if (model.IncludeOpenDated) {
                    q = q.Where(t => t.DepartureDate <= model.DepartureDateTo || t.DepartureDate == AppConstants.VoidDate);
                }
                else {
                    q = q.Where(t => t.DepartureDate <= model.DepartureDateTo);
                }
            }

            if (model.TxnDateFrom != null)
                transactionDetail = transactionDetail.Where(t => t.Transaction.DocumentDate >= model.TxnDateFrom);

            if (model.TxnDateTo != null)
                transactionDetail = transactionDetail.Where(t => t.Transaction.DocumentDate <= model.TxnDateTo);

            if (model.TripIdFrom != null && model.TripIdFrom > 0) {
                q = q.Where(t => t.Id >= model.TripIdFrom);
                transactionDetail = transactionDetail.Where(t => t.TripId >= model.TripIdFrom || (t.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission && t.ReceiptDetail.Receipt.TripId >= model.TripIdFrom));
            }

            if (model.TripIdTo != null && model.TripIdTo > 0) {
                q = q.Where(t => t.Id <= model.TripIdTo);
                transactionDetail = transactionDetail.Where(t => t.TripId <= model.TripIdTo || (t.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission && t.ReceiptDetail.Receipt.TripId <= model.TripIdTo));
            }

            if (model.AgencyIds != null)
                q = q.Where(t => model.AgencyIds.Contains(t.AgencyId));

            if (model.AgentIds != null)
                q = q.Where(t => model.AgentIds.Contains(t.AgentId));

            if (model.CategoryIds != null)
                q = q.Where(t => model.CategoryIds.Contains(t.CategoryId));

            if (model.ClassIds != null)
                q = q.Where(t => model.ClassIds.Contains(t.ClassId));

            if (model.ConsultantIds != null)
                q = q.Where(t => model.ConsultantIds.Contains(t.ConsultantId));

            if (model.DebtorIds != null)
                q = q.Where(t => model.DebtorIds.Contains(t.DebtorId));

            if (model.DestinationIds != null)
                q = q.Where(t => model.DestinationIds.Contains(t.DestinationId));

            if (model.GroupIds != null)
                q = q.Where(t => model.GroupIds.Contains(t.GroupId));

            if (model.LocationIds != null)
                q = q.Where(t => model.LocationIds.Contains(t.LocationId));

            if (model.SourceIds != null)
                q = q.Where(t => model.SourceIds.Contains(t.SourceId));

            if (model.ReportOrderId == 0) {
                q = q.OrderBy(t => t.Id);
            }
            else {
                q = q.OrderBy(t => t.LastName).ThenBy(t => t.FirstName);
            }

            var result = q.ToList().ConvertAll(row => new ClientLedger(transactionDetail.Where(t => t.TripId == row.Id || (t.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission && t.ReceiptDetail.Receipt.TripId == row.Id)), model.LedgerDocumentType ?? LedgerDocumentType.Standard) {
                TripId = row.Id,
                TripNo = row.TripNo,
                FirstName = row.FirstName,
                LastName = row.LastName,
                DepartureDate = row.DepartureDate,
                Consultant = row.Consultant,
                Agency = row.Agency,
                Agent = row.Agent,
                Source = row.Source,
                Category = row.Category,
                Class = row.Class,
                Destination = row.Destination,
                Group = row.Group,
                Location = row.Location,
                Debtor = row.Debtor,
                Debit = transactionDetail.Where(t => t.TripId == row.Id && t.SignType == SignType.Debit).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0,
                Credit = transactionDetail.Where(t => t.TripId == row.Id && t.SignType == SignType.Credit).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0,
                Balance = transactionDetail.Where(t => t.TripId == row.Id).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0
            });

            switch (model.TransactionBalanceType) {
                case TransactionBalanceType.NonZero:
                    result = result.Where(t => t.Balance != 0).ToList();
                    break;
                case TransactionBalanceType.Zero:
                    result = result.Where(t => t.Balance == 0).ToList();
                    break;
                case TransactionBalanceType.Debit:
                    result = result.Where(t => t.Balance > 0).ToList();
                    break;
                case TransactionBalanceType.Credit:
                    result = result.Where(t => t.Balance < 0).ToList();
                    break;
            }

            return result;
        }
    }

    public partial class TripAddress {
        [NotMapped]
        public string Address {
            get {
                return Utils.RemoveExtraSpaces(string.Concat(Address1, " ", Address2, " ", Locality, " ", Region, " ", PostCode, " ", CountryCode));
            }
        }
    }

    public partial class TripItineraryDetail {
        [NotMapped]
        public DateTime SeqDate {
            get {
                try {
                    return TripLine.TripLineType == TripLineType.Remark && TripLine.TripLineRemark.RelatedTripLineAirSegmentId > 0 ? TripLine.TripLineRemark.RelatedTripLineAirSegment.DepartureDate.AddMinutes(1)
                        : TripLine.TripLineType == TripLineType.Remark && TripLine.TripLineRemark.RelatedTripLineId > 0 ? TripLine.TripLineRemark.RelatedTripLine.StartDate.AddMinutes(1)
                        : TripLine.TripLineType == TripLineType.Air ? TripLineAirSegment.DepartureDate
                        : TripLine.StartDate == DateTime.MinValue ? DateTime.MaxValue : TripLine.StartDate;
                }
                catch {
                    return DateTime.MinValue;
                }
            }
        }
    }

    public partial class TripLine {
        [NotMapped]
        public bool IsBooking {
            get {
                if (Id <= 0)
                    return Trip.IsBooking;

                return TripLineSelections.Any(t => t.QuoteNo == 0);
            }
        }

        [NotMapped]
        public decimal NonCommissionable {
            get {
                switch (TripLineType) {
                    default:
                        return 0;
                    case TripLineType.Air:
                        return TripLineAir?.NonCommissionable ?? 0;
                    case TripLineType.Accommodation:
                    case TripLineType.Transport:
                    case TripLineType.Cruise:
                    case TripLineType.Tour:
                    case TripLineType.OtherLand:
                        return TripLineLand?.NonCommissionable ?? 0;
                }
            }
        }

        [NotMapped]
        public decimal CashAmount {
            get {
                return TripLineType == TripLineType.Air ? TripLineAir?.TripLineAirPassengers.Sum(t => (decimal?)t.CashAmount) ?? 0
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.CashAmount ?? 0
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.CashAmount ?? 0
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.CashAmount ?? 0
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.CashAmount ?? 0
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.CashAmount ?? 0
                    : TripLineType == TripLineType.Remark ? 0
                    : 0;
            }
        }

        [NotMapped]
        public decimal CashNonCommissionable {
            get {
                return TripLineType == TripLineType.Air ? TripLineAir?.TripLineAirPassengers.Sum(t => (decimal?)t.CashNonCommissionable) ?? 0
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.CashNonCommissionable ?? 0
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.CashNonCommissionable ?? 0
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.CashNonCommissionable ?? 0
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.CashNonCommissionable ?? 0
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.CashNonCommissionable ?? 0
                    : TripLineType == TripLineType.Remark ? 0
                    : 0;
            }
        }

        [NotMapped]
        public decimal CreditCardAmount {
            get {
                return TripLineType == TripLineType.Air ? TripLineAir?.TripLineAirPassengers.Sum(t => (decimal?)t.CreditCardAmount) ?? 0
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.CreditCardAmount ?? 0
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.CreditCardAmount ?? 0
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.CreditCardAmount ?? 0
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.CreditCardAmount ?? 0
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.CreditCardAmount ?? 0
                    : TripLineType == TripLineType.Remark ? 0
                    : 0;
            }
        }

        [NotMapped]
        public decimal CreditCardNonCommissionable {
            get {
                return TripLineType == TripLineType.Air ? TripLineAir?.TripLineAirPassengers.Sum(t => (decimal?)t.CreditCardNonCommissionable) ?? 0
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.CreditCardNonCommissionable ?? 0
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.CreditCardNonCommissionable ?? 0
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.CreditCardNonCommissionable ?? 0
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.CreditCardNonCommissionable ?? 0
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.CreditCardNonCommissionable ?? 0
                    : TripLineType == TripLineType.Remark ? 0
                    : 0;
            }
        }

        [NotMapped]
        public string DetailedDescription {
            get {
                return TripLineType == TripLineType.Air ? TripLineAir?.TripLineAirRouting ?? string.Empty
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? string.IsNullOrEmpty(TripLineLand?.SupplierServiceDescription ?? string.Empty) ? TripLineLand?.Supplier.Name : string.Format("{0} [{1}]", TripLineLand?.Supplier.Name, TripLineLand?.SupplierService.Name)
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.Supplier.Name
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.Supplier.Name
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.ServiceFeeType.Name
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.Supplier.Name
                    : TripLineType == TripLineType.Remark ? TripLineRemark?.Description ?? string.Empty
                    : string.Empty;
            }
        }

        [NotMapped]
        public int RelatedTripLineId {
            get {
                return TripLineType == TripLineType.Remark ? TripLineRemark?.RelatedTripLineId > 0 || TripLineRemark?.RelatedTripLineAirSegmentId > 0 ? TripLineRemark?.RelatedTripLineId ?? -1 : Id : Id;
            }
        }

        [NotMapped]
        public bool IsAllCreditCardPayment {
            get {
                if (TripLineType == TripLineType.Air)
                    return TripLineAir?.TripLineAirPassengers.All(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) ?? false;

                return FormOfPayment?.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard;
            }
        }

        [NotMapped]
        public string DocumentNo {
            get {
                return TripLineType == TripLineType.Air ? string.Empty
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.DocumentNo
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.PolicyNo
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.DocumentNo
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.DocumentNo
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.DocumentNo
                    : TripLineType == TripLineType.Remark ? string.Empty
                    : string.Empty;
            }
        }

        [NotMapped]
        public string ConfirmationNo {
            get {
                return TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.ConfirmationNo
                    : string.Empty;
            }
        }

        [NotMapped]
        public FormOfPayment FormOfPayment {
            get {
                return TripLineType == TripLineType.Air ? new FormOfPayment { Id = -1 }
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.FormOfPayment
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.FormOfPayment
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.FormOfPayment
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.FormOfPayment
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.FormOfPayment
                    : TripLineType == TripLineType.Remark ? new FormOfPayment { Id = -1 }
                    : new FormOfPayment { Id = -1 };
            }
        }

        [NotMapped]
        public Creditor Creditor {
            get {
                return TripLineType == TripLineType.Air ? new Creditor { Id = -1 }
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.Creditor
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.Creditor
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.Creditor
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.Creditor
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.Creditor
                    : TripLineType == TripLineType.Remark ? new Creditor { Id = -1 }
                    : new Creditor { Id = -1 };
            }
        }

        [NotMapped]
        public Supplier Supplier {
            get {
                return TripLineType == TripLineType.Air ? new Supplier { Id = -1 }
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.Supplier
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.Supplier
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.Supplier
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.Supplier
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.Supplier
                    : TripLineType == TripLineType.Remark ? new Supplier { Id = -1 }
                    : new Supplier { Id = -1 };
            }
        }

        [NotMapped]
        public SaleType SaleType {
            get {
                return TripLineType == TripLineType.Air ? new SaleType { Id = -1 }
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.SaleType
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.SaleType
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.SaleType
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.SaleType
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.SaleType
                    : TripLineType == TripLineType.Remark ? new SaleType { Id = -1 }
                    : new SaleType { Id = -1 };
            }
        }

        [NotMapped]
        public DiscountReason DiscountReason {
            get {
                return TripLineType == TripLineType.Air ? new DiscountReason { Id = -1 }
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.DiscountReason
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.DiscountReason
                    : TripLineType == TripLineType.ForeignCurrency ? new DiscountReason { Id = -1 }
                    : TripLineType == TripLineType.ServiceFee ? new DiscountReason { Id = -1 }
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.DiscountReason
                    : TripLineType == TripLineType.Remark ? new DiscountReason { Id = -1 }
                    : new DiscountReason { Id = -1 };
            }
        }

        [NotMapped]
        public MarkupStrategy MarkupStrategy {
            get {
                return TripLineType == TripLineType.Air ? new MarkupStrategy { Id = -1 }
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.MarkupStrategy
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.MarkupStrategy
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.MarkupStrategy
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.MarkupStrategy
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.MarkupStrategy
                    : TripLineType == TripLineType.Remark ? new MarkupStrategy { Id = -1 }
                    : new MarkupStrategy { Id = -1 };
            }
        }

        [NotMapped]
        public OfferedReason OfferedReason {
            get {
                return TripLineType == TripLineType.Air ? new OfferedReason { Id = -1, Name = string.Empty }
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.OfferedReason
                    : TripLineType == TripLineType.Insurance ? new OfferedReason { Id = -1, Name = string.Empty }
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.OfferedReason
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.OfferedReason
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.OfferedReason
                    : TripLineType == TripLineType.Remark ? new OfferedReason { Id = -1, Name = string.Empty }
                    : new OfferedReason { Id = -1, Name = string.Empty };
            }
        }

        [NotMapped]
        public Voucher Voucher {
            get {
                return Vouchers.OrderByDescending(t => t.DocumentDate).FirstOrDefault(t => t.ReversalStatus == ReversalStatus.None) ?? new Voucher { Id = -1, DocumentNo = string.Empty };
            }
        }

        [NotMapped]
        public decimal? OfferedFare {
            get {
                return TripLineType == TripLineType.Air ? 0
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.OfferedFare
                    : TripLineType == TripLineType.Insurance ? 0
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.OfferedFare
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.OfferedFare
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.OfferedFare
                    : TripLineType == TripLineType.Remark ? 0
                    : 0;
            }
        }

        [NotMapped]
        public bool IsCreditCardDiscountApplicable {
            get {
                return TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.IsCreditCardDiscountApplicable ?? false
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.IsCreditCardDiscountApplicable ?? false
                    : TripLineType == TripLineType.OtherInclusion && (TripLineOtherInclusion?.IsCreditCardDiscountApplicable ?? false);
            }
        }

        [NotMapped]
        public bool IncludeMarkupInCreditCardPayment {
            get {
                return TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.IncludeMarkupInCreditCardPayment ?? false
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.IncludeMarkupInCreditCardPayment ?? false
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.IncludeMarkupInCreditCardPayment ?? false
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.IncludeMarkupInCreditCardPayment ?? false
                    : TripLineType == TripLineType.OtherInclusion && (TripLineOtherInclusion?.IncludeMarkupInCreditCardPayment ?? false);
            }
        }

        [NotMapped]
        public bool DoNotGenerateInvoiceLine {
            get {
                return TripLineType == TripLineType.Air ? TripLineAir?.TripLineAirPassengers.All(t => t.FormOfPayment.DoNotGenerateInvoiceLine) ?? false
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.FormOfPayment.DoNotGenerateInvoiceLine ?? false
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.FormOfPayment.DoNotGenerateInvoiceLine ?? false
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.FormOfPayment.DoNotGenerateInvoiceLine ?? false
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.FormOfPayment.DoNotGenerateInvoiceLine ?? false
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.FormOfPayment.DoNotGenerateInvoiceLine ?? false
                    : TripLineType == TripLineType.Remark && false;
            }
        }

        [NotMapped]
        public string Creditors {
            get {
                return TripLineType == TripLineType.Air ? string.Join("; ", TripLineAir?.TripLineAirPassengers.OrderBy(t => t.Creditor.Name).Select(t => t.Creditor.Name).Distinct() ?? new List<string>())
                    : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.Creditor.Name
                    : TripLineType == TripLineType.Insurance ? TripLineInsurance?.Creditor.Name
                    : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.Creditor.Name
                    : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.Creditor.Name
                    : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.Creditor.Name
                    : TripLineType == TripLineType.Remark ? "None"
                    : "None";
            }
        }

        [NotMapped]
        public decimal DiscountApplicable {
            get {
                return TripLineType == TripLineType.Air ? TripLineAir.TripLineAirPassengers.Where(t => t.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard || t.IsCreditCardDiscountApplicable).Sum(t => (decimal?)t.Discount) ?? 0 : FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard || IsCreditCardDiscountApplicable ? Discount : 0;
            }
        }

        [NotMapped]
        public decimal MarkupApplicable {
            get {
                return TripLineType == TripLineType.Air ? TripLineAir.TripLineAirPassengers.Where(t => t.FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard || t.IncludeMarkupInCreditCardPayment).Sum(t => (decimal?)t.Markup) ?? 0 : FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard || IncludeMarkupInCreditCardPayment ? Markup : 0;
            }
        }

        [NotMapped]
        public bool Exists {
            get {
                switch (TripLineType) {
                    default:
                        return false;
                    case TripLineType.Air:
                        return TripLineAir != null;
                    case TripLineType.Accommodation:
                    case TripLineType.Transport:
                    case TripLineType.Cruise:
                    case TripLineType.Tour:
                    case TripLineType.OtherLand:
                        return TripLineLand != null;
                    case TripLineType.Insurance:
                        return TripLineInsurance != null;
                    case TripLineType.ForeignCurrency:
                        return TripLineForeignCurrency != null;
                    case TripLineType.ServiceFee:
                        return TripLineServiceFee != null;
                    case TripLineType.OtherInclusion:
                        return TripLineOtherInclusion != null;
                    case TripLineType.Remark:
                        return TripLineRemark != null;
                }
            }
        }

        [NotMapped]
        public static Expression<Func<TripLine, bool>> IsCompleteWhereClause {
            get {
                return t => !(t.Trip.CategoryId <= 0 || t.Trip.DestinationId <= 0 || t.Trip.ConsultantId <= 0 || t.Trip.SourceId <= 0 || t.Trip.DepartureDate == DateTime.MinValue || t.Trip.FirstName.Length == 0 || t.Trip.LastName.Length == 0);
            }
        }

        public string GetDescription() {
            return TripLineType == TripLineType.Air ? TripLineAir == null ? string.Empty : string.Format("{0}{1}{2}", string.IsNullOrEmpty(TripLineAir.Airline.Code) ? string.Empty : string.Concat(TripLineAir.Airline.Code, " - "), TripLineAir.TripLineAirRouting, string.IsNullOrEmpty(TripLineAir.ServiceDescription) ? string.Empty : string.Format(" [{0}]", TripLineAir.ServiceDescription)).TrimEnd(" - ")
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand == null ? string.Empty : string.Format("{0}{1}{2}", string.IsNullOrEmpty(TripLineLand.SupplierName) ? TripLineLand.Supplier.Name : TripLineLand.SupplierName, string.IsNullOrEmpty(TripLineLand.SupplierServiceDescription) ? string.Empty : string.Format(" [{0}]", TripLineLand.SupplierServiceDescription), string.IsNullOrEmpty(TripLineLand.ServiceDescription) ? string.Empty : string.Format(" [{0}]", TripLineLand.ServiceDescription)).Left(256)
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.Supplier?.Name ?? string.Empty
                : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.Supplier?.Name ?? string.Empty
                : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.ServiceFeeType?.Name ?? string.Empty
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.Supplier?.Name ?? string.Empty
                : TripLineType == TripLineType.Remark ? TripLineRemark?.Description ?? string.Empty
                : string.Empty;
        }

        public DateTime GetStartDate() {
            return TripLineType == TripLineType.Air ? TripLineAir?.DepartureDate ?? DateTime.MinValue
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.StartDate ?? DateTime.MinValue
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.StartDate ?? DateTime.MinValue
                : TripLineType == TripLineType.ForeignCurrency ? DateTime.MinValue
                : TripLineType == TripLineType.ServiceFee ? DateTime.MinValue
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.StartDate ?? DateTime.MinValue
                : TripLineType == TripLineType.Remark ? TripLineRemark?.StartDate ?? DateTime.MinValue
                : DateTime.MinValue;
        }

        public DateTime GetEndDate() {
            return TripLineType == TripLineType.Air ? TripLineAir?.ArrivalDate ?? DateTime.MinValue
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.EndDate ?? DateTime.MinValue
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.EndDate ?? DateTime.MinValue
                : TripLineType == TripLineType.ForeignCurrency ? DateTime.MinValue
                : TripLineType == TripLineType.ServiceFee ? DateTime.MinValue
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.EndDate ?? DateTime.MinValue
                : TripLineType == TripLineType.Remark ? TripLineRemark?.EndDate ?? DateTime.MinValue
                : DateTime.MinValue;
        }

        public DateTime GetDatePaid(AppLazyContext lazyContext) {
            DateTime bspDate = lazyContext.Bsp.Where(t => t.TripLineId == Id && t.BspType != BspType.AgencyCC && t.BspType != BspType.Conjunction && t.BspType != BspType.Free && t.BspType != BspType.Void).Max(t => (DateTime?)t.DocumentDate) ?? DateTime.MinValue;
            DateTime nonBspDate = lazyContext.NonBsp.Where(t => t.TripLineId == Id && t.NonBspType != NonBspType.AgencyCC).Max(t => (DateTime?)t.DocumentDate) ?? DateTime.MinValue;
            DateTime paymentDate = lazyContext.PaymentDetail.Where(t => t.TripLineId == Id && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).Max(t => (DateTime?)t.Payment.DocumentDate) ?? DateTime.MinValue;
            DateTime adjustmentDate = lazyContext.Adjustment.Where(t => t.DebitTripLineId == Id || t.CreditTripLineId == Id).Max(t => (DateTime?)t.DocumentDate) ?? DateTime.MinValue;

            DateTime date = bspDate;

            if (nonBspDate > date)
                date = nonBspDate;

            if (paymentDate > date)
                date = paymentDate;

            if (adjustmentDate > date)
                date = adjustmentDate;

            return date;
        }

        public string GetFormOfPaymentDetails(AppLazyContext lazyContext) {
            DateTime paymentDate = GetDatePaid(lazyContext);
            string formOfPaymentDetails = string.Format("{0}{1}", string.Format("{0}{1}", DocumentNo.Length == 0 ? "Paid with " : string.Format("Document No {0}: Paid with ", DocumentNo), FormOfPayment.Name), paymentDate == DateTime.MinValue ? string.Empty : string.Format(" on {0}", paymentDate.ToShortDateStringExt())).Replace("with Not Specified ", string.Empty).Replace("with  on", "on");

            if ((PaymentDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0)
                formOfPaymentDetails = formOfPaymentDetails.Replace("Paid", "Refunded");

            return formOfPaymentDetails;
        }

        public int GetPaxNo() {
            return TripLineType == TripLineType.Air ? TripLineAir?.PaxNo ?? 0
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.PaxNo ?? 0
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.PaxNo ?? 0
                : TripLineType == TripLineType.ForeignCurrency ? 0
                : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.PaxNo ?? 0
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.PaxNo ?? 0
                : TripLineType == TripLineType.Remark ? 0
                : 0;
        }

        public decimal GetSeqNo(int quoteNo) {
            try {
                return TripLineType == TripLineType.Remark ? TripLineRemark.RelatedTripLineAirSegmentId > 0 ? ((TripLineRemark.RelatedTripLineAirSegment.TripLineAir.TripLine.TripLineSelections.SingleOrDefault(t => t.QuoteNo == quoteNo)?.SeqNo ?? 0) + .05m)
                    : (TripLineRemark.RelatedTripLineId > 0 ? ((TripLineRemark.RelatedTripLine.TripLineSelections.SingleOrDefault(t => t.QuoteNo == quoteNo)?.SeqNo ?? 0) + .05m)
                    : (TripLineRemark.TripLine.TripLineSelections.SingleOrDefault(t => t.QuoteNo == quoteNo)?.SeqNo ?? 0))
                    : (TripLineType == TripLineType.Air ? (TripLineAir.TripLine.TripLineSelections.SingleOrDefault(t => t.QuoteNo == quoteNo)?.SeqNo ?? 0)
                    : (TripLineSelections.SingleOrDefault(t => t.QuoteNo == quoteNo)?.SeqNo ?? 0));
            }
            catch {
                return 0;
            }
        }

        public decimal GetSupplierNet() {
            return TripLineType == TripLineType.Air ? TripLineAir?.SupplierNet ?? 0
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.SupplierNet ?? 0
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.SupplierNet ?? 0
                : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.SupplierNet ?? 0
                : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.SupplierNet ?? 0
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.SupplierNet ?? 0
                : TripLineType == TripLineType.Remark ? 0
                : 0;
        }

        public decimal GetSellingPrice() {
            return TripLineType == TripLineType.Air ? TripLineAir?.SellingPrice ?? 0
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.SellingPrice ?? 0
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.SellingPrice ?? 0
                : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.SellingPrice ?? 0
                : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.SellingPrice ?? 0
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.SellingPrice ?? 0
                : TripLineType == TripLineType.Remark ? 0
                : 0;
        }

        public decimal GetCostToClient(int customerId) {
            return TripLineType == TripLineType.Air ? TripLineAir?.GetCostToClient(customerId) ?? 0
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.GetCostToClient(customerId) ?? 0
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.GetCostToClient(customerId) ?? 0
                : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.CostToClient ?? 0
                : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.CostToClient ?? 0
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.CostToClient ?? 0
                : TripLineType == TripLineType.Remark ? 0
                : 0;
        }

        public decimal GetCostToClient(int[] passengerIds = null) {
            decimal ratio = 1;

            if (passengerIds?.Length > 0)
                ratio = (decimal)passengerIds.Length / Trip.TripPassengers.Count;

            return Math.Round(CostToClient * ratio, 2);
        }

        public decimal GetCostToClientNet(int customerId, DateTime dateApplicable, int[] passengerIds = null) {
            return GetCostToClient(passengerIds) - GetCostToClientTax(customerId, dateApplicable, passengerIds);
        }

        public decimal GetCostToClientTax(int customerId, DateTime dateApplicable, int[] passengerIds = null) {
            if (SaleType.IsTaxApplicable) {
                decimal ratio = 1;

                if (passengerIds?.Length > 0)
                    ratio = (decimal)passengerIds.Length / Trip.TripPassengers.Count;

                decimal taxRate = CustomerSettings.GetTaxRate(customerId, dateApplicable);
                return taxRate == 0 ? 0 : Math.Round(CostToClient * taxRate / (1 + taxRate) * ratio, 2);
            }
            else {
                return 0;
            }
        }

        public decimal GetGross() {
            return TripLineType == TripLineType.Air ? TripLineAir?.Gross ?? 0
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.Gross ?? 0
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.Gross ?? 0
                : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.Gross ?? 0
                : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.Gross ?? 0
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.Gross ?? 0
                : TripLineType == TripLineType.Remark ? 0
                : 0;
        }

        public decimal GetCommission() {
            return TripLineType == TripLineType.Air ? TripLineAir?.Commission ?? 0
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.Commission ?? 0
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.Commission ?? 0
                : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.Commission ?? 0
                : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.Commission ?? 0
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.Commission ?? 0
                : TripLineType == TripLineType.Remark ? 0
                : 0;
        }

        public decimal GetDiscount() {
            return TripLineType == TripLineType.Air ? TripLineAir?.Discount ?? 0
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.Discount ?? 0
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.Discount ?? 0
                : TripLineType == TripLineType.ForeignCurrency ? 0
                : TripLineType == TripLineType.ServiceFee ? 0
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.Discount ?? 0
                : TripLineType == TripLineType.Remark ? 0
                : 0;
        }

        public decimal GetMarkup() {
            return TripLineType == TripLineType.Air ? TripLineAir?.Markup ?? 0
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.Markup ?? 0
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.Markup ?? 0
                : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.Markup ?? 0
                : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.Markup ?? 0
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.Markup ?? 0
                : TripLineType == TripLineType.Remark ? 0
                : 0;
        }

        public decimal GetYield() {
            return TripLineType == TripLineType.Air ? TripLineAir?.Yield ?? 0
                : TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand ? TripLineLand?.Yield ?? 0
                : TripLineType == TripLineType.Insurance ? TripLineInsurance?.Yield ?? 0
                : TripLineType == TripLineType.ForeignCurrency ? TripLineForeignCurrency?.Yield ?? 0
                : TripLineType == TripLineType.ServiceFee ? TripLineServiceFee?.Yield ?? 0
                : TripLineType == TripLineType.OtherInclusion ? TripLineOtherInclusion?.Yield ?? 0
                : TripLineType == TripLineType.Remark ? 0
                : 0;
        }

        public bool GetCreditCardNotPaid(AppLazyContext lazyContext, int customerId) {
            if (TripLineType == TripLineType.Air)
                return TripLineAir?.TripLineAirPassengers.Any(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard && t.GetAmountPayable(customerId) != t.GetAmountPaid(lazyContext)) ?? false;

            return FormOfPayment?.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard && AmountPayable != AmountPaid;
        }

        public decimal GetAmountInvoiceable() {
            return Id <= 0 ? 0 : CostToClient - PersonalTravelAmount;
        }

        public decimal GetAmountInvoiceableDue(AppLazyContext lazyContext, bool excludePayment = true) {
            return Id <= 0 ? 0 : GetAmountInvoiceable() - GetAmountInvoiced(lazyContext, excludePayment);
        }

        public decimal GetAmountInvoiced(AppLazyContext lazyContext, bool excludePayment = true) {
            return Id <= 0 ? 0 : lazyContext.InvoiceDetail.Where(t => t.TripLineId == Id && ((excludePayment && !t.IsPayment) || !excludePayment)).Sum(t => (decimal?)((t.Invoice.InvoiceType == InvoiceType.Invoice ? 1 : -1) * (t.Amount + t.Tax - t.Discount - t.DiscountTax + t.PaymentTax))) ?? 0;
        }

        public decimal GetAmountReceivable() {
            return Id <= 0 ? 0 : FormOfPayment?.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard || Voucher?.PaymentClass == PaymentClass.PaidDirect ? -Discount + Markup : CostToClient;
        }

        public decimal GetAmountReceivableDue(AppLazyContext lazyContext) {
            return Id <= 0 ? 0 : GetAmountReceivable() - GetAmountReceived(lazyContext);
        }

        public decimal GetAmountReceived(AppLazyContext lazyContext) {
            return Id <= 0 ? 0 : (lazyContext.ReceiptDetail.Where(t => t.TripLineId == Id && t.Receipt.ReceiptType == ReceiptType.Receipt).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0)
                + (lazyContext.Bsp.Where(t1 => t1.TripLineId == Id).AsEnumerable().Where(t1 => t1.TripLine.IsBooking && t1.BspType != BspType.AgencyCC && t1.BspType != BspType.Conjunction && t1.BspType != BspType.Free && t1.BspType != BspType.Void && t1.BspDetails.Any(t2 => t2.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)).Sum(t1 => (decimal?)(t1.Sign * ((t1.IncludeMarkupInCreditCardPayment ? t1.Markup + t1.MarkupTax : 0) - (t1.IsCreditCardDiscountApplicable ? t1.Discount + t1.DiscountTax : 0)))) ?? 0)
                + (lazyContext.NonBsp.Where(t1 => t1.TripLineId == Id).AsEnumerable().Where(t1 => t1.TripLine.IsBooking && t1.NonBspType != NonBspType.AgencyCC && t1.NonBspDetails.Any(t2 => t2.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)).Sum(t1 => (decimal?)(t1.Sign * ((t1.IncludeMarkupInCreditCardPayment ? t1.Markup + t1.MarkupTax : 0) - (t1.IsCreditCardDiscountApplicable ? t1.Discount + t1.DiscountTax : 0)))) ?? 0)
                + (lazyContext.Payment.Where(t1 => t1.TripId == TripId).AsEnumerable().Where(t1 => t1.PaymentDetails.Any(t2 => t2.TripLine.IsBooking) && t1.PaymentType == PaymentType.SupplierPayment && t1.PaymentDetails.Any(t2 => t2.TripLineId == Id && t2.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)).Sum(t1 => (decimal?)((t1.IncludeMarkupInCreditCardPayment ? t1.Markup + t1.MarkupTax : 0) - (t1.IsCreditCardDiscountApplicable ? t1.Discount + t1.DiscountTax : 0))) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineId == Id && t.Payment.PaymentType == PaymentType.ClientRefund).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);
        }

        public decimal GetAmountPayable(int customerId) {
            if (Id <= 0 || Voucher.PaymentClass == PaymentClass.PaidDirect)
                return 0;

            switch (TripLineType) {
                default:
                    return CostToClient + Discount - Markup;
                case TripLineType.Air:
                    return TripLineAir.GetCostToClient(customerId) + TripLineAir.Discount - TripLineAir.Markup;
                case TripLineType.Remark:
                    return 0;
            }
        }

        public decimal GetAmountPayableDue(AppLazyContext lazyContext, int customerId) {
            return Id <= 0 ? 0 : GetAmountPayable(customerId) - GetAmountPaid(lazyContext);
        }

        public decimal GetAmountPaid(AppLazyContext lazyContext) {
            return Id <= 0 ? 0 : (lazyContext.Bsp.Where(t => t.TripLineId == Id && t.BspType != BspType.AgencyCC && t.BspType != BspType.Conjunction && t.BspType != BspType.Free && t.BspType != BspType.Void).AsEnumerable().Where(t => t.TripLine.IsBooking).SelectMany(t => t.BspDetails).Sum(t => (decimal?)(t.Bsp.BspType == BspType.Refund ? -1 : 1) * (t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + (lazyContext.NonBsp.Where(t => t.TripLineId == Id && t.NonBspType != NonBspType.AgencyCC).AsEnumerable().Where(t => t.TripLine.IsBooking).SelectMany(t => t.NonBspDetails).Sum(t => (decimal?)(t.NonBsp.NonBspType == NonBspType.Refund ? -1 : 1) * (t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineId == Id && t.Payment.PaymentType != PaymentType.ClientRefund && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.DebitType == DebitCreditType.Client && t.DebitTripLineId == Id).AsEnumerable().Where(t => t.DebitTripLine.IsBooking).Sum(t => (decimal?)(-t.Amount - t.Tax)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.CreditType == DebitCreditType.Client && t.CreditTripLineId == Id).AsEnumerable().Where(t => t.CreditTripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);
        }

        public decimal GetAmountPaidWithDiscountAndMarkup(AppLazyContext lazyContext) {
            return Id <= 0 ? 0 : (lazyContext.Bsp.Where(t => t.TripLineId == Id && t.BspType != BspType.AgencyCC && t.BspType != BspType.Conjunction && t.BspType != BspType.Free && t.BspType != BspType.Void).AsEnumerable().Where(t => t.TripLine.IsBooking).SelectMany(t => t.BspDetails).Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionableGross - t.DiscountGrossProRata + t.MarkupGrossProRata)) ?? 0)
                + (lazyContext.NonBsp.Where(t => t.TripLineId == Id && t.NonBspType != NonBspType.AgencyCC).SelectMany(t => t.NonBspDetails).AsEnumerable().Where(t => t.NonBsp.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionableGross - t.DiscountGrossProRata + t.MarkupGrossProRata)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineId == Id && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionableGross - t.DiscountGrossProRata + t.MarkupGrossProRata)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.DebitType == DebitCreditType.Client && t.DebitTripLineId == Id).AsEnumerable().Where(t => t.DebitTripLine.IsBooking).Sum(t => (decimal?)(-t.Amount - t.Tax)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.CreditType == DebitCreditType.Client && t.CreditTripLineId == Id).AsEnumerable().Where(t => t.CreditTripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);
        }

        public decimal GetAmountPaidWithDiscountAndMarkupNet(AppLazyContext lazyContext) {
            return Id <= 0 ? 0 : (lazyContext.Bsp.Where(t => t.TripLineId == Id && t.BspType != BspType.AgencyCC && t.BspType != BspType.Conjunction && t.BspType != BspType.Free && t.BspType != BspType.Void).AsEnumerable().Where(t => t.TripLine.IsBooking).SelectMany(t => t.BspDetails).Sum(t => (decimal?)(t.Amount + t.NonCommissionable - t.DiscountProRata + t.MarkupProRata)) ?? 0)
                + (lazyContext.NonBsp.Where(t => t.TripLineId == Id && t.NonBspType != NonBspType.AgencyCC).SelectMany(t => t.NonBspDetails).AsEnumerable().Where(t => t.NonBsp.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.NonCommissionable - t.DiscountProRata + t.MarkupProRata)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineId == Id && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.NonCommissionable - t.DiscountProRata + t.MarkupProRata)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.DebitType == DebitCreditType.Client && t.DebitTripLineId == Id).AsEnumerable().Where(t => t.DebitTripLine.IsBooking).Sum(t => (decimal?)(-t.Amount - t.Tax)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.CreditType == DebitCreditType.Client && t.CreditTripLineId == Id).AsEnumerable().Where(t => t.CreditTripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);
        }

        public decimal GetAmountPaidWithDiscountAndMarkupTax(AppLazyContext lazyContext) {
            return Id <= 0 ? 0 : (lazyContext.Bsp.Where(t => t.TripLineId == Id && t.BspType != BspType.AgencyCC && t.BspType != BspType.Conjunction && t.BspType != BspType.Free && t.BspType != BspType.Void).AsEnumerable().Where(t => t.TripLine.IsBooking).SelectMany(t => t.BspDetails).Sum(t => (decimal?)(t.Tax + t.NonCommissionableTax - t.DiscountTaxProRata + t.MarkupTaxProRata)) ?? 0)
                + (lazyContext.NonBsp.Where(t => t.TripLineId == Id && t.NonBspType != NonBspType.AgencyCC).SelectMany(t => t.NonBspDetails).AsEnumerable().Where(t => t.NonBsp.TripLine.IsBooking).Sum(t => (decimal?)(t.Tax + t.NonCommissionableTax - t.DiscountTaxProRata + t.MarkupTaxProRata)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineId == Id && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Tax + t.NonCommissionableTax - t.DiscountTaxProRata + t.MarkupTaxProRata)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.DebitType == DebitCreditType.Client && t.DebitTripLineId == Id).AsEnumerable().Where(t => t.DebitTripLine.IsBooking).Sum(t => (decimal?)(-t.Amount - t.Tax)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.CreditType == DebitCreditType.Client && t.CreditTripLineId == Id).AsEnumerable().Where(t => t.CreditTripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);
        }

        public decimal GetNonCommissionableDue(AppLazyContext lazyContext) {
            return Id <= 0 ? 0 : NonCommissionable - ((lazyContext.Bsp.Where(t => t.TripLineId == Id).AsEnumerable().Sum(t => (decimal?)t.TotalNonCommissionable) ?? 0)
                + (lazyContext.NonBsp.Where(t => t.TripLineId == Id).AsEnumerable().Sum(t => (decimal?)t.TotalNonCommissionable) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineId == Id).Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0));
        }

        public decimal GetCommissionDue(AppLazyContext lazyContext) {
            return Id <= 0 ? 0 : Commission - ((lazyContext.Bsp.Where(t => t.TripLineId == Id).Sum(t => (decimal?)(t.Commission + t.CommissionTax)) ?? 0)
                + (lazyContext.NonBsp.Where(t => t.TripLineId == Id).Sum(t => (decimal?)(t.Commission + t.CommissionTax)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineId == Id).AsEnumerable().Sum(t => (decimal?)t.CommissionGrossProRata) ?? 0));
        }

        public decimal GetDiscountDue(AppLazyContext lazyContext) {
            return Id <= 0 ? 0 : Discount - ((lazyContext.Bsp.Where(t => t.TripLineId == Id).Sum(t => (decimal?)(t.Discount + t.DiscountTax)) ?? 0)
                + (lazyContext.NonBsp.Where(t => t.TripLineId == Id).Sum(t => (decimal?)(t.Discount + t.DiscountTax)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineId == Id).AsEnumerable().Sum(t => (decimal?)t.DiscountGrossProRata) ?? 0));
        }

        public decimal GetMarkupDue(AppLazyContext lazyContext) {
            return Id <= 0 ? 0 : Markup - ((lazyContext.Bsp.Where(t => t.TripLineId == Id).Sum(t => (decimal?)(t.Markup + t.MarkupTax)) ?? 0)
                + (lazyContext.NonBsp.Where(t => t.TripLineId == Id).Sum(t => (decimal?)(t.Markup + t.MarkupTax)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineId == Id).AsEnumerable().Sum(t => (decimal?)t.MarkupGrossProRata) ?? 0));
        }

        public decimal GetOfferedFareDue(AppLazyContext lazyContext) {
            return Id <= 0 ? 0 : (OfferedFare ?? 0) - ((lazyContext.Bsp.FirstOrDefault(t => t.TripLineId == Id)?.OfferedFare ?? 0)
                + (lazyContext.NonBsp.FirstOrDefault(t => t.TripLineId == Id)?.OfferedFare ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineId == Id).Sum(t => (decimal?)t.OfferedFare) ?? 0));
        }

        public decimal GetDiscountLessAgentCommission(int customerId) {
            int agentCommissionDiscountReasonId = AppSettings.Setting(customerId).AgentCommissionDiscountReasonId;

            return TripLineType == TripLineType.Air ? TripLineAir.TripLineAirPassengers.Where(t => t.DiscountReasonId != agentCommissionDiscountReasonId).Sum(t => (decimal?)t.Discount) ?? 0
                : DiscountReason.Id > 0 && DiscountReason.Id != agentCommissionDiscountReasonId ? Discount : 0;
        }

        public decimal GetAgentCommission(int customerId) {
            int agentCommissionDiscountReasonId = AppSettings.Setting(customerId).AgentCommissionDiscountReasonId;

            if (agentCommissionDiscountReasonId <= 0)
                return 0;

            return TripLineType == TripLineType.Air ? TripLineAir.TripLineAirPassengers.Where(t => t.DiscountReasonId == agentCommissionDiscountReasonId).Sum(t => (decimal?)t.Discount) ?? 0
                : DiscountReason.Id > 0 && DiscountReason.Id == agentCommissionDiscountReasonId ? Discount : 0;
        }

        public decimal GetPersonalTravelAmountTax(int customerId, DateTime dateApplicable) {
            decimal taxRate;

            if (SaleType.IsTaxApplicable) {
                taxRate = CustomerSettings.GetTaxRate(customerId, dateApplicable);
                return taxRate == 0 ? 0 : Math.Round(PersonalTravelAmount * taxRate / (1 + taxRate), 2);
            }
            else {
                return 0;
            }
        }

        public string GetReceiptInfo(AppLazyContext lazyContext, ref decimal amountReceived) {
            amountReceived = TripLineType == TripLineType.Air ? TripLineAir.TripLineAirPassengers.Sum(t => (decimal?)t.GetAmountReceived(lazyContext)) ?? 0 : GetAmountReceived(lazyContext);
            return string.Join(Environment.NewLine, lazyContext.ReceiptDetail.Where(t => t.TripLineId == Id).AsEnumerable().GroupBy(t => new { t.Receipt.DocumentNo, t.Receipt.DocumentDate }).Select(t1 => string.Format("Receipt No: {0} Date: {1} Amount: {2:c2}", t1.Key.DocumentNo, t1.Key.DocumentDate.ToShortDateStringExt(), t1.Sum(t2 => t2.Amount + t2.Tax + t2.NonCommissionableGrossProRata))).Distinct()).Left(512);
        }

        public string GetPaymentInfo(AppLazyContext lazyContext, ref decimal amountPaid) {
            var bsp = lazyContext.Bsp.Where(t => t.TripLineId == Id && t.BspType != BspType.AgencyCC && t.BspType != BspType.Conjunction && t.BspType != BspType.Free && t.BspType != BspType.Void);
            var nonBsp = lazyContext.NonBsp.Where(t => t.TripLineId == Id && t.NonBspType != NonBspType.AgencyCC);
            var paymentDetail = lazyContext.PaymentDetail.Where(t => t.TripLineId == Id && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn);

            var adjustmentDebit = lazyContext.Adjustment.Where(t => t.DebitType == DebitCreditType.Client && t.DebitTripLineId == Id);
            var adjustmentCredit = lazyContext.Adjustment.Where(t => t.CreditType == DebitCreditType.Client && t.CreditTripLineId == Id);

            amountPaid = (bsp.SelectMany(t => t.BspDetails).Sum(t => (decimal?)((t.Bsp.BspType == BspType.Refund ? -1 : 1) * (t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax))) ?? 0)
                + (nonBsp.SelectMany(t => t.NonBspDetails).Sum(t => (decimal?)((t.NonBsp.NonBspType == NonBspType.Refund ? -1 : 1) * (t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax))) ?? 0)
                + (paymentDetail.Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + (adjustmentDebit.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0)
                + (adjustmentCredit.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);

            return (string.Join(Environment.NewLine, bsp.Select(t => string.Format("BSP No: {0} Date: {1} Amount: {2:c2}", t.DocumentNo, t.DocumentDate.ToShortDateStringExt(), t.TotalAmountGross)).Distinct())
                + Environment.NewLine + string.Join(Environment.NewLine, nonBsp.Select(t => string.Format("Non-BSP No: {0} Date: {1} Amount: {2:c2}", t.DocumentNo, t.DocumentDate.ToShortDateStringExt(), t.TotalAmountGross)).Distinct())
                + Environment.NewLine + string.Join(Environment.NewLine, paymentDetail.Select(t => string.Format("Payment No: {0} Date: {1} Amount: {2:c2}", t.Payment.DocumentNo, t.Payment.DocumentDate.ToShortDateStringExt(), t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)).Distinct())
                + Environment.NewLine + string.Join(Environment.NewLine, adjustmentDebit.Select(t => string.Format("Adjustment No: {0} Date: {1} Amount: {2:c2}", t.DocumentNo, t.DocumentDate.ToShortDateStringExt(), -t.Amount - t.Tax)).Distinct())
                + Environment.NewLine + string.Join(Environment.NewLine, adjustmentCredit.Select(t => string.Format("Adjustment No: {0} Date: {1} Amount: {2:c2}", t.DocumentNo, t.DocumentDate.ToShortDateStringExt(), t.Amount + t.Tax)).Distinct())).Replace(Environment.NewLine + Environment.NewLine, Environment.NewLine).Replace(Environment.NewLine + Environment.NewLine, Environment.NewLine).TrimEnd(Environment.NewLine).Left(512);
        }

        public string GetInvoiceInfo(AppLazyContext lazyContext, ref decimal amountInvoiced) {
            amountInvoiced = TripLineType == TripLineType.Air ? TripLineAir.TripLineAirPassengers.Sum(t => (decimal?)t.GetAmountInvoiced(lazyContext)) ?? 0 : GetAmountInvoiced(lazyContext);
            return string.Join(Environment.NewLine, lazyContext.InvoiceDetail.Where(t => t.TripLineId == Id).Select(t => string.Format("{0} No: {1} Date: {2} Amount: {3:c2}", t.Invoice.InvoiceType.GetEnumDescription(), t.Invoice.DocumentNo, t.Invoice.DocumentDate.ToShortDateStringExt(), t.Invoice.TotalAmount)).Distinct()).Left(512);
        }

        public string GetTooltip(AppLazyContext lazyContext) {
            return string.Format("<table class='tl-tooltip-table'><tr><td>Gross:</td><td style='text-align: right'>{0:c2}</td></tr><tr><td>Commission:</td><td style='text-align: right'>{1:c2}</td></tr><tr><td>Supplier Net:</td><td style='text-align: right'>{2:c2}</td></tr><tr><td>Selling Price:</td><td style='text-align: right'>{3:c2}</td<</tr><tr><td>Cost to Client:</td><td style='text-align: right'>{4:c2}</td></tr><tr><td>Non-Comm:</td><td style='text-align: right'>{5:c2}</td></tr><tr><td>CC Amount:</td><td style='text-align: right'>{6:c2}</td></tr><tr><td>CC Non-Comm:</td><td style='text-align: right'>{7:c2}</td></tr><tr><td>Amount Received:</td><td style='text-align: right'>{8:c2}</td></tr><tr><td>Amount Paid:</td><td style='text-align: right'>{9:c2}</td></tr></table>", Gross, Commission, SupplierNet, SellingPrice, CostToClient, NonCommissionable, CreditCardAmount, CreditCardNonCommissionable, GetAmountReceived(lazyContext), GetAmountPaid(lazyContext));
        }

        public string GetTravelDocumentInvoiceDetails(AppMainContext context, int customerId, int tripLineAirPassengerId, int[] passengerIds = null) {
            decimal paxNoRatio = 0;
            string description = string.Empty;
            string htmlRemarkAfter = string.Empty;

            GetTravelDocumentDetails(
                context: context,
                customerId: customerId,
                issuedDocumentType: IssuedDocumentType.Invoice,
                timeFormat: TimeFormat.Military,
                quoteNo: 0,
                seqNo: 0,
                packageNo: -1,
                useCountryCode: false,
                useProRata: false,
                paxNoRatio: ref paxNoRatio,
                description: ref description,
                htmlRemarkAfter: ref htmlRemarkAfter,
                tripLineAirSegmentId: 0,
                tripLineAirPassengerId: tripLineAirPassengerId,
                passengerIds: passengerIds
            );

            return string.Format("{0}.", description.TrimEnd(".")).TrimStart(".");
        }

        public bool GetTravelDocumentReportDetails(AppMainContext context, int customerId, IssuedDocumentType issuedDocumentType, TimeFormat timeFormat, int quoteNo, decimal seqNo, int packageNo, ref decimal paxNoRatio, ref string description, ref string htmlRemarkAfter, int tripLineAirSegmentId, int[] passengerIds, bool detailedFooter, List<ConfirmationDetailSubReportModel> confirmationDetailSubReportList) {
            return GetTravelDocumentDetails(
                context: context,
                customerId: customerId,
                issuedDocumentType: issuedDocumentType,
                timeFormat: timeFormat,
                quoteNo: quoteNo,
                seqNo: seqNo,
                packageNo: packageNo,
                useCountryCode: false,
                useProRata: false,
                paxNoRatio: ref paxNoRatio,
                description: ref description,
                htmlRemarkAfter: ref htmlRemarkAfter,
                tripLineAirSegmentId: tripLineAirSegmentId,
                tripLineAirPassengerId: 0,
                passengerIds: passengerIds,
                isHtml: true,
                includePricing: true,
                includeDiscount: true,
                isReport: true,
                detailedFooter: detailedFooter,
                confirmationDetailSubReportList: confirmationDetailSubReportList
            );
        }

        private bool GetTravelDocumentDetails(AppMainContext context, int customerId, IssuedDocumentType issuedDocumentType, TimeFormat timeFormat, int quoteNo, decimal seqNo, int packageNo, bool useCountryCode, bool useProRata, ref decimal paxNoRatio, ref string description, ref string htmlRemarkAfter, int tripLineAirSegmentId, int tripLineAirPassengerId, int[] passengerIds = null, bool isHtml = false, bool includePricing = false, bool includeDiscount = false, bool isReport = false, bool detailedFooter = false, List<ConfirmationDetailSubReportModel> confirmationDetailSubReportList = null) {
            if (issuedDocumentType == IssuedDocumentType.PersonalStatement)
                includeDiscount = false;

            string lineBreak = isHtml ? AppConstants.HtmlLineBreak : Environment.NewLine;
            List<TripLineRemark> tripLineRemarks = null;

            DateTime startDate = DateTime.MinValue;
            DateTime endDate = DateTime.MinValue;
            DateTime dateApplicable = DateTime.MinValue;

            decimal costToClientTotal = 0;
            decimal costToClientTaxTotal = 0;
            decimal nonCommissionableTotal = 0;
            decimal miscellaneousChargesTotal = 0;
            decimal discountTotal = 0;
            decimal agentCommissionTotal = 0;
            decimal paxNo = 0;

            string header1 = string.Empty;
            string header2 = string.Empty;
            string footer = string.Empty;
            string dateRange = string.Empty;
            string relatedRemarks = string.Empty;
            string htmlRemark = string.Empty;

            bool isInvoice = issuedDocumentType == IssuedDocumentType.Invoice;

            if (isInvoice)
                issuedDocumentType = IssuedDocumentType.Itinerary;

            int agentCommissionDiscountReasonId = AppSettings.Setting(customerId).AgentCommissionDiscountReasonId;

            if (TripLineType != TripLineType.Air && issuedDocumentType == IssuedDocumentType.Itinerary) {
                if (StartDate == DateTime.MinValue) {
                    header2 = "Open-Dated";
                }
                else if (StartDate == AppConstants.VoidDate) {
                    header2 = "Own Arrangements";
                }
                else if (StartDate == EndDate) {
                    header2 = StartDate.ToString("dddd, dd MMMM yyyy");
                }
                else {
                    if (StartDate > AppConstants.VoidDate && EndDate > AppConstants.VoidDate) {
                        header2 = string.Format("{0} to {1}", StartDate.ToString("dddd, dd MMMM yyyy"), EndDate.ToString("dddd, dd MMMM yyyy"));
                    }
                    else if (StartDate > AppConstants.VoidDate || EndDate > AppConstants.VoidDate) {
                        header2 = (StartDate > AppConstants.VoidDate ? StartDate : EndDate).ToString("dddd, dd MMMM yyyy");
                    }
                    else {
                        header2 = "Open-Dated";
                    }
                }
            }

            switch (TripLineType) {
                case TripLineType.Air:
                    List<TripLineAirSegment> q;

                    if (tripLineAirPassengerId > 0) {
                        q = TripLineAir.TripLineAirPassengers.Where(t => t.Id == tripLineAirPassengerId).SelectMany(t => t.TripLineAirPassengerAirSegments).Select(t => t.TripLineAirSegment).Where(t => tripLineAirSegmentId == 0 || t.Id == tripLineAirSegmentId).OrderBy(t => t.SeqNo).ThenBy(t => t.Id).ToList();

                        if (q.Count == 0) {
                            if (!isInvoice)
                                description = "No flight segments selected";

                            return true;
                        }

                        if (passengerIds == null || passengerIds.Length == 0)
                            passengerIds = TripLineAir.TripLineAirPassengers.Where(t => t.Id == tripLineAirPassengerId).Select(t => t.PassengerId).Distinct().ToArray();
                    }
                    else {
                        q = TripLineAir.TripLineAirSegments.Where(t => tripLineAirSegmentId == 0 || t.Id == tripLineAirSegmentId).ToList();

                        if (passengerIds == null || passengerIds.Length == 0)
                            passengerIds = q.SelectMany(t => t.TripLineAirPassengerAirSegments).Select(t => t.TripLineAirPassenger.PassengerId).Distinct().ToArray();

                        q = q.Where(t1 => t1.TripLineAirPassengerAirSegments.Any(t2 => passengerIds.Contains(t2.TripLineAirPassenger.PassengerId))).OrderBy(t1 => t1.SeqNo).ThenBy(t1 => t1.Id).ToList();
                    }

                    if (isInvoice) {
                        var tripLineAirPassengers = TripLineAir.TripLineAirPassengers.Where(t => passengerIds.Contains(t.PassengerId));

                        if (tripLineAirPassengerId > 0)
                            tripLineAirPassengers = tripLineAirPassengers.Where(t => t.Id == tripLineAirPassengerId);

                        description = string.Format("Passenger(s): {0}", string.Join("; ", tripLineAirPassengers.OrderBy(t => t.Passenger.SeqNo).ThenBy(t => t.PassengerId).Select(t => t.Passenger.FullName).Distinct()));

                        description += string.Format("{0}{1}", lineBreak, TripLineAir.TripLineAirRoutingDetailed);
                        description += string.Format("{0}Departs {1:d} - Returns {2:d}", lineBreak, TripLineAir.DepartureDate, TripLineAir.ArrivalDate);
                        description += string.Format("{0}{1}", lineBreak, string.Join(", ", TripLineAir.TripLineAirSegments.Select(t => t.GetClassDescription(context, t.AirlineCode)).Distinct()));

                        string ticketNos = string.Join(", ", tripLineAirPassengers.Where(t => t.TicketNo.Length > 0).Select(t => t.TicketNo).Distinct());

                        if (ticketNos.Length > 0)
                            description += string.Format("{0}Ticket No(s): {1}", lineBreak, ticketNos);

                        decimal nonCommissionable = tripLineAirPassengers.Sum(t => (decimal?)t.NonCommissionable) ?? 0;

                        if (nonCommissionable != 0)
                            description += string.Format("{0}Includes Taxes, Levies {1} Surcharges of {2:c2}", lineBreak, isHtml ? "&amp;" : "&", nonCommissionable);

                        description = description.TrimStart(lineBreak).TrimEnd(lineBreak);
                    }
                    else {
                        header1 = "Flight(s)";
                        int segmentCount = 0;

                        foreach (var tripLineAirSegment in q) {
                            segmentCount++;

                            if (issuedDocumentType == IssuedDocumentType.Itinerary) {
                                if (tripLineAirSegment.DepartureDate == DateTime.MinValue) {
                                    header2 = "Open-Dated";
                                }
                                else if (tripLineAirSegment.DepartureDate == AppConstants.VoidDate) {
                                    header2 = "Own Arrangements";
                                }
                                else if (tripLineAirSegment.DepartureDate == tripLineAirSegment.ArrivalDate) {
                                    header2 = tripLineAirSegment.DepartureDate.ToString("dddd, dd MMMM yyyy");
                                }
                                else {
                                    if (tripLineAirSegment.DepartureDate > AppConstants.VoidDate && tripLineAirSegment.ArrivalDate > AppConstants.VoidDate) {
                                        header2 = string.Format("{0} to {1}", tripLineAirSegment.DepartureDate.ToString("dddd, dd MMMM yyyy"), tripLineAirSegment.ArrivalDate.ToString("dddd, dd MMMM yyyy"));
                                    }
                                    else if (tripLineAirSegment.DepartureDate > AppConstants.VoidDate || tripLineAirSegment.ArrivalDate > AppConstants.VoidDate) {
                                        header2 = (tripLineAirSegment.DepartureDate > AppConstants.VoidDate ? tripLineAirSegment.DepartureDate : tripLineAirSegment.ArrivalDate).ToString("dddd, dd MMMM yyyy");
                                    }
                                    else {
                                        header2 = "Open-Dated";
                                    }
                                }
                            }

                            dateRange = string.Format("{0}{1}{2}", tripLineAirSegment.DepartureDate <= AppConstants.VoidDate ? string.Empty : tripLineAirSegment.DepartureDate.ToShortDateStringExt(), lineBreak, tripLineAirSegment.ArrivalDate <= AppConstants.VoidDate || tripLineAirSegment.ArrivalDate == tripLineAirSegment.DepartureDate ? string.Empty : tripLineAirSegment.ArrivalDate.ToShortDateStringExt());

                            startDate = tripLineAirSegment.DepartureDate;
                            endDate = tripLineAirSegment.ArrivalDate;

                            var passengerSegments = tripLineAirSegment.TripLineAirPassengerAirSegments.Where(t => passengerIds.Contains(t.TripLineAirPassenger.PassengerId)).OrderBy(t => t.SeatNo);

                            if (string.IsNullOrEmpty(description))
                                description = string.Format("Passenger(s): {0}", string.Join("; ", passengerSegments.Select(t => new { t.TripLineAirPassenger.PassengerId, t.TripLineAirPassenger.Passenger.FullName, t.TripLineAirPassenger.Passenger.SeqNo }).Distinct().OrderBy(t => t.SeqNo).ThenBy(t => t.PassengerId).Select(t => t.FullName)));

                            if (tripLineAirSegment.DepartureDate == DateTime.MinValue || tripLineAirSegment.DepartureDate == AppConstants.VoidDate) {
                                description += string.Format("{0}Depart{1}", lineBreak, tripLineAirSegment.DepartureCityId <= 0 ? string.Empty : string.Format(" {0}", tripLineAirSegment.DepartureCity.Name));
                                description += string.Format("{0}Arrive{1}", lineBreak, tripLineAirSegment.ArrivalCityId <= 0 ? string.Empty : string.Format(" {0}", tripLineAirSegment.ArrivalCity.Name));

                                if (tripLineAirSegment.DepartureDate == AppConstants.VoidDate)
                                    description += string.Format("{0}Own Arrangements", lineBreak);
                            }
                            else {
                                var airline = Airline.GetAirline(context, tripLineAirSegment.FlightNo.Left(2));

                                description += string.Format("{0}Depart{1}{2}{3}{4}", lineBreak,
                                    tripLineAirSegment.DepartureCityId <= 0 ? string.Empty : string.Format(" {0}", tripLineAirSegment.DepartureCity.Name),
                                    string.IsNullOrEmpty(tripLineAirSegment.DepartureTerminal) ? string.Empty : string.Format(" Terminal {0}", tripLineAirSegment.DepartureTerminal),
                                    airline.Id <= 0 ? string.Empty : string.Format(" on {0}", airline.Name),
                                    string.IsNullOrEmpty(tripLineAirSegment.DepartureTime) ? string.Empty : string.Format(timeFormat == TimeFormat.Standard ? " at {0:hh:mm tt}" : " at {0:HH:mm}", tripLineAirSegment.DepartureDateTime)).TrimEnd(string.Format("{0}Depart", lineBreak));

                                if (!string.IsNullOrEmpty(tripLineAirSegment.FlightNo) || tripLineAirSegment.AircraftId > 0 || !string.IsNullOrEmpty(tripLineAirSegment.AirlinePnr)) {
                                    description += lineBreak + string.Format("{0}{1}{2}", string.IsNullOrEmpty(tripLineAirSegment.FlightNo) ? string.Empty : string.Format("Flight No: {0}", tripLineAirSegment.FlightNo),
                                    tripLineAirSegment.AircraftId <= 0 ? string.Empty : string.Format(" - {0}", tripLineAirSegment.Aircraft.Name),
                                    string.IsNullOrEmpty(tripLineAirSegment.AirlinePnr) ? string.Empty : string.Format(" - Airline Ref: {0}", tripLineAirSegment.AirlinePnr)).Trim().TrimStart(" - ".ToCharArray());
                                }

                                if (!string.IsNullOrEmpty(tripLineAirSegment.Operator) && airline.Name != tripLineAirSegment.Operator)
                                    description += string.Format("{0}Operated By: {1}", lineBreak, tripLineAirSegment.Operator);

                                if (passengerSegments.Any(t => !string.IsNullOrEmpty(t.TripLineAirSegment.Class) || !string.IsNullOrEmpty(t.SeatNo) || t.BaggageAllowance > 0)) {
                                    string seatDetails = string.Join(lineBreak, passengerSegments.Select(t => string.Format("{0}{1}{2}{3}",
                                        string.IsNullOrEmpty(t.TripLineAirSegment.Class) ? string.Empty : string.Format(" - Class: {0}", t.GetClassDescription(context)),
                                        t.SeatStatus == SeatStatus.NotSpecified ? string.Empty : string.Format(" - Status: {0}", t.SeatStatus.GetEnumDescription()),
                                        string.IsNullOrEmpty(t.SeatNo) ? string.Empty : string.Format(" - Seat No: {0}", t.SeatNo),
                                        t.BaggageAllowance == 0 ? string.Empty : string.Format(" - Baggage: {0} {1}", t.BaggageAllowance, t.BaggageUnit.GetEnumDescription())).Trim().TrimStart(" - ".ToCharArray())).Distinct());

                                    description += string.Format("{0}{1}", lineBreak, seatDetails.TrimStart(" - ").Trim());
                                }

                                string checkInTime = string.IsNullOrEmpty(tripLineAirSegment.CheckInTime) ? string.Empty : string.Format("Check-In Time: {0}", string.Format(timeFormat == TimeFormat.Standard ? "{0:hh:mm tt}" : "{0:HH:mm}", DateTime.Parse(tripLineAirSegment.CheckInTime)));
                                string flightTime = string.IsNullOrEmpty(tripLineAirSegment.FlightTime) ? string.Empty : string.Format("Flight Time: {0}", tripLineAirSegment.FlightTime);

                                description += string.Format("{0}{1}", lineBreak, string.Format("{0} - {1} - Flight Status: {2}", checkInTime, flightTime, tripLineAirSegment.TripStatus.GetEnumDescription()).Trim().TrimStart(" - ".ToCharArray()));

                                if (!string.IsNullOrEmpty(tripLineAirSegment.Meals))
                                    description += string.Format("{0}Meals Served: {1}", lineBreak, tripLineAirSegment.Meals);

                                if (string.IsNullOrEmpty(tripLineAirSegment.TransitStops)) {
                                    description += string.Format("{0}Non-Stop", lineBreak);
                                }
                                else {
                                    string transitStops;

                                    if (timeFormat == TimeFormat.Standard) {
                                        transitStops = tripLineAirSegment.TransitStopsStandard;
                                    }
                                    else {
                                        transitStops = tripLineAirSegment.TransitStops;
                                    }

                                    description += string.Format("{0}Transit Stops: {1}", lineBreak, transitStops);
                                }

                                description += string.Format("{0}{1}{2}{3}", lineBreak, tripLineAirSegment.ArrivalCityId <= 0 ? string.Empty : string.Format("Arrive {0}", tripLineAirSegment.ArrivalCity.Name),
                                    string.IsNullOrEmpty(tripLineAirSegment.ArrivalTerminal) ? string.Empty : string.Format(" Terminal {0}", tripLineAirSegment.ArrivalTerminal),
                                    string.IsNullOrEmpty(tripLineAirSegment.ArrivalTime) ? string.Empty : string.Format(timeFormat == TimeFormat.Standard ? " at {0:hh:mm tt}" : " at {0:HH:mm}", tripLineAirSegment.ArrivalDateTime)).TrimEnd(AppConstants.HtmlLineBreak).TrimEnd(Environment.NewLine);
                            }

                            if (confirmationDetailSubReportList != null) {
                                var tripLineAirPassengers = context.TripLineAirPassenger.Where(t => t.TripLineId == tripLineAirSegment.TripLineAir.TripLineId && passengerIds.Contains(t.PassengerId)).ToList();

                                if (issuedDocumentType == IssuedDocumentType.PersonalStatement) {
                                    costToClientTotal = tripLineAirPassengers.Sum(t => (decimal?)t.PersonalTravelAmount) ?? 0;
                                    costToClientTaxTotal = tripLineAirPassengers.Sum(t => (decimal?)t.GetPersonalTravelAmountTax(customerId, t.TripLineAir.TripLine.StartDate == DateTime.MinValue ? t.TripLineAir.TripLine.Trip.DepartureDate : t.TripLineAir.TripLine.StartDate)) ?? 0;
                                    nonCommissionableTotal = 0;
                                    miscellaneousChargesTotal = 0;
                                }
                                else {
                                    costToClientTotal = tripLineAirPassengers.Sum(t => (decimal?)t.GetCostToClient(customerId)) ?? 0;
                                    costToClientTaxTotal = tripLineAirPassengers.Sum(t => (decimal?)t.GetCostToClientTax(customerId, t.TripLineAir.TripLine.StartDate == DateTime.MinValue ? t.TripLineAir.TripLine.Trip.DepartureDate : t.TripLineAir.TripLine.StartDate)) ?? 0;
                                    nonCommissionableTotal = tripLineAirPassengers.Sum(t => (decimal?)t.NonCommissionable) ?? 0;
                                    miscellaneousChargesTotal = tripLineAirPassengers.Where(t => t.BspEntryType == BspEntryType.Emd).Sum(t => (decimal?)t.GetCostToClient(customerId)) ?? 0;

                                    if (issuedDocumentType == IssuedDocumentType.Confirmation) {
                                        discountTotal = includeDiscount ? (tripLineAirPassengers.Sum(t => (decimal?)t.Discount) ?? 0) : 0;
                                        agentCommissionTotal = 0;
                                    }
                                    else {
                                        discountTotal = includeDiscount ? (tripLineAirPassengers.Where(t => t.DiscountReasonId != agentCommissionDiscountReasonId).Sum(t => (decimal?)t.Discount) ?? 0) : 0;
                                        agentCommissionTotal = tripLineAirPassengers.Where(t => t.DiscountReasonId == agentCommissionDiscountReasonId).Sum(t => (decimal?)t.Discount) ?? 0;
                                    }
                                }

                                footer = string.Format("Total: {0:c2}{1}", costToClientTotal - discountTotal + agentCommissionTotal, costToClientTaxTotal == 0 ? string.Empty : "*");

                                if (detailedFooter) {
                                    if (nonCommissionableTotal != 0 && issuedDocumentType != IssuedDocumentType.PersonalStatement)
                                        footer = string.Format("{0}{1}Includes Taxes, Levies {2} Surcharges of {3:c2}", footer, lineBreak, isHtml ? "&amp;" : "&", nonCommissionableTotal);

                                    if (miscellaneousChargesTotal != 0)
                                        footer = string.Format("{0}{1}Includes Miscellaneous Charges (EMD) of {2:c2}", footer, lineBreak, miscellaneousChargesTotal);

                                    if (issuedDocumentType == IssuedDocumentType.ClientStatement) {
                                        footer = string.Format("{0}{1}{2}", footer,
                                            agentCommissionTotal == 0 ? string.Empty : string.Format("{0}Less Agent Commission of {1:c2}", lineBreak, agentCommissionTotal),
                                            discountTotal == 0 ? string.Empty : string.Format("{0}Discounts have been deducted to the value of {1:c2}", lineBreak, discountTotal));
                                    }
                                }

                                tripLineRemarks = context.TripLineRemark.Include(t => t.RelatedTripLine).ThenInclude(t => t.TripLineSelections)
                                    .Where(t1 => t1.RelatedTripLineAirSegmentId == tripLineAirSegment.Id && (t1.PassengerId == -1 || passengerIds.Contains(t1.PassengerId)) && (quoteNo < 0 || t1.RelatedTripLine.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo)) && ((issuedDocumentType == IssuedDocumentType.Confirmation && t1.TripLine.PrintOnConfirmation) || (issuedDocumentType == IssuedDocumentType.Itinerary && t1.TripLine.PrintOnItinerary) || ((issuedDocumentType == IssuedDocumentType.ClientStatement || issuedDocumentType == IssuedDocumentType.PersonalStatement) && t1.TripLine.PrintOnStatement))).ToList();

                                relatedRemarks = string.Empty;

                                if (tripLineRemarks.Count > 0)
                                    relatedRemarks = string.Join(string.Format("{0}{0}", lineBreak), tripLineRemarks.Select(t => t.Remark).Distinct().ToList());

                                AddTravelDocumentDetailRow(issuedDocumentType, packageNo, seqNo, TripLineType, Id, tripLineAirSegment.Id, startDate, endDate, header1, header2, footer, dateRange, description, relatedRemarks, costToClientTotal, isHtml, confirmationDetailSubReportList);
                            }

                            description += "." + lineBreak;
                        }
                    }

                    break;
                case TripLineType.Accommodation:
                case TripLineType.Transport:
                case TripLineType.Cruise:
                case TripLineType.Tour:
                case TripLineType.OtherLand:
                    header1 = TripLineType.GetEnumDescription();

                    string startDateLabel = "Start";
                    string endDateLabel = "End";

                    switch (TripLineType) {
                        case TripLineType.Accommodation:
                            startDateLabel = "Arrival";
                            endDateLabel = "Departure";
                            break;
                        case TripLineType.Transport:
                        case TripLineType.Tour:
                            startDateLabel = "Pickup";
                            endDateLabel = "Dropoff";
                            break;
                        case TripLineType.Cruise:
                            startDateLabel = "Departure";
                            endDateLabel = "Arrival";
                            break;
                    }

                    dateRange = string.Format("{0}{1}{2}", TripLineLand.StartDate == DateTime.MinValue ? string.Empty : TripLineLand.StartDate.ToShortDateStringExt(), lineBreak, TripLineLand.EndDate == DateTime.MinValue || TripLineLand.EndDate == TripLineLand.StartDate ? string.Empty : TripLineLand.EndDate.ToShortDateStringExt());

                    startDate = TripLineLand.StartDate;
                    endDate = TripLineLand.EndDate;

                    string supplierAddress = TripLineLand.GetSupplierAddress(context, useCountryCode);
                    string startAddress = TripLineLand.GetStartAddress(context, useCountryCode);
                    string endAddress = TripLineLand.GetEndAddress(context, useCountryCode);

                    description = string.Format("{0} for {1} {2} with:", TripLineType.GetEnumDescription(), TripLineLand.Duration, TripLineLand.DurationCoverageType.GetEnumDescription());
                    description += string.Format("{0}{1}{2}", lineBreak, TripLineLand.SupplierName.Length == 0 ? TripLineLand.Supplier.Name : TripLineLand.SupplierName, supplierAddress.Length == 0 ? string.Empty : string.Format("{0}{1}", lineBreak, supplierAddress.Replace(AppConstants.HtmlLineBreak, " ").Replace(Environment.NewLine, " ")));
                    description += string.IsNullOrEmpty(TripLineLand.SupplierContactPhoneNo) ? string.Empty : string.Format("{0}Phone: {1}", lineBreak, TripLineLand.SupplierContactPhoneNo);
                    description += string.IsNullOrEmpty(TripLineLand.SupplierContactEmail) ? string.Empty : string.Format("{0}Email: {1}", lineBreak, TripLineLand.SupplierContactEmail);
                    description += string.IsNullOrEmpty(TripLineLand.ConfirmationNo?.Trim()) ? string.Empty : string.Format("{0}Confirmation No: {1}", lineBreak, TripLineLand.ConfirmationNo);

                    if (TripLineLand.SupplierServiceDescription.Length > 0)
                        description += string.Format("{0}{1}", lineBreak, TripLineLand.SupplierServiceDescription);

                    if (!string.IsNullOrEmpty(TripLineLand.StartTime) || !string.IsNullOrEmpty(TripLineLand.StartDetails) || startAddress.Length > 0) {
                        if (!string.IsNullOrEmpty(TripLineLand.StartTime))
                            description += string.Format("{0}{1} Time: {2}", lineBreak, startDateLabel, Utils.FormatTimeString(TripLineLand.StartTime, timeFormat));

                        if (!string.IsNullOrEmpty(TripLineLand.StartDetails))
                            description += string.Format("{0}{1} Details: {2}", lineBreak, startDateLabel, TripLineLand.StartDetails);

                        if (startAddress.Length > 0)
                            description += string.Format("{0}{1} Address: {2}", lineBreak, startDateLabel, startAddress.Replace(AppConstants.HtmlLineBreak, " ").Replace(Environment.NewLine, " "));
                    }

                    if (!string.IsNullOrEmpty(TripLineLand.EndTime) || !string.IsNullOrEmpty(TripLineLand.EndDetails) || endAddress.Length > 0) {
                        if (!string.IsNullOrEmpty(TripLineLand.EndTime))
                            description += string.Format("{0}{1} Time: {2}", lineBreak, endDateLabel, Utils.FormatTimeString(TripLineLand.EndTime, timeFormat));

                        if (!string.IsNullOrEmpty(TripLineLand.EndDetails))
                            description += string.Format("{0}{1} Details: {2}", lineBreak, endDateLabel, TripLineLand.EndDetails);

                        if (endAddress.Length > 0)
                            description += string.Format("{0}{1} Address: {2}", lineBreak, endDateLabel, endAddress.Replace(AppConstants.HtmlLineBreak, " ").Replace(Environment.NewLine, " "));
                    }

                    dateApplicable = TripLineLand.TripLine.StartDate == DateTime.MinValue ? TripLineLand.TripLine.Trip.DepartureDate : TripLineLand.TripLine.StartDate;

                    if ((issuedDocumentType == IssuedDocumentType.ClientStatement || issuedDocumentType == IssuedDocumentType.PersonalStatement) && TripLineLand.TripLine.Voucher.PaymentClass == PaymentClass.PaidDirect) {
                        description += string.Format("{0}{1} Voucher has been issued", lineBreak, TripLineLand.TripLine.Voucher.VoucherType.GetEnumDescription());
                        costToClientTotal = 0;
                        costToClientTaxTotal = 0;
                    }
                    else if (issuedDocumentType == IssuedDocumentType.PersonalStatement) {
                        costToClientTotal = TripLineLand.TripLine.PersonalTravelAmount;
                        costToClientTaxTotal = TripLineLand.TripLine.GetPersonalTravelAmountTax(customerId, dateApplicable);
                    }
                    else {
                        var serviceTypeRateBasis = (ServiceTypeRateBasisBase)TripLineLand.ServiceTypeRateBasisId;
                        bool useTripPassengers = TripLineLand.PassengerClassification != PassengerClassification.Individual || (serviceTypeRateBasis != ServiceTypeRateBasisBase.AccommodationPerPerson && serviceTypeRateBasis != ServiceTypeRateBasisBase.CruisePerPerson && serviceTypeRateBasis != ServiceTypeRateBasisBase.OtherLandPerPerson);

                        paxNo = useTripPassengers || TripLineLand.PaxNo == 0 ? Trip.PaxAdult + Trip.PaxChild + Trip.PaxInfant : TripLineLand.PaxNo;
                        paxNoRatio = !useProRata || paxNo == 0 ? 1 : passengerIds.Length / paxNo;

                        costToClientTotal = TripLineLand.GetCostToClient(customerId) * paxNoRatio;
                        costToClientTaxTotal = TripLineLand.TripLine.GetCostToClientTax(customerId, dateApplicable) * paxNoRatio;
                    }

                    description += string.Format("{0}{1}", lineBreak, isHtml && isReport && issuedDocumentType == IssuedDocumentType.Itinerary ? TripLineLand.Inclusions.TrimEnd('.') : TripLineLand.Comments.TrimEnd('.')).TrimEnd(AppConstants.HtmlLineBreak).TrimEnd(Environment.NewLine).Replace(AppConstants.HtmlLineBreak, lineBreak).Replace(Environment.NewLine, lineBreak);
                    break;
                case TripLineType.Insurance:
                    header1 = "Insurance";
                    dateRange = string.Format("{0}{1}{2}", TripLineInsurance.StartDate == DateTime.MinValue ? string.Empty : TripLineInsurance.StartDate.ToShortDateStringExt(), lineBreak, TripLineInsurance.StartDate == DateTime.MinValue || TripLineInsurance.EndDate == TripLineInsurance.StartDate ? string.Empty : TripLineInsurance.EndDate.ToShortDateStringExt());

                    startDate = TripLineInsurance.StartDate;
                    endDate = TripLineInsurance.EndDate;

                    string passengerNames = null;

                    if (TripLineInsurance.PaxNo > 0) {
                        passengerNames = string.Join("; ", TripLineInsurance.TripLineInsurancePassengers.OrderBy(t => t.Passenger.SeqNo).ThenBy(t => t.PassengerId).Select(t => t.Passenger.FullName));
                    }
                    else {
                        passengerNames = string.Join("; ", Trip.TripPassengers.OrderBy(t => t.SeqNo).ThenBy(t => t.Id).Select(t => t.FullName));
                    }

                    description = string.Format("Passenger(s): {0}", passengerNames);
                    description += string.Format("{0}{1}", lineBreak, TripLineInsurance.Supplier.Name);

                    if (TripLineInsurance.TripLine.IsBooking) {
                        description += string.Format("{0}Policy No {1} - {2} - {3}", lineBreak, TripLineInsurance.PolicyNo, TripLineInsurance.InsurancePolicy.Name, TripLineInsurance.InsurancePolicyPlan.Name);
                    }
                    else {
                        description += string.Format("{0}{1} - {2}", lineBreak, TripLineInsurance.InsurancePolicy.Name, TripLineInsurance.InsurancePolicyPlan.Name);
                    }

                    description += string.Format("{0}{1} day(s) cover commencing {2}", lineBreak, TripLineInsurance.Duration, TripLineInsurance.StartDate.ToShortDateStringExt());
                    description += string.Format("{0}Coverage: {1}", lineBreak, TripLineInsurance.InsurancePolicyCoverage.GetEnumDescription());

                    dateApplicable = TripLineInsurance.TripLine.StartDate == DateTime.MinValue ? TripLineInsurance.TripLine.Trip.DepartureDate : TripLineInsurance.TripLine.StartDate;

                    if (issuedDocumentType == IssuedDocumentType.PersonalStatement) {
                        costToClientTotal = TripLineInsurance.TripLine.PersonalTravelAmount;
                        costToClientTaxTotal = TripLineInsurance.TripLine.GetPersonalTravelAmountTax(customerId, dateApplicable);
                    }
                    else {
                        paxNo = TripLineInsurance.PaxNo == 0 ? Trip.PaxAdult + Trip.PaxChild + Trip.PaxInfant : TripLineInsurance.PaxNo;
                        paxNoRatio = !useProRata || paxNo == 0 ? 1 : passengerIds.Length / paxNo;

                        costToClientTotal = TripLineInsurance.GetCostToClient(customerId) * paxNoRatio;
                        costToClientTaxTotal = TripLineInsurance.TripLine.GetCostToClientTax(customerId, dateApplicable) * paxNoRatio;
                    }

                    break;
                case TripLineType.ForeignCurrency:
                    header1 = "Foreign Currency";
                    dateRange = string.Empty;

                    startDate = DateTime.MinValue;
                    endDate = DateTime.MinValue;

                    dateApplicable = TripLineForeignCurrency.TripLine.StartDate == DateTime.MinValue ? TripLineForeignCurrency.TripLine.Trip.DepartureDate : TripLineForeignCurrency.TripLine.StartDate;
                    decimal foreignAmount;

                    if (issuedDocumentType == IssuedDocumentType.PersonalStatement) {
                        foreignAmount = TripLineForeignCurrency.TripLine.PersonalTravelAmount * TripLineForeignCurrency.ExchangeRate;
                        costToClientTotal = TripLineForeignCurrency.TripLine.PersonalTravelAmount;
                        costToClientTaxTotal = TripLineForeignCurrency.TripLine.GetPersonalTravelAmountTax(customerId, dateApplicable);
                    }
                    else {
                        foreignAmount = TripLineForeignCurrency.ForeignAmount;

                        paxNo = Trip.PaxAdult + Trip.PaxChild + Trip.PaxInfant;
                        paxNoRatio = !useProRata || paxNo == 0 ? 1 : passengerIds.Length / paxNo;

                        costToClientTotal = TripLineForeignCurrency.CostToClient * paxNoRatio;
                        costToClientTaxTotal = TripLineForeignCurrency.TripLine.GetCostToClientTax(customerId, dateApplicable) * paxNoRatio;
                    }

                    description = TripLineForeignCurrency.Supplier.Name;

                    if (includePricing)
                        description += string.Format("{0}{1:n2} {2} @ Exchange Rate of {3:n4}", lineBreak, foreignAmount, TripLineForeignCurrency.Currency.Name, TripLineForeignCurrency.ExchangeRate);

                    break;
                case TripLineType.ServiceFee:
                    header1 = "Service Fee";
                    dateRange = string.Empty;

                    startDate = DateTime.MinValue;
                    endDate = DateTime.MinValue;

                    dateApplicable = TripLineServiceFee.TripLine.StartDate == DateTime.MinValue ? TripLineServiceFee.TripLine.Trip.DepartureDate : TripLineServiceFee.TripLine.StartDate;
                    description = TripLineServiceFee.ServiceFeeType.Name;

                    if (issuedDocumentType == IssuedDocumentType.PersonalStatement) {
                        costToClientTotal = TripLineServiceFee.TripLine.PersonalTravelAmount;
                        costToClientTaxTotal = TripLineServiceFee.TripLine.GetPersonalTravelAmountTax(customerId, dateApplicable);
                    }
                    else {
                        paxNo = Trip.PaxAdult + Trip.PaxChild + Trip.PaxInfant;
                        paxNoRatio = !useProRata || paxNo == 0 ? 1 : passengerIds.Length / paxNo;

                        costToClientTotal = TripLineServiceFee.CostToClient * paxNoRatio;
                        costToClientTaxTotal = TripLineServiceFee.TripLine.GetCostToClientTax(customerId, dateApplicable) * paxNoRatio;
                    }

                    break;
                case TripLineType.OtherInclusion:
                    header1 = "Other Inclusion";
                    dateRange = string.Format("{0}{1}{2}", TripLineOtherInclusion.StartDate == DateTime.MinValue ? string.Empty : TripLineOtherInclusion.StartDate.ToShortDateStringExt(), lineBreak, TripLineOtherInclusion.EndDate == DateTime.MinValue || TripLineOtherInclusion.EndDate == TripLineOtherInclusion.StartDate ? string.Empty : TripLineOtherInclusion.EndDate.ToShortDateStringExt());

                    startDate = TripLineOtherInclusion.StartDate;
                    endDate = TripLineOtherInclusion.EndDate;

                    dateApplicable = TripLineOtherInclusion.TripLine.StartDate == DateTime.MinValue ? TripLineOtherInclusion.TripLine.Trip.DepartureDate : TripLineOtherInclusion.TripLine.StartDate;
                    description = string.Format("{1}{0}{2}", lineBreak, TripLineOtherInclusion.Supplier.Name, TripLineOtherInclusion.Comments.Replace(Environment.NewLine, lineBreak)).TrimEnd(lineBreak);

                    if (issuedDocumentType == IssuedDocumentType.PersonalStatement) {
                        costToClientTotal = TripLineOtherInclusion.TripLine.PersonalTravelAmount;
                        costToClientTaxTotal = TripLineOtherInclusion.TripLine.GetPersonalTravelAmountTax(customerId, dateApplicable);
                    }
                    else {
                        paxNo = Trip.PaxAdult + Trip.PaxChild + Trip.PaxInfant;
                        paxNoRatio = !useProRata || paxNo == 0 ? 1 : passengerIds.Length / paxNo;

                        costToClientTotal = TripLineOtherInclusion.CostToClient * paxNoRatio;
                        costToClientTaxTotal = TripLineOtherInclusion.TripLine.GetCostToClientTax(customerId, dateApplicable) * paxNoRatio;
                    }

                    break;
                case TripLineType.Remark:
                    if (TripLineRemark.RelatedTripLineId <= 0 && ((issuedDocumentType == IssuedDocumentType.Confirmation && PrintOnConfirmation) || (issuedDocumentType == IssuedDocumentType.Itinerary && PrintOnItinerary) || ((issuedDocumentType == IssuedDocumentType.ClientStatement || issuedDocumentType == IssuedDocumentType.PersonalStatement) && PrintOnStatement))) {
                        string remark = TripLineRemark.Remark.TrimHtmlLineBreaks();

                        if (TripLineRemark.PrintAfterTotals) {
                            htmlRemarkAfter = remark;
                        }
                        else {
                            htmlRemark = string.Format("<p>{0}</p>", remark);
                        }

                        if (htmlRemark.Length > 0)
                            AddTravelDocumentDetailRow(issuedDocumentType, packageNo, seqNo, TripLineType, Id, -1, startDate, endDate, string.Empty, string.Empty, string.Empty, dateRange, string.Empty, htmlRemark, 0, isHtml, confirmationDetailSubReportList);
                    }

                    return true;
            }

            if (TripLineType != TripLineType.Air && confirmationDetailSubReportList != null) {
                if (detailedFooter) {
                    if (TripLineType == TripLineType.Accommodation || TripLineType == TripLineType.Transport || TripLineType == TripLineType.Cruise || TripLineType == TripLineType.Tour || TripLineType == TripLineType.OtherLand) {
                        footer = TripLineLand.GetServiceTypeRateBasisDescription(customerId, true, issuedDocumentType == IssuedDocumentType.PersonalStatement, isHtml);

                        if (costToClientTaxTotal != 0)
                            footer += "*";

                        if (issuedDocumentType == IssuedDocumentType.Confirmation) {
                            discountTotal = includeDiscount ? TripLineLand.Discount : 0;
                            agentCommissionTotal = 0;
                        }
                        else {
                            discountTotal = includeDiscount && TripLineLand.DiscountReasonId != agentCommissionDiscountReasonId ? TripLineLand.Discount : 0;
                            agentCommissionTotal = TripLineLand.DiscountReasonId == agentCommissionDiscountReasonId ? TripLineLand.Discount : 0;
                        }

                        if (TripLineType == TripLineType.Cruise && issuedDocumentType != IssuedDocumentType.PersonalStatement)
                            footer = string.Format("{0}{1}", footer, TripLineLand.NonCommissionable == 0 ? string.Empty : string.Format("{0}Includes port charges and govt taxes of {1:c2}", lineBreak, TripLineLand.NonCommissionable));

                        if (issuedDocumentType == IssuedDocumentType.ClientStatement) {
                            footer = string.Format("{0}{1}{2}", footer,
                                agentCommissionTotal == 0 ? string.Empty : string.Format("{0}Less Agent Commission of {1:c2}", lineBreak, agentCommissionTotal),
                                discountTotal == 0 ? string.Empty : string.Format("{0}Discounts have been deducted to the value of {1:c2}", lineBreak, discountTotal));
                        }
                    }
                    else if (TripLineType == TripLineType.Insurance) {
                        if (issuedDocumentType == IssuedDocumentType.Confirmation) {
                            discountTotal = includeDiscount ? TripLineInsurance.Discount : 0;
                            agentCommissionTotal = 0;
                        }
                        else {
                            discountTotal = includeDiscount && TripLineInsurance.DiscountReasonId != agentCommissionDiscountReasonId ? TripLineInsurance.Discount : 0;
                            agentCommissionTotal = TripLineInsurance.DiscountReasonId == agentCommissionDiscountReasonId ? TripLineInsurance.Discount : 0;
                        }

                        footer = string.Format("Total: {0:c2}{1}", costToClientTotal - discountTotal + agentCommissionTotal, costToClientTaxTotal == 0 ? string.Empty : "*");

                        if (issuedDocumentType == IssuedDocumentType.ClientStatement) {
                            footer = string.Format("{0}{1}{2}", footer,
                                agentCommissionTotal == 0 ? string.Empty : string.Format("{0}Less Agent Commission of {1:c2}", lineBreak, agentCommissionTotal),
                                discountTotal == 0 ? string.Empty : string.Format("{0}Discounts have been deducted to the value of {1:c2}", lineBreak, discountTotal));
                        }
                    }
                    else if (TripLineType == TripLineType.OtherInclusion) {
                        if (issuedDocumentType == IssuedDocumentType.Confirmation) {
                            discountTotal = includeDiscount ? TripLineOtherInclusion.Discount : 0;
                            agentCommissionTotal = 0;
                        }
                        else {
                            discountTotal = includeDiscount && TripLineOtherInclusion.DiscountReasonId != agentCommissionDiscountReasonId ? TripLineOtherInclusion.Discount : 0;
                            agentCommissionTotal = TripLineOtherInclusion.DiscountReasonId == agentCommissionDiscountReasonId ? TripLineOtherInclusion.Discount : 0;
                        }

                        footer = string.Format("Total: {0:c2}{1}", costToClientTotal - discountTotal + agentCommissionTotal, costToClientTaxTotal == 0 ? string.Empty : "*");

                        if (issuedDocumentType == IssuedDocumentType.ClientStatement) {
                            footer = string.Format("{0}{1}{2}", footer,
                                agentCommissionTotal == 0 ? string.Empty : string.Format("{0}Less Agent Commission of {1:c2}", lineBreak, agentCommissionTotal),
                                discountTotal == 0 ? string.Empty : string.Format("{0}Discounts have been deducted to the value of {1:c2}", lineBreak, discountTotal));
                        }
                    }
                    else {
                        footer = string.Format("Total: {0:c2}{1}", costToClientTotal - discountTotal + agentCommissionTotal, costToClientTaxTotal == 0 ? string.Empty : "*");
                    }
                }
                else {
                    footer = string.Format("Total: {0:c2}{1}", costToClientTotal - discountTotal + agentCommissionTotal, costToClientTaxTotal == 0 ? string.Empty : "*");
                }

                tripLineRemarks = context.TripLineRemark.Include(t => t.RelatedTripLine).ThenInclude(t => t.TripLineSelections)
                    .Where(t1 => t1.RelatedTripLineId == Id && (t1.PassengerId == -1 || passengerIds.Contains(t1.PassengerId)) && (quoteNo < 0 || t1.RelatedTripLine.TripLineSelections.Any(t2 => t2.QuoteNo == quoteNo)) && ((issuedDocumentType == IssuedDocumentType.Confirmation && t1.TripLine.PrintOnConfirmation) || (issuedDocumentType == IssuedDocumentType.Itinerary && t1.TripLine.PrintOnItinerary) || ((issuedDocumentType == IssuedDocumentType.ClientStatement || issuedDocumentType == IssuedDocumentType.PersonalStatement) && t1.TripLine.PrintOnStatement))).ToList();

                relatedRemarks = string.Empty;

                if (tripLineRemarks.Count > 0)
                    relatedRemarks = string.Join(string.Format("{0}{0}", lineBreak), tripLineRemarks.Select(t => t.Remark).Distinct().ToList());

                AddTravelDocumentDetailRow(issuedDocumentType, packageNo, seqNo, TripLineType, Id, -1, startDate, endDate, header1, header2, footer, dateRange, description, relatedRemarks, costToClientTotal, isHtml, confirmationDetailSubReportList);
            }

            if (!isReport)
                description = description.Replace(AppConstants.HtmlLineBreak, "; ").Replace(Environment.NewLine, "; ");

            if (isHtml) {
                description = description.Replace(Environment.NewLine, AppConstants.HtmlLineBreak);
            }
            else {
                description = description.Replace(AppConstants.HtmlLineBreak, Environment.NewLine);
            }

            description = description.Replace(":;", ":").Replace(";;", ";").Replace("; ;", ";").Replace("; @", " @").TrimEnd(AppConstants.HtmlLineBreak).TrimEnd(Environment.NewLine).TrimEnd("; ");
            return true;
        }

        private void AddTravelDocumentDetailRow(IssuedDocumentType issuedDocumentType, int packageNo, decimal seqNo, TripLineType tripLineType, int tripLineId, int tripLineAirSegmentId, DateTime startDate, DateTime endDate, string header1, string header2, string footer, string dateRange, string description, string remarks, decimal costToClient, bool isHtml, List<ConfirmationDetailSubReportModel> confirmationDetailSubReportList) {
            if (!string.IsNullOrEmpty(footer))
                footer = string.Format("<div style='text-align: right'>{0}</div>", footer.TrimEnd(AppConstants.HtmlLineBreak));

            confirmationDetailSubReportList.Add(new ConfirmationDetailSubReportModel {
                PackageNo = issuedDocumentType == IssuedDocumentType.Itinerary ? 0 : packageNo,
                TripLineType = tripLineType.ToString(),
                TripLineId = tripLineId,
                TripLineAirSegmentId = tripLineAirSegmentId,
                StartDate = startDate,
                EndDate = endDate,
                Header1 = header1,
                Header2 = header2,
                Footer = packageNo > 0 ? string.Empty : issuedDocumentType == IssuedDocumentType.Itinerary || footer.Length == 0 ? AppConstants.HtmlLineBreak : footer,
                DateRange = dateRange,
                Description = isHtml ? Utils.HtmlEncodeExceptTags(description) : description,
                Remarks = remarks,
                CostToClient = costToClient,
                SeqNo = seqNo == 0 ? (confirmationDetailSubReportList.Max(t => (int?)t.SeqNo) ?? 0) + 1 : seqNo
            });
        }

        public bool Update(IPrincipal principal, int customerId, AppLazyContext lazyContext = null, Trip trip = null) {
            if ((Id <= 0 && trip == null) || !Exists)
                return false;

            bool disposeContext = false;
            bool result = false;

            if (lazyContext == null) {
                lazyContext = new AppLazyContext(principal, customerId, false, false);
                disposeContext = true;
            }

            if (trip == null)
                trip = Trip;

            try {
                if (Id > 0) {
                    StartDate = GetStartDate();
                    EndDate = GetEndDate();
                    Description = GetDescription();
                    PaxNo = GetPaxNo();
                    Commission = GetCommission();
                    Discount = GetDiscount();
                    Markup = GetMarkup();
                    Gross = GetGross();
                    SupplierNet = GetSupplierNet();
                    SellingPrice = GetSellingPrice();
                    CostToClient = GetCostToClient(customerId);
                    Yield = GetYield() * 100;

                    AmountReceivable = TripLineType == TripLineType.Air ? TripLineAir.TripLineAirPassengers.Sum(t => (decimal?)t.GetAmountReceivable(customerId)) ?? 0 : GetAmountReceivable();
                    AmountPayable = TripLineType == TripLineType.Air ? TripLineAir.TripLineAirPassengers.Sum(t => (decimal?)t.GetAmountPayable(customerId)) ?? 0 : GetAmountPayable(customerId);
                    AmountInvoiceable = TripLineType == TripLineType.Air ? TripLineAir.TripLineAirPassengers.Sum(t => (decimal?)t.GetAmountInvoiceable(customerId)) ?? 0 : GetAmountInvoiceable();

                    result = lazyContext.Save(this, false);

                    decimal amountReceived = 0;
                    decimal amountPaid = 0;
                    decimal amountInvoiced = 0;

                    string receiptInfo = GetReceiptInfo(lazyContext, ref amountReceived);
                    string paymentInfo = GetPaymentInfo(lazyContext, ref amountPaid);
                    string invoiceInfo = GetInvoiceInfo(lazyContext, ref amountInvoiced);

                    if (AmountReceived != amountReceived || AmountPaid != amountPaid || AmountInvoiced != amountInvoiced || ReceiptInfo != receiptInfo || PaymentInfo != paymentInfo || InvoiceInfo != invoiceInfo) {
                        AmountReceived = amountReceived;
                        AmountPaid = amountPaid;
                        AmountInvoiced = amountInvoiced;
                        ReceiptInfo = receiptInfo;
                        PaymentInfo = paymentInfo;
                        InvoiceInfo = invoiceInfo;
                        lazyContext.Save(this, false);
                    }
                }

                if (trip?.Id > 0)
                    trip.Update(principal, customerId, lazyContext);

                return result;
            }
            finally {
                if (disposeContext)
                    lazyContext.Dispose();
            }
        }

        public TripLine Duplicate(AppLazyContext lazyContext, IPrincipal principal, int customerId, Trip trip, Dictionary<int, int> passengerList, bool includePassengerDetails) {
            var tripLineClone = Clone() as TripLine;

            tripLineClone.Id = 0;
            tripLineClone.TripId = trip.Id;
            tripLineClone.Trip = trip;
            tripLineClone.PackageNo = 0;

            lazyContext.Insert(tripLineClone);

            int passengerId = 0;

            if (includePassengerDetails) {
                List<Passenger> sourcePassengers = null;
                List<Passenger> targetPassengers = null;

                bool buildPassengerList = passengerList == null;
                int count = 0;

                if (buildPassengerList) {
                    sourcePassengers = Trip.TripPassengers.ToList();
                    targetPassengers = lazyContext.Passenger.Where(t => t.TripId == trip.Id).ToList();
                    passengerList = new Dictionary<int, int>();
                }
                else {
                    var sourcePassengerIds = passengerList.Select(t => t.Key).ToArray();
                    var targetPassengerIds = passengerList.Select(t => t.Value).ToArray();

                    sourcePassengers = Trip.TripPassengers.Where(t => sourcePassengerIds.Contains(t.Id)).ToList();
                    targetPassengers = new List<Passenger>();

                    foreach (int targetPassengerId in targetPassengerIds) {
                        targetPassengers.Add(lazyContext.Passenger.Find(targetPassengerId));
                    }
                }

                if (sourcePassengers != null && targetPassengers != null) {
                    foreach (var passenger in Passenger.OrderByExpression(targetPassengers)) {
                        count++;

                        if (sourcePassengers.Count < count)
                            break;

                        if (passenger.TripId != trip.Id) {
                            var passengerClone = passenger.Clone() as Passenger;

                            passengerClone.Id = 0;
                            passengerClone.TripId = trip.Id;
                            passengerClone.CrsKey = string.Empty;

                            if (passengerClone.PassengerType == PassengerType.NotSpecified)
                                passengerClone.PassengerType = passenger.PassengerType;

                            if (passengerClone.PhoneNo.Length == 0)
                                passengerClone.PhoneNo = passenger.PhoneNo;

                            if (passengerClone.BirthDate == DateTime.MinValue)
                                passengerClone.BirthDate = passenger.BirthDate;

                            if (passengerClone.Age == 0)
                                passengerClone.Age = passenger.Age;

                            if (passengerClone.Gender == Gender.NotSpecified)
                                passengerClone.Gender = passenger.Gender;

                            if (tripLineClone.Trip.TripPassengers.Any(t => t.IsDuplicate(passengerClone)))
                                continue;

                            lazyContext.Insert(passengerClone);

                            foreach (var passengerDocument in passenger.PassengerDocuments) {
                                var passengerDocumentClone = lazyContext.PassengerDocument.Find(passengerDocument.Id).Clone() as PassengerDocument;
                                passengerDocumentClone.Id = 0;
                                passengerDocumentClone.PassengerId = passengerClone.Id;
                                lazyContext.Insert(passengerDocumentClone);
                            }

                            foreach (var passengerClubMembership in passenger.PassengerClubMemberships) {
                                var passengerClubMembershipClone = lazyContext.PassengerClubMembership.Find(passengerClubMembership.Id).Clone() as PassengerClubMembership;
                                passengerClubMembershipClone.Id = 0;
                                passengerClubMembershipClone.PassengerId = passengerClone.Id;
                                lazyContext.Insert(passengerClubMembershipClone);
                            }

                            if (buildPassengerList) {
                                passengerList.Add(passenger.Id, passengerClone.Id);
                            }
                            else {
                                foreach (var row in passengerList.Where(t => t.Value == passenger.Id).ToList()) {
                                    passengerList.Remove(row.Key);
                                    passengerList.Add(row.Key, passengerClone.Id);
                                }
                            }
                        }
                    }
                }
            }

            switch (TripLineType) {
                case TripLineType.Air:
                    var tripLineAirSegmentList = new Dictionary<int, int>();

                    var tripLineAirClone = TripLineAir.Clone() as TripLineAir;
                    tripLineAirClone.TripLineId = tripLineClone.Id;
                    lazyContext.Insert(tripLineAirClone);

                    foreach (var tripLineAirSegment in TripLineAir.TripLineAirSegments.Where(t1 => passengerList == null || t1.TripLineAirPassengerAirSegments.Count == 0 || t1.TripLineAirPassengerAirSegments.Any(t2 => passengerList.Any(t3 => t3.Key == t2.TripLineAirPassenger.PassengerId))).OrderBy(t => t.SeqNo).ThenBy(t => t.Id)) {
                        var tripLineAirSegmentClone = tripLineAirSegment.Clone() as TripLineAirSegment;
                        tripLineAirSegmentClone.Id = 0;
                        tripLineAirSegmentClone.TripLineId = tripLineClone.Id;
                        tripLineAirSegmentClone.CrsKey = string.Empty;
                        lazyContext.Insert(tripLineAirSegmentClone);

                        tripLineAirSegmentList.Add(tripLineAirSegment.Id, tripLineAirSegmentClone.Id);
                    }

                    foreach (var tripLineAirPassenger in TripLineAir.TripLineAirPassengers.Where(t1 => passengerList?.Any(t2 => t2.Key == t1.PassengerId) != false).OrderBy(t => t.Id)) {
                        if (!includePassengerDetails) {
                            passengerId = -1;
                        }
                        else if (passengerList.Any(t => t.Key == tripLineAirPassenger.PassengerId)) {
                            passengerId = passengerList.Single(t => t.Key == tripLineAirPassenger.PassengerId).Value;
                        }
                        else {
                            passengerId = -1;
                        }

                        var tripLineAirPassengerClone = tripLineAirPassenger.Clone() as TripLineAirPassenger;
                        tripLineAirPassengerClone.Id = 0;
                        tripLineAirPassengerClone.TripLineId = tripLineClone.Id;
                        tripLineAirPassengerClone.PassengerId = passengerId;
                        tripLineAirPassengerClone.TicketNo = string.Empty;
                        tripLineAirPassengerClone.OriginalTicketNo = string.Empty;
                        tripLineAirPassengerClone.FormOfPaymentId = -1;

                        lazyContext.Insert(tripLineAirPassengerClone);

                        foreach (var tripLineAirPassengerAirSegment in tripLineAirPassenger.TripLineAirPassengerAirSegments.Where(t => t.TripLineAirPassengerId == tripLineAirPassenger.Id).OrderBy(t => t.Id)) {
                            if (!tripLineAirSegmentList.Any(t => t.Key == tripLineAirPassengerAirSegment.TripLineAirSegmentId))
                                continue;

                            var tripLineAirPassengerAirSegmentClone = tripLineAirPassengerAirSegment.Clone() as TripLineAirPassengerAirSegment;

                            tripLineAirPassengerAirSegmentClone.Id = 0;
                            tripLineAirPassengerAirSegmentClone.TripLineAirPassengerId = tripLineAirPassengerClone.Id;
                            tripLineAirPassengerAirSegmentClone.TripLineAirSegmentId = tripLineAirSegmentList.SingleOrDefault(t => t.Key == tripLineAirPassengerAirSegment.TripLineAirSegmentId).Value;

                            lazyContext.Insert(tripLineAirPassengerAirSegmentClone);
                        }
                    }

                    break;
                case TripLineType.Accommodation:
                case TripLineType.Transport:
                case TripLineType.Cruise:
                case TripLineType.Tour:
                case TripLineType.OtherLand:
                    var tripLineLandClone = TripLineLand.Clone() as TripLineLand;
                    tripLineLandClone.TripLineId = tripLineClone.Id;
                    tripLineLandClone.DocumentNo = string.Empty;
                    tripLineLandClone.FormOfPaymentId = -1;
                    lazyContext.Insert(tripLineLandClone);
                    break;
                case TripLineType.Insurance:
                    var tripLineInsuranceClone = TripLineInsurance.Clone() as TripLineInsurance;
                    tripLineInsuranceClone.TripLineId = tripLineClone.Id;
                    tripLineInsuranceClone.PolicyNo = string.Empty;
                    tripLineInsuranceClone.FormOfPaymentId = -1;

                    lazyContext.Insert(tripLineInsuranceClone);

                    foreach (var row in TripLineInsurance.TripLineInsurancePassengers.Where(t1 => passengerList?.Any(t2 => t2.Key == t1.PassengerId) != false).OrderBy(t => t.Id)) {
                        if (!includePassengerDetails) {
                            passengerId = -1;
                        }
                        else if (passengerList.Any(t => t.Key == row.PassengerId)) {
                            passengerId = passengerList.Single(t => t.Key == row.PassengerId).Value;
                        }
                        else {
                            passengerId = -1;
                        }

                        var tripLineInsurancePassengerClone = row.Clone() as TripLineInsurancePassenger;
                        tripLineInsurancePassengerClone.Id = 0;
                        tripLineInsurancePassengerClone.TripLineId = tripLineClone.Id;
                        tripLineInsurancePassengerClone.PassengerId = passengerId;
                        lazyContext.Insert(tripLineInsurancePassengerClone);
                    }

                    foreach (var row in TripLineInsurance.TripLineInsuranceSurcharges.Where(t1 => passengerList?.Any(t2 => t2.Key == t1.PassengerId) != false).OrderBy(t => t.Id)) {
                        var tripLineInsuranceSurchargeClone = row.Clone() as TripLineInsuranceSurcharge;
                        tripLineInsuranceSurchargeClone.Id = 0;
                        tripLineInsuranceSurchargeClone.TripLineId = tripLineClone.Id;
                        lazyContext.Insert(tripLineInsuranceSurchargeClone);
                    }

                    break;
                case TripLineType.ForeignCurrency:
                    var tripLineForeignCurrencyClone = TripLineForeignCurrency.Clone() as TripLineForeignCurrency;
                    tripLineForeignCurrencyClone.TripLineId = tripLineClone.Id;
                    tripLineForeignCurrencyClone.DocumentNo = string.Empty;
                    tripLineForeignCurrencyClone.FormOfPaymentId = -1;
                    lazyContext.Insert(tripLineForeignCurrencyClone);
                    break;
                case TripLineType.ServiceFee:
                    var tripLineServiceFeeClone = TripLineServiceFee.Clone() as TripLineServiceFee;
                    tripLineServiceFeeClone.TripLineId = tripLineClone.Id;
                    tripLineServiceFeeClone.DocumentNo = string.Empty;
                    tripLineServiceFeeClone.FormOfPaymentId = -1;
                    lazyContext.Insert(tripLineServiceFeeClone);
                    break;
                case TripLineType.OtherInclusion:
                    var tripLineOtherInclusionClone = TripLineOtherInclusion.Clone() as TripLineOtherInclusion;
                    tripLineOtherInclusionClone.TripLineId = tripLineClone.Id;
                    tripLineOtherInclusionClone.DocumentNo = string.Empty;
                    tripLineOtherInclusionClone.FormOfPaymentId = -1;
                    lazyContext.Insert(tripLineOtherInclusionClone);
                    break;
                case TripLineType.Remark:
                    if (!includePassengerDetails) {
                        passengerId = -1;
                    }
                    else if (passengerList.Any(t => t.Key == TripLineRemark.PassengerId)) {
                        passengerId = passengerList.Single(t => t.Key == TripLineRemark.PassengerId).Value;
                    }
                    else {
                        passengerId = -1;
                    }

                    var tripLineRemarkClone = TripLineRemark.Clone() as TripLineRemark;
                    tripLineRemarkClone.TripLineId = tripLineClone.Id;
                    tripLineRemarkClone.PassengerId = passengerId;
                    lazyContext.Insert(tripLineRemarkClone);
                    break;
            }

            foreach (var row in lazyContext.TripLineSelection.Where(t => t.TripLineId == Id).ToList()) {
                var tripLineSelection = new TripLineSelection {
                    Id = 0,
                    TripLineId = tripLineClone.Id,
                    QuoteNo = row.QuoteNo,
                    SeqNo = row.SeqNo
                };

                lazyContext.Insert(tripLineSelection);
            }

            using (lazyContext = new AppLazyContext(principal, customerId, false, false)) {
                tripLineClone = lazyContext.TripLine.Include(t => t.Trip).Single(t => t.Id == tripLineClone.Id);
                tripLineClone.Update(principal, customerId, lazyContext);
            }

            return tripLineClone;
        }
    }

    public partial class TripLineAir {
        [NotMapped]
        public int PaxNo {
            get {
                return TripLineAirPassengers.Select(t => t.PassengerId).Distinct().Count();
            }
        }

        [NotMapped]
        public decimal Gross {
            get {
                return TripLineAirPassengers.Sum(t => (decimal?)t.Gross) ?? 0;
            }
        }

        [NotMapped]
        public decimal CashAmount {
            get {
                return TripLineAirPassengers.Sum(t => (decimal?)t.CashAmount) ?? 0;
            }
        }

        [NotMapped]
        public decimal CashNonCommissionable {
            get {
                return TripLineAirPassengers.Sum(t => (decimal?)t.CashNonCommissionable) ?? 0;
            }
        }

        [NotMapped]
        public decimal CreditCardAmount {
            get {
                return TripLineAirPassengers.Sum(t => (decimal?)t.CreditCardAmount) ?? 0;
            }
        }

        [NotMapped]
        public decimal CreditCardNonCommissionable {
            get {
                return TripLineAirPassengers.Sum(t => (decimal?)t.CreditCardNonCommissionable) ?? 0;
            }
        }

        [NotMapped]
        public decimal SupplierNet {
            get {
                return TripLineAirPassengers.Sum(t => (decimal?)t.SupplierNet) ?? 0;
            }
        }

        [NotMapped]
        public decimal SellingPrice {
            get {
                return TripLineAirPassengers.Sum(t => (decimal?)t.SellingPrice) ?? 0;
            }
        }

        [NotMapped]
        public decimal NonCommissionable {
            get {
                return TripLineAirPassengers.Sum(t => (decimal?)t.NonCommissionable) ?? 0;
            }
        }

        [NotMapped]
        public decimal Commission {
            get {
                return TripLineAirPassengers.Sum(t => (decimal?)t.Commission) ?? 0;
            }
        }

        [NotMapped]
        public decimal Discount {
            get {
                return TripLineAirPassengers.Sum(t => (decimal?)t.Discount) ?? 0;
            }
        }

        [NotMapped]
        public decimal Markup {
            get {
                return TripLineAirPassengers.Sum(t => (decimal?)t.Markup) ?? 0;
            }
        }

        [NotMapped]
        public decimal Yield {
            get {
                return SellingPrice - NonCommissionable + Discount + Markup == 0 ? 0 : (Commission - Discount + Markup) / (SellingPrice - NonCommissionable + Discount + Markup);
            }
        }

        [NotMapped]
        public DateTime DepartureDate {
            get {
                var q = TripLineAirSegments.Where(t => t.DepartureDate > AppConstants.VoidDate);

                if (TripLine?.Trip?.IsBooking == true)
                    q = q.Where(t => t.TripLineAir.TripLine.Trip.IsBooking);

                return q.Any() ? q.Min(t => t.DepartureDate) : DateTime.MinValue;
            }
        }

        [NotMapped]
        public DateTime ArrivalDate {
            get {
                var q = TripLineAirSegments.Where(t => t.DepartureDate > AppConstants.VoidDate);

                if (TripLine?.Trip?.IsBooking == true)
                    q = q.Where(t => t.TripLineAir.TripLine.Trip.IsBooking);

                return q.Any() ? q.Max(t => t.DepartureDate.AddDays((int)t.InternationalDateOffset)) : DateTime.MinValue;
            }
        }

        [NotMapped]
        public string TripLineAirRouting {
            get {
                try {
                    var q = TripLineAirSegments.OrderBy(t => t.SeqNo).ThenBy(t => t.Id).Select(row => new {
                        row.DepartureDate,
                        DepartureCityCode = row.DepartureCity?.Code,
                        ArrivalCityCode = row.ArrivalCity?.Code
                    }).ToList();

                    var airSegments = new List<string>();
                    string arrivalCityCode = null;

                    foreach (var item in q.Where(t => t.DepartureCityCode != null && t.ArrivalCityCode != null)) {
                        if (item.DepartureDate == AppConstants.VoidDate) {
                            airSegments.Add("/");
                            continue;
                        }

                        if (item.DepartureCityCode != arrivalCityCode)
                            airSegments.Add(item.DepartureCityCode);

                        airSegments.Add(item.ArrivalCityCode);
                        arrivalCityCode = item.ArrivalCityCode;
                    }

                    return airSegments.All(t => t == "???") ? string.Empty : string.Join("/", airSegments.ToArray()).TrimEnd("/???").Replace("///", "//").TrimEnd("/");
                }
                catch {
                    return string.Empty;
                }
            }
        }

        [NotMapped]
        public string TripLineAirRoutingDetailed {
            get {
                string airSegments = string.Empty;
                string arrivalCity = null;

                foreach (var segment in TripLineAirSegments.OrderBy(t => t.SeqNo).ThenBy(t => t.Id).ToList()) {
                    if (segment.DepartureCity.Name != arrivalCity)
                        airSegments += string.Format("{0}{1}", arrivalCity == null ? string.Empty : " then ", segment.DepartureCity.Name);

                    airSegments += string.Format(" to {0}", segment.ArrivalCity.Name);
                    arrivalCity = segment.ArrivalCity.Name;
                }

                return airSegments;
            }
        }

        [NotMapped]
        public string TripLineAirRoutingWithAirline {
            get {
                try {
                    var q = TripLineAirSegments.OrderBy(t => t.SeqNo).ThenBy(t => t.Id).Select(row => new {
                        DepartureCityCode = row.DepartureCity?.Code,
                        ArrivalCityCode = row.ArrivalCity?.Code,
                        row.DepartureDate,
                        row.ArrivalDate
                    }).ToList();

                    if (q.Count == 0)
                        return string.Empty;

                    var airSegments = new List<string>();
                    string arrivalCityCode = null;

                    foreach (var item in q.Where(t => t.DepartureCityCode != null && t.ArrivalCityCode != null)) {
                        if (item.DepartureCityCode != arrivalCityCode)
                            airSegments.Add(item.DepartureCityCode);

                        airSegments.Add(item.ArrivalCityCode);
                        arrivalCityCode = item.ArrivalCityCode;
                    }

                    string route = airSegments.All(t => t == "???") ? string.Empty : string.Join("/", airSegments.ToArray()).TrimEnd("/???");

                    DateTime departureDate = q.First().DepartureDate;
                    DateTime arrivalDate = q.Last().ArrivalDate;

                    var tripLineAirRouting = departureDate <= AppConstants.VoidDate && arrivalDate == DateTime.MinValue ? route
                        : departureDate > AppConstants.VoidDate ? string.Format("{0} Departing {1}", route, departureDate.ToShortDateStringExt())
                        : arrivalDate > DateTime.MinValue ? string.Format("{0} Returning {1}", route, arrivalDate.ToShortDateStringExt())
                        : string.Format("{0} Departing {1} Returning {2}", route, departureDate.ToShortDateStringExt(), arrivalDate.ToShortDateStringExt());

                    return string.Format("{0}{1}", string.IsNullOrEmpty(tripLineAirRouting) && Airline.Id <= 0 ? "Not Specified"
                        : string.IsNullOrEmpty(tripLineAirRouting) ? Airline.Code
                        : Airline.Id <= 0 ? tripLineAirRouting.TrimEnd('/')
                        : string.Concat(Airline.Code, " - ", tripLineAirRouting.TrimEnd('/')), TripLineAirPassengers.Any(t => t.SaleType.IsTaxApplicable) ? "*" : string.Empty);
                }
                catch {
                    return string.Empty;
                }
            }
        }

        public decimal GetCostToClient(int customerId) {
            return TripLineAirPassengers.Sum(t => (decimal?)t.GetCostToClient(customerId)) ?? 0;
        }
    }

    public partial class TripLineAirSegment {
        [NotMapped]
        public DateTime ArrivalDate {
            get {
                return DepartureDate <= AppConstants.VoidDate ? DepartureDate : DepartureDate.AddDays((int)InternationalDateOffset);
            }
        }

        [NotMapped]
        public DateTime DepartureDateTime {
            get {
                if (DepartureDate <= AppConstants.VoidDate)
                    return DateTime.MinValue;

                if (string.IsNullOrEmpty(DepartureTime))
                    return DepartureDate;

                return DepartureDate.AddHours(DepartureTime.Left(2).ToInt()).AddMinutes(DepartureTime.Right(2).ToInt());
            }
        }

        [NotMapped]
        public DateTime ArrivalDateTime {
            get {
                if (ArrivalDate == DateTime.MinValue)
                    return DateTime.MinValue;

                if (string.IsNullOrEmpty(ArrivalTime))
                    return ArrivalDate;

                return ArrivalDate.AddHours(ArrivalTime.Left(2).ToInt()).AddMinutes(ArrivalTime.Right(2).ToInt());
            }
        }

        [NotMapped]
        public string AirlineCode {
            get {
                return FlightNo.Left(2).ToUpper();
            }
        }

        [NotMapped]
        public string TransitStopsStandard {
            get {
                try {
                    string transitStops = TransitStops;

                    string arrivalTime = transitStops.Substring(transitStops.IndexOf(";") - 5, 5);
                    string departureTime = transitStops.Right(5);

                    string arrivalTimeStandard = string.Format("{0:hh:mm tt}", DateTime.Parse(arrivalTime));
                    string departureTimeStandard = string.Format("{0:hh:mm tt}", DateTime.Parse(departureTime));

                    return transitStops.Replace(arrivalTime, arrivalTimeStandard).Replace(departureTime, departureTimeStandard);
                }
                catch {
                    return TransitStops;
                }
            }
        }

        public string GetClassDescription(AppMainContext context, int airlineId) {
            var q1 = context.AirlineClass.SingleOrDefault(t => t.AirlineId == airlineId && t.Code == Class);

            if (q1 != null)
                return q1.Name;

            var q2 = context.TravelClassDefault.SingleOrDefault(t => t.Code == Class);
            return q2 == null ? "Economy Class" : q2.Name;
        }

        public string GetClassDescription(AppMainContext context, string airlineCode) {
            var q1 = context.AirlineClass.Include(t => t.Airline).SingleOrDefault(t => t.Airline.Code == airlineCode && t.Code == Class);

            if (q1 != null)
                return q1.Name;

            var q2 = context.TravelClassDefault.SingleOrDefault(t => t.Code == Class);
            return q2 == null ? "Economy Class" : q2.Name;
        }
    }

    public partial class TripLineAirPassenger {
        [NotMapped]
        public decimal Gross {
            get {
                return TicketedFare + NonCommissionable;
            }
        }

        [NotMapped]
        public decimal SupplierNet {
            get {
                return Gross - Commission;
            }
        }

        [NotMapped]
        public decimal SellingPrice {
            get {
                return Gross - Discount;
            }
        }

        [NotMapped]
        public decimal CommissionRate {
            get {
                return TicketedFare == 0 ? 0 : Commission / TicketedFare;
            }
        }

        [NotMapped]
        public decimal DiscountRate {
            get {
                return TicketedFare == 0 ? 0 : Discount / TicketedFare;
            }
        }

        [NotMapped]
        public decimal MarkupRate {
            get {
                return TicketedFare == 0 ? 0 : Markup / TicketedFare;
            }
        }

        [NotMapped]
        public decimal OverrideRate {
            get {
                return TicketedFare == 0 ? 0 : OverrideAmount / TicketedFare;
            }
        }

        [NotMapped]
        public decimal Yield {
            get {
                return SellingPrice - NonCommissionable + Discount + Markup == 0 ? 0 : (Commission - Discount + Markup) / (SellingPrice - NonCommissionable + Discount + Markup);
            }
        }

        [NotMapped]
        public string Routing {
            get {
                var airPassengerAirSegments = TripLineAirPassengerAirSegments.Select(t => t.TripLineAirSegment).OrderBy(t => t.SeqNo).ThenBy(t => t.Id).Select(row => new {
                    DepartureCityCode = row.DepartureCity.Code,
                    ArrivalCityCode = row.ArrivalCity.Code,
                    row.TripLineAir.DepartureDate,
                    row.TripLineAir.ArrivalDate
                }).ToList();

                var airSegments = new List<string>();
                string arrivalCityCode = null;

                foreach (var airPassengerAirSegment in airPassengerAirSegments) {
                    if (airPassengerAirSegment.DepartureCityCode != arrivalCityCode)
                        airSegments.Add(string.Format("{0}{1}", arrivalCityCode == null ? string.Empty : "/", airPassengerAirSegment.DepartureCityCode));

                    if (airPassengerAirSegment.DepartureDate == AppConstants.VoidDate)
                        airSegments.Add("/");

                    airSegments.Add(airPassengerAirSegment.ArrivalCityCode);
                    arrivalCityCode = airPassengerAirSegment.ArrivalCityCode;
                }

                return airSegments.All(t => t == "???") ? string.Empty : string.Join("/", airSegments.ToArray()).TrimEnd("/???");
            }
        }

        [NotMapped]
        public string TicketNoMain {
            get {
                return !string.IsNullOrEmpty(TicketNo) && TicketNo.IndexOf("/") > -1 ? TicketNo.Substring(0, TicketNo.IndexOf("/")) : string.IsNullOrEmpty(TicketNo) ? string.Empty : TicketNo;
            }
        }

        [NotMapped]
        public string TicketNoConjunction {
            get {
                return !string.IsNullOrEmpty(TicketNo) && TicketNo.IndexOf("/") > -1 ? TicketNo.Substring(TicketNo.IndexOf("/") + 1) : string.Empty;
            }
        }

        [NotMapped]
        public string OriginalTicketNoMain {
            get {
                return !string.IsNullOrEmpty(OriginalTicketNo) && OriginalTicketNo.IndexOf("/") > -1 ? OriginalTicketNo.Substring(0, OriginalTicketNo.IndexOf("/")) : string.IsNullOrEmpty(OriginalTicketNo) ? string.Empty : OriginalTicketNo;
            }
        }

        [NotMapped]
        public string OriginalTicketNoConjunction {
            get {
                return !string.IsNullOrEmpty(OriginalTicketNo) && OriginalTicketNo.IndexOf("/") > -1 ? OriginalTicketNo.Substring(OriginalTicketNo.IndexOf("/") + 1) : string.Empty;
            }
        }

        [NotMapped]
        public decimal DiscountApplicable {
            get {
                return FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard || IsCreditCardDiscountApplicable ? Discount : 0;
            }
        }

        [NotMapped]
        public decimal MarkupApplicable {
            get {
                return FormOfPayment.FormOfPaymentClass != FormOfPaymentClass.CreditCardTravelCard || IncludeMarkupInCreditCardPayment ? Markup : 0;
            }
        }

        public decimal GetTicketedFareNet(int customerId, DateTime dateApplicable, int[] passengerIds = null) {
            return TicketedFare - GetTicketedFareTax(customerId, dateApplicable, passengerIds);
        }

        public decimal GetTicketedFareTax(int customerId, DateTime dateApplicable, int[] passengerIds = null) {
            if (passengerIds?.Contains(PassengerId) != false && SaleType.IsTaxApplicable) {
                decimal taxRate = CustomerSettings.GetTaxRate(customerId, dateApplicable);
                return taxRate == 0 ? 0 : Math.Round(TicketedFare * taxRate / (1 + taxRate), 2);
            }
            else {
                return 0;
            }
        }

        public decimal GetCostToClient(int customerId) {
            return SellingPrice + Markup - (AppSettings.Setting(customerId).CostToClientIncludesNonComm ? 0 : NonCommissionable);
        }

        public decimal GetCostToClient(int customerId, int[] passengerIds = null) {
            return passengerIds?.Contains(PassengerId) != false ? GetCostToClient(customerId) : 0;
        }

        public decimal GetCostToClientNet(int customerId, DateTime dateApplicable, int[] passengerIds = null) {
            return GetCostToClient(customerId) - GetCostToClientTax(customerId, dateApplicable, passengerIds);
        }

        public decimal GetCostToClientTax(int customerId, DateTime dateApplicable, int[] passengerIds = null) {
            if (passengerIds?.Contains(PassengerId) != false && SaleType.IsTaxApplicable) {
                decimal taxRate = CustomerSettings.GetTaxRate(customerId, dateApplicable);
                decimal costToClient = GetCostToClient(customerId);
                return taxRate == 0 ? 0 : Math.Round(costToClient * taxRate / (1 + taxRate), 2);
            }
            else {
                return 0;
            }
        }

        public decimal GetPersonalTravelAmountTax(int customerId, DateTime dateApplicable) {
            if (SaleType.IsTaxApplicable) {
                decimal taxRate = CustomerSettings.GetTaxRate(customerId, dateApplicable);
                return taxRate == 0 ? 0 : Math.Round(PersonalTravelAmount * taxRate / (1 + taxRate), 2);
            }
            else {
                return 0;
            }
        }

        public decimal GetAmountInvoiceable(int customerId) {
            return GetCostToClient(customerId) - PersonalTravelAmount;
        }

        public decimal GetAmountInvoiceableDue(AppLazyContext lazyContext, int customerId, bool excludePayment = true) {
            return GetAmountInvoiceable(customerId) - GetAmountInvoiced(lazyContext, excludePayment);
        }

        public decimal GetAmountInvoiced(AppLazyContext lazyContext, bool excludePayment = true) {
            return lazyContext.InvoiceDetail.Where(t => t.TripLineAirPassengerId == Id && ((excludePayment && !t.IsPayment) || !excludePayment)).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)((t.Invoice.InvoiceType == InvoiceType.Invoice ? 1 : -1) * (t.Amount + t.Tax - t.Discount - t.DiscountTax + t.PaymentTax))) ?? 0;
        }

        public decimal GetAmountReceivable(int customerId) {
            return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard || TripLineAir.TripLine.Voucher.PaymentClass == PaymentClass.PaidDirect ? -Discount + Markup : GetCostToClient(customerId);
        }

        public decimal GetAmountReceivableDue(AppLazyContext lazyContext, int customerId) {
            return GetAmountReceivable(customerId) - GetAmountReceived(lazyContext);
        }

        public decimal GetAmountReceived(AppLazyContext lazyContext) {
            return (lazyContext.ReceiptDetail.Where(t => t.TripLineAirPassengerId == Id && t.Receipt.ReceiptType == ReceiptType.Receipt).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0)
                + (lazyContext.Bsp.Where(t1 => t1.TripLineId == TripLineAir.TripLineId).AsEnumerable().Where(t1 => t1.TripLine.IsBooking && t1.BspType != BspType.AgencyCC && t1.BspType != BspType.Conjunction && t1.BspType != BspType.Free && t1.BspType != BspType.Void && t1.BspDetails.Any(t2 => t2.TripLineAirPassengerId == Id && t2.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)).Sum(t1 => (decimal?)(t1.Sign * ((t1.IncludeMarkupInCreditCardPayment ? t1.Markup + t1.MarkupTax : 0) - (t1.IsCreditCardDiscountApplicable ? t1.Discount + t1.DiscountTax : 0)))) ?? 0)
                + (lazyContext.NonBsp.Where(t1 => t1.TripLineId == TripLineAir.TripLineId).AsEnumerable().Where(t1 => t1.TripLine.IsBooking && t1.NonBspType != NonBspType.AgencyCC && t1.NonBspDetails.Any(t2 => t2.TripLineAirPassengerId == Id && t2.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)).Sum(t1 => (decimal?)(t1.Sign * ((t1.IncludeMarkupInCreditCardPayment ? t1.Markup + t1.MarkupTax : 0) - (t1.IsCreditCardDiscountApplicable ? t1.Discount + t1.DiscountTax : 0)))) ?? 0)
                + (lazyContext.Payment.Where(t1 => t1.TripId == TripLineAir.TripLine.TripId).AsEnumerable().Where(t1 => t1.PaymentDetails.Any(t2 => t2.TripLine.IsBooking) && t1.PaymentType == PaymentType.SupplierPayment && t1.PaymentDetails.Any(t2 => t2.TripLineAirPassengerId == Id && t2.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)).Sum(t1 => (decimal?)((t1.IncludeMarkupInCreditCardPayment ? t1.Markup + t1.MarkupTax : 0) - (t1.IsCreditCardDiscountApplicable ? t1.Discount + t1.DiscountTax : 0))) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineAirPassengerId == Id && t.Payment.PaymentType == PaymentType.ClientRefund).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);
        }

        public decimal GetAmountPayable(int customerId) {
            return TripLineAir.TripLine.Voucher.PaymentClass == PaymentClass.PaidDirect ? 0 : GetCostToClient(customerId) + Discount - Markup;
        }

        public decimal GetAmountPayableDue(AppLazyContext lazyContext, int customerId) {
            return GetAmountPayable(customerId) - GetAmountPaid(lazyContext);
        }

        public decimal GetAmountPaid(AppLazyContext lazyContext) {
            return (lazyContext.BspDetail.Where(t => t.TripLineAirPassengerId == Id && t.Bsp.BspType != BspType.AgencyCC && t.Bsp.BspType != BspType.Conjunction && t.Bsp.BspType != BspType.Free && t.Bsp.BspType != BspType.Void).AsEnumerable().Where(t => t.Bsp.TripLine.IsBooking).Sum(t => (decimal?)(t.Bsp.BspType == BspType.Refund ? -1 : 1) * (t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + (lazyContext.NonBspDetail.Where(t => t.TripLineAirPassengerId == Id && t.NonBsp.NonBspType != NonBspType.AgencyCC).AsEnumerable().Where(t => t.NonBsp.TripLine.IsBooking).Sum(t => (decimal?)(t.NonBsp.NonBspType == NonBspType.Refund ? -1 : 1) * (t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineAirPassengerId == Id && t.Payment.PaymentType != PaymentType.ClientRefund && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.DebitType == DebitCreditType.Client && t.DebitTripLineId == TripLineId).AsEnumerable().Where(t => t.DebitTripLine.IsBooking).Sum(t => (decimal?)(-t.Amount - t.Tax)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.CreditType == DebitCreditType.Client && t.CreditTripLineId == TripLineId).AsEnumerable().Where(t => t.CreditTripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);
        }

        public decimal GetAmountPaidWithDiscountAndMarkup(AppLazyContext lazyContext) {
            return (lazyContext.BspDetail.Where(t => t.TripLineAirPassengerId == Id && t.Bsp.BspType != BspType.AgencyCC && t.Bsp.BspType != BspType.Conjunction && t.Bsp.BspType != BspType.Free && t.Bsp.BspType != BspType.Void).AsEnumerable().Where(t => t.Bsp.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionableGross - t.DiscountGrossProRata + t.MarkupGrossProRata)) ?? 0)
                + (lazyContext.NonBspDetail.Where(t => t.TripLineAirPassengerId == Id && t.NonBsp.NonBspType != NonBspType.AgencyCC).AsEnumerable().Where(t => t.NonBsp.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionableGross - t.DiscountGrossProRata + t.MarkupGrossProRata)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineAirPassengerId == Id && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionableGross - t.DiscountGrossProRata + t.MarkupGrossProRata)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.DebitType == DebitCreditType.Client && t.DebitTripLineId == TripLineId).AsEnumerable().Where(t => t.DebitTripLine.IsBooking).Sum(t => (decimal?)(-t.Amount - t.Tax)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.CreditType == DebitCreditType.Client && t.CreditTripLineId == TripLineId).AsEnumerable().Where(t => t.CreditTripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);
        }

        public decimal GetAmountPaidWithDiscountAndMarkupNet(AppLazyContext lazyContext) {
            return (lazyContext.BspDetail.Where(t => t.TripLineAirPassengerId == Id && t.Bsp.BspType != BspType.AgencyCC && t.Bsp.BspType != BspType.Conjunction && t.Bsp.BspType != BspType.Free && t.Bsp.BspType != BspType.Void).Where(t => t.Bsp.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.NonCommissionable - t.DiscountProRata + t.MarkupProRata)) ?? 0)
                + (lazyContext.NonBspDetail.Where(t => t.TripLineAirPassengerId == Id && t.NonBsp.NonBspType != NonBspType.AgencyCC).Where(t => t.NonBsp.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.NonCommissionable - t.DiscountProRata + t.MarkupProRata)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineAirPassengerId == Id && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.NonCommissionable - t.DiscountProRata + t.MarkupProRata)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.DebitType == DebitCreditType.Client && t.DebitTripLineId == TripLineId).AsEnumerable().Where(t => t.DebitTripLine.IsBooking).Sum(t => (decimal?)(-t.Amount - t.Tax)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.CreditType == DebitCreditType.Client && t.CreditTripLineId == TripLineId).AsEnumerable().Where(t => t.CreditTripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);
        }

        public decimal GetAmountPaidWithDiscountAndMarkupTax(AppLazyContext lazyContext) {
            return (lazyContext.BspDetail.Where(t => t.TripLineAirPassengerId == Id && t.Bsp.BspType != BspType.AgencyCC && t.Bsp.BspType != BspType.Conjunction && t.Bsp.BspType != BspType.Free && t.Bsp.BspType != BspType.Void).AsEnumerable().Where(t => t.Bsp.TripLine.IsBooking).Sum(t => (decimal?)(t.Tax + t.NonCommissionableTax - t.DiscountTaxProRata + t.MarkupTaxProRata)) ?? 0)
                + (lazyContext.NonBspDetail.Where(t => t.TripLineAirPassengerId == Id && t.NonBsp.NonBspType != NonBspType.AgencyCC).AsEnumerable().Where(t => t.NonBsp.TripLine.IsBooking).Sum(t => (decimal?)(t.Tax + t.NonCommissionableTax - t.DiscountTaxProRata + t.MarkupTaxProRata)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineAirPassengerId == Id && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).AsEnumerable().Where(t => t.TripLine.IsBooking).Sum(t => (decimal?)(t.Tax + t.NonCommissionableTax - t.DiscountTaxProRata + t.MarkupTaxProRata)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.DebitType == DebitCreditType.Client && t.DebitTripLineId == TripLineId).AsEnumerable().Where(t => t.DebitTripLine.IsBooking).Sum(t => (decimal?)(-t.Amount - t.Tax)) ?? 0)
                + (lazyContext.Adjustment.Where(t => t.CreditType == DebitCreditType.Client && t.CreditTripLineId == TripLineId).AsEnumerable().Where(t => t.CreditTripLine.IsBooking).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0);
        }

        public DateTime GetDatePaid(AppLazyContext lazyContext) {
            DateTime bspDate = lazyContext.BspDetail.Where(t => t.TripLineAirPassengerId == Id && t.Bsp.BspType != BspType.AgencyCC && t.Bsp.BspType != BspType.Conjunction && t.Bsp.BspType != BspType.Free && t.Bsp.BspType != BspType.Void).Max(t => (DateTime?)t.Bsp.DocumentDate) ?? DateTime.MinValue;
            DateTime nonBspDate = lazyContext.NonBspDetail.Where(t => t.TripLineAirPassengerId == Id && t.NonBsp.NonBspType != NonBspType.AgencyCC).Max(t => (DateTime?)t.NonBsp.DocumentDate) ?? DateTime.MinValue;
            DateTime paymentDate = lazyContext.PaymentDetail.Where(t => t.TripLineAirPassengerId == Id && t.Payment.PaymentType != PaymentType.BspReturn && t.Payment.PaymentType != PaymentType.NonBspReturn).Max(t => (DateTime?)t.Payment.DocumentDate) ?? DateTime.MinValue;
            DateTime adjustmentDate = lazyContext.Adjustment.Where(t => t.DebitTripLineId == Id || t.CreditTripLineId == Id).Max(t => (DateTime?)t.DocumentDate) ?? DateTime.MinValue;

            DateTime date = bspDate;

            if (nonBspDate > date)
                date = nonBspDate;

            if (paymentDate > date)
                date = paymentDate;

            if (adjustmentDate > date)
                date = adjustmentDate;

            return date;
        }

        public decimal GetOfferedFareDue(AppLazyContext lazyContext) {
            return OfferedFare - ((lazyContext.BspDetail.FirstOrDefault(t => t.TripLineAirPassengerId == Id)?.Bsp.OfferedFare ?? 0)
                + (lazyContext.NonBspDetail.FirstOrDefault(t => t.TripLineAirPassengerId == Id)?.NonBsp.OfferedFare ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineAirPassengerId == Id).Sum(t => (decimal?)t.OfferedFare) ?? 0));
        }

        public decimal GetNonCommissionableDue(AppLazyContext lazyContext) {
            return NonCommissionable - ((lazyContext.BspDetail.Where(t => t.TripLineAirPassengerId == Id).Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + (lazyContext.NonBspDetail.Where(t => t.TripLineAirPassengerId == Id).Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineAirPassengerId == Id).Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0));
        }

        public decimal GetCommissionDue(AppLazyContext lazyContext) {
            return Commission - ((lazyContext.BspDetail.Where(t => t.TripLineAirPassengerId == Id).Select(t => t.Bsp).Distinct().Sum(t => (decimal?)(t.Commission + t.CommissionTax)) ?? 0)
                + (lazyContext.NonBspDetail.Where(t => t.TripLineAirPassengerId == Id).Select(t => t.NonBsp).Distinct().Sum(t => (decimal?)(t.Commission + t.CommissionTax)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineAirPassengerId == Id).Select(t => t.Payment).Distinct().Sum(t => (decimal?)(t.Commission + t.CommissionTax)) ?? 0));
        }

        public decimal GetDiscountDue(AppLazyContext lazyContext) {
            return Discount - ((lazyContext.BspDetail.Where(t => t.TripLineAirPassengerId == Id).Select(t => t.Bsp).Distinct().Sum(t => (decimal?)(t.Discount + t.DiscountTax)) ?? 0)
                + (lazyContext.NonBspDetail.Where(t => t.TripLineAirPassengerId == Id).Select(t => t.NonBsp).Distinct().Sum(t => (decimal?)(t.Discount + t.DiscountTax)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineAirPassengerId == Id).Select(t => t.Payment).Distinct().Sum(t => (decimal?)(t.Discount + t.DiscountTax)) ?? 0));
        }

        public decimal GetMarkupDue(AppLazyContext lazyContext) {
            return Markup - ((lazyContext.BspDetail.Where(t => t.TripLineAirPassengerId == Id).Select(t => t.Bsp).Distinct().Sum(t => (decimal?)(t.Markup + t.MarkupTax)) ?? 0)
                + (lazyContext.NonBspDetail.Where(t => t.TripLineAirPassengerId == Id).Select(t => t.NonBsp).Distinct().Sum(t => (decimal?)(t.Markup + t.MarkupTax)) ?? 0)
                + (lazyContext.PaymentDetail.Where(t => t.TripLineAirPassengerId == Id).Select(t => t.Payment).Distinct().Sum(t => (decimal?)(t.Markup + t.MarkupTax)) ?? 0));
        }

        public string GetFormOfPaymentDetails(AppLazyContext lazyContext) {
            DateTime paymentDate = GetDatePaid(lazyContext);
            string formOfPaymentDetails = string.Format("{0}{1}", string.Format("{0}{1}", TicketNo.Length == 0 ? "Paid with " : string.Format("Ticket No {0}: Paid with ", TicketNo), FormOfPayment.Name), paymentDate == DateTime.MinValue ? string.Empty : string.Format(" on {0}", paymentDate.ToShortDateStringExt())).Replace("with Not Specified ", string.Empty).Replace("with  on", "on");

            if ((PaymentDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0)
                formOfPaymentDetails = formOfPaymentDetails.Replace("Paid", "Refunded");

            return formOfPaymentDetails;
        }

        public string GetTooltip(AppLazyContext lazyContext, int customerId) {
            return string.Format("<table class='tl-tooltip-table'><tr><td>Gross:</td><td style='text-align: right'>{0:c2}</td></tr><tr><td>Commission:</td><td style='text-align: right'>{1:c2}</td></tr><tr><td>Supplier Net:</td><td style='text-align: right'>{2:c2}</td></tr><tr><td>Selling Price:</td><td style='text-align: right'>{3:c2}</td<</tr><tr><td>Cost to Client:</td><td style='text-align: right'>{4:c2}</td></tr><tr><td>Non-Comm:</td><td style='text-align: right'>{5:c2}</td></tr><tr><td>CC Amount:</td><td style='text-align: right'>{6:c2}</td></tr><tr><td>CC Non-Comm:</td><td style='text-align: right'>{7:c2}</td></tr><tr><td>Amount Received:</td><td style='text-align: right'>{8:c2}</td></tr><tr><td>Amount Paid:</td><td style='text-align: right'>{9:c2}</td></tr></table>", Gross, Commission, SupplierNet, SellingPrice, GetCostToClient(customerId), NonCommissionable, CreditCardAmount, CreditCardNonCommissionable, GetAmountReceived(lazyContext), GetAmountPaid(lazyContext));
        }
    }

    public partial class TripLineAirPassengerAirSegment {
        public string GetClassDescription(AppMainContext context) {
            var q1 = context.AirlineClass.SingleOrDefault(t => t.AirlineId == TripLineAirPassenger.AirlineId && t.Code == TripLineAirSegment.Class);

            if (q1 != null)
                return q1.Name;

            var q2 = context.TravelClassDefault.SingleOrDefault(t => t.Code == TripLineAirSegment.Class);
            return q2 == null ? "Economy Class" : q2.Name;
        }

        public static SeatStatus GetSeatStatus(string code) {
            switch (code) {
                default:
                    return SeatStatus.NotSpecified;
                case "AK":
                case "BK":
                case "FS":
                case "GK":
                case "HK":
                case "HS":
                case "KK":
                case "NK":
                case "OK":
                case "PK":
                case "RR":
                case "SS":
                case "TK":
                    return SeatStatus.Confirmed;
                case "AN":
                case "BN":
                case "DS":
                case "GN":
                case "HA":
                case "HN":
                case "IN":
                case "IS":
                case "LK":
                case "MR":
                case "NN":
                case "RQ":
                case "TN":
                    return SeatStatus.OnRequest;
                case "AL":
                case "BL":
                case "DL":
                case "GL":
                case "HL":
                case "HW":
                case "KL":
                case "LL":
                case "ML":
                case "PA":
                case "PB":
                case "PC":
                case "PD":
                case "PL":
                case "PW":
                case "UU":
                case "TL":
                case "WL":
                    return SeatStatus.Waitlisted;
                case "HX":
                case "MN":
                case "UC":
                case "UN":
                case "US":
                    return SeatStatus.CannotConfirm;
                case "NS":
                    return SeatStatus.NoShow;
            }
        }

        public static void UpdateGroupNo(AppMainContext context, int tripLineId, int tripLineAirPassengerId) {
            var airPassengerAirSegments = context.TripLineAirPassengerAirSegment.Include(t => t.TripLineAirSegment).Include(t => t.TripLineAirPassenger).ThenInclude(t => t.TripLineAirPassengerAirSegments)
                .Where(t => t.TripLineAirSegment.TripLineId == tripLineId && t.TripLineAirPassengerId == tripLineAirPassengerId && t.TripLineAirSegment.DepartureDate != context.VoidDate).ToList();

            string fareBasis = string.Empty;
            decimal grossAmount = 0;
            int groupNo = 0;
            int skip = 0;

            var q = airPassengerAirSegments.Where(t => t.Amount + t.Tax != 0).OrderBy(t => t.FareBasis).ToList();

            foreach (var row in q) {
                skip++;

                if (fareBasis != row.FareBasis || grossAmount != row.Amount + row.Tax)
                    groupNo++;

                fareBasis = row.FareBasis;
                grossAmount = row.Amount + row.Tax;

                if (row.GroupNo != groupNo) {
                    row.GroupNo = groupNo;
                    context.Save(row, false);
                }

                if (q.Skip(skip).Any(t => t.FareBasis == fareBasis)) {
                    fareBasis = string.Empty;
                    grossAmount = 0;
                }
            }

            skip = -1;

            foreach (var row in airPassengerAirSegments) {
                skip++;

                if (row.GroupNo > 0)
                    continue;

                groupNo = airPassengerAirSegments.Skip(skip).FirstOrDefault(t => t.FareBasis == row.FareBasis && t.GroupNo > 0)?.GroupNo ?? 1;

                if (row.GroupNo != groupNo) {
                    row.GroupNo = groupNo;
                    context.Save(row, false);
                }
            }
        }
    }

    public partial class TripLineLand {
        [NotMapped]
        public decimal Gross {
            get {
                return GetValue("Gross");
            }
        }

        [NotMapped]
        public decimal Cost {
            get {
                return GetValue("Cost");
            }
        }

        [NotMapped]
        public decimal SupplierNet {
            get {
                return Gross - Commission;
            }
        }

        [NotMapped]
        public decimal SellingPrice {
            get {
                return Gross - Discount;
            }
        }

        [NotMapped]
        public decimal CommissionableValue {
            get {
                return Gross - NonCommissionable;
            }
        }

        [NotMapped]
        public decimal CommissionRate {
            get {
                return Gross - NonCommissionable == 0 ? 0 : Commission / (Gross - NonCommissionable);
            }
        }

        [NotMapped]
        public decimal DiscountRate {
            get {
                return Gross - NonCommissionable == 0 ? 0 : Discount / (Gross - NonCommissionable);
            }
        }

        [NotMapped]
        public decimal MarkupRate {
            get {
                return Gross - NonCommissionable == 0 ? 0 : Markup / (Gross - NonCommissionable);
            }
        }

        [NotMapped]
        public decimal Yield {
            get {
                return SellingPrice - NonCommissionable + Discount + Markup == 0 ? 0 : (Commission - Discount + Markup) / (SellingPrice - NonCommissionable + Discount + Markup);
            }
        }

        [NotMapped]
        public int PaxNo {
            get {
                return PaxAdultNo + PaxChildNo + PaxInfantNo;
            }
        }

        [NotMapped]
        public int PaxQty {
            get {
                return PaxAdultQty + PaxChildQty + PaxInfantQty;
            }
        }

        [NotMapped]
        public string SupplierContactFullName {
            get {
                return string.Concat(SupplierContactTitle, " ", SupplierContactName).Trim();
            }
        }

        [NotMapped]
        public string SupplierContactPhoneNo {
            get {
                return string.IsNullOrEmpty(SupplierContactMobile) ? string.IsNullOrEmpty(SupplierContactPhoneWork) ? SupplierContactPhoneHome : SupplierContactPhoneWork : SupplierContactMobile;
            }
        }

        public string GetStartAddress(AppMainContext context, bool useCountryCode = false) {
            string address = string.Empty;

            if (!string.IsNullOrEmpty(StartAddress1))
                address += string.Format("{0}{1}", StartAddress1, AppConstants.HtmlLineBreak);

            if (!string.IsNullOrEmpty(StartAddress2))
                address += string.Format("{0}{1}", StartAddress2, AppConstants.HtmlLineBreak);

            string country = string.Empty;

            if (!string.IsNullOrEmpty(StartCountryCode)) {
                if (useCountryCode) {
                    country = string.Concat(" ", StartCountryCode);
                }
                else {
                    country = string.Concat(AppConstants.HtmlLineBreak, Country.GetCountry(context, StartCountryCode).Name);
                }
            }

            address += Utils.RemoveExtraSpaces(string.Concat(StartLocality, " ", StartRegion, " ", StartPostCode, country));
            return address.TrimEnd(AppConstants.HtmlLineBreak);
        }

        public string GetEndAddress(AppMainContext context, bool useCountryCode = false) {
            string address = string.Empty;

            if (!string.IsNullOrEmpty(EndAddress1))
                address += string.Format("{0}{1}", EndAddress1, AppConstants.HtmlLineBreak);

            if (!string.IsNullOrEmpty(EndAddress2))
                address += string.Format("{0}{1}", EndAddress2, AppConstants.HtmlLineBreak);

            string country = string.Empty;

            if (!string.IsNullOrEmpty(EndCountryCode)) {
                if (useCountryCode) {
                    country = string.Concat(" ", EndCountryCode);
                }
                else {
                    country = string.Concat(AppConstants.HtmlLineBreak, Country.GetCountry(context, EndCountryCode).Name);
                }
            }

            address += Utils.RemoveExtraSpaces(string.Concat(EndLocality, " ", EndRegion, " ", EndPostCode, country));
            return address.TrimEnd(AppConstants.HtmlLineBreak);
        }

        public string GetSupplierAddress(AppMainContext context, bool useCountryCode = true) {
            string address = string.Empty;

            if (!string.IsNullOrEmpty(SupplierAddress1))
                address += string.Format("{0}{1}", SupplierAddress1, AppConstants.HtmlLineBreak);

            if (!string.IsNullOrEmpty(SupplierAddress2))
                address += string.Format("{0}{1}", SupplierAddress2, AppConstants.HtmlLineBreak);

            string country = string.Empty;

            if (!string.IsNullOrEmpty(SupplierCountryCode)) {
                if (useCountryCode) {
                    country = string.Concat(" ", SupplierCountryCode);
                }
                else {
                    country = string.Concat(AppConstants.HtmlLineBreak, Country.GetCountry(context, SupplierCountryCode).Name);
                }
            }

            address += Utils.RemoveExtraSpaces(string.Concat(SupplierLocality, " ", SupplierRegion, " ", SupplierPostCode, country));
            address = address.TrimEnd(AppConstants.HtmlLineBreak);

            if (!string.IsNullOrEmpty(address))
                return address;

            var supplierAddress = Supplier.SupplierAddresses.OrderBy(t => t.IsDefault ? 0 : 1).FirstOrDefault();

            if (supplierAddress == null)
                return string.Empty;

            if (!string.IsNullOrEmpty(supplierAddress.Address1))
                address += string.Format("{0}{1}", supplierAddress.Address1, AppConstants.HtmlLineBreak);

            if (!string.IsNullOrEmpty(supplierAddress.Address2))
                address += string.Format("{0}{1}", supplierAddress.Address2, AppConstants.HtmlLineBreak);

            country = string.Empty;

            if (!string.IsNullOrEmpty(supplierAddress.CountryCode)) {
                if (useCountryCode) {
                    country = string.Concat(" ", supplierAddress.CountryCode);
                }
                else {
                    country = string.Concat(AppConstants.HtmlLineBreak, Country.GetCountry(context, supplierAddress.CountryCode).Name);
                }
            }

            address += Utils.RemoveExtraSpaces(string.Concat(supplierAddress.Locality, " ", supplierAddress.Region, " ", supplierAddress.PostCode, country));
            return address.TrimEnd(AppConstants.HtmlLineBreak);
        }

        public decimal GetValue(string type) {
            decimal value = 0;

            int paxAdultNo = PaxAdultQty;
            int paxChildNo = PaxChildQty;
            int paxInfantNo = PaxInfantQty;

            if (ServiceTypeRateBasis.IsPaxNoApplicable) {
                paxAdultNo = PaxAdultNo;
                paxChildNo = PaxChildNo;
                paxInfantNo = PaxInfantNo;
            }

            decimal paxAdultRate = PaxAdultRate;
            decimal paxChildRate = PaxChildRate;
            decimal paxInfantRate = PaxInfantRate;

            if (type == "Cost") {
                paxAdultRate = RateCost;
                paxChildRate = RateCost;
                paxInfantRate = RateCost;
            }

            switch ((ServiceTypeRateBasisBase)ServiceTypeRateBasisId) {
                case ServiceTypeRateBasisBase.NotSpecified:
                case ServiceTypeRateBasisBase.AirPerPerson:
                case ServiceTypeRateBasisBase.AirPerDay:
                case ServiceTypeRateBasisBase.AccommodationPerPerson:
                case ServiceTypeRateBasisBase.TransportPerDay:
                case ServiceTypeRateBasisBase.CruisePerPerson:
                case ServiceTypeRateBasisBase.TourPerDay:
                case ServiceTypeRateBasisBase.OtherLandPerPerson:
                case ServiceTypeRateBasisBase.OtherLandPerService:
                case ServiceTypeRateBasisBase.InsurancePerPerson:
                case ServiceTypeRateBasisBase.InsurancePerDay:
                    value = Math.Round((paxAdultNo * paxAdultRate + (PassengerClassification == PassengerClassification.Group ? 0 : paxChildNo * paxChildRate + paxInfantNo * paxInfantRate)) * PayForDuration, 2);
                    break;
                case ServiceTypeRateBasisBase.AccommodationPerRoom:
                    value = Math.Round(paxAdultNo * paxAdultRate * PayForDuration, 2);
                    break;
                case ServiceTypeRateBasisBase.AirPackage:
                case ServiceTypeRateBasisBase.AccommodationPackage:
                case ServiceTypeRateBasisBase.TransportPackage:
                case ServiceTypeRateBasisBase.CruisePerCruise:
                case ServiceTypeRateBasisBase.TourPerTour:
                case ServiceTypeRateBasisBase.OtherLandPackage:
                case ServiceTypeRateBasisBase.InsurancePackage:
                    value = Math.Round(paxAdultNo * paxAdultRate + (PassengerClassification == PassengerClassification.Group ? 0 : paxChildNo * paxChildRate + paxInfantNo * paxInfantRate), 2);
                    break;
            }

            if (type == "Gross") {
                value += NonCommissionable;
            }
            else if (type == "Cost" && ExchangeRate != 0) {
                value /= ExchangeRate;
            }

            return value;
        }

        public int GetDuration() {
            int duration = 1;

            if (StartDate > DateTime.MinValue && EndDate > DateTime.MinValue && StartDate <= EndDate)
                duration = (EndDate - StartDate).Days + (DurationCoverageType == DurationCoverageType.Days ? 1 : (TripLine.TripLineType == TripLineType.Transport ? 1 : 0));

            if (duration <= 0)
                duration = 1;

            if (TripLine.TripLineType == TripLineType.Transport && duration > 1)
                duration -= 1;

            return duration;
        }

        public string GetServiceTypeRateBasisDescription(int customerId, bool includeDiscount = false, bool personalAmountOnly = false, bool isHtml = true, IssuedDocumentType issuedDocumentType = IssuedDocumentType.None) {
            var serviceTypeRateBasis = (ServiceTypeRateBasisBase)ServiceTypeRateBasisId;

            string lineSpace;
            string lineBreak;

            if (isHtml) {
                lineSpace = AppConstants.HtmlSpace;
                lineBreak = AppConstants.HtmlLineBreak;
            }
            else {
                lineSpace = " ";
                lineBreak = Environment.NewLine;
            }

            decimal costToClient;
            decimal markup = 0;

            if (personalAmountOnly) {
                costToClient = TripLine.PersonalTravelAmount;
            }
            else {
                bool costToClientIncludesNonComm = AppSettings.Setting(customerId).CostToClientIncludesNonComm;
                costToClient = GetCostToClient(customerId);

                if ((issuedDocumentType != IssuedDocumentType.Quote && DiscountReasonId > 0 && AppSettings.Setting(customerId).AgentCommissionDiscountReasonId == DiscountReasonId) || !includeDiscount)
                    costToClient += Discount;

                markup = Markup - (costToClientIncludesNonComm ? 0 : NonCommissionable);
            }

            switch (serviceTypeRateBasis) {
                case ServiceTypeRateBasisBase.NotSpecified:
                case ServiceTypeRateBasisBase.AccommodationPerPerson:
                case ServiceTypeRateBasisBase.AccommodationPerRoom:
                case ServiceTypeRateBasisBase.TransportPerDay:
                case ServiceTypeRateBasisBase.CruisePerPerson:
                case ServiceTypeRateBasisBase.TourPerDay:
                case ServiceTypeRateBasisBase.OtherLandPerPerson:
                case ServiceTypeRateBasisBase.OtherLandPerService:
                    markup /= PayForDuration == 0 ? 1 : PayForDuration;
                    break;
            }

            int paxAdultNo = PaxAdultNo;
            int paxChildNo = PaxChildNo;
            int paxInfantNo = PaxInfantNo;

            if (!ServiceTypeRateBasis.IsPaxNoApplicable) {
                paxAdultNo = PaxAdultQty;
                paxChildNo = PaxChildQty;
                paxInfantNo = PaxInfantQty;
            }

            decimal paxAdultRate = PaxAdultRate;
            decimal paxChildRate = PaxChildRate;
            decimal paxInfantRate = PaxInfantRate;

            if (PassengerClassification == PassengerClassification.Group) {
                decimal paxRatio = paxAdultNo == 0 ? 0 : 1m / paxAdultNo;
                paxAdultRate += markup * paxRatio;
            }
            else {
                decimal paxRatio = paxAdultNo + paxChildNo + paxInfantNo == 0 ? 0 : 1m / (paxAdultNo + paxChildNo + paxInfantNo);
                paxAdultRate += markup * paxRatio;
                paxChildRate += markup * paxRatio;
                paxInfantRate += markup * paxRatio;
            }

            paxAdultRate = Math.Round(paxAdultRate, 2);
            paxChildRate = Math.Round(paxChildRate, 2);
            paxInfantRate = Math.Round(paxInfantRate, 2);

            string unitOfService;

            switch (serviceTypeRateBasis) {
                default:
                    unitOfService = SupplierService.UnitOfService.Length == 0 ? string.Empty : string.Format("{0}(s)", SupplierService.UnitOfService);
                    unitOfService = unitOfService.Replace("(s)(s)", "(s)");

                    if (unitOfService.Length == 0) {
                        switch (serviceTypeRateBasis) {
                            case ServiceTypeRateBasisBase.AccommodationPerRoom:
                                if (PassengerClassification == PassengerClassification.Group)
                                    unitOfService = "Room(s)";

                                break;
                            case ServiceTypeRateBasisBase.AccommodationPerPerson:
                            case ServiceTypeRateBasisBase.AccommodationPackage:
                                unitOfService = string.Empty;
                                break;
                            case ServiceTypeRateBasisBase.TransportPerDay:
                            case ServiceTypeRateBasisBase.TransportPackage:
                                unitOfService = "Vehicle(s)";
                                break;
                            case ServiceTypeRateBasisBase.CruisePerPerson:
                            case ServiceTypeRateBasisBase.CruisePerCruise:
                                if (PassengerClassification == PassengerClassification.Group)
                                    unitOfService = "Cruise(s)";

                                break;
                            case ServiceTypeRateBasisBase.TourPerDay:
                            case ServiceTypeRateBasisBase.TourPerTour:
                                if (PassengerClassification == PassengerClassification.Group)
                                    unitOfService = "Tour(s)";

                                break;
                            case ServiceTypeRateBasisBase.OtherLandPerPerson:
                            case ServiceTypeRateBasisBase.OtherLandPackage:
                                if (PassengerClassification == PassengerClassification.Group)
                                    unitOfService = "Person(s)";

                                break;
                            case ServiceTypeRateBasisBase.OtherLandPerService:
                                if (PassengerClassification == PassengerClassification.Group)
                                    unitOfService = "Group(s)";

                                break;
                        }
                    }

                    break;
                case ServiceTypeRateBasisBase.AccommodationPerPerson:
                case ServiceTypeRateBasisBase.AccommodationPackage:
                    unitOfService = string.Empty;
                    break;
            }

            switch (serviceTypeRateBasis) {
                case ServiceTypeRateBasisBase.CruisePerPerson:
                case ServiceTypeRateBasisBase.CruisePerCruise:
                case ServiceTypeRateBasisBase.TourPerDay:
                case ServiceTypeRateBasisBase.TourPerTour:
                case ServiceTypeRateBasisBase.OtherLandPerPerson:
                case ServiceTypeRateBasisBase.OtherLandPerService:
                case ServiceTypeRateBasisBase.OtherLandPackage:
                    if (PassengerClassification == PassengerClassification.Individual)
                        unitOfService = string.Empty;

                    break;
            }

            string serviceCharged = SupplierService.ServiceCharged.Length == 0 ? string.Empty : string.Format("{0}(s)", SupplierService.ServiceCharged);

            if (serviceCharged.Length == 0) {
                switch (serviceTypeRateBasis) {
                    default:
                        serviceCharged = DurationCoverageType.GetEnumDescription();
                        break;
                    case ServiceTypeRateBasisBase.OtherLandPerPerson:
                    case ServiceTypeRateBasisBase.OtherLandPackage:
                    case ServiceTypeRateBasisBase.OtherLandPerService:
                        serviceCharged = "Service(s)";
                        break;
                }
            }

            string description = GetServiceTypeRateBasisDescription(serviceTypeRateBasis, unitOfService, serviceCharged, paxAdultNo, paxAdultRate, paxChildNo, paxChildRate, paxInfantNo, paxInfantRate, personalAmountOnly, isHtml);

            if (TripLine.TripLineType == TripLineType.Cruise && issuedDocumentType == IssuedDocumentType.Quote) {
                description = string.Format("{0}{1}", description, TripLine.TripLineLand.NonCommissionable == 0 ? string.Empty : string.Format("{0}Port Charges and Govt Taxes: {1:c2}", paxAdultNo > 0 && paxChildNo > 0 && paxInfantNo > 0 ? lineBreak : string.Format("{0}{0}{0}{0}{0}", lineSpace), TripLine.TripLineLand.NonCommissionable));

                return string.Format("{0}{1}Total: {2:c2}", description.TrimStart(string.Format("{0}{0}{0}{0}{0}", lineSpace)), lineBreak, costToClient);
            }

            return string.Format("{0}{1}{1}{1}{1}{1}Total: {2:c2}", description.TrimStart(string.Format("{0}{0}{0}{0}{0}", lineSpace)), lineSpace, costToClient);
        }

        private string GetServiceTypeRateBasisDescription(ServiceTypeRateBasisBase serviceTypeRateBasis, string unitOfService, string serviceCharged, int paxAdultNo, decimal paxAdultRate, int paxChildNo, decimal paxChildRate, int paxInfantNo, decimal paxInfantRate, bool personalAmountOnly, bool isHtml) {
            string lineSpace;

            if (isHtml) {
                lineSpace = AppConstants.HtmlSpace;
            }
            else {
                lineSpace = " ";
            }

            string description = string.Empty;

            if (unitOfService.Length == 0) {
                if (paxAdultNo == 1) {
                    unitOfService = "Person";
                }
                else {
                    unitOfService = "Persons";
                }
            }
            else if (PassengerClassification == PassengerClassification.Group && serviceTypeRateBasis == ServiceTypeRateBasisBase.CruisePerCruise) {
                unitOfService = paxAdultNo == 1 ? "Group" : "Groups";
            }
            else {
                unitOfService = paxAdultNo == 1 ? unitOfService.Replace("(s)", string.Empty) : unitOfService.Replace("(s)", "s");
            }

            switch (serviceTypeRateBasis) {
                default:
                    serviceCharged = string.Format("for {0} {1}", PayForDuration, PayForDuration == 1 ? serviceCharged.Replace("(s)", string.Empty) : serviceCharged.Replace("(s)", "s"));
                    break;
                case ServiceTypeRateBasisBase.AccommodationPerPerson:
                case ServiceTypeRateBasisBase.AccommodationPerRoom:
                case ServiceTypeRateBasisBase.TransportPerDay:
                case ServiceTypeRateBasisBase.CruisePerPerson:
                case ServiceTypeRateBasisBase.TourPerDay:
                case ServiceTypeRateBasisBase.OtherLandPerPerson:
                case ServiceTypeRateBasisBase.OtherLandPerService:
                    serviceCharged = string.Format("per {0} for {1} {2}", serviceCharged.Replace("(s)", string.Empty), PayForDuration, PayForDuration == 1 ? serviceCharged.Replace("(s)", string.Empty) : serviceCharged.Replace("(s)", "s"));
                    break;
                case ServiceTypeRateBasisBase.AccommodationPackage:
                case ServiceTypeRateBasisBase.TransportPackage:
                case ServiceTypeRateBasisBase.CruisePerCruise:
                case ServiceTypeRateBasisBase.TourPerTour:
                case ServiceTypeRateBasisBase.OtherLandPackage:
                    serviceCharged = string.Format(", {0} {1} Package", PayForDuration, serviceCharged.Replace("(s)", string.Empty));
                    break;
            }

            if (PassengerClassification == PassengerClassification.Group || TripLine.TripLineType == TripLineType.Transport) {
                if (personalAmountOnly) {
                    description = string.Format("{0} {1} {2}{3}", paxAdultNo, unitOfService, paxAdultNo == 1 ? string.Empty : "each ", serviceCharged);
                }
                else {
                    description = string.Format("{0} {1} @ {2:c2} {3}{4}", paxAdultNo, unitOfService, paxAdultRate, paxAdultNo == 1 ? string.Empty : "each ", serviceCharged);
                }
            }
            else {
                if (paxAdultNo > 0) {
                    if (personalAmountOnly) {
                        description = string.Format("{0} {1} {2}{3}", paxAdultNo, paxAdultNo == 1 ? "Adult" : "Adults", paxAdultNo == 1 ? string.Empty : "each ", serviceCharged);
                    }
                    else {
                        description = string.Format("{0} {1} @ {2:c2} {3}{4}", paxAdultNo, paxAdultNo == 1 ? "Adult" : "Adults", paxAdultRate, paxAdultNo == 1 ? string.Empty : "each ", serviceCharged);
                    }
                }

                if (paxChildNo > 0) {
                    bool padStart = true;

                    if (!string.IsNullOrEmpty(description)) {
                        padStart = false;
                        description = description.TrimEnd(string.Format(" {0}", serviceCharged));
                    }

                    if (personalAmountOnly) {
                        description += string.Format((padStart ? string.Empty : "{0}") + "{1} {2} {3}{4}", padStart ? lineSpace : ", ", paxChildNo, paxChildNo == 1 ? "Child" : "Children", paxChildNo == 1 ? string.Empty : "each ", serviceCharged);
                    }
                    else {
                        description += string.Format((padStart ? string.Empty : "{0}") + "{1} {2} @ {3:c2} {4}{5}", padStart ? lineSpace : ", ", paxChildNo, paxChildNo == 1 ? "Child" : "Children", paxChildRate, paxChildNo == 1 ? string.Empty : "each ", serviceCharged);
                    }
                }

                if (paxInfantNo > 0) {
                    bool padStart = true;

                    if (!string.IsNullOrEmpty(description)) {
                        padStart = false;
                        description = description.TrimEnd(string.Format(" {0}", serviceCharged));
                    }

                    if (personalAmountOnly) {
                        description += string.Format((padStart ? string.Empty : "{0}") + "{1} {2} {3}{4}", padStart ? lineSpace : ", ", paxInfantNo, paxInfantNo == 1 ? "Infant" : "Infants", paxInfantNo == 1 ? string.Empty : "each ", serviceCharged);
                    }
                    else {
                        description += string.Format((padStart ? string.Empty : "{0}") + "{1} {2} @ {3:c2} {4}{5}", padStart ? lineSpace : ", ", paxInfantNo, paxInfantNo == 1 ? "Infant" : "Infants", paxInfantRate, paxInfantNo == 1 ? string.Empty : "each ", serviceCharged);
                    }
                }
            }


            if (serviceTypeRateBasis == ServiceTypeRateBasisBase.CruisePerCruise || serviceTypeRateBasis == ServiceTypeRateBasisBase.CruisePerPerson)
                description = description.Replace("Package", "Cruise").Replace("per Day", "per Cruise").Replace("per Night", "per Cruise");

            return description.Replace(" ,", ",");
        }

        public decimal GetCostToClient(int customerId) {
            return SellingPrice + Markup - (AppSettings.Setting(customerId).CostToClientIncludesNonComm ? 0 : NonCommissionable);
        }

        public decimal GetCommissionRate() {
            if (SupplierServiceRateDetailId > 0) {
                return SupplierServiceRateDetail.GetCommissionRate(this);
            }
            else if (Supplier?.CommissionRate > 0) {
                return Supplier.CommissionRate;
            }
            else if (Creditor?.CommissionRate > 0) {
                return Creditor.CommissionRate;
            }
            else if (SaleType?.CommissionRate > 0) {
                return SaleType.CommissionRate;
            }

            return 0;
        }

        public bool UpdatePassengerCount(AppMainContext context) {
            if (!ServiceTypeRateBasis.IsPaxNoApplicable)
                return false;

            var passengers = TripLine.Trip.TripPassengers;

            int childCount = passengers.Count(t => t.PassengerType == PassengerType.Child);
            int infantCount = passengers.Count(t => t.PassengerType == PassengerType.Infant);
            int adultCount = passengers.Count - childCount - infantCount;

            if (adultCount < 0)
                adultCount = 0;

            PaxAdultNo = adultCount;

            if (PassengerClassification == PassengerClassification.Group) {
                PaxChildNo = 0;
                PaxInfantNo = 0;
            }
            else {
                PaxChildNo = childCount;
                PaxInfantNo = infantCount;
            }

            bool result = context.Save(this);

            if (result) {
                TripLine.PaxNo = TripLine.GetPaxNo();
                context.Save(TripLine);
            }

            return result;
        }
    }

    public partial class TripLineInsurance {
        [NotMapped]
        public decimal Gross {
            get {
                return PolicyValue - AmountAlreadyPaid + TotalSurcharge;
            }
        }

        [NotMapped]
        public decimal SupplierNet {
            get {
                return Gross - Commission;
            }
        }

        [NotMapped]
        public decimal SellingPrice {
            get {
                return Gross - Discount;
            }
        }

        [NotMapped]
        public decimal CommissionRate {
            get {
                return Gross - TotalNonCommissionableSurcharge == 0 ? 0 : Commission / (Gross - TotalNonCommissionableSurcharge);
            }
        }

        [NotMapped]
        public decimal DiscountRate {
            get {
                return Gross - TotalNonCommissionableSurcharge == 0 ? 0 : Discount / (Gross - TotalNonCommissionableSurcharge);
            }
        }

        [NotMapped]
        public decimal MarkupRate {
            get {
                return Gross - TotalNonCommissionableSurcharge == 0 ? 0 : Markup / (Gross - TotalNonCommissionableSurcharge);
            }
        }

        [NotMapped]
        public decimal Yield {
            get {
                return SellingPrice + Discount + Markup == 0 ? 0 : (Commission - Discount + Markup) / (SellingPrice + Discount + Markup);
            }
        }

        [NotMapped]
        public decimal TotalCommissionableSurcharge {
            get {
                return TripLineInsuranceSurcharges.Where(t => t.IsCommissionable).Sum(t => (decimal?)t.Amount) ?? 0;
            }
        }

        [NotMapped]
        public decimal TotalNonCommissionableSurcharge {
            get {
                return TripLineInsuranceSurcharges.Where(t => !t.IsCommissionable).Sum(t => (decimal?)t.Amount) ?? 0;
            }
        }

        [NotMapped]
        public decimal TotalSurcharge {
            get {
                return TripLineInsuranceSurcharges.Sum(t => (decimal?)t.Amount) ?? 0;
            }
        }

        [NotMapped]
        public int Duration {
            get {
                return (EndDate - StartDate).Days + 1;
            }
        }

        [NotMapped]
        public int DurationWeeks {
            get {
                return (int)Math.Floor((decimal)Duration / 7);
            }
        }

        [NotMapped]
        public int DurationDays {
            get {
                return Duration - (int)Math.Floor((decimal)Duration / 7) * 7;
            }
        }

        [NotMapped]
        public int PaxNo {
            get {
                return TripLineInsurancePassengers.Count;
            }
        }

        public decimal GetCostToClient(int customerId) {
            return SellingPrice + Markup - (AppSettings.Setting(customerId).CostToClientIncludesNonComm ? 0 : TotalNonCommissionableSurcharge);
        }

        public decimal GetCommissionRate() {
            if (Supplier?.CommissionRate > 0) {
                return Supplier.CommissionRate;
            }
            else if (Creditor?.CommissionRate > 0) {
                return Creditor.CommissionRate;
            }
            else if (SaleType?.CommissionRate > 0) {
                return SaleType.CommissionRate;
            }

            return 0;
        }
    }

    public partial class TripLineForeignCurrency {
        [NotMapped]
        public decimal Gross {
            get {
                return EquivalentValue + ClientFee;
            }
        }

        [NotMapped]
        public decimal SupplierNet {
            get {
                return EquivalentValue + BankFee;
            }
        }

        [NotMapped]
        public decimal SellingPrice {
            get {
                return Gross;
            }
        }

        [NotMapped]
        public decimal CostToClient {
            get {
                return Gross + Markup;
            }
        }

        [NotMapped]
        public decimal EquivalentValue {
            get {
                return ExchangeRate == 0 ? 0 : ForeignAmount / ExchangeRate;
            }
        }

        [NotMapped]
        public decimal ClientFeeRate {
            get {
                return EquivalentValue == 0 ? 0 : ClientFee / EquivalentValue;
            }
        }

        [NotMapped]
        public decimal BankFeeRate {
            get {
                return EquivalentValue == 0 ? 0 : BankFee / EquivalentValue;
            }
        }

        [NotMapped]
        public decimal MarkupRate {
            get {
                return EquivalentValue == 0 ? 0 : Markup / EquivalentValue;
            }
        }

        [NotMapped]
        public decimal Yield {
            get {
                return SellingPrice + Markup == 0 ? 0 : (Commission + Markup) / (SellingPrice + Markup);
            }
        }

        [NotMapped]
        public decimal Commission {
            get {
                return ClientFee - BankFee;
            }
        }

        [NotMapped]
        public decimal CommissionRate {
            get {
                return EquivalentValue == 0 ? 0 : Commission / EquivalentValue;
            }
        }
    }

    public partial class TripLineServiceFee {
        [NotMapped]
        public decimal Gross {
            get {
                return PaxNo * ItemCost;
            }
        }

        [NotMapped]
        public decimal SupplierNet {
            get {
                return Gross - Commission;
            }
        }

        [NotMapped]
        public decimal SellingPrice {
            get {
                return Gross;
            }
        }

        [NotMapped]
        public decimal CostToClient {
            get {
                return SellingPrice + Markup;
            }
        }

        [NotMapped]
        public decimal CommissionRate {
            get {
                return Gross == 0 ? 0 : Commission / Gross;
            }
        }

        [NotMapped]
        public decimal MarkupRate {
            get {
                return Gross == 0 ? 0 : Markup / Gross;
            }
        }

        [NotMapped]
        public decimal Yield {
            get {
                return SellingPrice + Markup == 0 ? 0 : (Commission + Markup) / (SellingPrice + Markup);
            }
        }

        public decimal GetCommissionRate() {
            if (ServiceFeePaymentType == ServiceFeePaymentType.Agency)
                return 100;

            if (Supplier?.CommissionRate > 0) {
                return Supplier.CommissionRate;
            }
            else if (Creditor?.CommissionRate > 0) {
                return Creditor.CommissionRate;
            }
            else if (SaleType?.CommissionRate > 0) {
                return SaleType.CommissionRate;
            }

            return 0;
        }
    }

    public partial class TripLineOtherInclusion {
        [NotMapped]
        public decimal Gross {
            get {
                return PaxNo * ItemCost;
            }
        }

        [NotMapped]
        public decimal SupplierNet {
            get {
                return Gross - Commission;
            }
        }

        [NotMapped]
        public decimal SellingPrice {
            get {
                return Gross - Discount;
            }
        }

        [NotMapped]
        public decimal CostToClient {
            get {
                return SellingPrice + Markup;
            }
        }

        [NotMapped]
        public decimal CommissionRate {
            get {
                return Gross == 0 ? 0 : Commission / Gross;
            }
        }

        [NotMapped]
        public decimal DiscountRate {
            get {
                return Gross == 0 ? 0 : Discount / Gross;
            }
        }

        [NotMapped]
        public decimal MarkupRate {
            get {
                return Gross == 0 ? 0 : Markup / Gross;
            }
        }

        [NotMapped]
        public decimal Yield {
            get {
                return SellingPrice + Discount + Markup == 0 ? 0 : (Commission - Discount + Markup) / (SellingPrice + Discount + Markup);
            }
        }

        public decimal GetCommissionRate() {
            if (Supplier?.CommissionRate > 0) {
                return Supplier.CommissionRate;
            }
            else if (Creditor?.CommissionRate > 0) {
                return Creditor.CommissionRate;
            }
            else if (SaleType?.CommissionRate > 0) {
                return SaleType.CommissionRate;
            }

            return 0;
        }
    }

    public partial class Passenger {
        [NotMapped]
        public string FullName {
            get {
                return (Title + " " + FirstName + " " + LastName).Trim();
            }
        }

        [NotMapped]
        public string FullNameWithEmail {
            get {
                return string.IsNullOrEmpty(Email) ? FullName : string.Concat(@"<a href=""mailto:", WebUtility.HtmlEncode(Email), @""">", FullName, "</a>");
            }
        }

        [NotMapped]
        public bool IsLeadPassenger {
            get {
                if (Trip != null && Title.ToLower() == Trip.Title.ToLower() && FirstName.ToLower() == Trip.FirstName.ToLower() && LastName.ToLower() == Trip.LastName.ToLower() && PhoneNo.Replace(" ", string.Empty).ToLower() == Trip.Mobile.Replace(" ", string.Empty).ToLower() && Email.ToLower() == Trip.Email.ToLower())
                    return true;

                return Trip != null && FirstName.ToLower() == Trip.FirstName.ToLower() && LastName.ToLower() == Trip.LastName.ToLower();
            }
        }

        public int GetAge() {
            if (BirthDate == DateTime.MinValue)
                return Age;

            if (PassengerType == PassengerType.Infant) {
                int days = (DateTime.Today - BirthDate).Days;

                if (days < 365 * 2) {
                    return (int)Math.Ceiling((decimal)days / 30);
                }
                else {
                    PassengerType = GetPassengerType();
                }
            }

            return DateTime.Today.Year - BirthDate.Year;
        }

        public static int GetAge(DateTime birthDate, DateTime dateApplicable) {
            if (birthDate == DateTime.MinValue)
                return 0;

            int age = dateApplicable.Year - birthDate.Year;

            if (birthDate > dateApplicable.AddYears(-age))
                age--;

            return age;
        }

        public PassengerType GetPassengerType() {
            return GetPassengerType(BirthDate, DateTime.Today);
        }

        public static PassengerType GetPassengerType(DateTime birthDate, DateTime dateApplicable) {
            if (birthDate == DateTime.MinValue || dateApplicable < birthDate)
                return PassengerType.NotSpecified;

            int days = (dateApplicable - birthDate).Days;

            if (days < 365 * 2) {
                return PassengerType.Infant;
            }
            else if (days < 365 * 12) {
                return PassengerType.Child;
            }
            else if (days >= 365 * 65) {
                return PassengerType.Senior;
            }

            return PassengerType.Adult;
        }

        public static PassengerType GetPassengerType(string value) {
            switch (value) {
                default:
                    return PassengerType.NotSpecified;
                case "ADD":
                case "ADR":
                case "ADT":
                    return PassengerType.Adult;
                case "SCF":
                case "SCM":
                case "SRC":
                    return PassengerType.Senior;
                case "STU":
                    return PassengerType.Student;
                case "YSB":
                case "YTH":
                case "YTR":
                case "ZYC":
                case "ZZS":
                    return PassengerType.Youth;
                case "C03":
                case "C04":
                case "C05":
                case "C06":
                case "C07":
                case "C08":
                case "C09":
                case "C10":
                case "C11":
                case "C12":
                case "CHD":
                case "UNN":
                    return PassengerType.Child;
                case "I00":
                case "I01":
                case "I02":
                case "INF":
                case "INS":
                    return PassengerType.Infant;
            }
        }

        public bool IsDuplicate(Passenger passenger) {
            return passenger == null ? false : ProfileId == passenger.ProfileId && TripId == passenger.TripId && Title.ToLower() == passenger.Title.ToLower() && FirstName.ToLower() == passenger.FirstName.ToLower() && LastName.ToLower() == passenger.LastName.ToLower() && PhoneNo.ToLower() == passenger.PhoneNo.ToLower() && Email.ToLower() == passenger.Email.ToLower() && Alias.ToLower() == passenger.Alias.ToLower() && DisplayName.ToLower() == passenger.DisplayName.ToLower() && BirthDate == passenger.BirthDate && Age == passenger.Age && Gender == passenger.Gender;
        }

        public bool IsDuplicate(int profileId, int tripId, string title, string firstName, string lastName, string phoneNo, string email, string alias, string displayName, DateTime birthDate, int age, Gender gender) {
            return ProfileId == profileId && TripId == tripId && Title.ToLower() == title.ToStringExt().ToLower() && FirstName.ToLower() == firstName.ToStringExt().ToLower() && LastName.ToLower() == lastName.ToStringExt().ToLower() && PhoneNo.ToLower() == phoneNo.ToStringExt().ToLower() && Email.ToLower() == email.ToStringExt().ToLower() && Alias.ToLower() == alias.ToStringExt().ToLower() && DisplayName.ToLower() == displayName.ToStringExt().ToLower() && BirthDate == birthDate && Age == age && Gender == gender;
        }

        public static IEnumerable<Passenger> OrderByExpression(IEnumerable<Passenger> source) {
            return source.OrderBy(t => t.SeqNo).ThenBy(t => t.Trip.FirstName.ToLower() == t.FirstName.ToLower() && t.Trip.LastName.ToLower() == t.LastName.ToLower() ? 0 : t.PassengerType == PassengerType.Infant ? 3 : t.PassengerType == PassengerType.Child ? 2 : 1);
        }
    }

    public class ClientLedger {
        public int TripId { get; set; }
        public string TripNo { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DepartureDate { get; set; }
        public Consultant Consultant { get; set; }
        public Agency Agency { get; set; }
        public Agent Agent { get; set; }
        public Source Source { get; set; }
        public Category Category { get; set; }
        public Class Class { get; set; }
        public Destination Destination { get; set; }
        public Group Group { get; set; }
        public Location Location { get; set; }
        public Debtor Debtor { get; set; }
        public decimal Debit { get; set; }
        public decimal Credit { get; set; }
        public decimal Balance { get; set; }

        public List<TransactionDetail> TransactionDetail { get; set; }

        public ClientLedger(IQueryable<TransactionDetail> transactionDetail, LedgerDocumentType documentType) {
            if (documentType == LedgerDocumentType.Standard || documentType == LedgerDocumentType.Reconciliation)
                return;

            TransactionDetail = transactionDetail.OrderByDescending(t => t.Transaction.DocumentDate).ThenByDescending(t => t.Transaction.DocumentNo).ToList();
            decimal balance = 0;

            foreach (var row in TransactionDetail) {
                row.Balance = balance += row.Amount + row.Tax;
            }
        }
    }

    public class TripLineInformation {
        public int TripLineId { get; set; }
        public int TripId { get; set; }
        public TripLineType TripLineType { get; set; }
        public ClientAccountType ClientAccountType { get; set; }
        public Voucher Voucher { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Creditors { get; set; }
        public string Description { get; set; }
        public string ReceiptInfo { get; set; }
        public string PaymentInfo { get; set; }
        public string InvoiceInfo { get; set; }
        public int PaxNo { get; set; }
        public int PackageNo { get; set; }
        public decimal Commission { get; set; }
        public decimal Discount { get; set; }
        public decimal Markup { get; set; }
        public decimal Gross { get; set; }
        public decimal SupplierNet { get; set; }
        public decimal SellingPrice { get; set; }
        public decimal CostToClient { get; set; }
        public decimal ClientToAgencyReceivable { get; set; }
        public decimal ClientToAgencyReceived { get; set; }
        public decimal AmountReceivable { get; set; }
        public decimal AmountReceived { get; set; }
        public decimal AmountPayable { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal AmountInvoiceable { get; set; }
        public decimal AmountInvoiced { get; set; }
        public decimal AmountInvoicedWithPayment { get; set; }
        public decimal PersonalTravelAmount { get; set; }
        public decimal Yield { get; set; }
        public bool IsAllCreditCardPayment { get; set; }
        public bool CreditCardNotPaid { get; set; }
        public bool DoNotGenerateInvoiceLine { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }
    }
}