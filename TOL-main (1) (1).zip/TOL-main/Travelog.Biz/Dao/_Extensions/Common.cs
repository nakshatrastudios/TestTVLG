using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz.Enums;

namespace Travelog.Biz.Dao.Common {
    public partial class AdjustmentType {
        [NotMapped]
        public string DebitAccountName {
            get {
                return DebitType == DebitCreditType.Client ? DebitTripId <= 0 ? string.Empty : DebitTrip.AccountName
                : DebitType == DebitCreditType.Debtor ? DebitDebtorId <= 0 ? string.Empty : DebitDebtor.Name
                : DebitType == DebitCreditType.Creditor ? DebitCreditorId <= 0 ? string.Empty : DebitCreditor.Name
                : DebitType == DebitCreditType.GeneralLedger ? DebitChartOfAccountId <= 0 ? string.Empty : string.Format("{0}: {1}", DebitChartOfAccount.Code, DebitChartOfAccount.Name)
                : string.Empty;
            }
        }

        [NotMapped]
        public string CreditAccountName {
            get {
                return CreditType == DebitCreditType.Client ? CreditTripId <= 0 ? string.Empty : CreditTrip.AccountName
                : CreditType == DebitCreditType.Debtor ? CreditDebtorId <= 0 ? string.Empty : CreditDebtor.Name
                : CreditType == DebitCreditType.Creditor ? CreditCreditorId <= 0 ? string.Empty : CreditCreditor.Name
                : CreditType == DebitCreditType.GeneralLedger ? CreditChartOfAccountId <= 0 ? string.Empty : string.Format("{0}: {1}", CreditChartOfAccount.Code, CreditChartOfAccount.Name)
                : string.Empty;
            }
        }
    }

    public partial class Agency {
        [NotMapped]
        public string BillingAddress {
            get {
                string address = string.Empty;

                if (!string.IsNullOrEmpty(BillingAddress1))
                    address += string.Format("{0}{1}", BillingAddress1, AppConstants.HtmlLineBreak);

                if (!string.IsNullOrEmpty(BillingAddress2))
                    address += string.Format("{0}{1}", BillingAddress2, AppConstants.HtmlLineBreak);

                address += Utils.RemoveExtraSpaces(string.Concat(BillingLocality, " ", BillingRegion, " ", BillingPostCode, " ", BillingCountryCode));
                return address.TrimEnd(AppConstants.HtmlLineBreak);
            }
        }

        [NotMapped]
        public string FinancialIntegrityLastRunTimeFormatted {
            get {
                DateTime lastRunTime = FinancialIntegrityCheckLastRunTime == DateTime.MinValue ? DateTime.MinValue : FinancialIntegrityCheckLastRunTime.ToLocalTime();
                return lastRunTime == DateTime.MinValue ? "Never" : lastRunTime.ToShortDateTimeStringExt();
            }
        }

        public string GetFinancialIntegrityStatus(AppMainContext context) {
            string statusDescription = null;

            if (FinancialIntegrityStatus == FinancialIntegrityStatus.Failed) {
                int count = context.TransactionDetail.Count(t => t.IntegrityCheckFailed);

                if (count == 0) {
                    statusDescription = FinancialIntegrityStatus.GetEnumDescription();
                }
                else if (count == 1) {
                    statusDescription = "1 Failure";
                }
                else {
                    statusDescription = string.Format("{0:n0} Failures", count);
                }
            }
            else {
                statusDescription = FinancialIntegrityStatus.GetEnumDescription();
            }

            return statusDescription;
        }
    }

    public partial class AgencyAddress {
        [NotMapped]
        public string Address {
            get {
                return string.Concat(Address1, " ", Address2, " ", Locality, " ", Region, " ", PostCode, " ", CountryCode).Trim();
            }
        }
    }

    public partial class AgencyContact {
        [NotMapped]
        public string FullName {
            get {
                return (Title + " " + Name).Trim();
            }
        }

        [NotMapped]
        public string PhoneNo {
            get {
                return string.IsNullOrEmpty(PhoneWork) ? string.IsNullOrEmpty(Mobile) ? PhoneHome : Mobile : PhoneWork;
            }
        }
    }

    public partial class Aircraft {
        public static Aircraft GetAircraft(AppMainContext context, string code) {
            return context.Aircraft.SingleOrDefault(t => t.Code.ToLower() == (code ?? string.Empty).ToLower()) ?? new Aircraft { Id = -1, Code = string.Empty, Name = string.Empty };
        }
    }

    public partial class Airline {
        public static Airline GetAirline(AppMainContext context, string code) {
            return context.Airline.SingleOrDefault(t => t.Code.ToLower() == (code ?? string.Empty).ToLower()) ?? new Airline { Id = -1, Code = string.Empty, Name = string.Empty };
        }

        public static decimal GetCommissionRate(AppMainContext context, int airlineId, int saleTypeId, CountryZone? countryZone = null, string taxCode = null) {
            var airline = context.Airline.Find(airlineId);
            return airline.GetCommissionRate(context, saleTypeId, countryZone, taxCode);
        }

        public decimal GetCommissionRate(AppMainContext context, int saleTypeId, CountryZone? countryZone = null, string taxCode = null) {
            decimal commissionRate = AirlineCommissions.FirstOrDefault(t => t.AirlineId == Id && t.SaleTypeId == saleTypeId && (countryZone == null || t.CountryZone == countryZone) && (taxCode == null || t.CommissionableTaxes == taxCode))?.CommissionRate ?? 0;

            if (commissionRate > 0)
                return commissionRate;

            return context.SaleType.Find(saleTypeId)?.CommissionRate ?? 0;
        }
    }

    public partial class AirlineCommisisonRate {
    }

    public partial class BankAccountAddress {
        [NotMapped]
        public string Address {
            get {
                return string.Concat(Address1, " ", Address2, " ", Locality, " ", Region, " ", PostCode, " ", CountryCode).Trim();
            }
        }
    }

    public partial class BankAccountStatement {
        [NotMapped]
        public string Name {
            get {
                return Id == -1 ? "None" : string.Concat("#", StatementNo, ": ", ClosingDate == DateTime.MinValue ? "Not Specified" : ClosingDate.ToShortDateStringExt());
            }
        }

        public static IQueryable<BankAccountStatementModel> GetBankAccountStatementQuery(AppMainContext context, int bankAccountId, bool includeDefault) {
            var q = context.BankAccountStatement.Include(t => t.BankAccount).ThenInclude(t => t.ChartOfAccount).Include(t => t.BankAccount).ThenInclude(t => t.BankAccountStatements).Where(t => t.BankAccountId == bankAccountId);

            if (!includeDefault)
                q = q.Where(t => t.Id > 0);

            return from t1 in q.OrderByDescending(t => t.StatementNo)
                   let t2 = t1.BankAccount.BankAccountStatements.Where(t3 => t3.ClosingDate < t1.ClosingDate).OrderByDescending(t2 => t2.ClosingDate).FirstOrDefault()
                   orderby t1.StatementNo descending
                   select new BankAccountStatementModel {
                       Id = t1.Id,
                       StatementNo = t1.StatementNo,
                       OpeningBalance = t1.OpeningBalance,
                       ClosingBalance = t1.ClosingBalance,
                       OpeningDate = t2 == null ? DateTime.MinValue : t2.ClosingDate.AddDays(1),
                       ClosingDate = t1.ClosingDate,
                       BankAccountId = t1.BankAccountId,
                       BankAccountName = t1.BankAccount.Name,
                       BankAccountBranch = t1.BankAccount.Branch,
                       BankAccountNo = t1.BankAccount.AccountNo,
                       BankAccountDescription = t1.BankAccount.AccountDescription,
                       BankChartOfAccountId = t1.BankAccount.ChartOfAccountId,
                       BankChartOfAccountCode = t1.BankAccount.ChartOfAccount.Code,
                       BankChartOfAccountName = t1.BankAccount.ChartOfAccount.Name,
                       BankOpeningBalance = t1.BankAccount.OpeningBalance,
                       AmountArchived = t1.AmountArchived,
                       LastWriteTime = t1.LastWriteTime,
                       CreationTime = t1.CreationTime,
                       LastWriteUser = t1.LastWriteUser,
                       CreationUser = t1.CreationUser
                   };
        }
    }

    public partial class City {
        public static City GetCity(AppMainContext context, string code) {
            return context.City.Include(t => t.Country).SingleOrDefault(t => t.Code.ToLower() == (code ?? string.Empty).ToLower()) ?? new City { Id = -1, Code = string.Empty, Name = string.Empty, CountryId = -1, Country = new Country { Id = -1, Code = string.Empty, Name = string.Empty } };
        }
    }

    public partial class ClubMembership {
        public static ClubMembership GetClubMembership(AppMainContext context, string crsCode) {
            return context.ClubMembership.SingleOrDefault(t => t.CrsCode.ToLower() == (crsCode ?? string.Empty).ToLower()) ?? new ClubMembership { Id = -1, Name = string.Empty, CrsCode = string.Empty };
        }
    }

    public partial class ContactTitle {
        public static ContactTitle GetContactTitle(AppMainContext context, string crsCodeOrTitle, bool isCrsCode = true) {
            if (string.IsNullOrEmpty(crsCodeOrTitle))
                return new ContactTitle { Id = -1, Name = string.Empty, Gender = Gender.NotSpecified };

            if (isCrsCode)
                return context.ContactTitle.FirstOrDefault(t => t.CrsCode.ToLower() == (crsCodeOrTitle ?? string.Empty).ToLower()) ?? new ContactTitle { Id = -1, Name = string.Empty, Gender = Gender.NotSpecified };

            return context.ContactTitle.FirstOrDefault(t => t.Name.ToLower() == (crsCodeOrTitle ?? string.Empty).ToLower()) ?? new ContactTitle { Id = -1, Name = string.Empty, Gender = Gender.NotSpecified };
        }
    }

    public partial class Country {
        public static Country GetCountry(AppMainContext context, string code, bool isIsoCode = false) {
            return context.Country.SingleOrDefault(t => (isIsoCode ? t.IsoCode : t.Code).ToLower() == code.ToLower()) ?? new Country { Id = -1, Code = string.Empty, IsoCode = string.Empty, Name = string.Empty };
        }
    }

    public partial class Currency {
        public static Currency GetCurrency(AppMainContext context, string code) {
            return context.Currency.SingleOrDefault(t => t.Code.ToLower() == (code ?? string.Empty).ToLower()) ?? new Currency { Id = -1, Code = string.Empty, Name = string.Empty };
        }

        public static decimal GetExchangeRate(AppMainContext context, int currencyId, bool officialRate = false) {
            var q = context.Currency.SingleOrDefault(t => t.Id == currencyId) ?? new Currency { Id = -1, Code = string.Empty, Name = string.Empty };
            return q.GetExchangeRate(officialRate);
        }

        public static decimal GetExchangeRate(AppMainContext context, string currencyCode, bool officialRate = false) {
            var q = context.Currency.SingleOrDefault(t => t.Code.ToLower() == (currencyCode ?? string.Empty).ToLower()) ?? new Currency { Id = -1, Code = string.Empty, Name = string.Empty };
            return q.GetExchangeRate(officialRate);
        }

        public decimal GetExchangeRate(bool officialRate = false) {
            return officialRate || Rate == 0 ? OfficialRate : Rate;
        }

        public static Dictionary<string, string> CurrencyList => new Dictionary<string, string> {
            { "AED", "UAE Dirham" },
            { "AFN", "Afghani" },
            { "ALL", "Lek" },
            { "AMD", "Armenian Dram" },
            { "ANG", "Netherlands Antillean Guilder" },
            { "AOA", "Kwanza" },
            { "ARS", "Argentine Peso" },
            { "AUD", "Australian Dollar" },
            { "AWG", "Aruban Florin" },
            { "AZN", "Azerbaijanian Manat" },
            { "BAM", "Convertible Mark" },
            { "BBD", "Barbados Dollar" },
            { "BDT", "Taka" },
            { "BGN", "Bulgarian Lev" },
            { "BHD", "Bahraini Dinar" },
            { "BIF", "Burundi Franc" },
            { "BMD", "Bermudian Dollar" },
            { "BND", "Brunei Dollar" },
            { "BOB", "Boliviano" },
            { "BOV", "Mvdol" },
            { "BRL", "Brazilian Real" },
            { "BSD", "Bahamian Dollar" },
            { "BTN", "Ngultrum" },
            { "BWP", "Pula" },
            { "BYN", "Belarussian Ruble" },
            { "BZD", "Belize Dollar" },
            { "CAD", "Canadian Dollar" },
            { "CDF", "Congolese Franc" },
            { "CHE", "WIR Euro" },
            { "CHF", "Swiss Franc" },
            { "CHW", "WIR Franc" },
            { "CLF", "Unidad de Fomento" },
            { "CLP", "Chilean Peso" },
            { "CNY", "Yuan Renminbi" },
            { "COP", "Colombian Peso" },
            { "COU", "Unidad de Valor Real" },
            { "CRC", "Costa Rican Colon" },
            { "CUC", "Peso Convertible" },
            { "CUP", "Cuban Peso" },
            { "CVE", "Cabo Verde Escudo" },
            { "CZK", "Czech Koruna" },
            { "DJF", "Djibouti Franc" },
            { "DKK", "Danish Krone" },
            { "DOP", "Dominican Peso" },
            { "DZD", "Algerian Dinar" },
            { "EGP", "Egyptian Pound" },
            { "ERN", "Nakfa" },
            { "ETB", "Ethiopian Birr" },
            { "EUR", "Euro" },
            { "FJD", "Fiji Dollar" },
            { "FKP", "Falkland Islands Pound" },
            { "GBP", "Pound Sterling" },
            { "GEL", "Lari" },
            { "GHS", "Ghana Cedi" },
            { "GIP", "Gibraltar Pound" },
            { "GMD", "Dalasi" },
            { "GNF", "Guinea Franc" },
            { "GTQ", "Quetzal" },
            { "GYD", "Guyana Dollar" },
            { "HKD", "Hong Kong Dollar" },
            { "HNL", "Lempira" },
            { "HRK", "Kuna" },
            { "HTG", "Gourde" },
            { "HUF", "Forint" },
            { "IDR", "Rupiah" },
            { "ILS", "New Israeli Sheqel" },
            { "INR", "Indian Rupee" },
            { "IQD", "Iraqi Dinar" },
            { "IRR", "Iranian Rial" },
            { "ISK", "Iceland Krona" },
            { "JMD", "Jamaican Dollar" },
            { "JOD", "Jordanian Dinar" },
            { "JPY", "Yen" },
            { "KES", "Kenyan Shilling" },
            { "KGS", "Som" },
            { "KHR", "Riel" },
            { "KMF", "Comoro Franc" },
            { "KPW", "North Korean Won" },
            { "KRW", "Won" },
            { "KWD", "Kuwaiti Dinar" },
            { "KYD", "Cayman Islands Dollar" },
            { "KZT", "Tenge" },
            { "LAK", "Kip" },
            { "LBP", "Lebanese Pound" },
            { "LKR", "Sri Lanka Rupee" },
            { "LRD", "Liberian Dollar" },
            { "LSL", "Loti" },
            { "LYD", "Libyan Dinar" },
            { "MAD", "Moroccan Dirham" },
            { "MDL", "Moldovan Leu" },
            { "MGA", "Malagasy Ariary" },
            { "MKD", "Denar" },
            { "MMK", "Kyat" },
            { "MNT", "Tugrik" },
            { "MOP", "Pataca" },
            { "MRU", "Ouguiya" },
            { "MUR", "Mauritius Rupee" },
            { "MVR", "Rufiyaa" },
            { "MWK", "Kwacha" },
            { "MXN", "Mexican Peso" },
            { "MXV", "Mexican Unidad de Inversion" },
            { "MYR", "Malaysian Ringgit" },
            { "MZN", "Mozambique Metical" },
            { "NAD", "Namibia Dollar" },
            { "NGN", "Naira" },
            { "NIO", "Cordoba Oro" },
            { "NOK", "Norwegian Krone" },
            { "NPR", "Nepalese Rupee" },
            { "NZD", "New Zealand Dollar" },
            { "OMR", "Rial Omani" },
            { "PAB", "Balboa" },
            { "PEN", "Nuevo Sol" },
            { "PGK", "Kina" },
            { "PHP", "Philippine Peso" },
            { "PKR", "Pakistan Rupee" },
            { "PLN", "Zloty" },
            { "PYG", "Guarani" },
            { "QAR", "Qatari Rial" },
            { "RON", "Romanian Leu" },
            { "RSD", "Serbian Dinar" },
            { "RUB", "Russian Ruble" },
            { "RWF", "Rwanda Franc" },
            { "SAR", "Saudi Riyal" },
            { "SBD", "Solomon Islands Dollar" },
            { "SCR", "Seychelles Rupee" },
            { "SDG", "Sudanese Pound" },
            { "SEK", "Swedish Krona" },
            { "SGD", "Singapore Dollar" },
            { "SHP", "Saint Helena Pound" },
            { "SLE", "Leone" },
            { "SOS", "Somali Shilling" },
            { "SRD", "Surinam Dollar" },
            { "SSP", "South Sudanese Pound" },
            { "STN", "Dobra" },
            { "SVC", "El Salvador Colon" },
            { "SYP", "Syrian Pound" },
            { "SZL", "Lilangeni" },
            { "THB", "Baht" },
            { "TJS", "Somoni" },
            { "TMT", "Turkmenistan New Manat" },
            { "TND", "Tunisian Dinar" },
            { "TOP", "Pa'anga" },
            { "TRY", "Turkish Lira" },
            { "TTD", "Trinidad and Tobago Dollar" },
            { "TWD", "New Taiwan Dollar" },
            { "TZS", "Tanzanian Shilling" },
            { "UAH", "Hryvnia" },
            { "UGX", "Uganda Shilling" },
            { "USD", "US Dollar" },
            { "UYI", "Uruguay Peso" },
            { "UYU", "Peso Uruguayo" },
            { "UZS", "Uzbekistan Sum" },
            { "VEF", "Bolivar" },
            { "VND", "Dong" },
            { "VUV", "Vatu" },
            { "WST", "Tala" },
            { "XAF", "CFA Franc" },
            { "XCD", "East Caribbean Dollar" },
            { "XDR", "SDR (Special Drawing Right)" },
            { "XOF", "CFA Franc BCEAO" },
            { "XPF", "CFP Franc" },
            { "XSU", "Sucre" },
            { "YER", "Yemeni Rial" },
            { "ZAR", "Rand" },
            { "ZMW", "Zambian Kwacha" },
            { "ZWL", "Zimbabwe Dollar" }
        };
    }

    public partial class Embassy {
        [NotMapped]
        public string Address {
            get {
                return string.Concat(Address1, " ", Address2, " ", Locality, " ", Region, " ", PostCode, " ", CountryCode).Trim();
            }
        }
    }

    public partial class FormOfPayment {
        [NotMapped]
        public FormOfPaymentClass FormOfPaymentClass {
            get {
                switch (FormOfPaymentType) {
                    default:
                        return FormOfPaymentClass.Other;
                    case FormOfPaymentType.CreditCard:
                    case FormOfPaymentType.TravelCard:
                        return FormOfPaymentClass.CreditCardTravelCard;
                    case FormOfPaymentType.AgencyCreditCardNet:
                    case FormOfPaymentType.ClearingHouseNet:
                        return FormOfPaymentClass.Net;
                    case FormOfPaymentType.AgencyCreditCardGross:
                    case FormOfPaymentType.PaySupplierGross:
                    case FormOfPaymentType.ClearingHouseGross:
                        return FormOfPaymentClass.Gross;
                }
            }
        }

        [NotMapped]
        public string PaySupplierDescription {
            get {
                return string.Concat(Name, FormOfPaymentType == FormOfPaymentType.CreditCard || FormOfPaymentType == FormOfPaymentType.TravelCard ? " [Client to Supplier]" : string.Empty);
            }
        }

        [NotMapped]
        public static Expression<Func<FormOfPayment, bool>> PaymentWhereClause {
            get {
                return t => t.Id == -1
                    || t.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross
                    || t.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet
                    || t.FormOfPaymentType == FormOfPaymentType.AutomaticPayment
                    || t.FormOfPaymentType == FormOfPaymentType.Cash
                    || t.FormOfPaymentType == FormOfPaymentType.Cheque
                    || t.FormOfPaymentType == FormOfPaymentType.ClearingHouseGross
                    || t.FormOfPaymentType == FormOfPaymentType.ClearingHouseNet
                    || t.FormOfPaymentType == FormOfPaymentType.CreditCard
                    || t.FormOfPaymentType == FormOfPaymentType.DirectDebitCredit
                    || t.FormOfPaymentType == FormOfPaymentType.EFTPOS
                    || t.FormOfPaymentType == FormOfPaymentType.LoyaltyScheme
                    || t.FormOfPaymentType == FormOfPaymentType.PaySupplierGross
                    || t.FormOfPaymentType == FormOfPaymentType.TravelCard;
            }
        }

        [NotMapped]
        public static Expression<Func<FormOfPayment, bool>> ReceiptWhereClause {
            get {
                return t => t.Id == -1
                    || t.FormOfPaymentType == FormOfPaymentType.AutomaticPayment
                    || t.FormOfPaymentType == FormOfPaymentType.Cash
                    || t.FormOfPaymentType == FormOfPaymentType.Cheque
                    || t.FormOfPaymentType == FormOfPaymentType.CreditCard
                    || t.FormOfPaymentType == FormOfPaymentType.DirectDebitCredit
                    || t.FormOfPaymentType == FormOfPaymentType.EFTPOS
                    || t.FormOfPaymentType == FormOfPaymentType.Other
                    || t.FormOfPaymentType == FormOfPaymentType.Reward
                    || t.FormOfPaymentType == FormOfPaymentType.TravelCard;
            }
        }

        [NotMapped]
        public static Expression<Func<FormOfPayment, bool>> ReceiptAndLoyaltySchemeWhereClause {
            get {
                return t => t.Id == -1
                    || t.FormOfPaymentType == FormOfPaymentType.AutomaticPayment
                    || t.FormOfPaymentType == FormOfPaymentType.Cheque
                    || t.FormOfPaymentType == FormOfPaymentType.CreditCard
                    || t.FormOfPaymentType == FormOfPaymentType.DirectDebitCredit
                    || t.FormOfPaymentType == FormOfPaymentType.EFTPOS
                    || t.FormOfPaymentType == FormOfPaymentType.LoyaltyScheme
                    || t.FormOfPaymentType == FormOfPaymentType.Other
                    || t.FormOfPaymentType == FormOfPaymentType.Reward
                    || t.FormOfPaymentType == FormOfPaymentType.TravelCard;
            }
        }

        public static FormOfPayment GetFormOfPayment(AppMainContext context, Crs crs, string crsCode) {
            return context.FormOfPaymentCrs.Include(t => t.FormOfPayment).FirstOrDefault(t => (t.Crs == Crs.NotSpecified || t.Crs == crs) && t.CrsCode.ToLower() == (crsCode ?? string.Empty).ToLower())?.FormOfPayment ?? context.FormOfPaymentCrs.Include(t => t.FormOfPayment).SingleOrDefault(t => t.Crs == Crs.NotSpecified && t.CrsCode.ToLower() == (crsCode ?? string.Empty).ToLower())?.FormOfPayment ?? new FormOfPayment { Id = -1, Name = string.Empty };
        }

        public static int GetFormOfPaymentIdByCardNo(int customerId, string cardNo) {
            if (cardNo.StartsWith("4")) {
                return AppSettings.Setting(customerId).VisaFormOfPaymentId;
            }
            else if (cardNo.StartsWith("5")) {
                return AppSettings.Setting(customerId).MastercardFormOfPaymentId;
            }
            else if (cardNo.StartsWith("34") || cardNo.StartsWith("37")) {
                return AppSettings.Setting(customerId).AmexFormOfPaymentId;
            }
            else if (cardNo.StartsWith("30") || cardNo.StartsWith("36") || cardNo.StartsWith("38")) {
                return AppSettings.Setting(customerId).DinersClubFormOfPaymentId;
            }

            return -1;
        }
    }

    public partial class IssuedDocument {
        [NotMapped]
        public string FileName {
            get {
                return string.Concat(Name, ".", FileExtension.ToLower());
            }
        }

        [NotMapped]
        public string FileContentType {
            get {
                return string.Concat("application/", FileExtension.ToLower());
            }
        }

        public static string GetQuoteName(AppMainContext context, int tripId, int quoteNo) {
            string tripNo = context.Trip.Find(tripId).TripNo;

            if (quoteNo == 0)
                return string.Format("Booking No {0}", tripNo);

            if (quoteNo < 0)
                return string.Format("Quote No {0}", tripNo);

            return string.Format("Quote No {0}.{1}", tripNo, quoteNo);
        }

        public static string GetConfirmationName(AppMainContext context, int tripId, int quoteNo) {
            string tripNo = context.Trip.Find(tripId).TripNo;

            if (quoteNo == 0)
                return string.Format("Confirmation - Booking No {0}", tripNo);

            if (quoteNo < 0)
                return string.Format("Confirmation - Quote No {0}", tripNo);

            return string.Format("Confirmation - Quote No {0}.{1}", tripNo, quoteNo);
        }

        public static string GetItineraryName(AppMainContext context, int tripId, int quoteNo) {
            string tripNo = context.Trip.Find(tripId).TripNo;

            if (quoteNo == 0)
                return string.Format("Itinerary - Booking No {0}", tripNo);

            if (quoteNo < 0)
                return string.Format("Itinerary - Quote No {0}", tripNo);

            return string.Format("Itinerary - Quote No {0}.{1}", tripNo, quoteNo);
        }

        public static string GetStatementName(AppMainContext context, int tripId, int quoteNo) {
            string tripNo = context.Trip.Find(tripId).TripNo;

            if (quoteNo == 0)
                return string.Format("Statement - Booking No {0}", tripNo);

            if (quoteNo < 0)
                return string.Format("Statement - Quote No {0}", tripNo);

            return string.Format("Statement - Quote No {0}.{1}", tripNo, quoteNo);
        }

        public static string GetReceiptName(ReceiptType receiptType, string documentNo) {
            return string.Format(receiptType == ReceiptType.Refund ? "Refund No {0}" : "Receipt No {0}", documentNo);
        }

        public static string GetInvoiceName(InvoiceType invoiceType, string documentNo) {
            return string.Format(invoiceType == InvoiceType.Invoice ? "Tax Invoice No {0}" : "Credit Note No {0}", documentNo);
        }

        public static string GetVoucherName(string documentNo) {
            return string.Format("Voucher No {0}", documentNo);
        }

        public static string GetFileName(string fileName) {
            var fi = new FileInfo(fileName);
            return fi.Name.Left(fi.Name.Length - fi.Extension.Length).Left(100);
        }

        public static string GetFileExtension(string fileName) {
            var fi = new FileInfo(fileName);
            return fi.Extension.Substring(1).ToLower();
        }
    }

    public partial class LastDocumentNo {
        public static string DocumentNo(AppMainContext context, string id, string value = null) {
            var q = context.LastDocumentNo.Find(id);

            if (value == null) {
                return (q.Value + 1).ToString("D8");
            }
            else {
                q.Value = int.Parse(new string(value.Where(char.IsDigit).ToArray()));
                context.Save(q, false);
                return value;
            }
        }
    }

    public partial class MarkupStrategy {
        public decimal GetRemainderCommission(decimal amount, decimal markup) {
            decimal markupValue = 0;

            foreach (var row in MarkupStrategyElements.Where(t => t.ApportionMethod == ApportionMethod.Fixed)) {
                markupValue += row.GetAmount(amount, markup);
            }

            decimal remainderCommission = markup - markupValue;

            if (!AllowInverseRemainderCommission && ((remainderCommission < 0 && markup > 0) || (remainderCommission > 0 && markup < 0)))
                remainderCommission = 0;

            return remainderCommission;
        }
    }

    public partial class MarkupStrategyElement {
        public decimal GetAmount(decimal amount, decimal markup) {
            switch (ApportionMethod) {
                default:
                    throw new InvalidOperationException("Apportion Method is invalid.");
                case ApportionMethod.Fixed:
                    return Amount;
                case ApportionMethod.PercentageGross:
                    return amount * Amount;
                case ApportionMethod.PercentageMarkup:
                    return markup * Amount;
                case ApportionMethod.PercentageGrossMarkup:
                    return (amount + markup) * Amount;
            }
        }
    }

    public partial class MealServed {
        public static MealServed GetMealServed(AppMainContext context, Crs crs, string crsCode) {
            return context.MealServedCrs.Include(t => t.MealServed).FirstOrDefault(t => (t.Crs == Crs.NotSpecified || t.Crs == crs) && t.CrsCode.ToLower() == (crsCode ?? string.Empty).ToLower())?.MealServed ?? new MealServed { Id = -1, Name = string.Empty };
        }
    }

    public class BankAccountStatementModel {
        public int Id { get; set; }
        public int StatementNo { get; set; }
        public decimal OpeningBalance { get; set; }
        public DateTime OpeningDate { get; set; }
        public decimal ClosingBalance { get; set; }
        public DateTime ClosingDate { get; set; }
        public int BankAccountId { get; set; }
        public string BankAccountName { get; set; }
        public string BankAccountBranch { get; set; }
        public string BankAccountNo { get; set; }
        public string BankAccountDescription { get; set; }
        public int BankChartOfAccountId { get; set; }
        public string BankChartOfAccountCode { get; set; }
        public string BankChartOfAccountName { get; set; }
        public decimal BankOpeningBalance { get; set; }
        public decimal AmountArchived { get; set; }
        public DateTime LastWriteTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string LastWriteUser { get; set; }
        public string CreationUser { get; set; }
    }
}