using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.StaticMethods;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;

namespace Travelog.Biz.Dao.GeneralLedger {
    public partial class ChartOfAccount {
		[NotMapped]
		public string AccountName {
			get {
				return Id <= 0 ? string.Empty : string.Concat(Code, ": ", Name);
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				return Id <= 0 ? string.Empty : string.Concat(@"<a href=""/GeneralLedger/ChartOfAccounts/?id=", Id, @""" target=""blank"">", AccountName, "</a>");
			}
		}

		public bool IsInRole(string userRoleId) {
			var q = ChartOfAccountRoles.Where(t => t.ChartOfAccountId == Id).ToList();
			return userRoleId == UserRole.SystemAdministrator.Id || q.Count == 0 || q.Any(t => t.RoleId == userRoleId);
		}

		public static bool IsInRole(AppMainContext context, int chartOfAccountId, string userRoleId) {
			var q = context.ChartOfAccountRole.Where(t => t.ChartOfAccountId == chartOfAccountId).ToList();
			return userRoleId == UserRole.SystemAdministrator.Id || q.Count == 0 || q.Any(t => t.RoleId == userRoleId);
		}

		public static IQueryable<ChartOfAccount> GetChartOfAccountQuery(AppMainContext context, int customerId, int agencyId, bool otherAgencies, bool otherConsultants, int[] agencyIds, int[] consultantIds, string userRoleId) {
			var q = context.ChartOfAccount.Include(t => t.Agency).Include(t => t.ChartOfAccountRoles).Where(t => t.Id > 0);

			if (userRoleId != UserRole.SystemAdministrator.Id)
				q = q.Where(t1 => t1.ChartOfAccountRoles.Count == 0 || t1.ChartOfAccountRoles.Any(t2 => t2.RoleId == userRoleId));

			if (agencyId > 0)
				q = q.Where(t1 => t1.AgencyId == agencyId);

			if (!otherAgencies)
				q = q.Where(t => agencyIds.Contains(t.AgencyId));

			if (!otherConsultants)
				q = q.Where(t1 => t1.Agency.ConsultantAgencies.Any(t2 => consultantIds.Contains(t2.ConsultantId)));

			if (CustomerSettings.Setting(customerId).AgencyType == AgencyType.MultiAgencyGLSingle)
				q = q.Where(t => t.ChartOfAccountType == ChartOfAccountType.ProfitLoss || (t.ChartOfAccountType == ChartOfAccountType.BalanceSheet && t.Agency.IsHeadOffice));

			return q.OrderBy(t => t.Code);
		}

		public ChartOfAccount GetChartOfAccountByAgencyId(AppMainContext context, int agencyId) {
            if (Id <= 0 || AgencyId == agencyId)
				return this;

			var chartOfAccount = context.ChartOfAccount.SingleOrDefault(t => (t.AgencyId == -1 || t.AgencyId == agencyId) && t.Code == Code);

			if (chartOfAccount == null) {
				agencyId = (context.Agency.SingleOrDefault(t => t.IsHeadOffice) ?? new Agency { Id = -1 }).Id;

				if (agencyId <= 0)
					throw new UnreportedException("No Agency has been defined as Head Office.");

				chartOfAccount = context.ChartOfAccount.SingleOrDefault(t => t.AgencyId == agencyId && t.Code == Code);

				if (chartOfAccount == null) {
					string agencyName = context.Agency.Find(agencyId).Name;
					throw new UnreportedException(string.Format("A General Ledger account does not exist for Agency {0} and Code {1}.", agencyName, Code));
				}
			}

			return chartOfAccount;
		}

		public static ChartOfAccount GetChartOfAccountByAgencyId(AppMainContext context, int chartOfAccountId, int agencyId) {
			return context.ChartOfAccount.Find(chartOfAccountId).GetChartOfAccountByAgencyId(context, agencyId);
		}
	}

	public partial class Setting {
		[NotMapped]
		public DateTime FiscalYearEndDate {
			get {
				return SettingDetails.OrderByDescending(t => t.FiscalPeriodEndDate).FirstOrDefault()?.FiscalPeriodEndDate ?? DateTime.MinValue;
			}
		}

		public static bool IsFiscalPeriodOpen(AppMainContext context, DateTime dateApplicable, bool isAdministrator) {
			var q = GetRow(context, dateApplicable);

			if (q.SettingId == 0)
				return false;

			return !q.IsUserClosed || (isAdministrator && !q.IsAdminClosed);
		}

		public static bool IsFiscalPeriodOpen(int customerId, DateTime dateApplicable, bool isAdministrator) {
			var q = GetRow(customerId, dateApplicable);

			if (q.SettingId == 0)
				return false;

			return !q.IsUserClosed || (isAdministrator && !q.IsAdminClosed);
		}

		public static bool IsControlAccount(int customerId, DateTime dateApplicable, int chartOfAccountId) {
			var q = GetRow(customerId, dateApplicable);

			if (q == null)
				return false;

			return q.ClientControlAccount?.Id == chartOfAccountId || q.DebtorControlAccount?.Id == chartOfAccountId || q.CreditorControlAccount?.Id == chartOfAccountId;
		}

		public static GeneralLedgerSettingDetail GetRow(AppMainContext context, DateTime dateApplicable, bool isFiscalYear = false, bool ignoreNullError = true) {
			var settingDetails = GeneralLedgerSettings.GetFiscalPeriodList(context);
			return GetRow(settingDetails, dateApplicable.Date, isFiscalYear, ignoreNullError);
		}

		public static GeneralLedgerSettingDetail GetRow(int customerId, DateTime dateApplicable, bool isFiscalYear = false, bool ignoreNullError = true) {
			var settingDetails = GeneralLedgerSettings.GetFiscalPeriodList(customerId);
			return GetRow(settingDetails, dateApplicable.Date, isFiscalYear, ignoreNullError);
		}

		private static GeneralLedgerSettingDetail GetRow(IEnumerable<GeneralLedgerSettingDetail> settingDetails, DateTime dateApplicable, bool isFiscalYear = false, bool ignoreNullError = true) {
			GeneralLedgerSettingDetail settingDetail = null;
			dateApplicable = dateApplicable.Date;

			if (isFiscalYear) {
				settingDetail = settingDetails.FirstOrDefault(t => t.FiscalYearStartDate <= dateApplicable && t.FiscalYearEndDate >= dateApplicable);
			}
			else {
				settingDetail = settingDetails.FirstOrDefault(t => t.FiscalPeriodStartDate <= dateApplicable && t.FiscalPeriodEndDate >= dateApplicable);
			}

			if (settingDetail == null && !ignoreNullError)
				throw new UnreportedException(string.Format("No General Ledger settings were found for the specified date {0:d}. Please review your settings to ensure there are no gaps between fiscal year/period start/end dates.", dateApplicable));

			return settingDetail ?? new GeneralLedgerSettingDetail();
		}
	}

	public class GeneralLedger {
		public ChartOfAccount ChartOfAccount { get; set; }
		public decimal SalesMtd { get; set; }
		public string Code { get; set; }
		public string Name { get; set; }
		public TotalLevel TotalGroupLevel { get; set; }
		public decimal PeriodBudget { get; set; }
		public decimal PeriodCurrentYear { get; set; }
		public decimal PeriodPreviousYear { get; set; }
		public decimal YtdBudget { get; set; }
		public decimal YtdCurrentYear { get; set; }
		public decimal YtdPreviousYear { get; set; }

		public TransactionDetailPeriodReportModel Period { get; set; }

		public IQueryable<TransactionDetail> TransactionDetail { get; set; }

        public IQueryable<TransactionDetail> TransactionDetailPeriod { get; set; }

        public static List<GeneralLedger> GetGeneralLedgerQuery(AppLazyContext lazyContext, int customerId, int agencyId, int currentDefaultAgencyId, string userRoleId, int chartOfAccountTypeId, AccountCategory accountCategory, DateTime fiscalYearStartDate, DateTime periodFrom, DateTime dateFrom, DateTime dateTo, ReportSourceGeneralLedger reportSource, TransactionViewOption transactionViewOption, bool excludeZeroBalances, bool useAltReportingCode, bool useDateFilters, bool useCache, string text = null) {
			DateTime periodCurrentYearFrom = DateTime.MinValue;
			DateTime periodCurrentYearTo = DateTime.MinValue;

			DateTime periodPreviousYearFrom = DateTime.MinValue;
			DateTime periodPreviousYearTo = DateTime.MinValue;

			DateTime ytdCurrentYearFrom = DateTime.MinValue;
			DateTime ytdCurrentYearTo = DateTime.MinValue;

			DateTime ytdPreviousYearFrom = DateTime.MinValue;
			DateTime ytdPreviousYearTo = DateTime.MinValue;

			GeneralLedgerSettingDetail settingCurrentPeriod = null;
			GeneralLedgerSettingDetail settingPreviousPeriod = null;
			GeneralLedgerSettingDetail settingCurrentYear = null;
			GeneralLedgerSettingDetail settingPreviousYear = null;

			if (useDateFilters) {
				if (dateFrom == DateTime.MinValue || dateTo == DateTime.MinValue)
					return new List<GeneralLedger>();
			}
			else {
				if (useCache) {
					settingCurrentPeriod = Setting.GetRow(customerId, periodFrom);
                    settingPreviousPeriod = Setting.GetRow(customerId, periodFrom <= DateTime.MinValue.AddYears(1) ? DateTime.MinValue : periodFrom.AddYears(-1));
                    settingCurrentYear = Setting.GetRow(customerId, fiscalYearStartDate, true);
                    settingPreviousYear = Setting.GetRow(customerId, fiscalYearStartDate <= DateTime.MinValue.AddYears(1) ? DateTime.MinValue : fiscalYearStartDate.AddYears(-1), true);
                }
                else {
					settingCurrentPeriod = Setting.GetRow(lazyContext, periodFrom);
                    settingPreviousPeriod = Setting.GetRow(lazyContext, periodFrom <= DateTime.MinValue.AddYears(1) ? DateTime.MinValue : periodFrom.AddYears(-1));
                    settingCurrentYear = Setting.GetRow(lazyContext, fiscalYearStartDate, true);
                    settingPreviousYear = Setting.GetRow(lazyContext, fiscalYearStartDate <= DateTime.MinValue.AddYears(1) ? DateTime.MinValue : fiscalYearStartDate.AddYears(-1), true);
                }

                periodCurrentYearFrom = useDateFilters ? dateFrom : settingCurrentPeriod.FiscalPeriodStartDate;
				periodCurrentYearTo = useDateFilters ? dateTo : settingCurrentPeriod.FiscalPeriodEndDate;

				if (periodCurrentYearFrom > DateTime.MinValue) {
					periodPreviousYearFrom = settingCurrentPeriod.FiscalPeriodPreviousStartDate;
					periodPreviousYearTo = settingCurrentPeriod.FiscalPeriodPreviousEndDate;
				}

				ytdCurrentYearFrom = settingCurrentYear.FiscalYearStartDate;
				ytdCurrentYearTo = settingCurrentYear.FiscalPeriodEndDate;

				if (periodCurrentYearFrom > DateTime.MinValue) {
					ytdPreviousYearFrom = settingPreviousYear.FiscalYearStartDate;

					if (chartOfAccountTypeId == (int)ChartOfAccountType.BalanceSheet) {
						ytdPreviousYearTo = settingPreviousYear.FiscalYearEndDate;
					}
					else {
						ytdPreviousYearTo = settingPreviousPeriod.FiscalPeriodEndDate;
					}
				}
			}

			decimal periodBudgetProfit = 0;
			decimal ytdBudgetProfit = 0;

			decimal periodCurrentYearProfit = 0;
			decimal periodPreviousYearProfit = 0;

			decimal ytdCurrentYearUndistributedProfit = 0;
			decimal ytdPreviousYearUndistributedProfit = 0;

			decimal ytdCurrentYearRetainedProfit = 0;
			decimal ytdPreviousYearRetainedProfit = 0;

			var chartOfAccounts = lazyContext.ChartOfAccount.Include(t => t.ChartOfAccountRoles).Include(t => t.ChartOfAccountBudgets).ThenInclude(t => t.SettingDetail).Where(t => t.Id > 0);

			if (currentDefaultAgencyId > 0)
				chartOfAccounts = chartOfAccounts.Where(t => t.AgencyId == currentDefaultAgencyId);

			var transactionDetail = lazyContext.TransactionDetail.Include(t => t.Transaction).Include(t => t.ChartOfAccount).Where(t => t.LedgerType == LedgerType.GeneralLedger);

			if (userRoleId != UserRole.SystemAdministrator.Id)
				chartOfAccounts = chartOfAccounts.Where(t1 => t1.ChartOfAccountRoles.Count == 0 || t1.ChartOfAccountRoles.Any(t2 => t2.RoleId == userRoleId));

			if (agencyId > 0) {
				chartOfAccounts = chartOfAccounts.Where(t => t.AgencyId == agencyId);
				transactionDetail = transactionDetail.Where(t => t.ChartOfAccount.AgencyId == agencyId);
			}

			if (chartOfAccountTypeId >= 0) {
				chartOfAccounts = chartOfAccounts.Where(t => (int)t.ChartOfAccountType == chartOfAccountTypeId);
			}
			else {
				chartOfAccounts = chartOfAccounts.Where(t => t.RowType != RowType.Header && t.RowType != RowType.UndistributedProfits && t.RowType != RowType.Total);

				if (chartOfAccountTypeId == -2) {
					if (accountCategory != AccountCategory.None)
						chartOfAccounts = chartOfAccounts.Where(t => t.AccountCategory == accountCategory);

					if (!string.IsNullOrEmpty(text)) {
						text = text.Trim().ToLower();
						chartOfAccounts = chartOfAccounts.Where(t => t.Code.ToLower().Contains(text) || t.Name.ToLower().Contains(text));
					}
				}
			}

			if (chartOfAccountTypeId == (int)ChartOfAccountType.BalanceSheet) {
				chartOfAccounts = chartOfAccounts.Where(t => t.ChartOfAccountType == ChartOfAccountType.BalanceSheet);

				if (transactionViewOption != TransactionViewOption.CurrentPrevious) {
					periodBudgetProfit = lazyContext.ChartOfAccountBudget.Include(t => t.ChartOfAccount).Where(t => t.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.ProfitLoss && t.SettingDetail.FiscalPeriodEndDate >= periodCurrentYearFrom && t.SettingDetail.FiscalPeriodEndDate <= periodCurrentYearTo).Sum(t => (decimal?)t.Amount) ?? 0;
					periodCurrentYearProfit = transactionDetail.Where(t => t.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.ProfitLoss && t.Transaction.DocumentDate >= periodCurrentYearFrom && t.Transaction.DocumentDate <= periodCurrentYearTo).Sum(t3 => (decimal?)(t3.Amount + t3.Tax)) ?? 0;
					periodPreviousYearProfit = transactionDetail.Where(t => t.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.ProfitLoss && t.Transaction.DocumentDate >= periodPreviousYearFrom && t.Transaction.DocumentDate <= periodPreviousYearTo).Sum(t3 => (decimal?)(t3.Amount + t3.Tax)) ?? 0;
					ytdBudgetProfit = lazyContext.ChartOfAccountBudget.Include(t => t.ChartOfAccount).Where(t => t.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.ProfitLoss && t.SettingDetail.FiscalPeriodEndDate >= ytdCurrentYearFrom && t.SettingDetail.FiscalPeriodEndDate <= periodCurrentYearTo).Sum(t => (decimal?)t.Amount) ?? 0;
				}

				ytdPreviousYearUndistributedProfit = transactionDetail.Where(t => t.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.ProfitLoss && t.Transaction.DocumentDate >= ytdPreviousYearFrom && t.Transaction.DocumentDate <= ytdPreviousYearTo).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
			}
			else if (chartOfAccountTypeId == (int)ChartOfAccountType.ProfitLoss) {
				chartOfAccounts = chartOfAccounts.Where(t => t.ChartOfAccountType == ChartOfAccountType.ProfitLoss);
				ytdPreviousYearUndistributedProfit = transactionDetail.Where(t => t.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.ProfitLoss && t.Transaction.DocumentDate >= ytdPreviousYearFrom && t.Transaction.DocumentDate <= periodPreviousYearTo).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
			}

			ytdCurrentYearUndistributedProfit = transactionDetail.Where(t => t.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.ProfitLoss && t.Transaction.DocumentDate >= ytdCurrentYearFrom && t.Transaction.DocumentDate <= periodCurrentYearTo).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;

			ytdPreviousYearRetainedProfit = transactionDetail.Where(t => t.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.ProfitLoss && t.Transaction.DocumentDate < ytdPreviousYearFrom).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
			ytdCurrentYearRetainedProfit = transactionDetail.Where(t => t.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.ProfitLoss && t.Transaction.DocumentDate < ytdCurrentYearFrom).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;

			var totalGroupLevel = lazyContext.ChartOfAccount.Where(t1 => t1.RowType == RowType.Total).OrderBy(t1 => useAltReportingCode ? t1.AltReportingCode : t1.Code).AsQueryable();

			if (userRoleId != UserRole.SystemAdministrator.Id)
				totalGroupLevel = totalGroupLevel.Include(t3 => t3.ChartOfAccountRoles).Where(t1 => t1.ChartOfAccountRoles.Count == 0 || t1.ChartOfAccountRoles.Any(t2 => t2.RoleId == userRoleId));

			var q = from t1 in chartOfAccounts.ToList()
					from t2 in t1.ChartOfAccountBudgets.Where(t3 => t3.SettingDetail.FiscalPeriodEndDate >= periodCurrentYearFrom && t3.SettingDetail.FiscalPeriodEndDate <= periodCurrentYearTo).ToList().DefaultIfEmpty()
					let TransactionDetail = transactionDetail.Where(t3 => t3.ChartOfAccountId == t1.Id).ToList()
					let TotalGroupLevel = totalGroupLevel.Where(t3 => t3.AgencyId == t1.AgencyId).ToList()
					orderby useAltReportingCode ? t1.AltReportingCode : t1.Code
					select new GeneralLedger {
						ChartOfAccount = t1,
						Code = useAltReportingCode ? t1.AltReportingCode : t1.Code,
						Name = t1.Name,
						TotalGroupLevel = (TotalGroupLevel.Find(t3 => string.Compare(t1.Code, t3.Code) <= 0) ?? new ChartOfAccount()).TotalLevel,

						PeriodCurrentYear = transactionViewOption == TransactionViewOption.CurrentPrevious ? 0
							: t1.RowType == RowType.UndistributedProfits ? periodCurrentYearProfit
							: TransactionDetail.Where(t3 => t3.Transaction.DocumentDate >= periodCurrentYearFrom && t3.Transaction.DocumentDate <= periodCurrentYearTo).Sum(t3 => (decimal?)(t3.Amount + t3.Tax)) ?? 0,

						PeriodPreviousYear = transactionViewOption == TransactionViewOption.CurrentPrevious ? 0
							: t1.RowType == RowType.UndistributedProfits ? periodPreviousYearProfit
							: TransactionDetail.Where(t3 => t3.Transaction.DocumentDate >= periodPreviousYearFrom && t3.Transaction.DocumentDate <= periodPreviousYearTo).Sum(t3 => (decimal?)(t3.Amount + t3.Tax)) ?? 0,

						PeriodBudget = transactionViewOption == TransactionViewOption.CurrentPrevious || transactionViewOption == TransactionViewOption.CurrentPreviousVariance ? 0
							: t1.RowType == RowType.UndistributedProfits ? periodBudgetProfit : t2 == null ? 0 : t2.Amount,

						YtdPreviousYear = t1.RowType == RowType.UndistributedProfits ? ytdPreviousYearUndistributedProfit
							: t1.RowType == RowType.RetainedProfits ? ytdPreviousYearRetainedProfit
							: chartOfAccountTypeId == (int)ChartOfAccountType.BalanceSheet ? (TransactionDetail.Where(t3 => t3.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.BalanceSheet && t3.Transaction.DocumentDate <= ytdPreviousYearTo).Sum(t3 => (decimal?)(t3.Amount + t3.Tax)) ?? 0)
							: chartOfAccountTypeId == (int)ChartOfAccountType.ProfitLoss ? (TransactionDetail.Where(t3 => t3.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.ProfitLoss && t3.Transaction.DocumentDate >= ytdPreviousYearFrom && t3.Transaction.DocumentDate <= periodPreviousYearTo).Sum(t3 => (decimal?)(t3.Amount + t3.Tax)) ?? 0)
                            : (TransactionDetail.Where(t => ((t.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.BalanceSheet && reportSource == ReportSourceGeneralLedger.TrialBalance) || t.Transaction.DocumentDate >= ytdPreviousYearFrom) && t.Transaction.DocumentDate <= periodPreviousYearTo).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0),

                        YtdCurrentYear = t1.RowType == RowType.UndistributedProfits ? ytdCurrentYearUndistributedProfit
							: t1.RowType == RowType.RetainedProfits ? ytdCurrentYearRetainedProfit
							: TransactionDetail.Where(t3 => (t3.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.BalanceSheet || t3.Transaction.DocumentDate >= ytdCurrentYearFrom) && t3.Transaction.DocumentDate <= periodCurrentYearTo).Sum(t3 => (decimal?)(t3.Amount + t3.Tax)) ?? 0,

						YtdBudget = transactionViewOption == TransactionViewOption.CurrentPrevious || transactionViewOption == TransactionViewOption.CurrentPreviousVariance ? 0
							: t1.RowType == RowType.UndistributedProfits ? ytdBudgetProfit : t1.ChartOfAccountBudgets.Where(t3 => t3.SettingDetail.FiscalPeriodEndDate >= ytdCurrentYearFrom && t3.SettingDetail.FiscalPeriodEndDate <= periodCurrentYearTo).Sum(t3 => (decimal?)t3.Amount) ?? 0
					};

			if (excludeZeroBalances) {
				if (chartOfAccountTypeId == -2) {
					q = q.Where(t => t.ChartOfAccount.RowType == RowType.Normal || t.ChartOfAccount.RowType == RowType.RetainedProfits);

					switch (transactionViewOption) {
						case TransactionViewOption.CurrentPrevious:
							q = q.Where(t => t.YtdCurrentYear != 0 || t.YtdPreviousYear != 0);
							break;
						case TransactionViewOption.CurrentPreviousVariance:
							q = q.Where(t => t.PeriodCurrentYear != 0 || t.PeriodPreviousYear != 0 || t.YtdCurrentYear != 0 || t.YtdPreviousYear != 0);
							break;
						case TransactionViewOption.CurrentBudgetVariance:
							q = q.Where(t => t.PeriodCurrentYear != 0 || t.PeriodBudget != 0 || t.YtdCurrentYear != 0 || t.YtdBudget != 0);
							break;
						case TransactionViewOption.CurrentBudgetPrevious:
							q = q.Where(t => t.PeriodCurrentYear != 0 || t.PeriodBudget != 0 || t.PeriodPreviousYear != 0 || t.YtdCurrentYear != 0 || t.YtdBudget != 0 || t.YtdPreviousYear != 0);
							break;
					}
				}
				else {
					switch (transactionViewOption) {
						case TransactionViewOption.CurrentPrevious:
							q = q.Where(t => t.ChartOfAccount.RowType == RowType.Header || t.ChartOfAccount.RowType == RowType.UndistributedProfits || t.ChartOfAccount.RowType == RowType.Total || t.YtdCurrentYear != 0 || t.YtdPreviousYear != 0);
							break;
						case TransactionViewOption.CurrentPreviousVariance:
							q = q.Where(t => t.ChartOfAccount.RowType == RowType.Header || t.ChartOfAccount.RowType == RowType.UndistributedProfits || t.ChartOfAccount.RowType == RowType.Total || t.PeriodCurrentYear != 0 || t.PeriodPreviousYear != 0 || t.YtdCurrentYear != 0 || t.YtdPreviousYear != 0);
							break;
						case TransactionViewOption.CurrentBudgetVariance:
							q = q.Where(t => t.ChartOfAccount.RowType == RowType.Header || t.ChartOfAccount.RowType == RowType.UndistributedProfits || t.ChartOfAccount.RowType == RowType.Total || t.PeriodCurrentYear != 0 || t.PeriodBudget != 0 || t.YtdCurrentYear != 0 || t.YtdBudget != 0);
							break;
						case TransactionViewOption.CurrentBudgetPrevious:
							q = q.Where(t => t.ChartOfAccount.RowType == RowType.Header || t.ChartOfAccount.RowType == RowType.UndistributedProfits || t.ChartOfAccount.RowType == RowType.Total || t.PeriodCurrentYear != 0 || t.PeriodBudget != 0 || t.PeriodPreviousYear != 0 || t.YtdCurrentYear != 0 || t.YtdBudget != 0 || t.YtdPreviousYear != 0);
							break;
					}
				}
			}

			return q.ToList();
		}

        public static IEnumerable<GeneralLedger> GetGeneralLedgerTransactionReportQuery(AppLazyContext lazyContext, int agencyId, string userRoleId, TransactionViewOption transactionViewOption, DateTime fiscalYearStartDate, DateTime previousFiscalYearStartDate, DateTime dateFrom, DateTime dateTo, TransactionType transactionType, ChartOfAccountType chartOfAccountType, AccountCategory accountCategory, bool useAltReportingCode, bool includeMonthlyTotals, int[] chartOfAccountIds) {
            if (transactionType == TransactionType.CreditNote)
                transactionType = TransactionType.Invoice;

            var chartOfAccount = lazyContext.ChartOfAccount.Where(t1 => t1.Id > 0 && (t1.RowType == RowType.Normal || t1.RowType == RowType.RetainedProfits) && (userRoleId == UserRole.SystemAdministrator.Id || t1.ChartOfAccountRoles.Count == 0 || t1.ChartOfAccountRoles.Any(t2 => t2.RoleId == userRoleId)));

            if (agencyId > 0)
                chartOfAccount = chartOfAccount.Where(t => t.AgencyId == agencyId);

            if (chartOfAccountType != ChartOfAccountType.NotSpecified)
                chartOfAccount = chartOfAccount.Where(t => t.ChartOfAccountType == chartOfAccountType);

            if (accountCategory != AccountCategory.None)
                chartOfAccount = chartOfAccount.Where(t => t.AccountCategory == accountCategory);

            if (chartOfAccountIds != null)
                chartOfAccount = chartOfAccount.Where(t => chartOfAccountIds.Contains(t.Id));

            var transactionDetail = lazyContext.TransactionDetail.Where(t1 => t1.LedgerType == LedgerType.GeneralLedger);
            var transactionDetailPeriod = transactionDetail;

            if (transactionType != TransactionType.All) {
                transactionDetail = transactionDetail.Where(t => t.Transaction.TransactionType == transactionType);
                transactionDetailPeriod = transactionDetail.Where(t => t.Transaction.TransactionType == transactionType);
            }

            if (agencyId > 0) {
                transactionDetail = transactionDetail.Where(t => t.ChartOfAccount.AgencyId == agencyId);
                transactionDetailPeriod = transactionDetailPeriod.Where(t => t.ChartOfAccount.AgencyId == agencyId);
            }

            if (dateFrom != DateTime.MinValue)
                transactionDetail = transactionDetail.Where(t => t.Transaction.DocumentDate >= dateFrom);

            if (dateTo != DateTime.MinValue)
                transactionDetail = transactionDetail.Where(t => t.Transaction.DocumentDate <= dateTo);

            return from ChartOfAccount in chartOfAccount.AsEnumerable()
                   let TransactionDetail = ChartOfAccount.RowType == RowType.RetainedProfits ? transactionDetail : transactionDetail.Where(t => t.ChartOfAccountId == ChartOfAccount.Id)
                   let TransactionDetailPeriod = ChartOfAccount.RowType == RowType.RetainedProfits ? transactionDetailPeriod : transactionDetailPeriod.Where(t => t.ChartOfAccountId == ChartOfAccount.Id)
                   orderby useAltReportingCode ? ChartOfAccount.AltReportingCode : ChartOfAccount.Code
                   select new GeneralLedger {
                       ChartOfAccount = ChartOfAccount,
                       Code = useAltReportingCode ? ChartOfAccount.AltReportingCode : ChartOfAccount.Code,
                       Name = ChartOfAccount.Name,
                       TransactionDetail = ChartOfAccount.RowType == RowType.RetainedProfits ? TransactionDetail.Take(0) : TransactionDetail,
                       TransactionDetailPeriod = ChartOfAccount.RowType == RowType.RetainedProfits ? TransactionDetailPeriod.Take(0) : TransactionDetailPeriod,
                       Period = GetGeneralLedgerPeriodRow(ChartOfAccount, TransactionDetailPeriod, transactionViewOption, fiscalYearStartDate, previousFiscalYearStartDate, dateTo, includeMonthlyTotals)
                   };
        }

        private static TransactionDetailPeriodReportModel GetGeneralLedgerPeriodRow(ChartOfAccount chartOfAccount, IQueryable<TransactionDetail> transactionDetail, TransactionViewOption transactionViewOption, DateTime fiscalYearStartDate, DateTime previousFiscalYearStartDate, DateTime dateTo, bool includeMonthlyTotals) {
			DateTime currentMonthFrom = fiscalYearStartDate;
			DateTime currentMonthTo = dateTo;

			var q = new TransactionDetailPeriodReportModel {
				YtdBalance = chartOfAccount.RowType == RowType.RetainedProfits ? 0
					: transactionDetail.Where(t => t.Transaction.DocumentDate <= currentMonthTo).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0,

				PreviousYearBalance = chartOfAccount.RowType == RowType.RetainedProfits ? transactionDetail.Where(t => t.ChartOfAccount.ChartOfAccountType == ChartOfAccountType.ProfitLoss && t.Transaction.DocumentDate < fiscalYearStartDate).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0
					: transactionDetail.Where(t => t.Transaction.DocumentDate < fiscalYearStartDate).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0
			};

			if (!includeMonthlyTotals || chartOfAccount.RowType == RowType.RetainedProfits)
				return q;

			for (int i = 0; i < 12; i++) {
				currentMonthFrom = fiscalYearStartDate.AddMonths(i);
				currentMonthTo = currentMonthFrom.AddMonths(1).AddDays(-1);

				DateTime previousMonthFrom = previousFiscalYearStartDate.AddMonths(i);
				DateTime previousMonthTo = previousMonthFrom.AddMonths(1).AddDays(-1);

				decimal currentValue = transactionDetail.Where(t => t.Transaction.DocumentDate >= currentMonthFrom && t.Transaction.DocumentDate <= currentMonthTo).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				decimal previousValue = 0;
				decimal budgetValue = 0;

				if (transactionViewOption == TransactionViewOption.CurrentPreviousVariance || transactionViewOption == TransactionViewOption.CurrentBudgetPrevious)
					previousValue = transactionDetail.Where(t => t.Transaction.DocumentDate >= previousMonthFrom && t.Transaction.DocumentDate <= previousMonthTo).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;

				if (transactionViewOption == TransactionViewOption.CurrentBudgetVariance || transactionViewOption == TransactionViewOption.CurrentBudgetPrevious)
					budgetValue = chartOfAccount.ChartOfAccountBudgets.Where(t => t.SettingDetail.FiscalPeriodEndDate == currentMonthTo).Sum(t => (decimal?)t.Amount) ?? 0;

				q.Period[i] = currentMonthFrom.ToString("MMM-yyyy");
				q.Row1Value[i] = currentValue;
				q.Row2Value[i] = transactionViewOption == TransactionViewOption.CurrentPreviousVariance ? previousValue : budgetValue;
				q.Row3Value[i] = transactionViewOption == TransactionViewOption.CurrentPreviousVariance ? currentValue - previousValue : transactionViewOption == TransactionViewOption.CurrentBudgetVariance ? currentValue - budgetValue : previousValue;
			}

			return q;
		}

		public static IQueryable<GeneralLedger> GetGeneralLedgerBudgetQuery(AppMainContext context, int agencyId, string userRoleId, DateTime fiscalYearStartDate) {
			var q = context.ChartOfAccount.Include(t => t.ChartOfAccountBudgets).ThenInclude(t => t.SettingDetail).Where(t1 => t1.AgencyId == agencyId && (t1.RowType == RowType.Normal || t1.RowType == RowType.RetainedProfits) && (userRoleId == UserRole.SystemAdministrator.Id || t1.ChartOfAccountRoles.Count == 0 || t1.ChartOfAccountRoles.Any(t2 => t2.RoleId == userRoleId))).OrderBy(t => t.Code);

			return q.Select(row => new GeneralLedger {
				ChartOfAccount = row,
				Code = row.Code,
				Name = row.Name,
				Period = GetGeneralLedgerBudgetRow(row.ChartOfAccountBudgets, fiscalYearStartDate)
			});
		}

		private static TransactionDetailPeriodReportModel GetGeneralLedgerBudgetRow(IEnumerable<ChartOfAccountBudget> budget, DateTime fiscalYearStartDate) {
			var q = new TransactionDetailPeriodReportModel();

			for (int i = 0; i < 12; i++) {
				DateTime currentMonthFrom = fiscalYearStartDate.AddMonths(i);
				DateTime currentMonthTo = currentMonthFrom.AddMonths(1).AddDays(-1);
				q.Period[i] = currentMonthFrom.ToString("MMM-yyyy");
				q.Row1Value[i] = budget.Where(t => t.SettingDetail.FiscalPeriodEndDate == currentMonthTo).Sum(t => (decimal?)t.Amount) ?? 0;
			}

			return q;
		}
	}
}