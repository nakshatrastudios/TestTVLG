using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.CreditorLedger;
using Travelog.Biz.Dao.DebtorLedger;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;

namespace Travelog.Biz.Dao.Accounting {
    public partial class Receipt {
		[NotMapped]
		public DocumentStatus DocumentStatus {
			get {
				return (DocumentStatus)(ReceiptDetails.Min(t => (int?)t.DocumentStatus) ?? -1);
			}
		}

		[NotMapped]
		public ReversalStatus ReversalStatus {
			get {
				return (ReversalStatus)(ReceiptDetails.Min(t => (int?)t.ReversalStatus) ?? 0);
			}
		}

		[NotMapped]
		public AccountType EffectiveAccountType {
			get {
				switch (AccountType) {
					default:
						return AccountType;
					case AccountType.GeneralLedger:
						return TripId > 0 ? AccountType.Client : DebtorId > 0 ? AccountType.Debtor : CreditorId > 0 ? AccountType.Creditor : AccountType.GeneralLedger;
				}
			}
		}

		[NotMapped]
		public AccountType TransactionAccountType {
			get {
				switch (AccountType) {
					default:
						return AccountType;
					case AccountType.Creditor:
						if (ReceiptType == ReceiptType.OtherCommission)
							return AccountType.GeneralLedger;

						return AccountType.Client;
					case AccountType.GeneralLedger:
						return DebtorId > 0 ? AccountType.Debtor : CreditorId > 0 ? AccountType.Creditor : ChartOfAccountId > 0 ? AccountType.GeneralLedger : TripId > 0 ? AccountType.Client : AccountType.None;
				}
			}
		}

		[NotMapped]
		public bool IsClientAccountLocked {
			get {
				return Id > 0 && (ReceiptType == ReceiptType.Receipt || ReceiptType == ReceiptType.Refund || ((EffectiveAccountType == AccountType.Client || EffectiveAccountType == AccountType.Debtor) && ReceiptType == ReceiptType.Admin)) && ReceiptDetails.Count > 1;
			}
		}

		[NotMapped]
		public bool IsTaxApplicable {
			get {
				return AccountType == AccountType.Creditor && !(ReceiptType == ReceiptType.OtherCommission && SupplierCommissionType == SupplierCommissionType.Creditor) ? SaleType.IsTaxApplicable
					: AccountType == AccountType.GeneralLedger && ReceiptType == ReceiptType.Admin && ChartOfAccount.IsTaxApplicable;
			}
		}

		[NotMapped]
		public bool IsChartOfAccountTaxApplicable {
			get {
				return AccountType == AccountType.GeneralLedger && ReceiptType == ReceiptType.Admin && ChartOfAccount.IsTaxApplicable;
			}
		}

		[NotMapped]
		public bool IsSaleTypeTaxApplicable {
			get {
				return AccountType == AccountType.Creditor && !(ReceiptType == ReceiptType.OtherCommission && SupplierCommissionType == SupplierCommissionType.Creditor) && SaleType.IsTaxApplicable;
			}
		}

		[NotMapped]
		public decimal NonCommissionableGross {
			get {
				return NonCommissionable + NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CommissionGross {
			get {
				return Commission + CommissionTax;
			}
		}

		[NotMapped]
		public decimal DiscountGross {
			get {
				return Discount + DiscountTax;
			}
		}

		[NotMapped]
		public decimal TotalLoyaltySchemePointsCollected {
			get {
				return ReceiptDetails.Sum(t => (decimal?)t.LoyaltySchemePointsCollected) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalLoyaltySchemePointsCost {
			get {
				return ReceiptDetails.Sum(t => (decimal?)t.LoyaltySchemePointsCost) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalLoyaltySchemeValue {
			get {
				return ReceiptDetails.Sum(t => (decimal?)t.LoyaltySchemeValue) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalMerchantFee {
			get {
				return ReceiptDetails.Sum(t => (decimal?)(t.MerchantFee + t.MerchantFeeTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal ClientRefundGross {
			get {
				return ClientRefund + ClientRefundTax;
			}
		}

		[NotMapped]
		public decimal ClientRefund {
			get {
				return AmountToBank + Commission - Discount - CancellationFee;
			}
		}

		[NotMapped]
		public decimal ClientRefundTax {
			get {
				return AmountToBankTax + CommissionTax - DiscountTax - CancellationFeeTax;
			}
		}

		[NotMapped]
		public decimal CommissionRateBySupplierCreditorSaleType {
			get {
				if (Supplier?.CommissionRate > 0) {
					return Supplier.CommissionRate;
				}
				else if (Creditor?.CommissionRate > 0) {
					return Creditor.CommissionRate;
				}
				else if (SaleType?.CommissionRate > 0) {
					return SaleType.CommissionRate;
				}

				return 0;
			}
		}

		[NotMapped]
		public string AccountName {
			get {
				return Id <= 0 ? "Not Specified"
					: IsDeposit ? BankAccount.ChartOfAccountId <= 0 ? "Not Specified" : BankAccount.ChartOfAccount.AccountName
					: TransactionAccountType == AccountType.Client && ReceiptType != ReceiptType.VoucherCommission ? Trip == null || TripId <= 0 ? "Not Specified" : Trip.AccountName
					: TransactionAccountType == AccountType.Debtor ? Debtor == null || DebtorId <= 0 ? "Not Specified" : Debtor.AccountName
					: TransactionAccountType == AccountType.Creditor || ReceiptType == ReceiptType.VoucherCommission ? Creditor == null || CreditorId <= 0 ? "Not Specified" : Creditor.AccountName
					: ChartOfAccount == null || ChartOfAccountId <= 0 ? "Not Specified" : string.Format("{0}{1}", ChartOfAccount.AccountName, string.IsNullOrEmpty(Payer) ? string.Empty : string.Format(" - {0}", Payer));
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				return Id <= 0 ? "Not Specified"
					: IsDeposit ? string.Format(@"<a href=""/GeneralLedger/ChartOfAccounts/?id={0}"" target=""_blank"">{1}</a>", BankAccount.ChartOfAccount.Id, BankAccount.ChartOfAccount.AccountName)
					: TransactionAccountType == AccountType.Client && ReceiptType != ReceiptType.VoucherCommission ? Trip == null || TripId <= 0 ? "Not Specified" : string.Format(@"<a href=""/ClientLedger/Trip/?profileId={0}&tripId={1}"" target=""_blank"">{2}</a>", Trip.ProfileId, TripId, Trip.AccountName)
					: TransactionAccountType == AccountType.Debtor ? Debtor == null || DebtorId <= 0 ? "Not Specified" : string.Format(@"<a href=""/DebtorLedger/?id={0}"" target=""_blank"">{1}</a>", Debtor.Id, Debtor.AccountName)
					: TransactionAccountType == AccountType.Creditor || ReceiptType == ReceiptType.VoucherCommission ? Creditor == null || CreditorId <= 0 ? "Not Specified" : string.Format(@"<a href=""/CreditorLedger/?id={0}"" target=""_blank"">{1}</a>", Creditor.Id, Creditor.AccountName)
					: ChartOfAccount == null || ChartOfAccountId <= 0 ? "Not Specified" : string.Format(@"<a href=""/GeneralLedger/ChartOfAccounts/?id={0}"" target=""_blank"">{1}</a>", ChartOfAccount.Id, string.Format("{0}{1}", ChartOfAccount.AccountName, string.IsNullOrEmpty(Payer) ? string.Empty : string.Format(" - {0}", Payer)));
			}
		}

        [NotMapped]
        public string EmailRecipient {
            get {
                return TransactionAccountType == AccountType.Client && ReceiptType != ReceiptType.VoucherCommission ? Trip == null || TripId <= 0 ? string.Empty : Trip.ClientAccountType == ClientAccountType.Client ? Trip.Email : Trip.DebtorBookedBy.Email
                    : TransactionAccountType == AccountType.Debtor ? Debtor == null || DebtorId <= 0 ? string.Empty : Debtor.DefaultContact.Email ?? string.Empty
                    : TransactionAccountType == AccountType.Creditor || ReceiptType == ReceiptType.VoucherCommission ? Creditor == null || CreditorId <= 0 ? string.Empty : Creditor.DefaultContact.Email ?? string.Empty
                    : string.Empty;
            }
        }

        public string GetDocumentNoLink(string source) {
			return Transaction.GetDocumentNoLink(source, TransactionType.Receipt, Id, DocumentNo);
		}

		public string GetFormOfPaymentDetails() {
            return string.Format("{0} No {1}: {2} {3} on {4}", (ReceiptDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? "Refund" : "Receipt", DocumentNo, (ReceiptDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? "Refunded by" : "Paid with", string.Join("; ", ReceiptDetails.Where(t => t.FormOfPaymentId > 0).Select(t => t.FormOfPayment.Name).Distinct()), DocumentDate.ToShortDateStringExt()).Replace("by Not Specified ", string.Empty).Replace("with Not Specified ", string.Empty).Replace("by  on", "on").Replace("with  on", "on");
		}

		public decimal GetAmountToBankGross(int excludedReceiptDetailId = 0, decimal unsavedAmount = 0, decimal unsavedTax = 0) {
			return AccountType == AccountType.Creditor ? (ReceiptDetails.Where(t => t.Id != excludedReceiptDetailId).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) + unsavedAmount + unsavedTax : 0;
		}

		public decimal GetAmountToBank(int excludedReceiptDetailId = 0, decimal unsavedAmount = 0) {
			return AccountType == AccountType.Creditor ? (ReceiptDetails.Where(t => t.Id != excludedReceiptDetailId).Sum(t => (decimal?)t.Amount) ?? 0) + unsavedAmount : 0;
		}

		public decimal GetAmountToBankTax(int excludedReceiptDetailId = 0, decimal unsavedTax = 0) {
			return AccountType == AccountType.Creditor ? (ReceiptDetails.Where(t => t.Id != excludedReceiptDetailId).Sum(t => (decimal?)t.Tax) ?? 0) + unsavedTax : 0;
		}

		public decimal GetOriginalSaleTotalGross(int excludedReceiptDetailId = 0, decimal unsavedAmount = 0, decimal unsavedTax = 0) {
			return GetAmountToBankGross(excludedReceiptDetailId, unsavedAmount, unsavedTax) + CommissionGross + SupplierCancellationFee + SupplierCancellationFeeTax;
		}

		public decimal GetOriginalSaleTotal(int excludedReceiptDetailId = 0, decimal unsavedAmount = 0) {
			return GetAmountToBank(excludedReceiptDetailId, unsavedAmount) + Commission + SupplierCancellationFee;
		}

		public decimal GetOriginalSaleTotalTax(int excludedReceiptDetailId = 0, decimal unsavedTax = 0) {
			return GetAmountToBankTax(excludedReceiptDetailId, unsavedTax) + CommissionTax + SupplierCancellationFeeTax;
		}

		public bool ValidateTaxApplicability(bool isTaxApplicable) {
			if (ReceiptDetails.Count == 0)
				return true;

			return IsTaxApplicable == isTaxApplicable;
		}

		public bool ValidateChartOfAccountTaxApplicability(bool isTaxApplicable) {
			if (ReceiptDetails.Count == 0 || !(AccountType == AccountType.GeneralLedger && ReceiptType == ReceiptType.Admin))
				return true;

			return IsChartOfAccountTaxApplicable == isTaxApplicable;
		}

		public bool ValidateSaleTypeTaxApplicability(bool isTaxApplicable) {
			if (ReceiptDetails.Count == 0 || !(AccountType == AccountType.Creditor && !(ReceiptType == ReceiptType.OtherCommission && SupplierCommissionType == SupplierCommissionType.Creditor)))
				return true;

			return IsSaleTypeTaxApplicable == isTaxApplicable;
		}

		public decimal GetTotalAmountGross(bool useAmountToBank = true, int excludedReceiptDetailId = 0, decimal unsavedAmount = 0, decimal unsavedTax = 0) {
			return IsDeposit ? AmountToBank + AmountToBankTax : ReceiptType == ReceiptType.Refund ? (useAmountToBank ? AmountToBank + AmountToBankTax : ClientRefundGross) : ((ReceiptDetails.Where(t => t.Id != excludedReceiptDetailId).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) + unsavedAmount + unsavedTax + NonCommissionable + NonCommissionableTax - Discount - DiscountTax);
		}

		public decimal GetTotalAmount(bool useAmountToBank = true, int excludedReceiptDetailId = 0, decimal unsavedAmount = 0) {
			return IsDeposit ? AmountToBank : ReceiptType == ReceiptType.Refund ? (useAmountToBank ? AmountToBank : ClientRefund) : ((ReceiptDetails.Where(t => t.Id != excludedReceiptDetailId).Sum(t => (decimal?)t.Amount) ?? 0) + unsavedAmount + NonCommissionable - Discount);
		}

		public decimal GetTotalTax(bool useAmountToBank = true, int excludedReceiptDetailId = 0, decimal unsavedTax = 0) {
			return IsDeposit ? AmountToBankTax : ReceiptType == ReceiptType.Refund ? (useAmountToBank ? AmountToBankTax : ClientRefundTax) : ((ReceiptDetails.Where(t => t.Id != excludedReceiptDetailId).Sum(t => (decimal?)t.Tax) ?? 0) + unsavedTax + NonCommissionableTax - DiscountTax);
		}

		public decimal GetDocumentTotal(AppMainContext context) {
			return AccountType == AccountType.Creditor && ReceiptType != ReceiptType.VoucherCommission ? (context.Receipt.Where(t => t.Id == Id || (t.ReceiptType == ReceiptType && t.IsSplit && t.DocumentNo == DocumentNo)).Sum(t => (decimal?)(t.AmountToBank + t.AmountToBankTax)) ?? 0) : (context.ReceiptDetail.Include(t => t.Receipt).Where(t => t.ReceiptId == Id || (t.Receipt.ReceiptType == ReceiptType && t.Receipt.IsSplit && t.Receipt.DocumentNo == DocumentNo)).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) + (context.Receipt.Where(t => t.Id == Id || (t.ReceiptType == ReceiptType && t.IsSplit && t.DocumentNo == DocumentNo)).Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax - (t.Discount + t.DiscountTax))) ?? 0);
		}

		public static List<ReceiptMerchantFeeTxnDetailModel> GetReceiptMerchantFeeTxnDetailList(AppLazyContext lazyContext, int allocationGroupNo, AccountType accountType = AccountType.None) {
			var q = new List<ReceiptMerchantFeeTxnDetailModel>();

			if (allocationGroupNo == 0)
				return q;

			var debtorReceiptAllocations = lazyContext.TransactionDetailAllocation.Where(t1 => t1.ReceiptDetail.Receipt.Debtor.FormOfPayments.Any(t2 => t2.Id > 0 && t2.DebtorId > 0) && t1.GroupNo == allocationGroupNo);
            var clientReceiptAllocations = lazyContext.TransactionDetailAllocation.Where(t1 => !t1.ReceiptDetail.Receipt.Debtor.FormOfPayments.Any(t2 => t2.Id > 0 && t2.DebtorId > 0) && t1.GroupNo == allocationGroupNo);

            if (accountType != AccountType.None)
				clientReceiptAllocations = clientReceiptAllocations.Where(t => t.ReceiptDetail.Receipt.AccountType == accountType);

			if (!debtorReceiptAllocations.Any() || !clientReceiptAllocations.Any())
				return q;

			foreach (var debtorReceiptAllocation in debtorReceiptAllocations.ToList()) {
				var transaction = lazyContext.Transaction.SingleOrDefault(t => t.ReceiptId == debtorReceiptAllocation.ReceiptDetail.ReceiptId);

				q.AddRange(clientReceiptAllocations.Where(t => t.TransactionDetailId == debtorReceiptAllocation.TransactionDetailId).Select(row => new ReceiptMerchantFeeTxnDetailModel {
					Transaction = transaction,
					DebtorId = debtorReceiptAllocation.ReceiptDetail.Receipt.DebtorId,
                    ClientAgencyId = row.ReceiptDetail.Receipt.AgencyId,
                    ClientReceiptDetailId = row.ReceiptDetailId,
					DebtorReceiptNo = debtorReceiptAllocation.ReceiptDetail.Receipt.DocumentNo,
					DebtorReceiptDate = debtorReceiptAllocation.ReceiptDetail.Receipt.DocumentDate,
					ClientReceiptNo = row.ReceiptDetail.Receipt.DocumentNo,
					ClientReceiptDate = row.ReceiptDetail.Receipt.DocumentDate,
					Amount = row.MerchantFee,
					Tax = row.MerchantFeeTax
				}));
			}

			return q;
		}

		public static IQueryable<Receipt> GetMissingAutoTransferReceipts(AppMainContext context, int agencyId) {
			return context.Receipt.Include(t => t.ReceiptDetails).Where(t1 => !t1.IsLegacy
				&& t1.ReceiptType == ReceiptType.Transfer && (agencyId <= 0 || t1.AgencyId == agencyId) && t1.ReverseTransferReceiptId == -1
				&& !context.Receipt.Any(t2 => t2.ReverseTransferReceiptId == t1.Id && t2.ReverseTransferReceiptId > 0));
		}

		public static IQueryable<Receipt> GetMissingAutoSupplierOtherCommissionReceipts(AppMainContext context, int agencyId) {
			return context.Receipt.Include(t => t.ReceiptDetails) .Where(t1 => !t1.IsLegacy
				&& t1.ReceiptType == ReceiptType.OtherCommission && t1.SupplierCommissionType == SupplierCommissionType.Creditor
                && (agencyId <= 0 || t1.AgencyId == agencyId) && !context.NonBsp.Any(t2 => t2.SupplierOtherCommissionReceiptId == t1.Id && t2.SupplierOtherCommissionReceiptId > 0));
		}

		public bool CanEdit(bool isAdministrator, bool isAccounts, bool isSuperUser) {
            return !IsLegacy && (isSuperUser || (isAdministrator
                && (ReceiptType != ReceiptType.Transfer || (DocumentStatus == (ReverseTransferReceipt?.DocumentStatus ?? DocumentStatus) && ReversalStatus == (ReverseTransferReceipt?.ReversalStatus ?? ReversalStatus)))
                || (isAccounts && DocumentStatus == DocumentStatus.None) || (DocumentStatus == DocumentStatus.None && ReceiptType != ReceiptType.Admin && ReceiptType != ReceiptType.Transfer))
                && ReversalStatus == ReversalStatus.None && !Trip.IsLocked && !IsIssued && !IsDeposit
                && !SupplierOtherCommissionNonBsps.Any(t => t.PaymentId > 0)
                && !ReceiptDetails.Any(t1 => t1.Id > 0 && (t1.DepositDetailId > 0 || t1.BankAccountStatementId > 0 || t1.LoyaltySchemeNonBsps.Any(t2 => t2.PaymentId > 0) || t1.TransactionDetailAllocations.Count > 0)));
        }

        public bool CanDelete(bool isAdministrator, bool isAccounts, bool isSuperUser) {
			return CanEdit(isAdministrator, isAccounts, isSuperUser) || (!IsLegacy && (isAdministrator || isAccounts) && DocumentStatus == DocumentStatus.DepositedPaid && IsDeposit
				&& !ReceiptDetails.Any(t => t.Id > 0 && (t.BankAccountStatementId > 0 || t.TransactionDetailAllocations.Count > 0)));
		}

		public bool CanUndo(bool isBankReconciliation) {
			return !IsLegacy && isBankReconciliation && DocumentStatus == DocumentStatus.Closed;
		}

		public bool CanReverse() {
			return !IsLegacy && DocumentStatus != DocumentStatus.None && ReversalStatus != ReversalStatus.Reversed && ReceiptType != ReceiptType.Transfer && !Trip.IsLocked && !IsDeposit
				&& !ReceiptDetails.Any(t => t.Id > 0 && (t.DepositDetailId > 0 || t.BankAccountStatementId > 0 || t.TransactionDetailAllocations.Count > 0));
		}
	}

	public partial class ReceiptDetail {
        [NotMapped]
        public string DocumentReferences {
            get {
                return TransactionDetailAllocations == null ? string.Empty : string.Join(Environment.NewLine, TransactionDetailAllocations.Where(t => t.TransactionDetail.DebtorId == Receipt.DebtorId && t.Reference.Length > 0).Select(t => t.Reference).Distinct());
            }
        }

        [NotMapped]
		public bool LoyaltySchemeIsTaxApplicable {
			get {
				return LoyaltyScheme.LoyaltySchemeSaleType1.IsTaxApplicable || LoyaltyScheme.LoyaltySchemeSaleType2.IsTaxApplicable;
			}
		}

		[NotMapped]
		public decimal NonCommissionableGrossProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.NonCommissionableGross;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.NonCommissionableGross - (receiptDetail.Sum(t => (decimal?)t.NonCommissionableGrossBaseProRata) ?? 0);
				}

				return NonCommissionableGrossBaseProRata;
			}
		}

		[NotMapped]
		private decimal NonCommissionableGrossBaseProRata {
			get {
				decimal totalAmount = Receipt.ReceiptDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				decimal ratio = totalAmount == 0 ? (1 / (decimal)Receipt.ReceiptDetails.Count) : (Amount + Tax) / totalAmount;
				return Receipt.NonCommissionableGross * ratio;
			}
		}

		[NotMapped]
		public decimal ClientRefundGrossProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.ClientRefund + Receipt.ClientRefundTax;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.ClientRefund + Receipt.ClientRefundTax - (receiptDetail.Sum(t => (decimal?)(t.ClientRefundBaseProRata + t.ClientRefundTaxBaseProRata)) ?? 0);
				}

				return ClientRefundBaseProRata + ClientRefundTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal ClientRefundProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.ClientRefund;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.ClientRefund - (receiptDetail.Sum(t => (decimal?)t.ClientRefundBaseProRata) ?? 0);
				}

				return ClientRefundBaseProRata;
			}
		}

		[NotMapped]
		private decimal ClientRefundBaseProRata {
			get {
				decimal totalAmount = Receipt.ReceiptDetails.Sum(t => (decimal?)t.Amount) ?? 0;
				decimal ratio = totalAmount == 0 ? (1 / (decimal)Receipt.ReceiptDetails.Count) : Amount / totalAmount;
				return Receipt.ClientRefund * ratio;
			}
		}

		[NotMapped]
		public decimal ClientRefundTaxProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.ClientRefundTax;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.ClientRefundTax - (receiptDetail.Sum(t => (decimal?)t.ClientRefundTaxBaseProRata) ?? 0);
				}

				return ClientRefundTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal ClientRefundTaxBaseProRata {
			get {
				decimal totalTax = Receipt.ReceiptDetails.Sum(t => (decimal?)t.Tax) ?? 0;
				decimal ratio = totalTax == 0 ? (1 / (decimal)Receipt.ReceiptDetails.Count) : Tax / totalTax;
				return Receipt.ClientRefundTax * ratio;
			}
		}

		[NotMapped]
		public decimal OriginalSaleTotalGrossProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.OriginalSaleTotal + Receipt.OriginalSaleTotalTax;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.OriginalSaleTotal + Receipt.OriginalSaleTotalTax - receiptDetail.Sum(t => (decimal?)(t.OriginalSaleTotalBaseProRata + t.OriginalSaleTotalTaxBaseProRata)) ?? 0;
				}

				return OriginalSaleTotalBaseProRata + OriginalSaleTotalTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal OriginalSaleTotalProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.OriginalSaleTotal;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.OriginalSaleTotal - (receiptDetail.Sum(t => (decimal?)t.OriginalSaleTotalBaseProRata) ?? 0);
				}

				return OriginalSaleTotalBaseProRata;
			}
		}

		[NotMapped]
		private decimal OriginalSaleTotalBaseProRata {
			get {
				decimal totalAmount = Receipt.ReceiptDetails.Sum(t => (decimal?)t.Amount) ?? 0;
				decimal ratio = totalAmount == 0 ? (1 / (decimal)Receipt.ReceiptDetails.Count) : Amount / totalAmount;
				return Receipt.OriginalSaleTotal * ratio;
			}
		}

		[NotMapped]
		public decimal OriginalSaleTotalTaxProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.OriginalSaleTotalTax;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.OriginalSaleTotalTax - (receiptDetail.Sum(t => (decimal?)t.OriginalSaleTotalTaxBaseProRata) ?? 0);
				}

				return OriginalSaleTotalTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal OriginalSaleTotalTaxBaseProRata {
			get {
				decimal totalTax = Receipt.ReceiptDetails.Sum(t => (decimal?)t.Tax) ?? 0;
				decimal ratio = totalTax == 0 ? (1 / (decimal)Receipt.ReceiptDetails.Count) : Tax / totalTax;
				return Receipt.OriginalSaleTotalTax * ratio;
			}
		}

		[NotMapped]
		public decimal AmountToBankGrossProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.AmountToBank + Receipt.AmountToBankTax;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.AmountToBank + Receipt.AmountToBankTax - receiptDetail.Sum(t => (decimal?)(t.AmountToBankBaseProRata + t.AmountToBankTaxBaseProRata)) ?? 0;
				}

				return AmountToBankBaseProRata + AmountToBankTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal AmountToBankProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.AmountToBank;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.AmountToBank - (receiptDetail.Sum(t => (decimal?)t.AmountToBankBaseProRata) ?? 0);
				}

				return AmountToBankBaseProRata;
			}
		}

		[NotMapped]
		private decimal AmountToBankBaseProRata {
			get {
				decimal totalAmount = Receipt.ReceiptDetails.Sum(t => (decimal?)t.Amount) ?? 0;
				decimal ratio = totalAmount == 0 ? (1 / (decimal)Receipt.ReceiptDetails.Count) : Amount / totalAmount;
				return Receipt.AmountToBank * ratio;
			}
		}

		[NotMapped]
		public decimal AmountToBankTaxProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.AmountToBankTax;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.AmountToBankTax - (receiptDetail.Sum(t => (decimal?)t.AmountToBankTaxBaseProRata) ?? 0);
				}

				return AmountToBankTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal AmountToBankTaxBaseProRata {
			get {
				decimal totalTax = Receipt.ReceiptDetails.Sum(t => (decimal?)t.Tax) ?? 0;
				decimal ratio = totalTax == 0 ? (1 / (decimal)Receipt.ReceiptDetails.Count) : Tax / totalTax;
				return Receipt.AmountToBankTax * ratio;
			}
		}

		[NotMapped]
		public decimal CommissionGrossProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.Commission + Receipt.CommissionTax;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.Commission + Receipt.CommissionTax - receiptDetail.Sum(t => (decimal?)(t.CommissionBaseProRata + t.CommissionTaxBaseProRata)) ?? 0;
				}

				return CommissionBaseProRata + CommissionTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal CommissionProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.Commission;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.Commission - (receiptDetail.Sum(t => (decimal?)t.CommissionBaseProRata) ?? 0);
				}

				return CommissionBaseProRata;
			}
		}

		[NotMapped]
		private decimal CommissionBaseProRata {
			get {
				decimal totalAmount = Receipt.ReceiptDetails.Sum(t => (decimal?)t.Amount) ?? 0;
				decimal ratio = totalAmount == 0 ? (1 / (decimal)Receipt.ReceiptDetails.Count) : Amount / totalAmount;
				return Receipt.Commission * ratio;
			}
		}

		[NotMapped]
		public decimal CommissionTaxProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.CommissionTax;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.CommissionTax - (receiptDetail.Sum(t => (decimal?)t.CommissionTaxBaseProRata) ?? 0);
				}

				return CommissionTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal CommissionTaxBaseProRata {
			get {
				decimal totalTax = Receipt.ReceiptDetails.Sum(t => (decimal?)t.Tax) ?? 0;
				decimal ratio = totalTax == 0 ? (1 / (decimal)Receipt.ReceiptDetails.Count) : Tax / totalTax;
				return Receipt.CommissionTax * ratio;
			}
		}

		[NotMapped]
		public decimal DiscountGrossProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.Discount + Receipt.DiscountTax;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.Discount + Receipt.DiscountTax - receiptDetail.Sum(t => (decimal?)(t.DiscountBaseProRata + t.DiscountTaxBaseProRata)) ?? 0;
				}

				return DiscountBaseProRata + DiscountTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal DiscountProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.Discount;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.Discount - (receiptDetail.Sum(t => (decimal?)t.DiscountBaseProRata) ?? 0);
				}

				return DiscountBaseProRata;
			}
		}

		[NotMapped]
		private decimal DiscountBaseProRata {
			get {
				return Receipt.Discount * DiscountProRataRatio;
			}
		}

		[NotMapped]
		public decimal DiscountTaxProRata {
			get {
				if (Receipt.ReceiptDetails.Count <= 1) {
					return Receipt.DiscountTax;
				}
				else if (Receipt.ReceiptDetails.Last().Id == Id) {
					var receiptDetail = Receipt.ReceiptDetails.Where(t => t.Id != Id);
					return Receipt.DiscountTax - (receiptDetail.Sum(t => (decimal?)t.DiscountTaxBaseProRata) ?? 0);
				}

				return DiscountTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal DiscountTaxBaseProRata {
			get {
				return Receipt.DiscountTax * DiscountProRataRatio;
			}
		}

		[NotMapped]
		public decimal DiscountProRataRatio {
			get {
				decimal totalAmount = 0;

				if (Receipt.ReceiptDetails.Count == 1) {
					return 1;
				}
				else if (!Receipt.ReceiptDetails.Any(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)) {
					totalAmount = Receipt.ReceiptDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}
				else if (Receipt.IsCreditCardDiscountApplicable && FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
					totalAmount = Receipt.ReceiptDetails.Where(t => t.Receipt.IsCreditCardDiscountApplicable && t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}

				return totalAmount == 0 ? 0 : (Amount + Tax) / totalAmount;
			}
		}

		[NotMapped]
		public decimal AmountNet {
			get {
				return Amount + Tax - MerchantFee - MerchantFeeTax;
			}
		}

        public DocumentStatus GetDocumentStatus() {
            if (FormOfPayment.DebtorId > 0) {
                return DocumentStatus.Closed;
            }
            else if (!FormOfPayment.IncludeInDeposit) {
                return DocumentStatus.DepositedPaid;
            }

            return DocumentStatus.Open;
        }

		public string GetDocumentNo(int transactionDetailId) {
			var q = TransactionDetails.SingleOrDefault(t => t.Id == transactionDetailId);

			if (q == null)
				throw new InvalidOperationException("Document not found.");

			switch (q.Transaction.TransactionType) {
				default:
					throw new InvalidOperationException("Transaction Type is invalid.");
				case TransactionType.Receipt:
					return q.ReceiptDetail.Receipt.DocumentNo;
				case TransactionType.Payment:
					return q.PaymentDetail.Payment.DocumentNo;
				case TransactionType.Invoice:
					return q.InvoiceDetail.Invoice.DocumentNo;
				case TransactionType.Journal:
					return q.JournalDetail.Journal.DocumentNo;
			}
		}

		public static IQueryable<ReceiptDetail> GetMissingAutoLoyaltySchemeReceiptDetails(AppMainContext context, int agencyId) {
			return context.ReceiptDetail.Include(t => t.FormOfPayment).Where(t1 => !t1.Receipt.IsLegacy
				&& t1.FormOfPayment.FormOfPaymentType == FormOfPaymentType.LoyaltyScheme && (agencyId <= 0 || t1.Receipt.AgencyId == agencyId)
                && !context.NonBsp.Any(t2 => t2.LoyaltySchemeReceiptDetailId == t1.Id && t2.LoyaltySchemeReceiptDetailId > 0));
		}

		public void GetLoyaltySchemeCalculations(string source, decimal receiptAmount, ref decimal pointsCollected, ref decimal pointsCost, ref decimal loyaltySchemeValue, ref bool isTaxApplicable) {
			if (LoyaltyScheme == null) {
				pointsCollected = 0;
				pointsCost = 0;
				loyaltySchemeValue = 0;
				isTaxApplicable = false;
				return;
			}

			if (source == "Amount") {
				if (LoyaltyScheme.LoyaltySchemeValueIsReceiptAmount) {
					source = "LoyaltySchemeId";
				}
				else {
					return;
				}
			}

			if (source != "LoyaltySchemeId" && source != "PointsCollected" && source != "PointsCost" && source != "LoyaltySchemeValue")
				throw new InvalidOperationException("Source is invalid.");

			if (source == "LoyaltySchemeId") {
				if (LoyaltyScheme.LoyaltySchemeValueIsReceiptAmount) {
					loyaltySchemeValue = receiptAmount;
				}
				else {
					pointsCollected = 0;
					pointsCost = 0;
					loyaltySchemeValue = 0;
					isTaxApplicable = false;
					return;
				}
			}

			if (source == "LoyaltySchemeId" || source == "LoyaltySchemeValue")
				pointsCollected = LoyaltyScheme.LoyaltySchemePointValue == 0 ? 0 : loyaltySchemeValue / LoyaltyScheme.LoyaltySchemePointValue;

			switch (LoyaltyScheme.LoyaltySchemePointsRoundingMethod) {
				default:
					pointsCollected = Math.Round(pointsCollected, 2);
					break;
				case LoyaltySchemePointsRoundingMethod.Down:
					pointsCollected = Math.Sign(pointsCollected) * Math.Floor(Math.Abs(pointsCollected));
					break;
				case LoyaltySchemePointsRoundingMethod.Up:
					pointsCollected = Math.Sign(pointsCollected) * Math.Ceiling(Math.Abs(pointsCollected));
					break;
				case LoyaltySchemePointsRoundingMethod.Nearest:
					if (pointsCollected < 0) {
						pointsCollected -= .5m;
					}
					else if (pointsCollected > 0) {
						pointsCollected += .5m;
					}

					pointsCollected = Math.Ceiling(pointsCollected);
					break;
				case LoyaltySchemePointsRoundingMethod.Banker:
					pointsCollected = Math.Round(pointsCollected, 0, MidpointRounding.ToEven);
					break;
			}

			if (source != "LoyaltySchemeId" && source != "LoyaltySchemeValue" && source != "PointsCollected")
				return;

			pointsCost = 0;

            for (int i = 1; i <= 2; i++) {
				switch (i) {
					case 1:
						if (LoyaltyScheme.LoyaltySchemeSaleType1Id <= 0)
							continue;

						pointsCost += Math.Round(LoyaltyScheme.LoyaltySchemePointCost1 * pointsCollected, 2);

						if (!isTaxApplicable)
							isTaxApplicable = LoyaltyScheme.LoyaltySchemeSaleType1.IsTaxApplicable;

						break;
					case 2:
						if (LoyaltyScheme.LoyaltySchemeSaleType2Id <= 0)
							continue;

						pointsCost += Math.Round(LoyaltyScheme.LoyaltySchemePointCost2 * pointsCollected, 2);

						if (!isTaxApplicable)
							isTaxApplicable = LoyaltyScheme.LoyaltySchemeSaleType2.IsTaxApplicable;

						break;
				}
			}
		}

        public decimal GetMerchantFee(int customerId) {
            return FormOfPayment.Debtor.IsCreditCardDebtor ? Math.Round((Amount + Tax) * FormOfPayment.MerchantFeeRate - GetMerchantFeeTax(customerId), 2) : 0;
        }

        public decimal GetMerchantFeeTax(int customerId) {
            return FormOfPayment.Debtor.IsCreditCardDebtor ? IsTaxApplicable ? Math.Round((Amount + Tax) * FormOfPayment.MerchantFeeRate * CustomerSettings.GetTaxRate(customerId, Receipt.DocumentDate), 2) : 0 : 0;
        }
        
		public List<ReceiptMerchantFeeModel> GetMerchantFees(AppLazyContext lazyContext, decimal taxRate, List<TransactionDetailAllocationModel> allocationList = null) {
            var merchantFees = new List<ReceiptMerchantFeeModel>();

            if (Receipt.Debtor.IsCreditCardDebtor) {
                if ((allocationList?.Count ?? 0) == 0) {
                    var allocations = TransactionDetailAllocations.Select(row => new {
                        MerchantFee = row.TransactionDetail.TransactionDetailAllocations.Sum(t => (decimal?)t.MerchantFee) ?? 0,
                        MerchantFeeTax = row.TransactionDetail.TransactionDetailAllocations.Sum(t => (decimal?)t.MerchantFeeTax) ?? 0,
                    });

                    merchantFees.Add(new ReceiptMerchantFeeModel {
                        ReceiptDetailId = Id,
                        MerchantFee = allocations.Sum(t => (decimal?)t.MerchantFee) ?? 0,
                        MerchantFeeTax = allocations.Sum(t => (decimal?)t.MerchantFeeTax) ?? 0
                    });
                }
                else {
                    var ccChargeAccount = GetCreditCardChargeAccount(lazyContext);

                    foreach (var allocation in allocationList.Where(t => t.TransactionType == TransactionType.Receipt)) {
                        var receiptDetail = lazyContext.ReceiptDetail.Find(allocation.TransactionDetailRefId);
                        allocation.MerchantFee = receiptDetail.Amount + receiptDetail.Tax - allocation.Amount;

                        if (ccChargeAccount.IsTaxApplicable) {
							allocation.MerchantFeeTax = Math.Round(allocation.MerchantFee * taxRate / (1 + taxRate), 2);
							allocation.MerchantFee -= allocation.MerchantFeeTax;
                        }

                        merchantFees.Add(new ReceiptMerchantFeeModel {
                            ReceiptDetailId = Id,
                            MerchantFee = allocation.MerchantFee,
                            MerchantFeeTax = allocation.MerchantFeeTax
                        });
                    }
                }

                foreach (var receiptDetail in Receipt.ReceiptDetails.Where(t => t.Id != Id)) {
                    var allocations = receiptDetail.TransactionDetailAllocations.Select(row => new {
                        MerchantFee = row.TransactionDetail.TransactionDetailAllocations.Sum(t => (decimal?)t.MerchantFee) ?? 0,
                        MerchantFeeTax = row.TransactionDetail.TransactionDetailAllocations.Sum(t => (decimal?)t.MerchantFeeTax) ?? 0,
                    });

                    decimal merchantFee = allocations.Sum(t => (decimal?)t.MerchantFee) ?? 0;
                    decimal merchantFeeTax = allocations.Sum(t => (decimal?)t.MerchantFeeTax) ?? 0;

                    if (merchantFee == 0 && merchantFeeTax == 0)
                        continue;

                    merchantFees.Add(new ReceiptMerchantFeeModel {
                        ReceiptDetailId = receiptDetail.Id,
                        MerchantFee = merchantFee,
                        MerchantFeeTax = merchantFeeTax
                    });
                }
            }
            else if (FormOfPayment.MerchantFeeRate != 0) {
                decimal merchantFee = Math.Round(Amount * FormOfPayment.MerchantFeeRate, 2);
                decimal merchantFeeTax = 0;

                if (merchantFee != 0) {
                    var ccChargeAccount = GetCreditCardChargeAccount(lazyContext);

                    if (ccChargeAccount.IsTaxApplicable) {
                        merchantFeeTax = Math.Round(merchantFee * taxRate / (1 + taxRate), 2);
						merchantFee -= merchantFeeTax;
					}
				}

                MerchantFee = merchantFee;
                MerchantFeeTax = merchantFeeTax;
            }

			return merchantFees;
        }

        public ChartOfAccount GetCreditCardChargeAccount(AppMainContext context) {
			if (FormOfPayment.CreditCardChartOfAccountId > 0)
				return FormOfPayment.CreditCardChartOfAccount.GetChartOfAccountByAgencyId(context, Receipt.AgencyId);

			var glSetting = Setting.GetRow(context, Receipt.DocumentDate);
			return glSetting.CreditCardChargeAccount;
		}

		public DateTime? GetDateDeposited(AppMainContext context, int depositDetailId) {
			return depositDetailId <= 0 ? null : context.ReceiptDetail.Include(t => t.Receipt).SingleOrDefault(t => t.Id == depositDetailId)?.Receipt.DocumentDate;
		}

		public DocumentStatus GetBankRecReportDocumentStatus(DateTime dateTo) {
			return BankAccountStatement.ClosingDate.AddDays(1) > dateTo ? DocumentStatus.DepositedPaid : DocumentStatus;
		}

		public int GetBankRecReportStatementId(DateTime dateTo) {
			return BankAccountStatement.ClosingDate.AddDays(1) > dateTo ? -1 : BankAccountStatementId;
		}

		public decimal GetAmountToBankGross() {
			return Receipt.AccountType == AccountType.Creditor ? Amount + Tax : 0;
		}

		public bool CanEdit(bool isAdministrator, bool isAccounts, bool isSuperUser) {
            return !Receipt.IsLegacy && (isSuperUser || (isAdministrator
                && (Receipt.ReceiptType != ReceiptType.Transfer || (DocumentStatus == (Receipt.ReverseTransferReceipt?.DocumentStatus ?? DocumentStatus) && ReversalStatus == (Receipt.ReverseTransferReceipt?.ReversalStatus ?? ReversalStatus)))
                || (isAccounts && DocumentStatus == DocumentStatus.None) || (DocumentStatus == DocumentStatus.None && Receipt.ReceiptType != ReceiptType.Admin && Receipt.ReceiptType != ReceiptType.Transfer))
                && ReversalStatus == ReversalStatus.None && !Receipt.Trip.IsLocked && !Receipt.IsIssued && !Receipt.IsDeposit
                && !(DepositDetailId > 0 || BankAccountStatementId > 0 || LoyaltySchemeNonBsps.Any(t => t.PaymentId > 0) || Receipt.SupplierOtherCommissionNonBsps.Any(t => t.PaymentId > 0) || TransactionDetailAllocations.Count > 0));
        }

        public bool CanDelete(bool isAdministrator, bool isAccounts, bool isSuperUser) {
			return CanEdit(isAdministrator, isAccounts, isSuperUser) || (!Receipt.IsLegacy && (isAdministrator || isAccounts) && DocumentStatus == DocumentStatus.DepositedPaid && Receipt.IsDeposit
				&& !(BankAccountStatementId > 0 || TransactionDetailAllocations.Count > 0));
		}

		public bool CanUndo(bool isBankReconciliation) {
			return !Receipt.IsLegacy && isBankReconciliation && DocumentStatus == DocumentStatus.Closed;
		}

		public bool CanReverse() {
			return !Receipt.IsLegacy && DocumentStatus != DocumentStatus.None && ReversalStatus != ReversalStatus.Reversed && Receipt.ReceiptType != ReceiptType.Transfer && !Receipt.Trip.IsLocked
				&& !Receipt.IsDeposit && !(DepositDetailId > 0 || BankAccountStatementId > 0 || TransactionDetailAllocations.Count > 0);
		}
	}

	public partial class Bsp {
		[NotMapped]
		public DocumentStatus DocumentStatus {
			get {
				return (DocumentStatus)(BspDetails.Min(t => (int?)t.DocumentStatus) ?? -1);
			}
		}

		[NotMapped]
		public ReversalStatus ReversalStatus {
			get {
				return (ReversalStatus)(BspDetails.Min(t => (int?)t.ReversalStatus) ?? 0);
			}
		}

		[NotMapped]
		public int Sign {
			get {
				return BspType == BspType.Refund || BspType == BspType.Acm || BspType == BspType.AcmNoAnalysis ? -1 : 1;
			}
		}

		[NotMapped]
		public bool IsClientAccountLocked {
			get {
				return Id > 0 && BspType != BspType.Conjunction && BspType != BspType.Free && BspType != BspType.Void && BspDetails.Count > 1;
			}
		}

		[NotMapped]
		public bool IsTaxApplicable {
			get {
				return SaleTypeId > 0 && SaleType.IsTaxApplicable;
			}
		}

		[NotMapped]
		public bool IsCommissionPermitted {
			get {
				return !(BspType == BspType.Conjunction || BspType == BspType.Free || BspType == BspType.Void || BspType == BspType.AcmNoAnalysis || BspType == BspType.AdmNoAnalysis || BspType == BspType.AgencyCC);
			}
		}

		[NotMapped]
		public bool IsDiscountPermitted {
			get {
				return !(BspType == BspType.Conjunction || BspType == BspType.Free || BspType == BspType.Void || BspType == BspType.AcmNoAnalysis || BspType == BspType.AdmNoAnalysis || BspType == BspType.AgencyCC);
			}
		}

		[NotMapped]
		public bool IsMarkupPermitted {
			get {
				return !(BspType == BspType.Conjunction || BspType == BspType.Free || BspType == BspType.Void || BspType == BspType.AgencyCC);
			}
		}

		[NotMapped]
		public bool IsCancellationPermitted {
			get {
				return BspType == BspType.Refund;
			}
		}

		[NotMapped]
		public decimal TotalAmountGross {
			get {
				return (BspDetails.Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0) - Discount - DiscountTax + Markup + MarkupTax;
			}
		}

		[NotMapped]
		public decimal TotalAmount {
			get {
				return (BspDetails.Sum(t => (decimal?)(t.Amount + t.NonCommissionable)) ?? 0) - Discount + Markup;
			}
		}

		[NotMapped]
		public decimal TotalTax {
			get {
				return (BspDetails.Sum(t => (decimal?)(t.Tax + t.NonCommissionableTax)) ?? 0) - DiscountTax + MarkupTax;
			}
		}

		[NotMapped]
		public decimal TotalTaxRate {
			get {
				return TotalAmount == 0 ? 0 : Math.Round(TotalTax / TotalAmount, 3);
			}
		}

		[NotMapped]
		public decimal TotalNonCommissionable {
			get {
				return BspDetails.Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalCash {
			get {
				return BspDetails.Sum(t => (decimal?)(t.Cash + t.CashTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalCashNonCommissionable {
			get {
				return BspDetails.Sum(t => (decimal?)(t.CashNonCommissionable + t.CashNonCommissionableTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalCreditCard {
			get {
				return BspDetails.Sum(t => (decimal?)(t.CreditCard + t.CreditCardTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalCreditCardNonCommissionable {
			get {
				return BspDetails.Sum(t => (decimal?)(t.CreditCardNonCommissionable + t.CreditCardNonCommissionableTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal CommissionRateBySupplierCreditorSaleType {
			get {
				if (Supplier?.CommissionRate > 0) {
					return Supplier.CommissionRate;
				}
				else if (Creditor?.CommissionRate > 0) {
					return Creditor.CommissionRate;
				}
				else if (SaleType?.CommissionRate > 0) {
					return SaleType.CommissionRate;
				}

				return 0;
			}
		}

		[NotMapped]
		public string AccountName {
			get {
				return TripId > 0 ? string.Concat(Trip.TripNo, ": ", BspDetails.Where(t => t.TripLineAirPassenger.PassengerId > 0)?.FirstOrDefault()?.TripLineAirPassenger.Passenger.FullName ?? Trip.FullName)
					: CreditorId > 0 ? Creditor.AccountName
					: SupplierId > 0 ? Supplier.Name
					: "Not Specified";
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				return TripId > 0 ? string.Format(@"<a href=""/ClientLedger/Trip/?profileId={0}&tripId={1}"" target=""_blank"">{2}</a>", Trip.ProfileId, TripId, string.Concat(Trip.TripNo, ": ", BspDetails.Where(t => t.TripLineAirPassenger.PassengerId > 0)?.FirstOrDefault()?.TripLineAirPassenger.Passenger.FullName ?? Trip.FullName))
					: CreditorId > 0 ? string.Format(@"<a href=""/CreditorLedger/?id={0}"" target=""_blank"">{1}</a>", CreditorId, Creditor.AccountName)
					: SupplierId > 0 ? string.Format(@"<a href=""/CreditorLedger/Suppliers/?id={0}"" target=""_blank"">{1}</a>", SupplierId, Supplier.Name)
					: "Not Specified";
			}
		}

		[NotMapped]
		public string PaymentLink {
			get {
				return PaymentId <= 0 ? "Not Specified" : string.Format(@"<a href=""/Accounting/Payments/?id={0}"" target=""_blank"">{1}{2}</a>", PaymentId, Payment.DocumentNo, Payment.SupplierId <= 0 ? string.Empty : string.Format(": {0}", Payment.Supplier.Name));
			}
		}

		public string GetDocumentNoLink(string source) {
            return Transaction.GetDocumentNoLink(source, TransactionType.Bsp, Id, DocumentNo);
        }

        public static string GetUniqueDocumentNo(AppMainContext context, BspType bspType, int bspId, string documentNo) {
			if (string.IsNullOrEmpty(documentNo))
				return string.Empty;

			documentNo = Utils.RemoveExtraSpaces(documentNo).Replace(" ", string.Empty).ToUpper();

			if (bspType == BspType.AgencyCC || !context.Bsp.Any(t => t.Id != bspId && t.BspType != BspType.AgencyCC && t.DocumentNo == documentNo))
				return documentNo;

			char suffix = Convert.ToChar(documentNo.Right(1));
			int length = documentNo.Length;

			if (!char.IsDigit(suffix) && length > 5) {
				length--;
				documentNo = documentNo.Left(length);
			}
			else {
				suffix = 'A';
			}

			var q = context.Bsp.Where(t => t.Id != bspId && t.BspType != BspType.AgencyCC);

			while (q.Any(t => t.DocumentNo.ToLower() == string.Format("{0}{1}", documentNo, suffix).ToLower())) {
				if (suffix == 'Z') {
					documentNo += "A";
					suffix = 'A';
					continue;
				}

				suffix = Convert.ToChar(suffix + 1);
			}

			return string.Format("{0}{1}", documentNo, suffix);
		}

		public string GetFormOfPaymentDetails() {
			return string.Format("{0} No {1}: {2} {3} on {4}", BspType == BspType.Refund || (BspDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? "Refund" : "Payment", DocumentNo, BspType == BspType.Refund || (BspDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? "Refunded by" : "Paid with", string.Join("; ", BspDetails.Where(t => t.FormOfPaymentId > 0).Select(t => t.FormOfPayment.Name).Distinct()), DocumentDate.ToShortDateStringExt()).Replace("by Not Specified ", string.Empty).Replace("with Not Specified ", string.Empty).Replace("by  on", "on").Replace("with  on", "on");
		}

		public bool ValidateTaxApplicability(bool isTaxApplicable) {
			if (BspDetails.Count == 0)
				return true;

			return IsTaxApplicable == isTaxApplicable;
		}

		public static IQueryable<int> GetMissingAutoAgencyCcBspIds(AppMainContext context, int agencyId) {
			return context.Bsp.Include(t => t.BspDetails).ThenInclude(t => t.FormOfPayment).Where(t1 => !t1.IsLegacy
				&& (agencyId <= 0 || t1.AgencyId == agencyId) && t1.AgencyCreditCardBspId == -1
				&& t1.BspDetails.Any(t2 => t2.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t2.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross)
				&& !context.NonBsp.Any(t2 => t2.AgencyCreditCardBspId == t1.Id && t2.AgencyCreditCardBspId > 0))
				.Concat(context.Bsp.Include(t => t.BspDetails).ThenInclude(t => t.FormOfPayment).Where(t1 => !t1.IsLegacy && (agencyId <= 0 || t1.AgencyId == agencyId) && t1.AgencyCreditCardBspId == -1
				&& t1.BspDetails.Any(t2 => t2.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t2.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross)
				&& !context.Bsp.Any(t2 => t2.AgencyCreditCardBspId == t1.Id && t2.AgencyCreditCardBspId > 0))).Where(t => t.BspType != BspType.AgencyCC).Select(t => t.Id).Distinct();
		}

		public decimal GetMarkupGross() {
			if (BspType == BspType.Conjunction || BspType == BspType.Free || BspType == BspType.Void || Markup == 0)
				return 0;

			switch (TripLine.TripLineType) {
				default:
					return 0;
				case TripLineType.Air:
					return TripLine.TripLineAir.TripLineAirPassengers.Where(t1 => BspDetails.Any(t2 => t2.TripLineAirPassengerId == t1.Id)).Sum(t => (decimal?)t.TicketedFare) ?? 0;
				case TripLineType.Accommodation:
				case TripLineType.Transport:
				case TripLineType.Cruise:
				case TripLineType.Tour:
				case TripLineType.OtherLand:
					return TripLine.TripLineLand.CommissionableValue;
				case TripLineType.Insurance:
					return TripLine.TripLineInsurance.TotalCommissionableSurcharge;
				case TripLineType.ForeignCurrency:
					return TripLine.TripLineForeignCurrency.EquivalentValue + TripLine.TripLineForeignCurrency.ClientFee;
				case TripLineType.ServiceFee:
					return TripLine.TripLineServiceFee.Gross;
				case TripLineType.OtherInclusion:
					return TripLine.TripLineOtherInclusion.Gross;
			}
		}

		public decimal GetAmountPayable(AppMainContext context, bool calculateValue = true, bool includeAutoGenerated = false) {
			if (BspType == BspType.Conjunction || BspType == BspType.Free || BspType == BspType.Void)
				return 0;

			if (calculateValue) {
				var q = context.BspDetail.Include(t => t.Bsp).Include(t => t.FormOfPayment).Where(t => (t.BspId == Id || (includeAutoGenerated && t.Bsp.AgencyCreditCardBspId == Id)) && t.Bsp.CreditorId == CreditorId).ToList();
				return ((q.Sum(t => (decimal?)(t.Cash + t.CashTax)) ?? 0) - (Commission + CommissionTax + SupplierCancellationFee + SupplierCancellationFeeTax)) * Sign;
			}
			else if (includeAutoGenerated) {
				return context.Bsp.Where(t => (t.Id == Id || t.AgencyCreditCardBspId == Id) && t.CreditorId == CreditorId).Sum(t => (decimal?)t.AmountPayable) ?? 0;
			}

			return AmountPayable;
		}

		public bool CanEdit(bool isSuperUser) {
			return !IsLegacy && (isSuperUser || ((DocumentStatus == DocumentStatus.None || DocumentStatus == DocumentStatus.Open) && ReversalStatus == ReversalStatus.None
				&& BspType != BspType.AgencyCC && !Trip.IsLocked && AgencyCreditCardBspId <= 0 && !AgencyCreditCardBsps.Any(t => t.PaymentId > 0) && !AgencyCreditCardNonBspBsps.Any(t => t.PaymentId > 0)));
		}

		public bool CanDelete(bool isSuperUser) {
			return CanEdit(isSuperUser);
		}

		public bool CanUndo() {
			return false;
		}

		public bool CanReverse() {
			return !IsLegacy && DocumentStatus == DocumentStatus.Open && ReversalStatus != ReversalStatus.Reversed && BspType != BspType.AgencyCC && !Trip.IsLocked && AgencyCreditCardBspId <= 0;
		}
	}

	public partial class BspDetail {
		[NotMapped]
		public decimal NonCommissionableGross {
			get {
				return NonCommissionable + NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CommissionGrossProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.Commission + Bsp.CommissionTax;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.Commission + Bsp.CommissionTax - bspDetail.Sum(t => (decimal?)(t.CommissionBaseProRata + t.CommissionTaxBaseProRata)) ?? 0;
				}

				return CommissionBaseProRata + CommissionTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal CommissionProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.Commission;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.Commission - (bspDetail.Sum(t => (decimal?)t.CommissionBaseProRata) ?? 0);
				}

				return CommissionBaseProRata;
			}
		}

		[NotMapped]
		private decimal CommissionBaseProRata {
			get {
				decimal totalAmount = Bsp.BspDetails.Sum(t => (decimal?)t.Amount) ?? 0;
				decimal ratio = totalAmount == 0 ? (1 / (decimal)Bsp.BspDetails.Count) : Amount / totalAmount;
				return Bsp.Commission * ratio;
			}
		}

		[NotMapped]
		public decimal CommissionTaxProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.CommissionTax;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.CommissionTax - (bspDetail.Sum(t => (decimal?)t.CommissionTaxBaseProRata) ?? 0);
				}

				return CommissionTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal CommissionTaxBaseProRata {
			get {
				decimal totalTax = Bsp.BspDetails.Sum(t => (decimal?)t.Tax) ?? 0;
				decimal ratio = totalTax == 0 ? (1 / (decimal)Bsp.BspDetails.Count) : Tax / totalTax;
				return Bsp.CommissionTax * ratio;
			}
		}

		[NotMapped]
		public decimal DiscountGrossProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.Discount + Bsp.DiscountTax;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.Discount + Bsp.DiscountTax - bspDetail.Sum(t => (decimal?)(t.DiscountBaseProRata + t.DiscountTaxBaseProRata)) ?? 0;
				}

				return DiscountBaseProRata + DiscountTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal DiscountProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.Discount;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.Discount - (bspDetail.Sum(t => (decimal?)t.DiscountBaseProRata) ?? 0);
				}

				return DiscountBaseProRata;
			}
		}

		[NotMapped]
		private decimal DiscountBaseProRata {
			get {
				return Bsp.Discount * DiscountProRataRatio;
			}
		}

		[NotMapped]
		public decimal DiscountTaxProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.DiscountTax;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.DiscountTax - (bspDetail.Sum(t => (decimal?)t.DiscountTaxBaseProRata) ?? 0);
				}

				return DiscountTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal DiscountTaxBaseProRata {
			get {
				return Bsp.DiscountTax * DiscountProRataRatio;
			}
		}

		[NotMapped]
		public decimal DiscountProRataRatio {
			get {
				decimal totalAmount = 0;

				if (Bsp.BspDetails.Count == 1) {
					return 1;
				}
				else if (!Bsp.BspDetails.Any(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)) {
					totalAmount = Bsp.BspDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}
				else if (Bsp.IsCreditCardDiscountApplicable && FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
					totalAmount = Bsp.BspDetails.Where(t => t.Bsp.IsCreditCardDiscountApplicable && t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}

				return totalAmount == 0 ? 0 : (Amount + Tax) / totalAmount;
			}
		}

		[NotMapped]
		public decimal MarkupGrossProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.Markup + Bsp.MarkupTax;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.Markup + Bsp.MarkupTax - bspDetail.Sum(t => (decimal?)(t.MarkupBaseProRata + t.MarkupTaxBaseProRata)) ?? 0;
				}

				return MarkupBaseProRata + MarkupTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal MarkupProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.Markup;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.Markup - (bspDetail.Sum(t => (decimal?)t.MarkupBaseProRata) ?? 0);
				}

				return MarkupBaseProRata;
			}
		}

		[NotMapped]
		private decimal MarkupBaseProRata {
			get {
				return Bsp.Markup * MarkupProRataRatio;
			}
		}

		[NotMapped]
		public decimal MarkupTaxProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.MarkupTax;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.MarkupTax - (bspDetail.Sum(t => (decimal?)t.MarkupTaxBaseProRata) ?? 0);
				}

				return MarkupTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal MarkupTaxBaseProRata {
			get {
				return Bsp.MarkupTax * MarkupProRataRatio;
			}
		}

		[NotMapped]
		public decimal MarkupProRataRatio {
			get {
				decimal totalAmount = 0;

				if (Bsp.BspDetails.Count == 1) {
					return 1;
				}
				else if (!Bsp.BspDetails.Any(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)) {
					totalAmount = Bsp.BspDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}
				else if (Bsp.IncludeMarkupInCreditCardPayment && FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
					totalAmount = Bsp.BspDetails.Where(t => t.Bsp.IncludeMarkupInCreditCardPayment && t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}

				return totalAmount == 0 ? 0 : (Amount + Tax) / totalAmount;
			}
		}

		[NotMapped]
		public decimal SupplierCancellationFeeGrossProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.SupplierCancellationFee + Bsp.SupplierCancellationFeeTax;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.SupplierCancellationFee + Bsp.SupplierCancellationFeeTax - bspDetail.Sum(t => (decimal?)(t.SupplierCancellationFeeBaseProRata + t.SupplierCancellationFeeTaxBaseProRata)) ?? 0;
				}

				return SupplierCancellationFeeBaseProRata + SupplierCancellationFeeTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal SupplierCancellationFeeProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.SupplierCancellationFee;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.SupplierCancellationFee - (bspDetail.Sum(t => (decimal?)t.SupplierCancellationFeeBaseProRata) ?? 0);
				}

				return SupplierCancellationFeeBaseProRata;
			}
		}

		[NotMapped]
		private decimal SupplierCancellationFeeBaseProRata {
			get {
				decimal totalAmount = Bsp.BspDetails.Sum(t => (decimal?)t.Amount) ?? 0;
				decimal ratio = totalAmount == 0 ? (1 / (decimal)Bsp.BspDetails.Count) : Amount / totalAmount;
				return Bsp.SupplierCancellationFee * ratio;
			}
		}

		[NotMapped]
		public decimal SupplierCancellationFeeTaxProRata {
			get {
				if (Bsp.BspDetails.Count <= 1) {
					return Bsp.SupplierCancellationFeeTax;
				}
				else if (Bsp.BspDetails.Last().Id == Id) {
					var bspDetail = Bsp.BspDetails.Where(t => t.Id != Id);
					return Bsp.SupplierCancellationFeeTax - (bspDetail.Sum(t => (decimal?)t.SupplierCancellationFeeTaxBaseProRata) ?? 0);
				}

				return SupplierCancellationFeeTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal SupplierCancellationFeeTaxBaseProRata {
			get {
				decimal totalTax = Bsp.BspDetails.Sum(t => (decimal?)t.Tax) ?? 0;
				decimal ratio = totalTax == 0 ? (1 / (decimal)Bsp.BspDetails.Count) : Tax / totalTax;
				return Bsp.SupplierCancellationFeeTax * ratio;
			}
		}

		[NotMapped]
		public decimal SupplierNet {
			get {
				return Cash - CommissionProRata - SupplierCancellationFeeProRata;
			}
		}

		[NotMapped]
		public decimal SupplierNetTax {
			get {
				return CashTax - CommissionTaxProRata - SupplierCancellationFeeTaxProRata;
			}
		}

		[NotMapped]
		private decimal CreditCardDiscountAndMarkup {
			get {
				return (Bsp.IsCreditCardDiscountApplicable ? DiscountProRata : 0) - (Bsp.IncludeMarkupInCreditCardPayment ? MarkupProRata : 0);
			}
		}

		[NotMapped]
		private decimal CreditCardDiscountAndMarkupTax {
			get {
				return (Bsp.IsCreditCardDiscountApplicable ? DiscountTaxProRata : 0) - (Bsp.IncludeMarkupInCreditCardPayment ? MarkupTaxProRata : 0);
			}
		}

		[NotMapped]
		public decimal Cash {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? CreditCardDiscountAndMarkup : Amount + NonCommissionable;
			}
		}

		[NotMapped]
		public decimal CashTax {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? CreditCardDiscountAndMarkupTax : Tax + NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CashNonCommissionableGross {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? 0 : NonCommissionable + NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CashNonCommissionable {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? 0 : NonCommissionable;
			}
		}

		[NotMapped]
		public decimal CashNonCommissionableTax {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? 0 : NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CreditCard {
			get {
				return Amount + NonCommissionable - Cash;
			}
		}

		[NotMapped]
		public decimal CreditCardTax {
			get {
				return Tax + NonCommissionableTax - CashTax;
			}
		}

		[NotMapped]
		public decimal CreditCardNonCommissionableGross {
			get {
				return NonCommissionable + NonCommissionableTax - CashNonCommissionable - CashNonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CreditCardNonCommissionable {
			get {
				return NonCommissionable - CashNonCommissionable;
			}
		}

		[NotMapped]
		public decimal CreditCardNonCommissionableTax {
			get {
				return NonCommissionableTax - CashNonCommissionableTax;
			}
		}

		[NotMapped]
		public string PaymentDetails {
			get {
				return string.Format("Paid {0}: {1}", Bsp.DocumentNo, FormOfPayment.Name);
			}
		}

		public bool CanEdit(bool isSuperUser) {
			return !Bsp.IsLegacy && (isSuperUser || ((DocumentStatus == DocumentStatus.None || DocumentStatus == DocumentStatus.Open) && ReversalStatus == ReversalStatus.None
				&& Bsp.BspType != BspType.AgencyCC && !Bsp.Trip.IsLocked && Bsp.AgencyCreditCardBspId <= 0 && !Bsp.AgencyCreditCardBsps.Any(t => t.PaymentId > 0) && !Bsp.AgencyCreditCardNonBspBsps.Any(t => t.PaymentId > 0)));
		}

		public bool CanDelete(bool isSuperUser) {
			return CanEdit(isSuperUser);
		}

		public bool CanUndo() {
			return false;
		}

		public bool CanReverse() {
			return !Bsp.IsLegacy && DocumentStatus == DocumentStatus.Open && ReversalStatus != ReversalStatus.Reversed && Bsp.BspType != BspType.AgencyCC && !Bsp.Trip.IsLocked && Bsp.AgencyCreditCardBspId <= 0;
		}
	}

	public partial class NonBsp {
		[NotMapped]
		public DocumentStatus DocumentStatus {
			get {
				return (DocumentStatus)(NonBspDetails.Min(t => (int?)t.DocumentStatus) ?? -1);
			}
		}

		[NotMapped]
		public ReversalStatus ReversalStatus {
			get {
				return (ReversalStatus)(NonBspDetails.Min(t => (int?)t.ReversalStatus) ?? 0);
			}
		}

		[NotMapped]
		public AccountType AccountType {
			get {
				return NonBspType == NonBspType.Admin ? AccountType.GeneralLedger : AccountType.Client;
			}
		}

		[NotMapped]
		public int Sign {
			get {
				return NonBspType == NonBspType.Refund ? -1 : 1;
			}
		}

		[NotMapped]
		public bool IsClientAccountLocked {
			get {
				return Id > 0 && NonBspDetails.Count > 1;
			}
		}

		[NotMapped]
		public bool IsTaxApplicable {
			get {
				return (ChartOfAccountId > 0 && ChartOfAccount.IsTaxApplicable) || (SaleTypeId > 0 && SaleType.IsTaxApplicable);
			}
		}

		[NotMapped]
		public bool IsMatched {
			get {
				return PaymentId > 0;
			}
		}

		[NotMapped]
		public bool IsCommissionPermitted {
			get {
				return !(NonBspType == NonBspType.Admin || NonBspType == NonBspType.AgencyCC);
			}
		}

		[NotMapped]
		public bool IsDiscountPermitted {
			get {
				return NonBspType == NonBspType.NonBsp || NonBspType == NonBspType.Refund || NonBspType == NonBspType.Other;
			}
		}

		[NotMapped]
		public bool IsMarkupPermitted {
			get {
				return NonBspType == NonBspType.NonBsp || NonBspType == NonBspType.Refund || NonBspType == NonBspType.Other;
			}
		}

		[NotMapped]
		public bool IsCancellationPermitted {
			get {
				return NonBspType == NonBspType.Refund;
			}
		}

		[NotMapped]
		public decimal TotalAmountGross {
			get {
				return (NonBspDetails.Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0) - Discount - DiscountTax + Markup + MarkupTax;
			}
		}

		[NotMapped]
		public decimal TotalAmount {
			get {
				return (NonBspDetails.Sum(t => (decimal?)(t.Amount + t.NonCommissionable)) ?? 0) - Discount + Markup;
			}
		}

		[NotMapped]
		public decimal TotalTax {
			get {
				return (NonBspDetails.Sum(t => (decimal?)(t.Tax + t.NonCommissionableTax)) ?? 0) - DiscountTax + MarkupTax;
			}
		}

		[NotMapped]
		public decimal TotalTaxRate {
			get {
				return TotalAmount == 0 ? 0 : Math.Round(TotalTax / TotalAmount, 3);
			}
		}

		[NotMapped]
		public decimal TotalNonCommissionable {
			get {
				return NonBspDetails.Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalCash {
			get {
				return NonBspDetails.Sum(t => (decimal?)(t.Cash + t.CashTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalCashNonCommissionable {
			get {
				return NonBspDetails.Sum(t => (decimal?)(t.CashNonCommissionable + t.CashNonCommissionableTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalCreditCard {
			get {
				return NonBspDetails.Sum(t => (decimal?)(t.CreditCard + t.CreditCardTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalCreditCardNonCommissionable {
			get {
				return NonBspDetails.Sum(t => (decimal?)(t.CreditCardNonCommissionable + t.CreditCardNonCommissionableTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal CommissionRateBySupplierCreditorSaleType {
			get {
				if (Supplier?.CommissionRate > 0) {
					return Supplier.CommissionRate;
				}
				else if (Creditor?.CommissionRate > 0) {
					return Creditor.CommissionRate;
				}
				else if (SaleType?.CommissionRate > 0) {
					return SaleType.CommissionRate;
				}

				return 0;
			}
		}

		[NotMapped]
		public string AccountName {
			get {
				return TripId > 0 ? string.Concat(Trip.TripNo, ": ", NonBspDetails.Where(t => t.TripLineAirPassenger.PassengerId > 0)?.FirstOrDefault()?.TripLineAirPassenger.Passenger.FullName ?? Trip.FullName)
					: ChartOfAccountId > 0 ? ChartOfAccount.AccountName
					: CreditorId > 0 ? Creditor.AccountName
					: SupplierId > 0 ? Supplier.Name
					: "Not Specified";
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				return TripId > 0 ? string.Format(@"<a href=""/ClientLedger/Trip/?profileId={0}&tripId={1}"" target=""_blank"">{2}</a>", Trip.ProfileId, TripId, string.Concat(Trip.TripNo, ": ", NonBspDetails.Where(t => t.TripLineAirPassenger.PassengerId > 0)?.FirstOrDefault()?.TripLineAirPassenger.Passenger.FullName ?? Trip.FullName))
					: ChartOfAccountId > 0 ? string.Format(@"<a href=""/GeneralLedger/ChartOfAccounts/?id={0}"" target=""_blank"">{1}</a>", ChartOfAccountId, ChartOfAccount.AccountName)
					: CreditorId > 0 ? string.Format(@"<a href=""/CreditorLedger/?id={0}"" target=""_blank"">{1}</a>", CreditorId, Creditor.AccountName)
					: SupplierId > 0 ? string.Format(@"<a href=""/CreditorLedger/Suppliers/?id={0}"" target=""_blank"">{1}</a>", SupplierId, Supplier.Name)
					: "Not Specified";
			}
		}

		[NotMapped]
		public string PaymentLink {
			get {
				return PaymentId <= 0 ? "Not Specified" : string.Format(@"<a href=""/Accounting/Payments/?id={0}"" target=""_blank"">{1}{2}</a>", PaymentId, Payment.DocumentNo, Payment.SupplierId <= 0 ? string.Empty : string.Format(": {0}", Payment.Supplier.Name));
			}
		}

		public string GetDocumentNoLink(string source) {
            return Transaction.GetDocumentNoLink(source, TransactionType.NonBsp, Id, DocumentNo);
        }

        public static string GetUniqueDocumentNo(AppMainContext context, NonBspType nonBspType, int nonBspId, string documentNo) {
			if (string.IsNullOrEmpty(documentNo))
				return string.Empty;

			documentNo = Utils.RemoveExtraSpaces(documentNo).Replace(" ", string.Empty).ToUpper();

			if (nonBspType == NonBspType.AgencyCC || !context.NonBsp.Any(t => t.Id != nonBspId && t.NonBspType != NonBspType.AgencyCC && t.DocumentNo == documentNo))
				return documentNo;

			char suffix = Convert.ToChar(documentNo.Right(1));
			int length = documentNo.Length;

			if (!char.IsDigit(suffix) && length > 5) {
				length--;
				documentNo = documentNo.Left(length);
			}
			else {
				suffix = 'A';
			}

			var q = context.NonBsp.Where(t => t.Id != nonBspId && t.NonBspType != NonBspType.AgencyCC);

			while (q.Any(t => t.DocumentNo.ToLower() == string.Format("{0}{1}", documentNo, suffix).ToLower())) {
				if (suffix == 'Z') {
					documentNo += "A";
					suffix = 'A';
					continue;
				}

				suffix = Convert.ToChar(suffix + 1);
			}

			return string.Format("{0}{1}", documentNo, suffix);
		}

		public string GetFormOfPaymentDetails() {
			return string.Format("{0} No {1}: {2} {3} on {4}", NonBspType == NonBspType.Refund || (NonBspDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? "Refund" : "Payment", DocumentNo, NonBspType == NonBspType.Refund || (NonBspDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? "Refunded by" : "Paid with", string.Join("; ", NonBspDetails.Where(t => t.FormOfPaymentId > 0).Select(t => t.FormOfPayment.Name).Distinct()), DocumentDate.ToShortDateStringExt()).Replace("by Not Specified ", string.Empty).Replace("with Not Specified ", string.Empty).Replace("by  on", "on").Replace("with  on", "on");
		}

		public bool ValidateTaxApplicability(bool isTaxApplicable) {
			if (NonBspDetails.Count == 0)
				return true;

			return IsTaxApplicable == isTaxApplicable;
		}

		public static IQueryable<int> GetMissingAutoAgencyCcNonBspIds(AppMainContext context, int agencyId) {
			return context.NonBsp.Include(t => t.NonBspDetails).ThenInclude(t => t.FormOfPayment).Where(t1 => !t1.IsLegacy
				&& (agencyId <= 0 || t1.AgencyId == agencyId) && t1.AgencyCreditCardBspId == -1 && t1.AgencyCreditCardNonBspId == -1
				&& t1.NonBspDetails.Any(t2 => t2.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardNet || t2.FormOfPayment.FormOfPaymentType == FormOfPaymentType.AgencyCreditCardGross || t2.FormOfPayment.FormOfPaymentType == FormOfPaymentType.PaySupplierGross)
				&& !context.NonBsp.Any(t2 => t2.AgencyCreditCardNonBspId == t1.Id && t2.AgencyCreditCardNonBspId > 0)).Where(t => t.NonBspType != NonBspType.AgencyCC).Select(t => t.Id);
		}

		public decimal GetMarkupGross() {
			if (Markup == 0)
				return 0;

			switch (TripLine.TripLineType) {
				default:
					return 0;
				case TripLineType.Air:
					return TripLine.TripLineAir.TripLineAirPassengers.Where(t1 => NonBspDetails.Any(t2 => t2.TripLineAirPassengerId == t1.Id)).Sum(t => (decimal?)t.TicketedFare) ?? 0;
				case TripLineType.Accommodation:
				case TripLineType.Transport:
				case TripLineType.Cruise:
				case TripLineType.Tour:
				case TripLineType.OtherLand:
					return TripLine.TripLineLand.CommissionableValue;
				case TripLineType.Insurance:
					return TripLine.TripLineInsurance.TotalCommissionableSurcharge;
				case TripLineType.ForeignCurrency:
					return TripLine.TripLineForeignCurrency.EquivalentValue + TripLine.TripLineForeignCurrency.ClientFee;
				case TripLineType.ServiceFee:
					return TripLine.TripLineServiceFee.Gross;
				case TripLineType.OtherInclusion:
					return TripLine.TripLineOtherInclusion.Gross;
			}
		}

		public decimal GetAmountPayable(AppMainContext context, bool calculateValue = true, bool includeAutoGenerated = false) {
			if (calculateValue) {
				var q = context.NonBspDetail.Include(t => t.NonBsp).Include(t => t.FormOfPayment).Where(t => (t.NonBspId == Id || (includeAutoGenerated && t.NonBsp.AgencyCreditCardBspId == Id)) && t.NonBsp.CreditorId == CreditorId).ToList();
				return ((q.Sum(t => (decimal?)(t.Cash + t.CashTax)) ?? 0) - (Commission + CommissionTax + SupplierCancellationFee + SupplierCancellationFeeTax)) * Sign;
			}
			else if (includeAutoGenerated) {
				return context.NonBsp.Where(t => (t.Id == Id || t.AgencyCreditCardNonBspId == Id) && t.CreditorId == CreditorId).Sum(t => (decimal?)t.AmountPayable) ?? 0;
			}

			return AmountPayable;
		}

		public bool CanEdit(bool isSuperUser) {
			return !IsLegacy && (isSuperUser || ((DocumentStatus == DocumentStatus.None || DocumentStatus == DocumentStatus.Open) && ReversalStatus == ReversalStatus.None
				&& NonBspType != NonBspType.AgencyCC && !Trip.IsLocked && AgencyCreditCardBspId <= 0 && AgencyCreditCardNonBspId <= 0 && LoyaltySchemeReceiptDetailId <= 0 && SupplierOtherCommissionReceiptId <= 0
				&& !AgencyCreditCardNonBsps.Any(t => t.PaymentId > 0)));
		}

		public bool CanDelete(bool isSuperUser) {
			return CanEdit(isSuperUser);
		}

		public bool CanUndo() {
			return false;
		}

		public bool CanReverse() {
			return !IsLegacy && DocumentStatus == DocumentStatus.Open && ReversalStatus != ReversalStatus.Reversed && NonBspType != NonBspType.AgencyCC && !Trip.IsLocked
				&& AgencyCreditCardBspId <= 0 && AgencyCreditCardNonBspId <= 0 && LoyaltySchemeReceiptDetailId <= 0 && SupplierOtherCommissionReceiptId <= 0;
		}
	}

	public partial class NonBspDetail {
		[NotMapped]
		public decimal NonCommissionableGross {
			get {
				return NonCommissionable + NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CommissionGrossProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.Commission + NonBsp.CommissionTax;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.Commission + NonBsp.CommissionTax - nonBspDetail.Sum(t => (decimal?)(t.CommissionBaseProRata + t.CommissionTaxBaseProRata)) ?? 0;
				}

				return CommissionBaseProRata + CommissionTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal CommissionProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.Commission;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.Commission - (nonBspDetail.Sum(t => (decimal?)t.CommissionBaseProRata) ?? 0);
				}

				return CommissionBaseProRata;
			}
		}

		[NotMapped]
		private decimal CommissionBaseProRata {
			get {
				decimal totalAmount = NonBsp.NonBspDetails.Sum(t => (decimal?)t.Amount) ?? 0;
				decimal ratio = totalAmount == 0 ? (1 / (decimal)NonBsp.NonBspDetails.Count) : Amount / totalAmount;
				return NonBsp.Commission * ratio;
			}
		}

		[NotMapped]
		public decimal CommissionTaxProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.CommissionTax;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.CommissionTax - (nonBspDetail.Sum(t => (decimal?)t.CommissionTaxBaseProRata) ?? 0);
				}

				return CommissionTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal CommissionTaxBaseProRata {
			get {
				decimal totalTax = NonBsp.NonBspDetails.Sum(t => (decimal?)t.Tax) ?? 0;
				decimal ratio = totalTax == 0 ? (1 / (decimal)NonBsp.NonBspDetails.Count) : Tax / totalTax;
				return NonBsp.CommissionTax * ratio;
			}
		}

		[NotMapped]
		public decimal DiscountGrossProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.Discount + NonBsp.DiscountTax;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.Discount + NonBsp.DiscountTax - nonBspDetail.Sum(t => (decimal?)(t.DiscountBaseProRata + t.DiscountTaxBaseProRata)) ?? 0;
				}

				return DiscountBaseProRata + DiscountTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal DiscountProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.Discount;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.Discount - (nonBspDetail.Sum(t => (decimal?)t.DiscountBaseProRata) ?? 0);
				}

				return DiscountBaseProRata;
			}
		}

		[NotMapped]
		private decimal DiscountBaseProRata {
			get {
				return NonBsp.Discount * DiscountProRataRatio;
			}
		}

		[NotMapped]
		public decimal DiscountTaxProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.DiscountTax;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.DiscountTax - (nonBspDetail.Sum(t => (decimal?)t.DiscountTaxBaseProRata) ?? 0);
				}

				return DiscountTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal DiscountTaxBaseProRata {
			get {
				return NonBsp.DiscountTax * DiscountProRataRatio;
			}
		}

		[NotMapped]
		public decimal DiscountProRataRatio {
			get {
				decimal totalAmount = 0;

				if (NonBsp.NonBspDetails.Count == 1) {
					return 1;
				}
				else if (!NonBsp.NonBspDetails.Any(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)) {
					totalAmount = NonBsp.NonBspDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}
				else if (NonBsp.IsCreditCardDiscountApplicable && FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
					totalAmount = NonBsp.NonBspDetails.Where(t => t.NonBsp.IsCreditCardDiscountApplicable && t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}

				return totalAmount == 0 ? 0 : (Amount + Tax) / totalAmount;
			}
		}

		[NotMapped]
		public decimal MarkupGrossProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.Markup + NonBsp.MarkupTax;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.Markup + NonBsp.MarkupTax - nonBspDetail.Sum(t => (decimal?)(t.MarkupBaseProRata + t.MarkupTaxBaseProRata)) ?? 0;
				}

				return MarkupBaseProRata + MarkupTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal MarkupProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.Markup;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.Markup - (nonBspDetail.Sum(t => (decimal?)t.MarkupBaseProRata) ?? 0);
				}

				return MarkupBaseProRata;
			}
		}

		[NotMapped]
		private decimal MarkupBaseProRata {
			get {
				return NonBsp.Markup * MarkupProRataRatio;
			}
		}

		[NotMapped]
		public decimal MarkupTaxProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.MarkupTax;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.MarkupTax - (nonBspDetail.Sum(t => (decimal?)t.MarkupTaxBaseProRata) ?? 0);
				}

				return MarkupTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal MarkupTaxBaseProRata {
			get {
				return NonBsp.MarkupTax * MarkupProRataRatio;
			}
		}

		[NotMapped]
		public decimal MarkupProRataRatio {
			get {
				decimal totalAmount = 0;

				if (NonBsp.NonBspDetails.Count == 1) {
					return 1;
				}
				else if (!NonBsp.NonBspDetails.Any(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)) {
					totalAmount = NonBsp.NonBspDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}
				else if (NonBsp.IncludeMarkupInCreditCardPayment && FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
					totalAmount = NonBsp.NonBspDetails.Where(t => t.NonBsp.IncludeMarkupInCreditCardPayment && t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}

				return totalAmount == 0 ? 0 : (Amount + Tax) / totalAmount;
			}
		}

		[NotMapped]
		public decimal SupplierCancellationFeeGrossProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.SupplierCancellationFee + NonBsp.SupplierCancellationFeeTax;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.SupplierCancellationFee + NonBsp.SupplierCancellationFeeTax - nonBspDetail.Sum(t => (decimal?)(t.SupplierCancellationFeeBaseProRata + t.SupplierCancellationFeeTaxBaseProRata)) ?? 0;
				}

				return SupplierCancellationFeeBaseProRata + SupplierCancellationFeeTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal SupplierCancellationFeeProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.SupplierCancellationFee;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.SupplierCancellationFee - (nonBspDetail.Sum(t => (decimal?)t.SupplierCancellationFeeBaseProRata) ?? 0);
				}

				return SupplierCancellationFeeBaseProRata;
			}
		}

		[NotMapped]
		private decimal SupplierCancellationFeeBaseProRata {
			get {
				decimal totalAmount = NonBsp.NonBspDetails.Sum(t => (decimal?)t.Amount) ?? 0;
				decimal ratio = totalAmount == 0 ? (1 / (decimal)NonBsp.NonBspDetails.Count) : Amount / totalAmount;
				return NonBsp.SupplierCancellationFee * ratio;
			}
		}

		[NotMapped]
		public decimal SupplierCancellationFeeTaxProRata {
			get {
				if (NonBsp.NonBspDetails.Count <= 1) {
					return NonBsp.SupplierCancellationFeeTax;
				}
				else if (NonBsp.NonBspDetails.Last().Id == Id) {
					var nonBspDetail = NonBsp.NonBspDetails.Where(t => t.Id != Id);
					return NonBsp.SupplierCancellationFeeTax - (nonBspDetail.Sum(t => (decimal?)t.SupplierCancellationFeeTaxBaseProRata) ?? 0);
				}

				return SupplierCancellationFeeTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal SupplierCancellationFeeTaxBaseProRata {
			get {
				decimal totalTax = NonBsp.NonBspDetails.Sum(t => (decimal?)t.Tax) ?? 0;
				decimal ratio = totalTax == 0 ? (1 / (decimal)NonBsp.NonBspDetails.Count) : Tax / totalTax;
				return NonBsp.SupplierCancellationFeeTax * ratio;
			}
		}

		[NotMapped]
		public decimal SupplierNet {
			get {
				return Cash - CommissionProRata - SupplierCancellationFeeProRata;
			}
		}

		[NotMapped]
		public decimal SupplierNetTax {
			get {
				return CashTax - CommissionTaxProRata - SupplierCancellationFeeTaxProRata;
			}
		}

		[NotMapped]
		private decimal CreditCardDiscountAndMarkup {
			get {
				return (NonBsp.IsCreditCardDiscountApplicable ? DiscountProRata : 0) - (NonBsp.IncludeMarkupInCreditCardPayment ? MarkupProRata : 0);
			}
		}

		[NotMapped]
		private decimal CreditCardDiscountAndMarkupTax {
			get {
				return (NonBsp.IsCreditCardDiscountApplicable ? DiscountTaxProRata : 0) - (NonBsp.IncludeMarkupInCreditCardPayment ? MarkupTaxProRata : 0);
			}
		}

		[NotMapped]
		public decimal Cash {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? CreditCardDiscountAndMarkup : Amount + NonCommissionable;
			}
		}

		[NotMapped]
		public decimal CashTax {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? CreditCardDiscountAndMarkupTax : Tax + NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CashNonCommissionableGross {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? 0 : NonCommissionable + NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CashNonCommissionable {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? 0 : NonCommissionable;
			}
		}

		[NotMapped]
		public decimal CashNonCommissionableTax {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? 0 : NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CreditCard {
			get {
				return Amount + NonCommissionable - Cash;
			}
		}

		[NotMapped]
		public decimal CreditCardTax {
			get {
				return Tax + NonCommissionableTax - CashTax;
			}
		}

		[NotMapped]
		public decimal CreditCardNonCommissionableGross {
			get {
				return NonCommissionable + NonCommissionableTax - CashNonCommissionable - CashNonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CreditCardNonCommissionable {
			get {
				return NonCommissionable - CashNonCommissionable;
			}
		}

		[NotMapped]
		public decimal CreditCardNonCommissionableTax {
			get {
				return NonCommissionableTax - CashNonCommissionableTax;
			}
		}

		[NotMapped]
		public string PaymentDetails {
			get {
				return string.Format("Paid {0}: {1}", NonBsp.TripLine.TripLineType == TripLineType.Air ? NonBsp.DocumentNo : NonBsp.TripLine.Description, FormOfPayment.Name);
			}
		}

		public bool CanEdit(bool isSuperUser) {
			return !NonBsp.IsLegacy && (isSuperUser || ((DocumentStatus == DocumentStatus.None || DocumentStatus == DocumentStatus.Open) && ReversalStatus == ReversalStatus.None && NonBsp.NonBspType != NonBspType.AgencyCC
				&& !NonBsp.Trip.IsLocked && NonBsp.AgencyCreditCardBspId <= 0 && NonBsp.AgencyCreditCardNonBspId <= 0 && NonBsp.LoyaltySchemeReceiptDetailId <= 0 && NonBsp.SupplierOtherCommissionReceiptId <= 0 && !NonBsp.AgencyCreditCardNonBsps.Any(t => t.PaymentId > 0)));
		}

		public bool CanDelete(bool isSuperUser) {
			return CanEdit(isSuperUser);
		}

		public bool CanUndo() {
			return false;
		}

		public bool CanReverse() {
			return !NonBsp.IsLegacy && DocumentStatus == DocumentStatus.Open && ReversalStatus != ReversalStatus.Reversed && NonBsp.NonBspType != NonBspType.AgencyCC && !NonBsp.Trip.IsLocked
				&& NonBsp.AgencyCreditCardBspId <= 0 && NonBsp.AgencyCreditCardNonBspId <= 0 && NonBsp.LoyaltySchemeReceiptDetailId <= 0 && NonBsp.SupplierOtherCommissionReceiptId <= 0;
		}
	}

	public class PaymentLinkModel {
		public int Id { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string AccountNameLink { get; set; }
		public decimal AmountPayable { get; set; }
	}

	public partial class Payment {
		[NotMapped]
		public DocumentStatus DocumentStatus {
			get {
				return (DocumentStatus)(PaymentDetails.Min(t => (int?)t.DocumentStatus) ?? -1);
			}
		}

		[NotMapped]
		public ReversalStatus ReversalStatus {
			get {
				return (ReversalStatus)(PaymentDetails.Min(t => (int?)t.ReversalStatus) ?? 0);
			}
		}

		[NotMapped]
		public AccountType AccountType {
			get {
				return PaymentType == PaymentType.SupplierPayment || PaymentType == PaymentType.ClientRefund ? AccountType.Client
					: PaymentType == PaymentType.BspReturn ? AccountType.None
					: PaymentType == PaymentType.NonBspReturn ? (CreditorId > 0 ? AccountType.Creditor : AccountType.None)
					: PaymentType == PaymentType.Admin ? (DebtorId > 0 ? AccountType.Debtor : (CreditorId > 0 ? AccountType.Creditor : (ChartOfAccountId > 0 ? AccountType.GeneralLedger : (TripId > 0 ? AccountType.Client : AccountType.None))))
					: AccountType.None;
			}
		}

		[NotMapped]
		public int Sign {
			get {
				return PaymentType == PaymentType.ClientRefund ? -1 : 1;
			}
		}

		[NotMapped]
		public bool IsClientAccountLocked {
			get {
				return Id > 0 && (PaymentType == PaymentType.SupplierPayment || PaymentType == PaymentType.ClientRefund || ((AccountType == AccountType.Client || AccountType == AccountType.Debtor || AccountType == AccountType.Creditor) && PaymentType == PaymentType.Admin)) && PaymentDetails.Count > 1;
			}
		}

		[NotMapped]
		public bool IsMatched {
			get {
				return PaymentType == PaymentType.NonBspReturn;
			}
		}

		[NotMapped]
		public bool IsDiscountPermitted {
			get {
				return PaymentType == PaymentType.SupplierPayment;
			}
		}

		[NotMapped]
		public bool IsMarkupPermitted {
			get {
				return PaymentType == PaymentType.SupplierPayment;
			}
		}

		[NotMapped]
		public decimal TotalAmount {
			get {
				return (PaymentDetails.Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0) - Discount - DiscountTax + Markup + MarkupTax;
			}
		}

		[NotMapped]
		public decimal TotalTax {
			get {
				return (PaymentDetails.Sum(t => (decimal?)t.Tax) ?? 0) - DiscountTax + MarkupTax;
			}
		}

		[NotMapped]
		public decimal TotalTaxRate {
			get {
				return AmountPayable == 0 ? 0 : Math.Round(AmountPayableTax / AmountPayable, 3);
			}
		}

		[NotMapped]
		public bool IsTaxApplicable {
			get {
				return (ChartOfAccountId > 0 && ChartOfAccount.IsTaxApplicable) || (SaleTypeId > 0 && SaleType.IsTaxApplicable);
			}
		}

		[NotMapped]
		public decimal TotalNonCommissionable {
			get {
				return PaymentDetails.Sum(t => (decimal?)(t.NonCommissionable + t.NonCommissionableTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal CommissionRateBySupplierCreditorSaleType {
			get {
				if (Supplier?.CommissionRate > 0) {
					return Supplier.CommissionRate;
				}
				else if (Creditor?.CommissionRate > 0) {
					return Creditor.CommissionRate;
				}
				else if (SaleType?.CommissionRate > 0) {
					return SaleType.CommissionRate;
				}

				return 0;
			}
		}

		[NotMapped]
		public string AccountName {
			get {
				return PaymentType == PaymentType.BspReturn ? Transactions.SelectMany(t => t.TransactionDetails).FirstOrDefault(t => t.ChartOfAccountId != BankAccount.ChartOfAccountId)?.ChartOfAccount.AccountName ?? Creditor.Name
					: TripId > 0 ? string.Concat(Trip.TripNo, ": ", PaymentDetails.FirstOrDefault(t => t.TripLineAirPassengerId > 0)?.TripLineAirPassenger.Passenger.FullName ?? Trip.FullName)
					: ChartOfAccountId > 0 ? ChartOfAccount.AccountName
					: CreditorId > 0 ? Creditor.AccountName
					: SupplierId > 0 ? Supplier.Name
					: DebtorId > 0 ? Debtor.AccountName
					: "Not Specified";
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				return PaymentType == PaymentType.BspReturn ? Transactions.SelectMany(t => t.TransactionDetails).FirstOrDefault(t => t.ChartOfAccountId != BankAccount.ChartOfAccountId)?.ChartOfAccount.AccountNameLink ?? string.Format(@"<a href=""/CreditorLedger/?id={0}"" target=""_blank"">{1}</a>", CreditorId, Creditor.AccountName)
					: TripId > 0 ? string.Format(@"<a href=""/ClientLedger/Trip/?profileId={0}&tripId={1}"" target=""_blank"">{2}</a>", Trip.ProfileId, TripId, string.Concat(Trip.TripNo, ": ", PaymentDetails.FirstOrDefault(t => t.TripLineAirPassengerId > 0)?.TripLineAirPassenger.Passenger.FullName ?? Trip.FullName))
					: ChartOfAccountId > 0 ? string.Format(@"<a href=""/GeneralLedger/ChartOfAccounts/?id={0}"" target=""_blank"">{1}{2}</a>", ChartOfAccountId, ChartOfAccount.AccountName, string.IsNullOrEmpty(Payee) ? string.Empty : string.Concat(" [", Payee, "]"))
					: CreditorId > 0 ? string.Format(@"<a href=""/CreditorLedger/?id={0}"" target=""_blank"">{1}</a>", CreditorId, Creditor.AccountName)
					: SupplierId > 0 ? string.Format(@"<a href=""/CreditorLedger/Suppliers/?id={0}"" target=""_blank"">{1}</a>", SupplierId, Supplier.Name)
					: DebtorId > 0 ? string.Format(@"<a href=""/DebtorLedger/?id={0}"" target=""_blank"">{1}</a>", DebtorId, Debtor.AccountName)
					: "Not Specified";
			}
		}

		public string GetDocumentNoLink(string source) {
            return Transaction.GetDocumentNoLink(source, TransactionType.Payment, Id, DocumentNo);
        }

        public string GetFormOfPaymentDetails() {
			return string.Format("{0} No {1}: {2} {3} on {4}", PaymentType == PaymentType.ClientRefund || (PaymentDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? "Refund" : "Payment", DocumentNo, PaymentType == PaymentType.ClientRefund || (PaymentDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0) < 0 ? "Refunded by" : "Paid with", string.Join("; ", PaymentDetails.Where(t => t.FormOfPaymentId > 0).Select(t => t.FormOfPayment.Name).Distinct()), DocumentDate.ToShortDateStringExt()).Replace("by Not Specified ", string.Empty).Replace("with Not Specified ", string.Empty).Replace("by  on", "on").Replace("with  on", "on");
		}

		public static string GetUniqueDocumentNo(AppMainContext context, int paymentId, int bankAccountId, bool isSplit, string documentNo) {
			if (string.IsNullOrEmpty(documentNo))
				return string.Empty;

			documentNo = Utils.RemoveExtraSpaces(documentNo).Replace(" ", string.Empty).ToUpper();

			var q = context.Payment.Where(t => t.Id != paymentId && t.BankAccountId == bankAccountId && !t.IsSplit);

			if (!q.Any(t => t.DocumentNo.ToLower() == documentNo.ToLower()))
				return documentNo;

			if (isSplit)
				throw new UnreportedException("Document No is already in use by a document that is not split.");

			char suffix = Convert.ToChar(documentNo.Right(1));
			int length = documentNo.Length;

			if (!char.IsDigit(suffix) && length > 5) {
				length--;
				documentNo = documentNo.Left(length);
			}
			else {
				suffix = 'A';
			}

			while (q.Any(t => t.DocumentNo.ToLower() == string.Format("{0}{1}", documentNo, suffix).ToLower())) {
				if (suffix == 'Z') {
					documentNo += "A";
					suffix = 'A';
					continue;
				}

				suffix = Convert.ToChar(suffix + 1);
			}

			return string.Format("{0}{1}", documentNo, suffix);
		}

		public bool ValidateTaxApplicability(bool isTaxApplicable) {
			if (PaymentDetails.Count == 0)
				return true;

			return IsTaxApplicable == isTaxApplicable;
		}

		public decimal GetCommission() {
			decimal amount = 0;

			if (PaymentType != PaymentType.BspReturn && PaymentType != PaymentType.NonBspReturn)
				amount = Commission;

			return amount;
		}

		public decimal GetCommissionTax() {
			decimal amount = 0;

			if (PaymentType != PaymentType.BspReturn && PaymentType != PaymentType.NonBspReturn)
				amount = CommissionTax;

			return amount;
		}

		public decimal GetMarkupGross() {
			return Markup == 0 ? 0 : PaymentDetails.Sum(t => (decimal?)t.GetMarkupGross()) ?? 0;
		}

		public decimal GetDocumentTotal(AppMainContext context) {
			return (context.PaymentDetail.Include(t => t.Payment).Where(t => t.PaymentId == Id || (t.Payment.PaymentType == PaymentType && t.Payment.IsSplit && t.Payment.DocumentNo == DocumentNo)).Sum(t => (decimal?)(t.Amount + t.Tax + t.NonCommissionable + t.NonCommissionableTax)) ?? 0) + (context.Payment.Where(t => t.Id == Id || (t.PaymentType == PaymentType && t.IsSplit && t.DocumentNo == DocumentNo)).Sum(t => (decimal?)(-t.Discount - t.DiscountTax + t.Markup + t.MarkupTax)) ?? 0);
		}

		public decimal GetDocumentAmountPayableGross(AppMainContext context, DocumentStatus documentStatus, int bankAccountId) {
			return context.Payment.Where(t => (t.Id == Id || (t.PaymentType == PaymentType && t.IsSplit && t.DocumentNo == DocumentNo)) && (bankAccountId <= 0 || t.BankAccountId == bankAccountId)).AsEnumerable().Where(t => t.DocumentStatus == documentStatus).Sum(t => (decimal?)(t.AmountPayable + t.AmountPayableTax)) ?? 0;
        }

        public decimal GetDocumentAmountPayable(AppMainContext context, DocumentStatus documentStatus, int bankAccountId) {
			return context.Payment.Where(t => (t.Id == Id || (t.PaymentType == PaymentType && t.IsSplit && t.DocumentNo == DocumentNo)) && (bankAccountId <= 0 || t.BankAccountId == bankAccountId)).AsEnumerable().Where(t => t.DocumentStatus == documentStatus).Sum(t => (decimal?)t.AmountPayable) ?? 0;
		}

		public decimal GetDocumentAmountPayableTax(AppMainContext context, DocumentStatus documentStatus, int bankAccountId) {
			return context.Payment.Where(t => (t.Id == Id || (t.PaymentType == PaymentType && t.IsSplit && t.DocumentNo == DocumentNo)) && (bankAccountId <= 0 || t.BankAccountId == bankAccountId)).AsEnumerable().Where(t => t.DocumentStatus == documentStatus).Sum(t => (decimal?)t.AmountPayableTax) ?? 0;
		}

		public decimal GetAmountPayableGross(AppMainContext context, bool calculateValue = false) {
			decimal amount = 0;

			switch (PaymentType) {
				default:
					amount = (PaymentDetails.Sum(t => (decimal?)(t.Cash + t.CashTax)) ?? 0) - Commission - CommissionTax;
					break;
				case PaymentType.BspReturn:
				case PaymentType.NonBspReturn:
					amount = GetAmountPayable(context, calculateValue);
					break;
			}

			return amount;
		}

		public decimal GetAmountPayable(AppMainContext context, bool calculateValue = false) {
			decimal amount = 0;

			switch (PaymentType) {
				default:
					amount = (PaymentDetails.Sum(t => (decimal?)t.Cash) ?? 0) - Commission;
					break;
				case PaymentType.BspReturn:
					int[] bspIds = context.Bsp.Where(t => t.PaymentId == Id && t.CreditorId == CreditorId).Select(t => t.Id).ToArray();
					amount = context.Bsp.Where(t => bspIds.Contains(t.Id)).AsEnumerable().Sum(t => (decimal?)t.GetAmountPayable(context, calculateValue, false)) ?? 0;
					break;
				case PaymentType.NonBspReturn:
					int[] nonBspIds = context.NonBsp.Where(t => t.PaymentId == Id && t.CreditorId == CreditorId).Select(t => t.Id).ToArray();
					amount = context.NonBsp.Where(t => nonBspIds.Contains(t.Id)).AsEnumerable().Sum(t => (decimal?)t.GetAmountPayable(context, calculateValue, false)) ?? 0;
					break;
			}

			return amount;
		}

		public decimal GetAmountPayableTax() {
			decimal amount = 0;

			if (PaymentType != PaymentType.BspReturn && PaymentType != PaymentType.NonBspReturn)
				amount = (PaymentDetails.Sum(t => (decimal?)t.CashTax) ?? 0) - CommissionTax;

			return amount;
		}

		public decimal GetTotalCashGross(AppMainContext context) {
			decimal amount = 0;

			if (PaymentType == PaymentType.BspReturn || PaymentType == PaymentType.NonBspReturn) {
				amount = GetAmountPayable(context);
			}
			else {
				amount = PaymentDetails.Sum(t => (decimal?)(t.Cash + t.CashTax)) ?? 0;
			}

			return amount;
		}

		public decimal GetTotalCashNonCommissionableGross() {
			decimal amount = 0;

			if (PaymentType != PaymentType.BspReturn && PaymentType != PaymentType.NonBspReturn)
				amount = PaymentDetails.Sum(t => (decimal?)(t.CashNonCommissionable + t.CashNonCommissionableTax)) ?? 0;

			return amount;
		}

		public decimal GetTotalCreditCardGross() {
			decimal amount = 0;

			if (PaymentType != PaymentType.BspReturn && PaymentType != PaymentType.NonBspReturn)
				amount = PaymentDetails.Sum(t => (decimal?)(t.CreditCard + t.CreditCardTax)) ?? 0;

			return amount;
		}

		public decimal GetTotalCreditCardNonCommissionableGross() {
			decimal amount = 0;

			if (PaymentType != PaymentType.BspReturn && PaymentType != PaymentType.NonBspReturn)
				amount = PaymentDetails.Sum(t => (decimal?)(t.CreditCardNonCommissionable + t.CreditCardNonCommissionableTax)) ?? 0;

			return amount;
		}

		public bool CanEdit(bool isAdministrator, bool isSuperUser) {
			return !IsLegacy && (isSuperUser
				|| (DocumentStatus == DocumentStatus.None || (isAdministrator && DocumentStatus == DocumentStatus.DepositedPaid)) && ReversalStatus == ReversalStatus.None
				&& PaymentType != PaymentType.BspReturn && PaymentType != PaymentType.NonBspReturn && !Trip.IsLocked && !PaymentDetails.Any(t => t.Id > 0 && t.TransactionDetailAllocations.Count > 0));
		}

		public bool CanDelete(bool isAdministrator, bool isAccounts, bool isSuperUser) {
			return CanEdit(isAdministrator, isSuperUser) || (!IsLegacy && (isAdministrator || isAccounts) && DocumentStatus == DocumentStatus.DepositedPaid
				&& (PaymentType == PaymentType.BspReturn || PaymentType == PaymentType.NonBspReturn));
		}

		public bool CanUndo(bool isBankReconciliation) {
			return isBankReconciliation && DocumentStatus == DocumentStatus.Closed;
		}

		public bool CanReverse() {
			return !IsLegacy && DocumentStatus == DocumentStatus.DepositedPaid && ReversalStatus != ReversalStatus.Reversed
				&& PaymentType != PaymentType.BspReturn && PaymentType != PaymentType.NonBspReturn && !Trip.IsLocked && !PaymentDetails.Any(t => t.Id > 0 && t.TransactionDetailAllocations.Count > 0);
		}
	}

	public partial class PaymentDetail {
		[NotMapped]
		public decimal NonCommissionableGross {
			get {
				return NonCommissionable + NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CommissionGrossProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.Commission + Payment.CommissionTax;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.Commission + Payment.CommissionTax - paymentDetail.Sum(t => (decimal?)(t.CommissionBaseProRata + t.CommissionTaxBaseProRata)) ?? 0;
				}

				return CommissionBaseProRata + CommissionTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal CommissionProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.Commission;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.Commission - (paymentDetail.Sum(t => (decimal?)t.CommissionBaseProRata) ?? 0);
				}

				return CommissionBaseProRata;
			}
		}

		[NotMapped]
		private decimal CommissionBaseProRata {
			get {
				decimal totalAmount = Payment.PaymentDetails.Sum(t => (decimal?)t.Amount) ?? 0;
				decimal ratio = totalAmount == 0 ? (1 / (decimal)Payment.PaymentDetails.Count) : Amount / totalAmount;
				return Payment.Commission * ratio;
			}
		}

		[NotMapped]
		public decimal CommissionTaxProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.CommissionTax;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.CommissionTax - (paymentDetail.Sum(t => (decimal?)t.CommissionTaxBaseProRata) ?? 0);
				}

				return CommissionTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal CommissionTaxBaseProRata {
			get {
				decimal totalTax = Payment.PaymentDetails.Sum(t => (decimal?)t.Tax) ?? 0;
				decimal ratio = totalTax == 0 ? (1 / (decimal)Payment.PaymentDetails.Count) : Tax / totalTax;
				return Payment.CommissionTax * ratio;
			}
		}

		[NotMapped]
		public decimal DiscountGrossProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.Discount + Payment.DiscountTax;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.Discount + Payment.DiscountTax - paymentDetail.Sum(t => (decimal?)(t.DiscountBaseProRata + t.DiscountTaxBaseProRata)) ?? 0;
				}

				return DiscountBaseProRata + DiscountTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal DiscountProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.Discount;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.Discount - (paymentDetail.Sum(t => (decimal?)t.DiscountBaseProRata) ?? 0);
				}

				return DiscountBaseProRata;
			}
		}

		[NotMapped]
		private decimal DiscountBaseProRata {
			get {
				return Payment.Discount * DiscountProRataRatio;
			}
		}

		[NotMapped]
		public decimal DiscountTaxProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.DiscountTax;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.DiscountTax - (paymentDetail.Sum(t => (decimal?)t.DiscountTaxBaseProRata) ?? 0);
				}

				return DiscountTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal DiscountTaxBaseProRata {
			get {
				return Payment.DiscountTax * DiscountProRataRatio;
			}
		}

		[NotMapped]
		public decimal DiscountProRataRatio {
			get {
				decimal totalAmount = 0;

				if (Payment.PaymentDetails.Count == 1) {
					return 1;
				}
				else if (!Payment.PaymentDetails.Any(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)) {
					totalAmount = Payment.PaymentDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}
				else if (Payment.IsCreditCardDiscountApplicable && FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
					totalAmount = Payment.PaymentDetails.Where(t => t.Payment.IsCreditCardDiscountApplicable && t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}

				return totalAmount == 0 ? 0 : (Amount + Tax) / totalAmount;
			}
		}

		[NotMapped]
		public decimal MarkupGrossProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.Markup + Payment.MarkupTax;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.Markup + Payment.MarkupTax - paymentDetail.Sum(t => (decimal?)(t.MarkupBaseProRata + t.MarkupTaxBaseProRata)) ?? 0;
				}

				return MarkupBaseProRata + MarkupTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal MarkupProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.Markup;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.Markup - (paymentDetail.Sum(t => (decimal?)t.MarkupBaseProRata) ?? 0);
				}

				return MarkupBaseProRata;
			}
		}

		[NotMapped]
		private decimal MarkupBaseProRata {
			get {
				return Payment.Markup * MarkupProRataRatio;
			}
		}

		[NotMapped]
		public decimal MarkupTaxProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.MarkupTax;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.MarkupTax - (paymentDetail.Sum(t => (decimal?)t.MarkupTaxBaseProRata) ?? 0);
				}

				return MarkupTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal MarkupTaxBaseProRata {
			get {
				return Payment.MarkupTax * MarkupProRataRatio;
			}
		}

		[NotMapped]
		public decimal MarkupProRataRatio {
			get {
				decimal totalAmount = 0;

				if (Payment.PaymentDetails.Count == 1) {
					return 1;
				}
				else if (!Payment.PaymentDetails.Any(t => t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard)) {
					totalAmount = Payment.PaymentDetails.Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}
				else if (Payment.IncludeMarkupInCreditCardPayment && FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard) {
					totalAmount = Payment.PaymentDetails.Where(t => t.Payment.IncludeMarkupInCreditCardPayment && t.FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
				}

				return totalAmount == 0 ? 0 : (Amount + Tax) / totalAmount;
			}
		}

		[NotMapped]
		public decimal AmountPayableGrossProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.AmountPayable + Payment.AmountPayableTax;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.AmountPayable + Payment.AmountPayableTax - paymentDetail.Sum(t => (decimal?)(t.AmountPayableBaseProRata + t.AmountPayableTaxBaseProRata)) ?? 0;
				}

				return AmountPayableBaseProRata + AmountPayableTaxBaseProRata;
			}
		}

		[NotMapped]
		public decimal AmountPayableProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.AmountPayable;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.AmountPayable - (paymentDetail.Sum(t => (decimal?)t.AmountPayableBaseProRata) ?? 0);
				}

				return AmountPayableBaseProRata;
			}
		}

		[NotMapped]
		private decimal AmountPayableBaseProRata {
			get {
				decimal totalAmount = Payment.PaymentDetails.Sum(t => (decimal?)t.Amount) ?? 0;
				decimal ratio = totalAmount == 0 ? (1 / (decimal)Payment.PaymentDetails.Count) : Amount / totalAmount;
				return Payment.AmountPayable * ratio;
			}
		}

		[NotMapped]
		public decimal AmountPayableTaxProRata {
			get {
				if (Payment.PaymentDetails.Count <= 1) {
					return Payment.AmountPayableTax;
				}
				else if (Payment.PaymentDetails.Last().Id == Id) {
					var paymentDetail = Payment.PaymentDetails.Where(t => t.Id != Id);
					return Payment.AmountPayableTax - (paymentDetail.Sum(t => (decimal?)t.AmountPayableTaxBaseProRata) ?? 0);
				}

				return AmountPayableTaxBaseProRata;
			}
		}

		[NotMapped]
		private decimal AmountPayableTaxBaseProRata {
			get {
				decimal totalTax = Payment.PaymentDetails.Sum(t => (decimal?)t.Tax) ?? 0;
				decimal ratio = totalTax == 0 ? (1 / (decimal)Payment.PaymentDetails.Count) : Tax / totalTax;
				return Payment.AmountPayableTax * ratio;
			}
		}

		[NotMapped]
		public decimal DiscountGrossPayableProRata {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard && Payment.IsCreditCardDiscountApplicable ? DiscountGrossProRata : 0;
			}
		}

		[NotMapped]
		public decimal MarkupGrossPayableProRata {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard && Payment.IncludeMarkupInCreditCardPayment ? MarkupGrossProRata : 0;
			}
		}

		[NotMapped]
		public decimal CreditCardDiscountAndMarkup {
			get {
				return (Payment.IsCreditCardDiscountApplicable ? DiscountProRata : 0) - (Payment.IncludeMarkupInCreditCardPayment ? MarkupProRata : 0);
			}
		}

		[NotMapped]
		public decimal CreditCardDiscountAndMarkupTax {
			get {
				return (Payment.IsCreditCardDiscountApplicable ? DiscountTaxProRata : 0) - (Payment.IncludeMarkupInCreditCardPayment ? MarkupTaxProRata : 0);
			}
		}

		[NotMapped]
		public decimal Cash {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? CreditCardDiscountAndMarkup : Amount + NonCommissionable;
			}
		}

		[NotMapped]
		public decimal CashTax {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? CreditCardDiscountAndMarkupTax : Tax + NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CashNonCommissionable {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? 0 : NonCommissionable;
			}
		}

		[NotMapped]
		public decimal CashNonCommissionableTax {
			get {
				return FormOfPayment.FormOfPaymentClass == FormOfPaymentClass.CreditCardTravelCard ? 0 : NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CreditCard {
			get {
				return Amount + NonCommissionable - Cash;
			}
		}

		[NotMapped]
		public decimal CreditCardTax {
			get {
				return Tax + NonCommissionableTax - CashTax;
			}
		}

		[NotMapped]
		public decimal CreditCardNonCommissionable {
			get {
				return NonCommissionable - CashNonCommissionable;
			}
		}

		[NotMapped]
		public decimal CreditCardNonCommissionableTax {
			get {
				return NonCommissionableTax - CashNonCommissionableTax;
			}
		}

		[NotMapped]
		public string PaymentDetails {
			get {
				return string.Format("Paid: {0} for {1}", TripLine.TripLineType == TripLineType.Air ? Payment.DocumentNo : TripLine.Description, FormOfPayment.Name);
			}
		}

		public decimal GetMarkupGross() {
			if (Payment.Markup == 0)
				return 0;

			switch (TripLine.TripLineType) {
				default:
					return 0;
				case TripLineType.Air:
					return TripLine.TripLineAir.TripLineAirPassengers.Where(t => TripLineAirPassengerId == t.Id).Sum(t => (decimal?)t.TicketedFare) ?? 0;
				case TripLineType.Accommodation:
				case TripLineType.Transport:
				case TripLineType.Cruise:
				case TripLineType.Tour:
				case TripLineType.OtherLand:
					return TripLine.TripLineLand.CommissionableValue;
				case TripLineType.Insurance:
					return TripLine.TripLineInsurance.TotalCommissionableSurcharge;
				case TripLineType.ForeignCurrency:
					return TripLine.TripLineForeignCurrency.EquivalentValue + TripLine.TripLineForeignCurrency.ClientFee;
				case TripLineType.ServiceFee:
					return TripLine.TripLineServiceFee.Gross;
				case TripLineType.OtherInclusion:
					return TripLine.TripLineOtherInclusion.Gross;
			}
		}

        public bool CanEdit(bool isAdministrator, bool isSuperUser) {
			return !Payment.IsLegacy && (isSuperUser
				|| (DocumentStatus == DocumentStatus.None || (isAdministrator && DocumentStatus == DocumentStatus.DepositedPaid)) && ReversalStatus == ReversalStatus.None
				&& Payment.PaymentType != PaymentType.BspReturn && Payment.PaymentType != PaymentType.NonBspReturn && !Payment.Trip.IsLocked && TransactionDetailAllocations.Count == 0);
		}

		public bool CanDelete(bool isAdministrator, bool isAccounts, bool isSuperUser) {
			return CanEdit(isAdministrator, isSuperUser) || (!Payment.IsLegacy && (isAdministrator || isAccounts) && DocumentStatus == DocumentStatus.DepositedPaid
				&& (Payment.PaymentType == PaymentType.BspReturn || Payment.PaymentType == PaymentType.NonBspReturn));
		}

		public bool CanUndo(bool isBankReconciliation) {
			return isBankReconciliation && DocumentStatus == DocumentStatus.Closed;
		}

		public bool CanReverse() {
			return !Payment.IsLegacy && DocumentStatus == DocumentStatus.DepositedPaid && ReversalStatus != ReversalStatus.Reversed
				&& Payment.PaymentType != PaymentType.BspReturn && Payment.PaymentType != PaymentType.NonBspReturn && !Payment.Trip.IsLocked && TransactionDetailAllocations.Count == 0;
		}
	}

	public partial class Invoice {
		[NotMapped]
		public DocumentStatus DocumentStatus {
			get {
				return (DocumentStatus)(InvoiceDetails.Min(t => (int?)t.DocumentStatus) ?? -1);
			}
		}

		[NotMapped]
		public decimal TotalAmount {
			get {
				return InvoiceDetails.Sum(t => (decimal?)(t.Amount + t.Tax + t.PaymentTax - t.Discount - t.DiscountTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalTax {
			get {
				return InvoiceDetails.Sum(t => (decimal?)(t.Tax + t.PaymentTax - t.DiscountTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalTaxRate {
			get {
				return TotalAmount - TotalTax == 0 ? 0 : Math.Round(TotalTax / (TotalAmount - TotalTax), 3);
			}
		}

		[NotMapped]
		public decimal TotalDiscount {
			get {
				return InvoiceDetails.Sum(t => (decimal?)(t.Discount + t.DiscountTax)) ?? 0;
			}
		}

		[NotMapped]
		public decimal TotalDiscountRate {
			get {
				return TotalAmount - TotalTax == 0 ? 0 : Math.Round(TotalDiscount / (TotalAmount - TotalTax), 3);
			}
		}

		[NotMapped]
		public string AccountName {
			get {
				return Id <= 0 || DebtorId <= 0 ? "Not Specified" : Debtor.AccountName;
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				return Id <= 0 || DebtorId <= 0 || Debtor == null ? "Not Specified" : string.Format(@"<a href=""/DebtorLedger/?id={0}"" target=""_blank"">{1}</a>", Debtor.Id, Debtor.AccountName);
			}
		}

		public string GetDocumentNoLink(string source) {
            return Transaction.GetDocumentNoLink(source, TransactionType.Invoice, Id, DocumentNo);
        }

        public string GetDebtorAddress(AppMainContext context, bool useCountryCode = false) {
			string address = string.Empty;

			if (!string.IsNullOrEmpty(DebtorAddress1))
				address += string.Format("{0}{1}", DebtorAddress1, AppConstants.HtmlLineBreak);

			if (!string.IsNullOrEmpty(DebtorAddress2))
				address += string.Format("{0}{1}", DebtorAddress2, AppConstants.HtmlLineBreak);

			string country = string.Empty;

			if (!string.IsNullOrEmpty(DebtorCountryCode)) {
				if (useCountryCode) {
					country = string.Concat(" ", DebtorCountryCode);
				}
				else {
					country = string.Concat(AppConstants.HtmlLineBreak, Country.GetCountry(context, DebtorCountryCode).Name);
				}
			}

			address += Utils.RemoveExtraSpaces(string.Concat(DebtorLocality, " ", DebtorRegion, " ", DebtorPostCode, country));
			return address.TrimEnd(AppConstants.HtmlLineBreak);
		}

		public bool CanEdit(bool isNew, bool isSuperUser) {
			return isSuperUser || isNew || (DocumentStatus == DocumentStatus.None && !IsMatched && !IsIssued && !InvoiceDetails.Any(t => t.Id > 0 && (t.Trip.IsLocked || t.TransactionDetailAllocations.Count > 0)));
		}

		public bool CanDelete(bool isNew, bool isAdministrator, bool isSuperUser) {
			return isSuperUser || isNew || (isAdministrator && DocumentStatus == DocumentStatus.None);
		}

		public bool CanUndo() {
			return false;
		}

		public bool CanReissue(bool isAutoMatchRequested = false) {
			return DocumentStatus != DocumentStatus.None && !(isAutoMatchRequested && IsMatched) && !InvoiceDetails.Any(t => t.Id > 0 && (t.Trip.IsLocked || t.TransactionDetailAllocations.Count > 0));
		}
	}

	public partial class InvoiceDetail {
		[NotMapped]
		public decimal AvailableCredit { get; set; }

		[NotMapped]
		public bool IsTaxApplicable {
			get {
				return ChartOfAccount.IsTaxApplicable || SaleType.IsTaxApplicable;
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				string description = string.Empty;

				if (IsPayment || Invoice.AccountType == AccountType.Client) {
					if (IsPayment) {
						description = Description;
					}
					else if (TripLineAirPassengerId > 0) {
						description = string.Format("{0}: {1}", Trip.TripNo, string.Format("{0}{1}", TripLineAirPassenger.Passenger.FullName, string.IsNullOrEmpty(TripLineAirPassenger.TicketNo) ? string.Empty : string.Concat(": Ticket No ", TripLineAirPassenger.TicketNo)));
					}
					else if (TripLineId > 0) {
						description = string.Format("{0}: {1}", Trip.TripNo, TripLine.Description);
					}
					else if (TripId > 0) {
						description = Trip.AccountName;
					}

					return string.Format(@"<a href=""javascript:void(0)"" onclick=""InvoiceDetailEdit.TripLineEdit({0}, {1}, {2}, {3}); return false;"">{4}</a>", (int)TripLine.TripLineType, TripId, TripLineId, TripLineAirPassengerId, description.TrimEnd('.'));
				}
				else if (Invoice.AccountType == AccountType.GeneralLedger && ChartOfAccountId > 0) {
					return string.Format(@"<a href=""/GeneralLedger/ChartOfAccounts/?id={0}"" target=""_blank"">{1}</a>", ChartOfAccount.Id, ChartOfAccount.AccountName);
				}

				return "Not Specified";
			}
		}

		[NotMapped]
		public decimal InvoiceDetailTotalAmount {
			get {
				return Amount + Tax - Discount - DiscountTax;
			}
		}

		public decimal GetDiscountLessAgentCommission(int customerId) {
			int agentCommissionDiscountReasonId = AppSettings.Setting(customerId).AgentCommissionDiscountReasonId;

			return DiscountReasonId > 0 && DiscountReasonId != agentCommissionDiscountReasonId ? Discount + DiscountTax : 0;
		}

		public decimal GetAgentCommission(int customerId) {
			int agentCommissionDiscountReasonId = AppSettings.Setting(customerId).AgentCommissionDiscountReasonId;

			if (agentCommissionDiscountReasonId <= 0)
				return 0;

			return DiscountReasonId > 0 && DiscountReason.Id == agentCommissionDiscountReasonId ? Discount + DiscountTax : 0;
		}

        public bool CanEdit(bool isNew, bool isSuperUser) {
			return Id <= 0 || isSuperUser || isNew || (DocumentStatus == DocumentStatus.None && !Invoice.IsMatched && !Invoice.IsIssued && !Trip.IsLocked && TransactionDetailAllocations.Count == 0);
		}

		public bool CanDelete(bool isNew, bool isSuperUser) {
			return isSuperUser || isNew;
		}

		public bool CanUndo() {
			return false;
		}

		public bool CanReissue(bool isAutoMatchRequested = false) {
			return DocumentStatus != DocumentStatus.None && !(isAutoMatchRequested && Invoice.IsMatched) && !Trip.IsLocked && TransactionDetailAllocations.Count == 0;
		}
	}

	public partial class Journal {
		[NotMapped]
		public decimal TotalAmount {
			get {
				return JournalDetails.Sum(t => (decimal?)(t.SignType == SignType.Debit ? t.Amount : -t.Amount)) ?? 0;
			}
		}

		[NotMapped]
		public string Comments {
			get {
				return string.Join("; ", JournalDetails.Where(t => t.Comments.Length > 0).Select(t => t.Comments).Distinct());
			}
		}

		public string GetDocumentNoLink(string source) {
            return Transaction.GetDocumentNoLink(source, TransactionType.Journal, Id, DocumentNo);
        }

        public bool CanEdit(bool isSuperUser) {
			return !IsLegacy && (isSuperUser || ((DocumentStatus == DocumentStatus.None || DocumentStatus == DocumentStatus.Open) && !JournalDetails.Any(t => t.Id > 0 && (t.Trip.IsLocked || t.TransactionDetailAllocations.Count > 0))));
		}

		public bool CanDelete(bool isSuperUser) {
			return CanEdit(isSuperUser);
		}

		public bool CanUndo() {
			return false;
		}

		public bool CanReverse() {
			return !IsLegacy && DocumentStatus == DocumentStatus.Closed && ReversalStatus != ReversalStatus.Reversed && !JournalDetails.Any(t => t.Id > 0 && (t.Trip.IsLocked || t.TransactionDetailAllocations.Count > 0));
		}

		public static IQueryable<Journal> GetJournalQuery(AppLazyContext lazyContext, int agencyId, int journalId, DateTime? dateFrom, DateTime? dateTo, int accountTypeId, int? documentStatusId, decimal? amountFrom, decimal? amountTo, string account, string text) {
			var accountType = (AccountType)accountTypeId;
			var documentStatus = (DocumentStatus?)documentStatusId;

			var q = lazyContext.Journal.Where(t => t.Id > 0);

			if (journalId > 0) {
				q = q.Where(t => t.Id == journalId);
			}
			else {
				if (agencyId != -1 && documentStatus != DocumentStatus.None)
					q = q.Where(t1 => t1.JournalDetails.Any(t2 => (t2.AccountType == AccountType.Client ? t2.Trip.AgencyId : t2.AccountType == AccountType.Debtor ? t2.Debtor.AgencyId : t2.AccountType == AccountType.Creditor ? t2.Creditor.AgencyId : t2.AccountType == AccountType.GeneralLedger ? t2.ChartOfAccount.AgencyId : -1) == agencyId));

				if (dateFrom != null)
					q = q.Where(t => t.DocumentDate >= dateFrom);

				if (dateTo != null)
					q = q.Where(t => t.DocumentDate <= dateTo);

				if (accountType != AccountType.None)
					q = q.Where(t1 => t1.JournalDetails.Any(t2 => t2.AccountType == accountType));

				if (documentStatus != null) {
					if (documentStatus == DocumentStatus.None) {
						q = q.Where(t => t.JournalDetails.Count == 0);
					}
					else {
						q = q.Where(t => t.DocumentStatus == documentStatus);
					}
				}

				if (amountFrom != null)
					q = q.Where(t1 => (t1.JournalDetails.Sum(t2 => (decimal?)(t2.SignType == SignType.Debit ? t2.Amount : -t2.Amount)) ?? 0) >= amountFrom);

				if (amountTo != null)
					q = q.Where(t1 => (t1.JournalDetails.Sum(t2 => (decimal?)(t2.SignType == SignType.Debit ? t2.Amount : -t2.Amount)) ?? 0) <= amountTo);

				if (!string.IsNullOrEmpty(account)) {
					var predicate = PredicateBuilder.False<JournalDetail>();

					foreach (var row in account.Trim().ToLower().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries)) {
						predicate = predicate.Or(t => t.Trip.Id.ToString().Contains(row) || (t.Trip.Title + " " + t.Trip.FirstName + " " + t.Trip.LastName).Trim().ToLower().Contains(row) || t.Debtor.Code.ToLower().Contains(row) || t.Debtor.Name.ToLower().Contains(row) || t.Creditor.Name.ToLower().Contains(row) || t.ChartOfAccount.Code.ToLower().Contains(row) || t.ChartOfAccount.Name.ToLower().Contains(row));
					}

					var journalDetailIds = lazyContext.JournalDetail.Where(predicate).Select(t => t.Id);
					q = q.Where(t1 => t1.JournalDetails.Any(t2 => journalDetailIds.Contains(t2.Id)));
				}

				if (!string.IsNullOrEmpty(text)) {
					text = text.Trim().ToLower();
					q = q.Where(t1 => t1.DocumentNo.ToLower().Contains(text) || t1.JournalDetails.Any(t2 => t2.Comments.ToLower().Contains(text)));
				}
			}

			return q.OrderByDescending(t => t.DocumentDate).ThenByDescending(t => t.DocumentNo);
		}
	}

	public partial class JournalDetail {
		[NotMapped]
		public string AccountName {
			get {
				return Id <= 0 ? "Not Specified"
					: AccountType == AccountType.Client ? TripId <= 0 ? "Not Specified" : Trip.AccountName
					: AccountType == AccountType.Debtor ? DebtorId <= 0 ? "Not Specified" : Debtor.AccountName
					: AccountType == AccountType.Creditor ? CreditorId <= 0 ? "Not Specified" : Creditor.AccountName
					: ChartOfAccountId <= 0 ? "Not Specified" : ChartOfAccount.AccountName;
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				return Id <= 0 ? "Not Specified"
					: AccountType == AccountType.Client ? TripId <= 0 ? "Not Specified" : string.Format(@"<a href=""/ClientLedger/Trip/?profileId={0}&tripId={1}"" target=""_blank"">{2}</a>", Trip.ProfileId, TripId, Trip.AccountName)
					: AccountType == AccountType.Debtor ? DebtorId <= 0 ? "Not Specified" : string.Format(@"<a href=""/DebtorLedger/?id={0}"" target=""_blank"">{1}</a>", Debtor.Id, Debtor.AccountName)
					: AccountType == AccountType.Creditor ? CreditorId <= 0 ? "Not Specified" : string.Format(@"<a href=""/CreditorLedger/?id={0}"" target=""_blank"">{1}</a>", Creditor.Id, Creditor.AccountName)
				   : ChartOfAccountId <= 0 ? "Not Specified" : string.Format(@"<a href=""/GeneralLedger/ChartOfAccounts/?id={0}"" target=""_blank"">{1}</a>", ChartOfAccount.Id, ChartOfAccount.AccountName);
			}
		}

		public bool CanEdit(bool isSuperUser) {
			return Journal.CanEdit(isSuperUser);
		}

		public bool CanDelete(bool isSuperUser) {
			return Journal.CanDelete(isSuperUser);
		}

		public bool CanUndo() {
			return false;
		}

		public bool CanReverse() {
			return false;
		}
	}

	public partial class Adjustment {
		[NotMapped]
		public bool IsTaxApplicable {
			get {
				return IsDebitTaxApplicable || IsCreditTaxApplicable;
			}
		}

		[NotMapped]
		public bool IsDebitTaxApplicable {
			get {
				return DebitType == DebitCreditType.GeneralLedger && (SaleTypeId > 0 ? SaleType.IsTaxApplicable : DebitChartOfAccount.IsTaxApplicable);
			}
		}

		[NotMapped]
		public bool IsCreditTaxApplicable {
			get {
				return CreditType == DebitCreditType.GeneralLedger && (SaleTypeId > 0 ? SaleType.IsTaxApplicable : CreditChartOfAccount.IsTaxApplicable);
			}
		}

		[NotMapped]
		public string DebitAccountName {
			get {
				return Id <= 0 ? "Not Specified"
					: DebitType == DebitCreditType.Client ? DebitTripId <= 0 ? "Not Specified" : DebitTrip.AccountName
					: DebitType == DebitCreditType.Debtor ? DebitDebtorId <= 0 ? "Not Specified" : DebitDebtor.AccountName
					: DebitType == DebitCreditType.Creditor ? DebitCreditorId <= 0 ? "Not Specified" : DebitCreditor.Name
					: DebitChartOfAccountId <= 0 ? "Not Specified" : DebitChartOfAccount.AccountName;
			}
		}

		[NotMapped]
		public string DebitAccountNameLink {
			get {
				return Id <= 0 ? "Not Specified"
					: DebitType == DebitCreditType.Client ? DebitTripId <= 0 ? "Not Specified" : string.Format(@"<a href=""/ClientLedger/Trip/?profileId={0}&tripId={1}"" target=""_blank"">{2}</a>", DebitTrip.ProfileId, DebitTripId, DebitTrip.AccountName)
					: DebitType == DebitCreditType.Debtor ? DebitDebtorId <= 0 ? "Not Specified" : string.Format(@"<a href=""/DebtorLedger/?id={0}"" target=""_blank"">{1}</a>", DebitDebtor.Id, DebitDebtor.AccountName)
					: DebitType == DebitCreditType.Creditor ? DebitCreditorId <= 0 ? "Not Specified" : string.Format(@"<a href=""/CreditorLedger/Creditors/?id={0}"" target=""_blank"">{1}</a>", DebitCreditor.Id, DebitCreditor.Name)
					: DebitChartOfAccountId <= 0 ? "Not Specified" : string.Format(@"<a href=""/GeneralLedger/ChartOfAccounts/?id={0}"" target=""_blank"">{1}</a>", DebitChartOfAccount.Id, DebitChartOfAccount.AccountName);
			}
		}

		[NotMapped]
		public string CreditAccountName {
			get {
				return Id <= 0 ? "Not Specified"
					: CreditType == DebitCreditType.Client ? CreditTripId <= 0 ? "Not Specified" : CreditTrip.AccountName
					: CreditType == DebitCreditType.Debtor ? CreditDebtorId <= 0 ? "Not Specified" : CreditDebtor.AccountName
					: CreditType == DebitCreditType.Creditor ? CreditCreditorId <= 0 ? "Not Specified" : CreditCreditor.Name
					: CreditChartOfAccountId <= 0 ? "Not Specified" : CreditChartOfAccount.AccountName;
			}
		}

		[NotMapped]
		public string CreditAccountNameLink {
			get {
				return Id <= 0 ? "Not Specified"
				: CreditType == DebitCreditType.Client ? CreditTripId <= 0 ? "Not Specified" : string.Format(@"<a href=""/ClientLedger/Trip/?profileId={0}&tripId={1}"" target=""_blank"">{2}</a>", CreditTrip.ProfileId, CreditTripId, CreditTrip.AccountName)
				: CreditType == DebitCreditType.Debtor ? CreditDebtorId <= 0 ? "Not Specified" : string.Format(@"<a href=""/DebtorLedger/?id={0}"" target=""_blank"">{1}</a>", CreditDebtor.Id, CreditDebtor.AccountName)
				: CreditType == DebitCreditType.Creditor ? CreditCreditorId <= 0 ? "Not Specified" : string.Format(@"<a href=""/CreditorLedger/Creditors/?id={0}"" target=""_blank"">{1}</a>", CreditCreditor.Id, CreditCreditor.Name)
				: CreditChartOfAccountId <= 0 ? "Not Specified" : string.Format(@"<a href=""/GeneralLedger/ChartOfAccounts/?id={0}"" target=""_blank"">{1}</a>", CreditChartOfAccount.Id, CreditChartOfAccount.AccountName);
			}
		}

		[NotMapped]
		public string AccountName {
			get {
				return DebitAccountNameLink == "Not Specified" ? CreditAccountName : DebitAccountName;
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				return DebitAccountNameLink == "Not Specified" ? CreditAccountNameLink : DebitAccountNameLink;
			}
		}

		public string GetDocumentNoLink(string source) {
            return Transaction.GetDocumentNoLink(source, TransactionType.Adjustment, Id, DocumentNo);
        }

        public decimal GetTax(int customerId) {
			if (!IsTaxApplicable)
				return 0;

			decimal taxRate = CustomerSettings.GetTaxRate(customerId, DocumentDate);
			return Math.Round(Amount * taxRate / (1 + taxRate), 2);
		}

		public bool CanEdit(bool isAdministrator, bool isSuperUser) {
			return isSuperUser || ((DocumentStatus == DocumentStatus.None || (isAdministrator && DocumentStatus == DocumentStatus.Open)) && ReversalStatus == ReversalStatus.None
				&& !(DebitTrip?.IsLocked ?? false) && !(CreditTrip?.IsLocked ?? false) && TransactionDetailAllocations?.Count(t => t.AdjustmentId > 0) == 0);
		}

		public bool CanDelete(bool isAdministrator, bool isSuperUser) {
			return CanEdit(isAdministrator, isSuperUser);
		}

		public bool CanUndo() {
			return false;
		}

		public bool CanReverse() {
			return DocumentStatus != DocumentStatus.None && ReversalStatus != ReversalStatus.Reversed && !(DebitTrip?.IsLocked ?? false) && !(CreditTrip?.IsLocked ?? false) && TransactionDetailAllocations.Count == 0;
		}
	}

	public partial class Voucher {
		[NotMapped]
		public bool IsTaxApplicable {
			get {
				return SaleType.IsTaxApplicable;
			}
		}

		[NotMapped]
		public decimal CommissionRate {
			get {
				return Math.Round(Amount + Tax == 0 ? 0 : Commission / (Amount + Tax), 3);
			}
		}

		[NotMapped]
		public decimal DiscountRate {
			get {
				return Math.Round(Amount + Tax == 0 ? 0 : Discount / (Amount + Tax), 3);
			}
		}

		[NotMapped]
		public decimal CommissionRateBySupplierCreditorSaleType {
			get {
				if (Supplier?.CommissionRate > 0) {
					return Supplier.CommissionRate;
				}
				else if (Creditor?.CommissionRate > 0) {
					return Creditor.CommissionRate;
				}
				else if (SaleType?.CommissionRate > 0) {
					return SaleType.CommissionRate;
				}

				return 0;
			}
		}

		[NotMapped]
		public int AgencyId {
			get {
				return Trip.AgencyId;
			}
		}

		[NotMapped]
		public string AccountName {
			get {
				return Id <= 0 ? "Not Specified" : TripId <= 0 ? "Not Specified" : Trip.AccountName;
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				return Id <= 0 ? "Not Specified" : TripId <= 0 ? "Not Specified" : string.Format(@"<a href=""/ClientLedger/Trip/?profileId={0}&tripId={1}"" target=""_blank"">{2}</a>", Trip.ProfileId, TripId, Trip.AccountName);
			}
		}

		[NotMapped]
		public string SupplierContactFullName {
			get {
				return string.Concat(SupplierContactTitle, " ", SupplierContactName).Trim();
			}
		}

		[NotMapped]
		public string SupplierContactPhoneNo {
			get {
				return string.IsNullOrEmpty(SupplierContactMobile) ? string.IsNullOrEmpty(SupplierContactPhoneWork) ? SupplierContactPhoneHome : SupplierContactPhoneWork : SupplierContactMobile;
			}
		}

		[NotMapped]
		public PaymentClass PaymentClass {
			get {
				return VoucherType == VoucherType.PaidDirect || VoucherType == VoucherType.BillbackClientDirect ? PaymentClass.PaidDirect : PaymentClass.PaidToAgency;
			}
		}

		public string GetSupplierAddress(AppMainContext context, bool useCountryCode = false) {
			string address = string.Empty;

			if (!string.IsNullOrEmpty(SupplierAddress1))
				address += string.Format("{0}{1}", SupplierAddress1, AppConstants.HtmlLineBreak);

			if (!string.IsNullOrEmpty(SupplierAddress2))
				address += string.Format("{0}{1}", SupplierAddress2, AppConstants.HtmlLineBreak);

			string country = string.Empty;

			if (!string.IsNullOrEmpty(SupplierCountryCode)) {
				if (useCountryCode) {
					country = string.Concat(" ", SupplierCountryCode);
				}
				else {
					country = string.Concat(AppConstants.HtmlLineBreak, Country.GetCountry(context, SupplierCountryCode).Name);
				}
			}

			address += Utils.RemoveExtraSpaces(string.Concat(SupplierLocality, " ", SupplierRegion, " ", SupplierPostCode, country));
			return address.TrimEnd(AppConstants.HtmlLineBreak);
		}

		public string GetServiceTypeRateBasisDescription(TripLineLand tripLineLand, int customerId) {
			return tripLineLand.GetServiceTypeRateBasisDescription(customerId).Replace(string.Format("{0}{0}{0}{0}{0}", AppConstants.HtmlSpace), " - ");
		}

		public string GetDocumentNoLink(string source) {
			return string.Format(@"<a href=""#"" onclick=""{0}.VoucherEdit({1});"">{2}</a>", source, Id, DocumentNo);
		}

		public decimal GetNetValue(bool isTaxIncluded) {
			return Amount - Commission - Discount + (isTaxIncluded ? 0 : Tax - CommissionTax - DiscountTax);
		}

		public bool CanEdit(bool isAdministrator, bool isSuperUser) {
			return isSuperUser || ((DocumentStatus == DocumentStatus.None || isAdministrator && (DocumentStatus == DocumentStatus.Open)) && ReversalStatus == ReversalStatus.None && !IsIssued
				&& !ReceiptDetails.Any(t => t.ReceiptId > 0));
		}

		public bool CanDelete(bool isSuperUser) {
			return isSuperUser;
		}

		public bool CanUndo() {
			return false;
		}

		public bool CanReverse() {
			return DocumentStatus != DocumentStatus.None && ReversalStatus != ReversalStatus.Reversed && !ReceiptDetails.Any(t => t.ReceiptId > 0);
		}
	}

	public partial class PaymentMethod {
		[NotMapped]
		public string AccountName {
			get {
				return Id <= 0 ? "Not Specified"
				: AccountType == AccountType.Client ? ProfileId <= 0 && TripId <= 0 ? "Not Specified" : ProfileId <= 0 ? Trip.AccountName : Profile.AccountName
				: AccountType == AccountType.Debtor ? DebtorId <= 0 ? "Not Specified" : Debtor.AccountName
				: AccountType == AccountType.Creditor ? CreditorId <= 0 ? "Not Specified" : Creditor.AccountName
				: ChartOfAccountId <= 0 ? "Not Specified" : ChartOfAccount.AccountName;
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				return Id <= 0 ? "Not Specified"
				: AccountType == AccountType.Client ? ProfileId <= 0 && TripId <= 0 ? "Not Specified" : ProfileId <= 0 ? string.Format(@"<a href=""/ClientLedger/Trip/?profileId={0}&tripId={1}"" target=""_blank"">{2}</a>", Trip.ProfileId, TripId, Trip.AccountName) : string.Format(@"<a href=""/ClientLedger/Profile/?profileId={0}"" target=""_blank"">{1}</a>", ProfileId, Profile.AccountName)
				: AccountType == AccountType.Debtor ? DebtorId <= 0 ? "Not Specified" : string.Format(@"<a href=""/DebtorLedger/?id={0}"" target=""_blank"">{1}</a>", Debtor.Id, Debtor.AccountName)
				: AccountType == AccountType.Creditor ? CreditorId <= 0 ? "Not Specified" : string.Format(@"<a href=""/CreditorLedger/?id={0}"" target=""_blank"">{1}</a>", Creditor.Id, Creditor.AccountName)
				: ChartOfAccountId <= 0 ? "Not Specified" : string.Format(@"<a href=""/GeneralLedger/ChartOfAccounts/?id={0}"" target=""_blank"">{1}</a>", ChartOfAccount.Id, ChartOfAccount.AccountName);
			}
		}
	}

	public partial class Transaction {
		[NotMapped]
		public int TransactionRefId {
			get {
				return TransactionType == TransactionType.Receipt ? ReceiptId
					: TransactionType == TransactionType.Bsp ? BspId
					: TransactionType == TransactionType.NonBsp ? NonBspId
					: TransactionType == TransactionType.Payment ? PaymentId
					: TransactionType == TransactionType.Invoice ? InvoiceId
					: TransactionType == TransactionType.Journal ? JournalId
					: TransactionType == TransactionType.Adjustment ? AdjustmentId
					: 0;
			}
		}

		[NotMapped]
		public TransactionType EffectiveTransactionType {
			get {
				return Invoice.InvoiceType == InvoiceType.CreditNote ? TransactionType.CreditNote : TransactionType;
			}
		}

		[NotMapped]
		public DocumentStatus DocumentStatus {
			get {
				return TransactionDetails.Count == 0 ? DocumentStatus.None : (DocumentStatus)TransactionDetails.Min(t => (int)t.DocumentStatus);
			}
		}

		[NotMapped]
		public string AccountName {
			get {
				return TransactionType == TransactionType.Receipt ? Receipt.AccountName
					: TransactionType == TransactionType.Bsp ? Bsp.AccountName
					: TransactionType == TransactionType.NonBsp ? NonBsp.AccountName
					: TransactionType == TransactionType.Payment ? Payment.AccountName
					: TransactionType == TransactionType.Invoice ? Invoice.AccountName
					: TransactionType == TransactionType.Adjustment ? Adjustment.AccountName
					: string.Empty;
			}
		}

		public string GetDocumentNoLink(string source) {
			return GetDocumentNoLink(source, TransactionType, TransactionRefId, DocumentNo);
		}

        public static string GetDocumentNoLink(string source, TransactionType transactionType, int id, string documentNo) {
            return string.Format(@"<a href=""#"" onclick=""Global.AccountingEdit($('#{0}'), '{1}', '{2}');"">{3}</a>", source, id, (int)transactionType, documentNo);
        }

        public bool CanEdit(bool isAdministrator, bool isAccounts, bool isSuperUser) {
			return TransactionType == TransactionType.Receipt ? Receipt?.CanEdit(isAdministrator, isAccounts, isSuperUser) ?? false
				: TransactionType == TransactionType.Bsp ? Bsp?.CanEdit(isSuperUser) ?? false
				: TransactionType == TransactionType.NonBsp ? NonBsp?.CanEdit(isSuperUser) ?? false
				: TransactionType == TransactionType.Payment ? Payment?.CanEdit(isAdministrator, isSuperUser) ?? false
				: TransactionType == TransactionType.Invoice ? Invoice?.CanEdit(false, isSuperUser) ?? false
				: TransactionType == TransactionType.Journal ? Journal?.CanEdit(isSuperUser) ?? false
				: TransactionType == TransactionType.Adjustment && (Adjustment?.CanEdit(isAdministrator, isSuperUser) ?? false);
		}

		public bool CanDelete(bool isAdministrator, bool isAccounts, bool isSuperUser) {
			return TransactionType == TransactionType.Receipt ? Receipt?.CanDelete(isAdministrator, isAccounts, isSuperUser) ?? false
				: TransactionType == TransactionType.Bsp ? Bsp?.CanDelete(isSuperUser) ?? false
				: TransactionType == TransactionType.NonBsp ? NonBsp?.CanDelete(isSuperUser) ?? false
				: TransactionType == TransactionType.Payment ? Payment?.CanDelete(isAdministrator, isAccounts, isSuperUser) ?? false
				: TransactionType == TransactionType.Invoice ? Invoice?.CanDelete(false, isAdministrator, isSuperUser) ?? false
				: TransactionType == TransactionType.Journal ? Journal?.CanDelete(isSuperUser) ?? false
				: TransactionType == TransactionType.Adjustment && (Adjustment?.CanDelete(isAdministrator, isSuperUser) ?? false);
		}

		public bool CanUndo() {
			return TransactionType == TransactionType.Receipt ? Receipt?.CanUndo(false) ?? false
				: TransactionType == TransactionType.Bsp ? Bsp?.CanUndo() ?? false
				: TransactionType == TransactionType.NonBsp ? NonBsp?.CanUndo() ?? false
				: TransactionType == TransactionType.Payment ? Payment?.CanUndo(false) ?? false
				: TransactionType == TransactionType.Invoice ? Invoice?.CanUndo() ?? false
				: TransactionType == TransactionType.Journal ? Journal?.CanUndo() ?? false
				: TransactionType == TransactionType.Adjustment && (Adjustment?.CanUndo() ?? false);
		}

		public bool CanReverse() {
			return TransactionType == TransactionType.Receipt ? Receipt?.CanReverse() ?? false
				: TransactionType == TransactionType.Bsp ? Bsp?.CanReverse() ?? false
				: TransactionType == TransactionType.NonBsp ? NonBsp?.CanReverse() ?? false
				: TransactionType == TransactionType.Payment ? Payment?.CanReverse() ?? false
				: TransactionType == TransactionType.Invoice ? Invoice?.CanReissue() ?? false
				: TransactionType == TransactionType.Journal ? Journal?.CanReverse() ?? false
				: TransactionType == TransactionType.Adjustment && (Adjustment?.CanReverse() ?? false);
		}
	}

	public partial class TransactionDetail {
        [NotMapped]
        public string AccountName {
            get {
                return (LedgerType == LedgerType.ClientLedger ? Trip.AccountName
                    : LedgerType == LedgerType.DebtorLedger ? Debtor.AccountName
                    : LedgerType == LedgerType.CreditorLedger ? Creditor.AccountName
                    : LedgerType == LedgerType.GeneralLedger ? ChartOfAccount.AccountName
                    : string.Empty).Replace("Not Specified", string.Empty);
            }
        }

        [NotMapped]
        public string TxnAccountName {
            get {
                return (ReceiptDetailId > 0 ? ReceiptDetail.Receipt.TripId != TripId && ReceiptDetail.Receipt.TripId > 0 ? ReceiptDetail.Receipt.Trip.AccountName : ReceiptDetail.Receipt.DebtorId != DebtorId && ReceiptDetail.Receipt.DebtorId > 0 ? ReceiptDetail.Receipt.Debtor.AccountName : ReceiptDetail.Receipt.CreditorId != CreditorId && ReceiptDetail.Receipt.CreditorId > 0 ? ReceiptDetail.Receipt.Creditor.AccountName : ReceiptDetail.Receipt.ChartOfAccountId != ChartOfAccountId && ReceiptDetail.Receipt.ChartOfAccountId > 0 ? ReceiptDetail.Receipt.ChartOfAccount.AccountName : string.Empty
                    : BspDetailId > 0 ? BspDetail.Bsp.TripId != TripId && BspDetail.Bsp.TripId > 0 ? BspDetail.Bsp.Trip.AccountName : BspDetail.Bsp.CreditorId != CreditorId && BspDetail.Bsp.CreditorId > 0 ? BspDetail.Bsp.Creditor.AccountName : string.Empty
                    : NonBspDetailId > 0 ? NonBspDetail.NonBsp.TripId != TripId && NonBspDetail.NonBsp.TripId > 0 ? NonBspDetail.NonBsp.Trip.AccountName : NonBspDetail.NonBsp.CreditorId != CreditorId && NonBspDetail.NonBsp.CreditorId > 0 ? NonBspDetail.NonBsp.Creditor.AccountName : NonBspDetail.NonBsp.ChartOfAccountId != ChartOfAccountId && NonBspDetail.NonBsp.ChartOfAccountId > 0 ? NonBspDetail.NonBsp.ChartOfAccount.AccountName : string.Empty
                    : PaymentDetailId > 0 ? PaymentDetail.Payment.TripId != TripId && PaymentDetail.Payment.TripId > 0 ? PaymentDetail.Payment.Trip.AccountName : PaymentDetail.Payment.DebtorId != DebtorId && PaymentDetail.Payment.DebtorId > 0 ? PaymentDetail.Payment.Debtor.AccountName : PaymentDetail.Payment.CreditorId != PaymentDetail.Payment.CreditorId && CreditorId > 0 ? PaymentDetail.Payment.Creditor.AccountName : PaymentDetail.Payment.ChartOfAccountId != ChartOfAccountId && PaymentDetail.Payment.ChartOfAccountId > 0 ? PaymentDetail.Payment.ChartOfAccount.AccountName : string.Empty
                    : InvoiceDetailId > 0 ? InvoiceDetail.TripId != TripId && InvoiceDetail.TripId > 0 ? InvoiceDetail.Trip.AccountName : InvoiceDetail.Invoice.DebtorId != DebtorId && InvoiceDetail.Invoice.DebtorId > 0 ? InvoiceDetail.Invoice.Debtor.AccountName : InvoiceDetail.CreditorId != CreditorId && InvoiceDetail.CreditorId > 0 ? InvoiceDetail.Creditor.AccountName : InvoiceDetail.ChartOfAccountId != ChartOfAccountId && InvoiceDetail.ChartOfAccountId > 0 ? InvoiceDetail.ChartOfAccount.AccountName : string.Empty
                    : JournalDetailId > 0 ? JournalDetail.TripId != TripId && JournalDetail.TripId > 0 ? JournalDetail.Trip.AccountName : JournalDetail.DebtorId != DebtorId && JournalDetail.DebtorId > 0 ? JournalDetail.Debtor.AccountName : JournalDetail.CreditorId != CreditorId && JournalDetail.CreditorId > 0 ? JournalDetail.Creditor.AccountName : JournalDetail.ChartOfAccountId != ChartOfAccountId && JournalDetail.ChartOfAccountId > 0 ? JournalDetail.ChartOfAccount.AccountName : string.Empty
                    : Transaction.Adjustment.DebitTripId != TripId && Transaction.Adjustment.DebitTripId > 0 ? Transaction.Adjustment.DebitTrip.AccountName : Transaction.Adjustment.DebitDebtorId != DebtorId && Transaction.Adjustment.DebitDebtorId > 0 ? Transaction.Adjustment.DebitDebtor.AccountName : Transaction.Adjustment.DebitCreditorId != CreditorId && Transaction.Adjustment.DebitCreditorId > 0 ? Transaction.Adjustment.DebitCreditor.AccountName : Transaction.Adjustment.DebitChartOfAccountId != ChartOfAccountId && Transaction.Adjustment.DebitChartOfAccountId > 0 ? Transaction.Adjustment.DebitChartOfAccount.AccountName
                    : Transaction.Adjustment.CreditTripId != TripId && Transaction.Adjustment.CreditTripId > 0 ? Transaction.Adjustment.CreditTrip.AccountName : Transaction.Adjustment.CreditDebtorId != DebtorId && Transaction.Adjustment.CreditDebtorId > 0 ? Transaction.Adjustment.CreditDebtor.AccountName : Transaction.Adjustment.CreditCreditorId != CreditorId && Transaction.Adjustment.CreditCreditorId > 0 ? Transaction.Adjustment.CreditCreditor.AccountName : Transaction.Adjustment.CreditChartOfAccountId != ChartOfAccountId && Transaction.Adjustment.CreditChartOfAccountId > 0 ? Transaction.Adjustment.CreditChartOfAccount.AccountName
                    : string.Empty).Replace("Not Specified", string.Empty);
            }
        }

        [NotMapped]
        public int SalesDebtorId {
            get {
                return DebtorIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesCreditorId {
            get {
                return CreditorIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesSupplierId {
            get {
                return SupplierIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesAirlineId {
            get {
                return AirlineIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesPassengerId {
            get {
                return PassengerIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesSaleTypeId {
            get {
                return SaleTypeIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesDiscountReasonId {
            get {
                return DiscountReasonIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public decimal OfferedFare {
            get {
                return OfferedFareExpression.Compile().Invoke(this) ?? 0;
            }
        }

        [NotMapped]
        public int SalesOfferedReasonId {
            get {
                return OfferedReasonIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesGroupId {
            get {
                return GroupIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesClassId {
            get {
                return ClassIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesLocationId {
            get {
                return LocationIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesSourceId {
            get {
                return SourceIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesCategoryId {
            get {
                return CategoryIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesDestinationId {
            get {
                return DestinationIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesRegionId {
            get {
                return RegionIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesConsultantId {
            get {
                return ConsultantIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
        public int SalesAgentId {
            get {
                return AgentIdExpression.Compile().Invoke(this);
            }
        }

        [NotMapped]
		public bool IsMatched { get; set; }

		[NotMapped]
		public bool IsTaxApplicable {
			get {
				return Transaction.TransactionType == TransactionType.Receipt ? ReceiptDetail.Receipt.IsTaxApplicable
					: Transaction.TransactionType == TransactionType.Bsp ? BspDetail.Bsp.IsTaxApplicable
					: Transaction.TransactionType == TransactionType.NonBsp ? NonBspDetail.IsTaxApplicable
					: Transaction.TransactionType == TransactionType.Payment ? PaymentDetail.IsTaxApplicable
					: Transaction.TransactionType == TransactionType.Invoice ? InvoiceDetail.IsTaxApplicable
					: Transaction.TransactionType != TransactionType.Journal && Transaction.TransactionType == TransactionType.Adjustment && Transaction.Adjustment.IsTaxApplicable;
			}
		}

		[NotMapped]
		public decimal Balance { get; set; }

		[NotMapped]
		public decimal CommissionGross {
			get {
				return TransactionDetailType == TransactionDetailType.Discount ? 0 : (TransactionDetailType == TransactionDetailType.CommissionOnly || ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission ? (Amount + Tax) : (Commission + CommissionTax));
			}
		}

		[NotMapped]
		public decimal CommissionLessDiscountGross {
			get {
				return TransactionDetailType == TransactionDetailType.CommissionOnly || ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission ? (Amount + Tax) : (Commission + CommissionTax + (TransactionDetailType == TransactionDetailType.Discount ? (Amount + Tax) : 0));
			}
		}

		[NotMapped]
		public decimal CommissionLessDiscount {
			get {
				return TransactionDetailType == TransactionDetailType.CommissionOnly || ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission ? Amount : (Commission + (TransactionDetailType == TransactionDetailType.Discount ? Amount : 0));
			}
		}

		[NotMapped]
		public decimal CommissionLessDiscountTax {
			get {
				return TransactionDetailType == TransactionDetailType.CommissionOnly || ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission ? Tax : (CommissionTax + (TransactionDetailType == TransactionDetailType.Discount ? Tax : 0));
			}
		}

		[NotMapped]
		public decimal TaxAuditCommissionLessDiscount {
			get {
				return TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.TaxAuditCommissionOnly || ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission || Transaction.TransactionType == TransactionType.Invoice || Transaction.TransactionType == TransactionType.Adjustment ? Amount : (Commission + (TransactionDetailType == TransactionDetailType.Discount ? Amount : 0));
			}
		}

		[NotMapped]
		public decimal TaxAuditCommissionLessDiscountTax {
			get {
				return TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.TaxAuditCommissionOnly || ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission || Transaction.TransactionType == TransactionType.Invoice || Transaction.TransactionType == TransactionType.Adjustment ? Tax : (CommissionTax + (TransactionDetailType == TransactionDetailType.Discount ? Tax : 0));
			}
		}

		[NotMapped]
		public decimal CashGross {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? (ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission ? ReceiptDetail.OriginalSaleTotalGrossProRata : (Amount + Tax)) : 0);
			}
		}

		[NotMapped]
		public decimal Cash {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? (ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission ? ReceiptDetail.OriginalSaleTotalProRata : Amount) : 0);
			}
		}

		[NotMapped]
		public decimal CashTax {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? (ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission ? ReceiptDetail.OriginalSaleTotalTaxProRata : Tax) : 0);
			}
		}

		[NotMapped]
		public decimal CashNonCommissionableGross {
			get {
				return IsCash ? NonCommissionable + NonCommissionableTax : 0;
			}
		}

		[NotMapped]
		public decimal CashNonCommissionable {
			get {
				return IsCash ? NonCommissionable : 0;
			}
		}

		[NotMapped]
		public decimal CashNonCommissionableTax {
			get {
				return IsCash ? NonCommissionableTax : 0;
			}
		}

		[NotMapped]
		public decimal CashLessNonCommissionableGross {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? (ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission ? (ReceiptDetail.OriginalSaleTotalGrossProRata - NonCommissionable - NonCommissionableTax) : (Amount + Tax - NonCommissionable - NonCommissionableTax)) : 0);
			}
		}

		[NotMapped]
		public decimal CashLessNonCommissionable {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? (ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission ? (ReceiptDetail.OriginalSaleTotalProRata - NonCommissionable) : (Amount - NonCommissionable)) : 0);
			}
		}

		[NotMapped]
		public decimal CashLessNonCommissionableTax {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? (ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission ? (ReceiptDetail.OriginalSaleTotalTaxProRata - NonCommissionableTax) : (Tax - NonCommissionableTax)) : 0);
			}
		}

		[NotMapped]
		public decimal CashTaxAudit {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? (ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission ? ReceiptDetail.OriginalSaleTotalTaxProRata : Tax) : 0);
			}
		}

		[NotMapped]
		public decimal CreditCardGross {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? 0 : (Amount + Tax));
			}
		}

		[NotMapped]
		public decimal CreditCard {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? 0 : Amount);
			}
		}

		[NotMapped]
		public decimal CreditCardTax {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? 0 : Tax);
			}
		}

		[NotMapped]
		public decimal CreditCardNonCommissionableGross {
			get {
				return IsCash ? 0 : (NonCommissionable + NonCommissionableTax);
			}
		}

		[NotMapped]
		public decimal CreditCardNonCommissionable {
			get {
				return IsCash ? 0 : NonCommissionable;
			}
		}

		[NotMapped]
		public decimal CreditCardNonCommissionableTax {
			get {
				return IsCash ? 0 : NonCommissionableTax;
			}
		}

		[NotMapped]
		public decimal CreditCardLessNonCommissionableGross {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? 0 : (Amount + Tax - NonCommissionable - NonCommissionableTax));
			}
		}

		[NotMapped]
		public decimal CreditCardLessNonCommissionable {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? 0 : (Amount - NonCommissionable));
			}
		}

		[NotMapped]
		public decimal CreditCardLessNonCommissionableTax {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CommissionOnly || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? 0 : (Tax - NonCommissionableTax));
			}
		}

		[NotMapped]
		public decimal CreditCardTaxAudit {
			get {
				return TransactionDetailType == TransactionDetailType.Discount || TransactionDetailType == TransactionDetailType.CancellationFee ? 0 : (IsCash ? 0 : Tax);
			}
		}

		[NotMapped]
        public int Sign {
            get {
                return SalesAnalysisOfferedFare < 0 || CommissionLessDiscount < 0 || CashLessNonCommissionable < 0 || CashNonCommissionable < 0 || CreditCardLessNonCommissionable < 0 || CreditCardNonCommissionable < 0 ? -1 : 1;
            }
        }

        [NotMapped]
		public static Expression<Func<TransactionDetail, int>> DebtorIdExpression {
			get {
				return t => t.Transaction.TransactionType == TransactionType.Receipt ? t.Transaction.Receipt.DebtorId
                    : t.Transaction.TransactionType == TransactionType.Bsp ? t.Trip.DebtorId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Trip.DebtorId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Trip.DebtorId
                    : t.Transaction.TransactionType == TransactionType.Adjustment ? (t.Transaction.Adjustment.DebitType == DebitCreditType.Debtor ? t.Transaction.Adjustment.DebitDebtorId : t.Transaction.Adjustment.CreditType == DebitCreditType.Debtor ? t.Transaction.Adjustment.CreditDebtorId : -1)
					: -1;
			}
		}

		[NotMapped]
		public static Expression<Func<TransactionDetail, int>> CreditorIdExpression {
			get {
				return t => t.Transaction.TransactionType == TransactionType.Receipt ? t.Transaction.Receipt.CreditorId
                    : t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.CreditorId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.CreditorId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.CreditorId
                    : t.Transaction.TransactionType == TransactionType.Adjustment ? (t.Transaction.Adjustment.DebitType == DebitCreditType.Creditor ? t.Transaction.Adjustment.DebitCreditorId : t.Transaction.Adjustment.CreditType == DebitCreditType.Creditor ? t.Transaction.Adjustment.CreditCreditorId : -1)
					: -1;
			}
		}

		[NotMapped]
		public static Expression<Func<TransactionDetail, int>> SupplierIdExpression {
			get {
				return t => t.Transaction.TransactionType == TransactionType.Receipt ? t.Transaction.Receipt.SupplierId
                    : t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.SupplierId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.SupplierId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.SupplierId
                    : t.Transaction.TransactionType == TransactionType.Adjustment ? t.Transaction.Adjustment.SupplierId
                    : -1;
			}
		}

		[NotMapped]
		public static Expression<Func<TransactionDetail, int>> AirlineIdExpression {
			get {
				return t => t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.AirlineId
                : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.AirlineId
                : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.AirlineId
                : -1;
			}
		}

		[NotMapped]
		public static Expression<Func<TransactionDetail, int>> PassengerIdExpression {
			get {
				return t => t.Transaction.TransactionType == TransactionType.Receipt ? (t.ReceiptDetail.TripLineAirPassengerId > 0 ? t.ReceiptDetail.TripLineAirPassenger.PassengerId : t.ReceiptDetail.PassengerId)
				: t.Transaction.TransactionType == TransactionType.Bsp ? (t.BspDetail.TripLineAirPassengerId > 0 ? t.BspDetail.TripLineAirPassenger.PassengerId : t.BspDetail.PassengerId)
				: t.Transaction.TransactionType == TransactionType.NonBsp ? (t.NonBspDetail.TripLineAirPassengerId > 0 ? t.NonBspDetail.TripLineAirPassenger.PassengerId : t.NonBspDetail.PassengerId)
				: t.Transaction.TransactionType == TransactionType.Payment ? (t.PaymentDetail.TripLineAirPassengerId > 0 ? t.PaymentDetail.TripLineAirPassenger.PassengerId : t.PaymentDetail.PassengerId)
				: -1;
			}
		}

        [NotMapped]
        public static Expression<Func<TransactionDetail, decimal?>> OfferedFareExpression {
            get {
                return t => t.Transaction.TransactionType == TransactionType.Receipt ? t.ReceiptDetail.OfferedFare
                    : t.Transaction.TransactionType == TransactionType.Bsp ? t.BspDetail.Bsp.OfferedFare
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.NonBspDetail.NonBsp.OfferedFare
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.PaymentDetail.OfferedFare
                    : 0;
            }
        }

        [NotMapped]
        public static Expression<Func<TransactionDetail, int>> OfferedReasonIdExpression {
            get {
                return t => t.Transaction.TransactionType == TransactionType.Receipt ? t.ReceiptDetail.OfferedReasonId
                    : t.Transaction.TransactionType == TransactionType.Bsp ? t.BspDetail.Bsp.OfferedReasonId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.NonBspDetail.NonBsp.OfferedReasonId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.PaymentDetail.OfferedReasonId
                    : -1;
            }
        }

        [NotMapped]
		public static Expression<Func<TransactionDetail, int>> SaleTypeIdExpression {
			get {
				return t => t.TransactionDetailType == TransactionDetailType.Markup ? (t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.MarkupStrategy.SaleTypeId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.MarkupStrategy.SaleTypeId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.MarkupStrategy.SaleTypeId
                    : -1)
					: (t.Transaction.TransactionType == TransactionType.Receipt ? t.ReceiptDetail.MerchantFee != 0 ? t.ReceiptDetail.FormOfPayment.CreditCardSaleTypeId : t.Transaction.Receipt.SaleTypeId
                    : t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.SaleTypeId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.SaleTypeId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.SaleTypeId
                    : t.Transaction.TransactionType == TransactionType.Adjustment ? t.Transaction.Adjustment.SaleTypeId
                    : -1);
			}
		}

		[NotMapped]
		public static Expression<Func<TransactionDetail, int>> DiscountReasonIdExpression {
			get {
				return t => t.Transaction.TransactionType == TransactionType.Receipt ? t.Transaction.Receipt.DiscountReasonId
                    : t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.DiscountReasonId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.DiscountReasonId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.DiscountReasonId
                    : -1;
			}
		}

		[NotMapped]
		public static Expression<Func<TransactionDetail, int>> GroupIdExpression {
			get {
				return t => t.Transaction.TransactionType == TransactionType.Adjustment ? t.Transaction.Adjustment.GroupId : t.Trip.GroupId;
			}
		}

		[NotMapped]
		public static Expression<Func<TransactionDetail, int>> ClassIdExpression {
			get {
				return t => t.Trip.ClassId;
			}
		}

        [NotMapped]
        public static Expression<Func<TransactionDetail, int>> LocationIdExpression {
            get {
                return t => t.Trip.LocationId;
            }
        }

        [NotMapped]
		public static Expression<Func<TransactionDetail, int>> SourceIdExpression {
			get {
				return t => t.Transaction.TransactionType == TransactionType.Receipt ? (t.ReceiptDetail.Receipt.AccountType == AccountType.Debtor && t.ReceiptDetail.LoyaltySchemeId > 0 ? t.ReceiptDetail.LoyaltyScheme.LoyaltySchemeSourceId : t.Transaction.Receipt.SourceId)
					: t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.SourceId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.SourceId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.SourceId
                    : t.Transaction.TransactionType == TransactionType.Adjustment ? t.Transaction.Adjustment.SourceId
                    : -1;
			}
		}

		[NotMapped]
		public static Expression<Func<TransactionDetail, int>> CategoryIdExpression {
			get {
				return t => t.Transaction.TransactionType == TransactionType.Receipt ? (t.ReceiptDetail.Receipt.AccountType == AccountType.Debtor && t.ReceiptDetail.LoyaltySchemeId > 0 ? t.ReceiptDetail.LoyaltyScheme.LoyaltySchemeCategoryId : t.Transaction.Receipt.CategoryId)
					: t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.CategoryId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.CategoryId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.CategoryId
                    : t.Transaction.TransactionType == TransactionType.Adjustment ? t.Transaction.Adjustment.CategoryId
                    : -1;
			}
		}

		[NotMapped]
		public static Expression<Func<TransactionDetail, int>> DestinationIdExpression {
			get {
				return t => t.Transaction.TransactionType == TransactionType.Receipt ? (t.ReceiptDetail.Receipt.AccountType == AccountType.Debtor && t.ReceiptDetail.LoyaltySchemeId > 0 ? t.ReceiptDetail.LoyaltyScheme.LoyaltySchemeDestinationId : t.Transaction.Receipt.Trip.DestinationId)
					: t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.DestinationId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.DestinationId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.Trip.DestinationId
                    : t.Transaction.TransactionType == TransactionType.Adjustment ? t.Transaction.Adjustment.DestinationId
                    : -1;
			}
		}

		[NotMapped]
		public static Expression<Func<TransactionDetail, int>> RegionIdExpression {
			get {
				return t => t.Transaction.TransactionType == TransactionType.Receipt ? (t.ReceiptDetail.Receipt.AccountType == AccountType.Debtor && t.ReceiptDetail.LoyaltySchemeId > 0 ? t.ReceiptDetail.LoyaltyScheme.LoyaltySchemeDestination.RegionId : t.Transaction.Receipt.Trip.Destination.RegionId)
					: t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.Destination.RegionId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.Destination.RegionId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.Trip.Destination.RegionId
                    : t.Transaction.TransactionType == TransactionType.Adjustment ? t.Transaction.Adjustment.Destination.RegionId
                    : -1;
			}
		}

        [NotMapped]
        public static Expression<Func<TransactionDetail, int>> ConsultantIdExpression {
            get {
                return t => t.Transaction.TransactionType == TransactionType.Receipt ? (t.ReceiptDetail.Receipt.AccountType == AccountType.Debtor && t.ReceiptDetail.LoyaltySchemeId > 0 ? t.ReceiptDetail.LoyaltyScheme.LoyaltySchemeConsultantId : t.Transaction.Receipt.ConsultantId)
                    : t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.ConsultantId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.ConsultantId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.ConsultantId
                    : t.Transaction.TransactionType == TransactionType.Adjustment ? t.Transaction.Adjustment.ConsultantId
                    : -1;
            }
        }

        [NotMapped]
        public static Expression<Func<TransactionDetail, int>> AgentIdExpression {
            get {
                return t => t.Transaction.TransactionType == TransactionType.Receipt ? t.Transaction.Receipt.Trip.AgentId
                    : t.Transaction.TransactionType == TransactionType.Bsp ? t.Transaction.Bsp.AgentId
                    : t.Transaction.TransactionType == TransactionType.NonBsp ? t.Transaction.NonBsp.AgentId
                    : t.Transaction.TransactionType == TransactionType.Payment ? t.Transaction.Payment.Trip.AgentId
                    : t.Transaction.TransactionType == TransactionType.Adjustment ? t.Transaction.Adjustment.AgentId
                    : -1;
            }
        }

        [NotMapped]
		public static Expression<Func<TransactionDetail, bool>> SalesAnalysisWhereClause {
			get {
				return t1 => (t1.LedgerType == LedgerType.ClientLedger
                    || (t1.LedgerType == LedgerType.DebtorLedger && ((t1.Transaction.TransactionType == TransactionType.NonBsp && t1.Transaction.NonBsp.LoyaltySchemeReceiptDetailId > 0) || (t1.Transaction.TransactionType == TransactionType.Adjustment && (t1.Transaction.Adjustment.DebitType == DebitCreditType.Client || t1.Transaction.Adjustment.DebitType == DebitCreditType.Debtor || t1.Transaction.Adjustment.CreditType == DebitCreditType.Client || t1.Transaction.Adjustment.CreditType == DebitCreditType.Debtor))))
                    || (t1.LedgerType == LedgerType.GeneralLedger && t1.Transaction.Receipt.ReceiptType == ReceiptType.OtherCommission && t1.Transaction.Receipt.SupplierCommissionType == SupplierCommissionType.None && t1.ChartOfAccountId == t1.Transaction.Receipt.BankAccount.ChartOfAccountId))
					&& ((t1.Transaction.TransactionType == TransactionType.Receipt && (t1.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission || t1.Transaction.Receipt.AccountType == AccountType.Creditor || (t1.Transaction.Receipt.ReceiptType == ReceiptType.Debtor && t1.ReceiptDetail.FormOfPayment.MerchantFeeReducesCommission && t1.ReceiptDetail.TransactionDetailAllocations.Any(t2 => t2.ReceiptDetail.Receipt.AccountType == AccountType.Client)) || t1.Transaction.Receipt.SupplierCancellationFee != 0 || t1.Transaction.Receipt.Discount != 0))
					|| (t1.Transaction.TransactionType == TransactionType.Bsp && (t1.Transaction.Bsp.BspType == BspType.Bsp || t1.Transaction.Bsp.BspType == BspType.Refund || t1.Transaction.Bsp.BspType == BspType.Adm || t1.Transaction.Bsp.BspType == BspType.Acm || t1.Transaction.Bsp.BspType == BspType.Exchange))
					|| (t1.Transaction.TransactionType == TransactionType.NonBsp && t1.Transaction.NonBsp.NonBspType != NonBspType.Admin)
					|| (t1.Transaction.TransactionType == TransactionType.Payment && t1.Transaction.Payment.PaymentType == PaymentType.SupplierPayment)
					|| t1.Transaction.TransactionType == TransactionType.Adjustment)
					&& t1.Transaction.TransactionType != TransactionType.Invoice
					&& t1.Transaction.TransactionType != TransactionType.Journal
					&& (t1.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission || t1.TransactionDetailType != TransactionDetailType.ExcludeFromSalesAnalysis);
			}
		}

		public static Expression<Func<TransactionDetail, string>> AccountExpression(bool isSalesAnalysis) {
            return t => t.LedgerType == LedgerType.ClientLedger && t.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission && t.ReceiptDetail.Receipt.TripId > 0 ? t.ReceiptDetail.Receipt.Trip.AccountName
                : t.LedgerType == LedgerType.ClientLedger && t.TripId > 0 ? t.Trip.AccountName
                : t.LedgerType == LedgerType.DebtorLedger && t.DebtorId > 0 ? t.Debtor.AccountName
                : t.LedgerType == LedgerType.CreditorLedger ? t.CreditorId <= 0 ? string.Empty : t.Creditor.Name
                : t.ChartOfAccountId > 0 ? t.ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission && t.TransactionAnalysisType == TransactionAnalysisType.SalesAnalysisAndTaxAuditReport && isSalesAnalysis ? t.ReceiptDetail.Receipt.ChartOfAccount.AccountName : t.ChartOfAccount.AccountName
                : string.Empty;
        }

        public static Expression<Func<TransactionDetail, bool>> AccountNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.GetAccount(true).Equals(name);

            return t => t.GetAccount(true).ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> AgencyNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.Agency.Name.Equals(name);

            return t => t.Agency.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> ConsultantNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisConsultant.Name.Equals(name);

            return t => t.SalesAnalysisConsultant.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> AgentNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisAgent.Name.Equals(name);

            return t => t.SalesAnalysisAgent.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> DebtorNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisDebtor.Name.Equals(name);

            return t => t.SalesAnalysisDebtor.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> CreditorNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisCreditor.Name.Equals(name);

            return t => t.SalesAnalysisCreditor.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> SupplierNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisSupplier.Name.Equals(name);

            return t => t.SalesAnalysisSupplier.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> AirlineNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisAirline.Name.Equals(name);

            return t => t.SalesAnalysisAirline.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> PassengerNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisPassenger.FullName.Equals(name);

            return t => t.SalesAnalysisPassenger.FullName.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> SaleTypeNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisSaleType.Name.Equals(name);

            return t => t.SalesAnalysisSaleType.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> DiscountReasonNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisDiscountReason.Name.Equals(name);

            return t => t.SalesAnalysisDiscountReason.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> OfferedReasonNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisOfferedReason.Name.Equals(name);

            return t => t.SalesAnalysisOfferedReason.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> GroupNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisGroup.Name.Equals(name);

            return t => t.SalesAnalysisGroup.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> ClassNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisClass.Name.Equals(name);

            return t => t.SalesAnalysisClass.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> SourceNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisSource.Name.Equals(name);

            return t => t.SalesAnalysisSource.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> CategoryNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisCategory.Name.Equals(name);

            return t => t.SalesAnalysisCategory.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> DestinationNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisDestination.Name.Equals(name);

            return t => t.SalesAnalysisDestination.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> RegionNameWhereClause(object name, bool useDefaultMethod = true) {
            if (useDefaultMethod)
                return t => t.SalesAnalysisRegion.Name.Equals(name);

            return t => t.SalesAnalysisRegion.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public static Expression<Func<TransactionDetail, bool>> LocationNameWhereClause(object name, bool useDefaultMethod = true) {
            if (name.ToStringExt().Length == 0)
                name = "Not Specified";

            if (useDefaultMethod)
                return t => t.Trip.Location.Name.Equals(name);

            return t => t.Trip.Location.Name.ToLower().Contains(name.ToString().ToLower());
        }

        public decimal GetMerchantFeeGross() {
			return TransactionDetailType == TransactionDetailType.MerchantFee && TransactionAnalysisType == TransactionAnalysisType.TaxAuditReport ? Amount : 0;
		}

		public decimal GetMerchantFeeTax(int customerId) {
			var glSetting = Setting.GetRow(customerId, ReceiptDetail.Receipt.DocumentDate);
			return TransactionDetailType == TransactionDetailType.MerchantFee && ChartOfAccountId == glSetting.PurchasesTaxAccount.Id ? Amount : 0;
		}

		public string GetAccount(bool isSalesAnalysis) {
			return AccountExpression(isSalesAnalysis).Compile().Invoke(this);
		}

		public string GetAccountLink(bool isSalesAnalysis) {
			return LedgerType == LedgerType.ClientLedger && TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission && ReceiptDetail.Receipt.TripId > 0 ? ReceiptDetail.Receipt.AccountNameLink
				: LedgerType == LedgerType.ClientLedger && TripId > 0 ? Trip.AccountNameLink
				: LedgerType == LedgerType.DebtorLedger && DebtorId > 0 ? Debtor.AccountNameLink
				: LedgerType == LedgerType.CreditorLedger && CreditorId > 0 ? Creditor.AccountNameLink
				: LedgerType == LedgerType.GeneralLedger && ChartOfAccountId > 0 ? ReceiptDetail.Receipt.ReceiptType == ReceiptType.OtherCommission && TransactionAnalysisType == TransactionAnalysisType.SalesAnalysisAndTaxAuditReport && isSalesAnalysis ? ReceiptDetail.Receipt.ChartOfAccount.AccountNameLink : ChartOfAccount.AccountNameLink
				: string.Empty;
		}

		public static IQueryable<TransactionDetail> GetTransactionDetailQuery(AppLazyContext lazyContext, LedgerType selectedLedgerType, LedgerType ledgerType, int transactionId = 0, int tripId = 0, int debtorId = 0, int creditorId = 0, int chartOfAccountId = 0, TransactionType transactionType = TransactionType.All) {
			if (transactionType == TransactionType.CreditNote)
				transactionType = TransactionType.Invoice;

			var q = lazyContext.TransactionDetail.Where(t => t.Id > 0);

			if (transactionId > 0)
				q = q.Where(t => t.TransactionId == transactionId);

			if (selectedLedgerType == LedgerType.CurrentAccountOnly) {
				q = q.Where(t => t.LedgerType == ledgerType);
			}
			else if (selectedLedgerType != LedgerType.None) {
				q = q.Where(t => t.LedgerType == selectedLedgerType);
			}

			if (transactionType != TransactionType.All)
				q = q.Where(t => t.Transaction.TransactionType == transactionType);

			if (selectedLedgerType == LedgerType.CurrentAccountOnly) {
				switch (ledgerType) {
					case LedgerType.ClientLedger:
						q = q.Where(t => t.TripId == tripId || (t.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission && t.ReceiptDetail.Receipt.TripId == tripId));
						break;
					case LedgerType.DebtorLedger:
						q = q.Where(t => t.DebtorId == debtorId);
						break;
					case LedgerType.CreditorLedger:
						q = q.Where(t => t.CreditorId == creditorId);
						break;
					case LedgerType.GeneralLedger:
						q = q.Where(t => t.ChartOfAccountId == chartOfAccountId);
						break;
				}
			}

			return q;
		}

		public static IQueryable<TransactionDetail> GetTransactionAnalysisQuery(AppLazyContext lazyContext, int agencyId, DateTime? dateFrom, DateTime? dateTo) {
			var q = lazyContext.TransactionDetail.AsQueryable();

             if (agencyId > 0)
                q = q.Where(t => t.AgencyId == agencyId);

            if (dateFrom != null)
				q = q.Where(t => t.Transaction.DocumentDate >= dateFrom);

			if (dateTo != null)
				q = q.Where(t => t.Transaction.DocumentDate <= dateTo);

			return q;
		}

		public static IQueryable<SalesAnalysisReportModel> GetSalesAnalysisQuery(AppLazyContext lazyContext, int agencyId, int consultantId, bool otherAgencies, bool otherConsultants, DateTime? dateFrom, DateTime? dateTo, bool isTaxIncluded) {
			var q = GetTransactionAnalysisQuery(lazyContext, -1, dateFrom, dateTo).Where(t => t.TransactionAnalysisType == TransactionAnalysisType.SalesAnalysis || t.TransactionAnalysisType == TransactionAnalysisType.SalesAnalysisAndTaxAuditReport);
			return GetSalesAnalysisQuery(q, agencyId, consultantId, otherAgencies, otherConsultants, isTaxIncluded);
		}

        public static IQueryable<SalesAnalysisReportModel> GetSalesAnalysisQuery(IQueryable<TransactionDetail> transactionDetails, int agencyId, int consultantId, bool otherAgencies, bool otherConsultants, bool isTaxIncluded) {
            if (!otherAgencies && agencyId > 0) {
                transactionDetails = transactionDetails.Where(t => t.ReceiptDetail.Receipt.AgencyId == agencyId || t.BspDetail.Bsp.AgencyId == agencyId || t.NonBspDetail.NonBsp.AgencyId == agencyId || t.PaymentDetail.Payment.AgencyId == agencyId
                    || t.InvoiceDetail.Trip.AgencyId == agencyId || t.JournalDetail.Trip.AgencyId == agencyId || t.Transaction.Adjustment.DebitTrip.AgencyId == agencyId || t.Transaction.Adjustment.CreditTrip.AgencyId == agencyId);
            }

            if (!otherConsultants && consultantId > 0) {
                transactionDetails = transactionDetails.Where(t => t.ReceiptDetail.Receipt.ConsultantId == consultantId || t.BspDetail.Bsp.ConsultantId == consultantId || t.NonBspDetail.NonBsp.ConsultantId == consultantId || t.PaymentDetail.Payment.ConsultantId == consultantId
                    || t.InvoiceDetail.Trip.ConsultantId == consultantId || t.JournalDetail.Trip.ConsultantId == consultantId || t.Transaction.Adjustment.ConsultantId == consultantId || t.Transaction.Adjustment.DebitTrip.ConsultantId == consultantId || t.Transaction.Adjustment.CreditTrip.ConsultantId == consultantId);
            }

            return transactionDetails.Select(row => new SalesAnalysisReportModel {
                TransactionDetailId = row.Id,
                TransactionType = row.Transaction.EffectiveTransactionType,
                DocumentType = row.Debtor.FormOfPayments.Any(t => t.DebtorId > 0) && row.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission ? row.ReceiptDetail.Receipt.ReceiptType.GetEnumDescription() : row.Transaction.DocumentType,
                DocumentNo = row.Debtor.FormOfPayments.Any(t => t.DebtorId > 0) && row.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission ? row.ReceiptDetail.Receipt.DocumentNo : row.Transaction.DocumentNo,
                DocumentNoLink = row.Debtor.FormOfPayments.Any(t => t.DebtorId > 0) && row.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission ? row.ReceiptDetail.Receipt.GetDocumentNoLink("SalesAnalysis") : row.Transaction.GetDocumentNoLink("SalesAnalysis"),
                DocumentDate = row.Transaction.DocumentDate,
                Account = row.GetAccount(true),
                AccountLink = row.GetAccountLink(true),
                Agency = row.AgencyId <= 0 ? string.Empty : row.Agency.Name,
                Reference = row.Reference,
                Airline = row.SalesAnalysisAirlineId <= 0 ? string.Empty : row.SalesAnalysisAirline.Name,
                Passenger = row.SalesAnalysisPassengerId <= 0 ? string.Empty : row.SalesAnalysisPassenger.FullName,
                PaxNo = row.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission ? row.ReceiptDetail.Receipt.Trip.PaxAdult + row.ReceiptDetail.Receipt.Trip.PaxChild + row.ReceiptDetail.Receipt.Trip.PaxInfant : row.Trip.PaxAdult + row.Trip.PaxChild + row.Trip.PaxInfant,
                OfferedFare = row.SalesAnalysisOfferedFare,
                OfferedReason = row.SalesAnalysisOfferedReasonId <= 0 ? string.Empty : row.SalesAnalysisOfferedReason.Name,
                DepartureDate = row.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission ? row.ReceiptDetail.Receipt.Trip.DepartureDate == DateTime.MinValue ? (DateTime?)null : row.ReceiptDetail.Receipt.Trip.DepartureDate : row.Trip.DepartureDate == DateTime.MinValue ? (DateTime?)null : row.Trip.DepartureDate,
                ReturnDate = row.TransactionDetailType == TransactionDetailType.MerchantFeeReducedCommission ? row.ReceiptDetail.Receipt.Trip.ReturnDate == DateTime.MinValue ? (DateTime?)null : row.ReceiptDetail.Receipt.Trip.ReturnDate : row.Trip.ReturnDate == DateTime.MinValue ? (DateTime?)null : row.Trip.ReturnDate,
                Debtor = row.SalesAnalysisDebtorId <= 0 ? string.Empty : row.SalesAnalysisDebtor.Name,
                Creditor = row.SalesAnalysisCreditorId <= 0 ? string.Empty : row.SalesAnalysisCreditor.Name,
                Supplier = row.SalesAnalysisSupplierId <= 0 ? string.Empty : row.SalesAnalysisSupplier.Name,
                SaleType = row.SalesAnalysisSaleTypeId <= 0 ? string.Empty : row.SalesAnalysisSaleType.Name,
                DiscountReason = row.SalesAnalysisDiscountReasonId <= 0 ? string.Empty : row.TransactionDetailType == TransactionDetailType.Discount ? row.SalesAnalysisDiscountReason.Name : string.Empty,
                Group = row.SalesAnalysisGroupId <= 0 ? string.Empty : row.SalesAnalysisGroup.Name,
                Class = row.SalesAnalysisClassId <= 0 ? string.Empty : row.SalesAnalysisClass.Name,
                Source = row.SalesAnalysisSourceId <= 0 ? string.Empty : row.SalesAnalysisSource.Name,
                Category = row.SalesAnalysisCategoryId <= 0 ? string.Empty : row.SalesAnalysisCategory.Name,
                Destination = row.SalesAnalysisDestinationId <= 0 ? string.Empty : row.SalesAnalysisDestination.Name,
                Region = row.SalesAnalysisRegionId <= 0 ? string.Empty : row.SalesAnalysisRegion.Name,
                Location = row.SalesAnalysisLocationId <= 0 ? string.Empty : row.SalesAnalysisLocation.Name,
                Consultant = row.SalesAnalysisConsultantId <= 0 ? string.Empty : row.SalesAnalysisConsultant.Name,
                Agent = row.SalesAnalysisAgentId <= 0 ? string.Empty : row.SalesAnalysisAgent.Name,
                Commission = isTaxIncluded ? row.CommissionLessDiscountGross : row.CommissionLessDiscount,
                Cash = isTaxIncluded ? row.CashLessNonCommissionableGross : row.CashLessNonCommissionable,
                CashNonCommissionable = isTaxIncluded ? row.CashNonCommissionableGross : row.CashNonCommissionable,
                CreditCard = isTaxIncluded ? row.CreditCardLessNonCommissionableGross : row.CreditCardLessNonCommissionable,
                CreditCardNonCommissionable = isTaxIncluded ? row.CreditCardNonCommissionableGross : row.CreditCardNonCommissionable
            });
        }
    }

    public partial class TransactionDetailAllocation {
        [NotMapped]
        public TransactionType TransactionType {
            get {
                return ReceiptDetailId > 0 ? TransactionType.Receipt : NonBspDetailId > 0 ? TransactionType.NonBsp : PaymentDetailId > 0 ? TransactionType.Payment : InvoiceDetailId > 0 ? InvoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote ? TransactionType.CreditNote : TransactionType.Invoice : JournalDetailId > 0 ? TransactionType.Journal : AdjustmentId > 0 ? TransactionType.Adjustment : TransactionType.All;
            }
        }

        public DateTime GetDocumentDate(AllocationQueryType queryType) {
            return queryType == AllocationQueryType.DebtorReceipt ? TransactionDetail.Transaction.DocumentDate : ReceiptDetailId > 0 ? ReceiptDetail.Receipt.DocumentDate : NonBspDetailId > 0 ? NonBspDetail.NonBsp.DocumentDate : PaymentDetailId > 0 ? PaymentDetail.Payment.DocumentDate : InvoiceDetailId > 0 ? InvoiceDetail.Invoice.DocumentDate : JournalDetailId > 0 ? JournalDetail.Journal.DocumentDate : Adjustment.DocumentDate;
        }

        public void UpdateReference(List<TransactionDetailAllocation> transactionDetailAllocations, int masterDocumentId) {
            string documentNo = string.Empty;
            var q = transactionDetailAllocations.Where(t => t.Id != Id && t.GroupNo == GroupNo);

            if (ReceiptDetailId > 0) {
                q = q.Where(t => t.ReceiptDetailId <= 0);
            }
            else if (NonBspDetailId > 0) {
                q = q.Where(t => t.NonBspDetailId <= 0);
            }
            else if (PaymentDetailId > 0) {
                q = q.Where(t => t.PaymentDetailId <= 0);
            }
            else if (InvoiceDetailId > 0) {
                if (InvoiceDetail.Invoice.InvoiceType == InvoiceType.Invoice) {
                    q = q.Where(t => t.InvoiceDetailId <= 0 && t.InvoiceDetail.Invoice.InvoiceType != InvoiceType.CreditNote);
                }
                else {
                    q = q.Where(t => t.InvoiceDetailId <= 0 && t.InvoiceDetail.Invoice.InvoiceType != InvoiceType.Invoice);
                }
            }
            else if (JournalDetailId > 0) {
                q = q.Where(t => t.JournalDetailId <= 0);
            }
            else if (AdjustmentId > 0) {
                q = q.Where(t => t.AdjustmentId <= 0);
            }

            if (!q.Any())
                q = transactionDetailAllocations.Where(t => t.Id != Id && t.GroupNo == GroupNo);

            UpdateReference(q);

            if (Reference.Length == 0) {
                var allocation = transactionDetailAllocations.FirstOrDefault(t => ((ReceiptDetailId > 0 && t.TransactionType == TransactionType.Receipt && t.ReceiptDetailId == masterDocumentId)
                    || (NonBspDetailId > 0 && t.TransactionType == TransactionType.NonBsp && t.NonBspDetailId == masterDocumentId)
                    || (PaymentDetailId > 0 && t.TransactionType == TransactionType.Payment && t.PaymentDetailId == masterDocumentId)
                    || (InvoiceDetailId > 0 && (t.TransactionType == TransactionType.Invoice || t.TransactionType == TransactionType.CreditNote) && t.InvoiceDetailId == masterDocumentId)
                    || (JournalDetailId > 0 && t.TransactionType == TransactionType.Journal && t.JournalDetailId == masterDocumentId)
                    || (AdjustmentId > 0 && t.TransactionType == TransactionType.Adjustment && t.AdjustmentId == masterDocumentId))
                    && t.GroupNo == GroupNo);

                if (allocation == null)
                    return;

                switch (allocation.TransactionType) {
                    case TransactionType.Receipt:
                        Reference = string.Format("Receipt No {0}", allocation.ReceiptDetail.Receipt.DocumentNo);
                        break;
                    case TransactionType.NonBsp:
                        Reference = string.Format("Non-BSP No {0}", allocation.NonBspDetail.NonBsp.DocumentNo);
                        break;
                    case TransactionType.Payment:
                        Reference = string.Format("Payment No {0}", allocation.PaymentDetail.Payment.DocumentNo);
                        break;
                    case TransactionType.Invoice:
                    case TransactionType.CreditNote:
                        Reference = string.Format("{0} No {1}", allocation.InvoiceDetail.Invoice.InvoiceType.GetEnumDescription(), allocation.InvoiceDetail.Invoice.DocumentNo);
                        break;
                    case TransactionType.Journal:
                        Reference = string.Format("Journal No {0}", allocation.JournalDetail.Journal.DocumentNo);
                        break;
                    case TransactionType.Adjustment:
                        Reference = string.Format("Adjustment No {0}", allocation.Adjustment.DocumentNo);
                        break;
                }
            }
        }

        private void UpdateReference(IEnumerable<TransactionDetailAllocation> transactionDetailAllocations) {
            string documentNo = string.Empty;

            foreach (var row in transactionDetailAllocations.ToList()) {
                if (row.TransactionDetail.DebtorId > 0) {
                    if (row.ReceiptDetailId > 0 && row.ReceiptDetailId != ReceiptDetailId && row.Amount == -Amount) {
                        documentNo = string.Format("Receipt No {0}", row.ReceiptDetail.Receipt.DocumentNo);
                    }
                    else if (row.InvoiceDetailId > 0 && row.InvoiceDetailId != InvoiceDetailId && row.InvoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote && row.Amount == -Amount) {
                        documentNo = string.Format("Credit Note No {0}", row.InvoiceDetail.Invoice.DocumentNo);
                    }
                }
                else if (row.TransactionDetail.CreditorId > 0) {
                    if (row.PaymentDetailId > 0 && row.PaymentDetailId != PaymentDetailId && row.Amount == -Amount)
                        documentNo = string.Format("Payment No {0}", row.PaymentDetail.Payment.DocumentNo);
                }

                if (documentNo.Length > 0)
                    break;

                if (row.NonBspDetailId > 0 && row.NonBspDetailId != NonBspDetailId && row.Amount == -Amount) {
                    documentNo = string.Format("Non-BSP No {0}", row.NonBspDetail.NonBsp.DocumentNo);
                }
                else if (row.InvoiceDetailId > 0 && row.InvoiceDetailId != InvoiceDetailId && row.InvoiceDetail.Invoice.InvoiceType == InvoiceType.Invoice && row.Amount == -Amount) {
                    documentNo = string.Format("Invoice No {0}", row.InvoiceDetail.Invoice.DocumentNo);
                }
                else if (row.JournalDetailId > 0 && row.JournalDetailId != JournalDetailId && row.Amount == -Amount) {
                    documentNo = string.Format("Journal No {0}", row.JournalDetail.Journal.DocumentNo);
                }
                else if (row.AdjustmentId > 0 && row.AdjustmentId != AdjustmentId && row.Amount == -Amount) {
                    documentNo = string.Format("Adjustment No {0}", row.Adjustment.DocumentNo);
                }
            }

            Reference = documentNo;
        }

        public SignType GetSignType(LedgerType ledgerType) {
            switch (ledgerType) {
                default:
                    throw new InvalidOperationException("Invalid Ledger Type.");
                case LedgerType.DebtorLedger:
                    return (ReceiptDetailId > 0 && !(TransactionDetail.Debtor.IsCreditCardDebtor && ReceiptDetail.FormOfPayment.DebtorId == TransactionDetail.DebtorId)) || (InvoiceDetailId > 0 && InvoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote) || JournalDetail.SignType == SignType.Credit || Adjustment.CreditDebtorId > 0 ? SignType.Credit : SignType.Debit;
                case LedgerType.CreditorLedger:
                    return ReceiptDetailId > 0 || (NonBspDetailId > 0 && NonBspDetail.NonBsp.NonBspType != NonBspType.Refund) || JournalDetail.SignType == SignType.Credit || Adjustment.CreditCreditorId > 0 ? SignType.Credit : SignType.Debit;
            }
        }
    }

    public class BankReconciliation {
		public string TransactionDetailBaseRefIds { get; set; }
		public int[] TransactionDetailRefIds { get { return TransactionDetailBaseRefIds.Split(',').Select(int.Parse).ToArray(); } }
		public TransactionType TransactionType { get; set; }
		public Receipt Receipt { get; set; }
		public Payment Payment { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public DocumentStatus DocumentStatus { get; set; }
		public StatementDocumentStatus StatementDocumentStatus { get; set; }
		public int FormOfPaymentId { get; set; }
		public FormOfPayment FormOfPayment { get; set; }
		public string BankAccountName { get; set; }
		public int BankAccountId { get; set; }
		public int BankAccountStatementId { get; set; }
		public decimal TotalAmount { get; set; }
		public decimal TotalTax { get; set; }
		public string LastWriteUser { get; set; }
		public DateTime LastWriteTime { get; set; }
		public DateTime CreationTime { get; set; }
		public string CreationUser { get; set; }

		public decimal? Debit {
			get {
				return TransactionType == TransactionType.Receipt ? (decimal?)null : TotalAmount;
			}
		}

		public decimal? Credit {
			get {
				return TransactionType == TransactionType.Receipt ? TotalAmount : (decimal?)null;
			}
		}

		[NotMapped]
		public string StatementDocumentStatusDescription {
			get {
				switch (StatementDocumentStatus) {
					case StatementDocumentStatus.NotDepositedNotBanked:
						if (TransactionType == TransactionType.Receipt)
							return "Receipts Awaiting Bank Deposit";

						break;
					case StatementDocumentStatus.ToBeDepositedNotBanked:
					case StatementDocumentStatus.ToBeDepositedToBeBanked:
						if (TransactionType == TransactionType.Receipt)
							return "Receipts Awaiting Bank Statement Matching";

						break;
					case StatementDocumentStatus.DepositedNotBanked:
					case StatementDocumentStatus.DepositedToBeBanked:
						if (TransactionType == TransactionType.Receipt)
							return "Receipts Awaiting Bank Statement Matching";

						return "Payments Awaiting Bank Statement Matching";
				}

				return string.Empty;
			}
		}

		public static int GetStatementDocumentStatusSeqNo(StatementDocumentStatus statementDocumentStatus, TransactionType transactionType) {
				switch (statementDocumentStatus) {
					case StatementDocumentStatus.NotDepositedNotBanked:
						if (transactionType == TransactionType.Receipt)
							return 0;

						break;
					case StatementDocumentStatus.ToBeDepositedNotBanked:
					case StatementDocumentStatus.ToBeDepositedToBeBanked:
						if (transactionType == TransactionType.Receipt)
							return 1;

						break;
					case StatementDocumentStatus.DepositedNotBanked:
					case StatementDocumentStatus.DepositedToBeBanked:
						if (transactionType == TransactionType.Receipt)
							return 1;

						return 2;
				}

				return 3;
		}

		public static IQueryable<BankReconciliation> GetBankReconciliationQuery(AppLazyContext lazyContext, int bankAccountId, int bankAccountStatementId, TransactionType transactionType = TransactionType.All, DocumentStatus documentStatus = DocumentStatus.None, BankReconciliationReportType bankReconciliationReportType = BankReconciliationReportType.None, DateTime? dateFrom = null, DateTime? dateTo = null, decimal? amountFrom = null, decimal? amountTo = null, string text = null, bool descendingDateOrder = false) {
			if (transactionType == TransactionType.CreditNote)
				transactionType = TransactionType.Invoice;

			var q1 = lazyContext.BankReconciliationView.AsQueryable();

			if (transactionType != TransactionType.All)
				q1 = q1.Where(t => t.TransactionType == transactionType);

			if (documentStatus != DocumentStatus.None)
				q1 = q1.Where(t => t.DocumentStatus == documentStatus);

			if (dateFrom != null)
				q1 = q1.Where(t => t.DocumentDate >= dateFrom);

			if (dateTo != null && (bankReconciliationReportType == BankReconciliationReportType.None || bankReconciliationReportType == BankReconciliationReportType.Reconciliation))
				q1 = q1.Where(t => t.DocumentDate <= dateTo);

			if (amountFrom != null)
				q1 = q1.Where(t => (t.TransactionType == TransactionType.Receipt ? (t.TotalAmount + t.TotalTax) : t.Payment.AmountPayable + t.Payment.AmountPayableTax) >= amountFrom);

			if (amountTo != null)
				q1 = q1.Where(t => (t.TransactionType == TransactionType.Receipt ? (t.TotalAmount + t.TotalTax) : t.Payment.AmountPayable + t.Payment.AmountPayableTax) <= amountTo);

			if (!string.IsNullOrEmpty(text))
				q1 = q1.Where(t => t.DocumentNo.ToLower().Contains(text.Trim().ToLower()));

			if (bankReconciliationReportType == BankReconciliationReportType.None) {
				q1 = q1.Where(t => !t.IsOnDeposit && (t.Receipt.IsDeposit || t.TransactionType == TransactionType.Payment || t.Receipt.ReceiptType == ReceiptType.Transfer || !t.FormOfPayment.IncludeInDeposit));
			}
			else if (bankReconciliationReportType == BankReconciliationReportType.Reconciliation) {
				q1 = q1.Where(t => t.Receipt.IsDeposit || (t.TransactionType == TransactionType.Receipt && t.DepositDate > dateTo) || t.TransactionType == TransactionType.Payment || t.Receipt.ReceiptType == ReceiptType.Transfer || !t.FormOfPayment.IncludeInDeposit);
			}

			if (bankAccountId > 0) {
				q1 = q1.Where(t => t.BankAccountId == bankAccountId);

				if (bankAccountStatementId > 0 && bankReconciliationReportType != BankReconciliationReportType.BankStatement && bankReconciliationReportType != BankReconciliationReportType.CashBook) {
					if (documentStatus == DocumentStatus.DepositedPaid) {
						if ((lazyContext.BankAccountStatement.Where(t => t.BankAccountId == bankAccountId).OrderByDescending(t => t.Id).FirstOrDefault() ?? new BankAccountStatement { Id = -1 }).Id != bankAccountStatementId) {
							DateTime closingDate = lazyContext.BankAccountStatement.Find(bankAccountStatementId).ClosingDate.AddDays(1).AddTicks(-1);
							q1 = q1.Where(t => t.DocumentDate <= closingDate && t.BankAccountStatementId == -1);
						}
					}
					else {
						q1 = q1.Where(t => t.BankAccountStatementId == bankAccountStatementId);
					}
				}
			}

			var q2 = q1.Select(row => new {
				TransactionDetailBaseRefIds = row.TransactionDetailRefIds,
				row.TransactionType,
				row.Receipt,
				row.Payment,
				row.DocumentNo,
				row.DocumentDate,
				row.DocumentStatus,
				StatementDocumentStatus = row.DocumentStatus == DocumentStatus.Open ? StatementDocumentStatus.NotDepositedNotBanked
				   : row.DocumentStatus == DocumentStatus.DepositedPaid && !row.IsOnDeposit ? StatementDocumentStatus.DepositedNotBanked
				   : row.DocumentStatus == DocumentStatus.DepositedPaid && row.IsOnDeposit && row.DepositDate > dateTo ? StatementDocumentStatus.ToBeDepositedNotBanked
				   : row.DocumentStatus == DocumentStatus.Closed && row.IsOnDeposit && row.DepositDate > dateTo ? StatementDocumentStatus.ToBeDepositedToBeBanked
				   : row.DocumentStatus == DocumentStatus.Closed && !row.IsOnDeposit && row.BankAccountStatementClosingDate > dateTo ? StatementDocumentStatus.DepositedToBeBanked
				   : row.DocumentStatus == DocumentStatus.Closed && row.BankAccountStatementClosingDate <= dateTo ? StatementDocumentStatus.DepositedBanked
				   : StatementDocumentStatus.None,
				row.FormOfPayment,
				row.BankAccount,
				BankAccountStatementId = bankReconciliationReportType != BankReconciliationReportType.None && row.BankAccountStatementId > 0 && row.BankAccountStatementClosingDate > dateTo ? -1 : row.BankAccountStatementId,
				row.TotalAmount,
				row.TotalTax,
				row.LastWriteTime,
				row.CreationTime,
				row.LastWriteUser,
				row.CreationUser
			});

			if (bankReconciliationReportType == BankReconciliationReportType.BankStatement || bankReconciliationReportType == BankReconciliationReportType.CashBook) {
				q2 = q2.Where(t => t.StatementDocumentStatus != StatementDocumentStatus.None && t.StatementDocumentStatus != StatementDocumentStatus.DepositedBanked && t.DocumentDate <= dateTo);

				if (descendingDateOrder) {
					q2 = q2.OrderBy(t => t.TransactionType == TransactionType.Payment ? 3 : t.StatementDocumentStatus == StatementDocumentStatus.NotDepositedNotBanked ? 0 : 1).ThenByDescending(t => t.DocumentDate).ThenBy(t => t.DocumentNo);
				}
				else {
					q2 = q2.OrderBy(t => t.TransactionType == TransactionType.Payment ? 3 : t.StatementDocumentStatus == StatementDocumentStatus.NotDepositedNotBanked ? 0 : 1).ThenBy(t => t.DocumentDate).ThenBy(t => t.DocumentNo);
				}
			}
			else if (descendingDateOrder) {
				q2 = q2.OrderByDescending(t => t.DocumentDate).ThenBy(t => t.DocumentNo);
			}
			else {
				q2 = q2.OrderBy(t => t.DocumentDate).ThenBy(t => t.DocumentNo);
			}

			return q2.Select(row => new BankReconciliation {
				TransactionDetailBaseRefIds = row.TransactionDetailBaseRefIds,
				TransactionType = row.TransactionType,
				Receipt = row.Receipt,
				Payment = row.Payment,
				DocumentNo = row.DocumentNo,
				DocumentDate = row.DocumentDate,
				DocumentStatus = row.DocumentStatus,
				StatementDocumentStatus = row.StatementDocumentStatus,
				FormOfPaymentId = row.FormOfPayment.Id,
				FormOfPayment = row.FormOfPayment,
				BankAccountId = row.BankAccount.Id,
				BankAccountName = row.BankAccount.AccountDescription,
				BankAccountStatementId = row.BankAccountStatementId,
				TotalAmount = row.TransactionType == TransactionType.Receipt ? row.TotalAmount + row.TotalTax : row.Payment.GetDocumentAmountPayableGross(lazyContext, row.DocumentStatus, bankAccountId),
				TotalTax = row.TransactionType == TransactionType.Receipt ? row.TotalTax : row.Payment.GetDocumentAmountPayableTax(lazyContext, row.DocumentStatus, bankAccountId),
				LastWriteTime = row.LastWriteTime,
				CreationTime = row.CreationTime,
				LastWriteUser = row.LastWriteUser,
				CreationUser = row.CreationUser
			});
		}
	}

	public class FinancialIntegrity {
		public int Id { get; set; }
		public int SettingId { get; set; }
		public string AccountName { get; set; }
		public DateTime FiscalYearStartDate { get; set; }
		public string FiscalYearStartDateName { get; set; }
		public decimal LedgerAccountTotal { get; set; }
		public decimal GlAccountTotal { get; set; }
        public int FailureCount { get; set; }
    }
}