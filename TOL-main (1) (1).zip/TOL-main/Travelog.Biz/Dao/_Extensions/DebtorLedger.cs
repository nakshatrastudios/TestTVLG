using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Net;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.Common;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;

namespace Travelog.Biz.Dao.DebtorLedger {
	public partial class Debtor {
		[NotMapped]
		public string AccountName {
			get {
				return Id <= 0 ? string.Empty : string.Concat(Code, ": ", Name);
			}
		}

		[NotMapped]
		public string AccountNameLink {
			get {
				return Id <= 0 ? string.Empty : string.Concat(@"<a href=""/DebtorLedger/?id=", Id, @""" target=""_blank"">", Code, ": ", Name, "</a>");
			}
		}

        [NotMapped]
        public Debtor ReportingHeadDebtor {
            get {
                var debtor = this;
                var debtorIds = new List<int>();

                while (debtor.ReportingParentId > 0 && debtor.ReportingParent != null) {
                    if (debtorIds.Contains(debtor.Id))
                        break;

                    debtorIds.Add(debtor.Id);
                    debtor = debtor.ReportingParent;
                }

                return debtor ?? this;
            }
        }

        [NotMapped]
        public Debtor BillingHeadDebtor {
            get {
                var debtor = this;
                var debtorIds = new List<int>();

                while (debtor.BillingParentId > 0 && debtor.BillingParent != null) {
                    if (debtorIds.Contains(debtor.Id))
                        break;

                    debtorIds.Add(debtor.Id);
                    debtor = debtor.BillingParent;
                }

                return debtor ?? this;
            }
        }

        [NotMapped]
        public DebtorContact DefaultContact {
            get {
                return DebtorContacts.OrderBy(t => t.IsDefault ? 0 : 1).FirstOrDefault() ?? new DebtorContact();
            }
        }

        [NotMapped]
		public ChartOfAccount CreditCardChartOfAccount {
			get {
				return FormOfPayments.SingleOrDefault(t => t.Id > 0 && t.DebtorId == Id)?.CreditCardChartOfAccount ?? new ChartOfAccount { Id = -1, Name = "Not Specified" };
			}
		}

		[NotMapped]
		public bool IsCreditCardDebtor {
			get {
				return FormOfPayments.Any(t => t.Id > 0 && t.DebtorId > 0);
			}
		}

        public static string GetNewCode(AppMainContext context, string name) {
            name = name?.Trim();

            if (string.IsNullOrEmpty(name))
                return string.Empty;

            name = Utils.RemoveExtraSpaces(name).Replace(" ", string.Empty).ToUpper();
            int length = name.Length < 8 ? name.Length : 8;

            string code = name.Substring(0, length);
            var q = context.Debtor.SingleOrDefault(t => t.Code.ToLower() == code.ToLower());

            if (q == null)
                return code.ToUpper();

            int i = 1;

            while (q != null) {
                i++;
                code = string.Format("{0}{1}", name.Substring(0, length), i);
                q = context.Debtor.SingleOrDefault(t => t.Code.ToLower() == code.ToLower());
            }

            return code.ToUpper();
        }

        public static string GetUniqueName(AppMainContext context, int debtorId, string name) {
            name = name?.Trim();

            if (string.IsNullOrEmpty(name))
                return string.Empty;

            var q = context.Debtor.SingleOrDefault(t => t.Id != debtorId && t.Name.ToLower() == name.ToLower());

            if (q == null)
                return name;

            int i = 1;
            int length = name.Length < 98 ? name.Length : 98;

            name = name.Substring(0, length);

            while (q != null) {
                i++;
                name = string.Format("{0} {1}", name, i);
                q = context.Debtor.SingleOrDefault(t => t.Id != debtorId && t.Name.ToLower() == name.ToLower());
            }

            return name;
        }

        public string GetAddress(AppMainContext context, bool useCountryCode = false) {
			var debtorAddress = DebtorAddresses.OrderByDescending(t => t.IsDefault).FirstOrDefault();

			if (debtorAddress == null)
				return string.Empty;

			string address = string.Empty;

			if (!string.IsNullOrEmpty(debtorAddress.Address1))
				address += string.Format("{0}{1}", debtorAddress.Address1, AppConstants.HtmlLineBreak);

			if (!string.IsNullOrEmpty(debtorAddress.Address2))
				address += string.Format("{0}{1}", debtorAddress.Address2, AppConstants.HtmlLineBreak);

			string country = string.Empty;

			if (!string.IsNullOrEmpty(debtorAddress.CountryCode)) {
				if (useCountryCode) {
					country = string.Concat(" ", debtorAddress.CountryCode);
				}
				else {
					country = string.Concat(AppConstants.HtmlLineBreak, Country.GetCountry(context, debtorAddress.CountryCode).Name);
				}
			}

			address += Utils.RemoveExtraSpaces(string.Concat(debtorAddress.Locality, " ", debtorAddress.Region, " ", debtorAddress.PostCode, country));
			return address.TrimEnd(AppConstants.HtmlLineBreak);
		}

		public bool IsReportingParentDebtorCircular(AppMainContext context) {
			int reportingParentId = ReportingParentId;
			var debtorIds = new List<int>();

			while (reportingParentId > 0) {
				if (debtorIds.Contains(Id))
					return true;

				debtorIds.Add(reportingParentId);
				reportingParentId = context.Debtor.Find(reportingParentId).ReportingParentId;
			}

			return false;
		}

		public bool IsBillingParentDebtorCircular(AppMainContext context) {
			int billingParentId = BillingParentId;
			var debtorIds = new List<int>();

			while (billingParentId > 0) {
				if (debtorIds.Contains(Id))
					return true;

				debtorIds.Add(billingParentId);
				billingParentId = context.Debtor.Find(billingParentId).BillingParentId;
			}

			return false;
		}

		public bool IsVideoConferencingOptionEnabled(Region region) {
			if (VideoConferencingDomestic && region.TravelZone == TravelZone.Domestic)
				return true;

			if (VideoConferencingShortHaul && region.TravelZone == TravelZone.ShortHaulInternational)
				return true;

			if (VideoConferencingInternational && (region.TravelZone == TravelZone.International || region.TravelZone == TravelZone.LongHaulInternational))
				return true;

			return false;
		}

		public bool ValidateCreditLimit(AppMainContext context, TransactionType transactionType, int id, int agencyId, decimal unsavedAmount) {
			decimal availableCredit = 0;
			return ValidateCreditLimit(context, transactionType, id, agencyId, unsavedAmount, ref availableCredit);
		}

		public bool ValidateCreditLimit(AppMainContext context, TransactionType transactionType, int id, int agencyId, decimal unsavedAmount, ref decimal availableCredit) {
			var debtor = BillingHeadDebtor;

			if (debtor.InvoiceValidationType == InvoiceValidationType.None)
				return true;

			availableCredit = debtor.CreditLimit - debtor.GetBalanceCurrent(context, transactionType, id, agencyId) - unsavedAmount;

			if (debtor.CreditLimit == 0 || unsavedAmount <= 0 || availableCredit >= 0)
				return true;

			if (debtor.InvoiceValidationType == InvoiceValidationType.PreventCreation)
				throw new UnreportedException(string.Format("This operation would result in the debtor's credit limit being exceeded by {0:c2}. The update has been cancelled.", -availableCredit));

			return false;
		}

		public decimal GetBalanceCurrent(AppMainContext context, TransactionType transactionType, int id, int agencyId) {
			var transactionDetail = context.TransactionDetail.Where(t => t.LedgerType == LedgerType.DebtorLedger && t.DebtorId == Id && t.Debtor.AgencyId == agencyId);

			if (id > 0) {
				switch (transactionType) {
					default:
						throw new InvalidOperationException("Invalid Transaction Type.");
					case TransactionType.All:
						break;
					case TransactionType.Bsp:
						transactionDetail = transactionDetail.Where(t => t.BspDetailId != id);
						break;
					case TransactionType.NonBsp:
						transactionDetail = transactionDetail.Where(t => t.NonBspDetailId != id);
						break;
					case TransactionType.Payment:
						transactionDetail = transactionDetail.Where(t => t.PaymentDetailId != id);
						break;
					case TransactionType.Invoice:
						transactionDetail = transactionDetail.Where(t => t.InvoiceDetailId != id);
						break;
					case TransactionType.Journal:
						transactionDetail = transactionDetail.Where(t => t.JournalDetailId != id);
						break;
					case TransactionType.Adjustment:
						transactionDetail = transactionDetail.Where(t => t.Transaction.AdjustmentId != id);
						break;
				}
			}

			return new DebtorLedger(transactionDetail, AgingCycle, AgingCycleStartDay, DateTime.Now, LedgerDocumentType.Standard).Balance;
		}

        public static IEnumerable<DebtorLedgerTransaction> GetDebtorLedgerTransactionQuery(AppLazyContext lazyContext, int debtorId, int customerId, int agencyId, int receiptDetailId, bool isCreditAllocation, bool isDetailView, TransactionMatchViewStatus transactionMatchViewStatus = TransactionMatchViewStatus.NotSaved) {
            var queryType = AllocationQueryType.DebtorReceipt;

            if (isCreditAllocation)
                queryType = AllocationQueryType.CreditAllocation;

            if (queryType == AllocationQueryType.DebtorReceipt && agencyId <= 0)
                return new List<DebtorLedgerTransaction>();

            var debtor = lazyContext.Debtor.Find(debtorId);

            var transactionDetail = lazyContext.TransactionDetail.Where(t => t.LedgerType == LedgerType.DebtorLedger && t.DebtorId == debtorId && t.Debtor.AgencyId == agencyId);
            var q = GetDebtorLedgerTransactionQuery(queryType, null, customerId, null, transactionDetail, transactionMatchViewStatus, debtor, receiptDetailId);

            if (isDetailView)
                return q;

            return q.GroupBy(t => new {
                t.TransactionId,
                t.TransactionRefId,
                t.TransactionType,
                t.SignType,
                t.DocumentNo,
                t.DocumentDate,
                t.TransactionMatchStatus
            }).OrderByDescending(t => t.Key.DocumentDate).ThenBy(t => t.Key.TransactionType).ThenByDescending(t => t.Key.DocumentNo).Select(row => new DebtorLedgerTransaction {
                TransactionDetailAllocationId = row.First().TransactionDetailAllocationId,
                TransactionId = row.Key.TransactionId,
                TransactionDetailId = row.First().TransactionDetailId,
                TransactionRefId = row.Key.TransactionRefId,
                TransactionDetailRefId = row.First().TransactionDetailRefId,
                ReceiptDetailId = row.First().ReceiptDetailId,
                PaymentDetailId = row.First().PaymentDetailId,
                InvoiceDetailId = row.First().InvoiceDetailId,
                JournalDetailId = row.First().JournalDetailId,
                AdjustmentId = row.First().AdjustmentId,
                TransactionType = row.Key.TransactionType,
                SignType = row.Key.SignType,
                DocumentNo = row.Key.DocumentNo,
                DocumentDate = row.Key.DocumentDate,
                Description = row.First().Description,
                Reference = row.First().Reference,
                AmountGross = row.Sum(t => (decimal?)t.AmountGross) ?? 0,
                MerchantFee = row.Sum(t => (decimal?)t.MerchantFee) ?? 0,
                MerchantFeeTax = row.Sum(t => (decimal?)t.MerchantFeeTax) ?? 0,
                Amount = row.Sum(t => (decimal?)t.Amount) ?? 0,
                TransactionMatchStatus = row.Key.TransactionMatchStatus
            });
        }

        public static IEnumerable<DebtorLedgerTransaction> GetDebtorLedgerTransactionQuery(AllocationQueryType queryType, DebtorLedger debtorLedger, int customerId, MatchedTxnsReportOption? matchedTxnsReportOption = null, IQueryable<TransactionDetail> transactionDetail = null, TransactionMatchViewStatus? transactionMatchViewStatus = null, Debtor debtor = null, int receiptDetailId = 0, DateTime? referenceDate = null, LedgerDocumentType documentType = LedgerDocumentType.Standard) {
            if (debtor == null && debtorLedger == null)
                return new List<DebtorLedgerTransaction>();

            if (debtor == null)
                debtor = debtorLedger.Debtor;

            if (queryType == AllocationQueryType.Report) {
                transactionDetail = debtorLedger.TransactionDetail.Where(t => t.Transaction.TransactionType != TransactionType.Bsp && t.Transaction.TransactionType != TransactionType.NonBsp);
            }
            else if (transactionMatchViewStatus != TransactionMatchViewStatus.Mismatches) {
                if (queryType == AllocationQueryType.DebtorReceipt) {
                    if (debtor.FormOfPayments.Any(t => t.DebtorId > 0)) {
                        transactionDetail = transactionDetail.Where(t1 => !t1.ReceiptDetail.Receipt.Debtor.FormOfPayments.Any(t2 => t2.DebtorId > 0));
                    }
                    else {
                        transactionDetail = transactionDetail.Where(t => t.ReceiptDetailId <= 0);
                    }
                }

                if (receiptDetailId > 0) {
                    if (transactionMatchViewStatus == TransactionMatchViewStatus.NotSaved) {
                        transactionDetail = transactionDetail.Where(t => t.ReceiptDetailId != receiptDetailId);
                    }
                    else {
                        transactionDetail = transactionDetail.Where(t1 => t1.TransactionDetailAllocations.Any(t2 => t2.ReceiptDetailId == receiptDetailId));
                    }
                }
            }

            transactionDetail = transactionDetail.Where(t => t.TransactionDetailType == TransactionDetailType.Normal || t.TransactionDetailType == TransactionDetailType.ExcludeFromSalesAnalysis);
            var transactionDetailAllocation = transactionDetail.SelectMany(t => t.TransactionDetailAllocations);

            if (queryType == AllocationQueryType.DebtorReceipt)
                transactionDetailAllocation = transactionDetailAllocation.Where(t => t.ReceiptDetailId != receiptDetailId);

            var q1 = from row in transactionDetailAllocation.AsEnumerable()
                     let MerchantFee = (row.ReceiptDetail.Receipt.Debtor.FormOfPayments.Any(t => t.DebtorId > 0) ? -1 : 1) * row.TransactionDetail.TransactionDetailAllocations.Where(t => t.GroupNo == row.GroupNo).Sum(t => (decimal?)(t.MerchantFee + t.MerchantFeeTax)) ?? 0
                     select new DebtorLedgerTransaction {
                         TransactionDetailAllocationId = row.Id,
                         TransactionId = row.TransactionDetail.TransactionId,
                         TransactionDetailId = row.TransactionDetailId,
                         TransactionRefId = row.ReceiptDetailId > 0 ? row.ReceiptDetail.ReceiptId : row.PaymentDetailId > 0 ? row.PaymentDetail.PaymentId : row.InvoiceDetailId > 0 ? row.InvoiceDetail.InvoiceId : row.JournalDetailId > 0 ? row.JournalDetail.JournalId : row.AdjustmentId,
                         TransactionDetailRefId = row.ReceiptDetailId > 0 ? row.ReceiptDetailId : row.PaymentDetailId > 0 ? row.PaymentDetailId : row.InvoiceDetailId > 0 ? row.InvoiceDetailId : row.JournalDetailId > 0 ? row.JournalDetailId : row.AdjustmentId,
                         ReceiptDetailId = row.ReceiptDetailId,
                         PaymentDetailId = row.PaymentDetailId,
                         InvoiceDetailId = row.InvoiceDetailId,
                         JournalDetailId = row.JournalDetailId,
                         AdjustmentId = row.AdjustmentId,
                         TransactionType = queryType == AllocationQueryType.DebtorReceipt ? row.TransactionDetail.Transaction.TransactionType : row.ReceiptDetailId > 0 ? TransactionType.Receipt : row.PaymentDetailId > 0 ? TransactionType.Payment : row.InvoiceDetailId > 0 ? row.InvoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote ? TransactionType.CreditNote : TransactionType.Invoice : row.JournalDetailId > 0 ? TransactionType.Journal : row.AdjustmentId > 0 ? TransactionType.Adjustment : TransactionType.All,
                         SignType = queryType == AllocationQueryType.DebtorReceipt ? row.TransactionDetail.SignType : row.GetSignType(LedgerType.DebtorLedger),
                         DocumentNo = queryType == AllocationQueryType.DebtorReceipt ? row.TransactionDetail.Transaction.DocumentNo : row.ReceiptDetailId > 0 ? row.ReceiptDetail.Receipt.DocumentNo : row.PaymentDetailId > 0 ? row.PaymentDetail.Payment.DocumentNo : row.InvoiceDetailId > 0 ? row.InvoiceDetail.Invoice.DocumentNo : row.JournalDetailId > 0 ? row.JournalDetail.Journal.DocumentNo : row.Adjustment.DocumentNo,
                         DocumentDate = row.GetDocumentDate(queryType),
                         Description = row.ReceiptDetailId > 0 && row.ReceiptDetail.Comments.Length > 0 ? row.ReceiptDetail.Comments : row.InvoiceDetailId > 0 && row.InvoiceDetail.Invoice.Comments.Length > 0 ? row.InvoiceDetail.Invoice.Comments : row.ReceiptDetail.Receipt.DebtorId == debtor.Id ? string.Empty : row.TransactionDetail.TxnAccountName,
                         Reference = row.Reference,
                         GroupNo = row.GroupNo,
                         Amount = row.Amount + (queryType == AllocationQueryType.CreditAllocation ? MerchantFee : 0),
                         AmountGross = row.Amount + MerchantFee,
                         MerchantFee = 0,
                         MerchantFeeTax = 0,
                         TransactionMatchStatus = queryType == AllocationQueryType.Report && row.TransactionDetail.TransactionDetailAllocations.Any(t => t.GetDocumentDate(queryType) > referenceDate) ? TransactionMatchStatus.None : row.TransactionMatchStatus
                     };

            var q2 = from row in transactionDetail.AsEnumerable()
                     let CreditCardDebtorAllocations = transactionDetailAllocation.Where(t1 => t1.ReceiptDetailId == row.ReceiptDetailId && t1.ReceiptDetail.Receipt.Debtor.FormOfPayments.Any(t2 => t2.DebtorId > 0))
                     let AllocationAmount = (queryType == AllocationQueryType.CreditAllocation || queryType == AllocationQueryType.Report) && CreditCardDebtorAllocations.Any() ? -(CreditCardDebtorAllocations.Sum(t => (decimal?)(t.TransactionDetail.Amount + t.TransactionDetail.Tax)) ?? 0) : transactionDetailAllocation.Where(t => (t.ReceiptDetailId > 0 && t.ReceiptDetailId == row.ReceiptDetailId) || (t.PaymentDetailId > 0 && t.PaymentDetailId == row.PaymentDetailId) || (t.InvoiceDetailId > 0 && t.InvoiceDetailId == row.InvoiceDetailId) || (t.JournalDetailId > 0 && t.JournalDetailId == row.JournalDetailId) || (t.AdjustmentId > 0 && t.AdjustmentId == row.Transaction.AdjustmentId)).Sum(t => (decimal?)(t.Amount + t.MerchantFee + t.MerchantFeeTax) ?? 0)
                     let Remainder = row.Amount + row.Tax - (row.InvoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote ? -1 : 1) * (row.InvoiceDetail.Discount + row.InvoiceDetail.DiscountTax) - AllocationAmount
                     where Remainder != 0
                     select new DebtorLedgerTransaction {
                         TransactionDetailAllocationId = -row.Id,
                         TransactionId = row.TransactionId,
                         TransactionDetailId = row.Id,
                         TransactionRefId = row.ReceiptDetailId > 0 ? row.ReceiptDetail.ReceiptId : row.PaymentDetailId > 0 ? row.PaymentDetail.PaymentId : row.InvoiceDetailId > 0 ? row.InvoiceDetail.InvoiceId : row.JournalDetailId > 0 ? row.JournalDetail.JournalId : row.Transaction.AdjustmentId,
                         TransactionDetailRefId = row.ReceiptDetailId > 0 ? row.ReceiptDetailId : row.PaymentDetailId > 0 ? row.PaymentDetailId : row.InvoiceDetailId > 0 ? row.InvoiceDetailId : row.JournalDetailId > 0 ? row.JournalDetailId : row.Transaction.AdjustmentId,
                         ReceiptDetailId = row.ReceiptDetailId,
                         PaymentDetailId = row.PaymentDetailId,
                         InvoiceDetailId = row.InvoiceDetailId,
                         JournalDetailId = row.JournalDetailId,
                         AdjustmentId = row.Transaction.AdjustmentId,
                         TransactionType = row.ReceiptDetailId > 0 ? TransactionType.Receipt : row.PaymentDetailId > 0 ? TransactionType.Payment : row.InvoiceDetailId > 0 ? row.InvoiceDetail.Invoice.InvoiceType == InvoiceType.CreditNote ? TransactionType.CreditNote : TransactionType.Invoice : row.JournalDetailId > 0 ? TransactionType.Journal : row.Transaction.AdjustmentId > 0 ? TransactionType.Adjustment : TransactionType.All,
                         SignType = row.SignType,
                         DocumentNo = row.Transaction.DocumentNo,
                         DocumentDate = row.Transaction.DocumentDate,
                         Description = row.ReceiptDetailId > 0 && row.ReceiptDetail.Comments.Length > 0 ? row.ReceiptDetail.Comments : row.InvoiceDetailId > 0 && row.InvoiceDetail.Invoice.Comments.Length > 0 ? row.InvoiceDetail.Invoice.Comments : row.TxnAccountName,
                         Reference = row.InvoiceDetail.Invoice.InvoiceLinkId > 0 ? string.Format("{0} No {1}", row.InvoiceDetail.Invoice.InvoiceLink.InvoiceType.GetEnumDescription(), row.InvoiceDetail.Invoice.InvoiceLink.DocumentNo) : string.Empty,
                         GroupNo = -1,
                         Amount = row.InvoiceDetail.Invoice.IsMatched ? Remainder : 0,
                         AmountGross = Remainder,
                         MerchantFee = queryType == AllocationQueryType.DebtorReceipt && debtor.IsCreditCardDebtor ? row.ReceiptDetail.GetMerchantFee(customerId) : 0,
                         MerchantFeeTax = queryType == AllocationQueryType.DebtorReceipt && debtor.IsCreditCardDebtor ? row.ReceiptDetail.GetMerchantFeeTax(customerId) : 0,
                         TransactionMatchStatus = queryType == AllocationQueryType.Report && row.TransactionDetailAllocations.Any(t => t.GetDocumentDate(queryType) > referenceDate) ? TransactionMatchStatus.None : row.InvoiceDetail.Invoice.IsMatched ? TransactionMatchStatus.AutoMatched : AllocationAmount == 0 ? TransactionMatchStatus.None : TransactionMatchStatus.Partial
                     };

            if (queryType == AllocationQueryType.Report && (documentType == LedgerDocumentType.Reconciliation || documentType == LedgerDocumentType.ReconciliationDetail)) {
                q1 = q1.Where(t => t.DocumentDate <= referenceDate);
                q2 = q2.Where(t => t.DocumentDate <= referenceDate);
            }

            if (queryType == AllocationQueryType.Report) {
                switch (matchedTxnsReportOption) {
                    case MatchedTxnsReportOption.ExcludeAll:
                        q1 = q1.Where(t => t.TransactionMatchStatus != TransactionMatchStatus.Matched && t.TransactionMatchStatus != TransactionMatchStatus.AutoMatched);
                        q2 = q2.Where(t => t.TransactionMatchStatus != TransactionMatchStatus.Matched && t.TransactionMatchStatus != TransactionMatchStatus.AutoMatched);
                        break;
                    case MatchedTxnsReportOption.CurrentPeriod:
                        q1 = q1.Where(t => t.DocumentDate >= debtorLedger.AgingCurrentDate);
                        q2 = q2.Where(t => t.DocumentDate >= debtorLedger.AgingCurrentDate);
                        break;
                    case MatchedTxnsReportOption.UpToPeriod1:
                        q1 = q1.Where(t => t.DocumentDate >= debtorLedger.AgingPeriod1Date);
                        q2 = q2.Where(t => t.DocumentDate >= debtorLedger.AgingPeriod1Date);
                        break;
                    case MatchedTxnsReportOption.UpToPeriod2:
                        q1 = q1.Where(t => t.DocumentDate >= debtorLedger.AgingPeriod2Date);
                        q2 = q2.Where(t => t.DocumentDate >= debtorLedger.AgingPeriod2Date);
                        break;
                }
            }
            else if (transactionMatchViewStatus == TransactionMatchViewStatus.NotSaved) {
                q1 = q1.Where(t => t.TransactionMatchStatus != TransactionMatchStatus.Matched && t.TransactionMatchStatus != TransactionMatchStatus.AutoMatched);
                q2 = q2.Where(t => t.TransactionMatchStatus != TransactionMatchStatus.Matched && t.TransactionMatchStatus != TransactionMatchStatus.AutoMatched);
            }
            else if (transactionMatchViewStatus == TransactionMatchViewStatus.Mismatches) {
                int[] groupNos = transactionDetailAllocation.GroupBy(t1 => new { t1.GroupNo }).Where(t1 => t1.Sum(t2 => t2.Amount) != 0).Select(t1 => t1.Key.GroupNo).Distinct().ToArray();
                q1 = q1.Where(t => groupNos.Contains(t.GroupNo));
                q2 = q2.Take(0);
            }
            else {
                q1 = q1.Where(t => t.TransactionMatchStatus == TransactionMatchStatus.Matched || t.TransactionMatchStatus == TransactionMatchStatus.AutoMatched);
                q2 = q2.Where(t => t.TransactionMatchStatus == TransactionMatchStatus.Matched || t.TransactionMatchStatus == TransactionMatchStatus.AutoMatched);
            }

            return q1.Concat(q2).OrderByDescending(t => t.DocumentDate).ThenBy(t => t.TransactionType).ThenByDescending(t => t.DocumentNo);
        }

        public static IEnumerable<DebtorLedger> GetDebtorLedgerReportQuery(AppLazyContext lazyContext, int agencyId, AgingCycle agingCycle, DateTime referenceDate, LedgerDocumentType documentType, int reportOrderId = 0, int classId = -1, int[] debtorIds = null) {
			var q = lazyContext.Debtor.Where(t => t.Id > 0);
			var transactionDetail = lazyContext.TransactionDetail.Where(t => t.LedgerType == LedgerType.DebtorLedger);

			if (agencyId > 0) {
				q = q.Where(t => t.AgencyId == agencyId);
				transactionDetail = transactionDetail.Where(t => t.Debtor.AgencyId == agencyId);
			}

			if (classId > 0)
				q = q.Where(t => t.ClassId == classId);

			if (agingCycle != AgingCycle.NotSpecified)
				q = q.Where(t => t.AgingCycle == agingCycle);

			if (debtorIds != null && debtorIds.Length > 0)
				q = q.Where(t => debtorIds.Contains(t.Id));

			if (reportOrderId == 0) {
				q = q.OrderBy(t => t.Code);
			}
			else {
				q = q.OrderBy(t => t.Name);
			}

			DateTime mtdFrom = DateTime.MinValue;
			DateTime ytdFrom = DateTime.MinValue;

			return q.ToList().ConvertAll(row => new DebtorLedger(transactionDetail.Where(t => t.DebtorId == row.Id), row.AgingCycle, row.AgingCycleStartDay, referenceDate, documentType) {
				Debtor = row,
				Address = row.GetAddress(lazyContext),
				PaymentTerms = row.PaymentTerm.Name
			});
		}

		public static List<TransactionDetailReportModel> GetDebtorLedgerTransactionReportQuery(DebtorLedger debtorLedger, int customerId, MatchedTxnsReportOption matchedTxnsReportOption, DateTime referenceDate, LedgerDocumentType documentType) {
            return GetDebtorLedgerTransactionQuery(
                queryType: AllocationQueryType.Report,
                debtorLedger: debtorLedger,
                customerId: customerId,
                matchedTxnsReportOption: matchedTxnsReportOption,
                transactionDetail: null,
                transactionMatchViewStatus: null,
                debtor: null,
                receiptDetailId: 0,
                referenceDate: referenceDate,
                documentType: documentType
            ).GroupBy(t => new {
                t.TransactionId,
                t.TransactionRefId,
                t.TransactionType,
                t.SignType,
                t.DocumentNo,
                t.DocumentDate,
                t.TransactionMatchStatus
            }).OrderByDescending(t => t.Key.DocumentDate).ThenBy(t => t.Key.TransactionType).ThenByDescending(t => t.Key.DocumentNo).Select(row => new TransactionDetailReportModel {
                TransactionDetailAllocationId = row.First().TransactionDetailAllocationId,
                TransactionType = row.Key.TransactionType.GetEnumDescription(),
                DocumentNo = row.Key.DocumentNo,
                DocumentDate = row.Key.DocumentDate,
                Description = row.First().Description,
                Reference = row.First().Reference,
                SignType = row.Key.SignType.ToString(),
                AmountGross = row.Sum(t => (decimal?)t.AmountGross) ?? 0,
                IsMatched = row.Key.TransactionMatchStatus == TransactionMatchStatus.Matched || row.Key.TransactionMatchStatus == TransactionMatchStatus.AutoMatched
            }).ToList();
        }
	}

	public partial class DebtorAddress {
		[NotMapped]
		public string Address {
			get {
				return string.Concat(Address1, " ", Address2, " ", Locality, " ", Region, " ", PostCode, " ", CountryCode).Trim();
			}
		}
	}

	public partial class DebtorContact {
		[NotMapped]
		public string FullName {
			get {
				return string.Concat(Title, " ", Name).Trim();
			}
		}

		[NotMapped]
		public string FullNameWithEmail {
			get {
				return string.IsNullOrEmpty(Email) ? FullName : string.Concat(@"<a href=""mailto:", WebUtility.HtmlEncode(Email), @""">", FullName, "</a>");
			}
		}

		[NotMapped]
		public string PhoneNo {
			get {
			    return string.IsNullOrEmpty(PhoneWork) ? string.IsNullOrEmpty(Mobile) ? PhoneHome : Mobile : PhoneWork;
            }
        }
	}

	public class DebtorLedger {
		public Debtor Debtor { get; set; }
		public string Address { get; set; }
		public string PaymentTerms { get; set; }
		public DateTime AgingCurrentDate { get; set; }
		public DateTime AgingPeriod1Date { get; set; }
		public DateTime AgingPeriod2Date { get; set; }
		public DateTime AgingPeriod3Date { get; set; }
		public decimal BalanceCurrent { get; set; }
		public decimal BalancePeriod1 { get; set; }
		public decimal BalancePeriod2 { get; set; }
		public decimal BalancePeriod3 { get; set; }
		public decimal Balance { get; set; }

		public IQueryable<TransactionDetail> TransactionDetail { get; set; }

		public DebtorLedger(IQueryable<TransactionDetail> transactionDetail, AgingCycle agingCycle, DayOfWeekExt agingCycleStartDay, DateTime referenceDate, LedgerDocumentType documentType) {
			if (documentType == LedgerDocumentType.Reconciliation || documentType == LedgerDocumentType.ReconciliationDetail) {
				DateTime documentDate = referenceDate;
				transactionDetail = transactionDetail.Where(t => t.Transaction.DocumentDate <= documentDate);
			}

			TransactionDetail = transactionDetail;

			if (agingCycle == AgingCycle.ThirtyDay) {
				referenceDate = new DateTime(referenceDate.Year, referenceDate.Month, 1);
			}
			else {
				referenceDate = referenceDate.StartOfWeek(agingCycleStartDay);
			}

			AgingCurrentDate = referenceDate;
			AgingPeriod1Date = agingCycle == AgingCycle.SevenDay ? referenceDate.AddDays(-7) : agingCycle == AgingCycle.FourteenDay ? referenceDate.AddDays(-14) : referenceDate.AddMonths(-1);
			AgingPeriod2Date = agingCycle == AgingCycle.SevenDay ? referenceDate.AddDays(-14) : agingCycle == AgingCycle.FourteenDay ? referenceDate.AddDays(-28) : referenceDate.AddMonths(-2);
			AgingPeriod3Date = agingCycle == AgingCycle.SevenDay ? referenceDate.AddDays(-21) : agingCycle == AgingCycle.FourteenDay ? referenceDate.AddDays(-42) : referenceDate.AddMonths(-3);

			BalanceCurrent = transactionDetail.Where(t => t.Transaction.DocumentDate >= AgingCurrentDate).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
			BalancePeriod1 = transactionDetail.Where(t => t.Transaction.DocumentDate < AgingCurrentDate && t.Transaction.DocumentDate >= AgingPeriod1Date).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
			BalancePeriod2 = transactionDetail.Where(t => t.Transaction.DocumentDate < AgingPeriod1Date && t.Transaction.DocumentDate >= AgingPeriod2Date).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
			BalancePeriod3 = transactionDetail.Where(t => t.Transaction.DocumentDate < AgingPeriod2Date).Sum(t => (decimal?)(t.Amount + t.Tax)) ?? 0;
			Balance = BalanceCurrent + BalancePeriod1 + BalancePeriod2 + BalancePeriod3;
		}
	}

	public class DebtorLedgerTransaction {
		public long TransactionDetailAllocationId { get; set; }
		public int TransactionId { get; set; }
		public long TransactionDetailId { get; set; }
        public int TransactionRefId { get; set; }
		public int TransactionDetailRefId { get; set; }
		public int ReceiptDetailId { get; set; }
		public int PaymentDetailId { get; set; }
		public int InvoiceDetailId { get; set; }
		public int JournalDetailId { get; set; }
		public int AdjustmentId { get; set; }
		public TransactionType TransactionType { get; set; }
		public SignType SignType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string Description { get; set; }
		public string Reference { get; set; }
		public int GroupNo { get; set; }
		public decimal Amount { get; set; }
		public decimal AmountGross { get; set; }
		public decimal MerchantFee { get; set; }
		public decimal MerchantFeeTax { get; set; }
		public TransactionMatchStatus TransactionMatchStatus { get; set; }
		public decimal Debit { get { return SignType == SignType.Debit ? AmountGross : 0; } }
		public decimal Credit { get { return SignType == SignType.Credit ? AmountGross : 0; } }

        public string DocumentNoLink {
            get {
                return Transaction.GetDocumentNoLink("TransactionDetailAllocation", TransactionType, TransactionRefId, DocumentNo);
            }
        }
    }
}