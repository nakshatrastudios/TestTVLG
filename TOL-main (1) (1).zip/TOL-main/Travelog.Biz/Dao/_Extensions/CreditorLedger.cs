using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Net;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Enums;
using Travelog.Biz.Models;

namespace Travelog.Biz.Dao.CreditorLedger {
    public partial class Creditor {
        [NotMapped]
        public string AccountName {
            get {
                return Id <= 0 ? string.Empty : Name;
            }
        }

        [NotMapped]
        public string AccountNameLink {
            get {
                return Id <= 0 ? string.Empty : string.Concat(@"<a href=""/CreditorLedger/?id=", Id, @""" target=""_blank"">", Name, "</a>");
            }
        }

        [NotMapped]
        public CreditorContact DefaultContact {
            get {
                return CreditorContacts.OrderBy(t => t.IsDefault ? 0 : 1).FirstOrDefault() ?? new CreditorContact();
            }
        }

        public static Creditor GetBspAgent(AppLazyContext lazyContext, int customerId, TripLineType tripLineType = TripLineType.All) {
            if (AppSettings.Setting(customerId).BspCreditorId > 0)
                return lazyContext.Creditor.Find(AppSettings.Setting(customerId).BspCreditorId);

            var creditors = lazyContext.Creditor.Where(t => t.IsBspAgent);

            if (tripLineType != TripLineType.All)
                creditors = creditors.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.Supplier.SupplierServiceTypes.Any(t3 => t3.ServiceType.TripLineType == tripLineType)));

            return creditors.FirstOrDefault() ?? lazyContext.Creditor.Find(-1);
        }

        public static Creditor GetCreditor(AppLazyContext lazyContext, string name) {
            var q = lazyContext.Creditor;
            return q.SingleOrDefault(t => t.Name.ToLower() == (name ?? string.Empty).ToLower()) ?? q.Find(-1);
        }

        public static Creditor GetCreditor(AppLazyContext lazyContext, Crs crs, string crsCode, string name) {
            var creditorCrs = lazyContext.CreditorCrs.Where(t => (t.Crs == Crs.NotSpecified || t.Crs == crs) && t.CrsCode.ToLower() == (crsCode ?? string.Empty).ToLower()).ToList();

            if (creditorCrs.Count == 1)
                return creditorCrs[0].Creditor;

            return GetCreditor(lazyContext, name);
        }

        public static Creditor GetCreditor(AppLazyContext lazyContext, int supplierId) {
            var q = lazyContext.Creditor;

            return q.FirstOrDefault(t1 => t1.SupplierCreditors.Any(t2 => t2.SupplierId == supplierId && t2.IsDefault))
                ?? q.FirstOrDefault(t1 => t1.SupplierCreditors.Any(t2 => t2.SupplierId == supplierId))
                ?? q.Find(-1);
        }

        public static IQueryable<Creditor> GetCreditorQuery(AppMainContext context, BspAgentType bspAgentType, int agencyId, int supplierId, string text, int? id) {
            var q = context.Creditor.Include(t => t.Agency).Include(t => t.Currency).Include(t => t.Class).Include(t => t.SupplierCreditors).Include(t => t.CreditorAddresses).Include(t => t.CreditorContacts).Where(t => t.Id > 0);

            switch (bspAgentType) {
                case BspAgentType.Bsp:
                    q = q.Where(t => t.IsBspAgent);
                    break;
                case BspAgentType.NonBsp:
                    q = q.Where(t => t.IsNonBspAgent);
                    break;
                case BspAgentType.BspOrNonBsp:
                    q = q.Where(t => t.IsBspAgent || t.IsNonBspAgent);
                    break;
                case BspAgentType.NeitherBspNorNonBsp:
                    q = q.Where(t => !t.IsBspAgent && !t.IsNonBspAgent);
                    break;
            }

            if (agencyId > 0)
                q = q.Where(t => t.AgencyId == agencyId);

            if (supplierId > 0)
                q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.SupplierId == supplierId));

            if (!string.IsNullOrEmpty(text))
                q = q.Where(t => t.Name.ToLower().Contains(text.ToLower()));

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.OrderBy(t => t.Name);
        }

        public static IQueryable<TransactionDetail> GetBspAccrualQuery(AppLazyContext lazyContext, int agencyId, PaidStatusReportOption paidStatusReportOption, LedgerDocumentType documentType, DateTime referenceDate, bool isFinancialIntegrity = false, bool amountsOnly = false, DateTime? dateFrom = null, DateTime? dateTo = null) {
            var bspAccrualAccount = lazyContext.BspDetail.Where(t => t.Id > 0);

            if (isFinancialIntegrity) {
                bspAccrualAccount = bspAccrualAccount.Where(t => t.Bsp.DocumentDate <= referenceDate && (t.Bsp.PaymentId <= 0 || (t.Bsp.PaymentId > 0 && t.Bsp.Payment.DocumentDate > referenceDate)));
            }
            else {
                if (paidStatusReportOption == PaidStatusReportOption.Unpaid) {
                    bspAccrualAccount = bspAccrualAccount.Where(t => t.Bsp.PaymentId <= 0);
                }
                else if (paidStatusReportOption == PaidStatusReportOption.Paid) {
                    bspAccrualAccount = bspAccrualAccount.Where(t => t.Bsp.PaymentId > 0);
                }

                if (documentType == LedgerDocumentType.Reconciliation || documentType == LedgerDocumentType.ReconciliationDetail)
                    bspAccrualAccount = bspAccrualAccount.Where(t => t.Bsp.DocumentDate <= referenceDate);
            }

            if (agencyId > 0)
                bspAccrualAccount = bspAccrualAccount.Where(t => t.Bsp.AgencyId == agencyId);

            if (dateFrom != null)
                bspAccrualAccount = bspAccrualAccount.Where(t => t.Bsp.DocumentDate >= dateFrom);

            if (dateTo != null)
                bspAccrualAccount = bspAccrualAccount.Where(t => t.Bsp.DocumentDate <= dateTo);

            if (amountsOnly) {
                return bspAccrualAccount.Select(row => new TransactionDetail {
                    Amount = -row.Bsp.Sign * row.SupplierNet,
                    Tax = -row.Bsp.Sign * row.SupplierNetTax,
                    IsCash = true
                });
            }

            return bspAccrualAccount.OrderByDescending(t => t.Bsp.DocumentDate).ThenByDescending(t => t.Bsp.DocumentNo).Select(row => new TransactionDetail {
                Id = row.TransactionDetails.Count == 0 ? 0 : row.TransactionDetails[0].Id,
                TransactionId = row.Bsp.Transactions.Count == 0 ? 0 : row.Bsp.Transactions[0].Id,
                Transaction = row.Bsp.Transactions.Count == 0 ? new Transaction { Id = 0, TransactionType = TransactionType.Bsp, Bsp = row.Bsp, DocumentNo = row.Bsp.DocumentNo, DocumentDate = row.Bsp.DocumentDate } : row.Bsp.Transactions[0],
                LedgerType = LedgerType.GeneralLedger,
                SignType = SignType.Credit,
                TripId = row.Bsp.TripId,
                CreditorId = row.Bsp.CreditorId,
                BspDetailId = row.Id,
                BspDetail = row,
                Description = string.Format("{0}: {1}", row.Bsp.Trip.TripNo, row.Bsp.Trip.FullName),
                Reference = row.Bsp.PaymentId <= 0 ? string.Empty : string.Format("Payment No {0}", row.Bsp.Payment.DocumentNo),
                Amount = -row.Bsp.Sign * row.SupplierNet,
                Tax = -row.Bsp.Sign * row.SupplierNetTax,
                IsCash = true
            });
        }

        public static IEnumerable<CreditorLedgerTransaction> GetCreditorLedgerTransactionQuery(AppLazyContext lazyContext, int creditorId, int agencyId, bool isCreditAllocation, TransactionType transactionType, bool isDetailView, TransactionMatchViewStatus transactionMatchViewStatus = TransactionMatchViewStatus.NotSaved) {
            var queryType = AllocationQueryType.Report;

            if (isCreditAllocation)
                queryType = AllocationQueryType.CreditAllocation;

            var transactionDetail = lazyContext.TransactionDetail.Where(t => t.LedgerType == LedgerType.CreditorLedger && t.CreditorId == creditorId && t.Creditor.AgencyId == agencyId);
            var q = GetCreditorLedgerTransactionQuery(queryType, null, transactionType, null, transactionDetail, transactionMatchViewStatus);

            if (isDetailView)
                return q;

            return q.GroupBy(t => new {
                t.TransactionId,
                t.TransactionRefId,
                t.TransactionType,
                t.SignType,
                t.DocumentNo,
                t.DocumentDate,
                t.TransactionMatchStatus
            }).OrderByDescending(t => t.Key.DocumentDate).ThenBy(t => t.Key.TransactionType).ThenByDescending(t => t.Key.DocumentNo).Select(row => new CreditorLedgerTransaction {
                TransactionDetailAllocationId = row.First().TransactionDetailAllocationId,
                TransactionId = row.Key.TransactionId,
                TransactionDetailId = row.First().TransactionDetailId,
                TransactionRefId = row.Key.TransactionRefId,
                TransactionDetailRefId = row.First().TransactionDetailRefId,
                ReceiptDetailId = row.First().ReceiptDetailId,
                NonBspDetailId = row.First().NonBspDetailId,
                PaymentDetailId = row.First().PaymentDetailId,
                JournalDetailId = row.First().JournalDetailId,
                AdjustmentId = row.First().AdjustmentId,
                TransactionType = row.Key.TransactionType,
                SignType = row.Key.SignType,
                DocumentNo = row.Key.DocumentNo,
                DocumentDate = row.Key.DocumentDate,
                Description = row.First().Description,
                Reference = row.First().Reference,
                AmountGross = row.Sum(t => (decimal?)t.AmountGross) ?? 0,
                Amount = row.Sum(t => (decimal?)t.Amount) ?? 0,
                TransactionMatchStatus = row.Key.TransactionMatchStatus
            });
        }

        public static IEnumerable<CreditorLedgerTransaction> GetCreditorLedgerTransactionQuery(AllocationQueryType queryType, CreditorLedger creditorLedger, TransactionType transactionType, MatchedTxnsReportOption? matchedTxnsReportOption = null, IQueryable<TransactionDetail> transactionDetail = null, TransactionMatchViewStatus? transactionMatchViewStatus = null, DateTime? referenceDate = null, LedgerDocumentType documentType = LedgerDocumentType.Standard) {
            if (queryType == AllocationQueryType.Report) {
                transactionDetail = creditorLedger.TransactionDetail.Where(t => t.Transaction.TransactionType != TransactionType.Bsp && t.Transaction.TransactionType != TransactionType.Invoice);

                if (transactionType != TransactionType.All)
                    transactionDetail = transactionDetail.Where(t => t.Transaction.TransactionType == transactionType);
            }

            transactionDetail = transactionDetail.Where(t => t.TransactionDetailType == TransactionDetailType.Normal || t.TransactionDetailType == TransactionDetailType.ExcludeFromSalesAnalysis);
            var transactionDetailAllocation = transactionDetail.SelectMany(t => t.TransactionDetailAllocations);

            var q1 = from row in transactionDetailAllocation.AsEnumerable()
                     select new CreditorLedgerTransaction {
                         TransactionDetailAllocationId = row.Id,
                         TransactionId = row.TransactionDetail.TransactionId,
                         TransactionDetailId = row.TransactionDetailId,
                         TransactionRefId = row.ReceiptDetailId > 0 ? row.ReceiptDetail.ReceiptId : row.NonBspDetailId > 0 ? row.NonBspDetail.NonBspId : row.PaymentDetailId > 0 ? row.PaymentDetail.PaymentId : row.JournalDetailId > 0 ? row.JournalDetail.JournalId : row.AdjustmentId,
                         TransactionDetailRefId = row.ReceiptDetailId > 0 ? row.ReceiptDetailId : row.NonBspDetailId > 0 ? row.NonBspDetailId : row.PaymentDetailId > 0 ? row.PaymentDetailId : row.JournalDetailId > 0 ? row.JournalDetailId : row.AdjustmentId,
                         ReceiptDetailId = row.ReceiptDetailId,
                         NonBspDetailId = row.NonBspDetailId,
                         PaymentDetailId = row.PaymentDetailId,
                         JournalDetailId = row.JournalDetailId,
                         AdjustmentId = row.AdjustmentId,
                         TransactionType = row.ReceiptDetailId > 0 ? TransactionType.Receipt : row.NonBspDetailId > 0 ? TransactionType.NonBsp : row.PaymentDetailId > 0 ? TransactionType.Payment : row.JournalDetailId > 0 ? TransactionType.Journal : row.AdjustmentId > 0 ? TransactionType.Adjustment : TransactionType.All,
                         SignType = row.GetSignType(LedgerType.CreditorLedger),
                         DocumentNo = row.ReceiptDetailId > 0 ? row.ReceiptDetail.Receipt.DocumentNo : row.NonBspDetailId > 0 ? row.NonBspDetail.NonBsp.DocumentNo : row.PaymentDetailId > 0 ? row.PaymentDetail.Payment.DocumentNo : row.JournalDetailId > 0 ? row.JournalDetail.Journal.DocumentNo : row.Adjustment.DocumentNo,
                         DocumentDate = row.GetDocumentDate(queryType),
                         Description = row.ReceiptDetailId > 0 && row.ReceiptDetail.Comments.Length > 0 ? row.ReceiptDetail.Comments : row.TransactionDetail.TxnAccountName,
                         Reference = row.Reference,
                         GroupNo = row.GroupNo,
                         Amount = row.Amount,
                         AmountGross = row.Amount,
                         TransactionMatchStatus = queryType == AllocationQueryType.Report && row.TransactionDetail.TransactionDetailAllocations.Any(t => t.GetDocumentDate(queryType) > referenceDate) ? TransactionMatchStatus.None : row.TransactionMatchStatus
                     };

            var q2 = from row in transactionDetail.AsEnumerable()
                     let AllocationAmount = transactionDetailAllocation.Where(t => t.TransactionDetailId == row.Id || (t.ReceiptDetailId > 0 && t.ReceiptDetailId == row.ReceiptDetailId) || (t.NonBspDetailId > 0 && t.NonBspDetailId == row.NonBspDetailId) || (t.PaymentDetailId > 0 && t.PaymentDetailId == row.PaymentDetailId) || (t.JournalDetailId > 0 && t.JournalDetailId == row.JournalDetailId) || (t.AdjustmentId > 0 && t.AdjustmentId == row.Transaction.AdjustmentId)).Sum(t => (decimal?)(t.Amount + t.MerchantFee + t.MerchantFeeTax)) ?? 0
                     let Remainder = row.Amount + row.Tax - AllocationAmount
                     where Remainder != 0
                     select new CreditorLedgerTransaction {
                         TransactionDetailAllocationId = -row.Id,
                         TransactionId = row.TransactionId,
                         TransactionDetailId = row.Id,
                         TransactionRefId = row.ReceiptDetailId > 0 ? row.ReceiptDetail.ReceiptId : row.NonBspDetailId > 0 ? row.NonBspDetail.NonBspId : row.PaymentDetailId > 0 ? row.PaymentDetail.PaymentId : row.JournalDetailId > 0 ? row.JournalDetail.JournalId : row.Transaction.AdjustmentId,
                         TransactionDetailRefId = row.ReceiptDetailId > 0 ? row.ReceiptDetailId : row.NonBspDetailId > 0 ? row.NonBspDetailId : row.PaymentDetailId > 0 ? row.PaymentDetailId : row.JournalDetailId > 0 ? row.JournalDetailId : row.Transaction.AdjustmentId,
                         ReceiptDetailId = row.ReceiptDetailId,
                         NonBspDetailId = row.NonBspDetailId,
                         PaymentDetailId = row.PaymentDetailId,
                         JournalDetailId = row.JournalDetailId,
                         AdjustmentId = row.Transaction.AdjustmentId,
                         TransactionType = row.ReceiptDetailId > 0 ? TransactionType.Receipt : row.NonBspDetailId > 0 ? TransactionType.NonBsp : row.PaymentDetailId > 0 ? TransactionType.Payment : row.JournalDetailId > 0 ? TransactionType.Journal : row.Transaction.AdjustmentId > 0 ? TransactionType.Adjustment : TransactionType.All,
                         SignType = row.SignType,
                         DocumentNo = row.Transaction.DocumentNo,
                         DocumentDate = row.Transaction.DocumentDate,
                         Description = row.ReceiptDetailId > 0 && row.ReceiptDetail.Comments.Length > 0 ? row.ReceiptDetail.Comments : row.TxnAccountName,
                         Reference = row.NonBspDetail.NonBsp.PaymentId > 0 ? string.Format("Payment No {0}", row.NonBspDetail.NonBsp.Payment.DocumentNo) : row.PaymentDetail.Payment.PaymentType == PaymentType.NonBspReturn && row.PaymentDetail.Payment.NonBsps.Count > 0 && row.PaymentDetail.TripLineId > 0 && row.PaymentDetail.TripLineAirPassengerId > 0 ? string.Format("Non-BSP No {0}", row.PaymentDetail.Payment.NonBsps.FirstOrDefault(t1 => (row.PaymentDetail.TripLineId > 0 && row.PaymentDetail.TripLineAirPassengerId <= 0 && t1.TripLineId == row.PaymentDetail.TripLineId) || t1.NonBspDetails.Any(t2 => row.PaymentDetail.TripLineAirPassengerId > 0 && t2.TripLineAirPassengerId == row.PaymentDetail.TripLineAirPassengerId))?.DocumentNo) : row.Reference,
                         GroupNo = row.TransactionId,
                         Amount = row.NonBspDetail.NonBsp.PaymentId > 0 || row.PaymentDetail.Payment.PaymentType == PaymentType.NonBspReturn ? Remainder : 0,
                         AmountGross = Remainder,
                         TransactionMatchStatus = queryType == AllocationQueryType.Report && row.TransactionDetailAllocations.Any(t => t.GetDocumentDate(queryType) > referenceDate) ? TransactionMatchStatus.None : row.NonBspDetail.NonBsp.PaymentId > 0 || row.PaymentDetail.Payment.PaymentType == PaymentType.NonBspReturn ? TransactionMatchStatus.AutoMatched : TransactionMatchStatus.None
                     };

            if (queryType == AllocationQueryType.Report && (documentType == LedgerDocumentType.Reconciliation || documentType == LedgerDocumentType.ReconciliationDetail)) {
                q1 = q1.Where(t => t.DocumentDate <= referenceDate);
                q2 = q2.Where(t => t.DocumentDate <= referenceDate);
            }

            if (transactionMatchViewStatus == null) {
                switch (matchedTxnsReportOption) {
                    case MatchedTxnsReportOption.ExcludeAll:
                        q1 = q1.Where(t => t.TransactionMatchStatus != TransactionMatchStatus.Matched && t.TransactionMatchStatus != TransactionMatchStatus.AutoMatched);
                        q2 = q2.Where(t => t.TransactionMatchStatus != TransactionMatchStatus.Matched && t.TransactionMatchStatus != TransactionMatchStatus.AutoMatched);
                        break;
                    case MatchedTxnsReportOption.CurrentPeriod:
                        q1 = q1.Where(t => t.DocumentDate >= creditorLedger.AgingCurrentDate);
                        q2 = q2.Where(t => t.DocumentDate >= creditorLedger.AgingCurrentDate);
                        break;
                    case MatchedTxnsReportOption.UpToPeriod1:
                        q1 = q1.Where(t => t.DocumentDate >= creditorLedger.AgingPeriod1Date);
                        q2 = q2.Where(t => t.DocumentDate >= creditorLedger.AgingPeriod1Date);
                        break;
                    case MatchedTxnsReportOption.UpToPeriod2:
                        q1 = q1.Where(t => t.DocumentDate >= creditorLedger.AgingPeriod2Date);
                        q2 = q2.Where(t => t.DocumentDate >= creditorLedger.AgingPeriod2Date);
                        break;
                }
            }
            else if (transactionMatchViewStatus == TransactionMatchViewStatus.NotSaved) {
                q1 = q1.Where(t => t.TransactionMatchStatus != TransactionMatchStatus.Matched && t.TransactionMatchStatus != TransactionMatchStatus.AutoMatched);
                q2 = q2.Where(t => t.TransactionMatchStatus != TransactionMatchStatus.Matched && t.TransactionMatchStatus != TransactionMatchStatus.AutoMatched);
            }
            else if (transactionMatchViewStatus == TransactionMatchViewStatus.Mismatches) {
                int[] groupNos = transactionDetailAllocation.GroupBy(t1 => new { t1.GroupNo }).Where(t1 => t1.Sum(t2 => t2.Amount) != 0).Select(t1 => t1.Key.GroupNo).Distinct().ToArray();
                q1 = q1.Where(t => groupNos.Contains(t.GroupNo));
                q2 = q2.Take(0);
            }
            else {
                q1 = q1.Where(t => t.TransactionMatchStatus == TransactionMatchStatus.Matched || t.TransactionMatchStatus == TransactionMatchStatus.AutoMatched);
                q2 = q2.Where(t => t.TransactionMatchStatus == TransactionMatchStatus.Matched || t.TransactionMatchStatus == TransactionMatchStatus.AutoMatched);
            }

            return q1.Concat(q2).OrderByDescending(t => t.DocumentDate).ThenBy(t => t.TransactionType).ThenByDescending(t => t.DocumentNo);
        }

        public static IEnumerable<CreditorLedger> GetCreditorLedgerReportQuery(AppLazyContext lazyContext, int agencyId, AgingCycle agingCycle, DateTime referenceDate, LedgerDocumentType documentType, PaidStatusReportOption paidStatusReportOption = PaidStatusReportOption.All, LedgerReportType ledgerReportType = LedgerReportType.TrialBalance, DateTime? dateFrom = null, DateTime? dateTo = null, TransactionType transactionType = TransactionType.All, int classId = -1, int[] creditorIds = null, DateTime? reportDate = null) {
            var q = lazyContext.Creditor.Where(t => t.Id > 0);

            if (agencyId > 0)
                q = q.Where(t => t.AgencyId == agencyId);

            if (agingCycle != AgingCycle.NotSpecified)
                q = q.Where(t => t.AgingCycle == agingCycle);

            if (classId > 0)
                q = q.Where(t => t.ClassId == classId);

            if (creditorIds != null && creditorIds.Length > 0)
                q = q.Where(t => creditorIds.Contains(t.Id));

            IQueryable<TransactionDetail> transactionDetail = null;

            DateTime mtdFrom = DateTime.MinValue;
            DateTime ytdFrom = DateTime.MinValue;

            if (ledgerReportType == LedgerReportType.TrialBalance) {
                transactionDetail = lazyContext.TransactionDetail.Where(t => t.LedgerType == LedgerType.CreditorLedger);

                if (agencyId > 0)
                    transactionDetail = transactionDetail.Where(t => t.Creditor.AgencyId == agencyId);

                if (transactionType != TransactionType.All)
                    transactionDetail = transactionDetail.Where(t => t.Transaction.TransactionType == transactionType);

                return q.OrderBy(t => t.Name).ToList().ConvertAll(row => new CreditorLedger(transactionDetail.Where(t => t.CreditorId == row.Id), row.AgingCycle, DayOfWeekExt.Monday, documentType, referenceDate) {
                    Creditor = row
                });
            }
            else {
                transactionDetail = GetBspAccrualQuery(lazyContext, agencyId, paidStatusReportOption, documentType, referenceDate, false, false, dateFrom, dateTo);
                int[] bspDetailIds = transactionDetail.Select(t => t.BspDetailId).ToArray();

                var totals = lazyContext.BspDetail.Where(t => bspDetailIds.Contains(t.Id)).Select(row => new CreditorTotalsModel {
                    CreditorId = row.Bsp.CreditorId,
                    AgingDate = row.Bsp.DocumentDate,
                    AmountGross = -row.Bsp.Sign * (row.SupplierNet + row.SupplierNetTax)
                });

                return q.OrderBy(t => t.Name).ToList().ConvertAll(row => new CreditorLedger(transactionDetail.Where(t => t.CreditorId == row.Id), row.AgingCycle, DayOfWeekExt.Monday, documentType, referenceDate, totals.Where(t => t.CreditorId == row.Id).ToList()) {
                    Creditor = row
                });
            }
        }

        public static List<TransactionDetailReportModel> GetCreditorLedgerTransactionReportQuery(CreditorLedger creditorLedger, TransactionType transactionType, MatchedTxnsReportOption matchedTxnsReportOption, DateTime referenceDate, LedgerDocumentType documentType) {
            return GetCreditorLedgerTransactionQuery(
                queryType: AllocationQueryType.Report,
                creditorLedger: creditorLedger,
                transactionType: transactionType,
                matchedTxnsReportOption: matchedTxnsReportOption,
                transactionDetail: null,
                transactionMatchViewStatus: null,
                referenceDate: referenceDate,
                documentType: documentType
            ).GroupBy(t => new {
                t.TransactionId,
                t.TransactionRefId,
                t.TransactionType,
                t.SignType,
                t.DocumentNo,
                t.DocumentDate,
                t.TransactionMatchStatus
            }).OrderByDescending(t => t.Key.DocumentDate).ThenBy(t => t.Key.TransactionType).ThenByDescending(t => t.Key.DocumentNo).Select(row => new TransactionDetailReportModel {
                TransactionDetailAllocationId = row.First().TransactionDetailAllocationId,
                TransactionType = row.Key.TransactionType.GetEnumDescription(),
                DocumentNo = row.Key.DocumentNo,
                DocumentDate = row.Key.DocumentDate,
                Description = row.First().Description,
                Reference = row.First().Reference,
                SignType = row.Key.SignType.ToString(),
                AmountGross = row.Sum(t => (decimal?)t.AmountGross) ?? 0,
                IsMatched = row.Key.TransactionMatchStatus == TransactionMatchStatus.Matched || row.Key.TransactionMatchStatus == TransactionMatchStatus.AutoMatched
            }).ToList();
        }
    }

    public partial class CreditorAddress {
        [NotMapped]
        public string Address {
            get {
                return Utils.RemoveExtraSpaces(string.Concat(Address1, " ", Address2, " ", Locality, " ", Region, " ", PostCode, " ", CountryCode));
            }
        }
    }

    public partial class CreditorContact {
        [NotMapped]
        public string FullName {
            get {
                return string.Concat(Title, " ", Name).Trim();
            }
        }

        [NotMapped]
        public string FullNameWithEmail {
            get {
                return string.IsNullOrEmpty(Email) ? FullName : string.Concat(@"<a href=""mailto:", WebUtility.HtmlEncode(Email), @""">", FullName, "</a>");
            }
        }

        [NotMapped]
        public string PhoneNo {
            get {
                return string.IsNullOrEmpty(PhoneWork) ? string.IsNullOrEmpty(Mobile) ? PhoneHome : Mobile : PhoneWork;
            }
        }
    }

    public partial class Supplier {
        [NotMapped]
        public string Address {
            get {
                var supplierAddress = SupplierAddresses.Select(t => t).OrderByDescending(t => t.IsDefault).FirstOrDefault();

                if (supplierAddress == null)
                    return string.Empty;

                string address = string.Empty;

                if (!string.IsNullOrEmpty(supplierAddress.Address1))
                    address += string.Format("{0}{1}", supplierAddress.Address1, AppConstants.HtmlLineBreak);

                if (!string.IsNullOrEmpty(supplierAddress.Address2))
                    address += string.Format("{0}{1}", supplierAddress.Address2, AppConstants.HtmlLineBreak);

                address += Utils.RemoveExtraSpaces(string.Concat(supplierAddress.Locality, " ", supplierAddress.Region, " ", supplierAddress.PostCode, " ", supplierAddress.CountryCode));
                address = address.TrimEnd(AppConstants.HtmlLineBreak);

                return address;
            }
        }

        [NotMapped]
        public string PhoneNo {
            get {
                var supplierContact = SupplierContacts.Select(t => t).OrderByDescending(t => t.IsDefault).FirstOrDefault();

                if (supplierContact == null)
                    return string.Empty;

                return supplierContact.PhoneNo;
            }
        }

        [NotMapped]
        public string Email {
            get {
                var supplierContact = SupplierContacts.Select(t => t).OrderByDescending(t => t.IsDefault).FirstOrDefault();

                if (supplierContact == null)
                    return string.Empty;

                return supplierContact.Email;
            }
        }

        public static Supplier GetBspAgent(AppLazyContext lazyContext, int customerId, TripLineType tripLineType = TripLineType.All) {
            Creditor creditor = null;

            if (AppSettings.Setting(customerId).BspCreditorId > 0) {
                creditor = lazyContext.Creditor.Find(AppSettings.Setting(customerId).BspCreditorId);

                if (creditor.SupplierCreditors.Count > 0)
                    return creditor.SupplierCreditors.OrderByDescending(t => t.IsDefault).First().Supplier;
            }

            var creditors = lazyContext.Creditor.Where(t => t.IsBspAgent);

            if (tripLineType != TripLineType.All)
                creditors = creditors.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.Supplier.SupplierServiceTypes.Any(t3 => t3.ServiceType.TripLineType == tripLineType)));

            creditor = creditors.FirstOrDefault();

            return creditor == null || creditor.SupplierCreditors.Count == 0
                ? lazyContext.Supplier.Find(-1)
                : creditor.SupplierCreditors.OrderByDescending(t => t.IsDefault).First().Supplier;
        }

        public static Supplier GetSupplier(AppLazyContext lazyContext, string name) {
            var supplier = lazyContext.Supplier.SingleOrDefault(t => t.Name.ToLower() == (name ?? string.Empty).ToLower());

            if (supplier == null)
                return lazyContext.Supplier.Single(t => t.Id == -1);

            return supplier;
        }

        public static Supplier GetSupplier(AppLazyContext lazyContext, Crs crs, string crsCode, string name) {
            var supplierCrs = lazyContext.SupplierCrs.Where(t => (t.Crs == Crs.NotSpecified || t.Crs == crs) && t.CrsCode.ToLower() == (crsCode ?? string.Empty).ToLower()).ToList();

            if (supplierCrs.Count == 1)
                return supplierCrs[0].Supplier;

            return GetSupplier(lazyContext, name);
        }

        public static IQueryable<Supplier> GetSupplierQuery(AppLazyContext lazyContext, TripLineType tripLineType, BspAgentType bspAgentType, int creditorId, string cityCode, string text, int? id) {
            var q = lazyContext.Supplier.Where(t => t.Id > 0);

            if (tripLineType == TripLineType.OtherLand) {
                q = q.Where(t1 => t1.SupplierServiceTypes.Any(t2 => t2.ServiceType.TripLineType == TripLineType.Accommodation || t2.ServiceType.TripLineType == TripLineType.Transport || t2.ServiceType.TripLineType == TripLineType.Cruise || t2.ServiceType.TripLineType == TripLineType.Tour || t2.ServiceType.TripLineType == TripLineType.OtherLand));
            }
            else if (tripLineType != TripLineType.All) {
                q = q.Where(t1 => t1.SupplierServiceTypes.Any(t2 => t2.ServiceType.TripLineType == tripLineType));
            }

            switch (bspAgentType) {
                case BspAgentType.Bsp:
                    q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.Creditor.IsBspAgent));
                    break;
                case BspAgentType.NonBsp:
                    q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.Creditor.IsNonBspAgent));
                    break;
                case BspAgentType.BspOrNonBsp:
                    q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.Creditor.IsBspAgent || t2.Creditor.IsNonBspAgent));
                    break;
                case BspAgentType.NeitherBspNorNonBsp:
                    q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => !t2.Creditor.IsBspAgent && !t2.Creditor.IsNonBspAgent));
                    break;
            }

            if (creditorId > 0)
                q = q.Where(t1 => t1.SupplierCreditors.Any(t2 => t2.CreditorId == creditorId));

            if (!string.IsNullOrEmpty(cityCode))
                q = q.Where(t => t.City.Code.ToLower().Contains(cityCode.ToLower()));

            if (!string.IsNullOrEmpty(text))
                q = q.Where(t => t.Name.ToLower().Contains(text.ToLower()));

            if (id != null)
                q = q.Where(t => t.Id == id);

            return q.OrderBy(t => t.Name);
        }
    }

    public partial class SupplierAddress {
        [NotMapped]
        public string Address {
            get {
                return Utils.RemoveExtraSpaces(string.Concat(Address1, " ", Address2, " ", Locality, " ", Region, " ", PostCode, " ", CountryCode));
            }
        }
    }

    public partial class SupplierContact {
        [NotMapped]
        public string FullName {
            get {
                return string.Concat(Title, " ", Name).Trim();
            }
        }

        [NotMapped]
        public string FullNameWithEmail {
            get {
                return string.IsNullOrEmpty(Email) ? Supplier.Name : string.Concat(@"<a href=""mailto:", WebUtility.HtmlEncode(Email), @""">", Supplier.Name, "</a>");
            }
        }

        [NotMapped]
        public string PhoneNo {
            get {
                return string.IsNullOrEmpty(PhoneWork) ? string.IsNullOrEmpty(Mobile) ? PhoneHome : Mobile : PhoneWork;
            }
        }
    }

    public partial class SupplierChain {
        public static SupplierChain GetSupplierChain(AppLazyContext lazyContext, Crs crs, string crsCode, string iataCode = null) {
            var supplierChainCrs = lazyContext.SupplierChainCrs.Where(t => (t.Crs == Crs.NotSpecified || t.Crs == crs) && t.CrsCode.ToLower() == (crsCode ?? string.Empty).ToLower()).ToList();

            if (supplierChainCrs.Count == 1)
                return supplierChainCrs[0].SupplierChain;

            SupplierChain supplierChain = null;

            if (iataCode != null)
                supplierChain = lazyContext.SupplierChain.FirstOrDefault(t => t.Id > 0 && t.IataCode.ToLower() == iataCode.ToLower());

            if (supplierChain == null)
                supplierChain = Supplier.GetSupplier(lazyContext, crs, crsCode, null).SupplierChain;

            return supplierChain ?? lazyContext.SupplierChain.Find(-1);
        }
    }

    public partial class SupplierServiceRateDetail {
        public decimal GetCommission(TripLineLand tripLineLand) {
            if (tripLineLand == null)
                return 0;

            return tripLineLand.CommissionableValue - tripLineLand.Cost;
        }

        public decimal GetCommissionRate(TripLineLand tripLineLand) {
            if (tripLineLand == null)
                return 0;

            return tripLineLand.CommissionableValue == 0 ? 0 : GetCommission(tripLineLand) / tripLineLand.CommissionableValue;
        }
    }

    public class CreditorLedger {
        public Creditor Creditor { get; set; }
        public DateTime AgingCurrentDate { get; set; }
        public DateTime AgingPeriod1Date { get; set; }
        public DateTime AgingPeriod2Date { get; set; }
        public DateTime AgingPeriod3Date { get; set; }
        public decimal BalanceCurrent { get; set; }
        public decimal BalancePeriod1 { get; set; }
        public decimal BalancePeriod2 { get; set; }
        public decimal BalancePeriod3 { get; set; }
        public decimal Balance { get; set; }

        public IQueryable<TransactionDetail> TransactionDetail { get; set; }
        public List<TransactionDetail> BspAccrualTransactionDetail { get; set; }

        public CreditorLedger(IQueryable<TransactionDetail> transactionDetail, AgingCycle agingCycle, DayOfWeekExt agingCycleStartDay, LedgerDocumentType documentType, DateTime referenceDate, List<CreditorTotalsModel> totals = null) {
            if (documentType == LedgerDocumentType.Reconciliation || documentType == LedgerDocumentType.ReconciliationDetail) {
                DateTime documentDate = referenceDate;

                if (totals != null)
                    BspAccrualTransactionDetail = transactionDetail.AsEnumerable().Where(t => t.Transaction.DocumentDate <= documentDate).ToList();

                transactionDetail = transactionDetail.Where(t => t.Transaction.DocumentDate <= documentDate);
            }
            else if (totals != null) {
                BspAccrualTransactionDetail = transactionDetail.ToList();
            }

            if (totals == null) {
                totals = transactionDetail.Select(row => new CreditorTotalsModel {
                    CreditorId = row.CreditorId,
                    AgingDate = row.Transaction.DocumentDate,
                    AmountGross = row.Amount + row.Tax
                }).ToList();
            }

            TransactionDetail = transactionDetail;

            if (agingCycle == AgingCycle.ThirtyDay) {
                referenceDate = new DateTime(referenceDate.Year, referenceDate.Month, 1);
            }
            else {
                referenceDate = referenceDate.StartOfWeek(agingCycleStartDay);
            }

            AgingCurrentDate = referenceDate;
            AgingPeriod1Date = agingCycle == AgingCycle.SevenDay ? referenceDate.AddDays(-7) : agingCycle == AgingCycle.FourteenDay ? referenceDate.AddDays(-14) : referenceDate.AddMonths(-1);
            AgingPeriod2Date = agingCycle == AgingCycle.SevenDay ? referenceDate.AddDays(-14) : agingCycle == AgingCycle.FourteenDay ? referenceDate.AddDays(-28) : referenceDate.AddMonths(-2);
            AgingPeriod3Date = agingCycle == AgingCycle.SevenDay ? referenceDate.AddDays(-21) : agingCycle == AgingCycle.FourteenDay ? referenceDate.AddDays(-42) : referenceDate.AddMonths(-3);

            BalancePeriod1 = totals.Where(t => t.AgingDate < AgingCurrentDate && t.AgingDate >= AgingPeriod1Date).Sum(t => (decimal?)t.AmountGross) ?? 0;
            BalancePeriod2 = totals.Where(t => t.AgingDate < AgingPeriod1Date && t.AgingDate >= AgingPeriod2Date).Sum(t => (decimal?)t.AmountGross) ?? 0;
            BalancePeriod3 = totals.Where(t => t.AgingDate < AgingPeriod2Date).Sum(t => (decimal?)t.AmountGross) ?? 0;
            BalanceCurrent = totals.Where(t => t.AgingDate >= AgingCurrentDate).Sum(t => (decimal?)t.AmountGross) ?? 0;
            Balance = BalanceCurrent + BalancePeriod1 + BalancePeriod2 + BalancePeriod3;
        }
    }

    public class CreditorLedgerTransaction {
        public long TransactionDetailAllocationId { get; set; }
        public int TransactionId { get; set; }
        public long TransactionDetailId { get; set; }
        public int TransactionRefId { get; set; }
        public int TransactionDetailRefId { get; set; }
        public int ReceiptDetailId { get; set; }
        public int NonBspDetailId { get; set; }
        public int PaymentDetailId { get; set; }
        public int JournalDetailId { get; set; }
        public int AdjustmentId { get; set; }
        public TransactionType TransactionType { get; set; }
        public SignType SignType { get; set; }
        public string DocumentNo { get; set; }
        public DateTime DocumentDate { get; set; }
        public string Description { get; set; }
        public string Reference { get; set; }
        public int GroupNo { get; set; }
        public decimal Amount { get; set; }
        public decimal AmountGross { get; set; }
        public TransactionMatchStatus TransactionMatchStatus { get; set; }
        public decimal Debit { get { return SignType == SignType.Debit ? AmountGross : 0; } }
        public decimal Credit { get { return SignType == SignType.Credit ? AmountGross : 0; } }

        public string DocumentNoLink {
            get {
                return Transaction.GetDocumentNoLink("TransactionDetailAllocation", TransactionType, TransactionRefId, DocumentNo);
            }
        }
    }
}