﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Travelog.Biz.Dao.GeneralLedger;
using Travelog.Biz.Enums;

namespace Travelog.Biz.Dao.StaticMethods {
	public static class GeneralLedgerSettings {
		private static List<GeneralLedgerSettingDetail> fiscalPeriodList = new List<GeneralLedgerSettingDetail>();
		private static List<GeneralLedgerSettingDetail> fiscalYearList = new List<GeneralLedgerSettingDetail>();

		public static List<GeneralLedgerSettingDetail> GetFiscalPeriodList(int customerId) {
			if (fiscalPeriodList.Any(t => t.CustomerId == customerId))
				return fiscalPeriodList.Where(t => t.CustomerId == customerId).ToList();

			using (var context = new AppMainContext(customerId, true)) {
				return GetFiscalPeriodList(context, customerId, false);
			}
		}

		public static List<GeneralLedgerSettingDetail> GetFiscalPeriodList(AppMainContext context, int customerId, bool useCache = true) {
			if (useCache && fiscalPeriodList.Any(t => t.CustomerId == customerId))
				return fiscalPeriodList.Where(t => t.CustomerId == customerId).ToList();

			var settings = context.Setting
				.Include(t => t.ClientControlAccount).Include(t => t.DebtorControlAccount).Include(t => t.CreditorControlAccount).Include(t => t.BspAccrualAccount).Include(t => t.SupplierReturnsAccount)
				.Include(t => t.CreditCardChargeAccount).Include(t => t.CommissionAccount).Include(t => t.OverrideCommissionAccount).Include(t => t.OtherCommissionAccount).Include(t => t.SalesTaxAccount).Include(t => t.PurchasesTaxAccount)
				.Where(t => t.Id > 0).OrderBy(t => t.FiscalYearStartDate).ToList();

			var q = new List<GeneralLedgerSettingDetail>();
			int i = -1;

			foreach (var setting in settings) {
				i++;

				var settingDetails = context.SettingDetail.Where(t => t.SettingId == setting.Id).OrderByDescending(t => t.FiscalPeriodEndDate).ToList();
				int j = -1;

				foreach (var settingDetail in settingDetails) {
					j++;

					q.Add(new GeneralLedgerSettingDetail {
						CustomerId = customerId,
						SettingId = setting.Id,
						SettingDetailId = settingDetail.Id,
						GeneralLedgerDivision = setting.GeneralLedgerDivision,
						ClientControlAccount = setting.ClientControlAccount,
						DebtorControlAccount = setting.DebtorControlAccount,
						CreditorControlAccount = setting.CreditorControlAccount,
						BspAccrualAccount = setting.BspAccrualAccount,
						SupplierReturnsAccount = setting.SupplierReturnsAccount,
						CreditCardChargeAccount = setting.CreditCardChargeAccount,
						CommissionAccount = setting.CommissionAccount,
						OverrideCommissionAccount = setting.OverrideCommissionAccount,
						OtherCommissionAccount = setting.OtherCommissionAccount,
						SalesTaxAccount = setting.SalesTaxAccount,
						PurchasesTaxAccount = setting.PurchasesTaxAccount,
						FiscalYearStartDate = setting.FiscalYearStartDate,
						FiscalYearEndDate = i < settings.Count - 1 ? settings[i + 1].FiscalYearStartDate.AddDays(-1) : settingDetail.FiscalPeriodEndDate,
						FiscalPeriodStartDate = j < settingDetails.Count - 1 ? settingDetails[j + 1].FiscalPeriodEndDate.AddDays(1) : setting.FiscalYearStartDate,
						FiscalPeriodEndDate = settingDetail.FiscalPeriodEndDate,
						FiscalYearStartDateName = setting.FiscalYearStartDateName,
						FiscalPeriodEndDateName = settingDetail.FiscalPeriodEndDateName,
						IsAdminClosed = settingDetail.IsAdminClosed,
						IsUserClosed = settingDetail.IsUserClosed
					});
				}
			}

			q = q.OrderByDescending(t => t.FiscalYearStartDate).ToList();

			foreach (var row in q) {
				DateTime dateApplicable = row.FiscalYearStartDate.AddYears(-1);
				var ytdPreviousYear = q.Find(t => t.FiscalYearStartDate <= dateApplicable && t.FiscalYearEndDate >= dateApplicable);

				dateApplicable = row.FiscalPeriodEndDate.AddYears(-1);
				var periodPreviousYear = q.Find(t => t.FiscalPeriodStartDate <= dateApplicable && t.FiscalPeriodEndDate >= dateApplicable);

				row.FiscalYearPreviousStartDate = ytdPreviousYear?.FiscalYearStartDate ?? DateTime.MinValue;
				row.FiscalYearPreviousEndDate = ytdPreviousYear?.FiscalYearEndDate ?? DateTime.MinValue;

				row.FiscalPeriodPreviousStartDate = periodPreviousYear?.FiscalPeriodStartDate ?? DateTime.MinValue;
				row.FiscalPeriodPreviousEndDate = periodPreviousYear?.FiscalPeriodEndDate ?? DateTime.MinValue;

				row.FiscalYearPreviousStartDateName = ytdPreviousYear?.FiscalYearStartDateName ?? string.Empty;
				row.FiscalPeriodPreviousEndDateName = periodPreviousYear?.FiscalPeriodEndDateName ?? string.Empty;
			}

			if (useCache)
				fiscalPeriodList = q;

			return q;
		}

		public static List<GeneralLedgerSettingDetail> GetFiscalYearList(int customerId) {
			if (fiscalYearList.Any(t => t.CustomerId == customerId))
				return fiscalYearList.Where(t => t.CustomerId == customerId).ToList();

			using (var context = new AppMainContext(customerId, true)) {
				return GetFiscalYearList(context, customerId);
			}
		}

		private static List<GeneralLedgerSettingDetail> GetFiscalYearList(AppMainContext context, int customerId) {
			var q = new List<GeneralLedgerSettingDetail>();

			foreach (var row in GetFiscalPeriodList(context, customerId, false).OrderByDescending(t => t.FiscalYearStartDate)) {
				if (q.Any(t => t.CustomerId == row.CustomerId && t.SettingId == row.SettingId))
					continue;

				q.Add(new GeneralLedgerSettingDetail {
					CustomerId = row.CustomerId,
					SettingId = row.SettingId,
					GeneralLedgerDivision = row.GeneralLedgerDivision,
					ClientControlAccount = row.ClientControlAccount,
					DebtorControlAccount = row.DebtorControlAccount,
					CreditorControlAccount = row.CreditorControlAccount,
					BspAccrualAccount = row.BspAccrualAccount,
					SupplierReturnsAccount = row.SupplierReturnsAccount,
					CreditCardChargeAccount = row.CreditCardChargeAccount,
					CommissionAccount = row.CommissionAccount,
					OverrideCommissionAccount = row.OverrideCommissionAccount,
					OtherCommissionAccount = row.OtherCommissionAccount,
					SalesTaxAccount = row.SalesTaxAccount,
					PurchasesTaxAccount = row.PurchasesTaxAccount,
					FiscalYearStartDate = row.FiscalYearStartDate,
					FiscalYearEndDate = row.FiscalPeriodEndDate,
					FiscalYearStartDateName = row.FiscalYearStartDateName
				});
			}

			return q;
		}

		public static IQueryable<GeneralLedgerSettingDetail> GetFiscalPeriodList(AppMainContext context) {
			return context.GeneralLedgerSettingDetailView.Select(row => new GeneralLedgerSettingDetail {
				CustomerId = 0,
				SettingId = row.SettingId,
				SettingDetailId = row.SettingDetailId,
				GeneralLedgerDivision = row.GeneralLedgerDivision,
				ClientControlAccount = row.ClientControlAccount,
				DebtorControlAccount = row.DebtorControlAccount,
				CreditorControlAccount = row.CreditorControlAccount,
				BspAccrualAccount = row.BspAccrualAccount,
				SupplierReturnsAccount = row.SupplierReturnsAccount,
				CreditCardChargeAccount = row.CreditCardChargeAccount,
				CommissionAccount = row.CommissionAccount,
				OverrideCommissionAccount = row.OverrideCommissionAccount,
				OtherCommissionAccount = row.OtherCommissionAccount,
				SalesTaxAccount = row.SalesTaxAccount,
				PurchasesTaxAccount = row.PurchasesTaxAccount,
				FiscalYearStartDate = row.FiscalYearStartDate,
				FiscalYearEndDate = row.FiscalYearEndDate,
				FiscalPeriodStartDate = row.FiscalPeriodStartDate,
				FiscalPeriodEndDate = row.FiscalPeriodEndDate,
				FiscalYearPreviousStartDate = row.FiscalYearPreviousStartDate,
				FiscalYearPreviousEndDate = row.FiscalYearPreviousEndDate,
				FiscalPeriodPreviousStartDate = row.FiscalPeriodPreviousStartDate,
				FiscalPeriodPreviousEndDate = row.FiscalPeriodPreviousEndDate,
				FiscalYearStartDateName = row.FiscalYearStartDateName,
				FiscalPeriodEndDateName = row.FiscalPeriodEndDateName,
				FiscalYearPreviousStartDateName = row.FiscalYearPreviousStartDateName,
				FiscalPeriodPreviousEndDateName = row.FiscalPeriodPreviousEndDateName,
				IsAdminClosed = row.IsAdminClosed,
				IsUserClosed = row.IsUserClosed
			});
		}

		public static List<GeneralLedgerSettingError> GetGeneralLedgerSettingErrorsList(AppMainContext context, int customerId) {
			var errorsList = new List<GeneralLedgerSettingError>();

			var q = GetFiscalYearList(context, customerId).OrderBy(t => t.FiscalYearStartDate).ToList();
			int i = -1;

			foreach (var row in q) {
				i++;

				if (i > 0 && row.FiscalYearStartDate != q[i - 1].FiscalYearEndDate.AddDays(1)) {
					errorsList.Add(new GeneralLedgerSettingError {
						SettingId = row.SettingId,
						PreviousFiscalYearEndDate = q[i - 1].FiscalYearEndDate,
						CurrentFiscalYearStartDate = row.FiscalYearStartDate
					});
				}
			}

			return errorsList;
		}

		public static void ClearFiscalPeriodLists(int customerId) {
			fiscalPeriodList = fiscalPeriodList.Where(t => t.CustomerId != customerId).ToList();
			fiscalYearList = fiscalYearList.Where(t => t.CustomerId != customerId).ToList();
		}
	}

	public class GeneralLedgerSettingDetail {
		public int CustomerId { get; set; }
		public int SettingId { get; set; }
		public int SettingDetailId { get; set; }
		public GeneralLedgerDivision GeneralLedgerDivision { get; set; }
		public ChartOfAccount ClientControlAccount { get; set; }
		public ChartOfAccount DebtorControlAccount { get; set; }
		public ChartOfAccount CreditorControlAccount { get; set; }
		public ChartOfAccount BspAccrualAccount { get; set; }
		public ChartOfAccount SupplierReturnsAccount { get; set; }
		public ChartOfAccount CreditCardChargeAccount { get; set; }
		public ChartOfAccount CommissionAccount { get; set; }
		public ChartOfAccount OverrideCommissionAccount { get; set; }
		public ChartOfAccount OtherCommissionAccount { get; set; }
		public ChartOfAccount SalesTaxAccount { get; set; }
		public ChartOfAccount PurchasesTaxAccount { get; set; }
		public DateTime FiscalYearStartDate { get; set; }
		public DateTime FiscalYearEndDate { get; set; }
		public DateTime FiscalPeriodStartDate { get; set; }
		public DateTime FiscalPeriodEndDate { get; set; }
		public string FiscalYearStartDateName { get; set; }
		public string FiscalPeriodEndDateName { get; set; }
		public DateTime FiscalYearPreviousStartDate { get; set; }
		public DateTime FiscalYearPreviousEndDate { get; set; }
		public DateTime FiscalPeriodPreviousStartDate { get; set; }
		public DateTime FiscalPeriodPreviousEndDate { get; set; }
		public string FiscalYearPreviousStartDateName { get; set; }
		public string FiscalPeriodPreviousEndDateName { get; set; }
		public bool IsAdminClosed { get; set; }
		public bool IsUserClosed { get; set; }
	}

	public class GeneralLedgerSettingError {
		public int SettingId { get; set; }
		public DateTime PreviousFiscalYearEndDate { get; set; }
		public DateTime CurrentFiscalYearStartDate { get; set; }
	}
}