using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Net;
using Travelog.Biz.Enums;

namespace Travelog.Biz.Dao.Admin {
    public partial class AspNetUsers {
		[NotMapped]
		public string FullNameWithEmail {
			get {
				return string.IsNullOrEmpty(Email) ? FullName : string.Concat(@"<a href=""mailto:", WebUtility.HtmlEncode(Email), @""">", FullName, "</a>");
			}
		}

		[NotMapped]
		public bool IsLocked {
			get {
				return LockoutEnd > DateTime.UtcNow;
			}
			set {
				LockoutEnd = value ? DateTime.MaxValue : (DateTime?)null;
			}
		}

        public AspNetUserRoles GetRole(int customerId = 0) {
            if (customerId == 0)
                customerId = CurrentCustomerId;

            return AspNetUserRoles.SingleOrDefault(t => t.CustomerId == customerId) ?? new AspNetUserRoles {
                UserId = Id,
                CustomerId = customerId,
                RoleId = UserRole.ReadOnly.Id,
                ConsultantId = -1,
                DefaultAgencyId = -1,
                Inactive = false,
                AspNetUsers = new AspNetUsers { Id = Id },
                AspNetRoles = new AspNetRoles { Id = UserRole.ReadOnly.Id, Name = UserRole.ReadOnly.Name }
            };
        }

        public List<AspNetUserRoles> GetRoles(AppAdminContext adminContext) {
			return adminContext.AspNetUserRoles.Where(t => t.UserId == Id).ToList();
		}

		public bool IsInRole(AppAdminContext adminContext, string roleId, int customerId) {
			return adminContext.AspNetUserRoles.Any(t => t.UserId == Id && t.RoleId == roleId && t.CustomerId == customerId);
		}
	}

	public partial class Customer {
		[NotMapped]
		public CustomerType CustomerType {
			get {
				return Id == -21 ? CustomerType.TravelogDev
					: Id == -22 ? CustomerType.TravelogDevTest1
					: Id == -23 ? CustomerType.TravelogDevTest2
					: Id == -24 ? CustomerType.TravelogDevTest3
					: Id == -25 ? CustomerType.TravelogDevTest4
					: Id == -26 ? CustomerType.TravelogDevTest5
					: Id == -27 ? CustomerType.TravelogDevTest6
					: Id == -28 ? CustomerType.TravelogDevTest7
					: Id == -29 ? CustomerType.TravelogDevTest8
					: Id == -30 ? CustomerType.TravelogDevTest9
					: Id == -11 ? CustomerType.TravelogStaging
					: Id == -12 ? CustomerType.TravelogStagingTest1
					: Id == -13 ? CustomerType.TravelogStagingTest2
					: Id == -14 ? CustomerType.TravelogStagingTest3
					: Id == -15 ? CustomerType.TravelogStagingTest4
					: Id == -16 ? CustomerType.TravelogStagingTest5
					: Id == -17 ? CustomerType.TravelogStagingTest6
					: Id == -18 ? CustomerType.TravelogStagingTest7
					: Id == -19 ? CustomerType.TravelogStagingTest8
					: Id == -20 ? CustomerType.TravelogStagingTest9
					: Id == 1 ? CustomerType.TravelogProd
					: CustomerType.Customer;
			}
		}

        [NotMapped]
        public int ManagementCustomerId {
			get {
				string customerType = CustomerType.ToString();
                return customerType.StartsWith("TravelogDev") ? (int)CustomerType.TravelogDev : customerType.StartsWith("TravelogStaging") ? (int)CustomerType.TravelogStaging : (int)CustomerType.TravelogProd;
            }
        }

		[NotMapped]
        public bool IsManagementCustomer => CustomerType == CustomerType.TravelogProd || CustomerType == CustomerType.TravelogStaging || CustomerType == CustomerType.TravelogDev;

        [NotMapped]
		public string Address {
			get {
				string address = string.Empty;

				if (!string.IsNullOrEmpty(Address1))
					address += string.Format("{0}{1}", Address1, AppConstants.HtmlLineBreak);

				if (!string.IsNullOrEmpty(Address2))
					address += string.Format("{0}{1}", Address2, AppConstants.HtmlLineBreak);

				address += Utils.RemoveExtraSpaces(string.Concat(Locality, " ", Region, " ", PostCode, " ", CountryCode));
				return address.TrimEnd(AppConstants.HtmlLineBreak);
			}
		}

		[NotMapped]
		public bool CanConnectAsExternalUser {
			get {
				return Id <= 0 || AllowRemoteAssistance || !AspNetUserRoles.Any(t => t.AspNetRoles.Id == UserRole.CompanyAdministrator.Id) || AspNetUsers.Any(t => t.LockoutEnd > DateTime.UtcNow);
			}
		}

		public bool IsAccountActive(DateTime? billingDate = null) {
			var q = CustomerTransactions.Where(t => t.Id > 0 && (t.CustomerTransactionType == CustomerTransactionType.AccountDeactivated || t.CustomerTransactionType == CustomerTransactionType.AccountReactivated))
				.OrderByDescending(t => t.CreationTime)
				.Select(row => new {
					row.CustomerTransactionType,
					row.DateTo
				});

			if (billingDate != null)
				q = q.Where(t => t.DateTo <= billingDate);

			return q.Select(t => t.CustomerTransactionType).FirstOrDefault() != CustomerTransactionType.AccountDeactivated;
		}

		public bool IsAccountSuspended(DateTime? billingDate = null) {
			var q = CustomerTransactions.Where(t => t.Id > 0 && (t.CustomerTransactionType == CustomerTransactionType.AccountSuspended || t.CustomerTransactionType == CustomerTransactionType.SuspensionLifted))
				.OrderByDescending(row => row.CreationTime)
				.Select(t => new {
					t.CustomerTransactionType,
					t.DateTo
				});

			if (billingDate != null)
				q = q.Where(t => t.DateTo <= billingDate);

			return q.Select(t => t.CustomerTransactionType).FirstOrDefault() == CustomerTransactionType.AccountSuspended;
		}

        public static Dictionary<CustomerAgingCycle, decimal> GetAccountBalances(AppAdminContext adminContext, int customerId) {
			var accountBalances = new Dictionary<CustomerAgingCycle, decimal>();

            var q = adminContext.CustomerTransactionView.Where(t => t.CustomerId == customerId && t.CustomerTransactionType != CustomerTransactionType.AccountDeactivated && t.CustomerTransactionType != CustomerTransactionType.AccountReactivated && t.CustomerTransactionType != CustomerTransactionType.AccountSuspended && t.CustomerTransactionType != CustomerTransactionType.SuspensionLifted).OrderByDescending(t => t.Id).AsEnumerable().Where(t => t.IsReceiptItem || t.CustomerTransactionApprovalStatus != CustomerTransactionApprovalStatus.NotApproved);
            decimal amount = q.FirstOrDefault()?.Balance ?? 0;

			accountBalances.Add(CustomerAgingCycle.None, amount);

            amount = (q.Where(t => !t.IsReceiptItem && t.DateDue < DateTime.Today.AddDays(-AppSettings.CustomerPaymentTermsDays)).Sum(t => (decimal?)(-t.Debit + t.Credit)) ?? 0)
                - (q.Where(t => t.IsReceiptItem).Sum(t => (decimal?)(-t.Debit + t.Credit)) ?? 0);

            accountBalances.Add(CustomerAgingCycle.Overdue, amount > 0 ? 0 : amount);

            amount = (q.Where(t => !t.IsReceiptItem && t.DateDue < DateTime.Today.AddDays(-AppSettings.CustomerPastDueDays)).Sum(t => (decimal?)(-t.Debit + t.Credit)) ?? 0)
                - (q.Where(t => t.IsReceiptItem).Sum(t => (decimal?)(-t.Debit + t.Credit)) ?? 0);

            accountBalances.Add(CustomerAgingCycle.PayableNow, amount > 0 ? 0 : amount);

            return accountBalances;
        }

		public static CustomerAccountStatus GetCustomerAccountStatus(decimal overdueAccountBalance, decimal payableNowAccountBalance) {
			return payableNowAccountBalance < -AppSettings.BalancePayableLimit ? CustomerAccountStatus.Locked : overdueAccountBalance < -AppSettings.BalancePayableLimit ? CustomerAccountStatus.Overdue : CustomerAccountStatus.Current;
		}

        public DateTime GetBillingStartDate(ref bool concurrentUserChangeApplies) {
            var q = CustomerTransactions.Where(t => t.CustomerTransactionType == CustomerTransactionType.Subscription).OrderByDescending(t => t.DateTo).FirstOrDefault();

            if (q == null) {
                concurrentUserChangeApplies = false;
                return StartDate;
            }
            else {
                concurrentUserChangeApplies = CustomerTransactions.Any(t => t.CustomerTransactionType == CustomerTransactionType.ConcurrentUserChange && t.CustomerTransactionStatus == CustomerTransactionStatus.Open);
                return q.DateTo.AddDays(1);
            }
        }

        public static CustomerPricing GetCustomerPricing(AppAdminContext adminContext, int customerId, int userCount, DateTime dateFrom, DateTime dateTo) {
			var q = adminContext.CustomerPricing.Where(t => t.CustomerId == customerId).OrderByDescending(t => t.DateFrom).FirstOrDefault(t => t.DateFrom <= dateFrom && t.DateTo >= dateTo && t.UserCount == userCount)
				?? adminContext.CustomerPricing.Where(t => t.CustomerId == customerId).OrderByDescending(t => t.DateFrom).FirstOrDefault(t => t.DateFrom <= dateFrom && t.DateTo >= dateTo);

			return q ?? new CustomerPricing {
                CustomerId = customerId,
                DateFrom = dateFrom,
                DateTo = dateTo,
                BillingCycle = BillingCycle.Monthly,
                UserCount = userCount,
                UserCharge = Pricing.GetUserCharge(adminContext, userCount)
            };
        }

        public string GetBusinessName() {
            return BusinessName.Length == 0 ? LegalName : BusinessName;
        }

        public static bool GetIsManagementCustomer(int customerId) {
            return customerId == (int)CustomerType.TravelogDev || customerId == (int)CustomerType.TravelogStaging || customerId == (int)CustomerType.TravelogProd;
        }
    }

    public partial class CustomerTransaction {
        [NotMapped]
        public bool IsReceiptItem {
            get {
                return CustomerTransactionType == CustomerTransactionType.OnlinePayment
                    || CustomerTransactionType == CustomerTransactionType.PaypalPayment
                    || CustomerTransactionType == CustomerTransactionType.DirectDeposit
                    || CustomerTransactionType == CustomerTransactionType.Payment
                    || CustomerTransactionType == CustomerTransactionType.MailPhonePayment
                    || CustomerTransactionType == CustomerTransactionType.RecurringPayment;
            }
        }

        [NotMapped]
        public bool IsInvoiceItem {
            get {
                return CustomerTransactionType == CustomerTransactionType.Subscription
                    || CustomerTransactionType == CustomerTransactionType.Refund
                    || CustomerTransactionType == CustomerTransactionType.Invoice
                    || CustomerTransactionType == CustomerTransactionType.CreditNote;
            }
        }

        [NotMapped]
		public bool IsPaymentGatewayTxn {
			get {
				return CustomerTransactionType == CustomerTransactionType.OnlinePayment
					|| CustomerTransactionType == CustomerTransactionType.Payment
					|| CustomerTransactionType == CustomerTransactionType.Refund;
			}
		}

		[NotMapped]
		public bool IsSystemOwned {
			get {
				return CustomerTransactionType == CustomerTransactionType.RecurringPayment
					|| CustomerTransactionType == CustomerTransactionType.ConcurrentUserChange;
			}
		}

        [NotMapped]
        public BillingCycle BillingCycle {
			get {
				int months = ((DateTo.Year - DateFrom.Year) * 12) + DateTo.Month - DateFrom.Month;
				return months > 3 ? BillingCycle.Annual : months > 1 ? BillingCycle.Quarterly : BillingCycle.Monthly;
			}
        }

		[NotMapped]
		public int BillingMonths {
			get {
				return BillingCycle == BillingCycle.Quarterly ? 3 : BillingCycle == BillingCycle.Annual ? 12 : 1;
			}
		}
	}

	public partial class CustomerTransactionView {
        [NotMapped]
        public bool IsReceiptItem {
            get {
                return CustomerTransactionType == CustomerTransactionType.OnlinePayment
                    || CustomerTransactionType == CustomerTransactionType.PaypalPayment
                    || CustomerTransactionType == CustomerTransactionType.DirectDeposit
                    || CustomerTransactionType == CustomerTransactionType.Payment
                    || CustomerTransactionType == CustomerTransactionType.MailPhonePayment
                    || CustomerTransactionType == CustomerTransactionType.RecurringPayment;
            }
        }

        [NotMapped]
        public bool IsInvoiceItem {
            get {
                return CustomerTransactionType == CustomerTransactionType.Subscription
                    || CustomerTransactionType == CustomerTransactionType.Refund
                    || CustomerTransactionType == CustomerTransactionType.Invoice
                    || CustomerTransactionType == CustomerTransactionType.CreditNote;
            }
        }

        [NotMapped]
		public bool IsPaymentGatewayTxn {
			get {
				return CustomerTransactionType == CustomerTransactionType.OnlinePayment
					|| CustomerTransactionType == CustomerTransactionType.Payment
					|| CustomerTransactionType == CustomerTransactionType.Refund;
			}
		}

		[NotMapped]
		public bool IsSystemOwned {
			get {
				return CustomerTransactionType == CustomerTransactionType.RecurringPayment
					|| CustomerTransactionType == CustomerTransactionType.ConcurrentUserChange;
			}
		}
	}

	public partial class CustomerPricing {
		[NotMapped]
		public int BillingMonths {
			get {
				return BillingCycle == BillingCycle.Quarterly ? 3 : BillingCycle == BillingCycle.Annual ? 12 : 1;
			}
		}
    }

    public partial class Pricing {
		public static decimal GetUserCharge(AppAdminContext adminContext, int userCount) {
			return adminContext.Pricing.OrderByDescending(t => t.UserCount).FirstOrDefault(t => t.UserCount <= userCount)?.UserCharge ?? 0;
		}
	}
}