﻿using System;
using System.Collections.Generic;
using System.Linq;
using Travelog.Biz.Dao;
using Travelog.Biz.Dao.Admin;
using Travelog.Biz.Enums;

namespace Travelog.Biz {
    public static class CustomerSettings {
        private static readonly object padlock = new object();

        private static List<CustomerModel> Customers { get; } = new List<CustomerModel> { new CustomerModel { CustomerId = -1, LegalName = AppSettings.SystemAccountName } };

        private static void InitSettings(int customerId) {
            using (var adminContext = new AppAdminContext(false)) {
                var customer = adminContext.Customer.Find(customerId);
                InitSettings(adminContext, customer);
            }
        }

        public static void InitSettings(AppAdminContext adminContext, Customer customer) {
            lock (padlock) {
                var appCustomer = Customers.SingleOrDefault(t => t.CustomerId == customer.Id);

                if (appCustomer == null) {
                    appCustomer = new CustomerModel {
                        CustomerId = customer.Id
                    };

                    Customers.Add(appCustomer);
                }

                appCustomer.DbName = customer.DbName;
                appCustomer.LegalName = customer.LegalName;
                appCustomer.BusinessName = customer.BusinessName;
                appCustomer.Location = customer.Location;
                appCustomer.CountryCode = customer.CountryCode;
                appCustomer.CountryIsoCode = customer.CountryIsoCode;
                appCustomer.CurrencyCode = customer.CurrencyCode;
                appCustomer.TaxNo = customer.TaxNo;
                appCustomer.CustomerType = customer.CustomerType;
                appCustomer.AgencyType = customer.AgencyType;
                appCustomer.CustomerStatus = customer.CustomerStatus;

                appCustomer.StartDate = customer.StartDate;
                appCustomer.UserCount = customer.UserCount;

                var accountBalances = Customer.GetAccountBalances(adminContext, customer.Id);

                appCustomer.CurrentAccountBalance = accountBalances[CustomerAgingCycle.None];
                appCustomer.OverdueAccountBalance = accountBalances[CustomerAgingCycle.Overdue];
                appCustomer.PayableNowAccountBalance = accountBalances[CustomerAgingCycle.PayableNow];

                appCustomer.ExcludeFromBilling = customer.ExcludeFromBilling;
                appCustomer.IsCustomerAccountActive = customer.IsAccountActive();
                appCustomer.IsCustomerAccountSuspended = customer.IsAccountSuspended();

                appCustomer.TaxRates = adminContext.TaxRate.Select(row => new TaxRateModel {
                    Id = row.Id,
                    CountryCode = row.CountryCode,
                    DateEffective = row.DateEffective,
                    Rate = row.Rate
                }).ToList();

                EtgAccessToken = adminContext.AppSetting.Find("EtgAccessToken").Value;
                EtgRefreshToken = adminContext.AppSetting.Find("EtgRefreshToken").Value;
                EtgAccessTokenExpiration = DateTime.Parse(adminContext.AppSetting.Find("EtgAccessTokenExpiration").Value);
            }
        }

        public static CustomerModel Setting(int customerId) {
            if (customerId == 0)
                return new CustomerModel();

            var setting = Customers.SingleOrDefault(t => t.CustomerId == customerId);

            if (setting == null) {
                InitSettings(customerId);
                setting = Customers.SingleOrDefault(t => t.CustomerId == customerId) ?? new CustomerModel { CustomerId = -1, LegalName = AppSettings.SystemAccountName };
            }

            return setting;
        }

        public static string GetBusinessName(int customerId) {
            return Setting(customerId).BusinessName.Length == 0 ? Setting(customerId).LegalName : Setting(customerId).BusinessName;
        }

        public static decimal GetTaxRate(AppAdminContext adminContext, DateTime dateApplicable, string countryCode) {
            return adminContext.TaxRate.Where(t => t.CountryCode == countryCode).OrderByDescending(t => t.DateEffective).FirstOrDefault(t => t.DateEffective <= dateApplicable)?.Rate ?? 0;
        }

        public static decimal GetTaxRate(int customerId, DateTime dateApplicable) {
            return Setting(customerId).TaxRates.Where(t => t.CountryCode == AppSettings.Setting(customerId).CountryCode).OrderByDescending(t => t.DateEffective).FirstOrDefault(t => t.DateEffective <= dateApplicable)?.Rate ?? 0;
        }

        public static int GetValidatedCustomerId(int customerId) {
            if (customerId > (int)CustomerType.TravelogProd)
                return customerId;

            switch (AppSettings.DbConnectionMode) {
                case DbConnectionMode.Production:
                    if (!(customerId >= (int)CustomerType.TravelogProd))
                        customerId = (int)CustomerType.TravelogProd;

                    break;
                case DbConnectionMode.Staging:
                    if (!(customerId <= (int)CustomerType.TravelogStaging && customerId >= (int)CustomerType.TravelogStagingTest9))
                        customerId = (int)CustomerType.TravelogStaging;

                    break;
                case DbConnectionMode.Development:
                    if (!(customerId <= (int)CustomerType.TravelogDev && customerId >= (int)CustomerType.TravelogDevTest9))
                        customerId = (int)CustomerType.TravelogDev;

                    break;
            }

            return customerId;
        }

        public static CustomerAccountStatus GetCustomerAccountStatus(int customerId) {
            return Setting(customerId).ExcludeFromBilling ? CustomerAccountStatus.Current : Setting(customerId).PayableNowAccountBalance < -AppSettings.BalancePayableLimit ? CustomerAccountStatus.Locked : Setting(customerId).OverdueAccountBalance < -AppSettings.BalancePayableLimit ? CustomerAccountStatus.Overdue : CustomerAccountStatus.Current;
        }

        public static void Clear(int customerId) {
            var setting = Customers.SingleOrDefault(t => t.CustomerId == customerId);

            if (setting != null) {
                lock (padlock) {
                    Customers.Remove(setting);
                }
            }
        }

        public static string EtgAccessToken { get; set; }
        public static string EtgRefreshToken { get; set; }
        public static DateTime EtgAccessTokenExpiration { get; set; }
    }

    public class CustomerModel {
        public CustomerModel() {
            LegalName = string.Empty;
            BusinessName = string.Empty;
            Location = string.Empty;
            TaxNo = string.Empty;
            DbName = string.Empty;
        }

        public int CustomerId { get; set; }
        public string LegalName { get; set; }
        public string BusinessName { get; set; }
        public string Location { get; set; }
        public string TaxNo { get; set; }
        public string DbName { get; set; }
        public string CountryCode { get; set; }
        public string CountryIsoCode { get; set; }
        public string CurrencyCode { get; set; }
        public CustomerType CustomerType { get; set; }
        public AgencyType AgencyType { get; set; }
        public CustomerStatus CustomerStatus { get; set; }
        public DateTime StartDate { get; set; }
        public int UserCount { get; set; }
        public decimal CurrentAccountBalance { get; set; }
        public decimal OverdueAccountBalance { get; set; }
        public decimal PayableNowAccountBalance { get; set; }
        public bool ExcludeFromBilling { get; set; }
        public bool IsCustomerAccountActive { get; set; }
        public bool IsCustomerAccountSuspended { get; set; }
        public bool IsManagementCustomer => CustomerType == CustomerType.TravelogProd || CustomerType == CustomerType.TravelogStaging || CustomerType == CustomerType.TravelogDev;
        public string FullName => string.Format("{0} T/A {1}", LegalName, BusinessName).Trim().TrimEnd(" T/A");
        public List<TaxRateModel> TaxRates { get; set; }
    }

    public class TaxRateModel {
        public int Id { get; set; }
        public string CountryCode { get; set; }
        public DateTime DateEffective { get; set; }
        public decimal Rate { get; set; }
    }

    [Serializable]
    public class CustomerListModel {
        public int Id { get; set; }
        public string LegalName { get; set; }
        public string BusinessName { get; set; }
        public string Location { get; set; }
        public bool IsManagementCustomer { get; set; }
        public bool CanConnectAsExternalUser { get; set; }
    }

    public class UserRoleModel {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public static class UserRole {
        public static UserRoleModel SystemAdministrator { get { return new UserRoleModel { Id = "4e949633-b1e9-4583-9a44-d8d9e377efc3", Name = "System Administrator" }; } }
        public static UserRoleModel CompanyAdministrator { get { return new UserRoleModel { Id = "73f65139-ed50-4e67-ac97-5d1d497c1f2c", Name = "Company Administrator" }; } }
        public static UserRoleModel Accounts { get { return new UserRoleModel { Id = "b7e7ee63-4082-4200-9d51-2fecf7d968f7", Name = "Accounts" }; } }
        public static UserRoleModel UserTeamLeader { get { return new UserRoleModel { Id = "61d750e1-24f2-429b-9cfd-b05bb3f57457", Name = "User Team Leader" }; } }
        public static UserRoleModel UserSenior { get { return new UserRoleModel { Id = "35273243-6f43-46d6-a7b3-95c4374e3b24", Name = "User Senior" }; } }
        public static UserRoleModel User { get { return new UserRoleModel { Id = "ae500897-0eb2-43df-b31b-afd0585775ed", Name = "User" }; } }
        public static UserRoleModel ReadOnly { get { return new UserRoleModel { Id = "6db17a81-464f-4c96-8e86-2399c8985734", Name = "Read-Only" }; } }
        public static UserRoleModel GetUserRole(AppUserRole appUserRole) {
            switch (appUserRole) {
                default:
                    return User;
                case AppUserRole.SystemAdministrator:
                    return SystemAdministrator;
                case AppUserRole.CompanyAdministrator:
                    return CompanyAdministrator;
                case AppUserRole.Accounts:
                    return Accounts;
                case AppUserRole.UserTeamLeader:
                    return UserTeamLeader;
                case AppUserRole.UserSenior:
                    return UserSenior;
                case AppUserRole.User:
                    return User;
            }
        }
        public static AppUserRole GetAppUserRole(string idOrName) {
            switch (idOrName) {
                default:
                    return AppUserRole.None;
                case "System Administrator":
                case "4e949633-b1e9-4583-9a44-d8d9e377efc3":
                    return AppUserRole.SystemAdministrator;
                case "Company Administrator":
                case "73f65139-ed50-4e67-ac97-5d1d497c1f2c":
                    return AppUserRole.CompanyAdministrator;
                case "Accounts":
                case "b7e7ee63-4082-4200-9d51-2fecf7d968f7":
                    return AppUserRole.Accounts;
                case "User Team Leader":
                case "61d750e1-24f2-429b-9cfd-b05bb3f57457":
                    return AppUserRole.UserTeamLeader;
                case "User Senior":
                case "35273243-6f43-46d6-a7b3-95c4374e3b24":
                    return AppUserRole.UserSenior;
                case "User":
                case "ae500897-0eb2-43df-b31b-afd0585775ed":
                    return AppUserRole.User;
            }
        }
    }
}