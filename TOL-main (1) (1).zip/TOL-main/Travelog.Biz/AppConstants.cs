﻿using System;
using Travelog.Biz.Resources;

namespace Travelog.Biz {
	public static class AppConstants {
		public static readonly DateTime VoidDate = new DateTime(2, 1, 1);

		public const int PasswordMinLength = 8;
		public const int PasswordMaxLength = 128;
		public const decimal MilesToKm = 1.609344m;

		public static readonly string GridDateFormatString = string.Format("{{0:{0}}}", Resource.ShortDatePattern);
		public static readonly string GridDateTimeFormatString = string.Format("{{0:{0} {1}}}", Resource.ShortDatePattern, Resource.ShortTimePattern);
		public static readonly string TaxRelatedRecordCannotBeAltered = string.Format("This value cannot be altered because {0} applicability is not consistent with the document's current status.", Resource.TaxLabel);

		public const string HtmlSpace = "&nbsp;";
		public const string HtmlLineBreak = "<br />";

		public const string DefaultAccentColor = "#2b489e";
		public const string DefaultHighlightColor = "#00b0ff";

        public const string Blue = "#428bca";
		public const string Green = "#44c17b";
		public const string Orange = "#ff7000";
		public const string Red = "#ff3448";

        public const string CdnUrl = "https://travelogonline.azureedge.net/cdn";

        public const string ContentTypeCsv = "text/csv";
        public const string ContentTypeExcel = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

		public static readonly string CustomerAccountIsOverdue = string.Format("Your account has an overdue balance payable. You have a grace period of {0} days from the due date to pay this amount and maintain access to your account.", AppSettings.CustomerPaymentTermsDays);
		public const string CustomerAccountIsPayableNow = "Your account has a balance payable now. Please pay this amount to restore access to your account.";
		public const string CustomerAccountIsDeactivated = "Your account has been deactivated. Please contact Travelog Online Support to reactivate it.";
		public const string CustomerAccountIsSuspended = "Your account has been suspended. Please contact Travelog Online Support to have the suspension lifted.";

		public static readonly string PasswordRule = string.Format("Password must be between {0} and {1} characters in length and contain at least one upper case character, one lower case character, one number and one special character.", PasswordMinLength, PasswordMaxLength);
        public static readonly string PasswordExpired = string.Format("Your password has expired and must be changed. {0}", PasswordRule);
        public static readonly string UserAccountCreated = string.Format(@"A user account has been created for you with {0}. Please <a href=""{1}{2}/{{0}}"">follow this link</a> to sign in. Your account details are:<br /><br />User Name: {{1}}<br />Password: {{2}}", AppSettings.AppTitle, AppSettings.HomeUrl, AppSettings.SignInPage);
        public const string UserAccountLocked = "Account has been locked. Please contact an Administrator to unlock it.";

		public const string ResourceNotFound = "The requested resource was not found.";
		public const string ApplicationError = "An error occurred. It has been logged for review.";
		public const string RequestLimitError = "An unusually high level of network traffic has resulted in your request being unsuccessful. Please try again.";
		public const string ConnectionError = "There was a problem connecting to the database. Please try reloading the page.";
		public const string ZeroAmountWarning = "Amount cannot be zero.";
		public const string NoCommissionWarning = "The record has been saved but Commission is zero. Press Cancel to close this window.";
		public const string GlControlAccountWarning = "GL control accounts can only be set by an administrator.";
		public const string GlControlAccountUpdate = "GL Account has been set to a control account.";
        public const string AgencyNotSpecified = "Agency has not been specified.";

        public const string UnauthorisedAccess = "You are not authorised to access this record.";
        public const string UnauthorisedAccessWarning = "You are not authorised to access the selected {0} record.";
        public const string UnauthorisedAccessRemoteAssistanceUser = "Remote assistance users are not authorised to perform this operation.";
        public const string UnauthorisedAccessSupportProvider = "Support providers are not authorised to perform this operation.";
        public const string UnauthorisedAccessAnotherCustomer = "You are not authorised to perform operations on another company.";
        public const string UnauthorisedAccessManagementCustomer = "This operation cannot be performed on a management company.";
        public const string UnauthorisedAccessNotManagementCustomer = "This operation can only be performed on a management company.";
        public const string UnauthorisedAccessNotAdministrator = "This operation can only be performed by an administrator.";
        public const string UnauthorisedAccessExport = "You are not authorised to use the Export function.";
        public const string UnauthorisedAccessCurrentUrl = "You are not authorised to connect to this company with the current URL.";
        public const string AntiForgeryTokenError = "Your request failed. The most likely cause is the selected company having changed since this page was last loaded.";

		public const string RecordNotFound = "Record not found.";
		public const string RecordCannotBeCreated = "This document requires a detail row in order to be created.";
		public const string RecordCannotBeDeleted = "At least one detail row is required in this document. Please edit this row or add another row before deleting this one.";
		public const string RecordCannotBeUndone = "The status of this document does not permit an undo.";
		public const string RecordCannotBeReversed = "The status of this document does not permit a reversal.";
		public const string RecordStatusCannotBeChanged = "The status of this document cannot be altered.";

		public const string RecordIsSaved = "This document has been saved. If no further changes are required then press 'Cancel' to close the form.";
		public const string RecordIsSavedAfterDeletion = "To ensure all related changes were updated after deletion of the detail row, this document has been saved.";
		public const string RecordIsReloadedAfterCancel = "To ensure all related changes were restored after cancellation of the detail row edit, this document has been reloaded to its original state.";
		public const string RecordIsNotBooking = "The trip assigned to this document is not a booking.";
		public const string RecordIsIssued = "This document has been issued and cannot be altered.";
		public const string RecordIsReadOnly = "This record is read-only and cannot be altered.";
		public const string RecordIsReadOnlyChangesNotSaved = "This record is read-only. Changes will not be saved.";
		public const string RecordIsLockedCannotUpdateMonetaryValues = "This Trip has been locked. Monetary and related values will not be saved.";
		public const string RecordIsLockedCannotDelete = "This Trip has been locked. Related records cannot be deleted.";
		public const string RecordIsClosed = "The fiscal period for this document date is closed. The record cannot be altered.";
		public const string RecordIsLegacy = "Legacy documents cannot be altered.";

		public static readonly string[] SqlReferenceConstraintDeleteConflict = { "The DELETE statement conflicted with the REFERENCE constraint", "The DELETE statement conflicted with the SAME TABLE REFERENCE constraint" };
		public static readonly string[] SqlArchiveDatabaseNotAvailable = { @"Cannot open database ""travelogarchive"" requested by the login", "Invalid object name 'travelogarchive.dbo.AuditLog'" };
		public static readonly string[] SqlRequestLimitReachedException = { "The request limit for the database is", "and has been reached" };

		public const string SqlReferenceConstraintInsertConflict = "The INSERT statement conflicted with the FOREIGN KEY constraint";
		public const string SqlReferenceConstraintUpdateConflict = "The UPDATE statement conflicted with the FOREIGN KEY constraint";
		public const string SqlDuplicateKeyException = "Cannot insert duplicate key row in object";
		public const string SqlUniqueKeyViolation = "Violation of UNIQUE KEY constraint ";
		public const string SqlDuplicateAirPassengerException = "Only one air passenger is permitted for";
        public const string SqlDateTimeOffsetException = "Unable to cast object of type 'System.DateTime' to type 'System.DateTimeOffset'";

        public const string SqlReferenceConstraintUpdate = "One or more records are referenced elsewhere in the application and cannot be altered.";
        public const string SqlReferenceConstraintDelete = "One or more records are referenced elsewhere in the application and cannot be deleted.";

        public const string ParametersDictionaryException = "The parameters dictionary contains a null entry for parameter";
		public const string ConnectionStringException = "The ConnectionString property has not been initialized";
		public const string AntiForgeryTokenException = "The provided anti-forgery token was meant for a different claims-based user than the current user";

		public static readonly string InvoiceAdvice = string.Format("We wish to advise that {{0}} from {0} is available to view online.", AppSettings.AppTitle);
		public static readonly string ReceiptAdvice = string.Format("We wish to advise that {{0}} from {0} is available to view online.", AppSettings.AppTitle);
		public static readonly string RefundAdvice = string.Format("We wish to advise that a refund from {0} is available to view online.", AppSettings.AppTitle);
		public static readonly string PaymentConfirmation = string.Format("This is to confirm that {0} has received your payment of {{0:c2}}.<br />Transaction ID: {{1:d8}}.", AppSettings.AppTitle);
		public static readonly string TermsAndConditionsChanged = string.Format("{0} has revised its Terms & Conditions. To view them, please sign in to your account.", AppSettings.AppTitle);

		public const string MailBody = @"<div style=""font: 11pt Calibri"">{0}</div>";

		public static readonly string MailBodyRecoverPassword = string.Format(@"<div style=""font: 11pt Calibri"">This message has been automatically generated by {0}. PLEASE DO NOT REPLY.<br /><br />Please <a href=""{{0}}"">follow this link</a> to reset your password.</div>", AppSettings.AppTitle);
		public static readonly string MailBodyNoReply = string.Format(@"<div style=""font: 11pt Calibri"">This message has been automatically generated by {0}. PLEASE DO NOT REPLY.<br /><br />{{0}}</div>", AppSettings.AppTitle);
		public static readonly string MailBodyHtml = string.Format(MailHtmlTemplate, AppSettings.HomeUrl, "{{0}}");

		private const string MailHtmlTemplate =
		@"<!DOCTYPE html PUBLIC ""-//W3C//DTD XHTML 1.0 Transitional//EN"" ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd""><html xmlns=""http://www.w3.org/1999/xhtml"">
		<head>
			<meta http-equiv=""Content-Type"" content=""text/html; charset=iso-8859-1""><meta name=""viewport"" content=""width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"">
			<style type=""text/css"">
				h1 {{
					color: #202020 !important;
					font-size: 26px;
					letter-spacing: normal;
					text-align: left;
					margin: 0 0 10px;
				}}
				h2 {{
					color: #404040 !important;
					font-size: 20px;
					line-height: 100%;
					letter-spacing: normal;
					text-align: left;
					margin: 0 0 10px;
				}}
				h1, img {{
					line-height: 100%;
				}}
				h1, h2 {{
					display: block;
					font-family: Helvetica;
					font-style: normal;
					font-weight: 700;
				}}
				h3, h4 {{
					display: block;
					font-style: italic;
					font-weight: 400;
					letter-spacing: normal;
					text-align: left;
					margin: 0 0 10px;
					font-family: Helvetica;
					line-height: 100%;
				}}
				h3 {{
					color: #606060 !important;
					font-size: 16px;
				}}
				h4 {{
					color: grey !important;
					font-size: 14px;
				}}
				a, body, li, p, table, td {{
					-webkit-text-size-adjust: 100%;
					-ms-text-size-adjust: 100%;
				}}
				body {{
					height: 100% !important;
					margin: 0;
					padding: 0;
					width: 100% !important;
					background-color: #FAFAFA;
				}}
				table {{
					border-collapse: collapse !important;
				}}
				table, td {{
					mso-table-lspace: 0;
					mso-table-rspace: 0;
				}}
				img {{
					-ms-interpolation-mode: bicubic;
					border: 0;
					height: auto;
					outline: 0;
					text-decoration: none;
				}}
			</style>
		</head>
		<body leftmargin=""0"" marginwidth=""0"" topmargin=""0"" marginheight=""0"" offset=""0""><center>
		<table>
			<tr>
				<td></td>
				<td width=""800"">
					<a href=""{0}""><img src=""{0}/wwwroot/css/images/images/logo.png""></a>
				</td>
				<td></td>
			</tr>
			<tr>
				<td></td>
				<td>{1}</td>
				<td></td>
			</tr>
			<tr>
				<td></td>
				<td width=""800"">
					{0}
				</td>
				<td></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td></td>
				<td width=""800"">
					<h4>
						Travelog Online Pty Ltd ABN 13 082 467 123
					</h4>
				</td>
				<td></td>
			</tr>
		</table></center></body></html>";
	}
}