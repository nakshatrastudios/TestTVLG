﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Travelog.Biz {
    public class ExceptionManagerBiz {
        public static ExceptionManagerBiz Instance { get; } = new ExceptionManagerBiz();

        public string HandleException(string className, string method, Exception ex, int customerId = 0, string userName = null) {
            return HandleExceptionAsync(className, method, ex, customerId, userName).Result;
        }

        public async Task<string> HandleExceptionAsync(string className, string method, Exception ex, int customerId = 0, string userName = null, string url = null, IPAddress ipAddress = null, string userAgent = null, string source = null, string stack = null, string message = null) {
            if (ex == null) {
                return string.Empty;
            }
            else if (ex is UnreportedException || ex is EwayException) {
                return ex.Message;
            }
            else if (IsSqlDuplicateException(ex)) {
                return "This entry contains a value which would result in a duplicate record.";
            }
            else if (IsSqlDuplicateAirPassengerException(ex)) {
                if (ex.InnerException.Message == null || ex.InnerException.Message == string.Format("{0} this document.", AppConstants.SqlDuplicateAirPassengerException))
                    return string.Format("{0} this document.", AppConstants.SqlDuplicateAirPassengerException);

                string documentNo = ex.InnerException.Message.Substring(AppConstants.SqlDuplicateAirPassengerException.Length, ex.Message.IndexOf(".") - AppConstants.SqlDuplicateAirPassengerException.Length + 1);
                return string.Format("{0} Document No {1}.", AppConstants.SqlDuplicateAirPassengerException, documentNo);
            }
            else if (IsSqlArchiveDatabaseNotAvailable(ex)) {
                return "The archive database is not available.";
            }
            else {
                string entityName = null;
                string exceptionType = null;

                if (IsSqlReferenceConstraintConflict(ex, false, ref entityName, ref exceptionType)) {
                    switch (exceptionType) {
                        case "Delete":
                            message = AppConstants.SqlReferenceConstraintDelete;
                            break;
                        case "Insert":
                        case "Update":
                            message = AppConstants.SqlReferenceConstraintUpdate;
                            break;
                    }

                    if (!string.IsNullOrEmpty(entityName)) {
                        var entityTransalation = EntityTranslations.SingleOrDefault(t => t.Key == entityName);

                        if (entityTransalation.Key == null) {
                            message = string.Format("{0} Entity: {1}", message, entityName);
                        }
                        else {
                            message = entityTransalation.Value;
                        }
                    }

                    return message;
                }
            }

            if (message == null)
                message = GetErrorMessage(className, method, ex, customerId, userName, url, ipAddress, userAgent, source, stack);

            LogError(message);
            await SendMailAsync(className, method, ex, message);

            if (ex is CrsException || ex is ReportedException)
                return ex.Message;

            if (IsConnectionStringException(ex))
                return AppConstants.ConnectionError;

            if (IsSqlRequestLimitReachedException(ex))
                return AppConstants.RequestLimitError;

            return AppConstants.ApplicationError;
        }

        public bool IsSqlDuplicateException(Exception ex) {
            var exception = ex;

            while (exception != null) {
                if (exception.Message.Contains(AppConstants.SqlDuplicateKeyException, StringComparison.OrdinalIgnoreCase) || exception.Message.Contains(AppConstants.SqlUniqueKeyViolation, StringComparison.OrdinalIgnoreCase))
                    return true;

                exception = exception.InnerException;
            }

            return false;
        }

        public bool IsSqlDuplicateAirPassengerException(Exception ex) {
            var exception = ex;

            while (exception != null) {
                if (exception.Message.StartsWith(AppConstants.SqlDuplicateAirPassengerException, StringComparison.OrdinalIgnoreCase))
                    return true;

                exception = exception.InnerException;
            }

            return false;
        }

        public bool IsSqlReferenceConstraintConflict(Exception ex) {
            string entityName = string.Empty;
            string exceptionType = string.Empty;
            return IsSqlReferenceConstraintConflict(ex, false, ref entityName, ref exceptionType);
        }

        private bool IsSqlReferenceConstraintConflict(Exception ex, bool validateDeleteOnly, ref string entityName, ref string exceptionType) {
            var exception = ex;

            while (exception != null) {
                foreach (var row in AppConstants.SqlReferenceConstraintDeleteConflict) {
                    if (exception.Message.Contains(row, StringComparison.OrdinalIgnoreCase)) {
                        entityName = GetReferenceConflictMessage(exception.Message);
                        exceptionType = "Delete";
                        return true;
                    }
                }

                if (!validateDeleteOnly) {
                    if (exception.Message.Contains(AppConstants.SqlReferenceConstraintInsertConflict, StringComparison.OrdinalIgnoreCase)) {
                        entityName = GetReferenceConflictMessage(exception.Message);
                        exceptionType = "Insert";
                        return true;
                    }

                    if (exception.Message.Contains(AppConstants.SqlReferenceConstraintUpdateConflict, StringComparison.OrdinalIgnoreCase)) {
                        entityName = GetReferenceConflictMessage(exception.Message);
                        exceptionType = "Update";
                        return true;
                    }
                }

                exception = exception.InnerException;
            }

            return false;
        }

        public bool IsSqlRequestLimitReachedException(Exception ex) {
            var exception = ex;

            while (exception != null) {
                foreach (var row in AppConstants.SqlRequestLimitReachedException) {
                    if (exception.Message.Contains(row, StringComparison.OrdinalIgnoreCase))
                        return true;
                }

                exception = exception.InnerException;
            }

            return false;
        }

        public bool IsConnectionStringException(Exception ex) {
            var exception = ex;

            while (exception != null) {
                if (exception.Message.Contains(AppConstants.ConnectionStringException, StringComparison.OrdinalIgnoreCase))
                    return true;

                exception = exception.InnerException;
            }

            return false;
        }

        public bool IsAntiForgeryTokenException(Exception ex) {
            var exception = ex;

            while (exception != null) {
                if (exception.Message.Contains(AppConstants.AntiForgeryTokenException, StringComparison.OrdinalIgnoreCase))
                    return true;

                exception = exception.InnerException;
            }

            return false;
        }

        public bool IsSqlArchiveDatabaseNotAvailable(Exception ex) {
            var exception = ex;

            while (exception != null) {
                foreach (var row in AppConstants.SqlArchiveDatabaseNotAvailable) {
                    if (exception.Message.Contains(row, StringComparison.OrdinalIgnoreCase))
                        return true;
                }

                exception = exception.InnerException;
            }

            return false;
        }

        public void LogError(string message) {
            if (AppSettings.IsLocal) {
                try {
                    EventLog.WriteEntry(AppSettings.AppTitle, message, EventLogEntryType.Error);
                }
                catch {
                }
            }
        }

        public string GetErrorMessage(string className, string method, Exception ex, int customerId = 0, string userName = null) {
            return GetErrorMessage(className, method, ex, customerId, userName, null, null, null);
        }

        public string GetErrorMessage(string className, string method, Exception ex, int customerId, string userName, string url, IPAddress ipAddress, string userAgent, string source = null, string stack = null) {
            var sb = new StringBuilder();

            if (customerId != 0)
                sb.AppendFormat("Customer: {0}", CustomerSettings.Setting(customerId).FullName).AppendLine();

            if (!string.IsNullOrEmpty(userName))
                sb.AppendFormat("User Name: {0}", userName).AppendLine();

            if (!string.IsNullOrEmpty(url))
                sb.AppendFormat("URL: {0}", url).AppendLine();

            if (ipAddress != null)
                sb.AppendFormat("IP Address: {0}", ipAddress).AppendLine();

            if (!string.IsNullOrEmpty(userAgent))
                sb.AppendFormat("User Agent: {0}", userAgent).AppendLine();

            if (!string.IsNullOrEmpty(className)) {
                if (string.IsNullOrEmpty(method)) {
                    sb.AppendFormat("Class: {0}", className).AppendLine();
                }
                else {
                    sb.AppendFormat("Class: {0}.{1}", className, method).AppendLine();
                }
            }

            sb.AppendLine();
            sb.AppendFormat("{0}: {1}", ex.GetType() == typeof(SourceTamperingException) ? "Source Tampering Exception" : "Exception", ex.Message).AppendLine();

            var innerException = ex.InnerException;

            while (innerException != null) {
                if (innerException.Message != ex.Message)
                    sb.AppendFormat("Inner Exception: {0}", innerException.Message).AppendLine();

                innerException = innerException.InnerException;
            }

            if (string.IsNullOrEmpty(source)) {
                if (!string.IsNullOrEmpty(ex.Source))
                    sb.AppendFormat("Source: {0}", ex.Source).AppendLine();
            }
            else {
                sb.AppendFormat("Source: {0}", source).AppendLine();
            }

            if (string.IsNullOrEmpty(stack)) {
                if (!string.IsNullOrEmpty(ex.StackTrace))
                    sb.AppendFormat("Stack Trace: {0}", ex.StackTrace).AppendLine();
            }
            else {
                sb.AppendFormat("Stack Trace: {0}", stack).AppendLine();
            }

            if (ex.TargetSite != null)
                sb.AppendFormat("Target Site: {0}", ex.TargetSite.ToString()).AppendLine();

            return sb.ToString();
        }

        private string GetReferenceConflictMessage(string message, bool includeReferenceId = false) {
            string entityName = string.Empty;
            int startIndex = message.IndexOf("table") + 5;
            int endIndex = message.IndexOf("column");

            if (startIndex > 4 && endIndex > startIndex)
                entityName = message.Substring(startIndex, endIndex - startIndex).Replace(",", string.Empty).Replace(@"\", string.Empty).Replace("\"", string.Empty).Trim();

            if (includeReferenceId) {
                startIndex = message.IndexOf("REFERENCE constraint ") + 22;
                endIndex = message.IndexOf(". The conflict occurred") - 1;

                if (startIndex > 21 && endIndex > startIndex)
                    entityName = string.Format("{0} [{1}]", entityName, message.Substring(startIndex, endIndex - startIndex));
            }

            return entityName;
        }

        public async Task SendMailAsync(string className, string method, Exception ex, string message = null, string to = null) {
            if (ex.GetType() == typeof(MailException))
                return;

            if (message == null)
                message = GetErrorMessage(className, method, ex);

            if (to == null) {
                if (AppSettings.IsDevelopmentMode) {
                    to = "steve@travelog.com.au";
                }
                else {
                    to = AppSettings.EmailErrors;
                }
            }

            string subject = string.Format("{0} - Application Error", AppSettings.AppTitle);
            string body = string.Format(AppConstants.MailBody, WebUtility.HtmlEncode(message).Replace(Environment.NewLine, AppConstants.HtmlLineBreak));

            await Mail.Instance.SendMailAsync(to, subject, body);
        }

        private Dictionary<string, string> EntityTranslations => new Dictionary<string, string> {
            { "Accounting.Transaction", "Related transactions must first be deleted before this record can be deleted." },
            { "Accounting.TransactionDetailAllocation", "Debtor or Creditor allocations must first be deleted before this record can be deleted." },
            { "Accounting.ReceiptDetail", "Related receipts must first be deleted before this record can be deleted." },
            { "Accounting.BspDetail", "Related BSP returns must first be deleted before this record can be deleted." },
            { "Accounting.NonBspDetail", "Related Non-BSP returns must first be deleted before this record can be deleted." },
            { "Accounting.PaymentDetail", "Related payments must first be deleted before this record can be deleted." },
            { "Accounting.InvoiceDetail", "Related invoices must first be deleted before this record can be deleted." },
            { "Accounting.JournalDetail", "Related journals must first be deleted before this record can be deleted." },
            { "Accounting.Adjustment", "Related adjustments must first be deleted before this record can be deleted." },
            { "ClientLedger.TripLineAir", "Air trip lines must first be deleted before this record can be deleted." },
            { "ClientLedger.TripLineAirPassenger", "Related air passengers must first be deleted before this record can be deleted." },
            { "ClientLedger.TripLineAirSegment", "Related air segments must first be deleted before this record can be deleted." },
            { "ClientLedger.TripLineAirPassengerAirSegment", "Related air passenger/segment assignments must first be deleted before this record can be deleted." },
            { "ClientLedger.TripLineLand", "Land trip lines must first be deleted before this record can be deleted." },
            { "ClientLedger.TripLineInsurance", "Insurance trip lines must first be deleted before this record can be deleted." },
            { "ClientLedger.TripLineForeignCurrency", "Foreign Currency trip lines must first be deleted before this record can be deleted." },
            { "ClientLedger.TripLineServiceFee", "Service Fee trip lines must first be deleted before this record can be deleted." },
            { "ClientLedger.TripLineOtherInclusion", "Other Inclusion trip lines must first be deleted before this record can be deleted." },
            { "ClientLedger.TripLineRemark", "Remark trip lines must first be deleted before this record can be deleted." },
            { "ClientLedger.TripItinerary", "Itineraries must first be deleted before this record can be deleted." },
            { "ClientLedger.TripItineraryDetail", "Itineraries must first be deleted before this record can be deleted." }
        };
    }

    [Serializable]
    public class CrsException : Exception {
        public CrsException() {
        }

        public CrsException(string message) : base(message) {
        }

        public CrsException(string message, Exception innerException) : base(message, innerException) {
        }
    }

    [Serializable]
    public class EwayException : Exception {
        public EwayException() {
        }

        public EwayException(string message) : base(message) {
        }

        public EwayException(string message, Exception innerException) : base(message, innerException) {
        }
    }

    [Serializable]
    public class MailException : Exception {
        public MailException() {
        }

        public MailException(string message) : base(message) {
        }

        public MailException(string message, Exception innerException) : base(message, innerException) {
        }
    }

    [Serializable]
    public class ReportedException : Exception {
        public ReportedException() {
        }

        public ReportedException(string message) : base(message) {
        }

        public ReportedException(string message, Exception innerException) : base(message, innerException) {
        }
    }

    [Serializable]
    public class SourceTamperingException : Exception {
        public SourceTamperingException() {
        }

        public SourceTamperingException(string message) : base(message) {
        }

        public SourceTamperingException(string message, Exception innerException) : base(message, innerException) {
        }
    }

    [Serializable]
    public class UnreportedException : Exception {
        public UnreportedException() {
        }

        public UnreportedException(string message) : base(message) {
        }

        public UnreportedException(string message, Exception innerException) : base(message, innerException) {
        }
    }
}