﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Telerik.Documents.Common.Model;
using Telerik.Documents.Media;
using Telerik.Windows.Documents.Spreadsheet.FormatProviders.OpenXml.Xlsx;
using Telerik.Windows.Documents.Spreadsheet.Model;

namespace Travelog.Biz {
    public class ExportToExcel<T> where T : class {
        private readonly List<T> ExportList;

        public ExportToExcel(List<T> list) {
            ExportList = list;
        }

        public byte[] ExportToBytes(string[] columns = null, bool includeHeaderRow = true) {
            IList<PropertyInfo> piList;

            if (columns == null) {
                piList = typeof(T).GetProperties();
            }
            else {
                piList = typeof(T).GetProperties().Where(t1 => columns.Any(t2 => t2.ToLower() == t1.Name.ToLower())).ToList();
            }

            var workbook = new Workbook();
            workbook.Sheets.Add(SheetType.Worksheet);

            var worksheet = workbook.ActiveWorksheet;
            worksheet.DefaultColumnWidth = new ColumnWidth(100, true);

            var border = new CellBorder(CellBorderStyle.Thin, new ThemableColor(Color.FromRgb(192, 192, 192)));

            int rowIndex = 0;
            int columnIndex = 0;

            if (includeHeaderRow) {
                foreach (PropertyInfo pi in piList) {
                    var cell = worksheet.Cells[0, columnIndex];
                    cell.SetValue(pi.Name);

                    if (pi.PropertyType.Name == "Decimal")
                        cell.SetHorizontalAlignment(RadHorizontalAlignment.Right);

                    worksheet.Cells[rowIndex, columnIndex].SetBorders(new CellBorders(null, null, null, border, null, null, null, null));
                    columnIndex++;
                }
            }

            foreach (T row in ExportList) {
                rowIndex++;
                columnIndex = 0;

                foreach (PropertyInfo pi in piList) {
                    var value = pi.GetValue(row, null);
                    var cell = worksheet.Cells[rowIndex, columnIndex];

                    if (value is string) {
                        cell.SetValueAsText(value.ToStringExt());
                    }
                    else {
                        cell.SetValue(value.ToStringExt());

                        if (value is DateTime) {
                            cell.SetHorizontalAlignment(RadHorizontalAlignment.Left);
                        }
                        else if (value is decimal) {
                            cell.SetHorizontalAlignment(RadHorizontalAlignment.Right);
                        }
                    }

                    worksheet.Cells[rowIndex, columnIndex].SetBorders(new CellBorders(null, null, null, border, null, null, null, null));
                    columnIndex++;
                }
            }

            var formatProvider = new XlsxFormatProvider();
            return formatProvider.Export(workbook);
        }
    }
}