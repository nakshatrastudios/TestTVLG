﻿using System;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Distributed;

namespace Travelog.Biz {
    public static class AppCache {
        public static async Task<T> GetAsync<T>(this IDistributedCache cache, string userName, CacheKey key) {
            if (cache == null || string.IsNullOrEmpty(userName))
                return default;

            byte[] value = await cache.GetAsync(GetCacheKey(userName, key));

            if (value == null)
                return default;

            return JsonSerializer.Deserialize<T>(Encoding.UTF8.GetString(value));
        }

        public static async Task SetAsync<T>(this IDistributedCache cache, string userName, CacheKey key, T value, TimeSpan? expiry = null) {
            if (cache == null || string.IsNullOrEmpty(userName))
                return;

            var cacheOptions = new DistributedCacheEntryOptions {
                SlidingExpiration = expiry ?? TimeSpan.FromDays(1)
            };

            if (value == null) {
                await cache.RemoveAsync(userName, key);
                return;
            }

            await cache.SetAsync(GetCacheKey(userName, key), JsonSerializer.SerializeToUtf8Bytes(value), cacheOptions);
        }

        public static async Task RemoveAsync(this IDistributedCache cache, string userName, CacheKey key) {
            if (cache == null || string.IsNullOrEmpty(userName))
                return;

            await cache.RemoveAsync(GetCacheKey(userName, key));
        }

        public static async Task RemoveUserAsync(this IDistributedCache cache, string userName) {
            if (cache == null || string.IsNullOrEmpty(userName))
                return;

            foreach (CacheKey key in Enum.GetValues(typeof(CacheKey))) {
                await cache.RemoveAsync(GetCacheKey(userName, key));
            }
        }

        private static string GetCacheKey(string userName, CacheKey key) {
            return string.Format("{0}-{1}", userName ?? AppSettings.SystemAccountName, key);
        }
    }

    public enum CacheKey {
        AgencyList = 0,
        MenuList = 1
    }
}