﻿namespace Travelog.Biz.Enums {
    public enum ChartOfAccountTransactionType {
        Consolidated = 0,
        Detailed = 1
    }
}