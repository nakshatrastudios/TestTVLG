using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum ReportSourceGeneralLedger {
		[Description("Trial Balance")]
		TrialBalance = 0,
		[Description("Profit & Loss")]
		ProfitLoss = 1,
		[Description("Balance Sheet")]
		BalanceSheet = 2,
		[Description("General Ledger Transactions")]
		GeneralLedgerTransactions = 3,
		Budget = 4
	}
}