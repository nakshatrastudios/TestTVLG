﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum ChartOfAccountGroup {
        [Description("All Account Types")]
        All = -1,
        Income = 0,
        Expenditure = 1,
        [Description("Current Assets")]
        CurrentAssets = 2,
        [Description("Non-Current Assets")]
        NonCurrentAssets = 3,
        [Description("Current Liabilities")]
        CurrentLiabilities = 4,
        [Description("Non-Current Liabilities")]
        NonCurrentLiabilities = 5,
        [Description("Profit & Loss Appropriation")]
        ProfitAndLossAppropriation = 6,
        Equity = 7
    }
}