﻿namespace Travelog.Biz.Enums {
    public enum GeneralLedgerDivision {
        None = 0,
        Agent = 1,
        Consultant = 2,
        Supplier = 3,
        Category = 4,
        Source = 5
    }
}