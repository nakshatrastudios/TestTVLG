﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum TotalLevel {
        Normal = 0,
        [Description("Total 1")]
        Total1 = 1,
        [Description("Total 2")]
        Total2 = 2,
        [Description("Total 3")]
        Total3 = 3,
        [Description("Total 4")]
        Total4 = 4,
        [Description("Total 5")]
        Total5 = 5,
        [Description("Total 6")]
        Total6 = 6,
        [Description("Total 7")]
        Total7 = 7,
        [Description("Total 8")]
        Total8 = 8,
        [Description("Total 9")]
        Total9 = 9,
        [Description("New Page")]
        NewPage = 10
    }
}