﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum ReportSign {
        [Description("None")]
        None = 0,
        Bracket = 1,
        Debit = 2,
        Credit = 3
    }
}