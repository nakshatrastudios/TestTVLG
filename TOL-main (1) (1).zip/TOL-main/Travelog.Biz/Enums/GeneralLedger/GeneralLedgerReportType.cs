
using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum GeneralLedgerReportType {
		[Description("General Ledger")]
		GeneralLedger = 0,
		[Description("Management Ledger")]
		ManagementLedger = 1
	}
}