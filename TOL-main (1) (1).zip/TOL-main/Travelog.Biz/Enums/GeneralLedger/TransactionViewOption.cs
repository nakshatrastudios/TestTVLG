
using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum TransactionViewOption {
		[Description("Current Period/Previous Year")]
		CurrentPrevious = 0,
		[Description("Current/Previous/Variance")]
		CurrentPreviousVariance = 1,
		[Description("Current/Budget/Variance")]
		CurrentBudgetVariance = 2,
		[Description("Current/Budget/Previous")]
		CurrentBudgetPrevious = 3
	}
}