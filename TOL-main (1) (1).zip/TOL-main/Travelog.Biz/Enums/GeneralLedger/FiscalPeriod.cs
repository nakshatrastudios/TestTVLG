using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum FiscalPeriod {
		[Description("3 Periods")]
		ThreePeriods = 0,
		[Description("6 Periods")]
		SixPeriods = 1,
		[Description("All Periods")]
		AllPeriods = 2
	}
}