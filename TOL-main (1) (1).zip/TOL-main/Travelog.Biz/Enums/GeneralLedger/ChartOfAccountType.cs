﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum ChartOfAccountType {
        [Description("Not Specified")]
        NotSpecified = -1,
        [Description("Balance Sheet")]
        BalanceSheet = 0,
        [Description("Profit & Loss")]
        ProfitLoss = 1
    }
}