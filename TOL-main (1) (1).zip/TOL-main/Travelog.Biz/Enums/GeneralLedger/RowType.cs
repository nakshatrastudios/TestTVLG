﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum RowType {
        Normal = 0,
        Header = 1,
        Description = 2,
        [Description("Undistributed Profits")]
        UndistributedProfits = 3,
        Total = 4,
        [Description("Retained Profits")]
        RetainedProfits = 5
    }
}