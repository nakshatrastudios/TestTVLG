﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum GLIssuedDocumentType {
        [Description("Trial Balance")]
        TrialBalance = 0,
        [Description("Profit & Loss")]
        ProfitAndLoss = 1,
        [Description("Balance Sheet")]
        BalanceSheet = 2,
        [Description("Tax Audit")]
        TaxAudit = 3
    }
}