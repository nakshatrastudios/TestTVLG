﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum AccountCategory {
        None = -1,
        Asset = 0,
        Liability = 1,
        Capital = 2,
        Income = 3,
        Expense = 4,
        [Description("Bank Charge/Interest")]
        BankCharge = 5,
        Purchase = 6,
        Salary = 7,
        [Description("PAYE/PAYG")]
        PAYEG = 8
    }
}