﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum Crs {
        [Description("Not Specified")]
        NotSpecified = -1,
        Aerotech = 0,
        Galileo = 1,
        Sabre = 2,
        Amadeus = 3,
        Abacus = 4,
        Calypso = 5,
		[Description("Express Travel Group")]
		ExpressTravelGroup = 6
	}
}