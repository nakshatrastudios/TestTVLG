﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum AdjustmentTransactionType {
        None = 0,
        Cash = 1,
        [Description("Cash & Commission")]
        CashCommission = 2,
        [Description("Credit Card")]
        CreditCard = 3,
        [Description("Credit Card & Commission")]
        CreditCardCommission = 4,
        [Description("Commission Only")]
        CommissionOnly = 5,
        [Description("Tax Audit Commission Only")]
        TaxAuditCommissionOnly = 6
    }
}