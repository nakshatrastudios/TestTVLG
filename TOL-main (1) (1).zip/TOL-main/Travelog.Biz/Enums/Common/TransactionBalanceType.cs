using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum TransactionBalanceType {
		None = -1,
		[Description("Non-Zero")]
		NonZero = 0,
		Zero = 1,
		Debit = 2,
		Credit = 3
	}
}