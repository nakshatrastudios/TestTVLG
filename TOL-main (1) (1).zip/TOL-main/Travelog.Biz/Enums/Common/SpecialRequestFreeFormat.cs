﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum SpecialRequestFreeFormat {
        Required = 0,
        Permitted = 1,
        [Description("Not Permitted")]
        NotPermitted = 2
    }
}