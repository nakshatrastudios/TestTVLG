﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum TravelZone {
        International = 0,
        Domestic = 1,
        [Description("Short Haul International")]
        ShortHaulInternational = 2,
        [Description("Long Haul International")]
        LongHaulInternational = 3
    }
}