﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum FormOfPaymentType {
        [Description("Not Specified")]
        NotSpecified = -1,
        Cash = 0,
        Cheque = 1,
        [Description("Credit Card")]
        CreditCard = 2,
        EFTPOS = 3,
        [Description("Automatic Payment")]
        AutomaticPayment = 4,
        [Description("Direct Debit/Credit")]
        DirectDebitCredit = 5,
        Other = 6,
        [Description("Travel Card")]
        TravelCard = 7,
        Reward = 8,
        [Description("Agency Credit Card Net")]
        AgencyCreditCardNet = 9,
        [Description("Loyalty Scheme")]
        LoyaltyScheme = 10,
        [Description("Pay Supplier Gross")]
        PaySupplierGross = 11,
        [Description("Agency Credit Card Gross")]
        AgencyCreditCardGross = 12,
        [Description("Clearing House Net")]
        ClearingHouseNet = 13,
        [Description("Clearing House Gross")]
        ClearingHouseGross = 14
    }
}