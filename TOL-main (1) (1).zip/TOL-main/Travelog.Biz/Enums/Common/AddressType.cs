﻿namespace Travelog.Biz.Enums {
    public enum AddressType {
        Street = 0,
        Postal = 1,
        Delivery = 2,
        Other = 3
    }
}