﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum AgingCycle {
        [Description("Not Specified")]
        NotSpecified = -1,
        [Description("7 Day")]
        SevenDay = 0,
        [Description("14 Day")]
        FourteenDay = 1,
        [Description("30 Day")]
        ThirtyDay = 2
    }
}