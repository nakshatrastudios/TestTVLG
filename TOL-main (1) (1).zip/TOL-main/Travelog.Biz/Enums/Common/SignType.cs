﻿namespace Travelog.Biz.Enums {
    public enum SignType {
        Debit = 0,
        Credit = 1,
        None = 2
    }
}