﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum ClassType {
        [Description("Not Specified")]
        NotSpecified = -1,
        Debtor = 1,
        Client = 2,
        Creditor = 3,
        [Description("Supplier - Insurance")]
        SupplierInsurance = 4,
        [Description("Supplier - Accommodation")]
        SupplierAccommodation = 5,
        [Description("Supplier - Transport")]
        SupplierTransport = 6,
        [Description("Supplier - Air")]
        SupplierAir = 7,
        [Description("Supplier - Tour")]
        SupplierTour = 8,
        [Description("Supplier - Other")]
        SupplierOther = 9,
        [Description("Supplier - Cruise")]
        SupplierCruise = 10
    }
}