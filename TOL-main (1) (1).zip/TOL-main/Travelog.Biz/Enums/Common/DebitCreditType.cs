﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum DebitCreditType {
        Client = 0,
        Debtor = 1,
        Creditor = 2,
        [Description("General Ledger")]
        GeneralLedger = 3
    }
}