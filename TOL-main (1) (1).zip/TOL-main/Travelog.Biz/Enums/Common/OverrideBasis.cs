﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum OverrideBasis {
        None = 0,
        [Description("Gross (ticketed)")]
        GrossTicketed = 1,
        [Description("Net (ex-commission)")]
        NetExCommission = 2,
        [Description("Gross (plus tax)")]
        GrossPlusTax = 3,
        [Description("Net (plus tax)")]
        NetPlusTax = 4
    }
}