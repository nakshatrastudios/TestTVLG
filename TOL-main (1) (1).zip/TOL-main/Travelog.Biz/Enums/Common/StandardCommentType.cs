﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum StandardCommentType {
        [Description("Not Specified")]
        NotSpecified = -1,
        Comment = 0,
        Signature = 1,
        [Description("Visa Header")]
        VisaHeader = 2,
        [Description("Visa Footer")]
        VisaFooter = 3,
        [Description("Passport Header")]
        PassportHeader = 4,
        [Description("Passport Footer")]
        PassportFooter = 5,
        Other = 6
    }
}