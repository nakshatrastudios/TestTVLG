﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum ReportPeriod {
        [Description("1 Month")]
        OneMonth = 0,
        [Description("2 Months")]
        TwoMonths = 1,
        [Description("3 Months")]
        ThreeMonths = 2,
        [Description("6 Months")]
        SixMonths = 3,
        [Description("12 Months")]
        TwelveMonths = 4
    }
}