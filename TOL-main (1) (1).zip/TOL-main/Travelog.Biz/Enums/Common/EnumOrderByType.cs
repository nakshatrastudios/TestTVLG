namespace Travelog.Biz.Enums {
	public enum EnumOrderByType {
		None = 0,
		Value = 1,
		Text = 2
	}
}