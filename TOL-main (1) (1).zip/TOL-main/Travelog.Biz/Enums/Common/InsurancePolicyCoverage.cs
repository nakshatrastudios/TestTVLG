﻿namespace Travelog.Biz.Enums {
    public enum InsurancePolicyCoverage {
        Family = 0,
        Individual = 1
    }
}