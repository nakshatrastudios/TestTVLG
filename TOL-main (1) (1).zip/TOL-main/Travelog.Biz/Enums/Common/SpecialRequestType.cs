﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum SpecialRequestType {
        [Description("Not Specified")]
        NotSpecified = -1,
        SSR = 0,
        OSI = 1
    }
}