﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum ApportionMethod {
        Fixed = 0,
        [Description("Percentage Gross")]
        PercentageGross = 1,
        [Description("Percentage Markup")]
        PercentageMarkup = 2,
        [Description("Percentage Gross + Mark-Up")]
        PercentageGrossMarkup = 3
    }
}