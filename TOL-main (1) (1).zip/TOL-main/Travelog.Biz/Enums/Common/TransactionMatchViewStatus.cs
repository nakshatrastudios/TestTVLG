using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum TransactionMatchViewStatus {
		[Description("Not Saved")]
		NotSaved = 0,
		Saved = 1,
		Mismatches = 2
	}
}