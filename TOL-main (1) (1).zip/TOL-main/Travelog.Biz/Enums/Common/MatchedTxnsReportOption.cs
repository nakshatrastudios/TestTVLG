﻿namespace Travelog.Biz.Enums {
    public enum PaidStatusReportOption {
        All = 0,
        Unpaid = 1,
        Paid = 2
    }
}