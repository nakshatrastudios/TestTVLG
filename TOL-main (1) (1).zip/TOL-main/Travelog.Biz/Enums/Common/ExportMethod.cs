
using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum ExportMethod {
		None = 0,
		[Description("Excel Detail")]
		ExcelDetail = 1,
		[Description("Excel Summary")]
		ExcelSummary = 2,
		[Description("CSV Detail")]
		CsvDetail = 3
	}
}