using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum SelectionOption {
		[Description("All Rows")]
		All = 0,
		[Description("Matched Rows")]
		Matched = 1,
		[Description("Unmatched Rows")]
		Unmatched = 2,
		[Description("Match Zeros")]
		MatchZeros = 3
	}
}