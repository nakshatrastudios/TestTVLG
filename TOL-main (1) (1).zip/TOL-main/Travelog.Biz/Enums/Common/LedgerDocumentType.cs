using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum LedgerDocumentType {
		Standard = 0,
		[Description("Standard Detail")]
		StandardDetail = 1,
		Reconciliation = 2,
		[Description("Reconciliation Detail")]
		ReconciliationDetail = 3
	}
}