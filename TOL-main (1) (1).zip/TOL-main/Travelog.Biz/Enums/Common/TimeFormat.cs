﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum TimeFormat {
        [Description("12 Hour")]
        Standard = 0,
        [Description("24 Hour")]
        Military = 1
    }
}