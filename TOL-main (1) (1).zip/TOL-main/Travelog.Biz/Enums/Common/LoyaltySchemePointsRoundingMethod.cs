﻿namespace Travelog.Biz.Enums {
    public enum LoyaltySchemePointsRoundingMethod {
        None = 0,
        Down = 1,
        Up = 2,
        Nearest = 3,
        Banker = 4
    }
}