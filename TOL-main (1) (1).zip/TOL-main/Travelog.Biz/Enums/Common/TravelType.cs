﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum TravelType {
        None = -1,
        Flight = 0,
        Hotel = 1,
        Insurance = 2,
        [Description("Car Rental")]
        CarRental = 3,
        Tours = 4,
        Cruises = 5,
        Rail = 6,
        Package = 7,
        [Description("Departure Tax")]
        DepartureTax = 8,
        [Description("Foreign Currency")]
        ForeignCurrency = 9,
        [Description("Additional Fees")]
        AdditionalFees = 10,
        [Description("Cancellation Fee")]
        CancellationFee = 11,
        [Description("Courier Fees")]
        CourierFees = 12,
        [Description("Visa Fees")]
        VisaFees = 13,
        [Description("Passport Fees")]
        PassportFees = 14,
        Other = 15,
        [Description("Not Included in Booking")]
        NotIncluded = 20,
    }
}
