﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum DocumentComment {
        Normal = 0,
        [Description("Alternate 1")]
        Alternate1 = 1,
        [Description("Alternate 2")]
        Alternate2 = 2,
        [Description("Alternate 3")]
        Alternate3 = 3,
        [Description("Alternate 4")]
        Alternate4 = 4
    }
}