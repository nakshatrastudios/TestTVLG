﻿namespace Travelog.Biz.Enums {
    public enum Position {
        Left = 0,
        Right = 1
    }
}