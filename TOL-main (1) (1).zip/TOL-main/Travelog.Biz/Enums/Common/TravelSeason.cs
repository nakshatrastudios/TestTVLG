﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum TravelSeason {
        [Description("Not Specified")]
        NotSpecified = 0,
        Low = 1,
        Shoulder = 2,
        High = 3
    }
}