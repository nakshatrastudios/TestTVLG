﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum MatchedTxnsReportOption {
        [Description("Exclude All")]
        ExcludeAll = 0,
        [Description("Current Period")]
        CurrentPeriod = 1,
        [Description("Up To Period 1")]
        UpToPeriod1 = 2,
        [Description("Up To Period 2")]
        UpToPeriod2 = 3,
        [Description("Include All")]
        IncludeAll = 4
    }
}