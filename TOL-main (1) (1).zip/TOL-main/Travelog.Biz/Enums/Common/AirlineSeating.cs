﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum AirlineSeating {
		[Description("Front - Aisle")]
		FrontAisle = 0,
		[Description("Front - Window")]
		FrontWindow = 1,
		[Description("Middle - Aisle")]
		MiddleAisle = 2,
		[Description("Middle - Window")]
		MiddleWindow = 3,
		[Description("Rear - Aisle")]
		RearAisle = 4,
		[Description("Rear - Window")]
		RearWindow = 5,
		[Description("Bulkhead - Aisle")]
		BulkheadAisle = 6,
		[Description("Bulkhead - Window")]
		BulkheadWindow = 7,
		[Description("Bulkhead - Centre")]
		BulkheadCentre = 8
	}
}