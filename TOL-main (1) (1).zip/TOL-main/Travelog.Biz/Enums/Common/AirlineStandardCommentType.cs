﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum AirlineStandardCommentType {
        [Description("E-Ticket Baggage")]
        ETicketBaggage = 0,
        [Description("E-Ticket Check-In")]
        ETicketCheckIn = 1,
        [Description("E-Ticket Footer")]
        ETicketFooter = 2
    }
}