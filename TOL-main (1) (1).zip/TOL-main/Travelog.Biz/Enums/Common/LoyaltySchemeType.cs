﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum LoyaltySchemeType {
        [Description("Fixed - Once Only")]
        FixedOnce = 0,
        [Description("Fixed - Daily")]
        FixedDaily = 1,
        [Description("Percentage of Distance")]
        PercentageDistance = 2,
        [Description("Percentage of Value")]
        PercentageValue = 3
    }
}