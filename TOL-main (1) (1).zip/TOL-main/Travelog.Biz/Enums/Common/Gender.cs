﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum Gender {
        [Description("Not Specified")]
        NotSpecified = 0,
        Female = 1,
        Male = 2,
        Other = 3
    }
}