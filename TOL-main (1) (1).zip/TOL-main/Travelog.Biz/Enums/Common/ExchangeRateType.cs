﻿namespace Travelog.Biz.Enums {
    public enum ExchangeRateType {
        Fixed = 0,
        Relative = 1
    }
}