
namespace Travelog.Biz.Enums {
	public enum FormOfPaymentClass {
		NotSpecified = 0,
		CreditCardTravelCard = 1,
		Net = 2,
		Gross = 3,
		Other = 4
	}
}
