﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum IssuedDocumentType {
        None = -1,
        Quote = 0,
        Confirmation = 1,
        Itinerary = 2,
        [Description("Client Statement")]
        ClientStatement = 3,
        [Description("Debtor Statement")]
        DebtorStatement = 4,
        Invoice = 5,
        Receipt = 6,
        Voucher = 7,
        Other = 8,
        [Description("Personal Statement")]
        PersonalStatement = 9,
        [Description("Trial Balance")]
        TrialBalance = 10
    }
}