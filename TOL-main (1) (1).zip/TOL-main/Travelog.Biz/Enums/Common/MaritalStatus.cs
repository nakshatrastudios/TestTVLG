﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum MaritalStatus {
        [Description("Not Specified")]
        NotSpecified = 0,
        Single = 1,
        Married = 2,
        [Description("De facto")]
        Defacto = 3,
        Separated = 4,
        Divorced = 5,
        Widowed = 6
    }
}