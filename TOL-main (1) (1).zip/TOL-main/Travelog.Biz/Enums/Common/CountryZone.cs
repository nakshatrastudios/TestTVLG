﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum CountryZone {
        International = 0,
        Domestic = 1,
        [Description("Short-Haul International")]
        ShortHaulInternational = 2
    }
}