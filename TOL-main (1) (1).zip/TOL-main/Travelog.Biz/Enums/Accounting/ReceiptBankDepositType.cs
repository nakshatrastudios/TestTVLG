﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum ReceiptBankDepositType {
		[Description("Not Deposited")]
		NotDeposited = -3,
		[Description("Bank Deposits")]
		BankDeposits = -2,
		[Description("All Deposits")]
		AllDeposits = -1,
		None = 0
	}
}