﻿namespace Travelog.Biz.Enums {
	public enum TaxAuditReportGroup {
		TaxExemptSales = 0,
		TaxApplicableSales = 1,
		TaxApplicablePurchases = 2,
		Salary = 3,
		PAYEG = 4
	}
}