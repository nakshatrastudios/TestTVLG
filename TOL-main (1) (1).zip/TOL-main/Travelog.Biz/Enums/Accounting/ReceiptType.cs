﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum ReceiptType {
		[Description("All Document Types")]
		All = -1,
		Receipt = 0,
		Refund = 1,
		[Description("Voucher Commission")]
		VoucherCommission = 2,
		[Description("Other Commission")]
		OtherCommission = 3,
		Debtor = 4,
		Admin = 5,
		Transfer = 6
	}
}
