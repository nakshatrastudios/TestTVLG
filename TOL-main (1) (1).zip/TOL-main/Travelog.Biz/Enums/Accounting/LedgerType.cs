﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum LedgerType {
		[Description("Current Account Only")]
		CurrentAccountOnly = -1,
		None = 0,
		[Description("Client Ledger")]
		ClientLedger = 1,
		[Description("Debtor Ledger")]
		DebtorLedger = 2,
		[Description("Creditor Ledger")]
		CreditorLedger = 3,
		[Description("General Ledger")]
		GeneralLedger = 4
	}
}