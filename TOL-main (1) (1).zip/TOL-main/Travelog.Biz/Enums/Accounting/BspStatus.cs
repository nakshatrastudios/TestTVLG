using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum BspStatus {
		None = DocumentCombinedStatus.None,
		Open = DocumentCombinedStatus.Open,
		Paid = DocumentCombinedStatus.DepositedPaid,
		Reversed = DocumentCombinedStatus.Reversed,
		Reversal = DocumentCombinedStatus.Reversal,
		[Description("Missing Open Docs")]
		MissingOpenDocuments = 5,
		[Description("No Auto-Agency CC")]
		NoAutoAgencyCc = 6
	}
}