using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum NonBspStatus {
		None = DocumentCombinedStatus.None,
		Open = DocumentCombinedStatus.Open,
		Paid = DocumentCombinedStatus.DepositedPaid,
		Reversed = DocumentCombinedStatus.Reversed,
		Reversal = DocumentCombinedStatus.Reversal,
		[Description("No Auto-Agency CC")]
		NoAutoAgencyCc = 5
	}
}