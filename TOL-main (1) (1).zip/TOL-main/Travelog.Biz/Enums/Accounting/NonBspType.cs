﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum NonBspType {
		[Description("All Document Types")]
		All = -1,
		[Description("Non-BSP")]
		NonBsp = 0,
		Refund = 1,
		Other = 2,
		Admin = 3,
		[Description("Agency CC")]
		AgencyCC = 4
	}
}