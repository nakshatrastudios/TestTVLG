﻿namespace Travelog.Biz.Enums {
    public enum TransactionUpdateType {
        SingleRow = 0,
        Bulk = 1,
        None = 2
    }
}