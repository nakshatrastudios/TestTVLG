namespace Travelog.Biz.Enums {
	public enum BspAgentType {
		All = 0,
		Bsp = 1,
		NonBsp = 2,
		BspOrNonBsp = 3,
		NeitherBspNorNonBsp = 4
	}
}