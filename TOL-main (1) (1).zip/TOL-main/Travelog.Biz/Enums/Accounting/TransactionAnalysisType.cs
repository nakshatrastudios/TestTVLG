﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum TransactionAnalysisType {
        All = 0,
        [Description("Sales Analysis")]
        SalesAnalysis = 1,
        [Description("Tax Audit Report")]
        TaxAuditReport = 2,
        [Description("Sales Analysis & Tax Audit Report")]
        SalesAnalysisAndTaxAuditReport = 3
    }
}