﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum ReceiptTypeExt {
		[Description("None")]
		None = -1,
		Receipt = 0,
		[Description("Refund Receipt")]
		Refund = 1,
		[Description("Voucher Commission")]
		VoucherCommission = 2,
		[Description("Other Commission")]
		OtherCommission = 3,
		[Description("Debtor Receipt")]
		Debtor = 4,
		[Description("Admin Receipt")]
		Admin = 5,
		[Description("Transfer Receipt")]
		Transfer = 6
	}
}
