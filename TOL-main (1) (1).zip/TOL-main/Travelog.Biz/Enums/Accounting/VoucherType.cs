﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum VoucherType {
		None = -1,
		[Description("Pre-Paid")]
		PrePaid = 0,
		[Description("Paid Direct")]
		PaidDirect = 1,
		Billback = 2,
		[Description("Billback to Client")]
		BillbackClientDirect = 3
	}
}