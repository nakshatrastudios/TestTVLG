using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum ReportSourceAccounting {
		Adjustments = 0,
		[Description("Bank Reconciliation")]
		BankReconciliation = 1,
		[Description("Tax Audit")]
		TaxAudit = 2
	}
}