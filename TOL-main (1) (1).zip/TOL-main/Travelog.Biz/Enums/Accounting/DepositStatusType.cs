﻿namespace Travelog.Biz.Enums {
    public enum DepositStatusType {
        Default = 0,
        Deposited = 1,
        Paid = 2,
        Excluded = 3
    }
}