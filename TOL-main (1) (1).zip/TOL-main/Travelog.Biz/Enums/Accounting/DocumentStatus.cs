﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum DocumentStatus {
		None = -1,
		Open = 0,
		[Description("Deposited/Paid")]
		DepositedPaid = 1,
		Closed = 2
	}
}