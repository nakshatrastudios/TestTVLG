﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum AccountType {
		[Description("All Account Types")]
		None = -1,
		Client = 0,
		Debtor = 1,
		Creditor = 2,
		[Description("General Ledger")]
		GeneralLedger = 3,
	}
}