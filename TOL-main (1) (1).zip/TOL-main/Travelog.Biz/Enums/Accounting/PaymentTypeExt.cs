﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum PaymentTypeExt {
		[Description("None")]
		None = -1,
		[Description("Supplier Payment")]
		SupplierPayment = 0,
		[Description("Client Refund")]
		ClientRefund = 1,
		[Description("BSP Return")]
		BspReturn = 2,
		[Description("Non-BSP Return")]
		NonBspReturn = 3,
		[Description("Admin Payment")]
		Admin = 4
	}
}
