﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum TransactionType {
		[Description("All Transaction Types")]
		All = -1,
		Receipt = 0,
		[Description("BSP Return")]
		Bsp = 1,
		[Description("Non-BSP Return")]
		NonBsp = 2,
		Payment = 3,
		Invoice = 4,
		Adjustment = 5,
		Journal = 6,
		[Description("Credit Note")]
		CreditNote = 7
	}
}