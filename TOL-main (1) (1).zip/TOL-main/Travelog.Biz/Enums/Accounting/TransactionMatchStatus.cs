﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum TransactionMatchStatus {
        None = 0,
        Partial = 1,
        Matched = 2,
        [Description("Auto-Matched")]
        AutoMatched = 3
    }
}