﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum AllocationQueryType {
        Report = 0,
        [Description("Debtor Receipt")]
        DebtorReceipt = 1,
        [Description("Credit Allocation")]
        CreditAllocation = 2
    }
}