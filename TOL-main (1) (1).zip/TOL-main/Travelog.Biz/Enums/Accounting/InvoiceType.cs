﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum InvoiceType {
		[Description("All Document Types")]
		All = -1,
		Invoice = 0,
		[Description("Credit Note")]
		CreditNote = 1
	}
}