
using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum TransactionDateOption {
		[Description("Transaction Date")]
		TxnDate = 0,
		[Description("Departure Date")]
		DepartureDate = 1
	}
}