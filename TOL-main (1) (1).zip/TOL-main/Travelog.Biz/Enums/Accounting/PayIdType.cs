using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum PayIdType {
        Phone = 0,
        Email = 1,
        [Description("Org ID")]
        OrganisationId = 2,
        [Description("ABN or ACN")]
        BusinessNo = 3
    }
}