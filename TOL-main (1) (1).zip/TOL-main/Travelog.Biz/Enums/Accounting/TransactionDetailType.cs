﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum TransactionDetailType {
		Normal = 0,
		[Description("Exclude from Sales Analysis")]
		ExcludeFromSalesAnalysis = 1,
		Discount = 2,
		Markup = 3,
		[Description("Commission Only")]
		CommissionOnly = 4,
		[Description("Merchant Fee")]
		MerchantFee = 5,
		[Description("Merchant Fee Reduced Commission")]
		MerchantFeeReducedCommission = 6,
		[Description("Cancellation Fee")]
		CancellationFee = 7,
		[Description("Tax Audit Commission Only")]
		TaxAuditCommissionOnly = 8
	}
}
