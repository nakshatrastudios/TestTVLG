namespace Travelog.Biz.Enums {
	public enum PaymentClass {
		PaidToAgency = 0,
		PaidDirect = 1
	}
}