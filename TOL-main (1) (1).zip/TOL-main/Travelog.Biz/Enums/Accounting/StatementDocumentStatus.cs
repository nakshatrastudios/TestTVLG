﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum StatementDocumentStatus {
        None = 0,
        [Description("Not Deposited/Not Banked")]
        NotDepositedNotBanked = 1,
        [Description("Deposited/Not Banked")]
        DepositedNotBanked = 2,
        [Description("To Be Deposited/Not Banked")]
        ToBeDepositedNotBanked = 3,
        [Description("To Be Deposited/To Be Banked")]
        ToBeDepositedToBeBanked = 4,
        [Description("Deposited/To Be Banked")]
        DepositedToBeBanked = 5,
        [Description("Deposited/Banked")]
        DepositedBanked = 6
    }
}