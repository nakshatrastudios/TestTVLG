﻿namespace Travelog.Biz.Enums {
	public enum SupplierCommissionType {
		None = 0,
		Creditor = 1
	}
}