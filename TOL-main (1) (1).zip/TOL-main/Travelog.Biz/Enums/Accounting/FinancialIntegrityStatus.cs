﻿namespace Travelog.Biz.Enums {
    public enum FinancialIntegrityStatus {
        Unknown = 0,
        Passed = 1,
        Warning = 2,
        Failed = 3
    }
}