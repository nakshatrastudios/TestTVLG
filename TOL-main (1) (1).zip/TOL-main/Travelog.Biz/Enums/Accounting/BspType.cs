﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum BspType {
		[Description("All Document Types")]
		All = -1,
		[Description("BSP")]
		Bsp = 0,
		Refund = 1,
		[Description("ADM")]
		Adm = 2,
		[Description("ACM")]
		Acm = 3,
		Exchange = 4,
		Conjunction = 5,
		[Description("Free of Charge")]
		Free = 6,
		Void = 7,
		[Description("ADM (no analysis)")]
		AdmNoAnalysis = 8,
		[Description("ACM (no analysis)")]
		AcmNoAnalysis = 9,
		[Description("Agency CC")]
		AgencyCC = 10
	}
}