using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum SalesAnalysisPeriodType {
        [Description("Current Month")]
        CurrentMonth = 0,
        [Description("Previous Month")]
        PreviousMonth = 1,
        [Description("Fiscal Year")]
        FiscalYear = 2,
        [Description("Calendar Year")]
        CalendarYear = 3,
        [Description("Custom View")]
        CustomView = 4
    }
}