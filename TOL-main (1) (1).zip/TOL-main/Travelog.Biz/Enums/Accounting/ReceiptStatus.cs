using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum ReceiptStatus {
		None = DocumentCombinedStatus.None,
		Open = DocumentCombinedStatus.Open,
		Deposited = DocumentCombinedStatus.DepositedPaid,
		Closed = DocumentCombinedStatus.Closed,
		Reversed = DocumentCombinedStatus.Reversed,
		Reversal = DocumentCombinedStatus.Reversal,
		[Description("No Auto-Loyalty Scheme")]
		NoAutoLoyaltyScheme = 5,
		[Description("No Auto-Commission")]
		NoAutoOtherCommission = 6,
		[Description("No Auto-Transfer")]
		NoAutoTransfer = 7
	}
}