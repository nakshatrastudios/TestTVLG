﻿namespace Travelog.Biz.Enums {
    public enum ReversalStatus {
        None = 0,
        Reversed = 1,
        Reversal = 2
    }
}
