using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum DocumentCombinedStatus {
		None = DocumentStatus.None,
		Open = DocumentStatus.Open,
		[Description("Deposited/Paid")]
		DepositedPaid = DocumentStatus.DepositedPaid,
		Closed = DocumentStatus.Closed,
		Reversed = 3,
		Reversal = 4
	}
}