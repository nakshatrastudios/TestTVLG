﻿namespace Travelog.Biz.Enums {
	public enum BankReconciliationReportType {
		None = 0,
		BankStatement = 1,
		CashBook = 2,
		Reconciliation = 3
	}
}