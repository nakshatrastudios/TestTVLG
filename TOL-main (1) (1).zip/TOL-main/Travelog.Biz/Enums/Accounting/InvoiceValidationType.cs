﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum InvoiceValidationType {
		None = 0,
		[Description("Display Warning")]
		DisplayWarning = 1,
		[Description("Prevent Creation")]
		PreventCreation = 2
	}
}