namespace Travelog.Biz.Enums {
    public enum SessionExpiryStatus {
        None = 0,
        ExpiredNotNotified = 1,
        ExpiredNotified = 2
    }
}