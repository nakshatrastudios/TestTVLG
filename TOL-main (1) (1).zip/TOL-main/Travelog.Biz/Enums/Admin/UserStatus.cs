
namespace Travelog.Biz.Enums {
	public enum UserStatus {
		Ok = 0,
        CustomerNotAuthorised = 1,
		NoAgencySelected = 2,
		ForceSignOut = 3,
		MultipleSignIns = 4,
		PasswordChangeReqd = 5
	}
}