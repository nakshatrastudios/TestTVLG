﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum AgencyMode {
        [Description("Simple Mode (limit of one agency per Debtor or Creditor)")]
        Simple = 0,
        [Description("Extended Mode (multiple agencies per Debtor or Creditor)")]
        Extended = 1
    }
}