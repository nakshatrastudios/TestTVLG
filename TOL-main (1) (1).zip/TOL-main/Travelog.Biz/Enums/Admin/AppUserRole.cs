﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum AppUserRole {
		None = 0,
		[Description("System Administrator")]
		SystemAdministrator = 1,
		[Description("Company Administrator")]
		CompanyAdministrator = 2,
		Accounts = 3,
		[Description("User Team Leader")]
		UserTeamLeader = 4,
		[Description("User Senior")]
		UserSenior = 5,
		User = 6
	}
}