using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum TwoFactorAuthenticationMethod {
        None = 0,
        [Description("Google Authenticator")]
		GoogleAuthenticator = 1,
		[Description("Email Authenticator")]
		EmailAuthenticator = 2
	}
}