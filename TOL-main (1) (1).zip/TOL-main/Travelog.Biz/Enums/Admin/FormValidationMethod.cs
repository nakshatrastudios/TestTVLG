﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum FormValidationMethod {
		[Description("Validate on form submission")]
		ValidateOnSubmit = 0,
		[Description("Validate each form field when it loses the focus")]
		ValidateOnBlur = 1
	}
}