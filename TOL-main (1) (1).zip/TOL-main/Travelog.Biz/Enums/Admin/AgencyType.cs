﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum AgencyType {
        [Description("Consolidated GL")]
        ConsolidatedGL = 0,
        [Description("Multi-Agency GL Single Balance Sheet")]
        MultiAgencyGLSingle = 1,
        [Description("Multi-Agency GL Individual Balance Sheet")]
        MultiAgencyGLIndividual = 2
    }
}