﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum AccessLevel {
		[Description("Not Authorised")]
		NotAuthorised = 0,
		[Description("Read-Only")]
		ReadOnly = 1,
		[Description("Read/Write")]
		ReadWrite = 2
	}
}