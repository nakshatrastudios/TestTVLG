﻿namespace Travelog.Biz.Enums {
    public enum CustomerStatus {
		Active = 0,
		Inactive = 1,
		Suspended = 2
	}
}
