namespace Travelog.Biz.Enums {
	public enum CustomerAccountStatus {
		Current = 0,
		Overdue = 1,
		Locked = 2
	}
}