﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum CustomerContactType {
		[Description("Billing & technical issues are managed by Company")]
		Company = 0,
		[Description("Billing and technical issues are managed by Agency Head Office")]
		AgencyHeadOffice = 1
	}
}