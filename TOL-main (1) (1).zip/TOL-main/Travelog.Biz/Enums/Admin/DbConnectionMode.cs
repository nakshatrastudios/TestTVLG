﻿namespace Travelog.Biz.Enums {
    public enum DbConnectionMode {
        Development = 0,
        Staging = 1,
        Production = 2
    }
}