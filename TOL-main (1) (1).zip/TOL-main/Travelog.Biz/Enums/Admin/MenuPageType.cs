﻿namespace Travelog.Biz.Enums {
    public enum MenuPageType {
        Undefined = 0,
        Receipt = 1,
        Bsp = 2,
        NonBsp = 3,
        Payment = 4,
        Invoice = 5,
        Journal = 6,
        Adjustment = 7
    }
}