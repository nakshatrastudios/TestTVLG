﻿namespace Travelog.Biz.Enums {
    public enum CustomerTransactionApprovalStatus {
        NotApproved = 0,
        Approved = 1,
        ApprovedAndEmailed = 2
    }
}