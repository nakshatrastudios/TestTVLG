﻿namespace Travelog.Biz.Enums {
	public enum CustomerTransactionStatus {
		Open = 0,
		Closed = 1,
		Failed = 2
	}
}