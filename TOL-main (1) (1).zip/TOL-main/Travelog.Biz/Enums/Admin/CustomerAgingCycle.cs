﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum CustomerAgingCycle {
        None = 0,
        Overdue = 1,
        [Description("Payable Now")]
        PayableNow = 2
    }
}