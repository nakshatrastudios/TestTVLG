﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum CustomerTransactionType {
		Subscription = 0,
        [Description("Online Payment")]
        OnlinePayment = 1,
        [Description("Paypal Payment")]
        PaypalPayment = 2,
        [Description("Direct Deposit")]
        DirectDeposit = 3,
		Payment = 4,
        [Description("Mail/Phone Payment")]
        MailPhonePayment = 5,
        [Description("Recurring Payment")]
        RecurringPayment = 6,
		Refund = 7,
		Adjustment = 8,
        [Description("Concurrent User Change")]
        ConcurrentUserChange = 9,
		Invoice = 10,
        [Description("Credit Note")]
        CreditNote = 11,
        [Description("Account Deactivated")]
        AccountDeactivated = 12,
        [Description("Account Reactivated")]
        AccountReactivated = 13,
        [Description("Account Suspended")]
        AccountSuspended = 14,
        [Description("Suspension Lifted")]
        SuspensionLifted = 15
	}
}