﻿namespace Travelog.Biz.Enums {
    public enum BillingCycle {
		Monthly = 0,
		Quarterly = 1,
		Annual = 2
	}
}