﻿namespace Travelog.Biz.Enums {
    public enum CustomerType {
        TravelogDev = -21,
        TravelogDevTest1 = -22,
        TravelogDevTest2 = -23,
        TravelogDevTest3 = -24,
        TravelogDevTest4 = -25,
        TravelogDevTest5 = -26,
        TravelogDevTest6 = -27,
        TravelogDevTest7 = -28,
        TravelogDevTest8 = -29,
        TravelogDevTest9 = -30,
        TravelogStaging = -11,
        TravelogStagingTest1 = -12,
        TravelogStagingTest2 = -13,
        TravelogStagingTest3 = -14,
        TravelogStagingTest4 = -15,
        TravelogStagingTest5 = -16,
        TravelogStagingTest6 = -17,
        TravelogStagingTest7 = -18,
        TravelogStagingTest8 = -19,
        TravelogStagingTest9 = -20,
        Customer = 0,
        TravelogProd = 1
    }
}