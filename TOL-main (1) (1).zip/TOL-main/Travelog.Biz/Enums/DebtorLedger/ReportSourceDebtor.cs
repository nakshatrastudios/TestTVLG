using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum ReportSourceDebtor {
		[Description("Trial Balance")]
		TrialBalance = 0,
		[Description("Debtor Statements")]
		DebtorStatements = 1
	}
}