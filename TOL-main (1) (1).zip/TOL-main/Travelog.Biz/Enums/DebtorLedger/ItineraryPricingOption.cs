﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum ItineraryPricingOption {
        No = 0,
        Yes = 1,
        [Description("Head Debtor")]
        HeadDebtor = 2
    }
}