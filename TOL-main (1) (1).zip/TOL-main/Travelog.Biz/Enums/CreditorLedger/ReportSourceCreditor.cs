using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum ReportSourceCreditor {
		[Description("Trial Balance")]
		TrialBalance = 0,
		[Description("BSP Returns")]
		BspReturns = 1
	}
}