﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum AddressPrintOption {
        [Description("Not Specified")]
        NotSpecified = 0,
        [Description("When Appropriate")]
        WhenAppropriate = 1,
        Never = 2,
        Always = 3
    }
}