﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum SeatStatus {
        [Description("Not Specified")]
        NotSpecified = 0,
        Confirmed = 1,
        [Description("On Request")]
        OnRequest = 2,
        [Description("Waitlisted")]
        Waitlisted = 3,
        [Description("Cannot Confirm")]
        CannotConfirm = 4,
        [Description("No Show")]
        NoShow = 5
    }
}