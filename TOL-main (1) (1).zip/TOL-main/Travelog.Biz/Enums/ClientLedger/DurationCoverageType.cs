﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum DurationCoverageType {
        [Description("Day(s)")]
        Days = 0,
        [Description("Night(s)")]
        Nights = 1
    }
}