﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum SurchargeType {
        Medical = 0,
        Items = 1,
        Other = 2,
        Age = 3,
        Excess = 4,
        [Description("Incoming Traveller")]
        IncomingTraveller = 5
    }
}