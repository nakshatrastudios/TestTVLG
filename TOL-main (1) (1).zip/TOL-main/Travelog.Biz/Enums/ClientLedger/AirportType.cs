﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum AirportType {
		International = 0,
		Domestic = 1,
		[Description("Not Specified")]
		NotSpecified = 2
	}
}