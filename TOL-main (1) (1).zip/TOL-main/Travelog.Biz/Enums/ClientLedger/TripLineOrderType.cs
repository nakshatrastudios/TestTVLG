namespace Travelog.Biz.Enums {
	public enum TripLineOrderType {
		None = 0,
		Up = 1,
		Down = 2,
		StartDate = 3
	}
}