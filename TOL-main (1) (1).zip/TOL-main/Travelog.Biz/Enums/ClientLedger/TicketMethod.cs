﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum TicketMethod {
        Hand = 0,
        Machine = 1,
        [Description("E-Ticket")]
        ETicket = 2
    }
}