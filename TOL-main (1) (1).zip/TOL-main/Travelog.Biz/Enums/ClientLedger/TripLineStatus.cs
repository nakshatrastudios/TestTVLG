﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum TripLineStatus{
        [Description("Old Entry")]
        OldEntry = 0,
        Entry = 1,
        Booked = 2,
        Invoiced = 3,
        [Description("Part Paid")]
        PartPaid = 4,
        Paid = 5,
        [Description("Invoiced/Part Paid")]
        InvoicedPartPaid = 6,
        [Description("Invoiced/Paid")]
        InvoicedPaid = 7,
        [Description("Invoiced/Reversed")]
        InvoicedReversed = 8,
        [Description("Paid/Reversed")]
        PaidReversed = 9
    }
}