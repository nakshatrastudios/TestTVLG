namespace Travelog.Biz.Enums {
	public enum ServiceTypeRateBasisBase {
		NotSpecified = -1,
		AccommodationPerPerson = 1,
		AccommodationPerRoom = 2,
		AccommodationPackage = 3,
		AirPerPerson = 4,
		AirPerDay = 5,
		AirPackage = 6,
		CruisePerCruise = 7,
		CruisePerPerson = 8,
		InsurancePerPerson = 9,
		InsurancePerDay = 10,
		InsurancePackage = 11,
		TourPerDay = 12,
		TourPerTour = 13,
		TransportPerDay = 14,
		TransportPackage = 15,
		OtherLandPerPerson = 16,
		OtherLandPerService = 17,
		OtherLandPackage = 18
	}
}