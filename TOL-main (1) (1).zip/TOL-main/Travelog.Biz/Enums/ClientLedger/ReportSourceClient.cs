using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum ReportSourceClient {
		[Description("Trial Balance")]
		TrialBalance = 0
	}
}