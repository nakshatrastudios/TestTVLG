﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum BaggageUnit {
        [Description("pc")]
        Piece = 0,
        [Description("kg")]
        Kilogram = 1,
        [Description("lb")]
        Pound = 2
    }
}