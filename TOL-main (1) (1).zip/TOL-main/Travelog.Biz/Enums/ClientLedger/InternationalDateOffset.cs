﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum InternationalDateOffset {
        [Description("-2")]
        MinusTwo = -2,
        [Description("-1")]
        MinusOne = -1,
        [Description("No")]
        None = 0,
        [Description("+1")]
        PlusOne = 1,
        [Description("+2")]
        PlusTwo = 2
    }
}