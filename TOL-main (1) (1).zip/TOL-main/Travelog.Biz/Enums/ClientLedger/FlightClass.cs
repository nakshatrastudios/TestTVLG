﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum FlightClass {
        First = 0,
        Business = 1,
        Economy = 2,
        Epic = 3,
        Thrifty = 4,
        Other = 5,
        [Description("Super Thrifty")]
        SuperThrifty = 6
    }
}