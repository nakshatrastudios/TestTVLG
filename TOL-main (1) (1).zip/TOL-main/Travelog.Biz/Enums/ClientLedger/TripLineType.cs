﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum TripLineType {
		All = 0,
		Air = 1,
		Accommodation = 2,
		Transport = 3,
		Cruise = 4,
		Tour = 5,
		[Description("Other Land")]
		OtherLand = 6,
		Insurance = 7,
		Remark = 8,
		[Description("Foreign Currency")]
		ForeignCurrency = 9,
		[Description("Service Fee")]
		ServiceFee = 10,
		[Description("Other Inclusion")]
		OtherInclusion = 11
	}
}