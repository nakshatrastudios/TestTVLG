﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum SurchargeRateType {
        [Description("Fixed Amount")]
        FixedAmount = 0,
        [Description("Per Item Rate")]
        PerItemRate = 1
    }
}