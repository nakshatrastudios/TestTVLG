﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum BspEntryType {
        Ticket = 0,
        Refund = 1,
        Exchange = 2,
        [Description("EMD")]
        Emd = 3
    }
}