﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum PassengerType {
        [Description("Not Specified")]
        NotSpecified = -1,
        Adult = 0,
        Child = 1,
        Infant = 2,
        Senior = 3,
        Student = 4,
        Youth = 5,
        Other = 6
    }
}