﻿namespace Travelog.Biz.Enums {
    public enum ServiceFeePaymentType {
        Supplier = 0,
        Agency = 1
    }
}