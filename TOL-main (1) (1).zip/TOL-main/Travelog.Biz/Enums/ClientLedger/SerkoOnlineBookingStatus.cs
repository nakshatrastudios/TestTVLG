﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum SerkoOnlineBookingStatus {
        [Description("Not Specified")]
        NotSpecified = -1,
        Quoted = 1,
        Booked = 2,
        Cancelled = 3,
        Authorised = 5,
        Ticketed = 6
    }
}