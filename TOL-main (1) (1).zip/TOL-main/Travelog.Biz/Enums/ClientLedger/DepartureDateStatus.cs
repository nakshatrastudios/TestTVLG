﻿namespace Travelog.Biz.Enums {
    public enum DepartureDateStatus {
        Normal = 0,
        Open = 1,
        ARNK = 2
    }
}