﻿namespace Travelog.Biz.Enums {
    public enum ClientAccountType {
        Client = 0,
        Debtor = 1
    }
}