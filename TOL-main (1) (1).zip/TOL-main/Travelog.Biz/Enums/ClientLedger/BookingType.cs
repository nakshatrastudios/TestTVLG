﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum BookingType {
        [Description("Not Specified")]
        NotSpecified = -1,
        [Description("Travel Agency")]
        TravelAgency = 0,
        Online = 1,
        [Description("Travel Agency Takeover")]
        TravelAgencyTakeover = 2
    }
}