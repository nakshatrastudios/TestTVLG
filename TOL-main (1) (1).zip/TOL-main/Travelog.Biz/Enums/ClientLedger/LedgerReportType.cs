using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum LedgerReportType {
		[Description("Trial Balance")]
		TrialBalance = 0,
		[Description("BSP Returns")]
		BspReturn = 1
	}
}