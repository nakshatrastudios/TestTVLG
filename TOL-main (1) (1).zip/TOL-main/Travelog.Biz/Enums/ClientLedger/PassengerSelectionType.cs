namespace Travelog.Biz.Enums {
	public enum PassengerSelectionType {
		None = 0,
		Trip = 1,
		ProfileOrTrip = 2,
		ProfileOrTripNoFilter = 3,
		Embedded = 4,
		EmbeddedNoFilter = 5
	}
}