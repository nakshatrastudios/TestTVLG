using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum ValueType {
		[Description("Net (Excludes Taxes)")]
		Net = 0,
		[Description("Gross (Includes Taxes)")]
		Gross = 1
	}
}