﻿namespace Travelog.Biz.Enums {
    public enum DocumentType {
        Passport = 0,
        Visa = 1
    }
}