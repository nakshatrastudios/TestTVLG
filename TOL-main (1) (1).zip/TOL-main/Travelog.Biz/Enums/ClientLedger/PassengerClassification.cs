﻿namespace Travelog.Biz.Enums {
    public enum PassengerClassification {
        Group = 0,
        Individual = 1
    }
}