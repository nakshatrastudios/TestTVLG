﻿namespace Travelog.Biz.Enums {
    public enum TripType {
        International = 0,
        Domestic = 1
    }
}