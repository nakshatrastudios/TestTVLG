﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum TripStatus {
        [Description("Not Specified")]
        NotSpecified = 0,
        Confirmed = 1,
        [Description("On Request")]
        OnRequest = 2,
        Waitlisted = 3,
        Pending = 4,
        [Description("Cannot Confirm")]
        CannotConfirm = 5,
        [Description("Not Available")]
        NotAvailable = 6
    }
}