﻿using System.ComponentModel;

namespace Travelog.Biz.Enums {
    public enum ContactMethod {
        [Description("Not Specified")]
        NotSpecified = 0,
        [Description("Internal Note")]
        InternalNote = 1,
        Email = 2,
        Phone = 3,
        [Description("SMS")]
        Sms = 4,
        [Description("In Person")]
        InPerson = 5
    }
}