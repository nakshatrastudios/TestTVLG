using System.ComponentModel;

namespace Travelog.Biz.Enums {
	public enum CrsImportOption {
		[Description("Update pricing (exclude trip lines where supplier has been paid)")]
		UpdatePricingExcludingPaid = 0,
		[Description("Update pricing (include trip lines where supplier has been paid)")]
		UpdatePricingIncludingPaid = 1,
		[Description("Do not update pricing")]
		DoNotUpdatePricing = 2
	}
}