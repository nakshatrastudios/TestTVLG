﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Travelog.Biz.Dao;
using Travelog.Biz.Enums;

namespace Travelog.Biz {
    public static class AppSettings {
        private static readonly object padlock = new object();
        public static IConfiguration Configuration { get; private set; }

        public static void Initialize(IConfiguration configuration) {
            Configuration = configuration;
        }

        private static List<AppSettingModel> Settings { get; } = new List<AppSettingModel>();

        public static AppSettingModel Setting(int customerId) {
            if (customerId == 0)
                return new AppSettingModel();

            var setting = Settings.SingleOrDefault(t => t.CustomerId == customerId);

            if (setting == null) {
                using (var context = new AppMainContext(customerId, true)) {
                    InitSettings(context, customerId);
                }
            }

            return setting ?? new AppSettingModel();
        }

        private static void InitSettings(AppMainContext context, int customerId) {
            lock (padlock) {
                var setting = CustomerSettings.Setting(customerId);

                if (!Settings.Any(t => t.CustomerId == setting.CustomerId))
                    Settings.Add(new AppSettingModel { CustomerId = setting.CustomerId });

                var appSetting = Settings.Single(t => t.CustomerId == setting.CustomerId);

                foreach (var row in context.AppSetting.ToList()) {
                    switch (row.Id) {
                        case "BspCreditorId":
                            appSetting.BspCreditorId = int.Parse(row.Value);
                            break;
                        case "AgentCommissionDiscountReasonId":
                            appSetting.AgentCommissionDiscountReasonId = int.Parse(row.Value);
                            break;
                        case "GeneralLedgerReportSign":
                            appSetting.GeneralLedgerReportSign = (ReportSign)int.Parse(row.Value);
                            break;
                        case "TaxAuditReportPeriodId":
                            appSetting.TaxAuditReportPeriod = (ReportPeriod)int.Parse(row.Value);
                            break;
                        case "FiscalPeriodAutoCloseOffMonths":
                            appSetting.FiscalPeriodAutoCloseOffMonths = int.Parse(row.Value);
                            break;
                        case "ExchangeRateMargin":
                            appSetting.ExchangeRateMargin = decimal.Parse(row.Value);
                            break;
                        case "AmexFormOfPaymentId":
                            appSetting.AmexFormOfPaymentId = int.Parse(row.Value);
                            break;
                        case "DinersClubFormOfPaymentId":
                            appSetting.DinersClubFormOfPaymentId = int.Parse(row.Value);
                            break;
                        case "MastercardFormOfPaymentId":
                            appSetting.MastercardFormOfPaymentId = int.Parse(row.Value);
                            break;
                        case "VisaFormOfPaymentId":
                            appSetting.VisaFormOfPaymentId = int.Parse(row.Value);
                            break;
                        case "LoyaltySchemeFormOfPaymentId":
                            appSetting.LoyaltySchemeFormOfPaymentId = int.Parse(row.Value);
                            break;
                        case "CrsDefaultProviderId":
                            appSetting.CrsDefaultProviderId = int.Parse(row.Value);
                            break;
                        case "CrsDomesticAirSaleTypeId":
                            appSetting.CrsDomesticAirSaleTypeId = int.Parse(row.Value);
                            break;
                        case "CrsInternationalAirSaleTypeId":
                            appSetting.CrsInternationalAirSaleTypeId = int.Parse(row.Value);
                            break;
                        case "CrsDomesticAccommodationSaleTypeId":
                            appSetting.CrsDomesticAccommodationSaleTypeId = int.Parse(row.Value);
                            break;
                        case "CrsInternationalAccommodationSaleTypeId":
                            appSetting.CrsInternationalAccommodationSaleTypeId = int.Parse(row.Value);
                            break;
                        case "CrsDomesticTransportSaleTypeId":
                            appSetting.CrsDomesticTransportSaleTypeId = int.Parse(row.Value);
                            break;
                        case "CrsInternationalTransportSaleTypeId":
                            appSetting.CrsInternationalTransportSaleTypeId = int.Parse(row.Value);
                            break;
                        case "CrsAmadeusCreditorAirId":
                            appSetting.CrsAmadeusCreditorAirId = int.Parse(row.Value);
                            break;
                        case "CrsAmadeusCreditorLandId":
                            appSetting.CrsAmadeusCreditorLandId = int.Parse(row.Value);
                            break;
                        case "CrsAmadeusSupplierAirId":
                            appSetting.CrsAmadeusSupplierAirId = int.Parse(row.Value);
                            break;
                        case "CrsAmadeusSupplierLandId":
                            appSetting.CrsAmadeusSupplierLandId = int.Parse(row.Value);
                            break;
                        case "CrsAmadeusDomesticServiceFeeTypeId":
                            appSetting.CrsAmadeusDomesticServiceFeeTypeId = int.Parse(row.Value);
                            break;
                        case "CrsAmadeusInternationalServiceFeeTypeId":
                            appSetting.CrsAmadeusInternationalServiceFeeTypeId = int.Parse(row.Value);
                            break;
                        case "CrsCalypsoSandboxUrl":
                            appSetting.CrsCalypsoSandboxUrl = row.Value;
                            break;
                        case "CrsEtgCreditorAirId":
                            appSetting.CrsEtgCreditorAirId = int.Parse(row.Value);
                            break;
                        case "CrsEtgCreditorLandId":
                            appSetting.CrsEtgCreditorLandId = int.Parse(row.Value);
                            break;
                        case "CrsEtgSupplierAirId":
                            appSetting.CrsEtgSupplierAirId = int.Parse(row.Value);
                            break;
                        case "CrsEtgSupplierLandId":
                            appSetting.CrsEtgSupplierLandId = int.Parse(row.Value);
                            break;
                        case "CrsEtgDomesticServiceFeeTypeId":
                            appSetting.CrsEtgDomesticServiceFeeTypeId = int.Parse(row.Value);
                            break;
                        case "CrsEtgInternationalServiceFeeTypeId":
                            appSetting.CrsEtgInternationalServiceFeeTypeId = int.Parse(row.Value);
                            break;
                        case "CrsGalileoCreditorAirId":
                            appSetting.CrsGalileoCreditorAirId = int.Parse(row.Value);
                            break;
                        case "CrsGalileoCreditorLandId":
                            appSetting.CrsGalileoCreditorLandId = int.Parse(row.Value);
                            break;
                        case "CrsGalileoSupplierAirId":
                            appSetting.CrsGalileoSupplierAirId = int.Parse(row.Value);
                            break;
                        case "CrsGalileoSupplierLandId":
                            appSetting.CrsGalileoSupplierLandId = int.Parse(row.Value);
                            break;
                        case "CrsGalileoDomesticServiceFeeTypeId":
                            appSetting.CrsGalileoDomesticServiceFeeTypeId = int.Parse(row.Value);
                            break;
                        case "CrsGalileoInternationalServiceFeeTypeId":
                            appSetting.CrsGalileoInternationalServiceFeeTypeId = int.Parse(row.Value);
                            break;
                        case "EwayCustomerClientKey":
                            appSetting.EwayCustomerClientKey = row.Value;
                            break;
                        case "EwaySandboxCustomerClientKey":
                            appSetting.EwaySandboxCustomerClientKey = row.Value;
                            break;
                        case "EwayCustomerApiKey":
                            appSetting.EwayCustomerApiKey = row.Value;
                            break;
                        case "EwaySandboxCustomerApiKey":
                            appSetting.EwaySandboxCustomerApiKey = row.Value;
                            break;
                        case "EwayCustomerPassword":
                            appSetting.EwayCustomerPassword = row.Value;
                            break;
                        case "EwaySandboxCustomerPassword":
                            appSetting.EwaySandboxCustomerPassword = row.Value;
                            break;
                        case "CostToClientIncludesNonComm":
                            appSetting.CostToClientIncludesNonComm = bool.Parse(row.Value);
                            break;
                        case "CountryCode":
                            appSetting.CountryId = context.Country.SingleOrDefault(t => t.Code == row.Value)?.Id ?? -1;
                            appSetting.CountryCode = row.Value;
                            break;
                        case "CurrencyCode":
                            appSetting.CurrencyId = context.Currency.SingleOrDefault(t => t.Code == row.Value)?.Id ?? -1;
                            appSetting.CurrencyCode = row.Value;
                            break;
                        case "SerkoOnline":
                            appSetting.SerkoOnline = bool.Parse(row.Value);
                            break;
                        case "GridSelectionReceiptDetailIds":
                            appSetting.GridSelectionReceiptDetailIds = row.Value.Length == 0 ? new int[] { } : row.Value.Split(',').Select(int.Parse).ToArray();
                            break;
                        case "GridSelectionBspIds":
                            appSetting.GridSelectionBspIds = row.Value.Length == 0 ? new int[] { } : row.Value.Split(',').Select(int.Parse).ToArray();
                            break;
                        case "GridSelectionNonBspIds":
                            appSetting.GridSelectionNonBspIds = row.Value.Length == 0 ? new int[] { } : row.Value.Split(',').Select(int.Parse).ToArray();
                            break;
                        case "GridSelectionPaymentDetailIds":
                            appSetting.GridSelectionPaymentDetailIds = row.Value.Length == 0 ? new int[] { } : row.Value.Split(',').Select(int.Parse).ToArray();
                            break;
                        case "GridSelectionInvoiceDetailIds":
                            appSetting.GridSelectionInvoiceDetailIds = row.Value.Length == 0 ? new int[] { } : row.Value.Split(',').Select(int.Parse).ToArray();
                            break;
                    }
                }
            }
        }

        public static bool UpdateAll(AppMainContext context, int customerId) {
            var appSetting = Settings.Single(t => t.CustomerId == customerId);
            bool isUpdated = false;

            foreach (var row in context.AppSetting.ToList()) {
                switch (row.Id) {
                    case "BspCreditorId":
                        if (Update(context, row.Id, appSetting.BspCreditorId))
                            isUpdated = true;

                        break;
                    case "AgentCommissionDiscountReasonId":
                        if (Update(context, row.Id, appSetting.AgentCommissionDiscountReasonId))
                            isUpdated = true;

                        break;
                    case "GeneralLedgerReportSign":
                        if (Update(context, row.Id, appSetting.GeneralLedgerReportSign))
                            isUpdated = true;

                        break;
                    case "TaxAuditReportPeriodId":
                        if (Update(context, row.Id, appSetting.TaxAuditReportPeriod))
                            isUpdated = true;

                        break;
                    case "FiscalPeriodAutoCloseOffMonths":
                        if (Update(context, row.Id, appSetting.FiscalPeriodAutoCloseOffMonths))
                            isUpdated = true;

                        break;
                    case "ExchangeRateMargin":
                        if (Update(context, row.Id, appSetting.ExchangeRateMargin))
                            isUpdated = true;

                        break;
                    case "AmexFormOfPaymentId":
                        if (Update(context, row.Id, appSetting.AmexFormOfPaymentId))
                            isUpdated = true;

                        break;
                    case "DinersClubFormOfPaymentId":
                        if (Update(context, row.Id, appSetting.DinersClubFormOfPaymentId))
                            isUpdated = true;

                        break;
                    case "MastercardFormOfPaymentId":
                        if (Update(context, row.Id, appSetting.MastercardFormOfPaymentId))
                            isUpdated = true;

                        break;
                    case "VisaFormOfPaymentId":
                        if (Update(context, row.Id, appSetting.VisaFormOfPaymentId))
                            isUpdated = true;

                        break;
                    case "LoyaltySchemeFormOfPaymentId":
                        if (Update(context, row.Id, appSetting.LoyaltySchemeFormOfPaymentId))
                            isUpdated = true;

                        break;
                    case "CrsDefaultProviderId":
                        if (Update(context, row.Id, appSetting.CrsDefaultProviderId))
                            isUpdated = true;

                        break;
                    case "CrsDomesticAirSaleTypeId":
                        if (Update(context, row.Id, appSetting.CrsDomesticAirSaleTypeId))
                            isUpdated = true;

                        break;
                    case "CrsInternationalAirSaleTypeId":
                        if (Update(context, row.Id, appSetting.CrsInternationalAirSaleTypeId))
                            isUpdated = true;

                        break;
                    case "CrsDomesticAccommodationSaleTypeId":
                        if (Update(context, row.Id, appSetting.CrsDomesticAccommodationSaleTypeId))
                            isUpdated = true;

                        break;
                    case "CrsInternationalAccommodationSaleTypeId":
                        if (Update(context, row.Id, appSetting.CrsInternationalAccommodationSaleTypeId))
                            isUpdated = true;

                        break;
                    case "CrsDomesticTransportSaleTypeId":
                        if (Update(context, row.Id, appSetting.CrsDomesticTransportSaleTypeId))
                            isUpdated = true;

                        break;
                    case "CrsInternationalTransportSaleTypeId":
                        if (Update(context, row.Id, appSetting.CrsInternationalTransportSaleTypeId))
                            isUpdated = true;

                        break;
                    case "CrsAmadeusCreditorAirId":
                        if (Update(context, row.Id, appSetting.CrsAmadeusCreditorAirId))
                            isUpdated = true;

                        break;
                    case "CrsAmadeusCreditorLandId":
                        if (Update(context, row.Id, appSetting.CrsAmadeusCreditorLandId))
                            isUpdated = true;

                        break;
                    case "CrsAmadeusSupplierAirId":
                        if (Update(context, row.Id, appSetting.CrsAmadeusSupplierAirId))
                            isUpdated = true;

                        break;
                    case "CrsAmadeusSupplierLandId":
                        if (Update(context, row.Id, appSetting.CrsAmadeusSupplierLandId))
                            isUpdated = true;

                        break;
                    case "CrsAmadeusDomesticServiceFeeTypeId":
                        if (Update(context, row.Id, appSetting.CrsAmadeusDomesticServiceFeeTypeId))
                            isUpdated = true;

                        break;
                    case "CrsAmadeusInternationalServiceFeeTypeId":
                        if (Update(context, row.Id, appSetting.CrsAmadeusInternationalServiceFeeTypeId))
                            isUpdated = true;

                        break;
                    case "CrsCalypsoSandboxUrl":
                        if (Update(context, row.Id, appSetting.CrsCalypsoSandboxUrl))
                            isUpdated = true;

                        break;
                    case "CrsEtgCreditorAirId":
                        if (Update(context, row.Id, appSetting.CrsEtgCreditorAirId))
                            isUpdated = true;

                        break;
                    case "CrsEtgCreditorLandId":
                        if (Update(context, row.Id, appSetting.CrsEtgCreditorLandId))
                            isUpdated = true;

                        break;
                    case "CrsEtgSupplierAirId":
                        if (Update(context, row.Id, appSetting.CrsEtgSupplierAirId))
                            isUpdated = true;

                        break;
                    case "CrsEtgSupplierLandId":
                        if (Update(context, row.Id, appSetting.CrsEtgSupplierLandId))
                            isUpdated = true;

                        break;
                    case "CrsEtgDomesticServiceFeeTypeId":
                        if (Update(context, row.Id, appSetting.CrsEtgDomesticServiceFeeTypeId))
                            isUpdated = true;

                        break;
                    case "CrsEtgInternationalServiceFeeTypeId":
                        if (Update(context, row.Id, appSetting.CrsEtgInternationalServiceFeeTypeId))
                            isUpdated = true;

                        break;
                    case "CrsGalileoCreditorAirId":
                        if (Update(context, row.Id, appSetting.CrsGalileoCreditorAirId))
                            isUpdated = true;

                        break;
                    case "CrsGalileoCreditorLandId":
                        if (Update(context, row.Id, appSetting.CrsGalileoCreditorLandId))
                            isUpdated = true;

                        break;
                    case "CrsGalileoSupplierAirId":
                        if (Update(context, row.Id, appSetting.CrsGalileoSupplierAirId))
                            isUpdated = true;

                        break;
                    case "CrsGalileoSupplierLandId":
                        if (Update(context, row.Id, appSetting.CrsGalileoSupplierLandId))
                            isUpdated = true;

                        break;
                    case "CrsGalileoDomesticServiceFeeTypeId":
                        if (Update(context, row.Id, appSetting.CrsGalileoDomesticServiceFeeTypeId))
                            isUpdated = true;

                        break;
                    case "CrsGalileoInternationalServiceFeeTypeId":
                        if (Update(context, row.Id, appSetting.CrsGalileoInternationalServiceFeeTypeId))
                            isUpdated = true;

                        break;
                    case "CrsGalileoUseProduction":
                        if (Update(context, row.Id, appSetting.CrsGalileoUseProduction))
                            isUpdated = true;

                        break;
                    case "EwayCustomerClientKey":
                        if (Update(context, row.Id, appSetting.EwayCustomerClientKey))
                            isUpdated = true;

                        break;
                    case "EwaySandboxCustomerClientKey":
                        if (Update(context, row.Id, appSetting.EwaySandboxCustomerClientKey))
                            isUpdated = true;

                        break;
                    case "EwayCustomerApiKey":
                        if (Update(context, row.Id, appSetting.EwayCustomerApiKey))
                            isUpdated = true;

                        break;
                    case "EwaySandboxCustomerApiKey":
                        if (Update(context, row.Id, appSetting.EwaySandboxCustomerApiKey))
                            isUpdated = true;

                        break;
                    case "EwayCustomerPassword":
                        if (Update(context, row.Id, appSetting.EwayCustomerPassword))
                            isUpdated = true;

                        break;
                    case "EwaySandboxCustomerPassword":
                        if (Update(context, row.Id, appSetting.EwaySandboxCustomerPassword))
                            isUpdated = true;

                        break;
                    case "CostToClientIncludesNonComm":
                        if (Update(context, row.Id, appSetting.CostToClientIncludesNonComm))
                            isUpdated = true;

                        break;
                    case "CountryCode":
                        if (Update(context, row.Id, appSetting.CountryCode))
                            isUpdated = true;

                        break;
                    case "CurrencyCode":
                        if (Update(context, row.Id, appSetting.CurrencyCode))
                            isUpdated = true;

                        break;
                    case "SerkoOnline":
                        if (Update(context, row.Id, appSetting.SerkoOnline))
                            isUpdated = true;

                        break;
                    case "GridSelectionReceiptDetailIds":
                        if (Update(context, row.Id, appSetting.GridSelectionReceiptDetailIds))
                            isUpdated = true;

                        break;
                    case "GridSelectionBspIds":
                        if (Update(context, row.Id, appSetting.GridSelectionBspIds))
                            isUpdated = true;

                        break;
                    case "GridSelectionNonBspIds":
                        if (Update(context, row.Id, appSetting.GridSelectionNonBspIds))
                            isUpdated = true;

                        break;
                    case "GridSelectionPaymentDetailIds":
                        if (Update(context, row.Id, appSetting.GridSelectionPaymentDetailIds))
                            isUpdated = true;

                        break;
                    case "GridSelectionInvoiceDetailIds":
                        if (Update(context, row.Id, appSetting.GridSelectionInvoiceDetailIds))
                            isUpdated = true;

                        break;
                }
            }

            if (isUpdated)
                InitSettings(context, customerId);

            return isUpdated;
        }

        private static bool Update(AppMainContext context, string settingId, object value) {
            lock (padlock) {
                var appSetting = context.AppSetting.Find(settingId);

                switch (settingId) {
                    default:
                        if (appSetting.Value == value.ToStringExt())
                            return false;

                        appSetting.Value = value.ToStringExt();
                        break;
                    case "GeneralLedgerReportSign":
                        if (appSetting.Value == ((int)(ReportSign)value).ToString())
                            return false;

                        appSetting.Value = ((int)(ReportSign)value).ToString();
                        break;
                    case "TaxAuditReportPeriodId":
                        if (appSetting.Value == ((int)(ReportPeriod)value).ToString())
                            return false;

                        appSetting.Value = ((int)(ReportPeriod)value).ToString();
                        break;
                    case "ExchangeRateMargin":
                        if (appSetting.Value == value.ToStringExt())
                            return false;

                        appSetting.Value = Math.Round(decimal.Parse(value.ToString()), 4).ToString();
                        break;
                    case "GridSelectionReceiptDetailIds":
                    case "GridSelectionBspIds":
                    case "GridSelectionNonBspIds":
                    case "GridSelectionPaymentDetailIds":
                    case "GridSelectionInvoiceDetailIds":
                        var array = value as int[];

                        if (value == null || array.Length == 0) {
                            if (appSetting.Value?.Length == 0)
                                return false;

                            appSetting.Value = string.Empty;
                        }
                        else {
                            string values = string.Join(",", array);

                            if (appSetting.Value == values)
                                return false;

                            appSetting.Value = values;
                        }

                        break;
                }

                return context.Save(appSetting);
            }
        }

        public static bool Clear(int customerId) {
            var setting = Settings.SingleOrDefault(t => t.CustomerId == customerId);

            if (setting != null) {
                lock (padlock) {
                    Settings.Remove(setting);
                }

                return true;
            }

            return false;
        }

        public static string GetConnectionString(int customerId) {
            return (Configuration?.GetConnectionString("travelogonline") ?? ConnectionStringLocal).Replace("{0}", CustomerSettings.Setting(customerId).DbName);
        }

        public static string AppTitle => "Travelog Online";
        public static bool IsLocal { get { return Configuration?.GetConnectionString("travelogonline-admin").Contains("localhost") ?? true; } }
        public static bool IsDevelopmentMode => DbConnectionMode != DbConnectionMode.Production;
        public static DbConnectionMode DbConnectionMode => Configuration == null ? DbConnectionMode.Staging : Configuration["AppSettings:DbConnectionMode"] == "Production" ? DbConnectionMode.Production : Configuration["AppSettings:DbConnectionMode"] == "Staging" ? DbConnectionMode.Staging : DbConnectionMode.Development;
        public static string HomeUrl => DbConnectionMode == DbConnectionMode.Production ? ProductionUrl : DbConnectionMode == DbConnectionMode.Staging ? StagingUrl : DevUrl;
        public static string ProductionUrl => "https://travelog.online";
        public static string StagingUrl => "https://travelogonline-staging.azurewebsites.net";
        public static string DevUrl => "https://travelogonline-dev.azurewebsites.net";
        public static string StaticFilesUrl => IsDevelopmentMode ? "/wwwroot" : AppConstants.CdnUrl;
        public static string ServiceDeskUrl => "https://travelog.atlassian.net/servicedesk/customer/user/requests?page=1&reporter=all&statuses=open";
        public static string ServiceDeskCustomersUrl => "https://admin.atlassian.com/s/43f1b9c6-224f-43cc-9448-a39585779625/jira-service-desk/portal-only-customers";
        public static int ManagementDatabaseId => DbConnectionMode == DbConnectionMode.Development ? (int)CustomerType.TravelogDev : DbConnectionMode == DbConnectionMode.Staging ? (int)CustomerType.TravelogStaging : (int)CustomerType.TravelogProd;
        public static string HomePage => "/";
        public static string ErrorPage => "/Error";
        public static string ResourceNotFoundPage => "/ResourceNotFound";
        public static string NotAuthorisedPage => "/NotAuthorised";
        public static string MyAccountPage => "/Account/MyAccount";
        public static string SignInPage => "/Account/SignIn";
        public static string SignOutPage => "/Account/SignOut";
        public static string ProcessSignInPage => "/Account/ProcessSignIn";
        public static string ChangePasswordPage => "/Account/ChangePassword";
        public static string RecoverPasswordPage => "/Account/RecoverPassword";
        public static string ResetPasswordPage => "/Account/ResetPassword";
        public static string DocumentationPage => "/Account/Documentation";
        public static string RequestSupportPage => "/Account/RequestSupport";
        public static string CustomerAccountPage => "/Admin/AccountManagement";
        public static string AmadeusDataFilePath => "App_Data/Amadeus/";
        public static string EmailFrom => "notifications@travelog.online";
        public static string EmailAccounts => "accounts@travelog.online";
        public static string EmailEnquiries => "info@travelog.online";
        public static string EmailErrors => "errors@travelog.online";
        public static string EmailServiceDesk => "servicedesk@travelog.online";
        public static string GoogleAccountSecretKeyPassword => "AEBZX-H:fnBo@6]]wBR8!L6GUNaC-*@z";
        public static Dictionary<string, string> CrsLocalTaxCodes => new Dictionary<string, string> { { "AUS", "UO" }, { "NZL", "NZ" }, { "PNG", "UN" } };
        public static int CustomerPaymentTermsDays => 7;
        public static int CustomerPastDueDays => 14;
        public static decimal BalancePayableLimit => 0.99m;
        public static int PasswordExpirationDays => 180;
        public static string EwayPrincipalClientKey => "5sYW2OruikNjHMIbY+qWOo+Fdzn3cEyertMH+4lKaM06RTT7XuHjw0npAfXUpsooQmvcXVjY+HHBFzjYPMoQLX2QREEkl2NFl3PICkh9/b27r4agmniJ+VNn5/wi5TADewKJiLhY+S8C9LHvfZLWsZDxlf/JJ0JpOLfBZPeTM+C1oMEQTbQBIKSV6R8B6sFp6LSjs+QBY8LyZ1VxvM1yULb2kmwO7sAUoBvUKzJcNpyZooj4iGJssKWnvMuI0dYjWxCeSFKnIyA/4JUuQ4QocfkLl4uVIN4wzGeklrZv0gwopDkoGNebSJC9l1vyOsCy9XhDDf9nCXcZ65EyrmH6KQ==";
        public static string EwaySandboxPrincipalClientKey => "5sYW2OruikNjHMIbY+qWOo+Fdzn3cEyertMH+4lKaM06RTT7XuHjw0npAfXUpsooQmvcXVjY+HHBFzjYPMoQLX2QREEkl2NFl3PICkh9/b27r4agmniJ+VNn5/wi5TADewKJiLhY+S8C9LHvfZLWsZDxlf/JJ0JpOLfBZPeTM+C1oMEQTbQBIKSV6R8B6sFp6LSjs+QBY8LyZ1VxvM1yULb2kmwO7sAUoBvUKzJcNpyZooj4iGJssKWnvMuI0dYjWxCeSFKnIyA/4JUuQ4QocfkLl4uVIN4wzGeklrZv0gwopDkoGNebSJC9l1vyOsCy9XhDDf9nCXcZ65EyrmH6KQ==";
        public static string JiraServiceDeskUrl => "https://travelog.atlassian.net/rest/servicedeskapi";
        public static string JiraIssueUrl => "https://travelog.atlassian.net/rest/api/2/issue";
        public static string JiraUserName => "servicedesk@travelog.online";
        public static string JiraApiToken => "IU7gEkHPn0vLfYSHOc56E5E5";

        public static string[] SuperAdminUsers => new string[] {
            "ben@travelog.com.au",
            "darren@travelog.com.au",
            "martin@travelog.com.au",
            "sharon@travelog.com.au",
            "steve@travelog.com.au",
            "ben@travelog.online",
            "darren@travelog.online",
            "martin@travelog.online",
            "sharon@travelog.online",
            "steve@travelog.online"
        };

        public const string ErrorNotificationEmail = "info@travelog.online";

        public const string SystemAccountName = "azure-logic-app";
        public const string SystemAccountEmail = "system@travelog.online";
        public const string SystemAccountPassword = "scqzFO)Bv%*)85#FEbxr";

        public const string ConnectionStringLocal = "Server=localhost;Initial Catalog={0};Integrated Security=True;Enlist=True;Encrypt=False;MultipleActiveResultSets=True;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;Connect Timeout=600";
        public const string ConnectionStringLocalAdmin = "Server=localhost;Initial Catalog=travelogadmin;Integrated Security=True;Enlist=True;Encrypt=False;MultipleActiveResultSets=True;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;Connect Timeout=600";

        public class AppSettingModel {
            public int CustomerId { get; set; }
            public int BspCreditorId { get; set; }
            public int AgentCommissionDiscountReasonId { get; set; }
            public ReportSign GeneralLedgerReportSign { get; set; }
            public ReportPeriod TaxAuditReportPeriod { get; set; }
            public int FiscalPeriodAutoCloseOffMonths { get; set; }
            public decimal ExchangeRateMargin { get; set; }
            public int AmexFormOfPaymentId { get; set; }
            public int DinersClubFormOfPaymentId { get; set; }
            public int MastercardFormOfPaymentId { get; set; }
            public int VisaFormOfPaymentId { get; set; }
            public int LoyaltySchemeFormOfPaymentId { get; set; }
            public int CrsDefaultProviderId { get; set; }
            public int CrsDomesticAirSaleTypeId { get; set; }
            public int CrsInternationalAirSaleTypeId { get; set; }
            public int CrsDomesticAccommodationSaleTypeId { get; set; }
            public int CrsInternationalAccommodationSaleTypeId { get; set; }
            public int CrsDomesticTransportSaleTypeId { get; set; }
            public int CrsInternationalTransportSaleTypeId { get; set; }
            public int CrsAmadeusCreditorAirId { get; set; }
            public int CrsAmadeusSupplierAirId { get; set; }
            public int CrsAmadeusCreditorLandId { get; set; }
            public int CrsAmadeusSupplierLandId { get; set; }
            public int CrsAmadeusDomesticServiceFeeTypeId { get; set; }
            public int CrsAmadeusInternationalServiceFeeTypeId { get; set; }
            public string CrsCalypsoSandboxUrl { get; set; }
            public int CrsEtgCreditorAirId { get; set; }
            public int CrsEtgSupplierAirId { get; set; }
            public int CrsEtgCreditorLandId { get; set; }
            public int CrsEtgSupplierLandId { get; set; }
            public int CrsEtgDomesticServiceFeeTypeId { get; set; }
            public int CrsEtgInternationalServiceFeeTypeId { get; set; }
            public int CrsGalileoCreditorAirId { get; set; }
            public int CrsGalileoSupplierAirId { get; set; }
            public int CrsGalileoCreditorLandId { get; set; }
            public int CrsGalileoSupplierLandId { get; set; }
            public int CrsGalileoDomesticServiceFeeTypeId { get; set; }
            public int CrsGalileoInternationalServiceFeeTypeId { get; set; }
            public bool CrsGalileoUseProduction { get; set; }
            public string EwayCustomerApiKey { get; set; }
            public string EwayCustomerClientKey { get; set; }
            public string EwayCustomerPassword { get; set; }
            public string EwaySandboxCustomerApiKey { get; set; }
            public string EwaySandboxCustomerClientKey { get; set; }
            public string EwaySandboxCustomerPassword { get; set; }
            public int CountryId { get; set; }
            public string CountryCode { get; set; }
            public int CurrencyId { get; set; }
            public string CurrencyCode { get; set; }
            public bool CostToClientIncludesNonComm { get; set; }
            public bool SerkoOnline { get; set; }
            public int[] GridSelectionReceiptDetailIds { get; set; }
            public int[] GridSelectionBspIds { get; set; }
            public int[] GridSelectionNonBspIds { get; set; }
            public int[] GridSelectionPaymentDetailIds { get; set; }
            public int[] GridSelectionInvoiceDetailIds { get; set; }

            public string CultureName {
                get {
                    switch (CountryCode) {
                        default:
                            return "en-AU";
                        case "GBR":
                            return "en-GB";
                        case "NZL":
                            return "en-NZ";
                        case "USA":
                            return "en-US";
                    }
                }
            }
        }
    }
}