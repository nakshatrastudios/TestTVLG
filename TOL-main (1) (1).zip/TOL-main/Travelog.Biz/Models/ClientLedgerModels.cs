﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Enums;

namespace Travelog.Biz.Models {
	public class ClientReportSourceModel {
		public ReportSourceClient ReportSource { get; set; }
		public int CustomerId { get; set; }
		public string OutputType { get; set; }
		public string DefaultAgency { get; set; }

		[Display(Name = "Trip From")]
		public int? TripIdFrom { get; set; }

		[Display(Name = "Trip To")]
		public int? TripIdTo { get; set; }

		[Display(Name = "Report Date")]
		public DateTime? ReportDate { get; set; }

		[Display(Name = "Report Order")]
		public int? ReportOrderId { get; set; }

		[Display(Name = "Report Type")]
		public LedgerDocumentType? LedgerDocumentType { get; set; }

		[Display(Name = "Commission Type")]
		public Enums.ValueType? CommissionValueType { get; set; }

		[Display(Name = "Balances")]
		public TransactionBalanceType? TransactionBalanceType { get; set; }

		[Display(Name = "Departure Date")]
		public DateTime? DepartureDateFrom { get; set; }
		public DateTime? DepartureDateTo { get; set; }

		[Display(Name = "Txn Date")]
		public DateTime? TxnDateFrom { get; set; }
		public DateTime? TxnDateTo { get; set; }

		[Display(Name = "Open-Dated")]
		public bool IncludeOpenDated { get; set; }

		[Display(Name = "Trip From")]
		public string TripNoFrom { get; set; }

		[Display(Name = "Trip To")]
		public string TripNoTo { get; set; }

		[Display(Name = "Agencies")]
		public int[] AgencyIds { get; set; }

		[Display(Name = "Agents")]
		public int[] AgentIds { get; set; }

		[Display(Name = "Categories")]
		public int[] CategoryIds { get; set; }

		[Display(Name = "Classes")]
		public int[] ClassIds { get; set; }

		[Display(Name = "Consultants")]
		public int[] ConsultantIds { get; set; }

		[Display(Name = "Debtors")]
		public int[] DebtorIds { get; set; }

		[Display(Name = "Destinations")]
		public int[] DestinationIds { get; set; }

		[Display(Name = "Groups")]
		public int[] GroupIds { get; set; }

		[Display(Name = "Locations")]
		public int[] LocationIds { get; set; }

		[Display(Name = "Sources")]
		public int[] SourceIds { get; set; }

		[Display(Name = "Group")]
		public bool GroupByAgency { get; set; }

		[Display(Name = "Group")]
		public bool GroupByAgent { get; set; }

		[Display(Name = "Group")]
		public bool GroupByCategory { get; set; }

		[Display(Name = "Group")]
		public bool GroupByClass { get; set; }

		[Display(Name = "Group")]
		public bool GroupByConsultant { get; set; }

		[Display(Name = "Group")]
		public bool GroupByDebtor { get; set; }

		[Display(Name = "Group")]
		public bool GroupByDestination { get; set; }

		[Display(Name = "Group")]
		public bool GroupByGroup { get; set; }

		[Display(Name = "Group")]
		public bool GroupByLocation { get; set; }

		[Display(Name = "Group")]
		public bool GroupBySource { get; set; }

		[Display(Name = "New Page")]
		public bool AgencyNewPage { get; set; }

		[Display(Name = "New Page")]
		public bool AgentNewPage { get; set; }

		[Display(Name = "New Page")]
		public bool CategoryNewPage { get; set; }

		[Display(Name = "New Page")]
		public bool ClassNewPage { get; set; }

		[Display(Name = "New Page")]
		public bool ConsultantNewPage { get; set; }

		[Display(Name = "New Page")]
		public bool DebtorNewPage { get; set; }

		[Display(Name = "New Page")]
		public bool DestinationNewPage { get; set; }

		[Display(Name = "New Page")]
		public bool GroupNewPage { get; set; }

		[Display(Name = "New Page")]
		public bool LocationNewPage { get; set; }

		[Display(Name = "New Page")]
		public bool SourceNewPage { get; set; }

		[Display(Name = "Level")]
		public int? AgencyLevel { get; set; }

		[Display(Name = "Level")]
		public int? AgentLevel { get; set; }

		[Display(Name = "Level")]
		public int? CategoryLevel { get; set; }

		[Display(Name = "Level")]
		public int? ClassLevel { get; set; }

		[Display(Name = "Level")]
		public int? ConsultantLevel { get; set; }

		[Display(Name = "Level")]
		public int? DebtorLevel { get; set; }

		[Display(Name = "Level")]
		public int? DestinationLevel { get; set; }

		[Display(Name = "Level")]
		public int? GroupLevel { get; set; }

		[Display(Name = "Level")]
		public int? LocationLevel { get; set; }

		[Display(Name = "Level")]
		public int? SourceLevel { get; set; }

		public string CreationUser { get; set; }
		public DateTime CreationTime { get; set; }
	}

	public class ClientTrialBalanceReportModel {
		public int TripId { get; set; }
		public string TripNo { get; set; }
		public string FullName { get; set; }
		public DateTime DepartureDate { get; set; }
		public int AgencyId { get; set; }
		public string Agency { get; set; }
		public int AgentId { get; set; }
		public string Agent { get; set; }
		public int CategoryId { get; set; }
		public string Category { get; set; }
		public int ClassId { get; set; }
		public string Class { get; set; }
		public int ConsultantId { get; set; }
		public string Consultant { get; set; }
		public int DebtorId { get; set; }
		public string Debtor { get; set; }
		public int DestinationId { get; set; }
		public string Destination { get; set; }
		public int GroupId { get; set; }
		public string Group { get; set; }
		public int LocationId { get; set; }
		public string Location { get; set; }
		public int SourceId { get; set; }
		public string Source { get; set; }
		public decimal Commission { get; set; }
		public decimal CommissionGross { get; set; }
		public decimal AmountGross { get; set; }
		public decimal Debit { get; set; }
		public decimal Credit { get; set; }
		public decimal Balance { get; set; }
		public List<TransactionDetailReportModel> TransactionDetailReportList { get; set; }
	}

	public class QuoteReportModel {
		public int TripId { get; set; }
		public string TripNo { get; set; }
		public int QuoteNo { get; set; }
		public string TaxNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string Consultant { get; set; }
		public DateTime DepartureDate { get; set; }
		public string Passengers { get; set; }
		public string FullName { get; set; }
		public string Address { get; set; }
		public string MainCity { get; set; }
	}

	public class QuoteSubReportModel {
		public int PackageNo { get; set; }
		public decimal PackageTotal { get; set; }
		public decimal PackageGrandTotal { get; set; }
		public decimal TaxTotal { get; set; }
		public decimal DiscountTotal { get; set; }
        public decimal GrandTotal { get; set; }
		public string RemarksAfter { get; set; }
		public decimal AirTotal { get { return QuoteDetailSubReportList.Where(t => t.QuoteSubReportAirPassenger != null).Sum(t => t.QuoteSubReportAirPassenger.CostToClient); } }
		public decimal AccommodationTotal { get { return QuoteDetailSubReportList.Where(t => t.QuoteSubReportLand != null).Sum(t => t.QuoteSubReportLand.TripLineType == TripLineType.Accommodation.GetEnumDescription() ? t.QuoteSubReportLand.CostToClient : 0); } }
		public decimal TransportTotal { get { return QuoteDetailSubReportList.Where(t => t.QuoteSubReportLand != null).Sum(t => t.QuoteSubReportLand.TripLineType == TripLineType.Transport.GetEnumDescription() ? t.QuoteSubReportLand.CostToClient : 0); } }
		public decimal CruiseTotal { get { return QuoteDetailSubReportList.Where(t => t.QuoteSubReportLand != null).Sum(t => t.QuoteSubReportLand.TripLineType == TripLineType.Cruise.GetEnumDescription() ? t.QuoteSubReportLand.CostToClient : 0); } }
		public decimal TourTotal { get { return QuoteDetailSubReportList.Where(t => t.QuoteSubReportLand != null).Sum(t => t.QuoteSubReportLand.TripLineType == TripLineType.Tour.GetEnumDescription() ? t.QuoteSubReportLand.CostToClient : 0); } }
		public decimal OtherLandTotal { get { return QuoteDetailSubReportList.Where(t => t.QuoteSubReportLand != null).Sum(t => t.QuoteSubReportLand.TripLineType == TripLineType.OtherLand.GetEnumDescription() ? t.QuoteSubReportLand.CostToClient : 0); } }
		public decimal InsuranceTotal { get { return QuoteDetailSubReportList.Where(t => t.QuoteSubReportInsurance != null).Sum(t => t.QuoteSubReportInsurance.CostToClient + t.QuoteSubReportInsurance.TotalSurcharge); } }
		public decimal ForeignCurrencyTotal { get { return QuoteDetailSubReportList.Where(t => t.QuoteSubReportForeignCurrency != null).Sum(t => t.QuoteSubReportForeignCurrency.CostToClient); } }
		public decimal ServiceFeeTotal { get { return QuoteDetailSubReportList.Where(t => t.QuoteSubReportServiceFee != null).Sum(t => t.QuoteSubReportServiceFee.CostToClient); } }
		public decimal OtherInclusionTotal { get { return QuoteDetailSubReportList.Where(t => t.QuoteSubReportOtherInclusion != null).Sum(t => t.QuoteSubReportOtherInclusion.CostToClient); } }
		public List<QuoteDetailSubReportModel> QuoteDetailSubReportList { get; set; }
	}

	public class QuoteDetailSubReportModel {
        public TripLineType TripLineType { get; set; }
        public int SeqNo { get; set; }
        public QuoteSubReportAirPassengerReportModel QuoteSubReportAirPassenger { get; set; }
		public QuoteSubReportLandReportModel QuoteSubReportLand { get; set; }
		public QuoteSubReportInsuranceReportModel QuoteSubReportInsurance { get; set; }
		public QuoteSubReportForeignCurrencyReportModel QuoteSubReportForeignCurrency { get; set; }
		public QuoteSubReportServiceFeeReportModel QuoteSubReportServiceFee { get; set; }
		public QuoteSubReportOtherInclusionReportModel QuoteSubReportOtherInclusion { get; set; }
		public QuoteSubReportRemarkReportModel QuoteSubReportRemark { get; set; }
	}

	public class QuoteSubReportAirPassengerReportModel {
		public int PackageNo { get; set; }
		public string PassengerNames { get; set; }
		public decimal CostToClient { get; set; }
        public decimal MiscellaneousCharges { get; set; }
        public string Footer { get; set; }
		public List<QuoteSubReportAirSegmentReportModel> QuoteSubReportAirSegmentList { get; set; }
	}

	public class QuoteSubReportAirSegmentReportModel {
		public int TripLineId { get; set; }
		public string Flight { get; set; }
		public string Segments { get; set; }
		public string StartEndDate { get; set; }
		public string ClassDescription { get; set; }
		public int DepartureSegmentId { get; set; }
		public int ArrivalSegmentId { get; set; }
		public string Remarks { get; set; }
	}

	public class QuoteSubReportLandReportModel {
		public string TripLineType { get; set; }
		public string SupplierName { get; set; }
		public string SupplierAddress { get; set; }
		public string StartEndDate { get; set; }
		public string SupplierServiceDescription { get; set; }
		public string ServiceTypeRateBasisDescription { get; set; }
		public string Comments { get; set; }
		public string Remarks { get; set; }
		public decimal CostToClient { get; set; }
		public int PackageNo { get; set; }
	}

	public class QuoteSubReportInsuranceReportModel {
		public string PassengerNames { get; set; }
		public string SupplierName { get; set; }
		public string StartEndDate { get; set; }
		public string Plan { get; set; }
		public string PolicyType { get; set; }
		public string Coverage { get; set; }
		public string Remarks { get; set; }
		public decimal CostToClient { get; set; }
		public decimal TotalSurcharge { get; set; }
		public string TotalAmountDescription { get; set; }
		public int PackageNo { get; set; }
	}

	public class QuoteSubReportForeignCurrencyReportModel {
		public string SupplierName { get; set; }
		public string Description { get; set; }
		public string Remarks { get; set; }
		public decimal CostToClient { get; set; }
		public int PackageNo { get; set; }
	}

	public class QuoteSubReportServiceFeeReportModel {
		public string ServiceFee { get; set; }
		public string Description { get; set; }
		public string Remarks { get; set; }
		public decimal CostToClient { get; set; }
		public int PackageNo { get; set; }
	}

	public class QuoteSubReportOtherInclusionReportModel {
		public string Comments { get; set; }
		public string Description { get; set; }
		public string Remarks { get; set; }
		public decimal CostToClient { get; set; }
		public string Footer { get; set; }
		public int PackageNo { get; set; }
	}

	public class QuoteSubReportRemarkReportModel {
		public string Remark { get; set; }
		public int PackageNo { get; set; }
	}

	public class ConfirmationReportModel {
		public int TripId { get; set; }
		public string TripNo { get; set; }
		public int QuoteNo { get; set; }
		public string TaxNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string Consultant { get; set; }
		public DateTime DepartureDate { get; set; }
		public string FullName { get; set; }
		public string Address { get; set; }
		public string Passengers { get; set; }
		public string StandardComment { get; set; }
	}

	public class ConfirmationSubReportModel {
		public int PackageNo { get; set; }
		public int TripLineId { get; set; }
		public decimal PackageTotal { get; set; }
		public decimal DiscountTotal { get; set; }
		public decimal AgentCommissionTotal { get; set; }
        public decimal TaxTotal { get; set; }
		public decimal Total { get; set; }
		public string RemarksBefore { get; set; }
		public string RemarksAfter { get; set; }
		public bool PackageTaxApplies { get; set; }
		public List<ConfirmationDetailSubReportModel> ConfirmationDetailSubReportList { get; set; }
	}

	public class ConfirmationDetailSubReportModel {
		public int PackageNo { get; set; }
		public string TripLineType { get; set; }
		public int TripLineId { get; set; }
		public int TripLineAirSegmentId { get; set; }
		public DateTime StartDate { get; set; }
		public DateTime EndDate { get; set; }
		public string Header1 { get; set; }
		public string Header2 { get; set; }
		public string Footer { get; set; }
		public string DateRange { get; set; }
		public string Description { get; set; }
		public string Remarks { get; set; }
		public decimal CostToClient { get; set; }
		public bool IsRelatedRemark { get; set; }
		public decimal SeqNo { get; set; }
		public bool IsHeaderHidden { get { return (Header1.Length == 0 || Header1.Substring(4).Length == 0) && Header2.Length == 0; } }
	}

	public class TripItineraryReportModel {
        public virtual TripLine TripLine { get; set; }
        public int TripLineAirSegmentId { get; set; }
		public int TripLineAirPassengerId { get; set; }
		public decimal SeqNo { get; set; }
	}
}