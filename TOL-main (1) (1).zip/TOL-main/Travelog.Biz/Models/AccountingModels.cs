﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Linq;
using Travelog.Biz.Dao.Accounting;
using Travelog.Biz.Dao.ClientLedger;
using Travelog.Biz.Enums;

namespace Travelog.Biz.Models {
    public class ReceiptMerchantFeeModel {
        public int ReceiptDetailId { get; set; }
        public decimal MerchantFee { get; set; }
        public decimal MerchantFeeTax { get; set; }
    }

    public class ReceiptMerchantFeeTxnDetailModel {
		public Transaction Transaction { get; set; }
		public int DebtorId { get; set; }
        public int ClientAgencyId { get; set; }
        public int ClientReceiptDetailId { get; set; }
		public string DebtorReceiptNo { get; set; }
		public DateTime DebtorReceiptDate { get; set; }
		public string ClientReceiptNo { get; set; }
		public DateTime ClientReceiptDate { get; set; }
		public decimal Amount { get; set; }
		public decimal Tax { get; set; }
	}

    public class TransactionDetailAllocationModel {
        public long TransactionDetailOrAllocationId { get; set; }
        public int TransactionId { get; set; }
        public long TransactionDetailId { get; set; }
        public int TransactionRefId { get; set; }
        public int TransactionDetailRefId { get; set; }
        public TransactionType TransactionType { get; set; }
        public SignType SignType { get; set; }
        public decimal Amount { get; set; }
        public decimal MerchantFee { get; set; }
        public decimal MerchantFeeTax { get; set; }
        public string Reference { get; set; }
        public TransactionMatchStatus TransactionMatchStatus { get; set; }
        public bool IsMasterDocument { get; set; }
    }

    public class AccountingReportSourceModel {
		public ReportSourceAccounting ReportSource { get; set; }
		public string OutputType { get; set; }
		public int CustomerId { get; set; }
		public string DefaultAgency { get; set; }

		[Display(Name = "Report Type")]
		public LedgerDocumentType LedgerDocumentType { get; set; }

		[Display(Name = "Grouping")]
		public int? ReportGroupingId { get; set; }

		[Display(Name = "Document Date")]
		public DateTime? DateFrom { get; set; }

		[Display(Name = "Document Date")]
		public DateTime? DateTo { get; set; }

		[Display(Name = "Period")]
		public DateTime? PeriodTo { get; set; }

		[Display(Name = "Agency")]
		public int? AgencyId { get; set; }

		[Display(Name = "Bank Account")]
		public int? BankAccountId { get; set; }

		[Display(Name = "Statement From")]
		public int? BankAccountStatementIdFrom { get; set; }

		[Display(Name = "Statement To")]
		public int? BankAccountStatementIdTo { get; set; }

		[Display(Name = "Types")]
		public int[] AdjustmentTypeIds { get; set; }

		[Display(Name = "Consultants")]
		public int[] ConsultantIds { get; set; }

		[Display(Name = "Descending Date")]
		public bool DescendingDateOrder { get; set; }

		[Display(Name = "Unreconciled")]
		public bool UnreconciledOnly { get; set; }

		public string CreationUser { get; set; }
		public DateTime CreationTime { get; set; }
	}

	public class JournalReportModel {
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public DocumentStatus DocumentStatus { get; set; }
		public ReversalStatus ReversalStatus { get; set; }
		public decimal TotalDebit { get; set; }
		public decimal TotalCredit { get; set; }
		public decimal Balance { get; set; }
		public string CombinedStatusDescription { get { return string.Concat(DocumentStatus.GetEnumDescription(), ReversalStatus == ReversalStatus.None ? string.Empty : string.Concat("/", ReversalStatus.GetEnumDescription())); } }
		public List<JournalDetailReportModel> JournalDetailReportList { get; set; }
	}

	public class JournalDetailReportModel {
		public string AccountType { get; set; }
		public string AccountName { get; set; }
		public decimal? Debit { get; set; }
		public decimal? Credit { get; set; }
		public string Comments { get; set; }
	}

	public class AdjustmentReportModel {
		public string AdjustmentType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string DebitAccountName { get; set; }
		public string CreditAccountName { get; set; }
		public DebitCreditType DebitType { get; set; }
		public DebitCreditType CreditType { get; set; }
		public string Consultant { get; set; }
		public string Comments { get; set; }
		public decimal Amount { get; set; }
		public decimal Tax { get; set; }
		public string DebitTypeDescription { get { return DebitType.GetEnumDescription(); } }
		public string CreditTypeDescription { get { return CreditType.GetEnumDescription(); } }
	}

	public class BankStatementReconciliationReportModel {
		public int StatementId { get; set; }
		public int StatementNo { get; set; }
		public decimal StatementAmountArchived { get; set; }
		public decimal StatementOpeningBalance { get; set; }
		public decimal StatementClosingBalance { get; set; }
		public DateTime StatementOpeningDate { get; set; }
		public DateTime StatementClosingDate { get; set; }
		public decimal UnreconciledAmount { get; set; }
		public int BankAccountId { get; set; }
		public string BankAccountName { get; set; }
		public string BankAccountBranch { get; set; }
		public string BankAccountNo { get; set; }
		public string BankAccountDescription { get; set; }
		public int BankChartOfAccountId { get; set; }
		public string GeneralLedgerAccount { get; set; }
		public decimal BankOpeningBalance { get; set; }
		public decimal ExpectedBalance { get; set; }
		public List<BankStatementReconciliationDetailReportModel> BankStatementReconciliationDetailReportList { get; set; }
	}

	public class BankStatementReconciliationDetailReportModel {
		public string GroupHeaderDescription { get; set; }
		public string GroupFooterDescription { get; set; }
		public string DocumentNo { get; set; }
		public DateTime? DocumentDate { get; set; }
		public string Description { get; set; }
		public decimal? Debit { get; set; }
		public decimal? Credit { get; set; }
	}

	public class TransactionDetailReportModel {
		public long TransactionDetailAllocationId { get; set; }
		public string GroupHeader { get; set; }
		public string TransactionType { get; set; }
		public string DocumentType { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public DateTime FiscalPeriod { get; set; }
		public string FiscalPeriodName { get; set; }
		public string Reference { get; set; }
		public string Description { get; set; }
		public string ChartOfAccountCode { get; set; }
		public string ChartOfAccountName { get; set; }
		public string ChartOfAccount { get; set; }
		public string AccountName { get; set; }
		public string Payee { get; set; }
		public string SignType { get; set; }
		public decimal Commission { get; set; }
		public decimal CommissionTax { get; set; }
		public decimal CommissionGross { get; set; }
		public decimal NonCommissionable { get; set; }
		public decimal Tax { get; set; }
		public decimal TaxNet { get; set; }
		public decimal AmountGross { get; set; }
		public decimal AmountNet { get; set; }
		public bool IsMatched { get; set; }
		public DateTime DocumentMonth { get { return new DateTime(DocumentDate.Year, DocumentDate.Month, 1); } }
	}

	public class TransactionDetailPeriodReportModel {
		public TransactionDetailPeriodReportModel() {
			Period = new string[12];
			Row1Value = new decimal[12];
			Row2Value = new decimal[12];
			Row3Value = new decimal[12];
		}

		public string[] Period { get; set; }
		public decimal[] Row1Value { get; set; }
		public decimal[] Row2Value { get; set; }
		public decimal[] Row3Value { get; set; }
		public decimal YtdBalance { get; set; }
		public decimal PreviousYearBalance { get; set; }
	}

	public class SalesAnalysisReportModel {
		public long TransactionDetailId { get; set; }
		public TransactionType TransactionType { get; set; }
		public string DocumentType { get; set; }
		public string DocumentNo { get; set; }
		public string DocumentNoLink { get; set; }
		public DateTime DocumentDate { get; set; }
		public string Account { get; set; }
		public string AccountLink { get; set; }
		public string Airline { get; set; }
		public string Passenger { get; set; }
		public int PaxNo { get; set; }
		public decimal OfferedFare { get; set; }
		public string OfferedReason { get; set; }
		public DateTime? DepartureDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public string Reference { get; set; }
		public string Debtor { get; set; }
		public string Creditor { get; set; }
		public string Supplier { get; set; }
		public string SaleType { get; set; }
		public string DiscountReason { get; set; }
		public string Group { get; set; }
		public string Class { get; set; }
		public string Source { get; set; }
		public string Category { get; set; }
		public string Destination { get; set; }
		public string Region { get; set; }
		public string Location { get; set; }
		public string Agency { get; set; }
		public string Consultant { get; set; }
		public string Agent { get; set; }
		public decimal Commission { get; set; }
		public decimal Cash { get; set; }
		public decimal CashNonCommissionable { get; set; }
		public decimal CreditCard { get; set; }
		public decimal CreditCardNonCommissionable { get; set; }
		public decimal AmountGross { get { return Cash + CreditCard; } }
		public decimal NonCommissionable { get { return CashNonCommissionable + CreditCardNonCommissionable; } }
		public decimal AmountNet { get { return AmountGross + NonCommissionable - Commission; } }
		public decimal Yield { get { return Cash + CreditCard == 0 ? (Commission == 0 ? 0 : (Commission < 0 ? -1 : 1)) : Commission / (Cash + CreditCard); } }
		public string TransactionTypeDescription { get { return TransactionType.GetEnumDescription(); } }
		public string DocumentDateString { get { return DocumentDate.ToShortDateStringExt(); } }
		public string DepartureDateString { get { return DepartureDate == null ? string.Empty : ((DateTime)DepartureDate).ToShortDateStringExt(); } }
        public string ReturnDateString { get { return ReturnDate == null ? string.Empty : ((DateTime)ReturnDate).ToShortDateStringExt(); } }
    }

    public class ReceiptReportModel {
		public string ReceiptType { get; set; }
		public string TaxNo { get; set; }
		public string Consultant { get; set; }
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public decimal TotalAmount { get; set; }
		public decimal TotalTax { get; set; }
		public decimal DocumentTotal { get; set; }
		public string StandardComment { get; set; }
        public bool IsCustomer { get; set; }
        public List<ReceiptDetailReportModel> ReceiptDetailReportList { get; set; }
	}

	public class ReceiptDetailReportModel {
		public bool IsDebtor { get; set; }
		public string AccountName { get; set; }
		public string TripLine { get; set; }
		public string Reference { get; set; }
		public string FormOfPayment { get; set; }
		public string Comments { get; set; }
		public decimal Amount { get; set; }
		public bool IsCustomer { get; set; }
	}

	public class ReceiptBankDepositReportModel {
		public string DepositDate { get; set; }
		public string Agency { get; set; }
		public string BankAccountName { get; set; }
		public string BankAccountBranch { get; set; }
		public string BankAccountNo { get; set; }
		public List<ReceiptDetailBankDepositReportModel> ReceiptDetailBankDepositReportList { get; set; }
	}

	public class ReceiptDetailBankDepositReportModel {
		public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public string FormOfPaymentType { get; set; }
		public string AccountName { get; set; }
		public string PaymentDetails { get; set; }
		public decimal Amount { get; set; }
	}

	public class InvoiceReportModel {
		public string DocumentType { get; set; }
		public string TaxNo { get; set; }
		public string Code { get; set; }
		public string Debtor { get; set; }
		public string SubDebtor { get; set; }
		public string Address { get; set; }
		public string ContactName { get; set; }
        public string DocumentNo { get; set; }
		public DateTime DocumentDate { get; set; }
		public DateTime DepartureDate { get; set; }
		public string OrderNo { get; set; }
		public DateTime DateDue { get; set; }
		public string ForeignCurrency { get; set; }
		public decimal PackageTotal { get; set; }
		public decimal SubTotal { get; set; }
		public decimal DiscountTotal { get; set; }
		public decimal DiscountTaxTotal { get; set; }
		public decimal AgentCommissionTotal { get; set; }
		public decimal TotalTax { get; set; }
		public decimal TotalAmount { get; set; }
		public decimal ForeignCurrencyTotalAmount { get; set; }
		public string Passengers { get; set; }
		public string DepositDetails { get; set; }
		public string PaymentTerms { get; set; }
		public string PaymentOptions { get; set; }
		public string PayIdLabel { get; set; }
		public string PayId { get; set; }
		public string TravelPayUrl { get; set; }
		public string MintUrl { get; set; }
		public decimal BalanceDue { get; set; }
		public bool PackageTaxApplies { get; set; }
		public decimal AirTotal { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Air && t.PackageNo == 0).Sum(t => (decimal?)t.Amount) ?? 0; } }
		public decimal AirTotalTax { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Air && t.PackageNo == 0).Sum(t => (decimal?)t.Tax) ?? 0; } }
		public decimal AccommodationTotal { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Accommodation && t.PackageNo == 0).Sum(t => (decimal?)t.Amount) ?? 0; } }
		public decimal AccommodationTotalTax { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Accommodation && t.PackageNo == 0).Sum(t => (decimal?)t.Tax) ?? 0; } }
		public decimal TransportTotal { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Transport && t.PackageNo == 0).Sum(t => (decimal?)t.Amount) ?? 0; } }
		public decimal TransportTotalTax { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Transport && t.PackageNo == 0).Sum(t => (decimal?)t.Tax) ?? 0; } }
		public decimal CruiseTotal { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Cruise && t.PackageNo == 0).Sum(t => (decimal?)t.Amount) ?? 0; } }
		public decimal CruiseTotalTax { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Cruise && t.PackageNo == 0).Sum(t => (decimal?)t.Tax) ?? 0; } }
		public decimal TourTotal { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Tour && t.PackageNo == 0).Sum(t => (decimal?)t.Amount) ?? 0; } }
		public decimal TourTotalTax { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Tour && t.PackageNo == 0).Sum(t => (decimal?)t.Tax) ?? 0; } }
		public decimal OtherLandTotal { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.OtherLand && t.PackageNo == 0).Sum(t => (decimal?)t.Amount) ?? 0; } }
		public decimal OtherLandTotalTax { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.OtherLand && t.PackageNo == 0).Sum(t => (decimal?)t.Tax) ?? 0; } }
		public decimal InsuranceTotal { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Insurance && t.PackageNo == 0).Sum(t => (decimal?)t.Amount) ?? 0; } }
		public decimal InsuranceTotalTax { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.Insurance && t.PackageNo == 0).Sum(t => (decimal?)t.Tax) ?? 0; } }
		public decimal ForeignCurrencyTotal { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.ForeignCurrency && t.PackageNo == 0).Sum(t => (decimal?)t.Amount) ?? 0; } }
		public decimal ForeignCurrencyTotalTax { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.ForeignCurrency && t.PackageNo == 0).Sum(t => (decimal?)t.Tax) ?? 0; } }
		public decimal ServiceFeeTotal { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.ServiceFee && t.PackageNo == 0).Sum(t => (decimal?)t.Amount) ?? 0; } }
		public decimal ServiceFeeTotalTax { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.ServiceFee && t.PackageNo == 0).Sum(t => (decimal?)t.Tax) ?? 0; } }
		public decimal OtherInclusionTotal { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.OtherInclusion && t.PackageNo == 0).Sum(t => (decimal?)t.Amount) ?? 0; } }
		public decimal OtherInclusionTotalTax { get { return InvoiceDetailReportList.Where(t => t.TripLineType == TripLineType.OtherInclusion && t.PackageNo == 0).Sum(t => (decimal?)t.Tax) ?? 0; } }
		public List<InvoiceDetailReportModel> InvoiceDetailReportList { get; set; }
		public List<InvoiceDetailReportModel> PaymentDetailReportList { get; set; }
        public List<TripPaymentScheduleReportModel> PaymentScheduleReportList { get; set; }
    }

    public class InvoiceDetailReportModel {
		public int TripId { get; set; }
		public int TripLineId { get; set; }
		public int TripLineAirPassengerId { get; set; }
        public TripLineAirPassenger TripLineAirPassenger { get; set; }
        public TripLineType TripLineType { get; set; }
        public string ChartOfAccountCode { get; set; }
        public int PackageNo { get; set; }
        public string AccountNo { get; set; }
		public string Description { get; set; }
		public decimal Amount { get; set; }
		public decimal Tax { get; set; }
		public decimal Discount { get; set; }
		public decimal AgentCommission { get; set; }
		public decimal PersonalTravelAmount { get; set; }
		public bool IsDebtor { get; set; }
		public bool IsPayment { get; set; }
	}

    public class TripPaymentScheduleReportModel {
        public int TripPaymentScheduleId { get; set; }
        public DateTime TransactionDate { get; set; }
        public decimal Amount { get; set; }
        public string Description { get; set; }
        public bool IsCompleted { get; set; }
    }

    public class VoucherReportModel : ICloneable {
		public object Clone() {
			return MemberwiseClone();
		}

		public string HeaderContent { get; set; }
		public Image Logo { get; set; }
		public string Copy { get; set; }
		public int VoucherId { get; set; }
		public string VoucherNo { get; set; }
		public int TripId { get; set; }
		public string TripNo { get; set; }
		public string ConfirmationNo { get; set; }
		public string TaxNo { get; set; }
		public string Passengers { get; set; }
		public string ServiceLabel { get; set; }
		public string Service { get; set; }
		public string ServiceComments { get; set; }
		public string StartDateLabel { get; set; }
		public DateTime StartDate { get; set; }
		public string EndDateLabel { get; set; }
		public DateTime EndDate { get; set; }
		public string StartDetailsLabel { get; set; }
		public string StartDetails { get; set; }
		public string EndDetailsLabel { get; set; }
		public string EndDetails { get; set; }
		public string ServiceProvider { get; set; }
		public string PaymentDetails { get; set; }
		public string RateDescription { get; set; }
	}
}