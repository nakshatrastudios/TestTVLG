﻿using System;
using System.Drawing;

namespace Travelog.Biz.Models {
	public class KeyValueModel {
		public int Key { get; set; }
		public int Value { get; set; }
	}

	public class CreditorTotalsModel {
		public int CreditorId { get; set; }
		public DateTime AgingDate { get; set; }
		public decimal AmountGross { get; set; }
	}

	public class AgencyHeaderReportModel {
		public string HeaderStandardComment { get; set; }
		public string FooterStandardComment { get; set; }
		public string Content { get; set; }
		public string LogoPosition { get; set; }
		public string LogoWidth { get; set; }
		public string LogoHeight { get; set; }
		public Image Logo { get; set; }
	}

	public class ReportGroupModel {
		public string Name { get; set; }
		public int Level { get; set; }
		public bool NewPage { get; set; }
	}
}