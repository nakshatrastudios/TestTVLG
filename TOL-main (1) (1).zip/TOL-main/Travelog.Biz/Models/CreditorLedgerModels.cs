﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Travelog.Biz.Enums;

namespace Travelog.Biz.Models {
	public class CreditorReportSourceModel {
		public ReportSourceCreditor ReportSource { get; set; }
		public int CustomerId { get; set; }
		public string OutputType { get; set; }
		public string DefaultAgency { get; set; }

		[Display(Name = "Report Date")]
		public DateTime? ReportDate { get; set; }

		[Display(Name = "Matched Txns")]
		public MatchedTxnsReportOption? MatchedTxnsReportOption { get; set; }

		[Display(Name = "Paid Status")]
		public PaidStatusReportOption? PaidStatusReportOption { get; set; }

		[Display(Name = "Report Type")]
		public LedgerDocumentType? LedgerDocumentType { get; set; }

		[Display(Name = "Document Date")]
		public DateTime? DateFrom { get; set; }

		[Display(Name = "Document Date")]
		public DateTime? DateTo { get; set; }

		[Display(Name = "Document Type")]
		public TransactionType? TransactionType { get; set; }

		[Display(Name = "Balances")]
		public TransactionBalanceType? TransactionBalanceType { get; set; }

		[Display(Name = "Aging Cycle")]
		public AgingCycle? AgingCycle { get; set; }

		[Display(Name = "Periods")]
		public int? AgingPeriodId { get; set; }

		[Display(Name = "Class")]
		public int? ClassId { get; set; }

		[Display(Name = "Agency")]
		public int? AgencyId { get; set; }

		[Display(Name = "Creditors")]
		public int[] CreditorIds { get; set; }

		public string CreationUser { get; set; }
		public DateTime CreationTime { get; set; }
	}

	public class CreditorTrialBalanceReportModel {
		public int CreditorId { get; set; }
		public string Name { get; set; }
		public decimal CreditLimit { get; set; }
		public decimal BalancePeriod1 { get; set; }
		public decimal BalancePeriod2 { get; set; }
		public decimal BalancePeriod3 { get; set; }
		public decimal BalanceCurrent { get; set; }
		public decimal Balance { get; set; }
		public List<TransactionDetailReportModel> TransactionDetailReportList { get; set; }
	}
}