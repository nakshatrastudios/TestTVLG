﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Travelog.Biz.Enums;

namespace Travelog.Biz.Models {
	public enum TotalLevelColumnName {
		PeriodBudgetTotal,
		PeriodCurrentYearTotal,
		PeriodPreviousYearTotal,
		YtdBudgetTotal,
		YtdCurrentYearTotal,
		YtdPreviousYearTotal
	}

	public class GeneralLedgerReportSourceModel {
		public ReportSourceGeneralLedger ReportSource { get; set; }
		public int CustomerId { get; set; }
		public string OutputType { get; set; }
		public string DefaultAgency { get; set; }
		public string UserRoleId { get; set; }
		public string FiscalYearStartDateName { get; set; }
		public string PeriodColumn1Header { get; set; }
		public string PeriodColumn2Header { get; set; }
		public string PeriodColumn3Header { get; set; }
		public string YtdColumn1Header { get; set; }
		public string YtdColumn2Header { get; set; }
		public string YtdColumn3Header { get; set; }

		[Display(Name = "Agency")]
		public int? AgencyId { get; set; }

		[Display(Name = "Fiscal Year")]
		public DateTime? FiscalYearStartDate { get; set; }

		[Display(Name = "Previous Year")]
		public DateTime? PreviousFiscalYearStartDate { get; set; }

		[Display(Name = "Period From")]
		public DateTime? PeriodFrom { get; set; }

		[Display(Name = "Period To")]
		public DateTime? PeriodTo { get; set; }

		[Display(Name = "Date Option")]
		public TransactionDateOption? TransactionDateOption { get; set; }

		[Display(Name = "Ledger Type")]
		public GeneralLedgerReportType? GeneralLedgerReportType { get; set; }

		[Display(Name = "View Option")]
		public TransactionViewOption? TransactionViewOption { get; set; }

		[Display(Name = "Balances")]
		public TransactionBalanceType? TransactionBalanceType { get; set; }

		[Display(Name = "Document Date")]
		public DateTime? DateFrom { get; set; }

		[Display(Name = "Document Date")]
		public DateTime? DateTo { get; set; }

		[Display(Name = "Document Type")]
		public TransactionType? TransactionType { get; set; }

		[Display(Name = "Account Type")]
		public ChartOfAccountType? ChartOfAccountType { get; set; }

		[Display(Name = "Category")]
		public AccountCategory? AccountCategory { get; set; }

		[Display(Name = "Accounts")]
		public int[] ChartOfAccountIds { get; set; }

		[Display(Name = "Use Alt Code")]
		public bool UseAltReportingCode { get; set; }

		[Display(Name = "Use Date Filters")]
		public bool UseDateFilters { get; set; }

		[Display(Name = "Monthly Totals")]
		public bool IncludeMonthlyTotals { get; set; }

		[Display(Name = "Exclude accounts with no Txns")]
		public bool ExistingTransactionsOnly { get; set; }

		public string CreationUser { get; set; }
		public DateTime CreationTime { get; set; }
	}

	public class GeneralLedgerTransactionReportModel {
		public int ChartOfAccountId { get; set; }
		public string Code { get; set; }
		public string Name { get; set; }
		public string ChartOfAccount { get { return string.Concat(Code, ": ", Name).TrimStart(": "); } }
		public ChartOfAccountType ChartOfAccountType { get; set; }
		public string ChartOfAccountTypeDescription { get { return ChartOfAccountType.GetEnumDescription(); } }
		public RowType RowType { get; set; }
		public string AccountCategory { get; set; }
		public string ChartOfAccountTransactionType { get; set; }
		public string AltReportingCode { get; set; }
		public decimal YtdBalance { get; set; }
		public decimal PreviousYearBalance { get; set; }
		public decimal TotalAmount { get; set; }
		public decimal AccumulatedTotal { get; set; }
		public string Period01 { get; set; }
		public string Period02 { get; set; }
		public string Period03 { get; set; }
		public string Period04 { get; set; }
		public string Period05 { get; set; }
		public string Period06 { get; set; }
		public string Period07 { get; set; }
		public string Period08 { get; set; }
		public string Period09 { get; set; }
		public string Period10 { get; set; }
		public string Period11 { get; set; }
		public string Period12 { get; set; }
		public decimal Row1Value01 { get; set; }
		public decimal Row1Value02 { get; set; }
		public decimal Row1Value03 { get; set; }
		public decimal Row1Value04 { get; set; }
		public decimal Row1Value05 { get; set; }
		public decimal Row1Value06 { get; set; }
		public decimal Row1Value07 { get; set; }
		public decimal Row1Value08 { get; set; }
		public decimal Row1Value09 { get; set; }
		public decimal Row1Value10 { get; set; }
		public decimal Row1Value11 { get; set; }
		public decimal Row1Value12 { get; set; }
		public decimal Row2Value01 { get; set; }
		public decimal Row2Value02 { get; set; }
		public decimal Row2Value03 { get; set; }
		public decimal Row2Value04 { get; set; }
		public decimal Row2Value05 { get; set; }
		public decimal Row2Value06 { get; set; }
		public decimal Row2Value07 { get; set; }
		public decimal Row2Value08 { get; set; }
		public decimal Row2Value09 { get; set; }
		public decimal Row2Value10 { get; set; }
		public decimal Row2Value11 { get; set; }
		public decimal Row2Value12 { get; set; }
		public decimal Row3Value01 { get; set; }
		public decimal Row3Value02 { get; set; }
		public decimal Row3Value03 { get; set; }
		public decimal Row3Value04 { get; set; }
		public decimal Row3Value05 { get; set; }
		public decimal Row3Value06 { get; set; }
		public decimal Row3Value07 { get; set; }
		public decimal Row3Value08 { get; set; }
		public decimal Row3Value09 { get; set; }
		public decimal Row3Value10 { get; set; }
		public decimal Row3Value11 { get; set; }
		public decimal Row3Value12 { get; set; }
		public List<TransactionDetailReportModel> TransactionDetailReportList { get; set; }
	}

	public class GeneralLedgerReportModel {
		public TransactionViewOption TransactionViewOption { get; set; }
		public string Code { get; set; }
		public string Name { get; set; }
		public int RowTypeId { get; set; }
		public decimal PeriodBudget { get; set; }
		public decimal PeriodCurrentYear { get; set; }
		public decimal PeriodPreviousYear { get; set; }
		public decimal YtdBudget { get; set; }
		public decimal YtdCurrentYear { get; set; }
		public decimal YtdPreviousYear { get; set; }
		public decimal PeriodColumn1 { get { return PeriodCurrentYear; } }
		public decimal PeriodColumn2 { get { return TransactionViewOption == TransactionViewOption.CurrentPreviousVariance ? PeriodPreviousYear : PeriodBudget; } }
		public decimal PeriodColumn3 { get { return TransactionViewOption == TransactionViewOption.CurrentPreviousVariance ? PeriodCurrentYear - PeriodPreviousYear : TransactionViewOption == TransactionViewOption.CurrentBudgetVariance ? PeriodCurrentYear - PeriodBudget : PeriodPreviousYear; } }
		public decimal YtdColumn1 { get { return YtdCurrentYear; } }
		public decimal YtdColumn2 { get { return TransactionViewOption == TransactionViewOption.CurrentPrevious || TransactionViewOption == TransactionViewOption.CurrentPreviousVariance ? YtdPreviousYear : YtdBudget; } }
		public decimal YtdColumn3 { get { return TransactionViewOption == TransactionViewOption.CurrentPrevious || TransactionViewOption == TransactionViewOption.CurrentPreviousVariance ? YtdCurrentYear - YtdPreviousYear : TransactionViewOption == TransactionViewOption.CurrentBudgetVariance ? YtdCurrentYear - YtdBudget : YtdPreviousYear; } }
		public decimal PeriodVariance { get { return PeriodColumn1 - PeriodColumn2; } }
		public decimal YtdVariance { get { return YtdColumn1 - YtdColumn2; } }
		public int PeriodVariancePercent { get { return PeriodColumn1 == 0 ? 0 : (int)(PeriodColumn3 * 100 / PeriodColumn1); } }
		public int YtdVariancePercent { get { return YtdColumn1 == 0 ? 0 : (int)(YtdColumn3 * 100 / YtdColumn1); } }
	}

	public class TotalLevelModel {
		public TotalLevel TotalLevel { get; set; }
		public TotalLevelColumnName ColumnName { get; set; }
		public decimal Amount { get; set; }
	}
}