﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Travelog.Biz.Enums;

namespace Travelog.Biz.Models {
	public class DebtorReportSourceModel {
		public ReportSourceDebtor ReportSource { get; set; }
		public int CustomerId { get; set; }
		public string OutputType { get; set; }
		public string DefaultAgency { get; set; }

		[Display(Name = "Report Date")]
		public DateTime? ReportDate { get; set; }

		[Display(Name = "Report Order")]
		public int? ReportOrderId { get; set; }

		[Display(Name = "Matched Txns")]
		public MatchedTxnsReportOption? MatchedTxnsReportOption { get; set; }

		[Display(Name = "Report Type")]
		public LedgerDocumentType? LedgerDocumentType { get; set; }

		[Display(Name = "Balances")]
		public TransactionBalanceType? TransactionBalanceType { get; set; }

		[Display(Name = "Aging Cycle")]
		public AgingCycle? AgingCycle { get; set; }

		[Display(Name = "Periods")]
		public int? AgingPeriodId { get; set; }

		[Display(Name = "Class")]
		public int? ClassId { get; set; }

		[Display(Name = "Agency")]
		public int? AgencyId { get; set; }

		[Display(Name = "Debtors")]
		public int[] DebtorIds { get; set; }

		public string CreationUser { get; set; }
		public DateTime CreationTime { get; set; }
	}

	public class DebtorTrialBalanceReportModel {
		public int DebtorId { get; set; }
		public string Code { get; set; }
		public string Name { get; set; }
		public decimal CreditLimit { get; set; }
		public decimal BalancePeriod1 { get; set; }
		public decimal BalancePeriod2 { get; set; }
		public decimal BalancePeriod3 { get; set; }
		public decimal BalanceCurrent { get; set; }
		public decimal Balance { get; set; }
		public List<TransactionDetailReportModel> TransactionDetailReportList { get; set; }
	}

	public class DebtorStatementReportModel {
		public int DebtorId { get; set; }
		public string Code { get; set; }
		public string Debtor { get; set; }
		public string Address { get; set; }
		public int AgencyId { get; set; }
		public string TaxNo { get; set; }
		public string PaymentTerms { get; set; }
		public string PaymentOptions { get; set; }
		public string PayIdLabel { get; set; }
		public string PayId { get; set; }
		public string TravelPayUrl { get; set; }
		public string MintUrl { get; set; }
		public int AgingCycleId { get; set; }
		public decimal BalancePeriod1 { get; set; }
		public decimal BalancePeriod2 { get; set; }
		public decimal BalancePeriod3 { get; set; }
		public decimal BalanceCurrent { get; set; }
		public decimal Balance { get; set; }
		public List<TransactionDetailReportModel> TransactionDetailReportList { get; set; }
	}
}