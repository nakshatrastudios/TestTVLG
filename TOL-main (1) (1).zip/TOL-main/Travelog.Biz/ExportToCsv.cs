﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Travelog.Biz {
    public class ExportToCsv<T> where T : class {
		private readonly List<T> ExportList;

		public ExportToCsv(List<T> list) {
			ExportList = list;
		}

		public void ExportToFile(string filePath, string[] columns = null, bool includeHeaderRow = true, bool useQuotesWithStrings = false) {
			File.WriteAllText(filePath, Export(columns, includeHeaderRow, useQuotesWithStrings));
		}

		public byte[] ExportToBytes(string[] columns = null, bool includeHeaderRow = true, bool useQuotesWithStrings = false) {
			return Encoding.UTF8.GetBytes(Export(columns, includeHeaderRow, useQuotesWithStrings));
		}

		private string Export(string[] columns, bool includeHeaderRow, bool useQuotesWithStrings) {
			IList<PropertyInfo> piList = null;

			if (columns == null) {
				piList = typeof(T).GetProperties();
			}
			else {
				piList = typeof(T).GetProperties().Where(t1 => columns.Any(t2 => t2.ToLower() == t1.Name.ToLower())).ToList();
			}

			var sb = new StringBuilder();

			if (includeHeaderRow) {
				foreach (PropertyInfo pi in piList) {
					sb.Append(pi.Name).Append(",");
				}

				if (sb.Length > 0)
					sb.Remove(sb.Length - 1, 1).AppendLine();
			}

			foreach (T obj in ExportList) {
				foreach (PropertyInfo pi in piList) {
					sb.Append(MakeValueCsvFriendly(pi.GetValue(obj, null), useQuotesWithStrings)).Append(",");
				}

				if (sb.Length > 0)
					sb.Remove(sb.Length - 1, 1).AppendLine();
			}

			return sb.ToString();
		}

		private string MakeValueCsvFriendly(object value, bool useQuotesWithStrings = false) {
			if (value == null || value.ToString().Length == 0)
				return string.Empty;

			if (value is DateTime)
				return GetCsvDate(value);

			if (value is string && value.ToString().StartsWith("0") && DataValidation.IsNumber(value.ToString()))
				return string.Format(@"=""{0}""", value);

			string output = value.ToString().Replace("Not Specified", string.Empty);

			if (output.Contains(",") || output.Contains("\"") || output.Contains(Environment.NewLine) || (value is string && useQuotesWithStrings))
				output = string.Format("\"{0}\"", output.Replace("\"", "\"\""));

			return output;
		}

		private string GetCsvDate(object value) {
			DateTime date = (DateTime)value;

			if (date == DateTime.MinValue)
				return string.Empty;

			if (date.Hour == 0 && date.Minute == 0 && date.Second == 0)
				return string.Format("{0:d}", date);

			return string.Format("{0:g}", date);
		}
	}
}