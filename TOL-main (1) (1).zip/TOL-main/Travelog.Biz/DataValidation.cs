using System;
using System.Text.RegularExpressions;

namespace Travelog.Biz {
    public static class DataValidation {
        public const string All = ".*";
        public const string Alpha = "^[a-zA-Z \u00c0-\u024f\u1e00-\u1eff]+$";
        public const string AlphaWithSpace = "^[a-zA-Z \u00c0-\u024f\u1e00-\u1eff ]+$";
        public const string AlphaNumeric = "^[a-zA-Z \u00c0-\u024f\u1e00-\u1eff0-9]+$";
        public const string AlphaNumericWithSpace = "^[a-zA-Z \u00c0-\u024f\u1e00-\u1eff0-9 ]+$";
        public const string AlphaNumericExt = @"^[a-zA-Z \u00c0-\u024f\u1e00-\u1eff0-9 ,//\\\'\""\,\.\!\;\:\+\-\&\?\*\$\%\#\(\)\[\]*@\r\n\t]+$";
        public const string NumericWithSpace = "^-?[0-9 ]*$";
        public const string Integer = "^-?[0-9]*$";
        public const string IntegerPositive = "^[0-9]+$";
        public const string IntegerPositiveWithSpace = "^[0-9 ]+$";
        public const string IntegerPositiveWithForwardSlash = "^[0-9/]+$";
        public const string IntegerGreaterThanZero = "^[1-9][0-9]+$";
        public const string Float = @"^-?[0-9]*(?:\.[0-9]*)?$";
        public const string FloatPositive = @"^[0-9]*(?:\.[0-9]*)?$";
        public const string FloatGreaterThanZero = @"^0*[1-9][0-9]*(\.[0-9]+)?|0+\.[0-9]*[1-9][0-9]*$";

        public const string Name = @"^[a-zA-Z \u00c0-\u024f\u1e00-\u1eff0-9_.-]+(([\'\,\.\-\& ][a-zA-Z\u00c0-\u024f\u1e00-\u1eff0-9 ])?[a-zA-Z \u00c0-\u024f\u1e00-\u1eff0-9_.-]*)*$";
        public const string Time = "^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$";
        public const string Phone = @"^[0-9+\-() ]+$";
        public const string Email = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
        public const string EmailMultiple = @"(([a-zA-Z\u00c0-\u024f\u1e00-\u1eff0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z\u00c0-\u024f\u1e00-\u1eff0-9\-]+\.)+))([a-zA-Z\u00c0-\u024f\u1e00-\u1eff]{2,4}|[0-9]{1,3})(\]?)(\s*;\s*|\s*$))*";
        public const string Url = @"(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})";

        public static bool IsDate(DateTime value) {
            return DateTime.TryParse(value.ToStringExt(), out DateTime result);
        }

        public static bool IsDate(string value) {
            return DateTime.TryParse(value, out DateTime result);
        }

        public static bool IsNullDate(string value) {
            try {
                var result = DateTime.Parse(value);
                return result == DateTime.MinValue;
            }
            catch {
                return false;
            }
        }

        public static bool IsTime(string value) {
            return ValidateRegex(Time, value);
        }

        public static bool IsNumber(string value) {
            return float.TryParse(value, out float result);
        }

        public static bool IsIntegerPositive(string value) {
            return ValidateRegex(IntegerPositive, value);
        }

        public static bool IsIntegerPositiveWithSpace(string value) {
            return ValidateRegex(IntegerPositiveWithSpace, value);
        }

        public static bool IsGreaterThanZero(string value) {
            if (!IsNumber(value))
                return false;

            float.TryParse(value, out float result);

            return result > 0;
        }

        public static bool IsAlpha(string value) {
            return string.IsNullOrEmpty(value) || ValidateRegex(Alpha, value);
        }

        public static bool IsAlphaWithSpace(string value) {
            return string.IsNullOrEmpty(value) || ValidateRegex(AlphaWithSpace, value);
        }

        public static bool IsAlphaNumeric(string value) {
            return string.IsNullOrEmpty(value) || ValidateRegex(AlphaNumeric, value);
        }

        public static bool IsAlphaNumericWithSpace(string value) {
            return string.IsNullOrEmpty(value) || ValidateRegex(AlphaNumericWithSpace, value);
        }

        public static bool IsAlphaNumericExt(string value) {
            return string.IsNullOrEmpty(value) || ValidateRegex(AlphaNumericExt, value);
        }

        public static bool IsName(string value) {
            return string.IsNullOrEmpty(value) || ValidateRegex(Name, value);
        }

        public static bool IsPhone(string value) {
            return string.IsNullOrEmpty(value) || ValidateRegex(Phone, value);
        }

        public static bool IsEmail(string value) {
            return ValidateRegex(Email, value);
        }

        public static bool IsUrl(string value) {
            return string.IsNullOrEmpty(value) || ValidateRegex(Url, value);
        }

        public static bool IsValidPassword(string value, int minLength, int maxLength) {
            return ValidateRegex(PasswordRegEx(minLength, maxLength), value);
        }

        public static string PasswordRegEx(int minLength, int maxLength) {
            //At least 1 uppercase alphabet, 1 lowercase alphabet, 1 number and 1 special character.
            return string.Format(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W)\S{{{0},{1}}}$", minLength, maxLength);
        }

        private static bool ValidateRegex(string expression, string value) {
            if (string.IsNullOrEmpty(value))
                return false;

            var regex = new Regex(expression);
            return regex.IsMatch(value);
        }
    }
}