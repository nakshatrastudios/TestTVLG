﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Travelog.Biz {
	public static class Cryptography {
		public static string Encrypt(string plainText) {
			byte[] salt = Encoding.ASCII.GetBytes(AppSettings.SystemAccountPassword);
			var key = new Rfc2898DeriveBytes(AppSettings.GoogleAccountSecretKeyPassword, salt);
			byte[] bytes = EncryptStringToBytes(plainText, key);
			return Convert.ToBase64String(bytes);
		}

		public static string Decrypt(string cipherText) {
			byte[] salt = Encoding.ASCII.GetBytes(AppSettings.SystemAccountPassword);
			var key = new Rfc2898DeriveBytes(AppSettings.GoogleAccountSecretKeyPassword, salt);
			byte[] bytes = Convert.FromBase64String(cipherText);
			return DecryptStringFromBytes(bytes, key);
		}

		private static byte[] EncryptStringToBytes(string plainText, Rfc2898DeriveBytes key) {
			byte[] bytes;

			using (var aes = Aes.Create()) {
				aes.Key = key.GetBytes(aes.KeySize / 8);
				aes.IV = key.GetBytes(aes.BlockSize / 8);

				using (var ms = new MemoryStream()) {
					using (var cs = new CryptoStream(ms, aes.CreateEncryptor(aes.Key, aes.IV), CryptoStreamMode.Write)) {
						using (var sw = new StreamWriter(cs)) {
							sw.Write(plainText);
						}

						bytes = ms.ToArray();
					}
				}
			}

			return bytes;
		}

		private static string DecryptStringFromBytes(byte[] cipherText, Rfc2898DeriveBytes key) {
			string plainText = string.Empty;

			using (var aes = Aes.Create()) {
				aes.Key = key.GetBytes(aes.KeySize / 8);
				aes.IV = key.GetBytes(aes.BlockSize / 8);

				using (var ms = new MemoryStream(cipherText)) {
					using (var cs = new CryptoStream(ms, aes.CreateDecryptor(aes.Key, aes.IV), CryptoStreamMode.Read)) {
						using (var sr = new StreamReader(cs)) {
							plainText = sr.ReadToEnd();
						}
					}
				}
			}

			return plainText;
		}

		public static string GeneratePassword(int passwordMinLength = 0, bool requireLowercase = true, bool requireUppercase = true, bool requireDigit = true, bool requireNonAlphanumeric = true) {
			string password = string.Empty;
			var random = new Random();

			if (passwordMinLength == 0)
				passwordMinLength = AppConstants.PasswordMinLength;


            while (password.Length != passwordMinLength) {
				int randomNumber = random.Next(48, 122);

				if ((randomNumber > 57 && randomNumber < 65) || (randomNumber > 90 && randomNumber < 97))
					continue;

				char c = Convert.ToChar(randomNumber);

				if (requireLowercase && char.IsLower(c))
					requireLowercase = false;

				if (requireUppercase && char.IsUpper(c))
					requireUppercase = false;

				if (requireDigit && char.IsDigit(c))
					requireDigit = false;

				if (requireNonAlphanumeric && !char.IsLetterOrDigit(c))
					requireNonAlphanumeric = false;

				password += c;
			}

			if (requireLowercase)
				password += Convert.ToChar(random.Next(97, 122));

			if (requireUppercase)
				password += Convert.ToChar(random.Next(65, 90));

			if (requireDigit)
				password += Convert.ToChar(random.Next(48, 57));

			if (requireNonAlphanumeric)
				password += Convert.ToChar(random.Next(33, 47));

			return password;
		}
	}
}