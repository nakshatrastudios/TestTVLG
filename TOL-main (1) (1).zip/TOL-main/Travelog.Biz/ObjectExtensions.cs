﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Travelog.Biz.Enums;
using Travelog.Biz.Resources;

namespace Travelog.Biz {
    public static class ObjectExtensions {
        public static string ToStringExt(this object value) {
            return ToStringExt(value, string.Empty);
        }

        public static string ToStringExt(this object value, string valueIfNull) {
            return value == null ? valueIfNull : value.ToString();
        }

        public static bool ToBool(this object value) {
            return ToBool(value, false);
        }

        public static bool ToBool(this object value, bool valueIfNull = false) {
            return value == null || value.ToString()?.Length == 0 ? valueIfNull : bool.Parse(value.ToString());
        }

        public static byte ToByte(this object value, byte valueIfNull = 0) {
            return value == null || value.ToString()?.Length == 0 ? valueIfNull : byte.Parse(value.ToString());
        }

        public static short ToShort(this object value, short valueIfNull = 0) {
            return value == null || value.ToString()?.Length == 0 ? valueIfNull : short.Parse(value.ToString());
        }

        public static int ToInt(this object value, int valueIfNull = 0) {
            return value == null || value.ToString()?.Length == 0 ? valueIfNull : int.Parse(value.ToString());
        }

        public static long ToLong(this object value, long valueIfNull = 0) {
            return value == null || value.ToString()?.Length == 0 ? valueIfNull : long.Parse(value.ToString());
        }

        public static string ToShortDateStringExt(this DateTime value) {
            return value.ToString(Resource.ShortDatePattern);
        }

        public static string ToShortDateTimeStringExt(this DateTime value) {
            return string.Format("{0} {1}", value.ToString(Resource.ShortDatePattern), value.ToString(Resource.ShortTimePattern));
        }

        public static bool Contains(this string source, string value, StringComparison comparisonType) {
            return source?.IndexOf(value, comparisonType) >= 0;
        }

        public static string Left(this string value, int maxLength) {
            if (string.IsNullOrEmpty(value))
                return value;

            return value.Length <= maxLength ? value : value.Substring(0, maxLength);
        }

        public static string Right(this string value, int maxLength) {
            if (string.IsNullOrEmpty(value))
                return value;

            return value.Length <= maxLength ? value : value.Substring(value.Length - maxLength, maxLength);
        }

        public static string TrimStart(this string source, string value) {
            return source.StartsWith(value) ? source.Substring(value.Length) : source;
        }

        public static string TrimEnd(this string source, string value) {
            return source.EndsWith(value) ? source.Remove(source.LastIndexOf(value, StringComparison.Ordinal)) : source;
        }

        public static string TrimHtmlLineBreaks(this string value) {
            return value.Replace("<br>", string.Empty).Replace("&#xfeff;", string.Empty).Replace("&#xFEFF;", string.Empty).Replace(Environment.NewLine, AppConstants.HtmlLineBreak).TrimStart(AppConstants.HtmlLineBreak).TrimEnd(AppConstants.HtmlLineBreak).TrimStart("<p>&nbsp;</p>").TrimEnd("<p>&nbsp;</p>");
        }

        public static IEnumerable<string> Split(this string value, int chunkSize) {
            if ((value?.Length ?? 0) == 0 || chunkSize <= 0)
                yield return string.Empty;

            for (int i = 0; i < value.Length; i += chunkSize) {
                yield return value.Substring(i, Math.Min(chunkSize, value.Length - i));
            }
        }

        public static DateTime StartOfWeek(this DateTime date, DayOfWeekExt startOfWeek) {
            int dayOfWeek = date.DayOfWeek == DayOfWeek.Sunday ? 7 : ((int)date.DayOfWeek - 1);
            int diff = (7 + (dayOfWeek - (int)startOfWeek)) % 7;
            return date.AddDays(-1 * diff).Date;
        }

        public static string MinutesToHoursMinutes(this object value) {
            int minutes = value.ToInt();
            return string.Format("{0:D2}:{1:D2}", minutes / 60 % 24, minutes % 60);
        }

        public static string Base64Encode(this string value) {
            var bytes = Encoding.UTF8.GetBytes(value);
            return Convert.ToBase64String(bytes);
        }

        public static string Base64Decode(this string value) {
            var bytes = Convert.FromBase64String(value);
            return Encoding.UTF8.GetString(bytes);
        }

        public static bool IsBase64Encoded(this string value) {
            try {
                Convert.FromBase64String(value);
                return true;
            }
            catch {
                return false;
            }
        }

        public static bool IsNumeric(this string value) {
            return double.TryParse(value, out double test);
        }

        public static string GetDigits(this string value) {
            return new string(value.Where(t => char.IsDigit(t)).ToArray());
        }

        public static string GetDigitsAndPunctuation(this string value) {
            return new string(value.Where(t => char.IsDigit(t) || char.IsPunctuation(t)).ToArray());
        }

        public static string ToSentenceCase(this string value) {
            var regex = new Regex(@"(^[a-z])|[?!.:;]\s+(.)", RegexOptions.ExplicitCapture);
            return regex.Replace(value.ToStringExt().Trim().ToLower(), t => t.Value.ToUpper());
        }

        public static string ToConcatenatedString<T>(this IEnumerable<T> source, Func<T, string> selector, string separator) {
            var sb = new StringBuilder();
            bool needSeparator = false;

            foreach (var item in source) {
                if (needSeparator)
                    sb.Append(separator);

                sb.Append(selector(item));
                needSeparator = true;
            }

            return sb.ToString();
        }

        public static LinkedList<T> ToLinkedList<T>(this IEnumerable<T> source) {
            return new LinkedList<T>(source);
        }

        public static byte[] StreamToBytes(this Stream stream) {
            using (var ms = new MemoryStream()) {
                stream.CopyTo(ms);
                return ms.ToArray();
            }
        }

        public static Image BytesToImage(this byte[] bytes) {
            using (var ms = new MemoryStream(bytes)) {
                return Image.FromStream(ms, true);
            }
        }

        public static byte[] ImageToBytes(this Image image) {
            using (var ms = new MemoryStream()) {
                var bmp = new Bitmap(image);
                bmp.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }
        }

        public static Image CopyImage(this Image image) {
            var bmp = new Bitmap(image.Width, image.Height);

            using (var graphics = Graphics.FromImage(bmp)) {
                graphics.DrawImage(image, 0, 0, image.Width, image.Height);
                graphics.Save();
            }

            return bmp;
        }

        public static Bitmap Resize(this Image image, int width, int height) {
            var rect = new Rectangle(0, 0, width, height);
            var bmp = new Bitmap(width, height);

            bmp.SetResolution(image.HorizontalResolution, image.VerticalResolution);

            using (var graphics = Graphics.FromImage(bmp)) {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                using (var wrapMode = new ImageAttributes()) {
                    wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(image, rect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }

            return bmp;
        }

        public static string ToBase64String(this Stream stream) {
            byte[] bytes = null;

            using (var memoryStream = new MemoryStream()) {
                stream.CopyTo(memoryStream);
                bytes = memoryStream.ToArray();
            }

            return Convert.ToBase64String(bytes);
        }

        public static string GetEnumDescription(this Enum value) {
            var fi = value.GetType().GetField(value.ToString());

            if (fi == null)
                return "Unknown";

            var attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

            if (attributes != null && attributes.Length > 0) {
                return attributes[0].Description;
            }
            else {
                return value.ToString();
            }
        }

        public static int GetNthIndex(this string value, char t, int n) {
            int count = 0;

            for (int i = 0; i < value.Length; i++) {
                if (value[i] == t) {
                    count++;

                    if (count == n) {
                        return i;
                    }
                }
            }

            return -1;
        }

        public static int IndexOf<T>(this IEnumerable<T> items, T item) {
            return items.FindIndex(i => EqualityComparer<T>.Default.Equals(item, i));
        }

        public static int FindIndex<T>(this IEnumerable<T> items, Func<T, bool> predicate) {
            if (items == null)
                throw new ArgumentNullException("Items cannot be null.");

            if (predicate == null)
                throw new ArgumentNullException("Predicate cannot be null.");

            int index = 0;

            foreach (var item in items) {
                if (predicate(item))
                    return index;

                index++;
            }

            return -1;
        }

        public static IEnumerable<IEnumerable<T>> Split<T>(this T[] array, int size) {
            for (var i = 0; i < (float)array.Length / size; i++) {
                yield return array.Skip(i * size).Take(size);
            }
        }
    }
}