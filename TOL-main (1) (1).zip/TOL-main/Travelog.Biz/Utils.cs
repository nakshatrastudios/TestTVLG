using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Transactions;
using HtmlAgilityPack;
using Telerik.Reporting;
using Telerik.Reporting.Processing;
using Travelog.Biz.Enums;

namespace Travelog.Biz {
    public static class Utils {
        public static IPrincipal GetGenericIdentity(string userRole = null, string identityName = null, string authenticationType = "") {
            var identity = new GenericIdentity(identityName ?? AppSettings.SystemAccountEmail, authenticationType);
            var roles = new string[] { userRole ?? UserRole.SystemAdministrator.Name };
            return new GenericPrincipal(identity, roles);
        }

        public static TransactionScope CreateTransactionScope(TransactionScopeOption scopeOption = TransactionScopeOption.Required, TransactionScopeAsyncFlowOption asyncFlowOption = TransactionScopeAsyncFlowOption.Enabled) {
			var transactionOptions = new TransactionOptions { IsolationLevel = IsolationLevel.Serializable, Timeout = new TimeSpan(0, 15, 0) };
			return new TransactionScope(scopeOption, transactionOptions, asyncFlowOption);
		}

        public static string ValidateHtmlTags(string value) {
			if (string.IsNullOrEmpty(value))
				return string.Empty;

            foreach (var item in HtmlTagReplacements) {
                value = value.Replace(item.Key, item.Value);
            }

			return value.TrimHtmlLineBreaks();
        }

        public static string HtmlEncodeExceptTags(string value) {
            return Regex.Replace(value, "(<[^>]+>|[^<]+)", t => t.Value.StartsWith("<") ? t.Value : HtmlDocument.HtmlEncode(t.Value));
        }

        public static string RemoveHtmlFromString(string value) {
			return Regex.Replace(value, "<.*?>", string.Empty);
		}

		public static string RemoveExtraSpaces(string value) {
			return Regex.Replace(value ?? string.Empty, @"\s+", " ").Trim();
		}

		public static string GetRandomString(int length) {
			const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var random = new Random();
			return new string(Enumerable.Repeat(chars, length).Select(t => t[random.Next(t.Length)]).ToArray());
		}

		public static string AddSpacesToString(string value, bool preserveAcronyms = false) {
			if (string.IsNullOrEmpty(value))
				return string.Empty;

			var text = new StringBuilder(value.Length * 2);
			text.Append(value[0]);

			for (int i = 1; i < value.Length; i++) {
				if (char.IsUpper(value[i])) {
					if ((value[i - 1] != ' ' && !char.IsUpper(value[i - 1])) || (preserveAcronyms && char.IsUpper(value[i - 1]) && i < value.Length - 1 && !char.IsUpper(value[i + 1])))
						text.Append(' ');
				}

				text.Append(value[i]);
			}

			return text.ToString();
		}

		public static string SplitStringByCapitals(string value) {
			var regex = new Regex(@"(?<=[A-Z])(?=[A-Z][a-z]) | (?<=[^A-Z])(?=[A-Z]) | (?<=[A-Za-z])(?=[^A-Za-z])", RegexOptions.IgnorePatternWhitespace);
			return regex.Replace(value, " ");
		}

		public static DateTime GetDayOfMonthDate(DateTime date, int dayOfMonth, int addDays = 0) {
			if (dayOfMonth <= 28)
				return date;

			int daysInMonth = DateTime.DaysInMonth(date.Year, date.Month);

			if (daysInMonth < dayOfMonth)
				dayOfMonth = daysInMonth;

			if (dayOfMonth == date.Day)
				return date;

			return new DateTime(date.Year, date.Month, dayOfMonth).AddDays(addDays);
		}

        public static DateTime GetDate(string value, string format) {
            DateTime.TryParseExact(value, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date);
            return date;
        }

        public static DateTime GetIso8601DateTime(string value) {
			if (DateTime.TryParseExact(value, "yyyy-MM-ddTHH:mm:ss.fffzzz", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
				return date;

			DateTime.TryParse(value, out date);
			return date;
		}

        public static string FormatIso8601DateTime(DateTime value, bool includeTimeZone = false) {
            if (includeTimeZone)
                return string.Format("{0:yyyy-MM-ddTHH:mm:ss.fffzzz}", value);

            return string.Format("{0:yyyy-MM-ddTHH:mm:ss}", value);
        }

        public static string FormatTimeString(string value, TimeFormat timeFormat) {
			if (timeFormat == TimeFormat.Military || string.IsNullOrEmpty(value) || value.Length != 5 || value.Substring(2, 1) != ":")
				return value;

			DateTime.TryParse(value, out DateTime date);

			if (date == DateTime.MinValue)
				return value;

			return string.Format("{0:hh:mm tt}", date);
		}

        public static int TimeZoneOffsetMinutes() {
            var now = DateTime.Now;
            var utcNow = now.ToUniversalTime();
            return (int)(now - utcNow).TotalMinutes;
        }

        public static RenderingResult ExportToPdf(TypeReportSource reportSource) {
			var rp = new ReportProcessor();
			var deviceInfo = new Hashtable();
			return rp.RenderReport("PDF", reportSource, deviceInfo);
		}

		public static RenderingResult ExportToPdf(InstanceReportSource reportSource) {
			var rp = new ReportProcessor();
			var deviceInfo = new Hashtable();
			return rp.RenderReport("PDF", reportSource, deviceInfo);
		}

		public static RenderingResult ExportToWord(TypeReportSource reportSource) {
			var rp = new ReportProcessor();
			var deviceInfo = new Hashtable();
			return rp.RenderReport("DOCX", reportSource, deviceInfo);
		}

		public static RenderingResult ExportToWord(InstanceReportSource reportSource) {
			var rp = new ReportProcessor();
			var deviceInfo = new Hashtable();
			return rp.RenderReport("DOCX", reportSource, deviceInfo);
		}

		public static RenderingResult ExportToExcel(TypeReportSource reportSource) {
			var rp = new ReportProcessor();
			var deviceInfo = new Hashtable();
			return rp.RenderReport("XLSX", reportSource, deviceInfo);
		}

		public static RenderingResult ExportToExcel(InstanceReportSource reportSource) {
			var rp = new ReportProcessor();
			var deviceInfo = new Hashtable();
			return rp.RenderReport("XLSX", reportSource, deviceInfo);
		}

		public static RenderingResult ExportToExcel(IList<Telerik.Reporting.Report> reports) {
			var rb = new ReportBook();

			foreach (var report in reports) {
				rb.ReportSources.Add(new InstanceReportSource {
					ReportDocument = report
				});
			}

			var reportSource = new InstanceReportSource {
				ReportDocument = rb
			};

			var rp = new ReportProcessor();
			var deviceInfo = new Hashtable();

			return rp.RenderReport("XLSX", reportSource, deviceInfo);
		}

        private static Dictionary<string, string> HtmlTagReplacements => new Dictionary<string, string> {
            { "&rsquo;", "'" }
        };
    }
}