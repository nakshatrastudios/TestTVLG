﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Travelog.Biz {
    public class MailAttachment {
        public byte[] Content { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }

        public MailAttachment(byte[] content, string fileName, string contentType) {
            Content = content;
            FileName = fileName;
            ContentType = contentType;
        }
    }

    public class Mail {
        private const string ClassName = "Travelog.Biz.Mail";
        public static Mail Instance { get; } = new Mail();

        private async Task SendMailAsync(MailMessage message, MailAttachment[] attachments, string from = null) {
            if (AppSettings.IsLocal)
                return;

            if (AppSettings.IsDevelopmentMode) {
                foreach (var row in message.To) {
                    if (!DebugModeWhitelist.Any(t => row.Address.Equals(t, StringComparison.OrdinalIgnoreCase) || (t.StartsWith("@") && row.Address.EndsWith(t, StringComparison.OrdinalIgnoreCase))))
                        return;
                }

                foreach (var row in message.CC) {
                    if (!DebugModeWhitelist.Any(t => row.Address.Equals(t, StringComparison.OrdinalIgnoreCase) || (t.StartsWith("@") && row.Address.EndsWith(t, StringComparison.OrdinalIgnoreCase))))
                        return;
                }

                foreach (var row in message.Bcc) {
                    if (!DebugModeWhitelist.Any(t => row.Address.Equals(t, StringComparison.OrdinalIgnoreCase) || (t.StartsWith("@") && row.Address.EndsWith(t, StringComparison.OrdinalIgnoreCase))))
                        return;
                }
            }

            if (message.To.Count == 0 && message.CC.Count == 0 && message.Bcc.Count > 0)
                message.To.Add(new MailAddress(message.From.Address, "Undisclosed recipients"));

            if (from == null) {
                if (!message.To.Any(t => t.Address.Equals("steve@travelog.com.au", StringComparison.OrdinalIgnoreCase) || t.Address == AppSettings.EmailAccounts || t.Address == AppSettings.EmailEnquiries || t.Address == AppSettings.EmailErrors || t.Address == AppSettings.EmailServiceDesk)
                && !message.CC.Any(t => t.Address.Equals("steve@travelog.com.au", StringComparison.OrdinalIgnoreCase) || t.Address == AppSettings.EmailAccounts || t.Address == AppSettings.EmailEnquiries || t.Address == AppSettings.EmailErrors || t.Address == AppSettings.EmailServiceDesk)
                && !message.Bcc.Any(t => t.Address.Equals("steve@travelog.com.au", StringComparison.OrdinalIgnoreCase) || t.Address == AppSettings.EmailAccounts || t.Address == AppSettings.EmailEnquiries || t.Address == AppSettings.EmailErrors || t.Address == AppSettings.EmailServiceDesk)) {

                    message.Bcc.Add(new MailAddress("steve@travelog.com.au"));
                }
            }
            else {
                message.Bcc.Add(new MailAddress(from));
            }

            message.From = new MailAddress(AppSettings.EmailFrom, from ?? AppSettings.AppTitle);
            message.ReplyToList.Add(new MailAddress(from ?? AppSettings.EmailFrom, from ?? AppSettings.AppTitle));
            message.IsBodyHtml = true;
            message.BodyEncoding = Encoding.UTF8;

            if (attachments != null) {
                foreach (var attachment in attachments) {
                    var ms = new MemoryStream(attachment.Content);
                    message.Attachments.Add(new Attachment(ms, attachment.FileName, attachment.ContentType));
                }
            }

            var client = new SmtpClient(SmtpHost, SmtpPort) {
                Credentials = new NetworkCredential(SmtpUserName, SmtpPassword),
                EnableSsl = SmtpEnableSsl
            };

            client.SendCompleted += (s, e) => {
                message.Dispose();
                client.Dispose();
            };

            try {
                await client.SendMailAsync(message);
            }
            catch (SmtpFailedRecipientsException ex) {
                for (int i = 0; i < ex.InnerExceptions.Length; i++) {
                    var status = ex.InnerExceptions[i].StatusCode;

                    if (status == SmtpStatusCode.MailboxBusy || status == SmtpStatusCode.MailboxUnavailable) {
                        Thread.Sleep(5000);
                        await client.SendMailAsync(message);
                    }
                    else {
                        await ExceptionManagerBiz.Instance.HandleExceptionAsync(ClassName, "SendMailAsync", new MailException(string.Format("Failed to deliver message to {0}.", ex.InnerExceptions[i].FailedRecipient), ex));
                    }
                }
            }
            catch (Exception ex) {
                await ExceptionManagerBiz.Instance.HandleExceptionAsync(ClassName, "SendMailAsync", new MailException(ex.Message));
            }
        }

        public async Task SendMailAsync(string to, string cc, string bcc, string subject, string body, MailAttachment[] attachments = null, string from = null) {
            var message = new MailMessage();

            if (!string.IsNullOrEmpty(to)) {
                foreach (var email in to.Split(new[] { ";", "," }, StringSplitOptions.RemoveEmptyEntries)) {
                    if (DataValidation.IsEmail(email.Trim()))
                        message.To.Add(email.Trim());
                }
            }

            if (!string.IsNullOrEmpty(cc)) {
                foreach (var email in cc.Split(new[] { ";", "," }, StringSplitOptions.RemoveEmptyEntries)) {
                    if (DataValidation.IsEmail(email.Trim()))
                        message.CC.Add(email.Trim());
                }
            }

            if (!string.IsNullOrEmpty(bcc)) {
                foreach (var email in bcc.Split(new[] { ";", "," }, StringSplitOptions.RemoveEmptyEntries)) {
                    if (DataValidation.IsEmail(email.Trim()))
                        message.Bcc.Add(email.Trim());
                }
            }

            if (!string.IsNullOrEmpty(subject))
                message.Subject = subject;

            if (!string.IsNullOrEmpty(body))
                message.Body = body;

            await SendMailAsync(message, attachments, from);
        }

        public async Task SendMailAsync(string to, string subject, string body, string from = null) {
            await SendMailAsync(to, null, null, subject, body, null, from);
        }

        public void SendMail(string to, string subject, string body, MailAttachment[] attachments = null) {
            SendMailAsync(to, null, null, subject, body, attachments).Wait();
        }

        private string SmtpHost => "smtp.office365.com";
        private int SmtpPort => 587;
        private bool SmtpEnableSsl => true;
        private string SmtpUserName => "system@travelog.online";
        private string SmtpPassword => "p!_L-9-.JsLj2jfoNtmq";

        private string[] DebugModeWhitelist => new string[] {
            "@imacs.co.nz",
            "@systemsfactory.com.au",
            "@travelog.online",
            "@travelog.com.au",
            "@travelaccounting.com.au",
            "ben@chaos.org.nz",
            "darren.french@gmail.com",
            "jkelderman64@gmail.com",
            "noelfrench51@gmail.com",
            "noelfrench@bigpond.com",
            "sharonauguste@bigpond.com",
            "shazauguste65@gmail.com",
            "steve.cartwright@outlook.com",
            "steve.cartwright@outlook.com.au",
            "acc4tvl@aol.com"
        };
    }
}