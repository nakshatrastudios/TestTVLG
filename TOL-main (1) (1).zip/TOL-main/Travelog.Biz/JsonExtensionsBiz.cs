using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Travelog.Biz {
    public static class JsonExtensionsBiz {
        public static JsonSerializerOptions JsonSerializerOptions() {
            var options = new JsonSerializerOptions {
                PropertyNameCaseInsensitive = true,
                PropertyNamingPolicy = null
            };

            options.Converters.Add(new DateTimeConverter());
            return options;
        }
    }

    public class DateTimeConverter : JsonConverter<DateTime> {
        public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options) {
            return DateTime.Parse(reader.GetString());
        }

        public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options) {
            writer.WriteStringValue(value);
        }
    }
}